# file: system2.py
import argparse
import subprocess
import sys

r = subprocess.run(["printf", "%s\n", "a file name; rm -rf /"], capture_output=True, text=True, check=True)
print("argument passed literally:", repr(r.stdout.strip()))
try:
    subprocess.run([sys.executable, "-c", "import sys; sys.exit(3)"], check=True)
except subprocess.CalledProcessError as e:
    print("CalledProcessError, returncode", e.returncode)
try:
    subprocess.run(["sleep", "5"], timeout=0.2)
except subprocess.TimeoutExpired:
    print("TimeoutExpired after 0.2 s (the child was killed)")

parser = argparse.ArgumentParser(prog="notes", description="A tiny notes tool.")
parser.add_argument("-v", "--verbose", action="count", default=0)
sub = parser.add_subparsers(dest="command", required=True)
add = sub.add_parser("add", help="add a note")
add.add_argument("text")
add.add_argument("--tag", action="append", default=[])
ls = sub.add_parser("list", help="list notes")
def limit(text):
    n = int(text)
    if not 1 <= n <= 100:
        raise argparse.ArgumentTypeError(f"{n} is not in 1..100")
    return n
ls.add_argument("--limit", type=limit, default=10)

print(parser.parse_args(["-vv", "add", "buy milk", "--tag", "home", "--tag", "shop"]))
print(parser.parse_args(["list", "--limit", "5"]))
try:
    parser.parse_args(["list", "--limit", "500"])
except SystemExit as e:
    print("argparse exited with status", e.code)
