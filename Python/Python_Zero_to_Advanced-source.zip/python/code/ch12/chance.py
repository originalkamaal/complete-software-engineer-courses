# file: chance.py
import random
import secrets
import statistics

rng = random.Random(42)                                # seeded: reproducible
print([rng.randint(1, 6) for _ in range(10)], rng.choice("ABC"), rng.sample(range(100), 3))
data = [rng.gauss(170, 8) for _ in range(10_000)]
print(f"mean {statistics.fmean(data):.2f}, median {statistics.median(data):.2f}, stdev {statistics.stdev(data):.2f}")
print("quartiles:", [round(q, 1) for q in statistics.quantiles(data, n=4)])
print("token:", len(secrets.token_urlsafe(32)), "chars | secure pick:", secrets.choice(["heads", "tails"]) in ("heads", "tails"))
print("constant-time compare:", secrets.compare_digest("s3cret", "s3cret"))
