# file: times.py
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

utc_now = datetime(2026, 11, 15, 9, 30, tzinfo=timezone.utc)
for zone in ("Asia/Kolkata", "Europe/Berlin", "America/New_York", "Australia/Sydney"):
    local = utc_now.astimezone(ZoneInfo(zone))
    print(f"{zone:>18}: {local:%Y-%m-%d %H:%M} (UTC{local:%z})")
print(datetime.fromisoformat("2026-11-15T14:00:00+05:30").astimezone(timezone.utc).isoformat())
print(date(2026, 12, 25) - date(2026, 11, 15), timedelta(hours=36).days, (date(2024, 3, 1) - date(2024, 2, 1)).days)

ny = ZoneInfo("America/New_York")
start = datetime(2026, 11, 1, 0, 30, tzinfo=ny)        # the night clocks fall back (02:00 EDT -> 01:00 EST)
later = start + timedelta(hours=2)                     # wall-clock arithmetic
elapsed = later.astimezone(timezone.utc) - start.astimezone(timezone.utc)
print(f"{start:%H:%M %Z} + 2h = {later:%H:%M %Z}; real time elapsed: {elapsed}")
utc_later = (start.astimezone(timezone.utc) + timedelta(hours=2)).astimezone(ny)
print(f"adding 2h in UTC instead: {utc_later:%H:%M %Z}")
gap = datetime(2026, 3, 8, 2, 30, tzinfo=ny)           # this wall time never happens (clocks jump 02:00 -> 03:00)
print("nonexistent 02:30 on 8 March round-trips to:", gap.astimezone(timezone.utc).astimezone(ny).strftime("%H:%M %Z"))
