# file: regex.py
import re

LOG = re.compile(r"""
    (?P<ip>\d{1,3}(?:\.\d{1,3}){3}) \s+
    \[(?P<when>[^\]]+)\] \s+
    "(?P<method>GET|POST|PUT|DELETE) \s (?P<path>\S+)" \s+
    (?P<status>\d{3})
""", re.VERBOSE)
line = '10.0.0.7 [15/Nov/2026:09:30:00] "GET /api/items?id=3" 404'
m = LOG.search(line)
print(m.group("ip"), m["method"], m["path"], int(m["status"]), m.groupdict()["when"])
print(re.findall(r"\b\w+@\w+\.\w+\b", "mail ana@ex.com or ben@ex.org now"))
html = "<b>bold</b> and <i>italic</i>"
print(re.findall(r"<.*>", html), re.findall(r"<.*?>", html))       # greedy vs lazy
print(re.sub(r"(\d{4})-(\d{2})-(\d{2})", r"\3/\2/\1", "due 2026-11-15, paid 2026-12-01"))
print(bool(re.fullmatch(r"[A-Z]{2}\d{4}", "AB1234")), bool(re.fullmatch(r"[A-Z]{2}\d{4}", "AB12345")))
