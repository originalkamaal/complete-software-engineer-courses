# file: system.py
import argparse
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

r = subprocess.run(["python3", "-c", "import sys; print('child says hi'); sys.exit(3)"], capture_output=True, text=True)
print("stdout:", r.stdout.strip(), "| return code:", r.returncode)
try:
    subprocess.run(["false"], check=True)
except subprocess.CalledProcessError as e:
    print("CalledProcessError, exit status", e.returncode)
user_input = "file.txt; echo INJECTED"
print("list args are not interpreted by a shell:", subprocess.run(["echo", user_input], capture_output=True, text=True).stdout.strip())

with tempfile.TemporaryDirectory() as d:
    src = Path(d, "src"); src.mkdir()
    (src / "a.txt").write_text("alpha")
    shutil.copytree(src, Path(d, "copy"))
    archive = shutil.make_archive(str(Path(d, "backup")), "zip", root_dir=d, base_dir="src")
    print(sorted(p.name for p in Path(d).iterdir()), Path(archive).suffix, shutil.which("python3") is not None)
print("HOME is set:", "HOME" in os.environ, "| PATH entries:", len(os.environ["PATH"].split(os.pathsep)))

parser = argparse.ArgumentParser(prog="resize", description="Resize images.")
parser.add_argument("files", nargs="+")
parser.add_argument("--width", type=int, required=True)
parser.add_argument("--format", choices=["png", "jpg"], default="png")
parser.add_argument("-v", "--verbose", action="store_true")
args = parser.parse_args(["a.png", "b.png", "--width", "640", "-v"])
print(args)
try:
    parser.parse_args(["a.png", "--width", "wide"])
except SystemExit as e:
    print("argparse exited with status", e.code)
