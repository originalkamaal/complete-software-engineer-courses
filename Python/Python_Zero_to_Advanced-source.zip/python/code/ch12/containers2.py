# file: containers2.py
import bisect
import heapq
from collections import Counter, defaultdict, deque, OrderedDict

words = "the cat sat on the mat the end".split()
c = Counter(words)
print(c.most_common(2), c["dog"], (c + Counter(["dog"]))["dog"])

graph = defaultdict(list)                        # adjacency list without key checks
for a, b in [("a", "b"), ("a", "c"), ("b", "d"), ("c", "d"), ("d", "e")]:
    graph[a].append(b)
def bfs(start):
    seen, q, order = {start}, deque([start]), []
    while q:
        node = q.popleft()                       # O(1); list.pop(0) is O(n)
        order.append(node)
        for nxt in graph[node]:
            if nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return order
print("bfs:", bfs("a"))

last3 = deque(maxlen=3)                          # a sliding window
for x in range(6):
    last3.append(x)
print("last three:", list(last3))

scores = [("ada", 91), ("bo", 78), ("cy", 99), ("di", 85)]
print("top 2:", heapq.nlargest(2, scores, key=lambda s: s[1]))
tasks = []
for pri, name in [(3, "email"), (1, "outage"), (2, "review")]:
    heapq.heappush(tasks, (pri, name))
print("by priority:", [heapq.heappop(tasks)[1] for _ in range(3)])

grades = [60, 70, 80, 90]
print("grade for 85:", "FDCBA"[bisect.bisect(grades, 85)])

lru = OrderedDict()
for key in ["a", "b", "c", "a", "d"]:
    lru[key] = True
    lru.move_to_end(key)
    if len(lru) > 3:
        lru.popitem(last=False)                  # evict the least recently used
print("LRU keeps:", list(lru))
