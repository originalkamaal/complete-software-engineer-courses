# file: containers.py
import bisect
import heapq
from collections import ChainMap, Counter, deque

recent = deque(maxlen=3)                              # keeps only the last 3
for event in ["a", "b", "c", "d", "e"]:
    recent.append(event)
print(recent)
oldest = recent.popleft()
print(oldest, recent)

inventory, sold = Counter(apples=5, pears=2), Counter(apples=3, kiwis=1)
print(inventory - sold, inventory + sold, (inventory - sold).total())

defaults = {"theme": "light", "lang": "en", "debug": False}
config_file = {"lang": "hi"}
cli = {"debug": True}
settings = ChainMap(cli, config_file, defaults)        # first mapping wins
print(settings["theme"], settings["lang"], settings["debug"], dict(settings))

tasks = []
for prio, name in [(3, "deploy"), (1, "fix bug"), (2, "review")]:
    heapq.heappush(tasks, (prio, name))
print([heapq.heappop(tasks)[1] for _ in range(3)], heapq.nlargest(2, [5, 1, 9, 7]))

grades = [60, 70, 80, 90]                              # boundaries
letters = "FDCBA"
print([letters[bisect.bisect_right(grades, s)] for s in (55, 60, 75, 99)])
sorted_list = [10, 20, 30]
bisect.insort(sorted_list, 25)
print(sorted_list)
