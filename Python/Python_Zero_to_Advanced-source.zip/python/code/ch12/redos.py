# file: redos.py
import re
import time
for n in (16, 18, 20, 22):
    s = "a" * n + "!"                                 # almost matches: the final "!" forces full backtracking
    for name, pat in (("(a+)+$", r"(a+)+$"), ("(?>a+)+$", r"(?>a+)+$")):
        t = time.perf_counter()
        re.match(pat, s)
        el = time.perf_counter() - t
        print(f"n={n}  {name:<9} {el * 1000:9.2f} ms")
