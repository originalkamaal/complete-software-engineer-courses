# file: planner/planner.py
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

PEOPLE = {"Alan (London)": "Europe/London", "Bruno (Berlin)": "Europe/Berlin", "Carla (New York)": "America/New_York"}
WORK_START, WORK_END = time(9), time(17)

def available_utc(zone, day):
    """The person's working hours on a local calendar day, as a UTC interval (or None on weekends)."""
    if day.weekday() >= 5:
        return None
    tz = ZoneInfo(zone)
    start = datetime.combine(day, WORK_START, tzinfo=tz).astimezone(timezone.utc)
    end = datetime.combine(day, WORK_END, tzinfo=tz).astimezone(timezone.utc)
    return start, end

def intervals(zone, first, last):
    d = first - timedelta(days=1)                      # local days near the UTC range boundaries
    out = []
    while d <= last + timedelta(days=1):
        iv = available_utc(zone, d)
        if iv:
            out.append(iv)
        d += timedelta(days=1)
    return out

def common_slots(first, last, minutes=30):
    lists = [intervals(z, first, last) for z in PEOPLE.values()]
    common = lists[0]
    for other in lists[1:]:                            # intersect sorted interval lists pairwise
        merged = []
        for a0, a1 in common:
            for b0, b1 in other:
                lo, hi = max(a0, b0), min(a1, b1)
                if lo < hi:
                    merged.append((lo, hi))
        common = merged
    step = timedelta(minutes=minutes)
    slots = []
    for lo, hi in common:
        t = lo
        while t + step <= hi:
            slots.append(t)
            t += step
    return slots

def brute_free(t):                                     # check one instant directly in every local zone
    for zone in PEOPLE.values():
        local = t.astimezone(ZoneInfo(zone))
        if local.weekday() >= 5 or not (WORK_START <= local.time() < WORK_END):
            return False
    return True

first, last = date(2026, 10, 26), date(2026, 11, 6)    # US clocks change on Sunday Nov 1, 2026; Europe's on Oct 25
slots = common_slots(first, last)
for s in slots[:3] + slots[-3:]:
    locals_ = "  ".join(f"{name.split()[0]} {s.astimezone(ZoneInfo(z)):%a %H:%M}" for name, z in PEOPLE.items())
    print(f"{s:%a %d %b %H:%M} UTC | {locals_}")
by_day = {}
for s in slots:
    by_day.setdefault(s.date(), []).append(s)
print({str(d): len(v) for d, v in by_day.items()})
t = datetime(2026, 10, 26, tzinfo=timezone.utc)
in_slots = free = mismatches = 0
while t < datetime(2026, 11, 7, tzinfo=timezone.utc):  # brute force: every minute of the two weeks
    covered = any(s <= t < s + timedelta(minutes=30) for s in by_day.get(t.date(), []))
    is_free = brute_free(t)
    in_slots += covered; free += is_free; mismatches += covered != is_free
    t += timedelta(minutes=1)
print(f"brute force over every minute: {free} free minutes, {in_slots} minutes in proposed slots, mismatches: {mismatches}")
