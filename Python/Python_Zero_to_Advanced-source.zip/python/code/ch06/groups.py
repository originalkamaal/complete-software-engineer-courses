# file: groups.py
def validate(user):
    errors = []
    if not user.get("name"):
        errors.append(ValueError("name is required"))
    if not isinstance(user.get("age"), int):
        errors.append(TypeError("age must be an int"))
    if "@" not in user.get("email", ""):
        errors.append(ValueError("email is invalid"))
    if errors:
        raise ExceptionGroup("invalid user", errors)

try:
    validate({"name": "", "age": "ten", "email": "nope"})
except* ValueError as eg:
    print("value problems:", [str(e) for e in eg.exceptions])
except* TypeError as eg:
    print("type problems:", [str(e) for e in eg.exceptions])
