# file: bare_except.py
import sys

def run(handler_catches_everything):
    for attempt in range(3):
        try:
            sys.exit(f"exit requested on attempt {attempt}")
        except BaseException if handler_catches_everything else Exception as e:
            print(f"  swallowed {type(e).__name__}: {e}")
    return "loop finished - the exit request was ignored"

print("bare except:", run(True))
print("except Exception:")
run(False)
print("never printed")
