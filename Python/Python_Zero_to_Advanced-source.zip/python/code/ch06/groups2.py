# file: groups2.py
import asyncio

async def fetch(name, fail_with=None):
    await asyncio.sleep(0.01)
    if fail_with:
        raise fail_with(f"{name} failed")
    return name

async def main():
    try:
        async with asyncio.TaskGroup() as tg:
            tg.create_task(fetch("a"))
            tg.create_task(fetch("b", TimeoutError))
            tg.create_task(fetch("c", ValueError))
            tg.create_task(fetch("d", TimeoutError))
    except* TimeoutError as eg:
        print("timeouts:", sorted(str(e) for e in eg.exceptions))
    except* ValueError as eg:
        print("bad values:", [str(e) for e in eg.exceptions])

asyncio.run(main())
