# file: managers.py
import contextlib
import time

class Timer:
    def __enter__(self):
        self.start = time.perf_counter()
        return self
    def __exit__(self, exc_type, exc, tb):
        self.elapsed = time.perf_counter() - self.start
        print(f"  block took {self.elapsed * 1000:.1f} ms (exception: {exc_type.__name__ if exc_type else None})")
        return False                                   # do not suppress exceptions

with Timer() as t:
    sum(range(1_000_000))
try:
    with Timer():
        raise KeyError("boom")
except KeyError:
    print("KeyError still propagated after __exit__ ran")

@contextlib.contextmanager
def tag(name):
    print(f"<{name}>")
    try:
        yield name.upper()                             # value bound by 'as'
    finally:
        print(f"</{name}>")                            # runs even on errors

with tag("div") as t:
    with tag("p"):
        print("  hello", t)

with contextlib.ExitStack() as stack:                  # a variable number of resources
    names = [stack.enter_context(tag(n)) for n in ("a", "b", "c")]
    print("  inside all three:", names)

with contextlib.suppress(FileNotFoundError):
    open("/definitely/missing.txt")
print("suppress: continued after FileNotFoundError")
