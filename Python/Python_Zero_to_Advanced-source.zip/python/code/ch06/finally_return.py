# file: finally_return.py
def risky():
    try:
        raise RuntimeError("important failure")
    finally:
        return "everything is fine"                   # swallows the RuntimeError!
print(risky())
