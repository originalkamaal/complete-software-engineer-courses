# file: custom.py
import json
import traceback

class ConfigError(Exception):
    """Base class for configuration problems."""

class MissingKey(ConfigError):
    def __init__(self, key):
        super().__init__(f"missing required key {key!r}")
        self.key = key

def load(text):
    try:
        cfg = json.loads(text)
    except json.JSONDecodeError as e:
        raise ConfigError("config is not valid JSON") from e      # keep the cause
    for key in ("host", "port"):
        if key not in cfg:
            raise MissingKey(key)
    return cfg

for text in ('{"host": "db", "port": 5432}', '{"host": "db"}', "{not json"):
    try:
        print("loaded:", load(text))
    except MissingKey as e:
        print("MissingKey for", e.key)
    except ConfigError as e:
        print("ConfigError:", e, "| caused by:", repr(e.__cause__))

try:
    try:
        load('{"host": "db"}')
    except ConfigError as e:
        e.add_note("while loading /etc/app.json")
        raise
except ConfigError:
    print(traceback.format_exc().strip().splitlines()[-2:])
