# file: chaining.py
import traceback

class ConfigError(Exception):
    pass

def load_port(text):
    try:
        return int(text)
    except ValueError as err:
        raise ConfigError(f"port must be a number, got {text!r}") from err

for fn in (lambda: load_port("80a"),):
    try:
        fn()
    except ConfigError as e:
        print("message:", e, "| cause:", repr(e.__cause__))
        lines = traceback.format_exception(e)
        print("traceback mentions the cause:", any("direct cause" in l for l in lines))

def parse_rows(rows):
    for i, row in enumerate(rows, 1):
        try:
            yield int(row)
        except ValueError as e:
            e.add_note(f"while parsing row {i} of the input")
            raise

try:
    list(parse_rows(["1", "2", "x"]))
except ValueError as e:
    print(type(e).__name__, e, e.__notes__)
