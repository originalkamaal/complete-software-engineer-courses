# file: basics.py
def parse_age(text):
    try:
        age = int(text)
    except ValueError:
        print(f"  {text!r} is not a number")
        return None
    else:                                              # only when int() succeeded
        if age < 0:
            raise ValueError(f"age cannot be negative: {age}")
        return age
    finally:
        print(f"  (parse_age({text!r}) done)")

for s in ("42", "forty", "-3"):
    try:
        print("result:", parse_age(s))
    except ValueError as e:
        print("caller caught:", e)

print([cls.__name__ for cls in ZeroDivisionError.__mro__])     # exceptions form a class hierarchy
try:
    1 / 0
except ArithmeticError as e:                           # a base class catches its subclasses
    print("caught via base class:", type(e).__name__, "-", e)
