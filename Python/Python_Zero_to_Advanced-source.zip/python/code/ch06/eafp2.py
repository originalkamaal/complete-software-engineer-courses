# file: eafp2.py
import os
import threading
import time

path = "volatile.txt"

def deleter():
    for _ in range(2000):
        try:
            open(path, "w").close()
            os.remove(path)
        except FileNotFoundError:
            pass

lbyl_failures = 0
t = threading.Thread(target=deleter)
t.start()
for _ in range(2000):
    if os.path.exists(path):
        try:
            with open(path) as f:
                f.read()
        except FileNotFoundError:
            lbyl_failures += 1        # existed when checked, gone when opened
    time.sleep(0)
t.join()
print("LBYL: check said 'exists' but open failed", "at least once" if lbyl_failures else "zero times this run")
