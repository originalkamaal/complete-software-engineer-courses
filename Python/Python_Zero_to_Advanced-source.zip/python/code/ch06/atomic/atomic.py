# file: atomic/atomic.py
import contextlib
import os
import random
import tempfile
from pathlib import Path

@contextlib.contextmanager
def atomic_write(path, mode="w"):
    path = Path(path)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, mode) as f:
            yield f
            f.flush()
            os.fsync(f.fileno())                        # data is on disk before the rename
        os.replace(tmp, path)                           # atomic on POSIX and Windows
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)                              # leave no temporary debris
        raise

class Store:
    def __init__(self):
        self.data = {}
    @contextlib.contextmanager
    def transaction(self):
        snapshot = dict(self.data)                      # shallow copy is enough for immutable values
        try:
            yield self.data
        except BaseException:
            self.data.clear()
            self.data.update(snapshot)                  # roll back
            raise

class InjectedFault(Exception):
    pass

target = Path("settings.txt")
target.write_text("version=1\n" * 3)
rng = random.Random(6)
ok = failed = 0
for trial in range(200):
    lines = [f"version={trial}\n"] * 3
    try:
        with atomic_write(target) as f:
            for line in lines:
                if rng.random() < 0.2:
                    raise InjectedFault("crash while writing")
                f.write(line)
        ok += 1
    except InjectedFault:
        failed += 1
    content = target.read_text().splitlines()
    assert len(content) == 3 and len(set(content)) == 1, f"torn write detected: {content}"
leftovers = [p.name for p in Path(".").glob(".settings.txt.*")]
print(f"atomic_write: {ok} completed, {failed} crashed mid-write, never a torn file; temp files left: {leftovers}")

store = Store()
with store.transaction() as d:
    d["alice"], d["bob"] = 100, 50
committed = rolled_back = 0
for trial in range(1000):
    before = dict(store.data)
    try:
        with store.transaction() as d:
            amount = rng.randint(1, 30)
            src, dst = rng.sample(["alice", "bob"], 2)
            d[src] -= amount                            # debit first...
            if d[src] < 0 or rng.random() < 0.1:
                raise InjectedFault("insufficient funds or crash")
            d[dst] += amount                            # ...then credit
        committed += 1
    except InjectedFault:
        rolled_back += 1
        assert store.data == before, "partial transaction leaked"
    assert sum(store.data.values()) == 150 and min(store.data.values()) >= 0
print(f"transactions: {committed} committed, {rolled_back} rolled back; total money conserved: {sum(store.data.values())}")
target.unlink()
