# file: eafp.py
import os
import tempfile
import timeit

d = {"a": 1}
def lbyl(k):
    return d[k] if k in d else None
def eafp(k):
    try:
        return d[k]
    except KeyError:
        return None
for name, f in (("LBYL", lbyl), ("EAFP", eafp)):
    hit = min(timeit.repeat(lambda: f("a"), number=200_000, repeat=3))
    miss = min(timeit.repeat(lambda: f("zz"), number=200_000, repeat=3))
    print(f"{name}: key present {hit * 5:.2f} µs/op, key missing {miss * 5:.2f} µs/op")

path = os.path.join(tempfile.gettempdir(), "maybe.txt")
try:                                                    # EAFP for files: no window between check and use
    with open(path) as f:
        print(f.read())
except FileNotFoundError:
    print("no such file - handled without a separate exists() check")
