# file: wordstat/src/wordstat/__init__.py
from .core import top_words
__all__ = ["top_words"]
