# file: wordstat/src/wordstat/core.py
import re
from collections import Counter

WORD = re.compile(r"[A-Za-z']+")

def top_words(text, n=5):
    return Counter(w.lower() for w in WORD.findall(text)).most_common(n)
