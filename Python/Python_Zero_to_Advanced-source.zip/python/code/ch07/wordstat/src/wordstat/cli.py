# file: wordstat/src/wordstat/cli.py
import argparse
import sys
from importlib.metadata import version
from .core import top_words

def main(argv=None):
    p = argparse.ArgumentParser(prog="wordstat", description="Show the most common words.")
    p.add_argument("files", nargs="*", help="files to read (default: stdin)")
    p.add_argument("-n", type=int, default=5, help="how many words")
    p.add_argument("--version", action="version", version=f"%(prog)s {version('wordstat')}")
    args = p.parse_args(argv)
    text = "".join(open(f).read() for f in args.files) if args.files else sys.stdin.read()
    for word, count in top_words(text, args.n):
        print(f"{count:>6}  {word}")
    return 0
