# file: wordstat/tests/test_core.py
import subprocess
import sys

import wordstat
from wordstat.cli import main

def test_counts_case_insensitively():
    assert wordstat.top_words("A a B", 2) == [("a", 2), ("b", 1)]

def test_apostrophes_are_part_of_words():
    assert wordstat.top_words("don't don't do", 1) == [("don't", 2)]

def test_cli_reads_files(tmp_path, capsys):
    f = tmp_path / "t.txt"
    f.write_text("x y x")
    assert main([str(f), "-n", "1"]) == 0
    assert capsys.readouterr().out.split() == ["2", "x"]

def test_module_comes_from_src_layout():
    assert "/src/wordstat/" in wordstat.__file__        # editable install points at src/
