# file: circ/models.py
from circ.services import audit                       # models imports services...

class User:
    def __init__(self, name):
        self.name = name
        audit(f"created {name}")
