# file: circ/services.py
from circ.models import User                          # ...and services imports models: a cycle

def audit(msg):
    print("audit:", msg)

def make_admin():
    return User("admin")
