# file: greetings.py
print(f"  [greetings module body runs, __name__ = {__name__!r}]")
DEFAULT = "hello"

def greet(name, word=DEFAULT):
    return f"{word}, {name}"

if __name__ == "__main__":
    print(greet("from the command line"))
