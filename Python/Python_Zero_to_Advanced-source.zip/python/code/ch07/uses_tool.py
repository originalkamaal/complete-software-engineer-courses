# file: uses_tool.py
import tool
import tool                      # cached in sys.modules: the top level does not run again
print("imported; CONFIG =", tool.CONFIG)
