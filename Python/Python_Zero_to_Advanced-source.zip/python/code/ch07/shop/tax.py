# file: shop/tax.py
VAT = 0.20
