# file: shop/__init__.py
"""A tiny package."""
from .pricing import total                              # re-export: users can write `from shop import total`
__version__ = "1.0"
