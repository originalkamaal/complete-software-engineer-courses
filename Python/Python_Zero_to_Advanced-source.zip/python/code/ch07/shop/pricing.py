# file: shop/pricing.py
from .tax import VAT                                    # relative import within the package

def total(net):
    return round(net * (1 + VAT), 2)
