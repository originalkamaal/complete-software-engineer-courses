# file: shop/__main__.py
import sys
from shop import total, __version__

amount = float(sys.argv[1]) if len(sys.argv) > 1 else 100.0
print(f"shop {__version__}: total for {amount} is {total(amount)}")
