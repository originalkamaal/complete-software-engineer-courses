# file: tool.py
import time

print(f"tool.py top level runs, __name__ = {__name__!r}")
CONFIG = {"retries": 3}

def main():
    print("main() runs: doing the script's work")

if __name__ == "__main__":
    main()
