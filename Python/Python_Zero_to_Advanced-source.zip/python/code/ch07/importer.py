# file: importer.py
import sys
print("first import:")
import greetings
print("second import (cached, body does not run again):")
import greetings as g2
print(greetings is g2, "greetings" in sys.modules, greetings.greet("ana"))
from greetings import greet
print(greet("ben", word="hi"))
print("search path starts with the script's directory:", sys.path[0].rsplit("/", 1)[-1])
