# file: pkgdemo/app/util.py
def double(x):
    return 2 * x
