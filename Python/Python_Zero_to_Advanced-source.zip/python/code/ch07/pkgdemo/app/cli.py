# file: pkgdemo/app/cli.py
from .util import double
print("double(21) =", double(21), "| __name__ =", __name__, "| __package__ =", __package__)
