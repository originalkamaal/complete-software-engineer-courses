# file: circ_fixed/models.py
from circ_fixed import services                       # import the module, not the name

class User:
    def __init__(self, name):
        self.name = name
        services.audit(f"created {name}")             # attribute looked up at call time
