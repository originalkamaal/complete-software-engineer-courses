# file: circ_fixed/services.py
from circ_fixed import models

def audit(msg):
    print("audit:", msg)

def make_admin():
    return models.User("admin")
