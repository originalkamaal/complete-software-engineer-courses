# file: generics312.py
from collections.abc import Callable, Iterable
from typing import Any, Protocol

class SupportsLessThan(Protocol):
    def __lt__(self, other: Any, /) -> bool: ...

def biggest[T: SupportsLessThan](xs: Iterable[T]) -> T:
    it = iter(xs)
    best = next(it)
    for x in it:
        if best < x:
            best = x
    return best

class Stack[T]:
    def __init__(self) -> None:
        self._items: list[T] = []
    def push(self, x: T) -> None:
        self._items.append(x)
    def pop(self) -> T:
        return self._items.pop()

type Handler = Callable[[str], None]

def run(h: Handler) -> None:
    h("event")

s: Stack[int] = Stack()
s.push(1)
print(biggest([3, 9, 4]), biggest(["pear", "apple"]), s.pop())
run(lambda e: print("handled", e))
print(Stack.__type_params__, Handler.__value__)
