# file: untyped.py
def add_tax(price):                                   # no annotations: body not checked by default
    rate = 1.2
    label = rate + " EUR"                             # float + str: certain TypeError at run time
    return price * rate, label

def typed_caller(p: float) -> object:
    return add_tax(p)
