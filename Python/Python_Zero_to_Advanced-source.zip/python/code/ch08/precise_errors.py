# file: precise_errors.py
from precise import Movie, UserId, lookup, open_db, MAX_RETRIES

m: Movie = {"title": "Arrival", "yeer": 2016}         # typo in a key
open_db("app.db", "delete")                           # not an allowed mode
lookup(7)                                             # plain int is not a UserId
MAX_RETRIES = 5                                       # reassigning a Final
