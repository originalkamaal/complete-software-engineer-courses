# file: basics.py
def greeting(name: str, times: int = 1) -> str:
    return ", ".join([f"hello {name}"] * times)

print(greeting("ana", 2))
print(greeting.__annotations__)
print(greeting(42))                                   # runs fine: annotations are not enforced
total: int = "not an int"                             # also runs fine
print(total)
