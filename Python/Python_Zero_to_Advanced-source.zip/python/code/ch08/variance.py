# file: variance.py
from collections.abc import Sequence

def mean_list(xs: list[float]) -> float:
    return sum(xs) / len(xs)

def mean_seq(xs: Sequence[float]) -> float:
    return sum(xs) / len(xs)

ints: list[int] = [1, 2, 3]
print(mean_seq(ints))                                  # fine: Sequence is read-only (covariant)
print(mean_list(ints))                                 # mypy error: list is invariant
