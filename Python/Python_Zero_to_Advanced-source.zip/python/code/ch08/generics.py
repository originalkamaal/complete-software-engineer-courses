# file: generics.py
from collections.abc import Callable, Iterable

def first[T](items: list[T]) -> T | None:             # PEP 695 syntax (3.12+)
    return items[0] if items else None

def apply_all[T, R](f: Callable[[T], R], xs: Iterable[T]) -> list[R]:
    return [f(x) for x in xs]

class Stack[T]:
    def __init__(self) -> None:
        self._items: list[T] = []
    def push(self, item: T) -> None:
        self._items.append(item)
    def pop(self) -> T:
        return self._items.pop()

def shout(name: str | None) -> str:
    if name is None:                                  # narrowing: after this, name is str
        return "NOBODY"
    return name.upper()

s: Stack[int] = Stack()
s.push(3)
n = first([10, 20])
lengths = apply_all(len, ["a", "bcd"])
print(s.pop(), n, lengths, shout(None), shout("ana"))
