# file: narrowing.py
from typing import TYPE_CHECKING, TypeGuard, TypeIs, overload

@overload
def double(x: int) -> int: ...
@overload
def double(x: str) -> str: ...
def double(x: int | str) -> int | str:
    return x * 2

def is_str_list(xs: list[object]) -> TypeGuard[list[str]]:   # TypeIs here: mypy error (invariance)
    return all(isinstance(x, str) for x in xs)

def is_int(x: object) -> TypeIs[int]:                         # fine: int is a subtype of object
    return isinstance(x, int)

def shout(xs: list[object]) -> str:
    if is_str_list(xs):
        return " ".join(x.upper() for x in xs)     # the checker knows x is str here
    return "not all strings"

n: int = double(21)
s: str = double("ab")
print(n, s, shout(["a", "b"]), shout(["a", 1]), [v for v in [1, "x", 2] if is_int(v)])
if TYPE_CHECKING:
    reveal_type(double(21))                          # only the type checker sees this
