# file: boundary.py
import json
from pydantic import BaseModel, Field, ValidationError

class Order(BaseModel):
    id: int
    customer: str = Field(min_length=1)
    quantity: int = Field(gt=0)
    unit_price: float

    @property
    def total(self) -> float:
        return self.quantity * self.unit_price

good = json.loads('{"id": "17", "customer": "ana", "quantity": 3, "unit_price": "2.5"}')
order = Order.model_validate(good)                     # strings are converted where it is safe
print(order, "| total:", order.total, "| id type:", type(order.id).__name__)
bad = json.loads('{"id": "x", "customer": "", "quantity": 0}')
try:
    Order.model_validate(bad)
except ValidationError as e:
    for err in e.errors():
        print(f"  {'.'.join(map(str, err['loc']))}: {err['msg']}")
