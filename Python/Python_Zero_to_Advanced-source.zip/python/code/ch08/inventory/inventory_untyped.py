# file: inventory/inventory_untyped.py
def load(rows):
    stock = {}
    for name, qty in rows:
        stock[name] = qty                              # bug 1: qty stays a string ("3")
    return stock

def restock(stock, name, amount):
    stock[name] = stock.get(name) + amount             # bug 2: get() may return None

def report(stock):
    lines = []
    for name, qty in sorted(stock.items()):
        lines.append(name + ": " + qty)                # bug 3 (masked by bug 1): concatenates qty
    return "\n".join(lines)

stock = load([("apple", "3"), ("pear", "5")])
restock(stock, "apple", "2")
print(report(stock))
