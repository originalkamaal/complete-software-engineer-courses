# file: inventory/inventory_fixed.py
from collections.abc import Iterable

Stock = dict[str, int]

def load(rows: Iterable[tuple[str, str]]) -> Stock:
    stock: Stock = {}
    for name, qty in rows:
        stock[name] = int(qty)                         # fix 1: parse at the boundary
    return stock

def restock(stock: Stock, name: str, amount: int) -> None:
    stock[name] = stock.get(name, 0) + amount          # fix 2: default for new items

def report(stock: Stock) -> str:
    lines = []
    for name, qty in sorted(stock.items()):
        lines.append(f"{name}: {qty}")                 # fix 3: format, do not concatenate
    return "\n".join(lines)

if __name__ == "__main__":
    stock = load([("apple", "3"), ("pear", "5")])
    restock(stock, "apple", 2)
    restock(stock, "kiwi", 4)
    print(report(stock))
