# file: inventory/inventory_typed.py
from collections.abc import Iterable

Stock = dict[str, int]

def load(rows: Iterable[tuple[str, str]]) -> Stock:
    stock: Stock = {}
    for name, qty in rows:
        stock[name] = qty
    return stock

def restock(stock: Stock, name: str, amount: int) -> None:
    stock[name] = stock.get(name) + amount

def report(stock: Stock) -> str:
    lines = []
    for name, qty in sorted(stock.items()):
        lines.append(name + ": " + qty)
    return "\n".join(lines)
