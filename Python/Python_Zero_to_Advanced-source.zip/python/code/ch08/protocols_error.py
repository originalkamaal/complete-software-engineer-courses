# file: protocols_error.py
from protocols import Label, Square, total_area
total_area([Square(1), Label()])
