# file: generics_errors.py
from generics import Stack, first

s: Stack[int] = Stack()
s.push("three")                                       # wrong item type
value = first(["a", "b"])
print(value.upper())                                  # value may be None
