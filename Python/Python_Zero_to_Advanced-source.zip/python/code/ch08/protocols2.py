# file: protocols2.py
from typing import Protocol, runtime_checkable

@runtime_checkable
class Closeable(Protocol):
    def close(self) -> None: ...

class File:
    def close(self) -> None:
        print("file closed")

class Liar:
    close = 42                        # an attribute named close, not a method

def shutdown(*things: object) -> None:
    for t in things:
        if isinstance(t, Closeable):
            print(type(t).__name__, "passes isinstance")

shutdown(File(), Liar(), "text")
