# file: precise.py
from typing import Final, Literal, NewType, TypedDict, overload

class Movie(TypedDict):
    title: str
    year: int

UserId = NewType("UserId", int)
MAX_RETRIES: Final = 3
Mode = Literal["read", "write"]

def open_db(path: str, mode: Mode) -> str:
    return f"{path} opened for {mode}"

def lookup(uid: UserId) -> str:
    return f"user #{uid}"

@overload
def parse(x: str) -> int: ...
@overload
def parse(x: bytes) -> str: ...
def parse(x: str | bytes) -> int | str:
    return int(x) if isinstance(x, str) else x.decode()

m: Movie = {"title": "Arrival", "year": 2016}
print(open_db("app.db", "read"), lookup(UserId(7)), parse("42") + 1, parse(b"ok").upper(), m["title"])
