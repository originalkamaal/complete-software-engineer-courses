# file: weather/service.py
import time
import urllib.request

def fetch_temperature(city):
    with urllib.request.urlopen(f"https://example.invalid/weather?city={city}") as r:   # never called in tests
        return float(r.read())

def advice(city):
    t = fetch_temperature(city)
    hour = time.localtime().tm_hour
    if t < 5:
        return "wear a coat"
    return "take sunglasses" if 10 <= hour < 17 and t > 25 else "dress normally"
