# file: weather/test_service.py
from unittest import mock
import service

def test_cold(monkeypatch):
    monkeypatch.setattr(service, "fetch_temperature", lambda city: 2.0)
    assert service.advice("Oslo") == "wear a coat"

def test_sunny_afternoon(monkeypatch):
    monkeypatch.setattr(service, "fetch_temperature", lambda city: 31.0)
    fake_time = mock.Mock()
    fake_time.localtime.return_value = mock.Mock(tm_hour=14)
    monkeypatch.setattr(service, "time", fake_time)      # replace the module as seen by service
    assert service.advice("Jaipur") == "take sunglasses"
    fake_time.localtime.assert_called_once()

def test_records_calls():
    with mock.patch("service.fetch_temperature", return_value=20.0) as fake:
        assert service.advice("Pune") == "dress normally"
    fake.assert_called_once_with("Pune")
