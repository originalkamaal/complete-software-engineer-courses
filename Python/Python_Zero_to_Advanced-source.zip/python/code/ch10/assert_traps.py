# file: assert_traps.py
def withdraw(balance, amount):
    assert amount <= balance, "insufficient funds"     # WRONG place for validation
    return balance - amount

if __name__ == "__main__":
    try:
        withdraw(10, 50)
    except AssertionError as e:
        print("normal run: AssertionError:", e)
