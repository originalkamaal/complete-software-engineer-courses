# file: shopping/cart.py
class Cart:
    def __init__(self, prices):
        self.prices = prices
        self.items = {}
    def add(self, sku, qty=1):
        if sku not in self.prices:
            raise KeyError(f"unknown sku {sku!r}")
        if qty <= 0:
            raise ValueError("quantity must be positive")
        self.items[sku] = self.items.get(sku, 0) + qty
    def total(self, discount=0.0):
        gross = sum(self.prices[s] * q for s, q in self.items.items())
        return round(gross * (1 - discount), 2)
    def save(self, path):
        path.write_text("\n".join(f"{s},{q}" for s, q in sorted(self.items.items())))
