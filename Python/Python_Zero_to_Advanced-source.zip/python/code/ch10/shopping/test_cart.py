# file: shopping/test_cart.py
import pytest
from cart import Cart

@pytest.fixture
def cart():                                            # fresh object for every test
    return Cart({"apple": 0.5, "pear": 0.75, "melon": 3.0})

def test_empty_total(cart):
    assert cart.total() == 0

@pytest.mark.parametrize("items, discount, expected", [
    ({"apple": 2}, 0.0, 1.0),
    ({"apple": 2, "melon": 1}, 0.0, 4.0),
    ({"pear": 4}, 0.1, 2.7),
])
def test_totals(cart, items, discount, expected):
    for sku, q in items.items():
        cart.add(sku, q)
    assert cart.total(discount) == expected

def test_unknown_sku(cart):
    with pytest.raises(KeyError, match="kiwi"):
        cart.add("kiwi")

def test_bad_quantity(cart):
    with pytest.raises(ValueError):
        cart.add("apple", 0)

def test_save(cart, tmp_path):                         # tmp_path: a fresh temporary directory
    cart.add("pear"); cart.add("apple", 3)
    f = tmp_path / "cart.csv"
    cart.save(f)
    assert f.read_text().splitlines() == ["apple,3", "pear,1"]

def test_deliberately_failing(cart):                   # shows pytest's assertion introspection
    cart.add("melon", 2)
    assert cart.total() == 5.0
