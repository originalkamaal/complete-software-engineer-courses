# file: dedupe/dedupe.py
import re

def normalise(line):
    line = line.strip().lower()
    return re.sub(r"\s+", " ", line)                   # recompiles via the cache on every call

def dedupe_slow(lines):
    seen, out = [], []
    for line in lines:
        key = normalise(line)
        if key not in seen:                            # O(n) per line
            seen.append(key)
            out.append(line)
    return out

SPACES = re.compile(r"\s+")

def dedupe_fast(lines):
    seen, out = set(), []
    for line in lines:
        key = SPACES.sub(" ", line.strip().lower())
        if key not in seen:                            # O(1) average
            seen.add(key)
            out.append(line)
    return out
