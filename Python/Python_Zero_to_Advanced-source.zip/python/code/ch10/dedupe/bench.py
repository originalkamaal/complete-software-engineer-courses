# file: dedupe/bench.py
import cProfile
import io
import pstats
import random
import time
from dedupe import dedupe_fast, dedupe_slow

rng = random.Random(10)
lines = [f"  Event {rng.randint(0, 5000)}   from   host{rng.randint(0, 3)} " for _ in range(30_000)]
pr = cProfile.Profile()
pr.enable(); dedupe_slow(lines); pr.disable()
s = io.StringIO()
pstats.Stats(pr, stream=s).sort_stats("tottime").print_stats(3)
print("\n".join(l for l in s.getvalue().splitlines() if "function calls" in l or "dedupe" in l or "normalise" in l or "sub" in l))
for f in (dedupe_slow, dedupe_fast):
    t = time.perf_counter()
    out = f(lines)
    print(f"{f.__name__}: {len(out):,} unique of {len(lines):,} in {(time.perf_counter() - t) * 1000:,.0f} ms")
