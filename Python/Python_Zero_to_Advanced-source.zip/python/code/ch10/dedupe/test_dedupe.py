# file: dedupe/test_dedupe.py
import pytest
from hypothesis import given, strategies as st
from dedupe import dedupe_fast, dedupe_slow

@pytest.mark.parametrize("impl", [dedupe_slow, dedupe_fast])
@pytest.mark.parametrize("lines, expected", [
    ([], []),
    (["a", "A ", " a"], ["a"]),
    (["x  y", "x y", "X\tY", "z"], ["x  y", "z"]),
    (["b", "a", "b"], ["b", "a"]),
])
def test_examples(impl, lines, expected):
    assert impl(lines) == expected

@given(st.lists(st.text(alphabet="ab \t", max_size=6), max_size=30))
def test_fast_matches_slow(lines):
    assert dedupe_fast(lines) == dedupe_slow(lines)
