# file: logging_demo.py
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)-7s %(name)s: %(message)s")
log = logging.getLogger("orders")

def process(order):
    log.debug("processing %s", order)                  # below INFO: not shown
    if order["qty"] <= 0:
        log.warning("rejecting order %s: qty=%d", order["id"], order["qty"])
        return False
    log.info("accepted order %s", order["id"])
    return True

for o in ({"id": 1, "qty": 2}, {"id": 2, "qty": 0}):
    process(o)
try:
    1 / 0
except ZeroDivisionError:
    log.exception("unexpected failure")                # logs the traceback too
