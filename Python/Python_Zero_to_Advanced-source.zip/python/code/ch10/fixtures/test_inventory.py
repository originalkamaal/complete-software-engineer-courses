# file: fixtures/test_inventory.py
import pytest
from inventory import Inventory

@pytest.fixture
def inv(tmp_path):
    path = tmp_path / "inv.json"
    path.write_text('{"pen": 2}')
    inventory = Inventory(path)
    yield inventory                       # the test runs here
    print(f"\nteardown: file still exists = {path.exists()}")

def test_loads_existing(inv):
    assert inv.items == {"pen": 2}

def test_save_round_trip(inv):
    inv.add("ink", 3)
    inv.save()
    assert Inventory(inv.path).items == {"ink": 3, "pen": 2}

@pytest.mark.parametrize("qty", [0, -1, -100])
def test_rejects_non_positive(inv, qty):
    with pytest.raises(ValueError, match="positive"):
        inv.add("pad", qty)

@pytest.mark.parametrize(("start", "add", "expected"), [(0, 1, 1), (2, 3, 5)], ids=["new", "existing"])
def test_add_cases(tmp_path, start, add, expected):
    inv = Inventory(tmp_path / "x.json")
    if start:
        inv.add("pen", start)
    inv.add("pen", add)
    assert inv.items["pen"] == expected
