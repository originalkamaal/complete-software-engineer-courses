# file: fixtures/inventory.py
import json
from pathlib import Path

class Inventory:
    def __init__(self, path: Path):
        self.path = path
        self.items = json.loads(path.read_text()) if path.exists() else {}
    def add(self, name: str, qty: int) -> None:
        if qty <= 0:
            raise ValueError("qty must be positive")
        self.items[name] = self.items.get(name, 0) + qty
    def save(self) -> None:
        self.path.write_text(json.dumps(self.items, sort_keys=True))
