# file: logconfig.py
import logging
import logging.config

logging.config.dictConfig({
    "version": 1,
    "formatters": {"brief": {"format": "%(levelname)-7s %(name)s: %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "brief", "stream": "ext://sys.stdout"}},
    "loggers": {"app.db": {"level": "WARNING"}},            # quiet one subsystem
    "root": {"level": "DEBUG", "handlers": ["console"]},
})

log = logging.getLogger("app.web")
db = logging.getLogger("app.db")

class Expensive:
    calls = 0
    def __str__(self):
        Expensive.calls += 1
        return "expensive repr"

log.debug("request %s took %d ms", "/home", 42)
db.debug("query plan: %s", Expensive())                     # filtered: never formatted
db.warning("slow query: %s", "SELECT ...")
try:
    1 / 0
except ZeroDivisionError:
    log.exception("handler failed")                         # includes the traceback
print("Expensive.__str__ calls:", Expensive.calls)
