# file: profiling.py
import cProfile
import pstats
import io

def slow_unique(words):
    seen = []
    for w in words:
        if w not in seen:                              # O(n) membership in a list
            seen.append(w)
    return seen

def normalise(words):
    return [w.strip().lower() for w in words]

def pipeline(n):
    words = [f" Word{i % 3000} " for i in range(n)]
    return len(slow_unique(normalise(words)))

pr = cProfile.Profile()
pr.enable()
pipeline(60_000)
pr.disable()
out = io.StringIO()
pstats.Stats(pr, stream=out).sort_stats("cumulative").print_stats(6)
print("\n".join(l for l in out.getvalue().splitlines() if l.strip())[:1400])
