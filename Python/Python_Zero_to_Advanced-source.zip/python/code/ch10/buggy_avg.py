# file: buggy_avg.py
def average(values):
    total = 0
    for v in values:
        total += v
    return total / len(values)

def report(groups):
    return {name: average(vals) for name, vals in groups.items()}

print(report({"a": [1, 2, 3], "b": []}))
