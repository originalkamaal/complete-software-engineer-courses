# file: patching/clock.py
import datetime

def now() -> datetime.datetime:
    return datetime.datetime.now()
