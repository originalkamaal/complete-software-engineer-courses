# file: patching/test_greeter.py
import datetime
from unittest.mock import patch
import greeter

MORNING = datetime.datetime(2026, 11, 16, 9, 0)
EVENING = datetime.datetime(2026, 11, 16, 18, 0)

def test_wrong_target_has_no_effect():
    with patch("clock.now", return_value=EVENING):
        with patch("greeter.now", return_value=MORNING):
            assert greeter.greeting() == "good morning"     # only greeter.now matters

def test_right_target():
    with patch("greeter.now", return_value=EVENING) as fake:
        assert greeter.greeting() == "good afternoon"
        fake.assert_called_once_with()
