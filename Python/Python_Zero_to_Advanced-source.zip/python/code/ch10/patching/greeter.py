# file: patching/greeter.py
from clock import now                   # greeter now holds its own reference

def greeting() -> str:
    return "good morning" if now().hour < 12 else "good afternoon"
