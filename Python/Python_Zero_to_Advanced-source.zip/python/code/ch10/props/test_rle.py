# file: props/test_rle.py
from hypothesis import given, strategies as st
from rle import decode, encode, encode_buggy

@given(st.text())
def test_roundtrip(s):
    assert decode(encode(s)) == s

@given(st.text())
def test_no_adjacent_equal_runs(s):
    runs = encode(s)
    assert all(a[0] != b[0] for a, b in zip(runs, runs[1:]))

@given(st.text(alphabet="ab"))
def test_buggy_roundtrip(s):
    assert decode(encode_buggy(s)) == s
