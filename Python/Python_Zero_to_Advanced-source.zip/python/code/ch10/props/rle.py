# file: props/rle.py
def encode(s):
    """Run-length encoding: 'aaab' -> [('a', 3), ('b', 1)]."""
    out = []
    for ch in s:
        if out and out[-1][0] == ch:
            out[-1] = (ch, out[-1][1] + 1)
        else:
            out.append((ch, 1))
    return out

def decode(pairs):
    return "".join(ch * n for ch, n in pairs)

def encode_buggy(s):                                     # "optimised": skips single characters' counts
    return [(ch, n) for ch, n in encode(s) if n > 1] or [(s[:1], 1)] if s else []
