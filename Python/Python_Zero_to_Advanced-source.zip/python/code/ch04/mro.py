# file: mro.py
class Base:
    def __init__(self, **kwargs):
        print("Base.__init__")
        super().__init__(**kwargs)           # object.__init__ at the end of the chain

class Logged(Base):
    def __init__(self, *, log_name="app", **kwargs):
        print(f"Logged.__init__ ({log_name})")
        super().__init__(**kwargs)

class Cached(Base):
    def __init__(self, *, cache_size=128, **kwargs):
        print(f"Cached.__init__ ({cache_size})")
        super().__init__(**kwargs)

class Service(Logged, Cached):
    def __init__(self, **kwargs):
        print("Service.__init__")
        super().__init__(**kwargs)

print([c.__name__ for c in Service.__mro__])
Service(log_name="svc", cache_size=10)
