# file: vector.py
import math
from functools import total_ordering

@total_ordering                                      # derives <=, >, >= from __eq__ and __lt__
class Vector:
    def __init__(self, *coords):
        self.coords = tuple(coords)
    def __repr__(self):
        return f"Vector{self.coords}"
    def __len__(self):
        return len(self.coords)
    def __getitem__(self, i):
        return self.coords[i]                        # also makes the object iterable and sliceable
    def __eq__(self, other):
        return isinstance(other, Vector) and self.coords == other.coords
    def __hash__(self):
        return hash(self.coords)                     # immutable coords: safe to hash
    def __lt__(self, other):
        return abs(self) < abs(other)
    def __abs__(self):
        return math.hypot(*self.coords)
    def __bool__(self):
        return any(self.coords)
    def __add__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        return Vector(*(a + b for a, b in zip(self, other, strict=True)))
    def __mul__(self, k):
        if not isinstance(k, (int, float)):
            return NotImplemented
        return Vector(*(a * k for a in self))
    __rmul__ = __mul__                               # 3 * v works too

v, w = Vector(3, 4), Vector(1, 2)
print(v + w, 2 * v, v * 0.5, abs(v), len(v), v[0], list(v), v[::-1])
print(v == Vector(3, 4), v > w, sorted([v, w, Vector(0, 1)]), bool(Vector(0, 0)))
print({v: "hashable"}, max([v, w]))
try:
    v + 1
except TypeError as e:
    print("TypeError:", e)
