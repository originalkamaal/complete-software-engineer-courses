# file: slots.py
import sys
import tracemalloc

class PlainPoint:
    def __init__(self, x, y):
        self.x, self.y = x, y

class SlotPoint:
    __slots__ = ("x", "y")
    def __init__(self, x, y):
        self.x, self.y = x, y

def measure(cls, n=100_000):
    tracemalloc.start()
    pts = [cls(i, i) for i in range(n)]
    current, _ = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return current / n, pts

plain_bytes, _ = measure(PlainPoint)
slot_bytes, _ = measure(SlotPoint)
print(f"per instance: plain ~{plain_bytes:.0f} bytes, slots ~{slot_bytes:.0f} bytes")
p = SlotPoint(1, 2)
try:
    p.z = 3
except AttributeError as e:
    print("AttributeError:", e)
print(hasattr(PlainPoint(1, 2), "__dict__"), hasattr(p, "__dict__"))
