# file: poly/poly.py
import random
from fractions import Fraction
from itertools import zip_longest

class Polynomial:
    __slots__ = ("c",)
    def __init__(self, *coeffs):                       # c[i] is the coefficient of x^i
        c = [Fraction(x) for x in coeffs]
        while c and c[-1] == 0:
            c.pop()                                    # normalise: no trailing zeros
        self.c = tuple(c)
    @property
    def degree(self):
        return len(self.c) - 1                         # -1 for the zero polynomial
    def __call__(self, x):
        acc = Fraction(0)
        for coef in reversed(self.c):                  # Horner: ((a_n x + a_{n-1}) x + ...)
            acc = acc * x + coef
        return acc
    def __add__(self, o):
        o = _lift(o)
        return Polynomial(*(a + b for a, b in zip_longest(self.c, o.c, fillvalue=0))) if o is not NotImplemented else o
    __radd__ = __add__
    def __neg__(self):
        return Polynomial(*(-a for a in self.c))
    def __sub__(self, o):
        o = _lift(o)
        return self + (-o) if o is not NotImplemented else o
    def __rsub__(self, o):
        return (-self) + o
    def __mul__(self, o):
        o = _lift(o)
        if o is NotImplemented:
            return o
        out = [Fraction(0)] * max(0, len(self.c) + len(o.c) - 1)
        for i, a in enumerate(self.c):
            for j, b in enumerate(o.c):
                out[i + j] += a * b
        return Polynomial(*out)
    __rmul__ = __mul__
    def __pow__(self, n):
        if not isinstance(n, int) or n < 0:
            return NotImplemented
        result, base = Polynomial(1), self
        while n:                                       # binary exponentiation
            if n & 1:
                result *= base
            base, n = base * base, n >> 1
        return result
    def __eq__(self, o):
        o = _lift(o)
        return o is not NotImplemented and self.c == o.c
    def __hash__(self):
        return hash(self.c)
    def __iter__(self):
        return iter(self.c)
    def __bool__(self):
        return bool(self.c)
    def derivative(self):
        return Polynomial(*(i * a for i, a in enumerate(self.c) if i))
    def __repr__(self):
        if not self.c:
            return "0"
        terms = []
        for i in range(len(self.c) - 1, -1, -1):
            a = self.c[i]
            if a == 0:
                continue
            sign = "-" if a < 0 else "+"
            a = abs(a)
            coef = "" if a == 1 and i else str(a)
            var = "" if i == 0 else "x" if i == 1 else f"x^{i}"
            terms.append((sign, coef + var))
        s = ("-" if terms[0][0] == "-" else "") + terms[0][1]
        return s + "".join(f" {sg} {t}" for sg, t in terms[1:])

def _lift(o):
    if isinstance(o, Polynomial):
        return o
    if isinstance(o, (int, Fraction)):
        return Polynomial(o)
    return NotImplemented

x = Polynomial(0, 1)
p = (x + 1) ** 3
print("(x + 1)^3 =", p, "| derivative:", p.derivative(), "| p(2) =", p(2))
print("(x - 1)(x + 1) =", (x - 1) * (x + 1), "| equal to x^2 - 1:", (x - 1) * (x + 1) == x ** 2 - 1)
print(Polynomial(Fraction(1, 2), 0, -3), "| zero:", x - x, "| hashable:", len({x ** 2 - 1, (x - 1) * (x + 1)}))

rng = random.Random(4)
rand_poly = lambda: Polynomial(*(rng.randint(-5, 5) for _ in range(rng.randint(0, 5))))
for _ in range(2000):
    a, b, v = rand_poly(), rand_poly(), Fraction(rng.randint(-9, 9), rng.randint(1, 4))
    assert (a * b)(v) == a(v) * b(v) and (a + b)(v) == a(v) + b(v) and (a - b)(v) == a(v) - b(v)
    assert (a ** 2)(v) == a(v) ** 2
    # exact identity for polynomials: d/dx a at v equals the coefficient of h in a(v + h)
    shifted = Polynomial(0) + a(Polynomial(v, 1))   # a(v + h) as a polynomial in h (lifted: a may be zero)
    assert a.derivative()(v) == (shifted.c[1] if len(shifted.c) > 1 else 0)
print("2,000 random checks of +, -, *, **, and derivative passed")
