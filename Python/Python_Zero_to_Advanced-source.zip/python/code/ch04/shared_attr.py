# file: shared_attr.py
class Cart:
    items = []                                        # shared by every Cart!
    def add(self, x):
        self.items.append(x)
c1, c2 = Cart(), Cart()
c1.add("apple")
print(c2.items, c1.items is c2.items is Cart.items)
