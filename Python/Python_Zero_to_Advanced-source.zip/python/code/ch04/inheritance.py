# file: inheritance.py
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self): ...
    def describe(self):
        return f"{type(self).__name__} with area {self.area():.2f}"

class Rect(Shape):
    def __init__(self, w, h):
        self.w, self.h = w, h
    def area(self):
        return self.w * self.h

class Square(Rect):
    def __init__(self, side):
        super().__init__(side, side)

print(Square(3).describe(), isinstance(Square(1), Shape))
try:
    Shape()
except TypeError as e:
    print("TypeError:", e)

class Base:
    def hello(self): return ["Base"]
class Left(Base):
    def hello(self): return ["Left"] + super().hello()
class Right(Base):
    def hello(self): return ["Right"] + super().hello()
class Child(Left, Right):
    def hello(self): return ["Child"] + super().hello()
print(Child().hello())
print([c.__name__ for c in Child.__mro__])
