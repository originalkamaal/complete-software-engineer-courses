# file: eq_hash.py
class P:
    def __init__(self, x): self.x = x
    def __eq__(self, o): return isinstance(o, P) and self.x == o.x
print(P.__hash__)
try:
    {P(1)}
except TypeError as e:
    print("TypeError:", e)
