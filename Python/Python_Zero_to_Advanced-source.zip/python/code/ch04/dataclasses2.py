# file: dataclasses2.py
from dataclasses import dataclass, field, asdict, replace

@dataclass(frozen=True, order=True)
class Version:
    major: int
    minor: int = 0
    patch: int = 0
    def __str__(self):
        return f"{self.major}.{self.minor}.{self.patch}"

@dataclass(kw_only=True)
class Order:
    id: str
    items: list[str] = field(default_factory=list)       # a new list per instance
    total_paise: int = 0
    note: str = field(default="", repr=False)
    def __post_init__(self):
        if self.total_paise < 0:
            raise ValueError("total_paise must be >= 0")

versions = sorted([Version(1, 10), Version(1, 4, 2), Version(2)])
print([str(v) for v in versions], Version(1, 4) < Version(1, 10))
v = Version(1, 2, 3)
print(replace(v, patch=4), {v: "release"}[Version(1, 2, 3)])
try:
    v.major = 9
except Exception as e:
    print(type(e).__name__, e)

a, b = Order(id="o1"), Order(id="o2")
a.items.append("pen")
print(a, b, asdict(a))
try:
    Order(id="o3", total_paise=-5)
except ValueError as e:
    print("ValueError:", e)
