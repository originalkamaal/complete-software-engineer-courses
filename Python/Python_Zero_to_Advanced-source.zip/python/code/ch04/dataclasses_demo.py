# file: dataclasses_demo.py
from dataclasses import dataclass, field, asdict, replace
from enum import Enum, auto

class Status(Enum):
    TODO = auto()
    DOING = auto()
    DONE = auto()

@dataclass(order=True)
class Task:
    priority: int
    title: str = field(compare=False)
    status: Status = field(default=Status.TODO, compare=False)
    tags: list[str] = field(default_factory=list, compare=False)

@dataclass(frozen=True, slots=True)
class Money:
    amount: int                                       # in cents
    currency: str = "EUR"
    def __add__(self, other):
        if other.currency != self.currency:
            raise ValueError("currency mismatch")
        return Money(self.amount + other.amount, self.currency)

tasks = [Task(2, "write"), Task(1, "plan", tags=["urgent"]), Task(3, "ship")]
print(sorted(tasks)[0])
t = tasks[0]
t.status = Status.DONE
print(asdict(t), replace(t, title="rewrite").title)
m = Money(150) + Money(250)
print(m, {m: "frozen dataclasses are hashable"})
try:
    m.amount = 0
except Exception as e:
    print(type(e).__name__, e)
print([s.name for s in Status], Status["DONE"] is Status.DONE, Status.DONE.value)
