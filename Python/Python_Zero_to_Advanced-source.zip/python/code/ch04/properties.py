# file: properties.py
import sys

class Temperature:
    def __init__(self, celsius):
        self.celsius = celsius                         # goes through the setter
    @property
    def celsius(self):
        return self._c
    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            raise ValueError("below absolute zero")
        self._c = value
    @property
    def fahrenheit(self):                              # computed, read-only
        return self._c * 9 / 5 + 32

t = Temperature(25)
t.celsius = 30
print(t.celsius, t.fahrenheit)
for bad in (-300,):
    try:
        t.celsius = bad
    except ValueError as e:
        print("ValueError:", e)

class PointDict:
    def __init__(self, x, y): self.x, self.y = x, y
class PointSlots:
    __slots__ = ("x", "y")
    def __init__(self, x, y): self.x, self.y = x, y
d, s = PointDict(1, 2), PointSlots(1, 2)
print("with __dict__:", sys.getsizeof(d) + sys.getsizeof(d.__dict__), "bytes; with __slots__:", sys.getsizeof(s), "bytes")
try:
    s.z = 3
except AttributeError as e:
    print("AttributeError:", e)
