# file: classes.py
class Account:
    bank = "PyBank"                                   # class attribute: shared
    count = 0

    def __init__(self, owner, balance=0):
        self.owner = owner                            # instance attributes
        self.balance = balance
        Account.count += 1

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self.balance += amount
        return self

    @classmethod
    def from_csv(cls, line):                          # alternative constructor
        owner, balance = line.split(",")
        return cls(owner, int(balance))

    @staticmethod
    def fee(amount):
        return round(amount * 0.01, 2)

a = Account("ana", 100).deposit(50)
b = Account.from_csv("ben,20")
print(a.owner, a.balance, b.owner, b.balance, Account.count, a.bank, Account.fee(250))
print(vars(a), type(a).__name__, isinstance(a, Account))
a.bank = "MyBank"                                     # creates an INSTANCE attribute that shadows the class one
print(a.bank, b.bank, Account.bank)
