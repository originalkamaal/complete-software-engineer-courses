# file: loops.py
def find_divisor(n):
    for d in range(2, int(n ** 0.5) + 1):
        if n % d == 0:
            print(f"{n} = {d} * {n // d}")
            break
    else:                                          # no break happened: no divisor found
        print(f"{n} is prime")

for n in (91, 97):
    find_divisor(n)

fruits = ["apple", "banana", "cherry"]
for i, f in enumerate(fruits, start=1):
    print(i, f)
for f, price in zip(fruits, [1.2, 0.5, 3.0]):
    print(f"{f}: {price}")

n, steps = 27, 0                                   # Collatz: a while loop with an unknown count
while n != 1:
    n = 3 * n + 1 if n % 2 else n // 2
    steps += 1
print("Collatz steps from 27:", steps)
