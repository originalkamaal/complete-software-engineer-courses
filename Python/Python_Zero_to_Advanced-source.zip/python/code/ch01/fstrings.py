# file: fstrings.py
items = [("apples", 3, 0.5), ("kiwis", 12, 0.25), ("watermelon", 1, 3.0)]
print(f"{'item':<12}|{'qty':>5}|{'cost':>8}")
for name, qty, price in items:
    print(f"{name:<12}|{qty:>5}|{qty * price:>8.2f}")

n, ratio, name = 1234567, 0.4567, "Ada"
print(f"{n:,} {n:_x} {ratio:.1%} {3.14159:08.3f} {name!r} {name:*^9}")
width = 6
print(f"[{42:>{width}}] [{42:<{width}}]")      # width from a variable
total = sum(q * p for _, q, p in items)
print(f"{total=}, {len(items)=}, {total / len(items)=:.3f}")

s = "  Hello, World  "
print(repr(s.strip()), s.split(","), "-".join(["a", "b", "c"]))
print("hello world".title(), "Straße".casefold(), "abc".startswith(("x", "a")))
print("report.final.pdf".rsplit(".", 1), "a=b=c".partition("="), "tab\tsep".expandtabs(4))
print("café".encode("utf-8"), "naïve".isascii(), "١٢٣".isdigit(), int("١٢٣"))
