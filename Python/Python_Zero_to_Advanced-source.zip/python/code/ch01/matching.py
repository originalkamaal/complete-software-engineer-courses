# file: matching.py
def describe(cmd):
    match cmd:
        case ["go", direction]:
            return f"move {direction}"
        case ["take", *items] if items:
            return f"pick up {', '.join(items)}"
        case {"action": "say", "text": str(text)}:
            return f"say {text!r}"
        case int(n) | float(n) if n < 0:
            return f"negative number {n}"
        case "quit" | "exit":
            return "goodbye"
        case _:
            return f"unknown: {cmd!r}"

for c in (["go", "north"], ["take", "key", "lamp"], ["take"], {"action": "say", "text": "hi"}, -3, 2.5, "quit"):
    print(f"{c!r:>35} -> {describe(c)}")

RED = "red"
def wrong(colour):
    match colour:
        case RED:                                  # binds a NEW name RED: matches everything!
            return "red?"
print(wrong("blue"))
