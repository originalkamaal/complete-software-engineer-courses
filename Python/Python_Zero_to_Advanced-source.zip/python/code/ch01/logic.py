# file: logic.py
for v in (0, 1, -1, "", "0", [], [0], None, 0.0, {}):
    print(f"{v!r:>5} -> {bool(v)}")
x = 5
print(0 < x < 10, 1 < x == 5 > 3)                 # chained: (1 < x) and (x == 5) and (5 > 3)
print("" or "default", 0 or None, 3 and "yes", [] and "never evaluated")
def expensive():
    print("  (expensive called)")
    return True
print("short-circuit:", False and expensive(), True or expensive())
print(None is None, [] == [], [] is [])
