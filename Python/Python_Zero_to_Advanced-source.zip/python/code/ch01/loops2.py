# file: loops2.py
import io

names = ["ada", "alan", "grace"]
scores = [91, 78, 88]
for i, (n, s) in enumerate(zip(names, scores), start=1):
    print(f"{i}. {n:6} {s}")
try:
    list(zip(names, [1, 2], strict=True))
except ValueError as e:
    print("zip strict:", e)
print(list(range(10, 0, -3)), list(reversed(names)), range(0, 10**12, 7)[-1])

stream = io.StringIO("alpha\nbeta\n\ngamma\n")
while (line := stream.readline()):                  # assign and test in one expression
    print(repr(line.rstrip("\n")))

data = [3, 8, 1, 9, 4]
if (big := [x for x in data if x > 5]):
    print("big values:", big)

for n in range(2, 20):
    for d in range(2, int(n ** 0.5) + 1):
        if n % d == 0:
            break
    else:                                           # runs only when the inner loop did not break
        print(n, end=" ")
print()
