# file: logic2.py
x = 5
print(1 < x < 10, 1 < x > 3, (1 < x) < 10)        # the last is (True) < 10, i.e. 1 < 10
print(0 or "default", "" or [] or "last", "a" and "b", None and 1)
given = ""
name = given or "anonymous"                         # careful: "" and 0 and [] are all replaced
count = 0
print(name, count or 10, count if count is not None else 10)

a = 1000
b = int("1000")
print(a == b, a is b)                               # equal values, different objects
print([] == [], [] is [])
SENTINEL = object()
def get(d, key, default=SENTINEL):
    v = d.get(key, SENTINEL)
    if v is SENTINEL:                                # identity check against a unique object
        if default is SENTINEL:
            raise KeyError(key)
        return default
    return v
print(get({"k": None}, "k"), get({}, "k", 7))
print(float("nan") == float("nan"), [float("nan")] == [float("nan")])
nan = float("nan")
print([nan] == [nan])                               # containers check identity first
