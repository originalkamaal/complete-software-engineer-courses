# file: calc/calc.py
import re
import sys

TOKEN = re.compile(r"\s*(?:(\d+\.\d*|\d+)|(\*\*|//|[-+*/%()=])|([A-Za-z_]\w*))")

def tokenize(text):
    pos, out = 0, []
    text = text.rstrip()
    while pos < len(text):
        m = TOKEN.match(text, pos)
        if not m:
            raise SyntaxError(f"unexpected character {text[pos]!r} at {pos}")
        num, op, name = m.groups()
        out.append(("num", float(num) if "." in num else int(num)) if num else ("op", op) if op else ("name", name))
        pos = m.end()
    return out

class Parser:
    def __init__(self, tokens, env):
        self.toks, self.i, self.env = tokens, 0, env
    def peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else ("end", None)
    def take(self, kind=None, value=None):
        tok = self.peek()
        if (kind and tok[0] != kind) or (value and tok[1] != value):
            raise SyntaxError(f"expected {value or kind}, got {tok[1]!r}")
        self.i += 1
        return tok
    def expr(self):                                 # expr := term (('+'|'-') term)*
        v = self.term()
        while self.peek() in (("op", "+"), ("op", "-")):
            op = self.take()[1]
            v = v + self.term() if op == "+" else v - self.term()
        return v
    def term(self):                                 # term := unary (('*'|'/'|'//'|'%') unary)*
        v = self.unary()
        while self.peek()[0] == "op" and self.peek()[1] in ("*", "/", "//", "%"):
            op, rhs = self.take()[1], None
            rhs = self.unary()
            match op:
                case "*": v *= rhs
                case "/": v /= rhs
                case "//": v //= rhs
                case "%": v %= rhs
        return v
    def unary(self):                                # unary := '-' unary | power
        if self.peek() == ("op", "-"):
            self.take()
            return -self.unary()
        return self.power()
    def power(self):                                # power := atom ('**' unary)?   (right-associative)
        base = self.atom()
        if self.peek() == ("op", "**"):
            self.take()
            return base ** self.unary()
        return base
    def atom(self):
        match self.peek():
            case ("num", value):
                self.take(); return value
            case ("name", name):
                self.take()
                if name not in self.env:
                    raise NameError(f"unknown variable {name!r}")
                return self.env[name]
            case ("op", "("):
                self.take(); v = self.expr(); self.take("op", ")"); return v
            case ("end", _):
                raise SyntaxError("unexpected end of input")
            case tok:
                raise SyntaxError(f"unexpected {tok[1]!r}")

def run_line(line, env):
    tokens = tokenize(line)
    match tokens:
        case []:
            return None
        case [("name", "quit")]:
            raise SystemExit
        case [("name", "vars")]:
            return ", ".join(f"{k}={v}" for k, v in sorted(env.items())) or "(none)"
        case [("name", target), ("op", "="), *rest]:
            p = Parser(rest, env); value = p.expr()
            if p.i != len(rest):
                raise SyntaxError("trailing input")
            env[target] = value
            return f"{target} = {value}"
        case _:
            p = Parser(tokens, env); value = p.expr()
            if p.i != len(tokens):
                raise SyntaxError("trailing input")
            return value

def main():
    env = {}
    for line in sys.stdin:
        try:
            out = run_line(line, env)
        except SystemExit:
            break
        except (SyntaxError, NameError, ZeroDivisionError) as e:
            out = f"error: {type(e).__name__}: {e}"
        if out is not None:
            print(f"> {line.strip():<22} {out}")

if __name__ == "__main__":
    main()
