# file: functions.py
def area(width, height=1.0, *, unit="m"):         # unit is keyword-only
    return f"{width * height:g} {unit}^2"

print(area(3), area(3, 4), area(height=2, width=5), area(2, 2, unit="cm"))
try:
    area(2, 2, "cm")
except TypeError as e:
    print("TypeError:", e)

def stats(*nums, **options):
    precision = options.get("precision", 2)
    mean = sum(nums) / len(nums)
    return round(mean, precision)

print(stats(1, 2, 4), stats(1, 2, 4, precision=4))
values = [3, 5, 8]
print(stats(*values))                              # unpack a list into positional arguments

def no_return():
    pass
print(no_return())
