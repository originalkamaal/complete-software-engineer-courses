# file: number_demo.py
from decimal import Decimal
from fractions import Fraction

print(2 ** 200)                                   # no overflow
print(7 / 2, 7 // 2, -7 // 2, 7 % 3, -7 % 3)      # floor division rounds toward minus infinity
print(divmod(-7, 3), (-7 // 3) * 3 + (-7 % 3))    # invariant: (a // b) * b + a % b == a
print(0.1 + 0.2, 0.1 + 0.2 == 0.3)
print(round(0.5), round(1.5), round(2.5), round(2.675, 2))   # banker's rounding; 2.675 is really 2.67499...
print(Fraction(1, 10) + Fraction(2, 10), Decimal("0.1") + Decimal("0.2"))
print(int("ff", 16), hex(255), bin(5), 1_000_000, 1e3, int(3.99), int(-3.99))
import math
print(math.isclose(0.1 + 0.2, 0.3), math.inf > 10**1000, math.nan == math.nan)
