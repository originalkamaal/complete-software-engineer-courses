# file: strings.py
name, price, qty = "Widget", 3.5, 12
print(f"{name:<10}|{price:>8.2f}|{qty:04d}|{price * qty:,.1f}")
print(f"{qty = }, {price * qty = }")              # debugging form: shows the expression too
s = "  Hello, World  "
print(repr(s.strip()), s.strip().lower().split(", "), "-".join(["a", "b", "c"]))
t = "Python"
print(t[0], t[-1], t[1:4], t[::-1], t[::2], "th" in t)
word = "naïve café 🐍"
print(len(word), len(word.encode("utf-8")), [hex(ord(c)) for c in "é🐍"])
try:
    t[0] = "J"
except TypeError as e:
    print("strings are immutable:", e)
