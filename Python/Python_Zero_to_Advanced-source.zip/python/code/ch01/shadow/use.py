# file: shadow/use.py
from fractions import Fraction
print(Fraction(1, 3))
