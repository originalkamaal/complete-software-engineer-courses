# file: shadow/numbers.py
print("this is MY numbers.py, not the standard library's")
