# file: matching2.py
from dataclasses import dataclass
from enum import Enum

class Color(Enum):
    RED = 1
    GREEN = 2

@dataclass
class Point:
    x: float
    y: float

def describe(obj):
    match obj:
        case Point(x=0, y=0):
            return "origin"
        case Point(x=0, y=y) | Point(x=y, y=0):
            return f"on an axis at {y}"
        case Point(x=x, y=y) if x == y:
            return f"on the diagonal at {x}"
        case {"type": "circle", "r": float(r) | int(r)} if r > 0:
            return f"circle of radius {r}"
        case [Point() as first, *rest]:
            return f"path starting at {first} with {len(rest)} more"
        case Color.RED:
            return "the colour red"
        case str() as s if s.isdigit():
            return f"digit string {s}"
        case _:
            return f"unknown: {obj!r}"

for o in [Point(0, 0), Point(0, 5), Point(3, 3), {"type": "circle", "r": 2}, [Point(1, 2), Point(3, 4)],
          Color.RED, "42", 3.5]:
    print(describe(o))

RED = "red"
def bad(c):
    match c:
        case RED:            # a capture pattern: matches anything and rebinds RED
            return "matched"
print(bad("blue"))
