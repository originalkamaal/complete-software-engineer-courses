# file: floats.py
import math
from decimal import Decimal
print(Decimal(0.1))
print(Decimal("0.1"))
total = 0.0
for _ in range(10):
    total += 0.1                                  # naive accumulation: error builds up
print(total, total == 1.0)
print(sum([0.1] * 10), math.fsum([0.1] * 10))      # sum() of floats is compensated since 3.12
