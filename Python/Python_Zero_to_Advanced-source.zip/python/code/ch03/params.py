# file: params.py
def connect(host, port=5432, /, *, timeout=10.0, retries=3):
    return f"{host}:{port} timeout={timeout} retries={retries}"

print(connect("db.local"))
print(connect("db.local", 6543, timeout=2))
for bad in ['connect(host="db")', 'connect("db", 1, 2)']:
    try:
        eval(bad)
    except TypeError as e:
        print(f"{bad}: {e}")

def log(msg, *args, level="INFO", **fields):
    extra = " ".join(f"{k}={v!r}" for k, v in fields.items())
    print(f"[{level}] {msg % args if args else msg} {extra}".rstrip())

log("started")
log("user %s logged in from %s", "ada", "10.0.0.7", level="DEBUG", session=42)
opts = {"level": "WARN", "disk": "/var"}
log("low disk", **opts)                                 # unpack a dict into keyword arguments
nums = [3, 9, 4]
print(max(*nums), max(nums), f"{len(nums)=}")
