# file: tools.py
import functools
from fractions import Fraction

@functools.cache
def fib(n):
    return n if n < 2 else fib(n - 1) + fib(n - 2)
print(fib(200), fib.cache_info())

int_from_hex = functools.partial(int, base=16)
print(int_from_hex("ff"), int_from_hex("10"))

@functools.singledispatch
def describe(x):
    return f"something: {x!r}"
@describe.register
def _(x: int):
    return f"an int with {x.bit_length()} bits"
@describe.register
def _(x: list):
    return f"a list of {len(x)} items"
@describe.register(Fraction)
def _(x):
    return f"a fraction {x.numerator}/{x.denominator}"
for v in (255, [1, 2], Fraction(3, 4), "text", True):
    print(describe(v))
