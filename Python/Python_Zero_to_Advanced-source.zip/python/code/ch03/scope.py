# file: scope.py
x = "global"

def outer():
    x = "enclosing"
    def inner():
        print("inner sees:", x)                     # E: found in outer
    inner()

outer()

count = 0
def broken():
    try:
        count += 1                                  # assignment makes count local -> read before assignment
    except UnboundLocalError as e:
        print("UnboundLocalError:", e)
broken()

def fixed():
    global count
    count += 1
fixed(); fixed()
print("count =", count)

def counter():
    n = 0
    def step():
        nonlocal n
        n += 1
        return n
    return step
c = counter()
print(c(), c(), c())
print(len("built-in len"), "<- len came from the built-in scope")
