# file: toolkit/toolkit.py
import functools
import inspect
import random
import time
from collections import OrderedDict

def retry(times=3, exceptions=(Exception,), backoff=0.01):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            delay = backoff
            for attempt in range(1, times + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == times:
                        raise                                    # give up: re-raise the last error
                    print(f"  attempt {attempt} failed ({e}); retrying in {delay * 1000:.0f} ms")
                    time.sleep(delay)
                    delay *= 2
        return wrapper
    return decorator

def memoize(maxsize=128):
    def decorator(func):
        cache, stats = OrderedDict(), {"hits": 0, "misses": 0}
        @functools.wraps(func)
        def wrapper(*args):
            if args in cache:
                stats["hits"] += 1
                cache.move_to_end(args)                         # most recently used
                return cache[args]
            stats["misses"] += 1
            result = cache[args] = func(*args)
            if len(cache) > maxsize:
                cache.popitem(last=False)                       # evict least recently used
            return result
        wrapper.stats = stats
        return wrapper
    return decorator

def validate(func):
    sig = inspect.signature(func)
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        bound = sig.bind(*args, **kwargs)
        for name, value in bound.arguments.items():
            expected = sig.parameters[name].annotation
            if expected is not inspect.Parameter.empty and not isinstance(value, expected):
                raise TypeError(f"{func.__name__}(): {name} must be {expected.__name__}, got {type(value).__name__}")
        return func(*args, **kwargs)
    return wrapper

rng = random.Random(3)
@retry(times=4, exceptions=(ConnectionError,))
def flaky_fetch(url):
    if rng.random() < 0.6:
        raise ConnectionError("network blip")
    return f"<html from {url}>"
print(flaky_fetch("example.org"))

@memoize(maxsize=2)
def slow_double(x):
    time.sleep(0.005)
    return 2 * x
for x in (1, 2, 1, 3, 2, 1):                                     # 3 evicts 2 (least recent), so 2 misses again
    slow_double(x)
print("memoize stats:", slow_double.stats)

@functools.lru_cache(maxsize=2)
def slow_double_std(x):
    return 2 * x
for x in (1, 2, 1, 3, 2, 1):
    slow_double_std(x)
print("lru_cache   :", slow_double_std.cache_info())

@validate
def transfer(amount: int, to: str, note: str = ""):
    return f"sent {amount} to {to}"
print(transfer(100, "ana"))
for bad in ((100.5, "ana"), (100, 42)):
    try:
        transfer(*bad)
    except TypeError as e:
        print("TypeError:", e)
