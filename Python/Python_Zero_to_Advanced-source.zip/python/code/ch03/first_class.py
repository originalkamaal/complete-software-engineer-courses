# file: first_class.py
def shout(s):
    return s.upper() + "!"

def whisper(s):
    return s.lower() + "..."

speak = shout                                           # just another name for the same function
print(speak("hi"), speak is shout, shout.__name__)
for style in (shout, whisper):
    print(style("Hello"))

ops = {"+": lambda a, b: a + b, "-": lambda a, b: a - b, "max": max}   # dispatch table
print([ops[k](7, 3) for k in ("+", "-", "max")])

def apply_twice(f, x):
    return f(f(x))
print(apply_twice(lambda n: n * 3, 2), apply_twice(shout, "go"))
words = ["banana", "Apple", "cherry", "date"]
print(sorted(words), sorted(words, key=str.lower), sorted(words, key=len))
print(list(map(len, words)), [w for w in words if len(w) > 4])   # comprehension preferred over filter
