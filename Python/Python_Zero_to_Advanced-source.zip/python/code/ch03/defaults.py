# file: defaults.py
import time

def add_item_bad(item, basket=[]):
    basket.append(item)
    return basket

print(add_item_bad("apple"), add_item_bad("pear"))      # the same list, growing across calls
print("stored default:", add_item_bad.__defaults__)

def add_item(item, basket=None):
    if basket is None:
        basket = []                                       # a fresh list per call
    basket.append(item)
    return basket

print(add_item("apple"), add_item("pear"))

def stamp(when=time.time()):                              # evaluated once at definition!
    return when
a = stamp(); time.sleep(0.01); b = stamp()
print("same timestamp both times:", a == b)
