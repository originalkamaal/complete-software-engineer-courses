# file: closures.py
from functools import partial

def make_multiplier(k):
    def multiply(x):
        return x * k                                # k lives on in the closure's cell
    return multiply
double, triple = make_multiplier(2), make_multiplier(3)
print(double(5), triple(5), double.__closure__[0].cell_contents)

late = [lambda: i for i in range(3)]
print("late binding:", [f() for f in late])         # all see the final i
early = [lambda i=i: i for i in range(3)]           # default evaluated at definition time
print("default-arg binding:", [f() for f in early])
with_partial = [partial(lambda i: i, i) for i in range(3)]
print("partial binding:", [f() for f in with_partial])
