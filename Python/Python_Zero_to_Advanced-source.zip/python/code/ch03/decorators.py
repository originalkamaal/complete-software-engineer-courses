# file: decorators.py
import functools
import time

def timed(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            print(f"  {func.__name__} took {(time.perf_counter() - start) * 1000:.1f} ms")
    return wrapper

def repeat(times):                                  # decorator factory: repeat(3) returns the decorator
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return [func(*args, **kwargs) for _ in range(times)]
        return wrapper
    return decorator

@timed
def slow_square(x):
    """Square x, slowly."""
    time.sleep(0.02)
    return x * x

@repeat(3)
def greet(name):
    return f"hi {name}"

print(slow_square(7))
print(greet("ana"))
print("metadata kept:", slow_square.__name__, "|", slow_square.__doc__, "| original:", slow_square.__wrapped__)

def no_wraps(func):
    def wrapper(*args):
        return func(*args)
    return wrapper
@no_wraps
def documented():
    """I have a docstring."""
print("without functools.wraps:", documented.__name__, documented.__doc__)
