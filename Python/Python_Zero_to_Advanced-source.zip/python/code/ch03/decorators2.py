# file: decorators2.py
import functools
import time

def retry(times=3, exceptions=(Exception,), delay=0.01):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            for attempt in range(1, times + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:
                    print(f"  {fn.__name__} attempt {attempt} failed: {e}")
                    if attempt == times:
                        raise
                    time.sleep(delay)
        return wrapper
    return decorator

calls = {"n": 0}

@retry(times=3, exceptions=(ConnectionError,))
def flaky_fetch(url):
    """Fetch a URL (fails twice, then works)."""
    calls["n"] += 1
    if calls["n"] < 3:
        raise ConnectionError("timeout")
    return f"content of {url}"

print(flaky_fetch("https://example.org"))
print(flaky_fetch.__name__, "|", flaky_fetch.__doc__, "|", flaky_fetch.__wrapped__.__name__)

def no_wraps(fn):
    def wrapper(*a, **k):
        return fn(*a, **k)
    return wrapper

@no_wraps
def important():
    """Docs that will be lost."""
print(important.__name__, important.__doc__)
