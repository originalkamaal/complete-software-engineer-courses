# file: unbound.py
counter = 0

def broken():
    print("counter is", counter)       # counter is local here, because of the line below
    counter = 1

def fixed():
    global counter
    counter += 1
    return counter

try:
    broken()
except UnboundLocalError as e:
    print("UnboundLocalError:", e)
print("fixed:", fixed(), fixed())

def make_counter():
    count = 0
    def inc():
        nonlocal count                  # rebinding an enclosing function's variable
        count += 1
        return count
    return inc
c = make_counter()
print(c(), c(), c())
print(broken.__code__.co_varnames, fixed.__code__.co_varnames)
