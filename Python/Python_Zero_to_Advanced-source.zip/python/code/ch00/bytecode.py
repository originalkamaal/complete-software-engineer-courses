# file: bytecode.py
import ast
import dis

src = "total = price * qty + tax"
print(ast.dump(ast.parse(src).body[0], indent=1))     # 1) the syntax tree

def total(price, qty, tax):
    return price * qty + tax

dis.dis(total)                                        # 2) the bytecode
print("code object:", total.__code__.co_varnames, "stack size", total.__code__.co_stacksize)
