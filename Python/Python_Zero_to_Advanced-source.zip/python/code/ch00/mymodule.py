# file: mymodule.py
def greet(name):
    return f"hello, {name}"
