# file: memory.py
import gc
import sys
import weakref

class Node:
    def __init__(self, name):
        self.name, self.other = name, None
    def __del__(self):
        print(f"  freeing {self.name}")

print("refcount of a fresh object:", sys.getrefcount(object()))   # only the temporary argument reference
x = Node("x")
print("refcount of x:", sys.getrefcount(x))
print("del x ->")
del x                                                 # count drops to 0: freed immediately

a, b = Node("a"), Node("b")
a.other, b.other = b, a                               # a cycle
print("del a, b (cycle) ->")
del a, b
print("  ...nothing freed yet; running gc.collect():")
print("  collected", gc.collect(), "objects")

target = Node("target")
w = weakref.ref(target)
print("weakref alive:", w() is target)
del target
print("after del, weakref returns:", w())
