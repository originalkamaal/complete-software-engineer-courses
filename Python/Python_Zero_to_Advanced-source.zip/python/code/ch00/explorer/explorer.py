# file: explorer/explorer.py
import dis
import timeit

def loop_sum(n):
    total = 0
    for i in range(n):
        total += i
    return total

def builtin_sum(n):
    return sum(range(n))

def formula_sum(n):
    return n * (n - 1) // 2

def count_instructions(f):
    ins = list(dis.get_instructions(f))
    return len(ins), sorted({i.opname for i in ins})

N = 1_000_000
assert loop_sum(N) == builtin_sum(N) == formula_sum(N)
for f in (loop_sum, builtin_sum, formula_sum):
    count, ops = count_instructions(f)
    t = min(timeit.repeat(lambda: f(N), number=3, repeat=3)) / 3
    print(f"{f.__name__:>12}: {count:>2} bytecode instructions, {t * 1000:8.2f} ms for n = {N:,}")
print("\nselected instructions of loop_sum (those from FOR_ITER to JUMP_BACKWARD run once per iteration):")
for ins in dis.get_instructions(loop_sum):
    if ins.opname in ("FOR_ITER", "STORE_FAST", "LOAD_FAST", "LOAD_FAST_LOAD_FAST", "BINARY_OP", "JUMP_BACKWARD"):
        print(f"  {ins.opname:<22} {ins.argrepr}")
