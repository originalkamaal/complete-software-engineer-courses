# file: use_module.py
import importlib.util
import os
import time

import mymodule
print(mymodule.greet("pyc"))
print("cached bytecode:", sorted(os.listdir("__pycache__")))
print("cache file for mymodule:", importlib.util.cache_from_source("mymodule.py"))
