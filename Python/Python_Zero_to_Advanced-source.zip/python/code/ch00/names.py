# file: names.py
a = [1, 2, 3]
b = a                       # a second name for the same list
b.append(4)
print(a, a is b, id(a) == id(b))

c = [1, 2, 3, 4]
print(a == c, a is c)       # equal values, different objects

def show(x):
    print(f"{x!r:>12}  type={type(x).__name__:<8} id={id(x)}")
for v in (42, "hi", 3.5, None, len, show):
    show(v)

x = 10
y = x
x = x + 1                   # rebinding x does not affect y: ints are immutable
print(x, y)
