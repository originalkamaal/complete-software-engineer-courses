# file: hello.py
import platform
import sys

print("Hello from Python", platform.python_version())
print("implementation:", platform.python_implementation())
print("executable:", sys.executable)
print("running as a script, __name__ =", __name__)
