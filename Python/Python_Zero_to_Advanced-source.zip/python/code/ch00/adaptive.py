# file: adaptive.py
import dis

def add(a, b):
    return a + b

for _ in range(1000):                                # warm up with integers
    add(1, 2)
dis.dis(add, adaptive=True)
