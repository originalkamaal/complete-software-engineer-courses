# file: identity.py
import sys

a = int("256"); b = int("256")
c = int("257"); d = int("257")
print("256 is 256:", a is b, "| 257 is 257:", c is d)
s1 = "".join(["hello", "_", "world"]); s2 = "hello_world"
print("equal strings, same object?", s1 is s2, "| after sys.intern:", sys.intern(s1) is sys.intern(s2))
