# file: blocking.py
import asyncio
import time

async def heartbeat(log):
    for _ in range(5):
        log.append(round(time.perf_counter() - START, 2))
        await asyncio.sleep(0.1)

def blocking_io():
    time.sleep(0.4)                                    # e.g. a synchronous HTTP library

async def bad():
    blocking_io()                                      # blocks the whole loop

async def good():
    await asyncio.to_thread(blocking_io)               # runs in a worker thread

async def run(job):
    log = []
    await asyncio.gather(heartbeat(log), job())
    return log

START = time.perf_counter()
print("blocking call in a coroutine, heartbeat times:", asyncio.run(run(bad)))
START = time.perf_counter()
print("asyncio.to_thread,           heartbeat times:", asyncio.run(run(good)))
