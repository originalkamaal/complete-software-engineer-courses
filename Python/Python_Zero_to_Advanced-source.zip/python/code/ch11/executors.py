# file: executors.py
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

def cpu_work(n):
    return sum(i * i for i in range(n))

def io_work(name):
    time.sleep(0.2)                         # stands in for a network call
    return name

if __name__ == "__main__":
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(io_work, f"url{i}") for i in range(8)]
        done = [f.result() for f in as_completed(futures)]
    print(f"8 I/O tasks with threads: {len(done)} done in about {round(time.perf_counter() - t0, 1)} s")

    times = {}
    for Executor in (ThreadPoolExecutor, ProcessPoolExecutor):
        t0 = time.perf_counter()
        with Executor(max_workers=2) as pool:
            results = list(pool.map(cpu_work, [3_000_000] * 4))
        times[Executor.__name__] = time.perf_counter() - t0
    ratio = times["ThreadPoolExecutor"] / times["ProcessPoolExecutor"]
    print("4 CPU tasks: processes faster than threads:", ratio > 1.3)
