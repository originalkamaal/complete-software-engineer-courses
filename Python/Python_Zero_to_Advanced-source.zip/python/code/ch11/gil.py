# file: gil.py
import os
import time
from concurrent.futures import ThreadPoolExecutor

def io_task(_):
    time.sleep(0.1)                                    # stands in for a network call: releases the GIL

def cpu_task(_):
    return sum(i * i for i in range(1_500_000))       # pure Python: holds the GIL

print("CPUs:", os.cpu_count())
for name, task, n in (("I/O-bound", io_task, 8), ("CPU-bound", cpu_task, 4)):
    t = time.perf_counter()
    for i in range(n):
        task(i)
    seq = time.perf_counter() - t
    t = time.perf_counter()
    with ThreadPoolExecutor(max_workers=n) as pool:
        list(pool.map(task, range(n)))
    thr = time.perf_counter() - t
    print(f"{name}: {n} tasks sequential {seq:.2f} s, {n} threads {thr:.2f} s  (speed-up {seq / thr:.1f}x)")
