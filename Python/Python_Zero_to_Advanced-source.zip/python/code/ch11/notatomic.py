# file: notatomic.py
import dis
import threading
import time

counter = 0
lock = threading.Lock()

def bump_unsafe(n):
    global counter
    for _ in range(n):
        v = counter          # read
        time.sleep(0)        # give up the CPU here: another thread may run
        counter = v + 1      # write: overwrites whatever that thread wrote

def bump_safe(n):
    global counter
    for _ in range(n):
        with lock:
            counter += 1

for fn in (bump_unsafe, bump_safe):
    counter = 0
    ts = [threading.Thread(target=fn, args=(20_000,)) for _ in range(4)]
    for t in ts: t.start()
    for t in ts: t.join()
    print(f"{fn.__name__}: {counter} of 80000", "(updates lost)" if counter < 80_000 else "")

ops = [i.opname for i in dis.get_instructions("counter += 1")]
print("counter += 1 is", len([o for o in ops if o not in ("RESUME", "RETURN_CONST")]), "bytecode instructions:", ops[1:4])
