# file: shared.py
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

sys.setswitchinterval(1e-6)                            # switch threads very often to expose races

def pause():
    pass

class Counter:
    def __init__(self):
        self.value, self.lock = 0, threading.Lock()
    def unsafe_add(self, n):
        for _ in range(n):
            v = self.value
            pause()                                     # a Python call: a point where CPython may switch threads
            self.value = v + 1
    def safe_add(self, n):
        for _ in range(n):
            with self.lock:
                self.value += 1

for method in ("unsafe_add", "safe_add"):
    c = Counter()
    threads = [threading.Thread(target=getattr(c, method), args=(100_000,)) for _ in range(4)]
    for t in threads: t.start()
    for t in threads: t.join()
    print(f"{method}: expected 400000, got {c.value}")

def work(chunk):                                       # no shared state: return results instead
    return sum(chunk)
chunks = [range(i, i + 250_000) for i in range(0, 1_000_000, 250_000)]
with ThreadPoolExecutor(4) as pool:
    print("results via futures:", sum(pool.map(work, chunks)) == sum(range(1_000_000)))
