# file: async_timeouts.py
import asyncio

async def slow_query(name, seconds):
    try:
        await asyncio.sleep(seconds)
        return f"{name} done"
    except asyncio.CancelledError:
        print(f"  {name}: cancelled, cleaning up")
        raise                                   # always re-raise

async def main():
    try:
        async with asyncio.timeout(0.1):
            await slow_query("report", 5)
    except TimeoutError:
        print("report timed out after 0.1 s")

    task = asyncio.create_task(slow_query("export", 5))
    await asyncio.sleep(0.05)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        print("export task:", "cancelled" if task.cancelled() else "?")

    results = await asyncio.gather(slow_query("a", 0.01), asyncio.wait_for(slow_query("b", 1), 0.05),
                                   return_exceptions=True)
    print([type(r).__name__ if isinstance(r, BaseException) else r for r in results])

asyncio.run(main())
