# file: async_basics.py
import asyncio
import time

async def fetch(name, delay):
    await asyncio.sleep(delay)                        # non-blocking wait: other tasks run meanwhile
    return f"{name} after {delay}s"

async def failing():
    await asyncio.sleep(0.05)
    raise ValueError("service B is down")

async def main():
    t = time.perf_counter()
    results = await asyncio.gather(fetch("A", 0.3), fetch("B", 0.2), fetch("C", 0.1))
    print(results, f"in {time.perf_counter() - t:.2f} s (not 0.6)")

    try:
        async with asyncio.TaskGroup() as tg:
            slow = tg.create_task(fetch("slow", 5))
            tg.create_task(failing())
    except* ValueError as eg:
        print("TaskGroup:", [str(e) for e in eg.exceptions], "| sibling cancelled:", slow.cancelled())

    try:
        async with asyncio.timeout(0.1):
            await fetch("too slow", 1)
    except TimeoutError:
        print("timed out after 0.1 s")

    limit = asyncio.Semaphore(2)
    async def limited(i):
        async with limit:                              # at most 2 at a time
            await asyncio.sleep(0.1)
            return i
    t = time.perf_counter()
    await asyncio.gather(*(limited(i) for i in range(6)))
    print(f"6 tasks, 2 at a time: {time.perf_counter() - t:.2f} s")

asyncio.run(main())
