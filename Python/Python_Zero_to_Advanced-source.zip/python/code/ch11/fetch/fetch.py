# file: fetch/fetch.py
import asyncio
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor

HOST, PORT, DELAY, N = "127.0.0.1", 8765, 0.05, 200

async def handle(reader, writer):
    req = (await reader.readline()).decode().strip()
    await asyncio.sleep(DELAY)                         # simulated network/processing latency
    writer.write(f"OK {req.upper()}\n".encode())
    await writer.drain()
    writer.close()

def run_server(ready):
    async def serve():
        server = await asyncio.start_server(handle, HOST, PORT, backlog=512)
        ready.set()
        async with server:
            await server.serve_forever()
    asyncio.run(serve())

def fetch_blocking(path):
    with socket.create_connection((HOST, PORT)) as s:
        s.sendall(f"{path}\n".encode())
        return s.makefile().readline().strip()

async def fetch_async(path, sem):
    async with sem:
        reader, writer = await asyncio.open_connection(HOST, PORT)
        writer.write(f"{path}\n".encode())
        await writer.drain()
        line = (await reader.readline()).decode().strip()
        writer.close()
        await writer.wait_closed()
        return line

async def fetch_all_async(paths):
    sem = asyncio.Semaphore(50)
    return await asyncio.gather(*(fetch_async(p, sem) for p in paths))

ready = threading.Event()
threading.Thread(target=run_server, args=(ready,), daemon=True).start()
ready.wait()
paths = [f"/item/{i}" for i in range(N)]
results = {}

t = time.perf_counter()
results["sequential"] = [fetch_blocking(p) for p in paths]
times = {"sequential": time.perf_counter() - t}
t = time.perf_counter()
with ThreadPoolExecutor(20) as pool:
    results["20 threads"] = list(pool.map(fetch_blocking, paths))
times["20 threads"] = time.perf_counter() - t
t = time.perf_counter()
results["asyncio, 50 at a time"] = asyncio.run(fetch_all_async(paths))
times["asyncio, 50 at a time"] = time.perf_counter() - t

for name, el in times.items():
    print(f"{name:>22}: {N} requests in {el:.2f} s  (lower bound {N * DELAY / {'sequential': 1, '20 threads': 20}.get(name, 50):.2f} s)")
print("identical responses:", results["sequential"] == results["20 threads"] == results["asyncio, 50 at a time"], "| e.g.", results["sequential"][7])
