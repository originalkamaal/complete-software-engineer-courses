# file: processes.py
import os
import time
from concurrent.futures import ProcessPoolExecutor

def count_primes(bounds):
    lo, hi = bounds
    count = 0
    for n in range(max(lo, 2), hi):
        if all(n % d for d in range(2, int(n ** 0.5) + 1)):
            count += 1
    return count

if __name__ == "__main__":
    N, workers = 300_000, os.cpu_count()
    chunks = [(i, i + N // 8) for i in range(0, N, N // 8)]
    t = time.perf_counter()
    seq = sum(map(count_primes, chunks))
    ts = time.perf_counter() - t
    t = time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        par = sum(pool.map(count_primes, chunks))
    tp = time.perf_counter() - t
    print(f"primes below {N:,}: {seq} sequential in {ts:.2f} s; {par} with {workers} processes in {tp:.2f} s "
          f"(speed-up {ts / tp:.1f}x on {workers} cores)")

    big = list(range(2_000_000))
    t = time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        lengths = list(pool.map(len, [big] * 8))       # tiny work, huge arguments: pickling dominates
    print(f"sending a 2M-element list to workers 8 times for len(): {time.perf_counter() - t:.2f} s (len itself: microseconds)")
