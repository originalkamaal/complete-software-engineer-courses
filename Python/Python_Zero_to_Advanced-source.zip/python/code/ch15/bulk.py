# file: bulk.py
import sqlite3
import time

db = sqlite3.connect("bulk.db")
db.execute("DROP TABLE IF EXISTS events")
db.execute("CREATE TABLE events (id INTEGER PRIMARY KEY, user TEXT, kind TEXT, ts INTEGER)")
rows = [(f"user{i % 500}", "click" if i % 3 else "view", i) for i in range(20_000)]

t0 = time.perf_counter()
for r in rows[:500]:
    db.execute("INSERT INTO events (user, kind, ts) VALUES (?, ?, ?)", r)
    db.commit()                                         # one transaction per row
per_row = (time.perf_counter() - t0) / 500

t0 = time.perf_counter()
with db:                                                # one transaction for everything
    db.executemany("INSERT INTO events (user, kind, ts) VALUES (?, ?, ?)", rows[500:])
batched = (time.perf_counter() - t0) / (len(rows) - 500)
print(f"per-row commits are more than 10x slower per row: {per_row > 10 * batched}")

query = "SELECT count(*) FROM events WHERE user = ?"
print("plan before index:", db.execute("EXPLAIN QUERY PLAN " + query, ("user7",)).fetchone()[-1])
db.execute("CREATE INDEX idx_events_user ON events(user)")
print("plan after index: ", db.execute("EXPLAIN QUERY PLAN " + query, ("user7",)).fetchone()[-1])
db.row_factory = sqlite3.Row                            # rows usable by column name
row = db.execute("SELECT user, count(*) AS n FROM events GROUP BY user ORDER BY n DESC, user LIMIT 1").fetchone()
print(dict(row))
