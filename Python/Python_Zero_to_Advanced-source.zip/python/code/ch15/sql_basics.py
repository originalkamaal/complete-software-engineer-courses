# file: sql_basics.py
import sqlite3

conn = sqlite3.connect(":memory:")
conn.row_factory = sqlite3.Row
conn.executescript("""
    CREATE TABLE books (id INTEGER PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL,
                        year INTEGER, price REAL CHECK (price >= 0));
""")
books = [("Dune", "Herbert", 1965, 9.99), ("Neuromancer", "Gibson", 1984, 7.5),
         ("Hyperion", "Simmons", 1989, 8.25), ("Foundation", "Asimov", 1951, 6.0)]
conn.executemany("INSERT INTO books (title, author, year, price) VALUES (?, ?, ?, ?)", books)
conn.commit()
for row in conn.execute("SELECT title, year FROM books WHERE year > ? ORDER BY year", (1960,)):
    print(dict(row))
r = conn.execute("SELECT COUNT(*) AS n, ROUND(AVG(price), 2) AS avg_price FROM books").fetchone()
print("count:", r["n"], "| average price:", r["avg_price"])
try:
    conn.execute("INSERT INTO books (title, author, price) VALUES (?, ?, ?)", ("Free?", "X", -1))
except sqlite3.IntegrityError as e:
    print("IntegrityError:", e)
