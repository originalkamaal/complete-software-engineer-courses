# file: injection.py
import sqlite3

conn = sqlite3.connect(":memory:")
conn.execute("CREATE TABLE users (name TEXT, is_admin INTEGER)")
conn.executemany("INSERT INTO users VALUES (?, ?)", [("ana", 1), ("ben", 0)])
attack = "nobody' OR '1'='1"
unsafe = conn.execute(f"SELECT name FROM users WHERE name = '{attack}'").fetchall()
safe = conn.execute("SELECT name FROM users WHERE name = ?", (attack,)).fetchall()
print("f-string query returned:", unsafe)
print("parameterised query returned:", safe)
