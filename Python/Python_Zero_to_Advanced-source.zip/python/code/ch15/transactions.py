# file: transactions.py
import sqlite3
import time

conn = sqlite3.connect(":memory:")
conn.execute("CREATE TABLE accounts (name TEXT PRIMARY KEY, balance INTEGER CHECK (balance >= 0))")
conn.executemany("INSERT INTO accounts VALUES (?, ?)", [("ana", 100), ("ben", 50)])
conn.commit()

def transfer(src, dst, amount):
    try:
        with conn:                                       # one transaction
            conn.execute("UPDATE accounts SET balance = balance + ? WHERE name = ?", (amount, dst))
            conn.execute("UPDATE accounts SET balance = balance - ? WHERE name = ?", (amount, src))
        return "ok"
    except sqlite3.IntegrityError as e:
        return f"rolled back ({e})"

print(transfer("ana", "ben", 30), dict(conn.execute("SELECT * FROM accounts")))
print(transfer("ben", "ana", 500), dict(conn.execute("SELECT * FROM accounts")))   # the credit to ana is undone too

conn.execute("CREATE TABLE events (id INTEGER PRIMARY KEY, user_id INTEGER, kind TEXT)")
conn.executemany("INSERT INTO events (user_id, kind) VALUES (?, ?)", ((i % 5000, "click") for i in range(300_000)))
query = "SELECT COUNT(*) FROM events WHERE user_id = ?"
for label in ("without index", "with index"):
    if label == "with index":
        conn.execute("CREATE INDEX idx_events_user ON events(user_id)")
    plan = conn.execute("EXPLAIN QUERY PLAN " + query, (42,)).fetchall()[0][-1]
    t = time.perf_counter()
    for uid in range(200):
        conn.execute(query, (uid,)).fetchone()
    print(f"{label:>14}: plan '{plan}', 200 queries in {(time.perf_counter() - t) * 1000:.0f} ms")
