# file: api/client.py
import concurrent.futures
import os
import subprocess
import sys
import time
import httpx

PORT = 8799
BASE = f"http://127.0.0.1:{PORT}"
if os.path.exists("notes.db"):
    os.remove("notes.db")
subprocess.run([sys.executable, "-c", "import app; app.init_db()"], check=True)
server = subprocess.Popen([sys.executable, "-m", "uvicorn", "app:app", "--port", str(PORT), "--log-level", "warning"])
try:
    for _ in range(100):                                  # wait until the server answers
        try:
            httpx.get(f"{BASE}/notes", timeout=0.2)
            break
        except httpx.TransportError:
            time.sleep(0.1)
    with httpx.Client(base_url=BASE) as c:
        with concurrent.futures.ThreadPoolExecutor(8) as pool:
            created = list(pool.map(lambda i: c.post("/notes", json={"title": f"note {i}", "tags": ["work" if i % 3 == 0 else "home"]}),
                                    range(12)))
        print("12 concurrent POSTs:", sorted({r.status_code for r in created}), "| ids:", sorted(r.json()["id"] for r in created))
        print("GET /notes/5      ->", c.get("/notes/5").json())
        print("GET /notes?tag=work ->", [n["title"] for n in c.get("/notes", params={"tag": "work", "limit": 50}).json()])
        r = c.post("/notes", json={"title": "x" * 200})
        print("POST too-long title ->", r.status_code, r.json()["detail"][0]["msg"])
        print("DELETE /notes/5   ->", c.delete("/notes/5").status_code, "| again ->", c.delete("/notes/5").status_code)
        print("GET /notes/abc    ->", c.get("/notes/abc").status_code)
        print("OpenAPI schema paths:", sorted(c.get("/openapi.json").json()["paths"]))
finally:
    server.terminate()
    server.wait(timeout=10)
    print("server stopped with exit code", server.returncode)
    os.remove("notes.db")
