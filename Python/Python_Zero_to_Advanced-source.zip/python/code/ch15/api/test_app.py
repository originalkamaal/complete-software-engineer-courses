# file: api/test_app.py
import pytest
from fastapi.testclient import TestClient
import app as app_module

@pytest.fixture
def client(tmp_path, monkeypatch):
    db = tmp_path / "test.db"
    monkeypatch.setattr(app_module, "DB_PATH", str(db))   # get_db reads the module global at call time
    app_module.init_db(str(db))
    return TestClient(app_module.app)

def test_create_and_read(client):
    r = client.post("/notes", json={"title": "Buy milk", "tags": ["home"]})
    assert r.status_code == 201
    note = r.json()
    assert note["id"] == 1 and note["tags"] == ["home"]
    assert client.get(f"/notes/{note['id']}").json()["title"] == "Buy milk"

def test_validation_error(client):
    r = client.post("/notes", json={"title": ""})
    assert r.status_code == 422
    assert r.json()["detail"][0]["loc"] == ["body", "title"]

def test_not_found_and_delete(client):
    assert client.get("/notes/99").status_code == 404
    nid = client.post("/notes", json={"title": "temp"}).json()["id"]
    assert client.delete(f"/notes/{nid}").status_code == 204
    assert client.delete(f"/notes/{nid}").status_code == 404

def test_filter_and_limit(client):
    for i in range(5):
        client.post("/notes", json={"title": f"n{i}", "tags": ["even"] if i % 2 == 0 else []})
    assert [n["title"] for n in client.get("/notes", params={"tag": "even"}).json()] == ["n0", "n2", "n4"]
    assert len(client.get("/notes", params={"limit": 2}).json()) == 2
    assert client.get("/notes", params={"limit": 0}).status_code == 422
