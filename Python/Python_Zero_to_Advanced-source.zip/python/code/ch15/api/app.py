# file: api/app.py
import sqlite3
from fastapi import Depends, FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

DB_PATH = "notes.db"

class NoteIn(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    body: str = ""
    tags: list[str] = []

class Note(NoteIn):
    id: int

app = FastAPI(title="Notes API")

def get_db():                                          # a dependency: one connection per request
    # FastAPI may run this generator's setup, the endpoint, and the cleanup in DIFFERENT pool threads,
    # so sqlite3's same-thread check must be disabled; the connection is still used by one request at a time.
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def init_db(path=DB_PATH):
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, title TEXT, body TEXT, tags TEXT)")

def to_note(row):
    return Note(id=row["id"], title=row["title"], body=row["body"], tags=[t for t in row["tags"].split(",") if t])

@app.post("/notes", response_model=Note, status_code=201)
def create_note(note: NoteIn, db: sqlite3.Connection = Depends(get_db)):
    with db:
        cur = db.execute("INSERT INTO notes (title, body, tags) VALUES (?, ?, ?)", (note.title, note.body, ",".join(note.tags)))
    return Note(id=cur.lastrowid, **note.model_dump())

@app.get("/notes/{note_id}", response_model=Note)
def read_note(note_id: int, db: sqlite3.Connection = Depends(get_db)):
    row = db.execute("SELECT * FROM notes WHERE id = ?", (note_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"note {note_id} not found")
    return to_note(row)

@app.get("/notes", response_model=list[Note])
def list_notes(tag: str | None = None, limit: int = Query(10, ge=1, le=100), db: sqlite3.Connection = Depends(get_db)):
    rows = db.execute("SELECT * FROM notes ORDER BY id").fetchall()
    notes = [to_note(r) for r in rows]
    if tag:
        notes = [n for n in notes if tag in n.tags]
    return notes[:limit]

@app.delete("/notes/{note_id}", status_code=204)
def delete_note(note_id: int, db: sqlite3.Connection = Depends(get_db)):
    with db:
        if db.execute("DELETE FROM notes WHERE id = ?", (note_id,)).rowcount == 0:
            raise HTTPException(status_code=404, detail=f"note {note_id} not found")
