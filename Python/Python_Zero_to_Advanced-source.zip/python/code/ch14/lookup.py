# file: lookup.py
class Config:
    defaults = {"timeout": 30, "retries": 3}
    def __init__(self, **overrides):
        self.__dict__.update(overrides)
    def __getattr__(self, name):                       # called only when normal lookup fails
        try:
            return self.defaults[name]
        except KeyError:
            raise AttributeError(f"no setting {name!r}") from None

c = Config(timeout=5)
print(c.timeout, c.retries, vars(c))
print(getattr(c, "retries"), getattr(c, "colour", "default-colour"), hasattr(c, "colour"))
setattr(c, "verbose", True)
print(vars(c))

class Traced:
    def __getattribute__(self, name):                  # called for EVERY attribute access
        if not name.startswith("__"):
            print(f"  looking up {name!r}")
        return super().__getattribute__(name)
    x = 1
t = Traced()
print(t.x + t.x)
