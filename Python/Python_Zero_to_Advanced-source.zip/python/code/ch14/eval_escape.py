# file: eval_escape.py
import ast
import warnings
warnings.simplefilter("ignore", DeprecationWarning)
payload = ("[c for c in ().__class__.__base__.__subclasses__() if c.__name__ == 'BuiltinImporter'][0]"
           ".load_module('posix').uname().sysname")      # import the OS module with no builtins at all
print("eval with empty __builtins__ reached the OS:", eval(payload, {"__builtins__": {}}))
print("literal_eval of data:", ast.literal_eval("{'a': [1, 2.5, (3, None)]}"))
try:
    ast.literal_eval(payload)
except ValueError as e:
    print("literal_eval refuses code:", type(e).__name__)
