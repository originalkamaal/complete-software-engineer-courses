# file: type_demo.py
def area(self):
    return self.w * self.h

Rect = type("Rect", (), {"__init__": lambda self, w, h: setattr(self, "w", w) or setattr(self, "h", h), "area": area})
print(Rect(3, 4).area(), type(Rect), Rect.__name__)

class CountingMeta(type):
    def __call__(cls, *args, **kwargs):              # runs when the CLASS is called: making an instance
        cls.instances = getattr(cls, "instances", 0) + 1
        return super().__call__(*args, **kwargs)
    def __len__(cls):                                # len() on the class itself
        return cls.instances

class Session(metaclass=CountingMeta):
    pass

Session(); Session(); Session()
print("sessions created:", len(Session))
