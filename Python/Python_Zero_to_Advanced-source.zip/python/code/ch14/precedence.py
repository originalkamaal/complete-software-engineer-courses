# file: precedence.py
from functools import cached_property

class Demo:
    @property
    def p(self): return "property (data descriptor)"
    def m(self): return "method (non-data descriptor)"
    @cached_property
    def heavy(self):
        print("  computing heavy once")
        return 42

d = Demo()
d.__dict__["p"] = "instance dict"
d.__dict__["m"] = lambda: "instance dict"
print(d.p, "|", d.m())
print(d.heavy, d.heavy, "| stored in instance dict:", "heavy" in vars(d))
