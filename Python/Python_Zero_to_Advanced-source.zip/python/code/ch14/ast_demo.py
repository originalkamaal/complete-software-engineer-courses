# file: ast_demo.py
import ast

src = '''
def area(w, h):
    print("computing")
    return w * h

total = area(3, 4) + area(1, 2)
'''
tree = ast.parse(src)
calls = [n.func.id for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)]
print("function calls:", calls)
print("names assigned:", [t.id for n in ast.walk(tree) if isinstance(n, ast.Assign) for t in n.targets])

class StripPrints(ast.NodeTransformer):                # remove print(...) statements
    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and getattr(node.value.func, "id", None) == "print":
            return None
        return node

class MulToAdd(ast.NodeTransformer):                   # a silly rewrite to show transformation
    def visit_BinOp(self, node):
        self.generic_visit(node)
        if isinstance(node.op, ast.Mult):
            node.op = ast.Add()
        return node

new = ast.fix_missing_locations(MulToAdd().visit(StripPrints().visit(tree)))
print(ast.unparse(new))
ns = {}
exec(compile(new, "<rewritten>", "exec"), ns)
print("total after rewrite:", ns["total"])
