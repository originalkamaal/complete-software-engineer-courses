# file: plugins.py
class Exporter:
    registry: dict[str, type["Exporter"]] = {}

    def __init_subclass__(cls, *, fmt: str, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "export"):
            raise TypeError(f"{cls.__name__} must define export()")
        Exporter.registry[fmt] = cls

class CsvExporter(Exporter, fmt="csv"):
    def export(self, rows):
        return "\n".join(",".join(map(str, r)) for r in rows)

class JsonExporter(Exporter, fmt="json"):
    def export(self, rows):
        import json
        return json.dumps(rows)

print(sorted(Exporter.registry))
print(Exporter.registry["csv"]().export([(1, 2), (3, 4)]))
try:
    class Broken(Exporter, fmt="xml"):
        pass
except TypeError as e:
    print("TypeError:", e)
