# file: descriptors.py
class Typed:
    """A reusable validated field."""
    def __init__(self, kind, minimum=None):
        self.kind, self.minimum = kind, minimum
    def __set_name__(self, owner, name):
        self.name = name
        self.storage = f"_{name}"
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self                                # accessed on the class itself
        return getattr(obj, self.storage)
    def __set__(self, obj, value):
        if not isinstance(value, self.kind):
            raise TypeError(f"{self.name} must be {self.kind.__name__}, got {type(value).__name__}")
        if self.minimum is not None and value < self.minimum:
            raise ValueError(f"{self.name} must be >= {self.minimum}")
        setattr(obj, self.storage, value)

class Product:
    name = Typed(str)
    price = Typed(float, minimum=0.0)
    stock = Typed(int, minimum=0)
    def __init__(self, name, price, stock):
        self.name, self.price, self.stock = name, price, stock

p = Product("pen", 1.5, 10)
print(p.name, p.price, p.stock, Product.price.name)
for field, bad in (("price", -1.0), ("stock", "ten")):
    try:
        setattr(p, field, bad)
    except (TypeError, ValueError) as e:
        print(type(e).__name__, "-", e)

def greet(self):
    return f"hi from {self.name}"
Product.greet = greet                                  # a plain function stored on the class...
print(type(Product.__dict__["greet"]), "->", type(p.greet), p.greet())   # ...becomes a bound method via __get__
print(greet.__get__(p, Product)())                     # what p.greet does under the hood
