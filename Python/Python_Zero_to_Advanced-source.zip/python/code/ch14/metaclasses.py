# file: metaclasses.py
Point = type("Point", (), {"x": 0, "norm": lambda self: abs(self.x)})
p = Point(); p.x = -3
print(Point, type(Point), p.norm(), type(type))

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):                # controls Class(...) for classes using this metaclass
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class Settings(metaclass=Singleton):
    def __init__(self):
        print("  Settings.__init__ runs once")
print(Settings() is Settings(), type(Settings).__name__)

class UpperAttrs(type):
    def __new__(mcls, name, bases, ns):
        ns = {k if k.startswith("__") else k.upper(): v for k, v in ns.items()}
        return super().__new__(mcls, name, bases, ns)
class Constants(metaclass=UpperAttrs):
    pi = 3.14159
    answer = 42
print(Constants.PI, Constants.ANSWER, hasattr(Constants, "pi"))
