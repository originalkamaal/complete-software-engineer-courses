# file: getattr_demo.py
class Config:
    def __init__(self, **values):
        self._values = values
    def __getattr__(self, name):                     # only for names not found normally
        try:
            return self._values[name]
        except KeyError:
            close = [k for k in self._values if k[0] == name[0]]
            raise AttributeError(f"no setting {name!r}" + (f"; did you mean {close[0]!r}?" if close else "")) from None

class Proxy:
    def __init__(self, target):
        self._target = target
        self.calls = []
    def __getattr__(self, name):
        attr = getattr(self._target, name)
        if callable(attr):
            def wrapper(*a, **k):
                self.calls.append(name)
                return attr(*a, **k)
            return wrapper
        return attr

cfg = Config(timeout=5, retries=3)
print(cfg.timeout, cfg._values is not None)
try:
    cfg.retry
except AttributeError as e:
    print("AttributeError:", e)
p = Proxy([3, 1, 2])
p.sort(); p.append(4)
print(p._target, p.calls, len(p._target))
