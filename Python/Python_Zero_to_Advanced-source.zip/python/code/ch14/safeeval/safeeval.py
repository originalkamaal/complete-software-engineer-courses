# file: safeeval/safeeval.py
import ast
import operator
import random

BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
       ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos, ast.Not: operator.not_}
CMP = {ast.Lt: operator.lt, ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
       ast.Eq: operator.eq, ast.NotEq: operator.ne}
FUNCS = {"min": min, "max": max, "abs": abs, "round": round}

class UnsafeExpression(ValueError):
    pass

def evaluate(expr, variables, max_len=500):
    if len(expr) > max_len:
        raise UnsafeExpression("expression too long")
    tree = ast.parse(expr, mode="eval")

    def ev(node):
        match node:
            case ast.Expression(body=b):
                return ev(b)
            case ast.Constant(value=v) if isinstance(v, (int, float, bool)):
                return v
            case ast.Name(id=name) if name in variables:
                return variables[name]
            case ast.BinOp(left=l, op=op, right=r) if type(op) in BIN:
                left, right = ev(l), ev(r)
                if isinstance(op, ast.Pow) and abs(right) > 100:
                    raise UnsafeExpression("exponent too large")      # avoid CPU/memory bombs like 9**9**9
                return BIN[type(op)](left, right)
            case ast.UnaryOp(op=op, operand=x) if type(op) in UNARY:
                return UNARY[type(op)](ev(x))
            case ast.BoolOp(op=ast.And(), values=vs):
                result = True
                for v in vs:                                          # short-circuit like Python
                    result = ev(v)
                    if not result:
                        return result
                return result
            case ast.BoolOp(op=ast.Or(), values=vs):
                result = False
                for v in vs:
                    result = ev(v)
                    if result:
                        return result
                return result
            case ast.Compare(left=l, ops=ops, comparators=cs) if all(type(o) in CMP for o in ops):
                left = ev(l)
                for o, c in zip(ops, cs):                             # chained comparisons
                    right = ev(c)
                    if not CMP[type(o)](left, right):
                        return False
                    left = right
                return True
            case ast.IfExp(test=t, body=b, orelse=e):
                return ev(b) if ev(t) else ev(e)
            case ast.Call(func=ast.Name(id=fname), args=args, keywords=[]) if fname in FUNCS:
                return FUNCS[fname](*(ev(a) for a in args))
            case _:
                raise UnsafeExpression(f"not allowed: {ast.dump(node)[:60]}")
    return ev(tree)

env = {"price": 12.5, "qty": 14, "discount": 0.1}
formula = "price * qty * (1 - discount) if qty > 10 else price * qty"
print(f"{formula}  =>  {evaluate(formula, env)}")
print("max(price, 20) // 3 =", evaluate("max(price, 20) // 3", env), "| 1 < qty <= 20 =", evaluate("1 < qty <= 20", env))

attacks = ["__import__('os').system('echo pwned')", "().__class__.__base__.__subclasses__()", "open('/etc/passwd').read()",
           "[x for x in range(10)]", "(lambda: 1)()", "price.__class__", "9 ** 9 ** 9", "exec('1')", "env['price']"]
for a in attacks:
    try:
        evaluate(a, env)
        print("NOT BLOCKED:", a)
    except (UnsafeExpression, SyntaxError) as e:
        print(f"blocked: {a[:42]:<42} ({type(e).__name__})")

rng = random.Random(14)
def rand_expr(depth=0):
    if depth > 3 or rng.random() < 0.3:
        return rng.choice(["price", "qty", "discount", str(rng.randint(-5, 9)), "2.5", "True"])
    kind = rng.random()
    if kind < 0.45:
        return f"({rand_expr(depth + 1)} {rng.choice(['+', '-', '*', '<', '>=', '==', 'and', 'or'])} {rand_expr(depth + 1)})"
    if kind < 0.6:
        return f"(not {rand_expr(depth + 1)})"
    if kind < 0.8:
        return f"({rand_expr(depth + 1)} if {rand_expr(depth + 1)} else {rand_expr(depth + 1)})"
    return f"{rng.choice(['min', 'max'])}({rand_expr(depth + 1)}, {rand_expr(depth + 1)})"
agree = 0
for _ in range(3000):
    e = rand_expr()
    try:
        expected = eval(e, {"__builtins__": {}, "min": min, "max": max}, env)   # trusted, generated input only
    except Exception as ex:
        expected = type(ex)
    try:
        got = evaluate(e, env)
    except Exception as ex:
        got = type(ex)
    agree += got == expected
print(f"3,000 random expressions: agreement with Python's eval on {agree}")
