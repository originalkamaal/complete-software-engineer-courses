# file: registry.py
class Exporter:
    registry = {}
    def __init_subclass__(cls, *, fmt, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "export"):
            raise TypeError(f"{cls.__name__} must define export()")
        Exporter.registry[fmt] = cls

class CsvExporter(Exporter, fmt="csv"):
    def export(self, rows): return "\n".join(",".join(map(str, r)) for r in rows)

class JsonExporter(Exporter, fmt="json"):
    def export(self, rows):
        import json
        return json.dumps(rows)

rows = [[1, "a"], [2, "b"]]
for fmt, cls in Exporter.registry.items():
    print(fmt, "->", cls().export(rows).replace("\n", " | "))
try:
    class BrokenExporter(Exporter, fmt="xml"):
        pass
except TypeError as e:
    print("TypeError:", e)

def add_repr(cls):                                     # a class decorator
    fields = list(vars(cls).get("__annotations__", {}))
    cls.__repr__ = lambda self: f"{cls.__name__}(" + ", ".join(f"{f}={getattr(self, f)!r}" for f in fields) + ")"
    return cls

@add_repr
class Point:
    x: int
    y: int
    def __init__(self, x, y): self.x, self.y = x, y
print(Point(1, 2))
