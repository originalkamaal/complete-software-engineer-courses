# file: minisearch/tests/test_minisearch.py
import asyncio
import sqlite3
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from minisearch.cli import main
from minisearch.crawl import crawl
from minisearch.index import add_pages, connect, search
from minisearch.parse import normalise_link, parse_page
from testsite import TOPICS, build, serve


@pytest.fixture(scope="module")
def site(tmp_path_factory: pytest.TempPathFactory) -> Iterator[str]:
    root = tmp_path_factory.mktemp("site")
    build(root)
    url, server = serve(root)
    yield url
    server.shutdown()


@pytest.fixture(scope="module")
def db(site: str, tmp_path_factory: pytest.TempPathFactory) -> str:
    path = str(tmp_path_factory.mktemp("db") / "index.db")
    result = asyncio.run(crawl(site, max_pages=50, concurrency=4))
    add_pages(connect(path), result.pages)
    return path


@pytest.mark.parametrize("base, href, expected", [
    ("http://h/docs/", "intro.html", "http://h/docs/intro.html"),
    ("http://h/docs", "intro.html", "http://h/intro.html"),               # DT-31: no trailing slash
    ("http://h/a.html", "b.html#sec", "http://h/b.html"),                 # fragment dropped
    ("http://h/a.html", "?page=2", "http://h/a.html?page=2"),
    ("http://h/a.html", "https://other.org/", None),                      # external host
    ("http://h/a.html", "mailto:x@y.z", None),
    ("http://h/a.html", "javascript:void(0)", None),
])
def test_normalise_link(base: str, href: str, expected: str | None) -> None:
    assert normalise_link(base, href) == expected


def test_parse_ignores_scripts() -> None:
    page = parse_page("http://h/", "<title> T </title><script>secret()</script><p>Hello <b>world</b></p><a href='x'>x</a>")
    assert page.title == "T" and page.text == "Hello world" and page.links == ("http://h/x",)


def test_crawl_visits_each_page_once(site: str) -> None:
    result = asyncio.run(crawl(site, max_pages=50, concurrency=4))
    urls = sorted(p.url.rsplit("/", 1)[-1] for p in result.pages)
    assert urls == sorted([""] + [f"{n}.html" for n in TOPICS])          # index + topic pages, no duplicates
    assert set(u.rsplit("/", 1)[-1] for u in result.errors) == {"missing.html", "paper.pdf"}


def test_max_pages_is_respected(site: str) -> None:
    assert len(asyncio.run(crawl(site, max_pages=3)).pages) == 3


def test_ranking(db: str) -> None:
    hits = search(connect(db), "binary search tree")
    assert hits[0].title == "Binary Search Tree"
    assert {h.title for h in hits[:3]} == {"Binary Search Tree", "Binary Search", "Binary Tree"}
    assert search(connect(db), "zebra") == []                             # script text is not indexed
    assert "priority queues" in search(connect(db), "priority")[0].snippet


def test_reindex_is_idempotent(db: str, site: str) -> None:
    conn = connect(db)
    before = conn.execute("SELECT COUNT(*) FROM postings").fetchone()[0]
    add_pages(conn, asyncio.run(crawl(site, max_pages=50)).pages)
    assert conn.execute("SELECT COUNT(*) FROM postings").fetchone()[0] == before


def test_api(db: str, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MINISEARCH_DB", db)
    from minisearch.api import app
    client = TestClient(app)
    r = client.get("/search", params={"q": "hash", "limit": 1})
    assert r.status_code == 200 and r.json()[0]["title"] == "Hash Table"
    assert client.get("/search", params={"q": ""}).status_code == 422
    assert client.get("/search", params={"q": "heap", "limit": 99}).status_code == 422


def test_cli(db: str, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["search", "breadth first", "--db", db]) == 0
    assert "Graph" in capsys.readouterr().out
    assert main(["search", "nonexistentword", "--db", db]) == 1
