# file: minisearch/tests/testsite.py
"""A deterministic website for tests, served from a temporary directory."""
import functools
import http.server
import threading
from pathlib import Path

TOPICS = {
    "binary-search": "Binary search halves a sorted range at each step until the target is found.",
    "binary-tree": "A binary tree is a tree in which each node has at most two children.",
    "binary-search-tree": "A binary search tree keeps keys ordered so that search, insert and delete follow one path.",
    "hash-table": "A hash table maps keys to buckets with a hash function for constant time lookups.",
    "heap": "A heap is a tree where every parent is ordered before its children; heaps implement priority queues.",
    "graph": "A graph has vertices and edges; breadth first search explores it level by level.",
}


def build(root: Path) -> None:
    names = list(TOPICS)
    for i, name in enumerate(names):
        links = "".join(f'<a href="{other}.html#top">{other}</a> ' for other in names if other != name)
        (root / f"{name}.html").write_text(
            f"<html><head><title>{name.replace('-', ' ').title()}</title>"
            f"<script>var decoy = 'zebra';</script></head><body><h1 id=top>{name}</h1>"
            f"<p>{TOPICS[name]}</p>{links}"
            f'<a href="missing.html">broken</a> <a href="https://example.com/x">external</a> '
            f'<a href="paper.pdf">pdf</a> <a href="mailto:a@b.c">mail</a></body></html>')
    (root / "index.html").write_text("<html><head><title>Home</title></head><body>"
                                     + "".join(f'<a href="{n}.html">{n}</a>' for n in names) + "</body></html>")
    (root / "paper.pdf").write_bytes(b"%PDF-1.4 not html")


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args: object) -> None:
        pass


def serve(root: Path) -> tuple[str, http.server.ThreadingHTTPServer]:
    handler = functools.partial(_Quiet, directory=str(root))
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{server.server_address[1]}/", server
