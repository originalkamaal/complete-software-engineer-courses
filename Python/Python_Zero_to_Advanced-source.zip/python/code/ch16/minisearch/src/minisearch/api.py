# file: minisearch/src/minisearch/api.py
import os
from typing import Annotated

from fastapi import FastAPI, Query
from pydantic import BaseModel

from .index import connect, search

app = FastAPI(title="minisearch")


class HitOut(BaseModel):
    url: str
    title: str
    score: float
    snippet: str


@app.get("/search", response_model=list[HitOut])
def search_endpoint(q: Annotated[str, Query(min_length=1, max_length=200)],
                    limit: Annotated[int, Query(ge=1, le=50)] = 10) -> list[HitOut]:
    conn = connect(os.environ.get("MINISEARCH_DB", "minisearch.db"))
    try:
        return [HitOut(url=h.url, title=h.title, score=h.score, snippet=h.snippet) for h in search(conn, q, limit)]
    finally:
        conn.close()
