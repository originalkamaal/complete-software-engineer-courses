# file: minisearch/src/minisearch/crawl.py
import asyncio
from dataclasses import dataclass, field

import httpx

from .models import Page
from .parse import normalise_link, parse_page


@dataclass
class CrawlResult:
    pages: list[Page] = field(default_factory=list)
    errors: dict[str, str] = field(default_factory=dict)


async def crawl(start: str, max_pages: int = 100, concurrency: int = 8, timeout: float = 5.0) -> CrawlResult:
    root = normalise_link(start, start)
    if root is None:
        raise ValueError(f"not an http(s) URL: {start!r}")
    result = CrawlResult()
    seen: set[str] = {root}
    queue: asyncio.Queue[str] = asyncio.Queue()
    queue.put_nowait(root)

    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:

        async def worker() -> None:
            while len(result.pages) < max_pages:
                try:
                    url = await asyncio.wait_for(queue.get(), timeout=0.5)
                except TimeoutError:
                    return                                  # queue stayed empty: crawl is finished
                try:
                    resp = await client.get(url)
                    if resp.status_code != 200 or "text/html" not in resp.headers.get("content-type", ""):
                        result.errors[url] = f"HTTP {resp.status_code} {resp.headers.get('content-type', '')}"
                        continue
                    page = parse_page(str(resp.url), resp.text)
                    if len(result.pages) < max_pages:
                        result.pages.append(page)
                    for link in page.links:
                        if link not in seen:
                            seen.add(link)
                            queue.put_nowait(link)
                except httpx.HTTPError as e:
                    result.errors[url] = type(e).__name__
                finally:
                    queue.task_done()

        async with asyncio.TaskGroup() as tg:
            for _ in range(concurrency):
                tg.create_task(worker())
    return result
