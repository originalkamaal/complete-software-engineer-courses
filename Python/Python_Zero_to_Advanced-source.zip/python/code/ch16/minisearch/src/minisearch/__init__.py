# file: minisearch/src/minisearch/__init__.py
"""minisearch: crawl, index, and search a website."""
__version__ = "1.0.0"
