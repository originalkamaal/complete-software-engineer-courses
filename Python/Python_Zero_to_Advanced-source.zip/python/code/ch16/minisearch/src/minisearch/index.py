# file: minisearch/src/minisearch/index.py
import math
import sqlite3
from collections import Counter
from collections.abc import Iterable

from .models import Hit, Page
from .parse import tokenize

SCHEMA = """
CREATE TABLE IF NOT EXISTS pages (id INTEGER PRIMARY KEY, url TEXT UNIQUE, title TEXT, text TEXT, length INTEGER);
CREATE TABLE IF NOT EXISTS postings (term TEXT, page_id INTEGER, count INTEGER, PRIMARY KEY (term, page_id));
CREATE INDEX IF NOT EXISTS idx_postings_term ON postings(term);
"""


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.executescript(SCHEMA)
    return conn


def add_pages(conn: sqlite3.Connection, pages: Iterable[Page]) -> int:
    n = 0
    with conn:                                               # one transaction for the whole batch
        for page in pages:
            tokens = tokenize(page.title + " " + page.text)
            # upsert that KEEPS the row id (INSERT OR REPLACE would delete the row and assign a new id,
            # orphaning the old postings - the test suite caught exactly that)
            page_id = conn.execute(
                "INSERT INTO pages (url, title, text, length) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(url) DO UPDATE SET title = excluded.title, text = excluded.text, length = excluded.length "
                "RETURNING id", (page.url, page.title, page.text, len(tokens))).fetchone()[0]
            conn.execute("DELETE FROM postings WHERE page_id = ?", (page_id,))
            conn.executemany("INSERT INTO postings (term, page_id, count) VALUES (?, ?, ?)",
                             ((t, page_id, c) for t, c in Counter(tokens).items()))
            n += 1
    return n


def snippet(text: str, terms: list[str], width: int = 80) -> str:
    low = text.lower()
    pos = min((p for t in terms if (p := low.find(t)) >= 0), default=0)
    start = max(0, pos - width // 4)
    return ("…" if start else "") + text[start:start + width].strip() + ("…" if start + width < len(text) else "")


def search(conn: sqlite3.Connection, query: str, limit: int = 10) -> list[Hit]:
    terms = list(dict.fromkeys(tokenize(query)))
    if not terms:
        return []
    total = conn.execute("SELECT COUNT(*) FROM pages").fetchone()[0]
    scores: Counter[int] = Counter()
    matched: Counter[int] = Counter()                       # how many distinct query terms each page contains
    for term in terms:
        rows = conn.execute("SELECT p.page_id, p.count, pg.length FROM postings p JOIN pages pg ON pg.id = p.page_id "
                            "WHERE p.term = ?", (term,)).fetchall()
        if not rows:
            continue
        idf = math.log(total / len(rows)) + 1.0
        for page_id, count, length in rows:
            scores[page_id] += (count / max(length, 1)) * idf
            matched[page_id] += 1
    hits: list[Hit] = []
    for page_id, score in scores.most_common():
        url, title, text = conn.execute("SELECT url, title, text FROM pages WHERE id = ?", (page_id,)).fetchone()
        coverage = matched[page_id] / len(terms)            # pages matching more of the query rank higher
        bonus = 0.25 * sum(t in tokenize(title) for t in terms)
        final = score * coverage ** 2 * (1 + bonus)
        hits.append(Hit(url=url, title=title, score=round(final, 6), snippet=snippet(text, terms)))
    hits.sort(key=lambda h: (-h.score, h.url))
    return hits[:limit]
