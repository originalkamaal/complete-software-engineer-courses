# file: minisearch/src/minisearch/parse.py
import re
from html.parser import HTMLParser
from urllib.parse import urldefrag, urljoin, urlsplit

from .models import Page

WORD = re.compile(r"[a-z0-9]+")
SKIP_TAGS = {"script", "style", "noscript"}


def tokenize(text: str) -> list[str]:
    return WORD.findall(text.lower())


def normalise_link(base: str, href: str) -> str | None:
    """Absolute http(s) URL on the same host as base, without fragment; None if not crawlable."""
    url, _fragment = urldefrag(urljoin(base, href.strip()))
    parts, base_parts = urlsplit(url), urlsplit(base)
    if parts.scheme not in ("http", "https") or parts.netloc != base_parts.netloc:
        return None
    path = parts.path or "/"
    return f"{parts.scheme}://{parts.netloc}{path}" + (f"?{parts.query}" if parts.query else "")


class _Extractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self.text_parts: list[str] = []
        self.hrefs: list[str] = []
        self._in_title = False
        self._skip_depth = 0
        self._in_link = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in SKIP_TAGS:
            self._skip_depth += 1
        elif tag == "title":
            self._in_title = True
        elif tag == "a":
            self._in_link += 1
            href = dict(attrs).get("href")
            if href:
                self.hrefs.append(href)

    def handle_endtag(self, tag: str) -> None:
        if tag in SKIP_TAGS and self._skip_depth:
            self._skip_depth -= 1
        elif tag == "title":
            self._in_title = False
        elif tag == "a" and self._in_link:
            self._in_link -= 1

    def handle_data(self, data: str) -> None:
        if self._skip_depth or self._in_link:           # skip scripts and navigation (anchor) text
            return
        (self.title_parts if self._in_title else self.text_parts).append(data)


def parse_page(url: str, html: str) -> Page:
    ex = _Extractor()
    ex.feed(html)
    ex.close()
    links: list[str] = []
    for href in ex.hrefs:
        link = normalise_link(url, href)
        if link and link not in links:
            links.append(link)
    text = " ".join(" ".join(ex.text_parts).split())
    title = " ".join("".join(ex.title_parts).split()) or url
    return Page(url=url, title=title, text=text, links=tuple(links))
