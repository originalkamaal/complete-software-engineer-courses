# file: minisearch/src/minisearch/cli.py
import argparse
import asyncio
import os
import sys
import time

from .crawl import crawl
from .index import add_pages, connect, search


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="minisearch", description="Crawl, index, and search a website.")
    sub = p.add_subparsers(dest="command", required=True)
    c = sub.add_parser("crawl", help="crawl a site and index it")
    c.add_argument("url")
    c.add_argument("--db", default="minisearch.db")
    c.add_argument("--max-pages", type=int, default=100)
    c.add_argument("--concurrency", type=int, default=8)
    s = sub.add_parser("search", help="query the index")
    s.add_argument("query")
    s.add_argument("--db", default="minisearch.db")
    s.add_argument("-n", type=int, default=5)
    v = sub.add_parser("serve", help="run the HTTP API")
    v.add_argument("--db", default="minisearch.db")
    v.add_argument("--port", type=int, default=8000)
    args = p.parse_args(argv)

    if args.command == "crawl":
        t = time.perf_counter()
        result = asyncio.run(crawl(args.url, args.max_pages, args.concurrency))
        n = add_pages(connect(args.db), result.pages)
        print(f"crawled {n} pages ({len(result.errors)} errors) in {time.perf_counter() - t:.2f} s")
        for url, err in sorted(result.errors.items())[:5]:
            print(f"  error: {url} -> {err}")
        return 0
    if args.command == "search":
        hits = search(connect(args.db), args.query, args.n)
        if not hits:
            print("no results")
            return 1
        for i, h in enumerate(hits, 1):
            print(f"{i}. {h.title}  [{h.score:.4f}]\n   {h.url}\n   {h.snippet}")
        return 0
    os.environ["MINISEARCH_DB"] = args.db
    import uvicorn
    uvicorn.run("minisearch.api:app", port=args.port, log_level="warning")
    return 0


if __name__ == "__main__":
    sys.exit(main())
