# file: minisearch/src/minisearch/models.py
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Page:
    url: str
    title: str
    text: str
    links: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Hit:
    url: str
    title: str
    score: float
    snippet: str
