# file: e2e.py
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

sys.path.insert(0, "minisearch/tests")
from testsite import build, serve                     # noqa: E402

BIN = Path("cap-env/bin")
with tempfile.TemporaryDirectory() as d:
    root = Path(d, "site"); root.mkdir()
    build(root)
    url, server = serve(root)
    db = str(Path(d, "site.db"))
    run = lambda *args: subprocess.run([str(BIN / "minisearch"), *args], capture_output=True, text=True)
    print("> minisearch crawl ...\n" + run("crawl", url, "--db", db, "--concurrency", "4").stdout)
    print("> minisearch search 'binary search tree' -n 2\n" + run("search", "binary search tree", "--db", db, "-n", "2").stdout)
    api = subprocess.Popen([str(BIN / "minisearch"), "serve", "--db", db, "--port", "8902"])
    try:
        for _ in range(100):
            try:
                r = httpx.get("http://127.0.0.1:8902/search", params={"q": "tree children"})
                break
            except httpx.TransportError:
                time.sleep(0.1)
        print("GET /search?q=tree children ->", r.status_code, [(h["title"], h["score"]) for h in r.json()][:3])
        print("GET /search?q= ->", httpx.get("http://127.0.0.1:8902/search", params={"q": ""}).status_code)
    finally:
        api.terminate(); api.wait(10)
        server.shutdown()
