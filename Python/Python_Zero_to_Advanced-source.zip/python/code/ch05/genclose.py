# file: genclose.py
from contextlib import closing

def numbers():
    print("  open resource")
    try:
        for i in range(10):
            yield i
    finally:
        print("  close resource")

gen = numbers()
print("first two:", next(gen), next(gen))
print("abandoned; nothing closed yet")
gen.close()
print("after close()")

with closing(numbers()) as g:
    for n in g:
        if n == 1:
            break
print("after with closing(...)")
