# file: itertools_demo.py
from itertools import accumulate, batched, chain, count, groupby, islice, pairwise, product, takewhile, zip_longest
import operator

print(list(islice(count(10, 5), 4)), list(takewhile(lambda x: x < 20, count(15))))
print(list(chain("ab", [1, 2])), list(zip_longest("abc", [1], fillvalue="-")))
print(list(accumulate([3, 1, 4, 1, 5])), list(accumulate([3, 1, 4, 1, 5], max)), list(accumulate([1, 2, 3, 4], operator.mul)))
print(list(pairwise("abcd")), list(batched(range(7), 3)))
print(["".join(p) for p in product("ab", repeat=2)])
data = ["apple", "avocado", "banana", "blueberry", "cherry", "apricot"]
print({k: list(g) for k, g in groupby(data, key=lambda w: w[0])})          # NOT sorted: 'a' appears twice
print({k: list(g) for k, g in groupby(sorted(data), key=lambda w: w[0])})  # sorted first: one group per key
