# file: pipeline.py
import itertools

def generate_log(path, n):
    with open(path, "w") as f:
        for i in range(n):
            level = "ERROR" if i % 1000 == 7 else "INFO"
            f.write(f"2026-11-16T10:{i // 60 % 60:02}:{i % 60:02} {level} request {i} took {i % 97} ms\n")

def read_lines(path):
    with open(path) as f:
        for line in f:                      # files are iterators: one line at a time
            yield line.rstrip("\n")

def parse(lines):
    for line in lines:
        ts, level, *rest = line.split(" ")
        yield {"ts": ts, "level": level, "ms": int(rest[-2])}

def errors(records):
    return (r for r in records if r["level"] == "ERROR")

generate_log("big.log", 200_000)
lines_read = 0
def counting(lines):
    global lines_read
    for l in lines:
        lines_read += 1
        yield l

first_three = list(itertools.islice(errors(parse(counting(read_lines("big.log")))), 3))
print(first_three)
print("lines read to find them:", lines_read, "of 200000")
