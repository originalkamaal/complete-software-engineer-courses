# file: protocol.py
class Countdown:                                      # an iterable: each iter() gives a fresh iterator
    def __init__(self, start):
        self.start = start
    def __iter__(self):
        return CountdownIterator(self.start)

class CountdownIterator:
    def __init__(self, n):
        self.n = n
    def __iter__(self):
        return self
    def __next__(self):
        if self.n <= 0:
            raise StopIteration
        self.n -= 1
        return self.n + 1

c = Countdown(3)
print(list(c), list(c))                               # iterable: can be looped twice
it = iter([10, 20, 30])
print(next(it), next(it), next(it), next(it, "done"))  # next with a default instead of StopIteration

loop_it = iter("ab")                                  # what a for loop does, by hand
while True:
    try:
        ch = next(loop_it)
    except StopIteration:
        break
    print("got", ch)
