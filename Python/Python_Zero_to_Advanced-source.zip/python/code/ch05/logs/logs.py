# file: logs/logs.py
import heapq
import random
import time
import tracemalloc
from collections import Counter
from pathlib import Path

LOG = Path("access.log")
ENDPOINTS = ["/", "/login", "/api/items", "/api/orders", "/static/app.js", "/search"]

def make_log(n):
    rng = random.Random(5)
    with LOG.open("w") as f:
        for i in range(n):
            status = rng.choices([200, 304, 404, 500], weights=[85, 8, 5, 2])[0]
            ms = int(rng.expovariate(1 / 40))
            f.write(f"2026-11-15T10:{i // 60000 % 60:02d}:{i // 1000 % 60:02d} {rng.choice(ENDPOINTS)} {status} {ms}\n")

def parse(lines):
    for line in lines:
        ts, path, status, ms = line.split()
        yield path, int(status), int(ms)

def analyse_lazy():
    with LOG.open() as f:
        records = parse(f)                              # nothing is read yet
        errors, slowest = Counter(), []
        for path, status, ms in records:
            if status >= 500:
                errors[path] += 1
            if len(slowest) < 5:
                heapq.heappush(slowest, ms)
            elif ms > slowest[0]:
                heapq.heapreplace(slowest, ms)
    return errors.most_common(3), sorted(slowest, reverse=True)

def analyse_eager():
    lines = LOG.read_text().splitlines()                # everything in memory
    records = [tuple(l.split()) for l in lines]
    parsed = [(p, int(s), int(m)) for _, p, s, m in records]
    errors = Counter(p for p, s, _ in parsed if s >= 500)
    slowest = sorted((m for _, _, m in parsed), reverse=True)[:5]
    return errors.most_common(3), slowest

make_log(1_000_000)
print(f"log file: {LOG.stat().st_size / 1e6:.1f} MB")
results = {}
for name, f in (("lazy pipeline", analyse_lazy), ("eager lists", analyse_eager)):
    tracemalloc.start()
    t = time.perf_counter()
    results[name] = f()
    el = time.perf_counter() - t
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(f"{name:>14}: peak memory {peak / 1e3:>9,.0f} kB, {el:.1f} s")
print("same results:", results["lazy pipeline"] == results["eager lists"])
print("top 5xx endpoints:", results["lazy pipeline"][0], "| slowest (ms):", results["lazy pipeline"][1])
LOG.unlink()
