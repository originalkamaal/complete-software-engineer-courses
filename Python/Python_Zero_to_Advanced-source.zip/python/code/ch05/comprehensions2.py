# file: comprehensions2.py
import sys

x = "unchanged"
squares = [x * x for x in range(5)]
print(squares, x)                                    # x did not leak

pairs = [(r, c) for r in range(3) for c in range(r)]  # like: for r ...: for c ...:
print(pairs)
matrix = [[1, 2, 3], [4, 5, 6]]
print([n for row in matrix for n in row], [list(col) for col in zip(*matrix)])
words = ["apple", "bob", "civic", "dad", "eagle"]
print({w: len(w) for w in words if w == w[::-1]}, {len(w) for w in words})

big_list = [n * n for n in range(1_000_000)]
big_gen = (n * n for n in range(1_000_000))
print(f"list: {sys.getsizeof(big_list):,} bytes, generator: {sys.getsizeof(big_gen)} bytes")
print(sum(n * n for n in range(1_000_000)) == sum(big_list))   # no brackets needed as the only argument
