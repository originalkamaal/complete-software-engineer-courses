# file: generators.py
def countdown(n):
    print("  (starting)")
    while n > 0:
        yield n
        n -= 1
    print("  (finished)")

g = countdown(2)
print("created:", g)
print(next(g)); print(next(g))
print(next(g, "exhausted"))

def naturals():                                       # infinite
    n = 1
    while True:
        yield n
        n += 1

def take(n, it):
    for i, x in enumerate(it):
        if i == n:
            return
        yield x

def evens(it):
    return (x for x in it if x % 2 == 0)

def squared(it):
    for x in it:
        yield x * x

print(list(take(5, squared(evens(naturals())))))      # lazy: only 10 naturals are ever produced
