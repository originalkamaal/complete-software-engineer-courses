# file: comprehensions.py
import sys
import timeit

nums = range(1, 11)
print([n * n for n in nums if n % 2 == 0])
print({n: n * n for n in range(4)}, {c.lower() for c in "Hello"})
print([(r, c) for r in range(2) for c in "ab"])         # nested: r outer, c inner
matrix = [[1, 2, 3], [4, 5, 6]]
print([[row[i] for row in matrix] for i in range(3)])   # transpose
x = "outer"
_ = [x for x in range(3)]
print("loop variable did not leak:", x)

big_list = [n for n in range(1_000_000)]
big_gen = (n for n in range(1_000_000))
print(f"list: {sys.getsizeof(big_list):,} bytes; generator: {sys.getsizeof(big_gen)} bytes")

def with_loop():
    out = []
    for n in range(10_000):
        out.append(n * 2)
    return out
def with_comp():
    return [n * 2 for n in range(10_000)]
for f in (with_loop, with_comp):
    print(f"{f.__name__}: {min(timeit.repeat(f, number=200, repeat=3)) / 200 * 1e6:.0f} µs")
