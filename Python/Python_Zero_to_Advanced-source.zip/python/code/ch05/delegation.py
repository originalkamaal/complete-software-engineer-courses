# file: delegation.py
def flatten(nested):
    for item in nested:
        if isinstance(item, (list, tuple)):
            yield from flatten(item)                  # delegate recursively
        else:
            yield item
print(list(flatten([1, [2, [3, (4, 5)]], [], 6])))

def running_average():
    total = count = 0
    average = None
    try:
        while True:
            value = yield average                     # receives values via send()
            total += value; count += 1
            average = total / count
    finally:
        print("  generator closed: cleanup runs")

avg = running_average()
next(avg)                                             # "prime" it: run to the first yield
print([avg.send(v) for v in (10, 20, 60)])
avg.close()
