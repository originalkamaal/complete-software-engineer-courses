# file: iterable_class.py
class Countdown:
    def __init__(self, start):
        self.start = start
    def __iter__(self):                 # a generator: a new iterator each time
        n = self.start
        while n > 0:
            yield n
            n -= 1
    def __len__(self):
        return self.start

c = Countdown(3)
print(list(c), list(c), len(c), 2 in c, sorted(c))
it = iter(c)
print(next(it), next(it), list(it), list(it))   # the iterator is used up
