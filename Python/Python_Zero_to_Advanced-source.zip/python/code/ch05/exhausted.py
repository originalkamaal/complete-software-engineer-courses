# file: exhausted.py
squares = (x * x for x in range(5))
print("max:", max(squares), "| sum afterwards:", sum(squares))
pairs = zip("abc", [1, 2, 3])
print(list(pairs), list(pairs))
