// file: geom.c
#include <math.h>
typedef struct { double x, y; } Point;

double path_length(const Point *pts, int n) {
    double total = 0;
    for (int i = 1; i < n; i++) total += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    return total;
}
void scale(Point *pts, int n, double k) {
    for (int i = 0; i < n; i++) { pts[i].x *= k; pts[i].y *= k; }
}
