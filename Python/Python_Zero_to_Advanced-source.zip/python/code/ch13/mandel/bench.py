# file: mandel/bench.py
import ctypes
import time
import numpy as np
from mandel_py import mandel_py
from mandel_np import mandel_np
from mandel_cy import mandel_cy

lib = ctypes.CDLL("./libmandel.so")
lib.mandel_c.argtypes = [ctypes.c_int] * 3 + [ctypes.c_double] * 4 + [ctypes.POINTER(ctypes.c_int64)]
lib.mandel_c.restype = None

def mandel_c(w, h, max_iter, x0=-2.0, x1=1.0, y0=-1.2, y1=1.2):
    out = np.zeros((h, w), dtype=np.int64)
    lib.mandel_c(w, h, max_iter, x0, x1, y0, y1, out.ctypes.data_as(ctypes.POINTER(ctypes.c_int64)))
    return out

W, H, IT = 400, 300, 200
results, times = {}, {}
for name, f in (("pure Python", mandel_py), ("NumPy", mandel_np), ("Cython", mandel_cy), ("C via ctypes", mandel_c)):
    t = time.perf_counter()
    results[name] = np.asarray(f(W, H, IT))
    times[name] = time.perf_counter() - t
base = times["pure Python"]
for name in results:
    print(f"{name:>13}: {times[name] * 1000:8,.1f} ms  ({base / times[name]:6.1f}x)  identical to Python: {np.array_equal(results[name], results['pure Python'])}")
inside = (results["C via ctypes"] == IT).sum()
print(f"{inside:,} of {W * H:,} points never escaped (in the set)")
rows = results["C via ctypes"][::30, ::10]
print("\n".join("".join(" .:-=+*#%@"[min(9, v // 20)] for v in row) for row in rows))
