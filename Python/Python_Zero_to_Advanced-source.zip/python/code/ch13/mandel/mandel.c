// file: mandel/mandel.c
#include <stdint.h>

void mandel_c(int w, int h, int max_iter, double x0, double x1, double y0, double y1, int64_t *out) {
    for (int j = 0; j < h; j++) {
        double ci = y0 + (y1 - y0) * j / (h - 1);
        for (int i = 0; i < w; i++) {
            double cr = x0 + (x1 - x0) * i / (w - 1);
            double zr = 0.0, zi = 0.0;
            int n = 0;
            while (n < max_iter && zr * zr + zi * zi <= 4.0) {
                double t = zr * zr - zi * zi + cr;
                zi = 2.0 * zr * zi + ci;
                zr = t;
                n++;
            }
            out[j * w + i] = n;
        }
    }
}
