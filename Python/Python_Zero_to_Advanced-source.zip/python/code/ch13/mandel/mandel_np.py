# file: mandel/mandel_np.py
import numpy as np

def mandel_np(w, h, max_iter, x0=-2.0, x1=1.0, y0=-1.2, y1=1.2):
    cr = x0 + (x1 - x0) * np.arange(w) / (w - 1)
    ci = y0 + (y1 - y0) * np.arange(h) / (h - 1)
    CR, CI = np.meshgrid(cr, ci)
    ZR, ZI = np.zeros_like(CR), np.zeros_like(CI)
    counts = np.zeros(CR.shape, dtype=np.int64)
    active = np.ones(CR.shape, dtype=bool)
    for _ in range(max_iter):
        active &= ZR * ZR + ZI * ZI <= 4.0                # points still iterating
        if not active.any():
            break
        zr, zi = ZR[active], ZI[active]
        ZR[active], ZI[active] = zr * zr - zi * zi + CR[active], 2.0 * zr * zi + CI[active]
        counts[active] += 1
    return counts
