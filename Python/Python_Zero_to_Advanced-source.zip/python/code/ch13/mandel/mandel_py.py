# file: mandel/mandel_py.py
def mandel_py(w, h, max_iter, x0=-2.0, x1=1.0, y0=-1.2, y1=1.2):
    out = [[0] * w for _ in range(h)]
    for j in range(h):
        ci = y0 + (y1 - y0) * j / (h - 1)
        for i in range(w):
            cr = x0 + (x1 - x0) * i / (w - 1)
            zr = zi = 0.0
            n = 0
            while n < max_iter and zr * zr + zi * zi <= 4.0:
                zr, zi = zr * zr - zi * zi + cr, 2.0 * zr * zi + ci
                n += 1
            out[j][i] = n
    return out
