# file: compare_primes.py
import time
import primes_cy
import primes_py

for name, mod in (("Python", primes_py), ("Cython (typed)", primes_cy)):
    t = time.perf_counter()
    r = mod.count_primes(200_000)
    print(f"{name:>15}: {r} primes below 200,000 in {(time.perf_counter() - t) * 1000:,.0f} ms")
