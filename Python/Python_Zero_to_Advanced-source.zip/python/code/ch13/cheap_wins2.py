# file: cheap_wins2.py
import timeit

data = list(range(1_000_000))

def loop_sum():
    total = 0
    for x in data:
        total += x
    return total

def append_loop():
    out = []
    for x in data:
        out.append(x * 2)
    return out

def comprehension():
    return [x * 2 for x in data]

t = {name: timeit.timeit(fn, number=5) for name, fn in
     [("for loop sum", loop_sum), ("built-in sum", lambda: sum(data)),
      ("append loop", append_loop), ("comprehension", comprehension)]}
print("sum() faster than the for loop:", t["built-in sum"] < t["for loop sum"] / 2)
print("comprehension faster than append loop:", t["comprehension"] < t["append loop"])
