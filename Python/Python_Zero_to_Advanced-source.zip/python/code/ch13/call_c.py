# file: call_c.py
import ctypes
import time
import numpy as np

lib = ctypes.CDLL("./libfastsum.so")
lib.sum_squares.argtypes = [ctypes.POINTER(ctypes.c_int64), ctypes.c_size_t]
lib.sum_squares.restype = ctypes.c_int64

a = np.arange(1_000_000, dtype=np.int64)
t = time.perf_counter(); c_result = lib.sum_squares(a.ctypes.data_as(ctypes.POINTER(ctypes.c_int64)), a.size); tc = time.perf_counter() - t
t = time.perf_counter(); py_result = sum(int(v) * int(v) for v in range(1_000_000)); tp = time.perf_counter() - t
print(f"C: {c_result} in {tc * 1000:.2f} ms | Python: {py_result} in {tp * 1000:.0f} ms | equal: {c_result == py_result}")
