# file: primes_py.py
def count_primes(limit):
    count = 0
    for n in range(2, limit):
        d, is_prime = 2, True
        while d * d <= n:
            if n % d == 0:
                is_prime = False
                break
            d += 1
        count += is_prime
    return count
