# file: call_geom.py
import ctypes

lib = ctypes.CDLL("./libgeom.so")

class Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]

lib.path_length.argtypes = [ctypes.POINTER(Point), ctypes.c_int]
lib.path_length.restype = ctypes.c_double
lib.scale.argtypes = [ctypes.POINTER(Point), ctypes.c_int, ctypes.c_double]
lib.scale.restype = None

pts = (Point * 3)(Point(0, 0), Point(3, 4), Point(6, 8))
print("length:", lib.path_length(pts, len(pts)))
lib.scale(pts, len(pts), 0.5)                      # C modifies our array in place
print("scaled:", [(p.x, p.y) for p in pts])

raw = ctypes.CDLL("./libgeom.so")                  # same library, no restype declared
print("without restype the double comes back as:", type(raw.path_length(pts, 3)).__name__)
