# file: overflow.py
import numpy as np
a = np.array([2**62, 2**62], dtype=np.int64)
print("NumPy int64:", a + a, "| sum:", a.sum())
print("Python int: ", 2**62 + 2**62)
small = np.array([200, 100], dtype=np.uint8)
print("uint8 200 + 100 =", small[0] + small[1], "| as Python ints:", int(small[0]) + int(small[1]))
