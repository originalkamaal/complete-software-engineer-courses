# file: cheap_wins.py
import timeit

words = [f"w{i}" for i in range(20_000)]

def concat_loop():
    s = ""
    for w in words:
        s += w + ","                                    # may copy the growing string
    return s

def concat_join():
    return ",".join(words) + ","

def squares_loop():
    out = []
    for i in range(20_000):
        out.append(i * i)
    return out

def squares_comp():
    return [i * i for i in range(20_000)]

def squares_local_append():
    out = []
    append = out.append                                 # hoist the attribute lookup
    for i in range(20_000):
        append(i * i)
    return out

def total_loop():
    t = 0
    for i in range(200_000):
        t += i
    return t

def total_builtin():
    return sum(range(200_000))

assert concat_loop() == concat_join() and squares_loop() == squares_comp() == squares_local_append()
for f in (concat_loop, concat_join, squares_loop, squares_local_append, squares_comp, total_loop, total_builtin):
    us = min(timeit.repeat(f, number=20, repeat=5)) / 20 * 1e6
    print(f"{f.__name__:>22}: {us:9,.0f} µs")
