# file: numpy_basics.py
import time
import numpy as np

rng = np.random.default_rng(13)
x = rng.random(1_000_000)
t = time.perf_counter(); py = sum(v * v for v in x.tolist()); tp = time.perf_counter() - t
t = time.perf_counter(); vec = float(np.dot(x, x)); tv = time.perf_counter() - t
print(f"sum of squares: Python {tp * 1000:.0f} ms, NumPy {tv * 1000:.2f} ms, relative difference {abs(py - vec) / vec:.1e}")

m = np.arange(12).reshape(3, 4)
print(m, m.shape, m.dtype, sep="\n")
print("column means:", m.mean(axis=0), "| row sums:", m.sum(axis=1))
print("broadcast add a row vector:\n", m + np.array([100, 200, 300, 400]))
print("mask:", m[m % 3 == 0], "| where:", np.where(m > 6, m, 0)[1])

points = rng.random((5, 2))
d = np.sqrt(((points[:, None, :] - points[None, :, :]) ** 2).sum(axis=2))   # all pairwise distances
print("pairwise distance matrix shape:", d.shape, "| symmetric:", np.allclose(d, d.T), "| zero diagonal:", np.allclose(np.diag(d), 0))
