# file: aliasing.py
grid = [[0] * 3] * 3
grid[0][0] = 1
print(grid, [id(row) for row in grid])
grid = [[0] * 3 for _ in range(3)]
grid[0][0] = 1
print(grid, len({id(row) for row in grid}), "distinct rows")
