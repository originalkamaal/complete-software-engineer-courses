# file: lists.py
import sys

a = []
last = sys.getsizeof(a)
print(f"len  0: {last} bytes")
for i in range(1, 33):
    a.append(i)
    size = sys.getsizeof(a)
    if size != last:                                  # print only when the array was reallocated
        print(f"len {i:>2}: {size} bytes  (capacity ~{(size - sys.getsizeof([])) // 8} slots)")
        last = size

b = [5, 3, 8, 1]
b.append(9); b.insert(0, 0); b.extend([7, 7]); b.remove(7)   # remove deletes the FIRST 7 only
print(b)
last, first = b.pop(), b.pop(0)
print(last, first, b, b.index(8), b.count(7))
print(sorted(b), sorted(b, reverse=True), b[::-1], b[1:3])
c = b[:]                                              # a copy: c and b are different lists
c.append(100)
print(b, c)
