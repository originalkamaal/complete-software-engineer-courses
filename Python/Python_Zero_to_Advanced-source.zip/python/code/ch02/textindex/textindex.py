# file: textindex/textindex.py
import re
from collections import Counter, defaultdict
from pathlib import Path

text = Path(__file__).resolve().parents[3].joinpath("src", "ch00.md").read_text()
lines = text.splitlines()
WORD = re.compile(r"[a-z]+")

freq = Counter()
where = defaultdict(set)                                   # word -> set of line numbers
for no, line in enumerate(lines, 1):
    for w in WORD.findall(line.lower()):
        freq[w] += 1
        where[w].add(no)

print(f"{len(lines)} lines, {sum(freq.values()):,} words, {len(freq):,} distinct")
print("most common:", freq.most_common(8))
hapax = sorted(w for w, c in freq.items() if c == 1 and len(w) > 9)
print("long words used once:", hapax[:8])

anagrams = defaultdict(set)
for w in freq:
    anagrams["".join(sorted(w))].add(w)
groups = sorted((sorted(g) for g in anagrams.values() if len(g) > 1), key=len, reverse=True)
print("anagram groups:", groups[:6])

def lines_with_all(*words):
    sets = [where.get(w, set()) for w in words]
    return sorted(set.intersection(*sets)) if sets else []

for query in (("reference", "count"), ("bytecode", "loop"), ("object", "identity", "type")):
    hits = lines_with_all(*query)
    print(f"lines containing {' + '.join(query)}: {hits[:10]}")
