# file: copying.py
import copy
from operator import itemgetter

orig = {"name": "team", "members": ["ana", "ben"]}
shallow, deep = copy.copy(orig), copy.deepcopy(orig)
orig["members"].append("cy")
print("shallow sees the change:", shallow["members"], "| deep does not:", deep["members"])

people = [("ana", 31, "Pune"), ("ben", 25, "Delhi"), ("cy", 31, "Agra"), ("dev", 25, "Pune")]
print(sorted(people, key=itemgetter(1)))                      # stable: ties keep original order
print(sorted(people, key=lambda p: (-p[1], p[0])))            # age descending, then name
print(max(people, key=lambda p: p[1]), min(people, key=len))
by_city = sorted(sorted(people, key=itemgetter(0)), key=itemgetter(2))   # two stable passes
print([p[0] for p in by_city])
