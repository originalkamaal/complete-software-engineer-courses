# file: bad_hash.py
class Point:
    def __init__(self, x, y):
        self.x, self.y = x, y
    def __eq__(self, other):
        return (self.x, self.y) == (other.x, other.y)
    def __hash__(self):
        return hash((self.x, self.y))                 # depends on mutable fields: dangerous

p = Point(1, 2)
d = {p: "here"}
p.x = 100                                             # mutate the key after insertion
print("p in d:", p in d, "| Point(1, 2) in d:", Point(1, 2) in d, "| len(d):", len(d))
print("but iterating finds it:", [(k.x, k.y) for k in d])
