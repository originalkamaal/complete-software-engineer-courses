# file: stable.py
from operator import attrgetter, itemgetter

staff = [("ravi", "eng", 90), ("ada", "eng", 120), ("lin", "ops", 90), ("bo", "eng", 90)]
by_two_passes = sorted(sorted(staff, key=itemgetter(0)), key=itemgetter(1))   # dept, then name
by_tuple = sorted(staff, key=lambda e: (e[1], -e[2], e[0]))                     # dept, salary desc, name
print(by_two_passes)
print(by_tuple)

calls = 0
def key(s):
    global calls
    calls += 1
    return s.lower()
words = ["b", "A", "c", "B", "a"] * 200
sorted(words, key=key)
print("key called", calls, "times for", len(words), "items")
print(sorted(["b", "A", "c", "B", "a"]), sorted(["b", "A", "c", "B", "a"], key=str.lower))
