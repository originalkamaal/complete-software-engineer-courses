# file: sets.py
import time

a, b = {1, 2, 3, 4}, {3, 4, 5}
print(a | b, a & b, a - b, a ^ b, {3, 4} <= a)
emails = ["x@a.com", "y@b.com", "x@a.com"]
print(len(set(emails)), "unique;", list(dict.fromkeys(emails)), "(dedupe keeping order)")
print({frozenset({1, 2}): "a frozenset can be a key"})

n = 50_000
as_list, as_set = list(range(n)), set(range(n))
probes = range(n - 1000, n)                           # values near the end: worst case for the list
for name, container in (("list", as_list), ("set", as_set)):
    t = time.perf_counter()
    hits = sum(1 for p in probes if p in container)
    print(f"1,000 membership tests in a {name} of {n:,}: {(time.perf_counter() - t) * 1000:8.2f} ms ({hits} hits)")
