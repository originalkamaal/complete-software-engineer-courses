# file: tuples2.py
from typing import NamedTuple

first, *middle, last = [1, 2, 3, 4, 5]
print(first, middle, last)
head, *tail = "abc"
print(head, tail)
(a, b), c = (1, 2), 3
print(a, b, c)
a, b = b, a                                     # swap without a temporary
print(a, b)

grid = {(0, 0): "start", (2, 3): "treasure"}
print(grid[(2, 3)], grid.get((9, 9), "empty"))

class Point(NamedTuple):
    x: float
    y: float = 0.0
    def dist(self) -> float:
        return (self.x ** 2 + self.y ** 2) ** 0.5

p = Point(3, 4)
print(p, p.x, p[1], p.dist(), p._replace(y=0), Point(5))
x, y = p                                        # still a tuple
print(x + y, p == (3, 4))
t = (1, [2, 3])
t[1].append(4)                                  # the tuple is immutable; the list inside is not
print(t)
try:
    hash(t)
except TypeError as e:
    print("unhashable:", e)
