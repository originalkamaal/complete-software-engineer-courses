# file: sets2.py
import timeit

python = {"ada", "alan", "grace", "linus"}
rust = {"grace", "linus", "ken"}
print("both:", sorted(python & rust), "either:", sorted(python | rust))
print("only python:", sorted(python - rust), "exactly one:", sorted(python ^ rust))
print({"grace"} <= python, python.isdisjoint({"x"}))

seen, dupes = set(), []
for w in "the cat and the hat and the bat".split():
    if w in seen:
        dupes.append(w)
    seen.add(w)
print("duplicates in order:", dupes, "| first occurrences:", list(dict.fromkeys("the cat and the hat".split())))

pairs = {frozenset({"a", "b"}): 1}
print(pairs[frozenset({"b", "a"})])            # order does not matter

big_list = list(range(100_000))
big_set = set(big_list)
t_list = timeit.timeit(lambda: 99_999 in big_list, number=200)
t_set = timeit.timeit(lambda: 99_999 in big_set, number=200)
print("set membership faster by more than 100x:", t_list > 100 * t_set)
