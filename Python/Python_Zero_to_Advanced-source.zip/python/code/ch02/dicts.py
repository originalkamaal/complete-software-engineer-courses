# file: dicts.py
from collections import Counter, defaultdict

stock = {"apple": 3, "pear": 0}
stock["kiwi"] = 7
print(stock, stock.get("plum", 0), "pear" in stock, list(stock))
for fruit, qty in stock.items():
    print(f"  {fruit}: {qty}")
print({k: v for k, v in stock.items() if v})          # dict comprehension
print(stock | {"apple": 10, "fig": 1})                # merge: right side wins
words = "the cat and the hat and the bat".split()
by_letter = defaultdict(list)
for w in words:
    by_letter[w[0]].append(w)
print(dict(by_letter))
print(Counter(words).most_common(2))
try:
    {["a", "list"]: 1}
except TypeError as e:
    print("TypeError:", e)
