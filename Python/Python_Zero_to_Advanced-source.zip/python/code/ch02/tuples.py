# file: tuples.py
from typing import NamedTuple

point = 3, 4                                         # parentheses are optional: the comma makes the tuple
x, y = point
first, *middle, last = [1, 2, 3, 4, 5]
print(point, x, y, first, middle, last)
a, b = 1, 2
a, b = b, a                                          # swap via packing and unpacking
print(a, b, (1,), type((1)), type((1,)))

class City(NamedTuple):
    name: str
    lat: float
    lon: float
paris = City("Paris", 48.86, 2.35)
print(paris, paris.name, paris[1], paris._replace(name="Lutetia"))
locations = {(48.86, 2.35): "Paris"}                 # tuples can be dict keys
print(locations[(48.86, 2.35)])
t = ([1, 2], 3)
t[0].append(99)                                      # the tuple is immutable; the list inside is not
print(t)
