# file: atomic.py
import json
import os
import tempfile
from pathlib import Path

def write_atomic(path: Path, data: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())               # the data is on disk before the rename
        os.replace(tmp, path)                  # atomic: readers see old or new, never half
    except BaseException:
        os.unlink(tmp)
        raise

cfg = Path("settings.json")
write_atomic(cfg, json.dumps({"theme": "dark", "size": 14}))
print(cfg.read_text(), sorted(p.name for p in Path(".").glob("settings.json*")))

with tempfile.TemporaryDirectory() as d:
    p = Path(d) / "scratch.txt"
    p.write_text("temporary")
    print("inside:", p.exists(), p.read_text())
print("after the with block:", p.exists())
print(Path("data/raw/2026/file.csv").parts, Path("report.tar.gz").suffixes, Path("a/b/c.txt").with_suffix(".md"))
