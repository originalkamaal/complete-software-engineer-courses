# file: pickle_danger.py
import pickle

class Payload:
    def __reduce__(self):                                # tells pickle how to "rebuild" this object...
        import os
        return (os.system, ("echo '  !!! arbitrary command executed during pickle.loads'",))

evil = pickle.dumps(Payload())
print("pickle bytes look harmless:", evil[:40], "...")
pickle.loads(evil)                                       # ...and loading runs the command
safe = pickle.loads(pickle.dumps({"a": [1, 2], "b": (3, 4)}))
print("ordinary round trip:", safe)
