# file: files.py
import hashlib
from pathlib import Path

base = Path("demo_dir")
base.mkdir(exist_ok=True)
notes = base / "notes.txt"
notes.write_text("first line\nsecond line\nthird line\n", encoding="utf-8")
with notes.open("a", encoding="utf-8") as f:
    f.write("appended line\n")
with notes.open(encoding="utf-8") as f:
    for no, line in enumerate(f, 1):                    # streaming, one line at a time
        print(no, line.rstrip("\n"))

big = base / "blob.bin"
big.write_bytes(bytes(range(256)) * 4096)              # 1 MiB
h = hashlib.sha256()
with big.open("rb") as f:
    while chunk := f.read(64 * 1024):                  # walrus: read until b""
        h.update(chunk)
print(f"{big.name}: {big.stat().st_size:,} bytes, sha256 {h.hexdigest()[:16]}...")
print(sorted(p.name for p in base.glob("*")), notes.suffix, notes.stem, notes.parent, notes.resolve().is_absolute())
try:
    with notes.open("x") as f:                         # "x": create, fail if it exists
        pass
except FileExistsError as e:
    print("FileExistsError:", e.filename)
for p in base.iterdir():
    p.unlink()
base.rmdir()
