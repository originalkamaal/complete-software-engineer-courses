# file: formats2.py
import csv
import io
import json
from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal

text = 'name,comment,amount\nada,"says ""hi"", then leaves",10.50\nbob,"two\nlines",3\n'
rows = list(csv.DictReader(io.StringIO(text, newline="")))
for r in rows:
    print(r)
print("naive split gets", len(text.splitlines()[1].split(",")), "fields on line 2 instead of 3")

@dataclass
class Invoice:
    number: int
    issued: date
    total: Decimal

def encode(o):
    if isinstance(o, date):
        return o.isoformat()
    if isinstance(o, Decimal):
        return str(o)                             # keep exact decimal digits
    raise TypeError(f"cannot serialise {type(o).__name__}")

inv = Invoice(7, date(2026, 11, 16), Decimal("1999.90"))
s = json.dumps(asdict(inv), default=encode)
print(s)
back = json.loads(s, parse_float=Decimal)
print(Invoice(back["number"], date.fromisoformat(back["issued"]), Decimal(back["total"])) == inv)
try:
    json.dumps({"when": date.today()})
except TypeError as e:
    print("TypeError:", e)
print(json.dumps({"price": 0.1 + 0.2}), json.loads("1e400"), json.dumps(float("nan")))
