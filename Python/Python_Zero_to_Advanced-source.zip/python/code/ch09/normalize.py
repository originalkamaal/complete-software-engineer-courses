# file: normalize.py
import unicodedata
a = "café"                 # é as one code point
b = "café"                # e + combining acute accent
print(a, b, a == b, len(a), len(b))
nfc = lambda s: unicodedata.normalize("NFC", s)
print("after NFC:", nfc(a) == nfc(b), len(nfc(b)))
print("Straße".lower() == "STRASSE".lower(), "Straße".casefold() == "STRASSE".casefold())
