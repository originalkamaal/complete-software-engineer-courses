# file: encodings.py
s = "café ☕ 🐍"
for enc in ("utf-8", "utf-16-le", "latin-1"):
    try:
        b = s.encode(enc)
        print(f"{enc:>9}: {len(b):>2} bytes {b[:12]!r}...")
    except UnicodeEncodeError as e:
        print(f"{enc:>9}: cannot encode {e.object[e.start]!r} ({e.reason})")
raw = "café".encode("utf-8")
print("decoded with latin-1 (mojibake):", raw.decode("latin-1"))
try:
    b"\xff\xfeabc".decode("utf-8")
except UnicodeDecodeError as e:
    print("UnicodeDecodeError:", e)
print("errors='replace':", b"ok \xff bad".decode("utf-8", errors="replace"))
print("bytes are integers:", raw[0], list(raw), bytes([99, 97, 102, 195, 169]).decode())
