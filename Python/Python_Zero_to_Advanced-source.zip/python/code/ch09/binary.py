# file: binary.py
import struct

record = struct.Struct("<I10sd")                       # uint32 id, 10-byte name, float64 price
print("record size:", record.size)
packed = record.pack(42, "widget".encode(), 3.5)
print(packed.hex(" "))
rid, name, price = record.unpack(packed)
print(rid, name.rstrip(b"\0").decode(), price)
print("big-endian 1:", struct.pack(">I", 1).hex(), "| little-endian 1:", struct.pack("<I", 1).hex())
data = b"".join(record.pack(i, f"item{i}".encode(), i * 1.5) for i in range(5))
view = memoryview(data)
third = record.unpack(view[2 * record.size:3 * record.size])   # random access, no copy of data
print("third record:", third[0], third[1].rstrip(b"\0").decode(), third[2])
try:
    struct.pack("<H", 70000)
except struct.error as e:
    print("struct.error:", e)
