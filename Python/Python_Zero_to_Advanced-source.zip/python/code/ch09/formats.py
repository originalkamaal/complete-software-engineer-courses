# file: formats.py
import csv
import io
import json
from datetime import date
from decimal import Decimal

rows = [{"name": "Ana", "city": "Pune, MH", "note": 'says "hi"'}, {"name": "Ben", "city": "Delhi", "note": "line1\nline2"}]
buf = io.StringIO(newline="")
w = csv.DictWriter(buf, fieldnames=["name", "city", "note"])
w.writeheader(); w.writerows(rows)
text = buf.getvalue()
print(text)
print("naive split breaks:", text.splitlines()[1].split(","))
print("csv module round-trips:", list(csv.DictReader(io.StringIO(text, newline=""))) == rows)

def encode(obj):
    if isinstance(obj, (date, Decimal)):
        return {"__type__": type(obj).__name__, "value": str(obj)}
    raise TypeError(f"not JSON serializable: {type(obj).__name__}")

def decode(d):
    match d:
        case {"__type__": "date", "value": v}:
            return date.fromisoformat(v)
        case {"__type__": "Decimal", "value": v}:
            return Decimal(v)
    return d

invoice = {"id": 7, "issued": date(2026, 11, 15), "amount": Decimal("19.99"), "tags": ("a", "b")}
s = json.dumps(invoice, default=encode, indent=None)
print(s)
back = json.loads(s, object_hook=decode)
print(back, "| tuple came back as", type(back["tags"]).__name__)
try:
    json.dumps({"when": date.today()})
except TypeError as e:
    print("TypeError:", e)
