# file: struct2.py
import struct

print(struct.calcsize("@BI"), struct.calcsize("<BI"))        # native alignment pads after the byte
print(struct.pack("<I", 1).hex(), struct.pack(">I", 1).hex())

header = struct.Struct("<4sHHI")                              # magic, version, flags, length
blob = header.pack(b"BOOK", 2, 0b101, 1234) + b"payload..."
magic, version, flags, length = header.unpack_from(blob)
print(magic, version, bin(flags), length, header.size)
for rec in struct.iter_unpack("<hh", bytes([1, 0, 255, 255, 0, 1, 2, 0])):
    print(rec)
print(int.from_bytes(b"\x01\x00", "little"), (258).to_bytes(2, "big"))
