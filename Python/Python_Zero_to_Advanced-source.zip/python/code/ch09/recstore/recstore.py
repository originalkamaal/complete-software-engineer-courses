# file: recstore/recstore.py
import csv
import json
import random
import struct
import time
from pathlib import Path

HEADER = struct.Struct("<4sHI")                        # magic, version, count
RECORD = struct.Struct("<I24sdI")                      # id, name (24 bytes UTF-8), price, stock
MAGIC, VERSION = b"PRDB", 1

def make_csv(path, n, rng):
    ids = sorted(rng.sample(range(1, 10 * n), n))
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "name", "price", "stock"])
        for i in ids:
            w.writerow([i, f"Produkt-{i}-é", f"{rng.uniform(1, 500):.2f}", rng.randint(0, 999)])
    return ids

def csv_to_bin(src, dst):
    with src.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    with dst.open("wb") as out:
        out.write(HEADER.pack(MAGIC, VERSION, len(rows)))
        for r in rows:                                  # rows are sorted by id: enables binary search
            name = r["name"].encode("utf-8")
            if len(name) > 24:
                raise ValueError(f"name too long for the format: {r['name']!r}")
            out.write(RECORD.pack(int(r["id"]), name, float(r["price"]), int(r["stock"])))
    return len(rows)

def decode(rec):
    rid, name, price, stock = RECORD.unpack(rec)
    return {"id": rid, "name": name.rstrip(b"\0").decode("utf-8"), "price": price, "stock": stock}

def find(f, count, target):                             # binary search with seek
    lo, hi = 0, count - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        f.seek(HEADER.size + mid * RECORD.size)
        rec = f.read(RECORD.size)
        rid = struct.unpack_from("<I", rec)[0]
        if rid == target:
            return decode(rec)
        lo, hi = (mid + 1, hi) if rid < target else (lo, mid - 1)
    return None

def find_in_csv(path, target):
    with path.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if int(r["id"]) == target:
                return r
    return None

rng = random.Random(9)
src, dst = Path("products.csv"), Path("products.bin")
ids = make_csv(src, 100_000, rng)
n = csv_to_bin(src, dst)
print(f"{n:,} rows: CSV {src.stat().st_size:,} bytes, binary {dst.stat().st_size:,} bytes "
      f"(header {HEADER.size} + {n:,} x {RECORD.size})")

with dst.open("rb") as f:
    magic, version, count = HEADER.unpack(f.read(HEADER.size))
    assert magic == MAGIC and version == VERSION and count == n
    probes = rng.sample(ids, 200) + [0, 10**9]        # 200 hits and 2 misses
    t = time.perf_counter()
    found = [find(f, count, p) for p in probes]
    tb = time.perf_counter() - t
print(f"binary search on file: 202 lookups in {tb * 1000:.1f} ms, {sum(r is not None for r in found)} found")
t = time.perf_counter()
csv_found = [find_in_csv(src, p) for p in probes[:20]]
tc = (time.perf_counter() - t) / 20 * 202
print(f"scanning the CSV: ~{tc * 1000:,.0f} ms for the same 202 lookups (estimated from 20)")
print("example:", found[0])

with dst.open("rb") as f:                              # round trip: binary -> JSON -> compare with CSV
    f.seek(HEADER.size)
    from_bin = [decode(f.read(RECORD.size)) for _ in range(count)]
from_json = json.loads(json.dumps(from_bin))
with src.open(newline="", encoding="utf-8") as f:
    from_csv = [{"id": int(r["id"]), "name": r["name"], "price": float(r["price"]), "stock": int(r["stock"])} for r in csv.DictReader(f)]
print("round trip CSV -> binary -> JSON preserves all rows:", from_json == from_csv)
src.unlink(); dst.unlink()
