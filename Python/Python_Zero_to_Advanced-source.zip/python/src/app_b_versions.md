# Appendix B — What Changed in Recent Python Versions

Features used in this book, by the version that introduced them. Code in this book needs Python 3.12 or later (PEP 695 type-parameter syntax in Chapter 8); it was run on 3.13.

| Version | Feature | Where in this book |
| --- | --- | --- |
| 3.6 | f-strings; `secrets` module | Units 1.2, 12.5 |
| 3.7 | dict insertion order guaranteed; `dataclasses`; `breakpoint()` | Units 2.3, 4.5, 10.4 |
| 3.8 | walrus operator `:=`; positional-only parameters `/`; `f"{x=}"`; `functools.cached_property` | Units 9.2, 1.6, 1.2, DT-30 |
| 3.9 | dict merge `|`; built-in generics `list[int]`; `zoneinfo`; `str.removeprefix` | Units 2.3, 8.2, 12.2 |
| 3.10 | structural pattern matching `match`; `X | Y` union types; `zip(strict=True)`; `int.bit_count` | Units 1.5, 8.2, 4.3 |
| 3.11 | `ExceptionGroup` and `except*`; `asyncio.TaskGroup` and `asyncio.timeout`; `add_note`; specialising adaptive interpreter; zero-cost `try`; atomic groups in `re` | Units 6.4, 11.4, 6.2, DT-1, 6.3, DT-28 |
| 3.12 | type-parameter syntax `def f[T]`, `class C[T]`; `itertools.batched`; `sum()` of floats uses compensated summation; f-string grammar relaxed | Units 8.2, 5.5, DT-4 |
| 3.13 | experimental free-threaded build (no GIL, PEP 703); experimental JIT; improved REPL and error messages (e.g. "consider renaming" for shadowed modules); `copy.replace` | DT-25, DT-5 |
| 3.14 | `return`/`break`/`continue` in `finally` warns (PEP 765); deferred evaluation of annotations (PEP 649) | DT-16, Chapter 8 |

## Habits that changed with these versions

- Use `list[int]`, `dict[str, int]`, and `X | None` instead of `typing.List`, `typing.Dict`, and `Optional` (3.9/3.10+).
- Use `TaskGroup` instead of bare `gather` + `create_task` when tasks must be cancelled together (3.11+).
- Prefer `zoneinfo` over third-party time-zone libraries for IANA zones (3.9+).
- Expect `dis` output and micro-benchmark results to change between versions (DT-1); re-measure after upgrading.
