---
title: "Python from Zero to Advanced"
subtitle: "How Python really works — from the interpreter and the data model to concurrency, performance, packaging, and a tested, typed, production-style application"
lang: en
---

# Preface

Python is easy to start and surprisingly deep. Many people write it for years on top of a mental model that is almost right: variables as boxes, `is` as a stricter `==`, threads as parallelism, type hints as checks, `eval` with empty builtins as a sandbox. Almost-right models produce bugs that are hard to see, because the code runs.

This book builds the accurate model from the ground up. It begins below the language — how CPython compiles source to bytecode, how names refer to objects, how memory is reclaimed — and climbs through the core language, the built-in data structures and their internals, functions and closures, classes and the data model, iterators and generators, errors and context managers, modules and packaging, type hints, files and formats, testing and profiling, concurrency, the standard library, performance with NumPy and compiled code, and metaprogramming. It ends with databases, web services, and a capstone: a small search engine with an asynchronous crawler, a SQLite index, a FastAPI service, and a command-line tool, checked by `mypy --strict` and a pytest suite.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the Python Language Reference, the library documentation, a PEP, CPython's implementation, or a library's documented behaviour.
2. **Evidence.** Every program shown with output was run with CPython 3.13, and the output is real — including tracebacks, type-checker errors, and timings. Several examples were wrong in their first draft; where that taught something (a file that shadowed a standard module, a connection used across threads by a web framework, an upsert that orphaned rows), the book shows what happened.
3. **Order.** Nothing is used before it is taught; later chapters refer back by unit number.

# How to use this book

## Who it is for

- **Beginners:** start at Chapter 0 and read in order. Type every program; run it; change it.
- **Programmers from other languages:** read Chapters 0–2 quickly but carefully — names and objects (Unit 0.3), integer division (DT-3), and containers (Chapter 2) differ from most languages — then continue in order.
- **Working Python developers:** skim the summaries and read every *Deep & Tricky* entry; Chapters 5, 8, 10, 11, 13, and 14 usually contain the most new material.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | Small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, labelled with their source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a realistic program with complete code, real output, and a review checklist.

## Running the code

The source archive has one directory per chapter. Programs run with `python3 file.py` from their chapter directory; the console blocks show the exact commands. You need Python 3.12 or later (3.13 was used). Third-party packages used: `pytest`, `hypothesis`, `mypy`, `numpy`, `cython`, `pydantic`, `fastapi`, `uvicorn`, and `httpx` — Chapters 7 and 16 show how to install them into a virtual environment with `uv` or `pip`. Chapter 13 also needs a C compiler.
