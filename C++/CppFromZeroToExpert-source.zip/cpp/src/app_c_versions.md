# Appendix C — C++ standards and compiler support

C++ is defined by ISO/IEC 14882, revised every three years. Each revision is almost entirely backwards compatible; select one with `-std=`. The `gnu++` variants (`-std=gnu++20`) add GCC extensions; this book uses the strict modes so that non-standard code is reported.

| Standard | Year | Features used or discussed in this book |
| --- | --- | --- |
| C++98/03 | 1998/2003 | classes, inheritance, virtual functions, templates, exceptions, namespaces, the STL (containers, iterators, algorithms), `std::string`, iostreams, RTTI and the named casts |
| C++11 | 2011 | move semantics and rvalue references; `auto` and `decltype`; lambdas; range-`for`; `nullptr`; `enum class`; `constexpr`; `noexcept`; `override`/`final`; `= default`/`= delete`; uniform initialisation and `initializer_list`; variadic templates; `static_assert`; `unique_ptr`, `shared_ptr`, `weak_ptr`; `unordered_*` containers; `std::array`; `std::thread`, `mutex`, `condition_variable`, `atomic`, `future`; the memory model; `<chrono>`, `<random>`, `<regex>`; user-defined literals |
| C++14 | 2014 | generic lambdas; return type deduction; `make_unique`; relaxed `constexpr`; variable templates; digit separators and binary literals; heterogeneous lookup in ordered containers (`std::less<>`); `shared_timed_mutex` |
| C++17 | 2017 | structured bindings; `if constexpr`; `if`/`switch` with initialisers; guaranteed copy elision; class template argument deduction (CTAD); fold expressions; inline variables; `std::optional`, `std::variant`, `std::any`, `std::string_view`; `<filesystem>`; parallel algorithms (execution policies); `<memory_resource>` (`pmr`); `[[nodiscard]]`, `[[maybe_unused]]`, `[[fallthrough]]`; `std::scoped_lock`; `try_emplace`; `std::from_chars`/`to_chars` |
| C++20 | 2020 | **the baseline of this book.** Concepts and `requires`; ranges and views; coroutines; modules; three-way comparison `<=>` and defaulted `==`; `consteval`, `constinit`; designated initialisers; templated lambdas; `std::format`; `std::span`; `std::jthread` and stop tokens; `latch`, `barrier`, `counting_semaphore`; `std::atomic_ref` and `atomic::wait`; `[[likely]]`/`[[unlikely]]`; `std::erase_if`; `contains` on associative containers; heterogeneous lookup for unordered containers; `std::bit_cast`; `std::source_location`; `using enum` |
| C++23 | 2024 | `std::expected`; `std::print`/`println`; `std::generator`; deducing `this`; `if consteval`; multidimensional `operator[]`; `std::mdspan`; `std::flat_map`/`flat_set`; formatting of ranges; `ranges::to`, `views::zip`, `enumerate`, `chunk`, `slide`, `stride`; `std::unreachable`; `std::to_underlying`; `import std;`; lifetime extension of temporaries in range-`for` (P2718) |
| C++26 | expected 2026 | contracts (P2900: `pre`, `post`, `contract_assert`); static reflection (P2996); `std::execution` (senders/receivers); `std::inplace_vector`; hardened standard library preconditions; erroneous behaviour for uninitialised reads |

## Compiler support used in this book

| Feature | GCC 13 | GCC 14 | Clang 18 (with libstdc++) |
| --- | --- | --- | --- |
| C++20 language (concepts, coroutines, `<=>`, `consteval`) | yes | yes | yes |
| C++20 named modules (`export module`) | partial (`-fmodules-ts`) | yes (`-fmodules-ts`; Unit 0.5) | yes (`.cppm` files; CMake 3.28+ automates the build order) |
| `std::format` | yes | yes | yes |
| `std::print`/`println` | no | yes | yes (`-std=c++23`) |
| `std::expected` | yes | yes | no: libstdc++'s `<expected>` needs C++20 concepts at a level Clang 19 first reports |
| `std::generator` | no | yes | no (Clang 19) |
| Formatting of ranges (`println("{}", v)`) | no | no (GCC 15) | no |
| `std::flat_map`, `std::mdspan` | no | no (GCC 15) | no |
| Deducing `this` | no | yes | yes (without the feature-test macro) |
| Range-`for` temporary lifetime extension (P2718) | no | no (GCC 15) | no (Clang 19) |
| `import std;` | no | no (GCC 15) | no (Clang 19, with libc++) |

Microsoft Visual C++ (Visual Studio 2022, 17.10 and later) supports all the C++20 features in this book and most of C++23, including `import std;`. Apple Clang lags upstream Clang by roughly a year.

Every row above was checked with the compilers used for this book. Library support changes quickly: before relying on a newer feature, check the compiler-support tables on cppreference.com, and the "Status" pages of libstdc++ and libc++.

## Feature-test macros

Every library and language feature since C++20 has a **feature-test macro** in `<version>` (`__cpp_lib_expected`, `__cpp_lib_generator`, `__cpp_concepts`, …). Code that must build on several compilers can test them instead of compiler versions:

```text
#include <version>
#if defined(__cpp_lib_print) && __cpp_lib_print >= 202207L
    std::println("hello");
#else
    std::cout << "hello\n";
#endif
```
