# Appendix A — Index of Deep & Tricky entries and Patterns

Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, with the unit where it is explained. Use it for revision: read each title and explain the entry before looking it up.

## Deep & Tricky

| # | Entry | Where |
| --- | --- | --- |
| DT-1 | "C++ is a superset of C" is false. | Unit 0.1 |
| DT-2 | Two different definitions of the same inline function or class across TUs: undefined behaviour, usually silent. | Unit 0.3 |
| DT-3 | An exception must not propagate out of a function called from C code: C frames have no unwind information to run destructors with, so the result ranges from `std::terminate` to skipped cleanup — and the C++ standard leaves crossing language boundaries entirely to the implementation. | Unit 0.4 |
| DT-4 | `auto x{1, 2};` is an error, but `auto x = {1, 2};` is an `std::initializer_list<int>`. | Unit 1.1 |
| DT-5 | Lifetime extension applies only to a reference bound *directly* to a temporary. | Unit 1.2 |
| DT-6 | The *static initialisation order fiasco*: global objects in different translation units are initialised in an unspecified order, so a global whose constructor uses another file's global may see it before it has been constructed. `constinit` turns the bug into a compile error by insisting that the initialiser is a constant expression — run before any dynamic initialisation at all. | Unit 1.3 |
| DT-7 | A lambda that captures by reference must not outlive what it captured. | Unit 1.5 |
| DT-8 | `std::string_view` is not null-terminated. | Unit 1.6 |
| DT-9 | `"abc" + 1` and `'a' + "bc"` compile — as pointer arithmetic, not string concatenation — because string literals are arrays of `char`, not `std::string`s. `std::string s = 'a' + "bc";` adds 97 to the address of `"bc"` and reads far past it. | Unit 1.6 |
| DT-10 | `auto [a, b] = expr;` does not bind `a` and `b` to the members of `expr`: it makes one hidden *copy* of the whole object and binds the names to that copy's members. Modifying `a` changes nothing outside; to modify the original, write `auto& [a, b]`, and to avoid the copy while only reading, `const auto& [a, b]`. | Unit 1.7 |
| DT-11 | A constructor with one parameter (and no `explicit`) is an implicit conversion: `void send(Packet p); send(42);` silently builds a `Packet` from 42. Mark single-argument constructors `explicit` unless the conversion is genuinely meant to be invisible (like `std::string` from `const char*`). | Unit 2.2 |
| DT-12 | A destructor must not throw. | Unit 2.3 |
| DT-13 | Declaring a destructor silently disables move operations. | Unit 2.6 |
| DT-14 | A move constructor that is not `noexcept` makes `std::vector` copy instead of move. | Unit 3.2 |
| DT-15 | A moved-from standard library object is in a "valid but unspecified state": you may assign to it, destroy it, or call functions without preconditions (`size()`, `clear()`, `empty()`), but you must not assume it is empty. A moved-from `std::string` holding a short string usually still contains its characters. | Unit 3.2 |
| DT-16 | "Pass by value and move" (`void set(std::string s) { name_ = std::move(s); }`) costs one extra move compared with two overloads (`const std::string&` and `std::string&&`), and it allocates on every call where the overloads would reuse the existing buffer. For constructors it is the right default; for a setter called in a loop on a long-lived object, the `const&` overload can be much cheaper. | Unit 3.5 |
| DT-17 | `std::vector<bool>` is not a container of `bool`s: it packs bits, so `v[i]` returns a proxy object, not a `bool&`. `auto x = v[0];` gives a proxy that still refers into the vector, `bool* p = &v[0];` does not compile, and two threads writing different elements race on the same byte. | Unit 4.1 |
| DT-18 | `map[key]` on a missing key inserts it. | Unit 4.2 |
| DT-19 | References and pointers to `unordered_map` elements survive rehashing; iterators do not. | Unit 4.2 |
| DT-20 | An invalid comparator can make `std::sort` crash, not just mis-sort. | Unit 4.4 |
| DT-21 | Some views cache their `begin()` (for example `filter_view`, so that repeated iteration stays cheap). Iterating a cached view, then modifying the underlying container, then iterating the view again gives results based on the stale cached position — and a view that caches is not usable through a `const&`. | Unit 4.5 |
| DT-22 | Checking and then acting on a file is a race: between `fs::exists(p)` and `std::ofstream(p)`, another process can create, delete, or replace `p` (a *time-of-check to time-of-use* bug, TOCTOU). Do the operation and handle its failure instead of checking first; for "create only if absent", `std::fstream` has no exclusive mode before C++23's `std::ios::noreplace`, so use POSIX `open(O_CREAT ¦ O_EXCL)` or C11 `fopen(p, "wx")`. | Unit 4.7 |
| DT-23 | `std::regex` in libstdc++ uses a recursive backtracking matcher: a long input against a pattern with nested repetition can take exponential time or overflow the stack and crash. It is also several times slower than RE2, PCRE2, or a hand-written parser even on simple patterns. | Unit 4.8 |
| DT-24 | Two `shared_ptr`s created separately from the same raw pointer will both delete it. | Unit 5.3 |
| DT-25 | `shared_ptr`'s reference count is thread-safe; the object it points to is not, and neither is one `shared_ptr` *variable* shared between threads. Two threads copying *their own* `shared_ptr`s to the same object is fine; one thread assigning to a `shared_ptr` while another reads that same variable is a data race. | Unit 5.3 |
| DT-26 | Passing `shared_ptr` by value in hot code costs two atomic operations per call. | Unit 5.5 |
| DT-27 | An exception thrown while a constructor is running means the object never existed: its destructor does *not* run. Members and base classes that were already fully constructed *are* destroyed — so a class that owns two raw resources and acquires them in its constructor body leaks the first if the second throws. | Unit 6.2 |
| DT-28 | `noexcept` is not checked at compile time. | Unit 6.3 |
| DT-29 | Dereferencing an `expected` or `optional` that holds no value is undefined behaviour. | Unit 6.5 |
| DT-30 | Template argument deduction never considers implicit conversions: `std::max(1, 2.0)` does not compile, because `T` would have to be both `int` and `double`. And `T` deduced from an array argument passed by value decays to a pointer, while `T&` keeps the array type and its size. | Unit 7.2 |
| DT-31 | Function templates cannot be partially specialised, and a full specialisation does not take part in overload resolution: the compiler first picks the best *primary template* among the overloads, and only then looks at that template's specialisations. A specialisation can therefore be skipped for a call that seems to match it exactly. | Unit 7.5 |
| DT-32 | Template errors are reported deep inside the instantiation. | Unit 7.6 |
| DT-33 | Overloads constrained by unrelated concepts are ambiguous; subsumption only works through named concepts. | Unit 8.1 |
| DT-34 | Undefined behaviour in a constant expression is a compile error. | Unit 8.4 |
| DT-35 | Without `override`, a typo creates a new function instead of overriding. | Unit 9.2 |
| DT-36 | Deleting a derived object through a base pointer without a virtual destructor is undefined behaviour. | Unit 9.2 |
| DT-37 | A derived class function with the same *name* as a base class function hides *every* base overload of that name, even ones with different parameters: `d.f(1)` stops finding `Base::f(int)` once `Derived` declares `f(std::string)`. Bring the base overloads back with `using Base::f;`. | Unit 9.3 |
| DT-38 | A C-style cast can silently become a `reinterpret_cast` or `const_cast`. | Unit 9.6 |
| DT-39 | `std::lock_guard(m_);` without a variable name locks and immediately unlocks. | Unit 10.2 |
| DT-40 | `std::atomic<T>` is not lock-free for every `T`. | Unit 10.4 |
| DT-41 | The `std::future` returned by `std::async(std::launch::async, ...)` blocks in its destructor until the task finishes. Ignoring the return value therefore runs the "asynchronous" tasks one after another: `std::async(std::launch::async, f); std::async(std::launch::async, g);` waits for `f` before starting `g`. | Unit 10.5 |
| DT-42 | A coroutine's reference parameters can dangle. | Unit 10.7 |
| DT-43 | A benchmark whose result is unused may measure nothing. | Unit 11.3 |
| DT-44 | Objects allocated from a `monotonic_buffer_resource` must not outlive it. | Unit 12.3 |
| DT-45 | `[[likely]]` and `[[unlikely]]` only change code layout, never correctness, and a wrong hint makes code slower. Profile-guided optimisation (`-fprofile-generate`, run, `-fprofile-use`) usually beats hand-written hints, because it uses measured branch frequencies for every branch, not just the ones you annotated. | Unit 12.5 |
| DT-46 | `std::string_view` parameters are safe; `std::string_view` return values and members are where dangling happens. | Unit 13.1 |
| DT-47 | The range-for over a temporary's member dangles (before C++23). | Unit 13.2 |
| DT-48 | A class that stores iterators or pointers into its own members must not use the default copy and move. | Unit 14.2 |
| DT-49 | Erasing the element a reference points to, then using the reference, is the most common bug in code like this. | Unit 14.3 |

## Patterns

| # | Pattern | Where |
| --- | --- | --- |
| P-1 | Every resource is owned by exactly one RAII object. | Unit 2.3 |
| P-2 | Return by value; take sinks by value and move; read through `const&`. | Unit 3.5 |
| P-3 | Make ownership visible in types; observe with references. | Unit 5.5 |
| P-4 | Prepare on the side, commit with no-throw operations. | Unit 6.2 |
| P-5 | Choose the polymorphism mechanism by how the set of types changes. | Unit 9.5 |
| P-6 | Make every quality check a command that CI runs, not a habit people must remember. | Unit 11.5 |
| P-7 | Optimise in this order: algorithm, allocations, layout, then code generation — measuring each step. | Unit 12.5 |
| P-8 | Run every test suite in three build configurations: warnings-as-errors release, ASan+UBSan, and TSan for concurrent code. | Unit 13.4 |
| P-9 | Test a fast implementation against a slow, obviously correct one. | Unit 14.6 |
