---
title: "C++ from Zero to Expert"
subtitle: "A complete course in modern C++ (C++20 and C++23) — from the compilation model to a tested, measured order-matching engine"
lang: en
---

# Preface

C++ is the language of performance-critical software: browsers, game engines, databases, compilers, trading systems, robotics, machine-learning runtimes, and much of the operating system's user space. It gives you the machine-level control of C, plus abstractions — classes, templates, RAII, the standard library — that cost nothing at run time when used well.

C++ is also large, and much of what is written about it is out of date. This book teaches **modern C++**: C++20 as the baseline, with C++23 features where today's compilers support them. It treats the language the way experienced engineers do: value semantics and RAII by default; ownership expressed in types; the standard library before hand-written code; templates constrained with concepts; and every claim about correctness or speed checked with tools — warnings, sanitizers, debuggers, static analysis, fuzzers, benchmarks, and profilers.

The book begins with what a C++ compiler and linker actually do, then covers the core language, classes and RAII, move semantics, the standard library, smart pointers, error handling, templates and concepts, polymorphism, concurrency and coroutines, build and test tooling, performance engineering, and undefined behaviour and safety. It ends with a capstone: a limit order book and matching engine, verified against a reference model and measured to nanosecond percentiles.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the C++ standard, the standard library's specification, a particular implementation, the compiler, or established practice.
2. **Evidence.** Every program in this book was compiled and run, and every output shown is real — including compiler errors, warnings, sanitizer reports, and benchmark numbers. When the first version of an example was wrong, or an optimisation did not pay off (several did not), the book shows that too, because that is how real C++ development goes.
3. **Order.** Nothing is used before it is taught, and later chapters refer back by unit number.

This book is a companion to *C from Zero to Systems*. You do not need to read the C book first — Chapter 0 and Chapter 1 cover what you need — but where a topic is the same in both languages (the machine model, the ABI, POSIX, caches, fuzzing), this book gives the C++ view and refers to the C book for depth.

# How to use this book

## Who it is for

- **Beginners** who are willing to work carefully: start at Chapter 0 and read in order. No previous programming is assumed, though it helps.
- **C programmers:** read Chapters 0–1 quickly, then slow down at Chapter 2: RAII, value semantics, and move semantics (Chapters 2–3) are where C++ thinking differs most from C.
- **Programmers who learned "C++98 with classes":** start at Chapter 3 and do every *Deep & Tricky* entry; Chapters 3, 5, 8, and 13 cover what has changed most.
- **Working C++ programmers:** use Appendix A to test yourself, then focus on Chapters 8, 10, 12, and 13.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | The rules, with small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, each labelled with its source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Explain*, *Predict* (decide the output before running), *Write* (code it). Answers to prediction questions are at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a specification, a complete reference solution with real output, and a review checklist. Try the project yourself first.

## How to study

1. **Type the programs and run them,** with the flags shown. Compare your output with the book's.
2. **Predict before you run.** When you are wrong, find out why before moving on.
3. **Read compiler errors fully.** Template errors are long but structured; Chapters 7 and 8 show how to read them, and concepts make them short.
4. **Break things on purpose.** Remove a `std::move`, return a reference to a local, share data between threads without a lock — and watch which tool catches it.
5. **Use the tools from day one:** `-Wall -Wextra`, `-fsanitize=address,undefined`, and a debugger. Chapter 0 shows how; Chapters 11 and 13 explain them fully.
6. **Revise with Appendix A,** which lists every DT and P entry by title.

## How to read the labels

| Label | Meaning |
| --- | --- |
| *Guarantee: C++ standard* (and variants naming a rule, e.g. *special member generation rules*) | Required by ISO C++. True on every conforming implementation. |
| *Guarantee: UB* (… *on dangling reference*, *double delete*, …) | The standard says the behaviour is undefined: no requirements at all. |
| *ODR violation, no diagnostic required* | The program is ill-formed, but the implementation need not tell you. |
| *Library guarantee*, *Library behaviour*, *Library precondition* | Specified by the standard library's specification, or how libstdc++ behaves where the standard leaves freedom. |
| *Compiler behaviour*, *Optimiser behaviour*, *Implementation behaviour* | What GCC, Clang, or the library implementation do. Stable in practice; may change between versions. |
| *Language rules*, *Standard, [section]* | A rule of the language, with the section of the standard where it is specified. |
| *Practice*, *Core Guidelines* | Professional practice, or a rule from the C++ Core Guidelines — experience, not language rules. |

## Toolchain and versions

All code was compiled and run on **Linux x86-64 (Ubuntu 24.04)** with:

- **GCC 14.2** (`g++-14`, the default compiler in this book) and **GCC 13.3**,
- **Clang 18** (`clang++`: sanitizers including ThreadSanitizer, libFuzzer, `clang-tidy`, `clang-format`),
- **libstdc++** from GCC 14, **CMake 3.28**, **GoogleTest 1.14**, **Google Benchmark 1.8**, **GDB 15**, **Valgrind 3.22**, **perf** (Linux 6.8 tools), **oneTBB** (for parallel algorithms).

The language baseline is **C++20** (`-std=c++20`). **C++23** features are marked and compiled with `-std=c++23`. Some C++23 library features are not yet complete in GCC 14's libstdc++ — notably formatting of ranges (`std::println("{}", vec)`) — and the text says so where it matters. Appendix C lists which standard introduced each feature and what each compiler supports.

Measurements (Chapters 6, 10, 11, 12, 14) were taken on a 2-core virtual machine. Your numbers will differ; compare the ratios and the shapes, and expect some run-to-run variation, which the text reports where it is large. Hardware performance counters were not available in the virtual machine, so profiles use software clock sampling.

## Setting up

1. Install a compiler and tools. On Debian/Ubuntu 24.04: `sudo apt install g++-14 clang clang-tidy clang-format gdb valgrind cmake libgtest-dev libbenchmark-dev libtbb-dev`. On Fedora: `sudo dnf install gcc-c++ clang clang-tools-extra gdb valgrind cmake gtest-devel google-benchmark-devel tbb-devel`. On macOS: install Xcode command-line tools for Apple Clang, or `brew install llvm gcc cmake` for current compilers. On Windows: Visual Studio 2022 supports nearly everything here; use WSL2 for the POSIX, sanitizer, and `perf` sections.
2. Check: `g++-14 --version`, `clang++ --version`, `cmake --version`.
3. Use an editor with **clangd** (VS Code, CLion, Neovim, Emacs, Zed). CMake's `compile_commands.json` (Chapter 11) makes it understand your project.
4. Create a working folder with one subfolder per chapter, and keep a journal of the predictions you got wrong.

# Roadmap

| Chapter | Title | You will be able to… |
| --- | --- | --- |
| 0 | The C++ Toolchain and Compilation Model | follow C++ through compiling and linking; explain the ODR, name mangling, `extern "C"`, and modules |
| 1 | Core Language | use types, initialisation, references, `const`/`constexpr`, functions, lambdas, strings, and formatted output |
| 2 | Classes and RAII | design classes with invariants, constructors, destructors, copying, and operators; tie resources to lifetimes |
| 3 | Value Semantics and Move Semantics | explain value categories; write moves; use perfect forwarding; pass and return values efficiently |
| 4 | The Standard Library | choose containers; use iterators, algorithms, ranges, and views; know the invalidation rules |
| 5 | Smart Pointers and Ownership | express ownership with `unique_ptr`, `shared_ptr`, `weak_ptr`, and scope guards |
| 6 | Error Handling | use exceptions with the safety guarantees, `noexcept`, and `std::expected`; know what each costs |
| 7 | Templates I | write function and class templates; understand deduction, CTAD, specialisation, and instantiation |
| 8 | Templates II | constrain templates with concepts; write variadic templates and compile-time code |
| 9 | Polymorphism | use inheritance and virtual dispatch correctly; use `std::variant`, CRTP, and type erasure |
| 10 | Concurrency | use threads, locks, condition variables, atomics, the memory model, tasks, parallel algorithms, and coroutines |
| 11 | Building, Testing, and Tooling | build with modern CMake; test with GoogleTest; benchmark; lint; run sanitizers in CI |
| 12 | Performance Engineering | remove hidden allocations and copies; use `pmr`; design cache-friendly data; optimise by measurement |
| 13 | Undefined Behaviour and Safe C++ | prevent dangling and invalidation bugs; use hardened libraries, sanitizers, and fuzzing |
| 14 | Capstone: An Order-Matching Engine | design, build, verify, and measure a performance-critical C++ system |
| A | Index of Deep & Tricky entries and Patterns | revise every entry by title |
| B | Glossary | look up any term |
| C | C++ standards and compiler support | see which standard introduced each feature, and what compilers support |

Chapters 0–6 are the **foundation**; read them in order. Chapters 7 and 8 belong together. After that, Chapters 9–13 can be read in any order (Chapter 12 uses Chapter 11's benchmarking, and Chapter 13 uses Chapter 11's sanitizers). Chapter 14 uses the whole book.
