# Appendix B — Glossary

Short definitions of the terms used in this book. The unit given (where there is one) explains the term fully.

| Term | Meaning |
| --- | --- |
| ABI (application binary interface) | The binary-level contract between compiled pieces of code: calling convention, object layout, name mangling, vtable layout (Unit 0.4) |
| Abstract class | A class with at least one pure virtual function; cannot be instantiated (Unit 9.2) |
| ADL (argument-dependent lookup) | Lookup of an unqualified function name in the namespaces of its arguments' types; how `swap` and operators are found |
| Aggregate | A class or array with no user-declared constructors, no private members, and no virtual functions; initialised member by member with braces |
| Allocator | An object that supplies memory to a container; `std::pmr` makes it a run-time choice (Unit 12.3) |
| Arena (monotonic buffer) | An allocator that hands out memory by bumping a pointer and frees everything at once (Unit 12.3) |
| Atomic | An object whose operations are indivisible and free of data races (Unit 10.4) |
| `auto` | Lets the compiler deduce a variable's or return type from its initialiser (Unit 1.1) |
| Benchmark | A program that measures performance under controlled conditions; Google Benchmark automates repetition and statistics (Unit 11.3) |
| CMake | The de-facto build system generator for C++; describes targets and their usage requirements (Unit 11.1) |
| Coroutine | A function that can suspend and resume (`co_await`, `co_yield`, `co_return`) (Unit 10.7) |
| Concept | A named compile-time predicate on template arguments, used to constrain templates (Unit 8.1) |
| `const` correctness | Marking everything that should not change as `const`, so the compiler enforces it (Unit 1.3) |
| `constexpr` / `consteval` / `constinit` | May run at compile time / must run at compile time / must be initialised at compile time (Unit 1.3) |
| Copy elision | Constructing a returned or temporary object directly in its final place; guaranteed for prvalues since C++17 (Unit 3.4) |
| CRTP | Curiously recurring template pattern: a base class template parameterised by its derived class, for static polymorphism (Unit 9.5) |
| CTAD | Class template argument deduction: `std::vector v{1, 2}` deduces `vector<int>` (Unit 7.3) |
| Dangling reference | A reference, pointer, iterator, or view whose object has been destroyed; using it is UB (Unit 13.1) |
| Data race | Two threads accessing the same memory without synchronisation, at least one writing; UB (Unit 10.2) |
| Data-oriented design | Organising data by how it is accessed (e.g. struct of arrays) for cache efficiency (Unit 12.4) |
| Deduction | The process by which the compiler works out template arguments from function arguments (Unit 7.2) |
| Destructor | A member function that runs automatically when an object's lifetime ends; the basis of RAII (Unit 2.3) |
| Devirtualisation | The compiler replacing a virtual call with a direct call when it can prove the dynamic type (Unit 12.5) |
| Differential testing | Testing an implementation against a simpler reference implementation on random inputs (Unit 14.4) |
| Dynamic dispatch | Choosing which function to call at run time from the object's dynamic type, via the vtable (Unit 9.2) |
| Exception safety guarantees | No-throw, strong (commit or roll back), basic (valid but unspecified state) (Unit 6.2) |
| `explicit` | Prevents a constructor or conversion operator from being used for implicit conversions (Unit 2.2) |
| `std::expected` | A value or an error, returned instead of throwing (C++23) (Unit 6.5) |
| Fold expression | Applies a binary operator across a parameter pack: `(args + ...)` (Unit 8.2) |
| Forwarding reference | A `T&&` parameter where `T` is deduced; binds to anything and preserves value category (Unit 3.3) |
| Fuzzing | Feeding generated inputs to code to find crashes and property violations (Unit 13.6) |
| Hardening (library) | Precondition checks in the standard library, e.g. `_GLIBCXX_ASSERTIONS` (Unit 13.3) |
| Heterogeneous lookup | Looking up a container by a type other than its key type without converting (Unit 12.2) |
| Header-only library | A library whose code is entirely in headers (often templates), needing no separate compilation (Chapter 11 project) |
| Inlining | Replacing a call with the body of the called function; the optimisation that enables most others (Unit 12.5) |
| Instantiation | Generating concrete code from a template for particular arguments (Unit 7.6) |
| Invariant | A condition a class guarantees is always true between member-function calls (Unit 2.1) |
| Iterator | An object that refers to a position in a sequence; the glue between containers and algorithms (Unit 4.3) |
| Iterator invalidation | An iterator, reference, or pointer becoming unusable after a container operation (Units 4.3, 13.2) |
| `std::jthread` | A thread that joins automatically in its destructor and supports cooperative cancellation (Unit 10.1) |
| Lambda | An anonymous function object, optionally capturing variables (Unit 1.5) |
| Lifetime extension | Binding a temporary directly to a `const&` or `&&` reference extends its life to the reference's (Unit 13.1) |
| Linker | Combines object files and libraries into an executable, resolving symbols (Unit 0.3) |
| lvalue / rvalue / prvalue / xvalue | Value categories: has identity / can be moved from; prvalues are pure temporaries, xvalues are expiring objects (Unit 3.1) |
| Mangling | Encoding namespaces, classes, and parameter types into symbol names (Unit 0.4) |
| Memory order | The ordering constraints on atomic operations: `relaxed`, `acquire`, `release`, `seq_cst` (Unit 10.4) |
| Module | A C++20 unit of code compiled once and imported, replacing textual inclusion (Unit 0.5) |
| Move semantics | Transferring a resource from an object that is about to die instead of copying it (Unit 3.2) |
| `noexcept` | Declares that a function does not throw; enables optimisations such as moving in `vector` growth (Unit 6.3) |
| Non-type template parameter | A template parameter that is a value rather than a type: `std::array<int, 4>` (Unit 7.4) |
| ODR (One Definition Rule) | Every entity has exactly one definition in the program (inline ones: identical in every translation unit) (Unit 0.3) |
| Order book | The set of resting buy and sell orders in a market, organised by price (Unit 14.1) |
| Overload resolution | The rules that choose among functions with the same name (Unit 1.5) |
| `override` / `final` | Ask the compiler to check that a function overrides a virtual / forbid further overriding or derivation (Unit 9.2) |
| Parameter pack | A template parameter that accepts any number of arguments: `typename... Ts` (Unit 8.2) |
| Perfect forwarding | Passing arguments on with their value category preserved, using `std::forward` (Unit 3.3) |
| PMR | Polymorphic memory resources (`<memory_resource>`): allocators chosen at run time (Unit 12.3) |
| Polymorphism | One interface, many implementations: dynamic (virtual), static (templates, CRTP), or closed (`std::variant`) (Chapter 9) |
| Price-time priority | The matching rule: best price first, then earliest arrival (Unit 14.1) |
| RAII | Resource acquisition is initialisation: a resource's lifetime is tied to an object's (Unit 2.3) |
| Ranges and views | C++20 algorithms over whole ranges, and lazy, composable adaptors such as `views::filter` (Unit 4.5) |
| Reference | An alias for an existing object; cannot be null or reseated (Unit 1.2) |
| Rule of Zero / Three / Five | Define none of the special members, or all of the copy ones, or all five including the moves (Units 2.4, 3.2) |
| Sanitizer | Compiler instrumentation that detects bugs at run time: ASan, UBSan, TSan (Units 11.5, 13.4) |
| `shared_ptr` / `weak_ptr` | Shared ownership by reference counting / a non-owning observer of a shared object (Units 5.3, 5.4) |
| SFINAE | Substitution failure is not an error: removing overloads whose template substitution fails; largely replaced by concepts (Unit 8.5) |
| Slicing | Copying a derived object into a base object, losing the derived part (Unit 9.3) |
| Small-buffer / small-string optimisation | Storing small contents inside the object to avoid heap allocation (Unit 12.1) |
| Special member functions | Default constructor, destructor, copy and move constructors, copy and move assignment (Unit 2.6) |
| Specialisation | A custom version of a template for particular arguments, full or partial (Unit 7.5) |
| `std::span` | A non-owning view of a contiguous sequence (Unit 4.6) |
| Stack unwinding | Destroying local objects in reverse order as an exception propagates (Unit 6.1) |
| `std::string_view` | A non-owning view of a sequence of characters (Units 1.6, 13.1) |
| Structured bindings | `auto [a, b] = pair;` — naming the parts of an aggregate, pair, or tuple (Unit 1.7) |
| Template | A pattern from which the compiler generates functions or classes for given types or values (Chapter 7) |
| Translation unit | A source file after preprocessing; the unit of compilation (Unit 0.3) |
| Type erasure | Hiding different concrete types behind one non-template interface, as `std::function` does (Unit 9.5) |
| Type trait | A compile-time query or transformation of types, in `<type_traits>` (Unit 7.7) |
| Undefined behaviour (UB) | Behaviour for which the standard imposes no requirements (Chapter 13) |
| `unique_ptr` | Exclusive ownership of a heap object, freed automatically; zero overhead (Unit 5.2) |
| `std::variant` | A type-safe union holding one of a fixed set of types; used with `std::visit` (Unit 9.4) |
| Virtual function / vtable | A function dispatched on the dynamic type; implemented with a per-class table of function pointers (Unit 9.2) |
| Zero-overhead principle | What you don't use, you don't pay for; what you do use, you couldn't hand-code any better (Unit 0.1) |
