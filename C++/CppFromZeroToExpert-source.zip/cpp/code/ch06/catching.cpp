// file: catching.cpp
#include <exception>
#include <iostream>
#include <stdexcept>

struct ParseError : std::runtime_error {
    int line;
    ParseError(const std::string& m, int l) : std::runtime_error(m), line(l) {}
};

void parse() { throw ParseError("unexpected '}'", 42); }

void layer_bad() {
    try { parse(); }
    catch (std::exception& e) { throw e; }        // throws a copy of type std::exception: sliced
}
void layer_good() {
    try { parse(); }
    catch (std::exception&) { throw; }            // rethrows the original ParseError
}

int main() {
    for (auto f : {layer_bad, layer_good}) {
        try { f(); }
        catch (const ParseError& e) { std::cout << "ParseError at line " << e.line << ": " << e.what() << '\n'; }
        catch (const std::exception& e) { std::cout << "only std::exception left: " << e.what() << '\n'; }
    }
    std::exception_ptr saved;
    try { parse(); } catch (...) { saved = std::current_exception(); }
    try { if (saved) std::rethrow_exception(saved); }
    catch (const ParseError& e) { std::cout << "rethrown later, still a ParseError (line " << e.line << ")\n"; }
}
