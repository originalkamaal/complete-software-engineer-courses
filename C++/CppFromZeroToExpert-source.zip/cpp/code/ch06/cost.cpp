// file: cost.cpp
#include <chrono>
#include <expected>
#include <iostream>
#include <stdexcept>
#include <string>

[[gnu::noinline]] int with_exception(int x) {
    if (x % 100 == 0) throw std::runtime_error("bad");
    return x;
}

[[gnu::noinline]] std::expected<int, int> with_expected(int x) {
    if (x % 100 == 0) return std::unexpected(-1);
    return x;
}

int main() {
    using clock = std::chrono::steady_clock;
    const int n = 1'000'000;
    for (int fail_every : {0, 100, 1}) {
        long long sum = 0;
        auto t0 = clock::now();
        for (int i = 1; i <= n; ++i) {
            int x = fail_every == 0 ? 1 : (fail_every == 1 ? i * 100 : i);
            try { sum += with_exception(x); } catch (const std::exception&) { --sum; }
        }
        auto t1 = clock::now();
        for (int i = 1; i <= n; ++i) {
            int x = fail_every == 0 ? 1 : (fail_every == 1 ? i * 100 : i);
            auto r = with_expected(x);
            sum += r ? *r : -1;
        }
        auto t2 = clock::now();
        auto ns = [&](auto a, auto b) { return std::chrono::duration<double, std::nano>(b - a).count() / n; };
        const char* label = fail_every == 0 ? "never fails " : fail_every == 100 ? "fails 1%    " : "always fails";
        std::cout << label << ": exceptions " << ns(t0, t1) << " ns/call, expected " << ns(t1, t2)
                  << " ns/call (checksum " << sum << ")\n";
    }
}
