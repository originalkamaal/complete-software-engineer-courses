// file: noexceptop.cpp
#include <iostream>
#include <string>
#include <type_traits>
#include <vector>

struct Safe { Safe(Safe&&) noexcept = default; Safe() = default; };
struct Risky { Risky(Risky&&) {} Risky() = default; };
void may_throw();
void never_throws() noexcept;

int main() {
    std::cout << std::boolalpha
              << "noexcept(may_throw()): " << noexcept(may_throw()) << '\n'
              << "noexcept(never_throws()): " << noexcept(never_throws()) << '\n'
              << "noexcept(1 + 2): " << noexcept(1 + 2) << '\n'
              << "string move ctor nothrow: " << std::is_nothrow_move_constructible_v<std::string> << '\n'
              << "Safe nothrow: " << std::is_nothrow_move_constructible_v<Safe> << '\n'
              << "Risky nothrow: " << std::is_nothrow_move_constructible_v<Risky> << '\n'
              << "vector<int>::push_back noexcept: " << noexcept(std::declval<std::vector<int>&>().push_back(1)) << '\n';
    void (*p)() noexcept = never_throws;
    // void (*q)() noexcept = may_throw;     // error: cannot convert
    (void)p;
}
void may_throw() {}
void never_throws() noexcept {}
