// file: chain.cpp
#include <charconv>
#include <expected>
#include <iostream>
#include <string>
#include <string_view>

enum class Err { empty, not_a_number, out_of_range };
std::string_view name(Err e) {
    switch (e) { case Err::empty: return "empty"; case Err::not_a_number: return "not a number";
                 case Err::out_of_range: return "out of range"; }
    return "?";
}

std::expected<std::string_view, Err> nonempty(std::string_view s) {
    if (s.empty()) return std::unexpected(Err::empty);
    return s;
}
std::expected<int, Err> to_int(std::string_view s) {
    int v{};
    auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), v);
    if (ec != std::errc{} || p != s.data() + s.size()) return std::unexpected(Err::not_a_number);
    return v;
}
std::expected<int, Err> port(int v) {
    if (v < 1 || v > 65535) return std::unexpected(Err::out_of_range);
    return v;
}

int main() {
    for (std::string_view input : {"8080", "", "80a", "70000"}) {
        auto result = nonempty(input).and_then(to_int).and_then(port).transform([](int p) { return p + 1; });
        std::cout << '"' << input << "\" -> ";
        if (result) std::cout << "next port " << *result << '\n';
        else std::cout << "error: " << name(result.error()) << '\n';
    }
}
