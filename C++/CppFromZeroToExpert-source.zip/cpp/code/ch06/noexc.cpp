// file: noexc.cpp
#include <cstdio>
#include <vector>

int main() {
    std::vector<int> v(3);
    std::printf("v.at(1) = %d\n", v.at(1));
    std::printf("v.at(10) = %d\n", v.at(10));    // throws out_of_range normally; aborts with -fno-exceptions
}
