// file: expected.cpp
#include <charconv>
#include <expected>
#include <fstream>
#include <iostream>
#include <string>
#include <string_view>
#include <system_error>

enum class ParseError { empty, not_a_number, out_of_range };

std::string_view describe(ParseError e) {
    switch (e) {
    case ParseError::empty: return "empty input";
    case ParseError::not_a_number: return "not a number";
    case ParseError::out_of_range: return "out of range";
    }
    return "?";
}

std::expected<int, ParseError> parse_int(std::string_view s) {
    if (s.empty()) return std::unexpected(ParseError::empty);
    int v{};
    auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), v);
    if (ec == std::errc::result_out_of_range) return std::unexpected(ParseError::out_of_range);
    if (ec != std::errc{} || p != s.data() + s.size()) return std::unexpected(ParseError::not_a_number);
    return v;
}

std::expected<int, ParseError> check_percent(int v) {
    if (v < 0 || v > 100) return std::unexpected(ParseError::out_of_range);
    return v;
}

std::expected<std::string, std::error_code> read_file(const std::string& path) {
    std::ifstream in{path};
    if (!in) return std::unexpected(std::make_error_code(std::errc::no_such_file_or_directory));
    return std::string{std::istreambuf_iterator<char>{in}, {}};
}

int main() {
    for (std::string_view input : {"42", "", "4x2", "250", "99999999999"}) {
        auto result = parse_int(input)
                          .and_then(check_percent)                       // runs only on success
                          .transform([](int p) { return p / 100.0; });  // maps the value
        if (result)
            std::cout << '"' << input << "\" -> " << *result << '\n';
        else
            std::cout << '"' << input << "\" -> error: " << describe(result.error()) << '\n';
    }
    auto f = read_file("/no/such/file");
    std::cout << "read_file: " << (f ? "ok" : f.error().message()) << '\n';
}
