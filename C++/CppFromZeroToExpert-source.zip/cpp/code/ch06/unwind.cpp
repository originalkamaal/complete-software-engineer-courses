// file: unwind.cpp
#include <iostream>
#include <stdexcept>
#include <string>

struct Noisy {
    std::string name;
    explicit Noisy(std::string n) : name{std::move(n)} { std::cout << "  acquire " << name << '\n'; }
    ~Noisy() { std::cout << "  release " << name << '\n'; }
};

class ConfigError : public std::runtime_error {        // a domain-specific exception type
public:
    ConfigError(const std::string& key, const std::string& why)
        : std::runtime_error("config key '" + key + "': " + why), key_{key} {}
    const std::string& key() const { return key_; }
private:
    std::string key_;
};

int parse_port(const std::string& text) {
    Noisy guard{"parse buffer"};
    int port = std::stoi(text);                        // throws std::invalid_argument on "abc"
    if (port < 1 || port > 65535)
        throw ConfigError("port", "out of range: " + text);
    return port;
}

void load(const std::string& value) {
    Noisy file{"config file"};
    int port = parse_port(value);
    std::cout << "  port = " << port << '\n';
}

int main() {
    for (std::string v : {"8080", "99999", "abc"}) {
        std::cout << "load(\"" << v << "\"):\n";
        try {
            load(v);
        } catch (const ConfigError& e) {               // most specific first
            std::cout << "  ConfigError for key " << e.key() << ": " << e.what() << '\n';
        } catch (const std::exception& e) {            // anything standard
            std::cout << "  other error: " << e.what() << '\n';
        }
    }
}
