// file: calc/calc.hpp
#pragma once
#include <cmath>
#include <cstddef>
#include <expected>
#include <string>
#include <string_view>

struct CalcError {
    std::size_t pos;          // offset in the input where the error was detected
    std::string message;
};

class Parser {
public:
    explicit Parser(std::string_view text) : s_{text} {}

    std::expected<double, CalcError> parse() {
        auto v = expr();
        if (!v) return v;
        skip_ws();
        if (i_ != s_.size()) return fail("unexpected '" + std::string(1, s_[i_]) + "'");
        return v;
    }

private:
    std::expected<double, CalcError> fail(std::string msg) const { return std::unexpected(CalcError{i_, std::move(msg)}); }
    void skip_ws() { while (i_ < s_.size() && s_[i_] == ' ') ++i_; }
    bool eat(char c) { skip_ws(); if (i_ < s_.size() && s_[i_] == c) { ++i_; return true; } return false; }

    std::expected<double, CalcError> expr() {
        auto lhs = term();
        while (lhs) {
            if (eat('+')) { auto r = term(); if (!r) return r; *lhs += *r; }
            else if (eat('-')) { auto r = term(); if (!r) return r; *lhs -= *r; }
            else break;
        }
        return lhs;
    }

    std::expected<double, CalcError> term() {
        auto lhs = factor();
        while (lhs) {
            if (eat('*')) { auto r = factor(); if (!r) return r; *lhs *= *r; }
            else if (eat('/')) {
                skip_ws();
                std::size_t at = i_;                   // position of the divisor
                auto r = factor();
                if (!r) return r;
                if (*r == 0.0) return std::unexpected(CalcError{at, "division by zero"});
                *lhs /= *r;
            } else break;
        }
        return lhs;
    }

    std::expected<double, CalcError> factor() {
        auto base = unary();
        if (base && eat('^'))
            return factor().and_then([&](double e) -> std::expected<double, CalcError> {
                double r = std::pow(*base, e);
                if (!std::isfinite(r)) return fail("result too large");
                return r;
            });
        return base;
    }

    std::expected<double, CalcError> unary() {
        if (eat('-')) return unary().transform([](double v) { return -v; });
        return primary();
    }

    std::expected<double, CalcError> primary() {
        skip_ws();
        if (i_ == s_.size()) return fail("unexpected end of input");
        if (eat('(')) {
            auto v = expr();
            if (!v) return v;
            if (!eat(')')) return fail("expected ')'");
            return v;
        }
        std::size_t start = i_;
        while (i_ < s_.size() && (std::isdigit(static_cast<unsigned char>(s_[i_])) || s_[i_] == '.')) ++i_;
        if (start == i_) return fail("expected a number");
        try {
            std::size_t used = 0;
            double v = std::stod(std::string(s_.substr(start, i_ - start)), &used);
            if (used != i_ - start) { i_ = start + used; return fail("malformed number"); }
            return v;
        } catch (const std::exception&) {      // stod throws: convert at the boundary
            i_ = start;
            return fail("malformed number");
        }
    }

    std::string_view s_;
    std::size_t i_ = 0;
};
