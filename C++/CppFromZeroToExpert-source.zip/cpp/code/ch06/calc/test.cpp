// file: calc/test.cpp
#include <cassert>
#include <cmath>
#include <iostream>
#include <string>
#include "calc.hpp"

static int failures = 0;

void ok(const char* in, double want) {
    auto r = Parser{in}.parse();
    if (!r || std::fabs(*r - want) > 1e-9) {
        ++failures;
        std::cout << "FAIL: \"" << in << "\" expected " << want << '\n';
    }
}

void err(const char* in, std::size_t pos, const std::string& msg) {
    auto r = Parser{in}.parse();
    if (r || r.error().pos != pos || r.error().message != msg) {
        ++failures;
        std::cout << "FAIL: \"" << in << "\" expected error at " << pos << ": " << msg;
        if (!r) std::cout << " (got " << r.error().pos << ": " << r.error().message << ")";
        std::cout << '\n';
    }
}

int main() {
    ok("1 + 2 * 3", 7);
    ok("(1 + 2) * 3", 9);
    ok("2 ^ 3 ^ 2", 512);              // right-associative: 2^(3^2)
    ok("-2 ^ 2", 4);                   // unary minus binds tighter here: (-2)^2
    ok("10 / 4 - 0.5", 2);
    ok("--3", 3);
    ok("  42  ", 42);
    err("1 / 0", 4, "division by zero");
    err("1 / (2 - 2)", 4, "division by zero");
    err("2 *", 3, "unexpected end of input");
    err("(1 + 2", 6, "expected ')'");
    err("1 + 2)", 5, "unexpected ')'");
    err("3 $ 4", 2, "unexpected '$'");
    err("1.2.3", 3, "malformed number");
    err("10 ^ 1000", 9, "result too large");
    err("", 0, "unexpected end of input");

    for (std::string line : {"(2 + 3) * 4 ^ 0.5", "1 / (3 - 3)"}) {
        auto r = Parser{line}.parse();
        if (r) std::cout << line << " = " << *r << '\n';
        else std::cout << line << "\n" << std::string(r.error().pos, ' ') << "^ " << r.error().message << '\n';
    }
    std::cout << (failures == 0 ? "all calculator tests passed\n" : "SOME TESTS FAILED\n");
    return failures == 0 ? 0 : 1;
}
