// file: ctorthrow.cpp
#include <iostream>
#include <memory>
#include <stdexcept>

struct Resource {
    int id;
    explicit Resource(int i) : id(i) {
        if (i == 2) throw std::runtime_error("cannot acquire resource 2");
        std::cout << "  acquire " << id << '\n';
    }
    ~Resource() { std::cout << "  release " << id << '\n'; }
};

struct RawOwner {
    Resource* a; Resource* b;
    RawOwner() : a(new Resource(1)), b(new Resource(2)) {}   // b throws: a leaks
    ~RawOwner() { delete a; delete b; }                       // never runs
};
struct RaiiOwner {
    std::unique_ptr<Resource> a, b;
    RaiiOwner() : a(std::make_unique<Resource>(1)), b(std::make_unique<Resource>(2)) {}
};

int main() {
    std::cout << "raw pointers:\n";
    try { RawOwner r; } catch (const std::exception& e) { std::cout << "  caught: " << e.what() << '\n'; }
    std::cout << "unique_ptr members:\n";
    try { RaiiOwner r; } catch (const std::exception& e) { std::cout << "  caught: " << e.what() << '\n'; }
}
