// file: safety.cpp
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

class Inventory {
public:
    // Basic guarantee only: if the second push_back throws, the first change stays.
    void add_pair_basic(std::string a, std::string b) {
        items_.push_back(std::move(a));
        maybe_fail(b);
        items_.push_back(std::move(b));
    }
    // Strong guarantee: build the new state on the side, then commit with a no-throw swap.
    void add_pair_strong(std::string a, std::string b) {
        std::vector<std::string> next = items_;         // may throw: items_ untouched
        next.push_back(std::move(a));
        maybe_fail(b);
        next.push_back(std::move(b));
        items_.swap(next);                               // no-throw commit
    }
    std::size_t size() const { return items_.size(); }
private:
    static void maybe_fail(const std::string& s) {
        if (s == "bad") throw std::runtime_error("cannot add 'bad'");
    }
    std::vector<std::string> items_;
};

int main() {
    Inventory inv;
    inv.add_pair_strong("apple", "pear");
    try { inv.add_pair_basic("plum", "bad"); } catch (const std::exception& e) {
        std::cout << "basic: " << e.what() << ", size now " << inv.size() << " (half-applied)\n";
    }
    try { inv.add_pair_strong("fig", "bad"); } catch (const std::exception& e) {
        std::cout << "strong: " << e.what() << ", size now " << inv.size() << " (unchanged)\n";
    }
}
