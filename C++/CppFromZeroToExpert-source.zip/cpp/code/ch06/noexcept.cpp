// file: noexcept.cpp
#include <iostream>
#include <stdexcept>
#include <type_traits>
#include <vector>

void promise_broken() noexcept {
    throw std::runtime_error("escaped a noexcept function");   // GCC warns: will call terminate
}

template <typename T>
void swap_values(T& a, T& b) noexcept(std::is_nothrow_move_constructible_v<T> &&
                                      std::is_nothrow_move_assignable_v<T>) {   // conditional noexcept
    T tmp = std::move(a);
    a = std::move(b);
    b = std::move(tmp);
}

int main() {
    std::vector<int> a{1}, b{2};
    std::cout << std::boolalpha << "swap_values<vector> noexcept: " << noexcept(swap_values(a, b)) << '\n';
    std::cout << "vector move ctor noexcept: " << std::is_nothrow_move_constructible_v<std::vector<int>> << '\n';
    try {
        promise_broken();
    } catch (...) {
        std::cout << "never reached\n";
    }
}
