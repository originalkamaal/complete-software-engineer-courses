int main(){ try { throw 1; } catch (int) {} }
