// file: hetero.cpp
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

static long g_allocs = 0;
void* operator new(std::size_t n) { ++g_allocs; if (void* p = std::malloc(n)) return p; throw std::bad_alloc{}; }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

struct StringHash {                                        // transparent: hashes string, string_view, const char*
    using is_transparent = void;
    std::size_t operator()(std::string_view s) const noexcept { return std::hash<std::string_view>{}(s); }
};

int main() {
    std::unordered_map<std::string, int> plain;
    std::unordered_map<std::string, int, StringHash, std::equal_to<>> transparent;
    std::vector<std::string> keys;
    for (int i = 0; i < 1000; ++i) {
        keys.push_back("a fairly long key that does not fit in SSO #" + std::to_string(i));
        plain[keys.back()] = i;
        transparent[keys.back()] = i;
    }
    std::vector<std::string_view> views(keys.begin(), keys.end());   // lookups arrive as views (e.g. parsed input)

    long sum = 0;
    long a0 = g_allocs;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 200; ++r)
        for (auto v : views) sum += plain.find(std::string(v))->second;     // must build a std::string
    auto t1 = std::chrono::steady_clock::now();
    long a1 = g_allocs;
    for (int r = 0; r < 200; ++r)
        for (auto v : views) sum += transparent.find(v)->second;           // no temporary
    auto t2 = std::chrono::steady_clock::now();
    long a2 = g_allocs;
    auto ms = [](auto a, auto b) { return std::chrono::duration<double, std::milli>(b - a).count(); };
    std::printf("plain:       %ld allocations, %.1f ms\ntransparent: %ld allocations, %.1f ms (sum %ld)\n",
                a1 - a0, ms(t0, t1), a2 - a1, ms(t1, t2), sum);
}
