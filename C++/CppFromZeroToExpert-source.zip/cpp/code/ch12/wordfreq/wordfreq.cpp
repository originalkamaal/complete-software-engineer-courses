// file: wordfreq/wordfreq.cpp
#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <memory_resource>
#include <sstream>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

using Counts = std::vector<std::pair<std::string, long>>;

Counts top10(std::vector<std::pair<std::string, long>> all) {
    std::partial_sort(all.begin(), all.begin() + std::min<std::size_t>(10, all.size()), all.end(),
                      [](const auto& a, const auto& b) { return a.second != b.second ? a.second > b.second : a.first < b.first; });
    all.resize(std::min<std::size_t>(10, all.size()));
    return all;
}

// v1: the obvious version
Counts v1_naive(const std::string& text) {
    std::map<std::string, long> counts;
    std::istringstream in{text};
    std::string word;
    while (in >> word) {
        std::string clean;
        for (char c : word)
            if (std::isalpha(static_cast<unsigned char>(c))) clean += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if (!clean.empty()) ++counts[clean];
    }
    return top10({counts.begin(), counts.end()});
}

// v2: hash map instead of a tree
Counts v2_unordered(const std::string& text) {
    std::unordered_map<std::string, long> counts;
    std::istringstream in{text};
    std::string word;
    while (in >> word) {
        std::string clean;
        for (char c : word)
            if (std::isalpha(static_cast<unsigned char>(c))) clean += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if (!clean.empty()) ++counts[clean];
    }
    return top10({counts.begin(), counts.end()});
}

// v3: scan the text directly (no istringstream), reuse one buffer for the word
Counts v3_scan(const std::string& text) {
    std::unordered_map<std::string, long> counts;
    std::string word;
    for (std::size_t i = 0, n = text.size(); i <= n; ++i) {
        unsigned char c = i < n ? static_cast<unsigned char>(text[i]) : ' ';
        if (std::isalpha(c)) word += static_cast<char>(std::tolower(c));
        else if (std::isspace(c) || i == n) { if (!word.empty()) { ++counts[word]; word.clear(); } }
    }
    return top10({counts.begin(), counts.end()});
}

// v4: transparent lookup with string_view: allocate only for NEW words; reserve the table
struct SvHash { using is_transparent = void; std::size_t operator()(std::string_view s) const noexcept { return std::hash<std::string_view>{}(s); } };
Counts v4_transparent(const std::string& text) {
    std::unordered_map<std::string, long, SvHash, std::equal_to<>> counts;
    counts.reserve(1 << 16);
    std::string word;
    for (std::size_t i = 0, n = text.size(); i <= n; ++i) {
        unsigned char c = i < n ? static_cast<unsigned char>(text[i]) : ' ';
        if (std::isalpha(c)) word += static_cast<char>(std::tolower(c));
        else if (std::isspace(c) || i == n) {
            if (!word.empty()) {
                if (auto it = counts.find(std::string_view{word}); it != counts.end()) ++it->second;
                else counts.emplace(word, 1);
                word.clear();
            }
        }
    }
    return top10({counts.begin(), counts.end()});
}

// v5: one lowercase copy of all letters, an open-addressing table of string_views into it, a lookup table
Counts v5_flat(const std::string& text) {
    static constexpr auto kind = [] {                        // compile-time classification: 0 other, 1 space, else letter
        std::array<unsigned char, 256> t{};
        for (int c = 'a'; c <= 'z'; ++c) t[static_cast<std::size_t>(c)] = static_cast<unsigned char>(c);
        for (int c = 'A'; c <= 'Z'; ++c) t[static_cast<std::size_t>(c)] = static_cast<unsigned char>(c - 'A' + 'a');
        for (char c : {' ', '\t', '\n', '\v', '\f', '\r'}) t[static_cast<unsigned char>(c)] = 1;
        return t;
    }();
    std::string letters(text.size(), '\0');                  // one allocation holds every word's characters
    struct Slot { std::string_view key; long count; std::uint64_t hash; };
    std::vector<Slot> slots(1 << 17);                        // power of two, kept sparse
    const std::size_t mask = slots.size() - 1;
    std::size_t w = 0, start = 0;                            // write cursor and start of the current word
    std::uint64_t h = 14695981039346656037ull;               // FNV-1a hash, computed while scanning
    auto flush = [&] {
        if (w == start) return;
        std::string_view word{letters.data() + start, w - start};
        for (std::size_t i = h & mask;; i = (i + 1) & mask) {
            if (slots[i].key.empty()) { slots[i] = {word, 1, h}; break; }
            if (slots[i].hash == h && slots[i].key == word) { ++slots[i].count; w = start; break; }   // reuse the space
        }
        start = w;
        h = 14695981039346656037ull;
    };
    for (unsigned char c : text) {
        unsigned char k = kind[c];
        if (k > 1) { letters[w++] = static_cast<char>(k); h = (h ^ k) * 1099511628211ull; }   // letter: append, hash
        else if (k == 1) flush();                            // whitespace ends a word; other characters are dropped
    }
    flush();
    std::vector<std::pair<std::string, long>> all;
    for (const auto& s : slots) if (!s.key.empty()) all.emplace_back(std::string{s.key}, s.count);
    return top10(std::move(all));
}

template <typename F>
Counts run(const char* name, F f, const std::string& text, double base_ms, double& out_ms) {
    auto t0 = std::chrono::steady_clock::now();
    Counts c = f(text);
    out_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::printf("%-34s %8.1f ms  %5.1fx\n", name, out_ms, base_ms > 0 ? base_ms / out_ms : 1.0);
    return c;
}

int main(int argc, char* argv[]) {
    std::ifstream in{argc > 1 ? argv[1] : "corpus.txt"};
    std::string text{std::istreambuf_iterator<char>{in}, {}};
    std::printf("input: %.1f MB\n", text.size() / 1e6);
    double base = 0, t = 0;
    Counts ref = run("v1 istringstream + map", v1_naive, text, 0, base);
    bool same = true;
    same &= run("v2 unordered_map", v2_unordered, text, base, t) == ref;
    same &= run("v3 direct scan, reused buffer", v3_scan, text, base, t) == ref;
    same &= run("v4 transparent lookup + reserve", v4_transparent, text, base, t) == ref;
    same &= run("v5 flat table, LUT, inline hash", v5_flat, text, base, t) == ref;
    std::printf("all versions agree: %s\ntop words:", same ? "yes" : "NO");
    for (const auto& [w, n] : ref) std::printf(" %s(%ld)", w.c_str(), n);
    std::printf("\n");
}
