// file: wordfreq/gen.cpp
#include <cmath>
#include <cstdio>
#include <random>
#include <string>
#include <vector>

int main() {
    std::mt19937 rng{2026};
    std::vector<std::string> vocab;
    std::uniform_int_distribution<int> len{2, 9}, letter{0, 25};
    for (int i = 0; i < 50000; ++i) {
        std::string w;
        for (int k = len(rng); k > 0; --k) w += static_cast<char>('a' + letter(rng));
        vocab.push_back(w);
    }
    std::vector<double> weights(vocab.size());
    for (std::size_t i = 0; i < weights.size(); ++i) weights[i] = 1.0 / static_cast<double>(i + 1);   // Zipf
    std::discrete_distribution<std::size_t> pick{weights.begin(), weights.end()};
    std::uniform_int_distribution<int> style{0, 19};
    std::size_t bytes = 0;
    while (bytes < 50'000'000) {
        std::string w = vocab[pick(rng)];
        int s = style(rng);
        if (s == 0) w[0] = static_cast<char>(w[0] - 32);             // Capitalised
        if (s == 1) w += ",";
        if (s == 2) w = "\"" + w + "\"";
        if (s == 3) w.insert(w.size() / 2, "'");                      // inner apostrophe
        w += (style(rng) == 0 ? "\n" : " ");
        bytes += w.size();
        std::fputs(w.c_str(), stdout);
    }
}
