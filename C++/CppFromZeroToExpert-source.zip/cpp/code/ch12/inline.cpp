// file: inline.cpp
#include <algorithm>
#include <chrono>
#include <functional>
#include <iostream>
#include <random>
#include <vector>

template <typename F>
double ms(F f) {
    auto t0 = std::chrono::steady_clock::now();
    f();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

bool less_fn(int a, int b) { return a < b; }

int main() {
    std::vector<int> base(5'000'000);
    std::mt19937 rng{3};
    for (auto& x : base) x = static_cast<int>(rng());
    auto a = base, b = base, c = base, d = base;
    double t_lambda = ms([&] { std::sort(a.begin(), a.end(), [](int x, int y) { return x < y; }); });
    double t_fnptr = ms([&] { std::sort(b.begin(), b.end(), less_fn); });                     // through a pointer
    std::function<bool(int, int)> f = [](int x, int y) { return x < y; };
    double t_stdfn = ms([&] { std::sort(c.begin(), c.end(), f); });                           // type-erased
    double t_qsort = ms([&] { std::qsort(d.data(), d.size(), sizeof(int), [](const void* p, const void* q) {
                                   int x = *static_cast<const int*>(p), y = *static_cast<const int*>(q);
                                   return (x > y) - (x < y); }); });
    std::cout << "sort 5M ints: lambda " << t_lambda << " ms, function pointer " << t_fnptr << " ms, std::function "
              << t_stdfn << " ms, C qsort " << t_qsort << " ms; equal: " << (a == b && b == c && c == d) << '\n';
}
