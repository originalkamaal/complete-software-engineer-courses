// file: falseshare.cpp
#include <atomic>
#include <chrono>
#include <cstdio>
#include <thread>
#include <vector>

struct Packed { std::atomic<long> v{0}; };
struct alignas(64) Padded { std::atomic<long> v{0}; };

template <typename Slot> double run() {
    Slot slots[4];
    auto t0 = std::chrono::steady_clock::now();
    {
        std::vector<std::jthread> ts;
        for (int t = 0; t < 4; ++t)
            ts.emplace_back([&slots, t] { for (int i = 0; i < 20'000'000; ++i) slots[t].v.fetch_add(1, std::memory_order_relaxed); });
    }
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    double packed = run<Packed>(), padded = run<Padded>();
    std::printf("sizeof Packed %zu, Padded %zu\n", sizeof(Packed), sizeof(Padded));
    std::printf("same cache line is %s than separate lines\n", packed > 1.5 * padded ? "clearly slower" : "not clearly slower");
}
