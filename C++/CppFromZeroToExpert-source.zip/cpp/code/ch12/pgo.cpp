#include <cstdio>
int main(int c,char**){long s=0;for(long i=0;i<200000000;++i){if(i%97==c)s+=i;else s^=i;}std::printf("%ld\n",s);}
