// file: hetero_um.cpp
#include <cstdio>
#include <cstdlib>
#include <new>
#include <string>
#include <string_view>
#include <unordered_map>

static int allocations = 0;
void* operator new(std::size_t n) { ++allocations; if (void* p = std::malloc(n)) return p; throw std::bad_alloc(); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

struct StringHash {
    using is_transparent = void;
    std::size_t operator()(std::string_view s) const { return std::hash<std::string_view>{}(s); }
};

int main() {
    const char* key = "a-rather-long-configuration-key";
    std::unordered_map<std::string, int> plain{{key, 1}};
    std::unordered_map<std::string, int, StringHash, std::equal_to<>> transparent{{key, 1}};

    int before = allocations;
    for (int i = 0; i < 1000; ++i) (void)plain.find(key);
    std::printf("plain unordered_map:       %d allocations for 1000 lookups\n", allocations - before);
    before = allocations;
    for (int i = 0; i < 1000; ++i) (void)transparent.find(key);
    std::printf("transparent unordered_map: %d allocations for 1000 lookups\n", allocations - before);
}
