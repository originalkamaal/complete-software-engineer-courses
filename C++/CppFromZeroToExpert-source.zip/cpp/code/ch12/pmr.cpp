// file: pmr.cpp
#include <array>
#include <chrono>
#include <cstddef>
#include <iostream>
#include <list>
#include <memory_resource>
#include <string>

template <typename F>
double ms(F f) {
    auto t0 = std::chrono::steady_clock::now();
    f();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    const int n = 1'000'000;
    long checksum = 0;
    double t_default = ms([&] {
        for (int r = 0; r < 5; ++r) {
            std::list<int> l;
            for (int i = 0; i < n; ++i) l.push_back(i);
            checksum += l.back();
        }
    });
    double t_arena = ms([&] {
        for (int r = 0; r < 5; ++r) {
            std::pmr::monotonic_buffer_resource arena{std::pmr::new_delete_resource()};   // grows in big chunks
            std::pmr::list<int> l{&arena};
            for (int i = 0; i < n; ++i) l.push_back(i);
            checksum += l.back();
        }                                          // the whole arena released at once
    });
    std::cout << "1M-node lists x5: default allocator " << t_default << " ms, monotonic arena " << t_arena
              << " ms (checksum " << checksum << ")\n";

    std::array<std::byte, 1024> stack_buf;         // allocation from a stack buffer, no heap at all
    std::pmr::monotonic_buffer_resource local{stack_buf.data(), stack_buf.size(), std::pmr::null_memory_resource()};
    std::pmr::string s{"pmr strings propagate their allocator", &local};
    std::cout << s << " (allocated inside a 1 KiB stack buffer)\n";
}
