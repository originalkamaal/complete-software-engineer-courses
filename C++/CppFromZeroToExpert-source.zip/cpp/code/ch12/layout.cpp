// file: layout.cpp
#include <chrono>
#include <iostream>
#include <memory>
#include <random>
#include <string>
#include <vector>

struct Particle {                       // hot fields and cold fields together
    float x, y, vx, vy;
    std::string name;                   // 32 bytes of rarely used data
    double created_at;
};

struct ParticlesSoA {                   // struct of arrays: one array per field
    std::vector<float> x, y, vx, vy;
};

template <typename F>
double ms(F f) {
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 20; ++r) f();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    const int n = 1'000'000;
    std::vector<Particle> values(n);
    std::vector<std::unique_ptr<Particle>> pointers;
    for (int i = 0; i < n; ++i) pointers.push_back(std::make_unique<Particle>());
    std::shuffle(pointers.begin(), pointers.end(), std::mt19937{1});   // realistic: allocation order != iteration order
    ParticlesSoA soa{std::vector<float>(n), std::vector<float>(n), std::vector<float>(n, 1), std::vector<float>(n, 1)};

    double t_ptr = ms([&] { for (auto& p : pointers) { p->x += p->vx; p->y += p->vy; } });
    double t_val = ms([&] { for (auto& p : values) { p.x += p.vx; p.y += p.vy; } });
    double t_soa = ms([&] { for (int i = 0; i < n; ++i) { soa.x[i] += soa.vx[i]; soa.y[i] += soa.vy[i]; } });
    std::cout << "update 1M particles x20: vector<unique_ptr> " << t_ptr << " ms, vector<Particle> " << t_val
              << " ms, struct of arrays " << t_soa << " ms\n";
    std::cout << "sizeof(Particle) = " << sizeof(Particle) << " bytes, of which the loop uses 16\n";
}
