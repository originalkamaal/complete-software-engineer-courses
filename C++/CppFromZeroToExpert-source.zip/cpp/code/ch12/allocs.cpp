// file: allocs.cpp
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <map>
#include <new>
#include <string>
#include <vector>

static long g_allocs = 0;
void* operator new(std::size_t n) {                       // count every allocation in the program
    ++g_allocs;
    if (void* p = std::malloc(n)) return p;
    throw std::bad_alloc{};
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

template <typename F>
void count(const char* label, F f) {
    long before = g_allocs;
    f();
    std::printf("%-48s %4ld allocation(s)\n", label, g_allocs - before);
}

void by_value(std::string s) { (void)s; }
void by_cref(const std::string& s) { (void)s; }

int main() {
    std::string long_str(64, 'x');
    count("std::string of 15 chars (fits SSO)", [] { std::string s(15, 'a'); });
    count("std::string of 16 chars (heap)", [] { std::string s(16, 'a'); });
    count("pass long string by value", [&] { by_value(long_str); });
    count("pass long string by const&", [&] { by_cref(long_str); });
    count("call const std::string& with a literal", [] { by_cref("a literal longer than fifteen chars"); });
    count("push_back 1000 ints, no reserve", [] { std::vector<int> v; for (int i = 0; i < 1000; ++i) v.push_back(i); });
    count("push_back 1000 ints, reserve first", [] { std::vector<int> v; v.reserve(1000); for (int i = 0; i < 1000; ++i) v.push_back(i); });
    count("insert 100 ints into std::map", [] { std::map<int, int> m; for (int i = 0; i < 100; ++i) m[i] = i; });
    count("std::function with small lambda (SBO)", [] { int a = 1; std::function<int()> f = [a] { return a; }; (void)f; });
    count("std::function with large capture", [] { std::array<long, 8> big{}; std::function<long()> f = [big] { return big[0]; }; (void)f; });
}
