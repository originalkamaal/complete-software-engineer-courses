// file: lru/tests/lru_test.cpp
#include <gtest/gtest.h>
#include <algorithm>
#include <random>
#include <string>
#include <vector>
#include "lru/lru_cache.hpp"

using lru::LruCache;

TEST(LruCache, RejectsZeroCapacity) { EXPECT_THROW((LruCache<int, int>{0}), std::invalid_argument); }

TEST(LruCache, EvictsLeastRecentlyUsed) {
    LruCache<std::string, int> c{2};
    c.put("a", 1);
    c.put("b", 2);
    ASSERT_NE(c.get("a"), nullptr);          // a is now most recent
    auto evicted = c.put("c", 3);            // evicts b
    ASSERT_TRUE(evicted.has_value());
    EXPECT_EQ(*evicted, "b");
    EXPECT_EQ(c.get("b"), nullptr);
    EXPECT_EQ(*c.get("a"), 1);
    EXPECT_EQ(*c.get("c"), 3);
}

TEST(LruCache, PutExistingKeyUpdatesAndRefreshes) {
    LruCache<int, std::string> c{2};
    c.put(1, "one");
    c.put(2, "two");
    EXPECT_FALSE(c.put(1, "uno").has_value());   // update, no eviction
    c.put(3, "three");                            // evicts 2, not 1
    EXPECT_EQ(*c.get(1), "uno");
    EXPECT_EQ(c.get(2), nullptr);
}

TEST(LruCache, CountsHitsAndMisses) {
    LruCache<int, int> c{4};
    c.put(1, 1);
    c.get(1);
    c.get(2);
    c.get(1);
    EXPECT_EQ(c.hits(), 2u);
    EXPECT_EQ(c.misses(), 1u);
}

// Differential test: compare with an obviously correct (slow) model on random operations.
TEST(LruCache, MatchesReferenceModel) {
    const std::size_t cap = 8;
    LruCache<int, int> cache{cap};
    std::vector<std::pair<int, int>> model;      // front = most recent
    std::mt19937 rng{123};
    for (int step = 0; step < 100000; ++step) {
        int key = static_cast<int>(rng() % 20), op = static_cast<int>(rng() % 3);
        auto it = std::find_if(model.begin(), model.end(), [&](auto& e) { return e.first == key; });
        if (op < 2) {                            // get
            int* got = cache.get(key);
            if (it == model.end()) { ASSERT_EQ(got, nullptr) << "step " << step; }
            else {
                ASSERT_NE(got, nullptr) << "step " << step;
                ASSERT_EQ(*got, it->second);
                std::rotate(model.begin(), it, it + 1);
            }
        } else {                                 // put
            if (it != model.end()) model.erase(it);
            else if (model.size() == cap) model.pop_back();
            model.insert(model.begin(), {key, step});
            cache.put(key, step);
        }
        ASSERT_EQ(cache.size(), model.size());
    }
    std::vector<int> order;
    cache.for_each_mru([&](int k, int) { order.push_back(k); });
    for (std::size_t i = 0; i < model.size(); ++i) ASSERT_EQ(order[i], model[i].first);
}
