# file: lru/CMakeLists.txt
cmake_minimum_required(VERSION 3.24)
project(lru VERSION 1.0 LANGUAGES CXX)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)                        # compile_commands.json for clang-tidy and editors

add_library(lru INTERFACE)                                   # header-only library
add_library(lru::lru ALIAS lru)
target_include_directories(lru INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_features(lru INTERFACE cxx_std_20)

add_library(lru_warnings INTERFACE)
target_compile_options(lru_warnings INTERFACE -Wall -Wextra -Wpedantic -Wshadow -Wconversion
                       -Wnon-virtual-dtor -Wold-style-cast -Woverloaded-virtual)

option(LRU_SANITIZE "Build tests with ASan and UBSan" OFF)
option(LRU_BENCH "Build benchmarks" ON)

include(FetchContent)
FetchContent_Declare(googletest                              # installed copy if present, else download
  GIT_REPOSITORY https://github.com/google/googletest.git GIT_TAG v1.15.2
  FIND_PACKAGE_ARGS NAMES GTest)
FetchContent_MakeAvailable(googletest)

enable_testing()
add_executable(lru_test tests/lru_test.cpp)
target_link_libraries(lru_test PRIVATE lru::lru lru_warnings GTest::gtest_main)
if(LRU_SANITIZE)
  target_compile_options(lru_test PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer -D_GLIBCXX_ASSERTIONS)
  target_link_options(lru_test PRIVATE -fsanitize=address,undefined)
endif()
include(GoogleTest)
gtest_discover_tests(lru_test)

if(LRU_BENCH)
  find_package(benchmark REQUIRED)
  add_executable(lru_bench bench/lru_bench.cpp)
  target_link_libraries(lru_bench PRIVATE lru::lru benchmark::benchmark)
endif()
