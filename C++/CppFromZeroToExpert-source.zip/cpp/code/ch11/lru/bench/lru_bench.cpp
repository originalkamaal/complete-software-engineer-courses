// file: lru/bench/lru_bench.cpp
#include <benchmark/benchmark.h>
#include <random>
#include "lru/lru_cache.hpp"

static void BM_LruMixed(benchmark::State& state) {
    const auto cap = static_cast<std::size_t>(state.range(0));
    lru::LruCache<int, int> cache{cap};
    std::mt19937 rng{1};
    std::geometric_distribution<int> skewed{0.001};               // popular keys are small numbers
    for (auto _ : state) {
        int key = skewed(rng);
        if (int* v = cache.get(key)) benchmark::DoNotOptimize(*v);
        else cache.put(key, key);
    }
    state.counters["hit_rate"] = static_cast<double>(cache.hits()) / static_cast<double>(cache.hits() + cache.misses());
}
BENCHMARK(BM_LruMixed)->Arg(100)->Arg(1000)->Arg(10000);
BENCHMARK_MAIN();
