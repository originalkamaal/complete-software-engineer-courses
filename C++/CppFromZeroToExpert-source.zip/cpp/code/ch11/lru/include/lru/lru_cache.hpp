// file: lru/include/lru/lru_cache.hpp
#pragma once
#include <cstddef>
#include <functional>
#include <list>
#include <optional>
#include <stdexcept>
#include <unordered_map>
#include <utility>

namespace lru {

// LruCache maps keys to values, holding at most capacity() entries. Every get or
// put marks the entry most recently used; inserting into a full cache evicts the
// least recently used entry. All operations are O(1) on average.
template <typename K, typename V, typename Hash = std::hash<K>>
class LruCache {
public:
    explicit LruCache(std::size_t capacity) : capacity_{capacity} {
        if (capacity == 0) throw std::invalid_argument("LruCache capacity must be positive");
        index_.reserve(capacity);
    }

    // get returns a pointer to the value (valid until the next modification), or nullptr.
    V* get(const K& key) {
        auto it = index_.find(key);
        if (it == index_.end()) { ++misses_; return nullptr; }
        order_.splice(order_.begin(), order_, it->second);   // move to front: O(1), no allocation
        ++hits_;
        return &it->second->second;
    }

    // put inserts or replaces; returns the evicted key, if any.
    std::optional<K> put(K key, V value) {
        if (auto it = index_.find(key); it != index_.end()) {
            it->second->second = std::move(value);
            order_.splice(order_.begin(), order_, it->second);
            return std::nullopt;
        }
        std::optional<K> evicted;
        if (order_.size() == capacity_) {
            evicted = std::move(order_.back().first);
            index_.erase(*evicted);
            order_.pop_back();
        }
        order_.emplace_front(std::move(key), std::move(value));
        index_.emplace(order_.front().first, order_.begin());
        return evicted;
    }

    bool erase(const K& key) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        order_.erase(it->second);
        index_.erase(it);
        return true;
    }

    std::size_t size() const { return index_.size(); }
    std::size_t capacity() const { return capacity_; }
    std::size_t hits() const { return hits_; }
    std::size_t misses() const { return misses_; }

    template <typename F> void for_each_mru(F&& f) const {   // most recent first
        for (const auto& [k, v] : order_) f(k, v);
    }

private:
    using Entry = std::pair<K, V>;
    std::size_t capacity_;
    std::list<Entry> order_;                                  // front = most recently used
    std::unordered_map<K, typename std::list<Entry>::iterator, Hash> index_;
    std::size_t hits_ = 0, misses_ = 0;
};

}  // namespace lru
