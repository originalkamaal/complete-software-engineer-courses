// file: gtest_demo/stack_test.cpp
#include <gtest/gtest.h>
#include <stdexcept>
#include <vector>

class BoundedStack {
public:
    explicit BoundedStack(std::size_t cap) : cap_{cap} {}
    void push(int v) { if (v_.size() == cap_) throw std::overflow_error("full"); v_.push_back(v); }
    int pop() { if (v_.empty()) throw std::underflow_error("empty"); int x = v_.back(); v_.pop_back(); return x; }
    std::size_t size() const { return v_.size(); }
    int top_unchecked() const { return v_.back(); }       // precondition: not empty
private:
    std::size_t cap_;
    std::vector<int> v_;
};

TEST(BoundedStack, PushPopIsLifo) {
    BoundedStack s{3};
    s.push(1);
    s.push(2);
    EXPECT_EQ(s.pop(), 2);
    EXPECT_EQ(s.pop(), 1);
    EXPECT_EQ(s.size(), 0u);
}

TEST(BoundedStack, ThrowsWhenFullOrEmpty) {
    BoundedStack s{1};
    s.push(7);
    EXPECT_THROW(s.push(8), std::overflow_error);
    EXPECT_EQ(s.pop(), 7);
    EXPECT_THROW(s.pop(), std::underflow_error);
}

class FilledStack : public ::testing::Test {              // fixture: shared setup
protected:
    void SetUp() override { for (int i = 1; i <= 5; ++i) s.push(i * 10); }
    BoundedStack s{5};
};

TEST_F(FilledStack, IsFull) { EXPECT_THROW(s.push(60), std::overflow_error); }
TEST_F(FilledStack, PopsInReverse) { for (int i = 5; i >= 1; --i) ASSERT_EQ(s.pop(), i * 10) << "at step " << i; }

class CapacityTest : public ::testing::TestWithParam<std::size_t> {};
TEST_P(CapacityTest, HoldsExactlyCapacityItems) {          // parameterised over capacities
    BoundedStack s{GetParam()};
    for (std::size_t i = 0; i < GetParam(); ++i) s.push(static_cast<int>(i));
    EXPECT_EQ(s.size(), GetParam());
    EXPECT_ANY_THROW(s.push(0));
}
INSTANTIATE_TEST_SUITE_P(Sizes, CapacityTest, ::testing::Values(1, 2, 10, 1000));

TEST(BoundedStackDeathTest, TopOnEmptyAbortsWithAssertions) {
    BoundedStack s{1};
    EXPECT_DEATH((void)s.top_unchecked(), "");             // with _GLIBCXX_ASSERTIONS, back() on empty aborts
}

TEST(Demo, ShowsAFailure) {
    EXPECT_EQ(2 + 2, 5) << "a deliberately failing check, to show the report format";
}
