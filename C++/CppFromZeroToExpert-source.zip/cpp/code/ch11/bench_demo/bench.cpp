// file: bench_demo/bench.cpp
#include <benchmark/benchmark.h>
#include <algorithm>
#include <map>
#include <numeric>
#include <random>
#include <unordered_map>
#include <vector>

static std::vector<int> random_keys(std::size_t n) {
    std::vector<int> v(n);
    std::iota(v.begin(), v.end(), 0);
    std::shuffle(v.begin(), v.end(), std::mt19937{42});
    return v;
}

template <typename Map>
static void BM_Lookup(benchmark::State& state) {
    auto keys = random_keys(static_cast<std::size_t>(state.range(0)));
    Map m;
    for (int k : keys) m[k] = k;
    std::size_t i = 0;
    for (auto _ : state) {                                // the timed loop
        auto it = m.find(keys[i++ % keys.size()]);
        benchmark::DoNotOptimize(it);                     // the result "escapes": cannot be optimised away
    }
    state.SetComplexityN(state.range(0));
}
BENCHMARK_TEMPLATE(BM_Lookup, std::map<int, int>)->RangeMultiplier(10)->Range(1000, 1000000)->Complexity();
BENCHMARK_TEMPLATE(BM_Lookup, std::unordered_map<int, int>)->RangeMultiplier(10)->Range(1000, 1000000)->Complexity();

static void BM_SortedVectorLookup(benchmark::State& state) {
    auto keys = random_keys(static_cast<std::size_t>(state.range(0)));
    std::vector<int> sorted = keys;
    std::sort(sorted.begin(), sorted.end());
    std::size_t i = 0;
    for (auto _ : state)
        benchmark::DoNotOptimize(std::binary_search(sorted.begin(), sorted.end(), keys[i++ % keys.size()]));
}
BENCHMARK(BM_SortedVectorLookup)->RangeMultiplier(10)->Range(1000, 1000000);

BENCHMARK_MAIN();
