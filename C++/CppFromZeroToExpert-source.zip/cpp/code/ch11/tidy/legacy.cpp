// file: tidy/legacy.cpp
#include <cstdio>
#include <cstring>
#include <vector>

class Widget {
public:
    Widget(int n) : n(n) {}                              // implicit conversion from int
    virtual void draw() { std::printf("%d\n", n); }
    ~Widget() {}                                          // non-virtual destructor in a polymorphic class
    int n;
};

int sum(std::vector<int> v) {                             // copies the vector
    int total = 0;
    for (std::size_t i = 0; i < v.size(); i++) total += v[i];
    return total;
}

int main() {
    Widget* w = new Widget(3);                            // owning raw pointer
    w->draw();
    char buf[8];
    std::strcpy(buf, "hello");
    int* p = NULL;
    if (p == NULL) std::printf("%d %s\n", sum({1, 2, 3}), buf);
    delete w;
}
