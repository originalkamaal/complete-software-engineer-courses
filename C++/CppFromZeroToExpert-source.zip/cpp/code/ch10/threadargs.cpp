// file: threadargs.cpp
#include <functional>
#include <iostream>
#include <thread>

void add_ten(int& x) { x += 10; }

int main() {
    int counter = 0;
    // std::thread bad(add_ten, counter);       // error: cannot bind a copied int to int&
    std::jthread t(add_ten, std::ref(counter));  // a reference to main's counter
    t.join();
    std::cout << "counter = " << counter << '\n';

    try {
        std::thread forgot([] {});
        forgot.detach();                         // detached threads may not touch main's locals after main ends
    } catch (...) {}
    std::cout << "hardware threads: " << (std::thread::hardware_concurrency() > 0 ? "reported" : "unknown") << '\n';
}
