// file: relacq.cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <string>
#include <thread>

std::string payload;                       // ordinary, non-atomic data
std::atomic<bool> ready{false};

int main() {
    int checks = 0;
    for (int round = 0; round < 2000; ++round) {
        payload.clear();
        ready.store(false, std::memory_order_relaxed);
        std::jthread producer([] {
            payload = "result of a long computation";
            ready.store(true, std::memory_order_release);      // publishes payload
        });
        std::jthread consumer([&] {
            while (!ready.load(std::memory_order_relaxed)) {}  // spin until published
            assert(payload == "result of a long computation"); // guaranteed to see it
            ++checks;
        });
    }
    std::cout << checks << " rounds, payload always visible\n";
}
