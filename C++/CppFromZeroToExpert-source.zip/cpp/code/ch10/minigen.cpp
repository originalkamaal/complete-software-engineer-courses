// file: minigen.cpp
#include <coroutine>
#include <exception>
#include <iostream>
#include <utility>

struct IntGen {
    struct promise_type {
        int current = 0;
        IntGen get_return_object() { return IntGen{std::coroutine_handle<promise_type>::from_promise(*this)}; }
        std::suspend_always initial_suspend() noexcept { return {}; }   // start suspended
        std::suspend_always final_suspend() noexcept { return {}; }     // keep the frame until destroyed
        std::suspend_always yield_value(int v) noexcept { current = v; return {}; }
        void return_void() noexcept {}
        void unhandled_exception() { std::terminate(); }
    };
    explicit IntGen(std::coroutine_handle<promise_type> h) : h_(h) {}
    IntGen(IntGen&& o) noexcept : h_(std::exchange(o.h_, {})) {}
    ~IntGen() { if (h_) h_.destroy(); }                                  // frees the coroutine frame
    bool next() { h_.resume(); return !h_.done(); }
    int value() const { return h_.promise().current; }
private:
    std::coroutine_handle<promise_type> h_;
};

IntGen fib(int n) {
    int a = 0, b = 1;                     // these locals live in the coroutine frame
    for (int i = 0; i < n; ++i) {
        co_yield a;
        int t = a + b; a = b; b = t;
    }
}

int main() {
    auto g = fib(10);
    while (g.next()) std::cout << g.value() << ' ';
    std::cout << '\n';
}
