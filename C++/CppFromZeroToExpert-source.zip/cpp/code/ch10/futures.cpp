// file: futures.cpp
#include <chrono>
#include <future>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <vector>

long long count_primes(int from, int to) {
    long long n = 0;
    for (int x = std::max(2, from); x < to; ++x) {
        bool prime = true;
        for (int d = 2; d * d <= x && prime; ++d) prime = x % d != 0;
        n += prime;
    }
    return n;
}

int main() {
    using clock = std::chrono::steady_clock;
    const int limit = 3'000'000;
    auto t0 = clock::now();
    long long serial = count_primes(0, limit);
    auto t1 = clock::now();

    std::vector<std::future<long long>> parts;
    const int chunks = 8;
    for (int c = 0; c < chunks; ++c)
        parts.push_back(std::async(std::launch::async, count_primes, limit / chunks * c, limit / chunks * (c + 1)));
    long long parallel = 0;
    for (auto& f : parts) parallel += f.get();             // get() waits; rethrows exceptions
    auto t2 = clock::now();
    auto ms = [](auto a, auto b) { return std::chrono::duration<double, std::milli>(b - a).count(); };
    std::cout << "primes below " << limit << ": serial " << serial << " in " << ms(t0, t1) << " ms, async "
              << parallel << " in " << ms(t1, t2) << " ms\n";

    auto failing = std::async(std::launch::async, [] () -> int { throw std::runtime_error("task failed"); });
    try { failing.get(); } catch (const std::exception& e) { std::cout << "exception from task: " << e.what() << '\n'; }

    std::promise<std::string> p;
    std::future<std::string> answer = p.get_future();
    std::jthread producer{[&p] { p.set_value("value set by another thread"); }};
    std::cout << answer.get() << '\n';
}
