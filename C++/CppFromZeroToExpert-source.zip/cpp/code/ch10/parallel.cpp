// file: parallel.cpp
#include <algorithm>
#include <chrono>
#include <execution>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>

template <typename F>
double ms(F f) {
    auto t0 = std::chrono::steady_clock::now();
    f();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    std::vector<double> data(20'000'000);
    std::mt19937_64 rng{7};
    std::uniform_real_distribution<double> dist{0, 1};
    for (auto& x : data) x = dist(rng);
    auto a = data, b = data;

    double t_seq = ms([&] { std::sort(std::execution::seq, a.begin(), a.end()); });
    double t_par = ms([&] { std::sort(std::execution::par, b.begin(), b.end()); });
    double s1 = 0, s2 = 0;
    double r_seq = ms([&] { s1 = std::transform_reduce(std::execution::seq, data.begin(), data.end(), 0.0, std::plus<>{}, [](double x) { return x * x; }); });
    double r_par = ms([&] { s2 = std::transform_reduce(std::execution::par_unseq, data.begin(), data.end(), 0.0, std::plus<>{}, [](double x) { return x * x; }); });
    std::cout << "sort 20M doubles: seq " << t_seq << " ms, par " << t_par << " ms; sorted equal: " << std::boolalpha << (a == b) << '\n';
    std::cout << "sum of squares: seq " << r_seq << " ms, par_unseq " << r_par << " ms; |difference| = " << std::abs(s1 - s2) << '\n';
}
