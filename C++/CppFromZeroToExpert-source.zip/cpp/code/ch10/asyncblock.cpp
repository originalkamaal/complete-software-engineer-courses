// file: asyncblock.cpp
#include <chrono>
#include <future>
#include <iostream>
#include <thread>

using namespace std::chrono;

void work() { std::this_thread::sleep_for(200ms); }

int main() {
    auto t0 = steady_clock::now();
    std::async(std::launch::async, work);          // temporary future: destructor waits here
    std::async(std::launch::async, work);
    auto serial = duration_cast<milliseconds>(steady_clock::now() - t0).count();

    t0 = steady_clock::now();
    {
        auto f1 = std::async(std::launch::async, work);
        auto f2 = std::async(std::launch::async, work);
    }
    auto parallel = duration_cast<milliseconds>(steady_clock::now() - t0).count();
    std::cout << "discarded futures: " << (serial >= 390 ? "about 400 ms (serial)" : "?") << '\n'
              << "kept futures:      " << (parallel < 390 ? "about 200 ms (parallel)" : "?") << '\n';
}
