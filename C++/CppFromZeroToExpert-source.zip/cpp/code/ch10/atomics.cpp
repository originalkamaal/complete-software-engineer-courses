// file: atomics.cpp
#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    std::atomic<long> hits{0};
    {
        std::vector<std::jthread> ts;
        for (int i = 0; i < 4; ++i)
            ts.emplace_back([&] { for (int k = 0; k < 100000; ++k) hits.fetch_add(1, std::memory_order_relaxed); });
    }
    std::cout << "hits " << hits << ", lock-free: " << std::boolalpha << hits.is_lock_free() << '\n';

    std::atomic<int> state{0};
    std::jthread waiter{[&] {
        state.wait(0);                                   // sleeps until state != 0 (futex on Linux, no spinning)
        std::cout << "waiter woke with state " << state.load() << '\n';
    }};
    state.store(42);
    state.notify_one();

    int plain_counter = 0;
    {
        std::vector<std::jthread> ts;
        for (int i = 0; i < 4; ++i)
            ts.emplace_back([&] { std::atomic_ref ref{plain_counter}; for (int k = 0; k < 1000; ++k) ++ref; });
    }
    std::cout << "plain int updated atomically via atomic_ref: " << plain_counter << '\n';
}
