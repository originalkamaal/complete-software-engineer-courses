// file: sync.cpp
#include <barrier>
#include <chrono>
#include <condition_variable>
#include <iostream>
#include <latch>
#include <mutex>
#include <queue>
#include <semaphore>
#include <thread>
#include <vector>

template <typename T>
class BlockingQueue {
public:
    void push(T v) {
        { std::lock_guard g{m_}; q_.push(std::move(v)); }
        cv_.notify_one();                                   // notify after unlocking: the waiter can run at once
    }
    bool pop(T& out) {                                      // false when closed and empty
        std::unique_lock lock{m_};
        cv_.wait(lock, [&] { return !q_.empty() || closed_; });   // predicate: no lost or spurious wake-ups
        if (q_.empty()) return false;
        out = std::move(q_.front());
        q_.pop();
        return true;
    }
    void close() { { std::lock_guard g{m_}; closed_ = true; } cv_.notify_all(); }
private:
    std::mutex m_;
    std::condition_variable cv_;
    std::queue<T> q_;
    bool closed_ = false;
};

int main() {
    BlockingQueue<int> q;
    long long sum = 0;
    std::mutex sum_m;
    {
        std::vector<std::jthread> consumers;
        for (int i = 0; i < 3; ++i)
            consumers.emplace_back([&] { int v; long long local = 0; while (q.pop(v)) local += v; std::lock_guard g{sum_m}; sum += local; });
        for (int v = 1; v <= 1000; ++v) q.push(v);
        q.close();
    }
    std::cout << "queue: sum " << sum << " (expected 500500)\n";

    std::latch ready{3};                                     // one-shot: count down to zero
    std::barrier phase{3, []() noexcept { std::cout << "  -- phase complete --\n"; }};
    std::counting_semaphore<2> slots{2};                     // at most 2 threads inside at once
    std::atomic<int> inside{0}, max_inside{0};
    {
        std::vector<std::jthread> ts;
        for (int id = 0; id < 3; ++id)
            ts.emplace_back([&, id] {
                ready.count_down();
                ready.wait();                                // everyone starts together
                for (int p = 0; p < 2; ++p) {
                    slots.acquire();
                    int now = ++inside;
                    for (int m = max_inside; now > m && !max_inside.compare_exchange_weak(m, now);) {}
                    std::this_thread::sleep_for(std::chrono::milliseconds(5));
                    --inside;
                    slots.release();
                    phase.arrive_and_wait();                 // nobody starts phase p+1 early
                }
                (void)id;
            });
    }
    std::cout << "max threads inside the semaphore at once: " << max_inside << " (limit 2)\n";
}
