// file: pool/test.cpp
#include <atomic>
#include <cassert>
#include <chrono>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <string>
#include "thread_pool.hpp"

long long count_primes(int from, int to) {
    long long n = 0;
    for (int x = std::max(2, from); x < to; ++x) {
        bool prime = true;
        for (int d = 2; d * d <= x && prime; ++d) prime = x % d != 0;
        n += prime;
    }
    return n;
}

int main() {
    ThreadPool pool{4};

    auto sq = pool.submit([](int x) { return x * x; }, 12);
    auto text = pool.submit([](std::string a, std::string b) { return a + b; }, std::string("thread "), std::string("pool"));
    auto boom = pool.submit([]() -> int { throw std::runtime_error("task error"); });
    assert(sq.get() == 144);
    assert(text.get() == "thread pool");
    try { boom.get(); assert(false); } catch (const std::runtime_error& e) { std::cout << "exception propagated: " << e.what() << '\n'; }

    std::atomic<int> done{0};
    for (int i = 0; i < 1000; ++i) pool.submit([&done] { done.fetch_add(1, std::memory_order_relaxed); });
    pool.wait_idle();
    assert(done == 1000);
    std::cout << "1000 small tasks completed\n";

    const int limit = 2'000'000, chunks = 64;
    auto t0 = std::chrono::steady_clock::now();
    std::vector<std::future<long long>> parts;
    for (int c = 0; c < chunks; ++c) parts.push_back(pool.submit(count_primes, limit / chunks * c, limit / chunks * (c + 1)));
    long long total = 0;
    for (auto& f : parts) total += f.get();
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    assert(total == count_primes(0, limit));
    std::cout << "primes below " << limit << ": " << total << " (" << chunks << " tasks, " << ms << " ms)\n";
    std::cout << "all thread pool tests passed\n";
}
