// file: pool/thread_pool.hpp
#pragma once
#include <condition_variable>
#include <deque>
#include <functional>
#include <future>
#include <mutex>
#include <thread>
#include <type_traits>
#include <vector>

class ThreadPool {
public:
    explicit ThreadPool(unsigned n = std::thread::hardware_concurrency()) {
        for (unsigned i = 0; i < (n ? n : 1); ++i)
            workers_.emplace_back([this](std::stop_token st) { run(st); });
    }
    ~ThreadPool() {
        for (auto& w : workers_) w.request_stop();
        cv_.notify_all();                                     // wake idle workers so they see the stop
    }                                                         // jthreads join here
    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

    template <typename F, typename... Args>
    auto submit(F&& f, Args&&... args) -> std::future<std::invoke_result_t<F, Args...>> {
        using R = std::invoke_result_t<F, Args...>;
        std::packaged_task<R()> task{[f = std::forward<F>(f), ... a = std::forward<Args>(args)]() mutable {
            return std::invoke(std::move(f), std::move(a)...);
        }};
        auto fut = task.get_future();
        {
            std::lock_guard g{m_};
            tasks_.emplace_back(std::move(task));             // std::move_only_function would avoid the wrapper
            ++pending_;
        }
        cv_.notify_one();
        return fut;
    }

    void wait_idle() {                                        // block until every submitted task finished
        std::unique_lock lock{m_};
        idle_cv_.wait(lock, [&] { return pending_ == 0; });
    }

private:
    void run(std::stop_token st) {
        while (true) {
            std::packaged_task<void()> job;
            {
                std::unique_lock lock{m_};
                cv_.wait(lock, [&] { return st.stop_requested() || !tasks_.empty(); });
                if (tasks_.empty()) return;                   // stop requested and nothing left
                job = std::move(tasks_.front());
                tasks_.pop_front();
            }
            job();                                            // run outside the lock; exceptions go to the future
            {
                std::lock_guard g{m_};
                if (--pending_ == 0) idle_cv_.notify_all();
            }
        }
    }

    std::mutex m_;
    std::condition_variable cv_, idle_cv_;
    std::deque<std::packaged_task<void()>> tasks_;
    std::size_t pending_ = 0;
    std::vector<std::jthread> workers_;                       // declared last: destroyed (joined) first
};
