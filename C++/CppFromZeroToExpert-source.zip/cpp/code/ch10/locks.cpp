// file: locks.cpp
#include <iostream>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

class Account {
public:
    explicit Account(long long b) : balance_{b} {}
    friend void transfer(Account& from, Account& to, long long amount) {
        std::scoped_lock lock{from.m_, to.m_};          // both, in a deadlock-free order
        from.balance_ -= amount;
        to.balance_ += amount;
    }
    long long balance() const { std::lock_guard g{m_}; return balance_; }
private:
    mutable std::mutex m_;                              // mutable: lockable in const functions
    long long balance_;
};

class Config {                                          // read-mostly data
public:
    std::string get(const std::string& k) const {
        std::shared_lock lock{m_};                      // many readers at once
        auto it = values_.find(k);
        return it == values_.end() ? "" : it->second;
    }
    void set(const std::string& k, std::string v) {
        std::unique_lock lock{m_};                      // one writer, no readers
        values_[k] = std::move(v);
    }
private:
    mutable std::shared_mutex m_;
    std::unordered_map<std::string, std::string> values_;
};

int main() {
    Account a{1000}, b{1000};
    {
        std::vector<std::jthread> ts;
        for (int i = 0; i < 4; ++i)
            ts.emplace_back([&, i] {
                for (int k = 0; k < 10000; ++k)
                    i % 2 ? transfer(a, b, 1) : transfer(b, a, 1);   // opposite directions: classic deadlock risk
            });
    }
    std::cout << "a=" << a.balance() << " b=" << b.balance() << " total=" << a.balance() + b.balance() << '\n';

    Config cfg;
    cfg.set("mode", "fast");
    std::vector<std::jthread> readers;
    for (int i = 0; i < 4; ++i) readers.emplace_back([&] { for (int k = 0; k < 1000; ++k) (void)cfg.get("mode"); });
    readers.clear();
    std::cout << "mode=" << cfg.get("mode") << '\n';
}
