// file: coro.cpp
#include <generator>
#include <utility>
#include <iostream>
#include <ranges>
#include <string>
#include <string_view>

std::generator<long long> fibonacci() {                  // an infinite lazy sequence
    long long a = 0, b = 1;
    while (true) {
        co_yield a;                                       // suspend, hand out a, resume here next time
        a = std::exchange(b, a + b);
    }
}

std::generator<std::string_view> words(std::string_view text) {
    std::size_t i = 0;
    while (i < text.size()) {
        while (i < text.size() && text[i] == ' ') ++i;
        std::size_t j = i;
        while (j < text.size() && text[j] != ' ') ++j;
        if (j > i) co_yield text.substr(i, j - i);
        i = j;
    }
}

int main() {
    for (long long f : fibonacci() | std::views::take(15)) std::cout << f << ' ';
    std::cout << '\n';
    for (auto w : words("  coroutines suspend   and resume ")) std::cout << '[' << w << ']';
    std::cout << '\n';
}
