#include <thread>
int main(){ std::thread t([]{}); }
