// file: jthread.cpp
#include <chrono>
#include <iostream>
#include <stop_token>
#include <thread>
#include <vector>

using namespace std::chrono_literals;

void worker(std::stop_token st, int id, int& progress) {     // stop_token injected by jthread
    while (!st.stop_requested()) {
        ++progress;
        std::this_thread::sleep_for(10ms);
    }
    std::cout << "  worker " << id << " stopping after " << progress << " steps\n";
}

int main() {
    std::vector<int> progress(3, 0);                         // each thread writes only its own slot
    {
        std::vector<std::jthread> threads;
        for (int i = 0; i < 3; ++i)
            threads.emplace_back(worker, i, std::ref(progress[i]));   // std::ref: pass by reference
        std::this_thread::sleep_for(55ms);
        std::cout << "requesting stop\n";
    }                                                          // ~jthread: request_stop() + join()
    std::cout << "all joined; hardware threads: " << std::thread::hardware_concurrency() << '\n';

    std::thread plain{[] {}};
    plain.join();                                              // forgetting this would terminate the program
}
