// file: boundedq.cpp
#include <condition_variable>
#include <deque>
#include <iostream>
#include <mutex>
#include <optional>
#include <thread>
#include <vector>

template <typename T> class BoundedQueue {
public:
    explicit BoundedQueue(std::size_t cap) : cap_(cap) {}
    void push(T v) {
        std::unique_lock lk(m_);
        not_full_.wait(lk, [&] { return q_.size() < cap_; });
        q_.push_back(std::move(v));
        not_empty_.notify_one();
    }
    std::optional<T> pop() {                   // empty optional once closed and drained
        std::unique_lock lk(m_);
        not_empty_.wait(lk, [&] { return !q_.empty() || closed_; });
        if (q_.empty()) return std::nullopt;
        T v = std::move(q_.front());
        q_.pop_front();
        not_full_.notify_one();
        return v;
    }
    void close() { { std::lock_guard lk(m_); closed_ = true; } not_empty_.notify_all(); }
private:
    std::mutex m_;
    std::condition_variable not_full_, not_empty_;
    std::deque<T> q_;
    std::size_t cap_;
    bool closed_ = false;
};

int main() {
    BoundedQueue<int> q(4);
    long total = 0;
    std::mutex tm;
    {
        std::vector<std::jthread> consumers;
        for (int c = 0; c < 3; ++c)
            consumers.emplace_back([&] {
                long local = 0;
                while (auto v = q.pop()) local += *v;
                std::lock_guard lk(tm);
                total += local;
            });
        for (int i = 1; i <= 10000; ++i) q.push(i);
        q.close();
    }                                          // consumers join here
    std::cout << "sum " << total << " (expected " << 10000L * 10001 / 2 << ")\n";
}
