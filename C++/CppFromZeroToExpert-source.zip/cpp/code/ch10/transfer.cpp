// file: transfer.cpp
#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

struct Account { std::mutex m; long balance = 1000; };

void transfer(Account& from, Account& to, long amount) {
    std::scoped_lock lock(from.m, to.m);       // both, deadlock-free, whatever the order
    from.balance -= amount;
    to.balance += amount;
}

int main() {
    Account a, b;
    std::vector<std::jthread> ts;
    for (int i = 0; i < 4; ++i) {
        ts.emplace_back([&] { for (int k = 0; k < 100000; ++k) transfer(a, b, 1); });
        ts.emplace_back([&] { for (int k = 0; k < 100000; ++k) transfer(b, a, 1); });
    }
    ts.clear();                                // joins every thread
    std::cout << "a " << a.balance << ", b " << b.balance << ", total " << a.balance + b.balance << '\n';
}
