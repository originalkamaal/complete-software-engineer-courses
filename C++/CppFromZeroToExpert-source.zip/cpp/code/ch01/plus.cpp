// file: plus.cpp
#include <iostream>
#include <string>
using namespace std::string_literals;

int main() {
    std::string ok = "a"s + "bc";
    std::cout << "\"a\"s + \"bc\" = " << ok << '\n';
    const char* p = "hello, world" + 7;              // legal: a pointer to "world"
    std::cout << "\"hello, world\" + 7 = " << p << '\n';
}
