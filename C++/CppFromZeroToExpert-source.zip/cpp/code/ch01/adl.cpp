// file: adl.cpp
#include <iostream>

namespace shapes {
struct Circle { double r; };
void print(const Circle& c) { std::cout << "shapes::print: circle of radius " << c.r << '\n'; }
}

namespace app {
void print(double) { std::cout << "app::print(double)\n"; }
void draw() {
    shapes::Circle c{2.0};
    print(c);         // not visible in app ... found through the argument's namespace
    print(3.5);       // ordinary lookup: app::print
}
}

namespace util {
template <typename T> void log(const T&) { std::cout << "util::log (generic)\n"; }
}
namespace shapes {
void log(const Circle&) { std::cout << "shapes::log (via ADL!)\n"; }
}

int main() {
    app::draw();
    shapes::Circle c{1.0};
    using util::log;
    log(c);            // both util::log<Circle> and shapes::log are candidates; the non-template wins
    util::log(c);      // qualified name: no ADL
}
