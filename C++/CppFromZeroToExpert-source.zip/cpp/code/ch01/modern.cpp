// file: modern.cpp
#include <iostream>
#include <map>
#include <string>
#include <tuple>

struct Stats { double mean; double max; int count; };

Stats summarise(const int* data, int n) {
    double sum = 0, max = data[0];
    for (int i = 0; i < n; ++i) {
        sum += data[i];
        if (data[i] > max) max = data[i];
    }
    return {sum / n, max, n};
}

std::tuple<int, int> divmod(int a, int b) { return {a / b, a % b}; }

int main() {
    int data[] = {4, 8, 15, 16, 23, 42};
    auto [mean, max, count] = summarise(data, 6);              // structured binding
    std::cout << "mean " << mean << ", max " << max << ", n " << count << '\n';

    auto [q, r] = divmod(17, 5);
    std::cout << "17 = 5*" << q << " + " << r << '\n';

    std::map<std::string, int> ages{{"ada", 36}, {"alan", 41}};
    for (const auto& [name, age] : ages)                       // bindings in range-for
        std::cout << name << " is " << age << '\n';

    if (auto it = ages.find("grace"); it == ages.end())        // if with initialiser
        std::cout << "grace not found\n";
    else
        std::cout << "grace is " << it->second << '\n';
}
