// file: when_ct.cpp
#include <iostream>

constexpr long fib(int n) { return n < 2 ? n : fib(n - 1) + fib(n - 2); }
consteval long fib_ct(int n) { return fib(n); }

constinit long counter = fib(10);          // initialised at compile time, but may change later

int main(int argc, char**) {
    constexpr long a = fib(30);            // a constant is required: computed by the compiler
    long b = fib(argc + 29);               // depends on run-time input: computed when the program runs
    static_assert(fib(10) == 55);
    long c = fib_ct(30);                   // must be computed at compile time
    counter += 1;
    std::cout << a << ' ' << b << ' ' << c << ' ' << counter << '\n';
    // long d = fib_ct(argc);              // error: argc is not a constant expression
}
