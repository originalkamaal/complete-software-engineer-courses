// file: bindcopy.cpp
#include <iostream>
#include <map>
#include <string>

int main() {
    std::map<std::string, int> stock{{"apples", 3}, {"pears", 5}};
    for (auto [name, count] : stock) count += 10;          // modifies copies
    std::cout << "after auto:  apples " << stock["apples"] << '\n';
    for (auto& [name, count] : stock) count += 10;         // modifies the map's values
    std::cout << "after auto&: apples " << stock["apples"] << '\n';
    // name is const std::string here either way: map keys cannot be changed in place
}
