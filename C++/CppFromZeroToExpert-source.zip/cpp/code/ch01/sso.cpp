// file: sso.cpp
#include <cstdio>
#include <cstdlib>
#include <new>
#include <string>

static int allocations = 0;
void* operator new(std::size_t n) {                        // count every heap allocation in the program
    ++allocations;
    if (void* p = std::malloc(n)) return p;
    throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

int main() {
    std::printf("sizeof(std::string) = %zu\n", sizeof(std::string));
    for (std::size_t len : {0u, 15u, 16u, 100u}) {
        int before = allocations;
        std::string s(len, 'x');
        const void* inside = &s;
        bool in_object = static_cast<const void*>(s.data()) >= inside &&
                         static_cast<const void*>(s.data()) < static_cast<const char*>(inside) + sizeof s;
        std::printf("length %3zu: capacity %3zu, heap allocations %d, characters stored %s\n", len, s.capacity(),
                    allocations - before, in_object ? "inside the string object" : "on the heap");
    }
}
