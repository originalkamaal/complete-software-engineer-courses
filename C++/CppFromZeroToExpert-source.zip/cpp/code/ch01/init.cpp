// file: init.cpp
#include <iostream>
#include <string>
#include <vector>

struct Point { int x, y; };

int main() {
    int a = 7;                 // copy-initialisation
    int b(7);                  // direct-initialisation
    int c{7};                  // direct-list-initialisation (braces): preferred
    int d{};                   // value-initialisation: zero
    // int e{7.5};             // error: narrowing conversion from double to int
    int f = 7.9;               // allowed (truncates to 7), only a warning with -Wconversion

    std::vector<int> v1(3, 1); // three elements, each 1
    std::vector<int> v2{3, 1}; // two elements: 3 and 1 (initializer_list wins)
    Point p{1, 2};             // aggregate initialisation
    Point q{.x = 5, .y = 6};   // designated initialisers (C++20, must be in member order)

    auto i = 42;               // int
    auto s = std::string{"hi"};// std::string
    auto x = 1.5f;             // float
    const int& r = a;
    auto copy = r;             // int: auto drops the reference and top-level const

    std::cout << a << b << c << d << ' ' << f << '\n';
    std::cout << "v1 size " << v1.size() << ", v2 size " << v2.size() << '\n';
    std::cout << p.x << p.y << q.x << q.y << ' ' << i << s << x << copy << '\n';
}
