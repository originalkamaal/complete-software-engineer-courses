#include <format>
#include <string>
std::string f() { return std::format("{:d}", "text"); }
