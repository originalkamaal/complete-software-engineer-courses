// file: view_trap.cpp
#include <iostream>
#include <string>
#include <string_view>

std::string make_name() { return "a temporary string long enough to be on the heap"; }

int main() {
    std::string_view v = make_name();   // the temporary std::string dies at the end of this line
    std::cout << v << '\n';             // reads freed memory
}
