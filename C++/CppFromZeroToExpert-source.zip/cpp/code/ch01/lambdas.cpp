// file: lambdas.cpp
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

void print(int x) { std::cout << "int " << x << '\n'; }
void print(double x) { std::cout << "double " << x << '\n'; }
void print(const std::string& s, int times = 1) {          // default argument
    for (int i = 0; i < times; ++i) std::cout << "string " << s << '\n';
}

int main() {
    print(3);
    print(3.5);
    print(std::string("hi"), 2);
    // print(3L);   error: ambiguous (long -> int and long -> double are equally good)

    std::vector<int> v{5, 3, 9, 1, 7};
    int threshold = 4;
    auto count = std::count_if(v.begin(), v.end(), [threshold](int x) { return x > threshold; });
    std::cout << count << " values above " << threshold << '\n';

    int calls = 0;
    std::sort(v.begin(), v.end(), [&calls](int a, int b) { ++calls; return a > b; });  // by reference
    std::cout << "sorted descending with " << calls << " comparisons:";
    for (int x : v) std::cout << ' ' << x;
    std::cout << '\n';

    auto make_counter = [] {
        int n = 0;
        return [n]() mutable { return ++n; };          // owns its own copy of n
    };
    auto c1 = make_counter(), c2 = make_counter();
    std::cout << c1() << c1() << c1() << ' ' << c2() << '\n';

    auto add = [](auto a, auto b) { return a + b; };   // generic lambda
    std::cout << add(1, 2) << ' ' << add(std::string("a"), "b") << '\n';
}
