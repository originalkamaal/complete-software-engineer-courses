// file: constexpr.cpp
#include <array>
#include <iostream>

constexpr unsigned long long factorial(int n) {
    unsigned long long r = 1;
    for (int i = 2; i <= n; ++i)
        r *= i;
    return r;
}

consteval int square(int x) { return x * x; }       // compile time only

constexpr std::array<int, 10> make_squares() {
    std::array<int, 10> a{};
    for (int i = 0; i < 10; ++i)
        a[i] = i * i;
    return a;
}

constinit int global_counter = square(4);          // initialised at compile time, still mutable

int main() {
    constexpr auto f20 = factorial(20);             // computed by the compiler
    static_assert(f20 == 2432902008176640000ULL);   // checked at compile time
    constexpr auto squares = make_squares();        // a whole table at compile time
    static_assert(squares[7] == 49);

    int n;
    std::cin >> n;
    std::cout << "factorial(" << n << ") at run time = " << factorial(n) << '\n';
    // square(n);   error: n is not a constant expression
    std::cout << "square(12) = " << square(12) << ", global_counter = " << ++global_counter << '\n';
}
