#include <string>
std::string f() { return 'a' + "bc"; }
