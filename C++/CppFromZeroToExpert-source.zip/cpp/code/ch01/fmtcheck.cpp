// file: fmtcheck.cpp
#include <format>
#include <iostream>
#include <string>

int main() {
    std::cout << std::format("{:>8.2f}|{:<6}|{:#x}\n", 3.14159, "ab", 255);
    std::string runtime_fmt = "{} items, {:.1f}% done\n";             // e.g. read from a config file
    int items = 12; double pct = 37.5;                                 // make_format_args takes lvalues
    std::cout << std::vformat(runtime_fmt, std::make_format_args(items, pct));
    try {
        std::string bad = "{:d}\n";                                    // 'd' is not valid for a string
        std::string arg = "text";
        std::cout << std::vformat(bad, std::make_format_args(arg));
    } catch (const std::format_error& e) {
        std::cout << "format_error: " << e.what() << '\n';
    }
}
