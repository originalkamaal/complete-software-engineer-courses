// file: fiasco/registry.cpp
#include <cstdlib>
#include <string>
static std::string make_name() {                           // cannot run at compile time: reads the environment
    const char* e = std::getenv("SERVICE_NAME");
    return e ? e : "service";
}
std::string default_name = make_name();                    // dynamic initialisation
