// file: fiasco/main.cpp
#include <iostream>
#include <string>
extern std::string default_name;
std::string greeting = "hello, " + default_name;          // uses another file's global during start-up
int main() { std::cout << "[" << greeting << "]\n"; }
