// file: strings.cpp
#include <array>
#include <iostream>
#include <span>
#include <string>
#include <string_view>
#include <vector>

std::string_view first_word(std::string_view s) {          // accepts literals, strings, substrings
    auto end = s.find(' ');
    return s.substr(0, end);                                // no allocation: a view into s
}

int sum(std::span<const int> values) {                      // any contiguous ints
    int total = 0;
    for (int v : values) total += v;
    return total;
}

int main() {
    std::string s = "hello";
    s += ", world";
    s.insert(0, ">> ");
    std::cout << s << " (size " << s.size() << ")\n";
    std::cout << "find world at " << s.find("world") << ", substr: " << s.substr(3, 5) << '\n';
    std::cout << "starts_with \">>\": " << s.starts_with(">>") << '\n';        // C++20

    std::cout << "first word: " << first_word("alpha beta gamma") << '\n';

    std::array<int, 4> arr{1, 2, 3, 4};
    std::vector<int> vec{10, 20, 30};
    int c_array[] = {100, 200};
    std::cout << sum(arr) << ' ' << sum(vec) << ' ' << sum(c_array) << '\n';
    std::cout << "number as text: " << std::to_string(3.25) << ", parsed: " << std::stoi("42") + 1 << '\n';
}
