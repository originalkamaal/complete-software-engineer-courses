// file: format.cpp
#include <format>
#include <iomanip>
#include <iostream>
#include <print>
#include <string>

struct Point { int x, y; };

template <>
struct std::formatter<Point> : std::formatter<std::string> {     // make Point formattable
    auto format(const Point& p, std::format_context& ctx) const {
        return std::formatter<std::string>::format(std::format("({}, {})", p.x, p.y), ctx);
    }
};

int main() {
    double pi = 3.14159265;
    std::cout << "iostream: " << std::fixed << std::setprecision(2) << pi << " [" << std::setw(6) << 42 << "]\n";

    std::string s = std::format("format: {:.3f} [{:>6}] [{:<6}] [{:^6}] {:#x} {:08b}", pi, 42, 42, 42, 255, 5);
    std::cout << s << '\n';

    std::println("print (C++23): {} + {} = {}", 2, 3, 2 + 3);
    std::println("{0} {1} {0}", "positional", "args");
    std::println("custom type: {}", Point{3, 4});
    // std::println("{:d}", "text");   compile error: format string checked at compile time
}
