// file: enums.cpp
#include <cstdint>
#include <iostream>
#include <string_view>

enum class Color : std::uint8_t { Red, Green, Blue };   // scoped, 1 byte
enum class Light { Red, Yellow, Green };                // no clash with Color::Red

namespace app::net {                                   // nested namespace (C++17)
    using Port = std::uint16_t;                         // type alias
    constexpr Port default_port = 8080;
}

std::string_view to_string(Color c) {
    switch (c) {                                        // -Wswitch warns about missing cases
    case Color::Red: return "red";
    case Color::Green: return "green";
    case Color::Blue: return "blue";
    }
    return "?";
}

int main() {
    Color c = Color::Green;
    // int i = c;                        error: no implicit conversion
    int i = static_cast<int>(c);         // explicit
    std::cout << to_string(c) << " = " << i << ", sizeof(Color) = " << sizeof(Color) << '\n';
    std::cout << "port " << app::net::default_port << '\n';

    using enum Light;                    // C++20: bring the enumerators into scope
    Light l = Yellow;
    std::cout << "light " << static_cast<int>(l) << '\n';
}
