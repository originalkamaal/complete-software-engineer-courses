// file: refs.cpp
#include <iostream>
#include <string>

void increment(int& n) { ++n; }                          // modifies the caller's object
std::size_t length(const std::string& s) { return s.size(); }   // no copy, no modification

const std::string& longer(const std::string& a, const std::string& b) {
    return a.size() >= b.size() ? a : b;                  // returns a reference to an argument
}

int main() {
    int x = 1;
    int& alias = x;            // alias is x
    alias = 5;
    increment(x);
    std::cout << "x = " << x << '\n';

    std::cout << "length = " << length("temporary string") << '\n';   // binds to a temporary

    const std::string& lifetime_extended = std::string("I live as long as the reference");
    std::cout << lifetime_extended << '\n';

    std::string s1 = "short", s2 = "much longer";
    std::cout << "longer: " << longer(s1, s2) << '\n';                // fine: s1, s2 outlive the call
}
