// file: grades/grades.cpp
#include <algorithm>
#include <charconv>
#include <iostream>
#include <optional>
#include <print>
#include <string>
#include <string_view>
#include <vector>

struct Student {
    std::string name;
    std::vector<int> scores;
    double mean() const {
        double s = 0;
        for (int x : scores) s += x;
        return s / static_cast<double>(scores.size());
    }
};

// parse_score converts a field to 0..100 with no allocation and no exceptions.
std::optional<int> parse_score(std::string_view field) {
    while (!field.empty() && field.front() == ' ') field.remove_prefix(1);
    while (!field.empty() && field.back() == ' ') field.remove_suffix(1);
    int value{};
    auto [ptr, ec] = std::from_chars(field.data(), field.data() + field.size(), value);
    if (ec != std::errc{} || ptr != field.data() + field.size() || value < 0 || value > 100)
        return std::nullopt;
    return value;
}

// parse_line returns a Student, or an error message.
std::optional<Student> parse_line(std::string_view line, std::string& error) {
    auto comma = line.find(',');
    if (comma == std::string_view::npos || comma == 0) {
        error = "expected name,score[,score...]";
        return std::nullopt;
    }
    Student st{std::string{line.substr(0, comma)}, {}};
    line.remove_prefix(comma + 1);
    while (true) {
        auto next = line.find(',');
        auto field = line.substr(0, next);
        auto score = parse_score(field);
        if (!score) {
            error = std::format("bad score '{}'", field);
            return std::nullopt;
        }
        st.scores.push_back(*score);
        if (next == std::string_view::npos) break;
        line.remove_prefix(next + 1);
    }
    return st;
}

int main() {
    std::vector<Student> students;
    std::string line, error;
    int lineno = 0, bad = 0;
    while (std::getline(std::cin, line)) {
        ++lineno;
        if (line.find_first_not_of(" \t\r") == std::string::npos) continue;
        if (auto st = parse_line(line, error))
            students.push_back(std::move(*st));
        else {
            std::println(stderr, "line {}: {}", lineno, error);
            ++bad;
        }
    }
    std::ranges::sort(students, [](const Student& a, const Student& b) {
        return a.mean() != b.mean() ? a.mean() > b.mean() : a.name < b.name;
    });
    std::println("{:<10} {:>6} {:>6} {:>5}", "name", "scores", "mean", "best");
    double total = 0;
    for (const auto& [name, scores] : students) {
        Student tmp{name, scores};
        total += tmp.mean();
        std::println("{:<10} {:>6} {:>6.1f} {:>5}", name, scores.size(), tmp.mean(), std::ranges::max(scores));
    }
    if (!students.empty())
        std::println("class mean: {:.1f} over {} students", total / static_cast<double>(students.size()), students.size());
    return bad == 0 ? 0 : 1;
}
