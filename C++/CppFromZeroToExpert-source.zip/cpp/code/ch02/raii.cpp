// file: raii.cpp
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

class File {                                 // RAII wrapper for a C FILE*
public:
    File(const std::string& path, const char* mode) : f_{std::fopen(path.c_str(), mode)}, path_{path} {
        if (f_ == nullptr)
            throw std::runtime_error("cannot open " + path);
        std::cout << "  [open " << path_ << "]\n";
    }
    ~File() {
        if (f_) {
            std::fclose(f_);
            std::cout << "  [close " << path_ << "]\n";
        }
    }
    File(const File&) = delete;              // a file handle must not be copied (Unit 2.4)
    File& operator=(const File&) = delete;

    void write_line(const std::string& s) {
        if (std::fprintf(f_, "%s\n", s.c_str()) < 0)
            throw std::runtime_error("write failed");
    }
private:
    std::FILE* f_;
    std::string path_;
};

void process(bool fail_midway) {
    File a{"a.txt", "w"};
    File b{"b.txt", "w"};
    a.write_line("first");
    if (fail_midway)
        throw std::runtime_error("something went wrong");   // both files still closed
    b.write_line("second");
}                                            // destructors run here: b, then a

int main() {
    std::cout << "normal run:\n";
    process(false);
    std::cout << "failing run:\n";
    try {
        process(true);
    } catch (const std::exception& e) {
        std::cout << "caught: " << e.what() << '\n';
    }
}
