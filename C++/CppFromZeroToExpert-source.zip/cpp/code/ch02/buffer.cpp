// file: buffer.cpp
#include <algorithm>
#include <cstddef>
#include <iostream>

class Buffer {                          // owns a heap array: needs the Rule of Three
public:
    explicit Buffer(std::size_t n) : size_{n}, data_{new int[n]{}} {}
    ~Buffer() { delete[] data_; }

    Buffer(const Buffer& other) : size_{other.size_}, data_{new int[other.size_]} {   // deep copy
        std::copy(other.data_, other.data_ + size_, data_);
    }

    Buffer& operator=(const Buffer& other) {        // copy-and-swap: strong exception safety
        Buffer tmp{other};                          // may throw: *this is untouched if it does
        std::swap(size_, tmp.size_);
        std::swap(data_, tmp.data_);
        return *this;                               // tmp's destructor frees our old array
    }

    int& operator[](std::size_t i) { return data_[i]; }
    std::size_t size() const { return size_; }

private:
    std::size_t size_;
    int* data_;
};

int main() {
    Buffer a{3};
    a[0] = 1; a[1] = 2; a[2] = 3;
    Buffer b = a;           // copy constructor
    b[0] = 100;
    Buffer c{1};
    c = a;                  // copy assignment
    c = c;                  // self-assignment must be safe
    std::cout << "a[0]=" << a[0] << " b[0]=" << b[0] << " c[2]=" << c[2] << " c.size=" << c.size() << std::endl;   // endl flushes: see below
}
