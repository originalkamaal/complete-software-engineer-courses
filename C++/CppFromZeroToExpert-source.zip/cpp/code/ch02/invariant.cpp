// file: invariant.cpp
#include <iostream>
#include <stdexcept>

struct Point { double x, y; };                 // no invariant: any x and y are fine

class Range {                                  // invariant: lo <= hi, always
public:
    Range(int lo, int hi) : lo_(lo), hi_(hi) {
        if (lo > hi) throw std::invalid_argument("Range: lo > hi");
    }
    int lo() const { return lo_; }
    int hi() const { return hi_; }
    int width() const { return hi_ - lo_; }    // can rely on the invariant: never negative
    void shift(int d) { lo_ += d; hi_ += d; }  // every member function keeps the invariant
    void set_hi(int h) {
        if (h < lo_) throw std::invalid_argument("Range: hi < lo");
        hi_ = h;
    }
private:
    int lo_, hi_;
};

int main() {
    Point p{1.5, -2};
    p.x = 100;                                 // fine: Point promises nothing
    Range r(3, 10);
    r.shift(5);
    std::cout << "p.x " << p.x << ", range [" << r.lo() << ", " << r.hi() << "] width " << r.width() << '\n';
    try { r.set_hi(0); } catch (const std::exception& e) { std::cout << "rejected: " << e.what() << '\n'; }
    try { Range bad(5, 1); } catch (const std::exception& e) { std::cout << "rejected: " << e.what() << '\n'; }
}
