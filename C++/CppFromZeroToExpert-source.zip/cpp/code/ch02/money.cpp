// file: money.cpp
#include <compare>
#include <iostream>

class Money {
public:
    constexpr explicit Money(long long cents = 0) : cents_{cents} {}
    constexpr long long cents() const { return cents_; }

    Money& operator+=(Money o) { cents_ += o.cents_; return *this; }     // compound: member
    friend Money operator+(Money a, Money b) { return a += b; }         // binary: non-member (friend)
    friend Money operator*(Money a, long long k) { return Money{a.cents_ * k}; }
    Money operator-() const { return Money{-cents_}; }                  // unary minus

    auto operator<=>(const Money&) const = default;   // generates <, <=, >, >= (and == below)
    bool operator==(const Money&) const = default;

    friend std::ostream& operator<<(std::ostream& os, Money m) {        // streaming
        long long c = m.cents_ < 0 ? -m.cents_ : m.cents_;
        return os << (m.cents_ < 0 ? "-" : "") << '$' << c / 100 << '.' << (c % 100 < 10 ? "0" : "") << c % 100;
    }

private:
    long long cents_;
};

int main() {
    Money price{1999}, tax{160};
    Money total = price + tax;
    std::cout << price << " + " << tax << " = " << total << '\n';
    std::cout << "x3: " << total * 3 << ", negated: " << -total << '\n';
    std::cout << std::boolalpha << "price < total: " << (price < total)
              << ", total == $21.59: " << (total == Money{2159}) << '\n';
}
