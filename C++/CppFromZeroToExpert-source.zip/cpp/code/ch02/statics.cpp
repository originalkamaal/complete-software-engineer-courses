// file: statics.cpp
#include <iostream>

class Widget {
public:
    Widget() : id_{++next_id_} { ++alive_; }
    Widget(const Widget&) : id_{++next_id_} { ++alive_; }   // copies get new ids
    ~Widget() { --alive_; }
    Widget& operator=(const Widget&) { return *this; }      // keep our own id
    int id() const { return id_; }
    static int alive() { return alive_; }                   // no this: class-level query
private:
    int id_;
    inline static int next_id_ = 0;                         // one shared counter (C++17 inline)
    inline static int alive_ = 0;
};

int main() {
    Widget a, b;
    {
        Widget c = a;
        std::cout << "ids " << a.id() << b.id() << c.id() << ", alive " << Widget::alive() << '\n';
    }
    std::cout << "after scope, alive " << Widget::alive() << '\n';
}
