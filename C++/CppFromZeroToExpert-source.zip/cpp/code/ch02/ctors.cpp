// file: ctors.cpp
#include <iostream>
#include <string>

class Temperature {
public:
    Temperature() = default;                                   // uses the default member initialisers
    explicit Temperature(double celsius) : celsius_{celsius} {}
    static Temperature from_fahrenheit(double f) { return Temperature{(f - 32) * 5 / 9}; }  // named constructor
    double celsius() const { return celsius_; }
private:
    double celsius_ = 20.0;                                    // default member initialiser
};

void report(Temperature t) { std::cout << t.celsius() << " C\n"; }

class Range {
public:
    Range(int lo, int hi) : hi_{hi}, lo_{lo}, width_{hi_ - lo_} {}   // list order is irrelevant ...
    int width() const { return width_; }
private:
    int lo_, hi_, width_;                                      // ... declaration order is what counts
};

int main() {
    Temperature room;
    report(room);
    report(Temperature{25});
    report(Temperature::from_fahrenheit(212));
    // report(30.0);   error with explicit; without it, 30.0 would silently become a Temperature

    Range r{10, 15};
    std::cout << "width " << r.width() << " (expected 5)\n";
}
