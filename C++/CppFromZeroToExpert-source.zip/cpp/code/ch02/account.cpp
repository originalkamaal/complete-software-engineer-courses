// file: account.cpp
#include <iostream>
#include <stdexcept>
#include <string>

class Account {
public:
    Account(std::string owner, long long cents) : owner_{std::move(owner)}, balance_{cents} {
        if (cents < 0)
            throw std::invalid_argument("opening balance must not be negative");
    }

    void deposit(long long cents) {
        if (cents <= 0) throw std::invalid_argument("deposit must be positive");
        balance_ += cents;
    }

    bool withdraw(long long cents) {        // invariant: balance never negative
        if (cents <= 0 || cents > balance_)
            return false;
        balance_ -= cents;
        return true;
    }

    long long balance() const { return balance_; }      // const: callable on const objects
    const std::string& owner() const { return owner_; }

private:
    std::string owner_;
    long long balance_;                     // in cents: never use floating point for money
};

int main() {
    Account a{"ada", 10'000};
    a.deposit(2'550);
    std::cout << a.owner() << " has " << a.balance() << " cents\n";
    std::cout << "withdraw 20000: " << (a.withdraw(20'000) ? "ok" : "refused") << '\n';
    const Account& view = a;
    std::cout << "via const reference: " << view.balance() << '\n';
    // view.deposit(1);   error: deposit is not const
    // a.balance_ = -5;   error: balance_ is private
    try {
        Account bad{"eve", -1};
    } catch (const std::invalid_argument& e) {
        std::cout << "construction failed: " << e.what() << '\n';
    }
}
