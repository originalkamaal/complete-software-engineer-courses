// file: copyswap.cpp
#include <algorithm>
#include <cstddef>
#include <iostream>
#include <utility>

class IntArray {
public:
    explicit IntArray(std::size_t n) : size_(n), data_(new int[n]{}) {}
    IntArray(const IntArray& o) : size_(o.size_), data_(new int[o.size_]) {
        std::copy(o.data_, o.data_ + size_, data_);
    }
    IntArray& operator=(IntArray other) {        // by value: the copy happens here
        swap(*this, other);                      // cannot fail
        return *this;                            // other's destructor frees our old array
    }
    ~IntArray() { delete[] data_; }
    friend void swap(IntArray& a, IntArray& b) noexcept {
        using std::swap;
        swap(a.size_, b.size_);
        swap(a.data_, b.data_);
    }
    int& operator[](std::size_t i) { return data_[i]; }
    std::size_t size() const { return size_; }
private:
    std::size_t size_;
    int* data_;
};

int main() {
    IntArray a(3), b(5);
    a[0] = 7;
    b = a;                     // b now has 3 elements
    a = a;                     // self-assignment: harmless
    b[1] = 9;
    std::cout << "a: " << a[0] << ' ' << a[1] << " (size " << a.size() << "), b: " << b[0] << ' ' << b[1]
              << " (size " << b.size() << ")\n";
}
