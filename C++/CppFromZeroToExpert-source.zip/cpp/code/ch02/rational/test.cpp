// file: rational/test.cpp
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include "line_reader.hpp"
#include "rational.hpp"

int main() {
    // Rational: invariant and arithmetic
    static_assert(Rational(6, -8) == Rational(-3, 4));          // checked at compile time
    static_assert(Rational(1, 3) + Rational(1, 6) == Rational(1, 2));
    static_assert(Rational(1, 2) < Rational(2, 3));
    Rational r{2, 4};
    assert(r.num() == 1 && r.den() == 2);
    r *= Rational{4};
    assert(r == Rational{2});
    assert(-Rational(1, 3) < Rational(0));
    assert(Rational(7, 3) / Rational(7, 6) == Rational(2));
    std::ostringstream os;
    os << Rational(-10, 4) << ' ' << Rational(8, 4);
    assert(os.str() == "-5/2 2");
    bool threw = false;
    try { Rational bad{1, 0}; } catch (const std::domain_error&) { threw = true; }
    assert(threw);

    // harmonic number H(10) as an exact fraction
    Rational h;
    for (int k = 1; k <= 10; ++k) h += Rational(1, k);
    std::cout << "H(10) = " << h << " ~= " << static_cast<double>(h) << '\n';

    // LineReader: RAII and reading
    { std::ofstream out{"lines.txt"}; out << "alpha\nbeta\n\ngamma"; }   // last line has no newline
    LineReader reader{"lines.txt"};
    std::string all;
    while (auto line = reader.next())
        all += "[" + *line + "]";
    assert(all == "[alpha][beta][][gamma]");
    assert(reader.lines_read() == 4);
    threw = false;
    try { LineReader missing{"no-such-file.txt"}; } catch (const std::runtime_error&) { threw = true; }
    assert(threw);
    std::cout << "lines: " << all << "\nall tests passed\n";
}
