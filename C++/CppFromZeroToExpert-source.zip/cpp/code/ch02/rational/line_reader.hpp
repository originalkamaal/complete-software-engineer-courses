// file: rational/line_reader.hpp
#pragma once
#include <cstdio>
#include <optional>
#include <stdexcept>
#include <string>

class LineReader {                        // owns a FILE*; yields lines one at a time
public:
    explicit LineReader(const std::string& path) : f_{std::fopen(path.c_str(), "r")} {
        if (!f_) throw std::runtime_error("cannot open " + path);
    }
    ~LineReader() { if (f_) std::fclose(f_); }
    LineReader(const LineReader&) = delete;
    LineReader& operator=(const LineReader&) = delete;

    std::optional<std::string> next() {
        std::string line;
        int c;
        while ((c = std::fgetc(f_)) != EOF && c != '\n')
            line.push_back(static_cast<char>(c));
        if (c == EOF && line.empty())
            return std::nullopt;
        ++count_;
        return line;
    }
    int lines_read() const { return count_; }
private:
    std::FILE* f_;
    int count_ = 0;
};
