// file: rational/rational.hpp
#pragma once
#include <compare>
#include <cstdint>
#include <numeric>
#include <ostream>
#include <stdexcept>

class Rational {
public:
    constexpr Rational(std::int64_t num = 0, std::int64_t den = 1) : num_{num}, den_{den} {
        if (den_ == 0)
            throw std::domain_error("zero denominator");
        normalise();
    }
    constexpr std::int64_t num() const { return num_; }
    constexpr std::int64_t den() const { return den_; }

    constexpr Rational& operator+=(const Rational& o) { return *this = Rational{num_ * o.den_ + o.num_ * den_, den_ * o.den_}; }
    constexpr Rational& operator-=(const Rational& o) { return *this = Rational{num_ * o.den_ - o.num_ * den_, den_ * o.den_}; }
    constexpr Rational& operator*=(const Rational& o) { return *this = Rational{num_ * o.num_, den_ * o.den_}; }
    constexpr Rational& operator/=(const Rational& o) { return *this = Rational{num_ * o.den_, den_ * o.num_}; }

    friend constexpr Rational operator+(Rational a, const Rational& b) { return a += b; }
    friend constexpr Rational operator-(Rational a, const Rational& b) { return a -= b; }
    friend constexpr Rational operator*(Rational a, const Rational& b) { return a *= b; }
    friend constexpr Rational operator/(Rational a, const Rational& b) { return a /= b; }
    constexpr Rational operator-() const { return Rational{-num_, den_}; }

    friend constexpr bool operator==(const Rational&, const Rational&) = default;   // normalised: memberwise is right
    friend constexpr std::strong_ordering operator<=>(const Rational& a, const Rational& b) {
        return a.num_ * b.den_ <=> b.num_ * a.den_;     // dens are positive: cross-multiply
    }
    friend std::ostream& operator<<(std::ostream& os, const Rational& r) {
        os << r.num_;
        if (r.den_ != 1) os << '/' << r.den_;
        return os;
    }
    constexpr explicit operator double() const { return static_cast<double>(num_) / static_cast<double>(den_); }

private:
    constexpr void normalise() {                         // establishes the invariant
        std::int64_t g = std::gcd(num_, den_);
        num_ /= g;
        den_ /= g;
        if (den_ < 0) { num_ = -num_; den_ = -den_; }
    }
    std::int64_t num_, den_;
};
