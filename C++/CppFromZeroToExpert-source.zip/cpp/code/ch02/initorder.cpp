// file: initorder.cpp
#include <iostream>
#include <string>

class Message {
public:
    explicit Message(const std::string& text) : text_(text), length_(text_.size()) {}
    // looks fine, but length_ is declared first, so it is initialised first,
    // from text_ — which has not been constructed yet
    std::size_t length() const { return length_; }
private:
    std::size_t length_;
    std::string text_;
};

int main() {
    Message m("hello");
    std::cout << "length " << m.length() << '\n';
}
