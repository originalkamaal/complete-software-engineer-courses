// file: spaceship.cpp
#include <compare>
#include <iostream>
#include <set>
#include <string>

struct Version {
    int major, minor, patch;
    auto operator<=>(const Version&) const = default;   // compares major, then minor, then patch
    bool operator==(const Version&) const = default;
};

struct Reading {
    std::string sensor;
    double value;
    auto operator<=>(const Reading&) const = default;  // partial_ordering because of the double
};

int main() {
    Version a{1, 4, 2}, b{1, 10, 0};
    std::cout << std::boolalpha << "1.4.2 < 1.10.0: " << (a < b) << '\n';
    std::set<Version> vs{{2, 0, 0}, {1, 10, 0}, {1, 4, 2}};
    for (auto& v : vs) std::cout << v.major << '.' << v.minor << '.' << v.patch << ' ';
    std::cout << '\n';

    Reading r1{"t1", 0.0 / 0.0}, r2{"t1", 1.0};                 // a NaN reading
    auto c = r1 <=> r2;
    std::cout << "NaN vs 1.0 unordered: " << (c == std::partial_ordering::unordered)
              << ", r1 < r2: " << (r1 < r2) << ", r1 > r2: " << (r1 > r2) << '\n';
}
