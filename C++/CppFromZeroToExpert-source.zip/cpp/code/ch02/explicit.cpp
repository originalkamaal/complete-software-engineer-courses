// file: explicit.cpp
#include <iostream>

struct Buffer { Buffer(int size) : size(size) {} int size; };              // converting constructor
struct SafeBuffer { explicit SafeBuffer(int size) : size(size) {} int size; };

void upload(const Buffer& b) { std::cout << "uploading a buffer of " << b.size << " bytes\n"; }
void upload_safe(const SafeBuffer& b) { std::cout << "uploading " << b.size << " bytes\n"; }

int main() {
    upload(1024);                   // compiles: an int silently became a Buffer
    upload('A');                    // compiles too: char -> int -> Buffer, 65 bytes
    upload_safe(SafeBuffer(1024));  // the conversion must be written out
    // upload_safe(1024);           // error: no implicit conversion
}
