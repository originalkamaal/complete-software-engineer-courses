// file: regexdemo.cpp
#include <iostream>
#include <regex>
#include <string>

int main() {
    const std::regex line_re(R"((\d{4})-(\d{2})-(\d{2}) (ERROR|WARN|INFO) (.*))");   // compiled once
    for (std::string line : {"2026-11-16 ERROR disk full", "garbage", "2026-11-16 INFO started"}) {
        std::smatch m;
        if (std::regex_match(line, m, line_re))
            std::cout << "year " << m[1] << ", level " << m[4] << ", message '" << m[5] << "'\n";
        else
            std::cout << "no match: " << line << '\n';
    }
    std::string text = "mail ada@example.org or alan@example.net today";
    const std::regex email(R"([\w.]+@[\w.]+)");
    for (std::sregex_iterator it(text.begin(), text.end(), email), end; it != end; ++it)
        std::cout << "found " << it->str() << " at " << it->position() << '\n';
    std::cout << std::regex_replace(text, email, "<hidden>") << '\n';
}
