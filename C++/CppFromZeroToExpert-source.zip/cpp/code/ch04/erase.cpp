// file: erase.cpp
#include <iostream>
#include <vector>

int main() {
    std::vector<int> v{1, 2, 3, 4, 5, 6};
    for (auto it = v.begin(); it != v.end();) {
        if (*it % 2 == 0)
            it = v.erase(it);          // erase returns the next valid iterator: use it
        else
            ++it;
    }
    std::vector<int> w{1, 2, 3, 4, 5, 6};
    std::erase_if(w, [](int x) { return x % 2 == 0; });   // C++20: one line, O(n)
    for (int x : v) std::cout << x << ' ';
    std::cout << "| ";
    for (int x : w) std::cout << x << ' ';
    std::cout << '\n';
}
