// file: viewcache.cpp
#include <iostream>
#include <ranges>
#include <vector>

int main() {
    std::vector<int> v{1, 2, 3, 4, 5, 6};
    auto even = v | std::views::filter([](int x) { return x % 2 == 0; });
    std::cout << "first pass: ";
    for (int x : even) std::cout << x << ' ';
    v[0] = 100;                                   // now the first even element is at index 0
    std::cout << "\nsecond pass (cached begin skips the new 100): ";
    for (int x : even) std::cout << x << ' ';
    auto fresh = v | std::views::filter([](int x) { return x % 2 == 0; });
    std::cout << "\nfresh view: ";
    for (int x : fresh) std::cout << x << ' ';
    std::cout << '\n';
    // void print(const auto& r); print(even);   // error: filter_view has no const begin()
}
