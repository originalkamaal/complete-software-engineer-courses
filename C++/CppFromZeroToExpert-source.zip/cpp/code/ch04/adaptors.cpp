// file: adaptors.cpp
#include <iostream>
#include <optional>
#include <queue>
#include <string>
#include <vector>

struct Task { int priority; std::string name; };

std::optional<int> find_index(const std::vector<std::string>& v, const std::string& key) {
    for (std::size_t i = 0; i < v.size(); ++i)
        if (v[i] == key) return static_cast<int>(i);
    return std::nullopt;
}

int main() {
    auto cmp = [](const Task& a, const Task& b) { return a.priority < b.priority; };   // max-heap
    std::priority_queue<Task, std::vector<Task>, decltype(cmp)> pq{cmp};
    pq.push({2, "write tests"});
    pq.push({5, "fix outage"});
    pq.push({1, "refactor"});
    while (!pq.empty()) {
        std::cout << pq.top().priority << ' ' << pq.top().name << '\n';
        pq.pop();
    }

    std::vector<std::string> names{"ada", "alan", "grace"};
    if (auto i = find_index(names, "alan")) std::cout << "alan at " << *i << '\n';
    std::cout << "bob at " << find_index(names, "bob").value_or(-1) << '\n';
}
