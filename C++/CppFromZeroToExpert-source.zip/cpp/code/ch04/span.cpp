// file: span.cpp
#include <array>
#include <iostream>
#include <numeric>
#include <span>
#include <vector>

double average(std::span<const int> xs) {
    return xs.empty() ? 0.0 : std::accumulate(xs.begin(), xs.end(), 0.0) / static_cast<double>(xs.size());
}
void zero_first(std::span<int> xs, std::size_t n) {
    for (int& x : xs.first(std::min(n, xs.size()))) x = 0;
}

int main() {
    std::vector<int> v{2, 4, 6, 8};
    std::array<int, 3> a{1, 2, 3};
    int c[] = {10, 20, 30, 40, 50};
    std::cout << average(v) << ' ' << average(a) << ' ' << average(c) << ' '
              << average(std::span(c).subspan(1, 3)) << '\n';
    zero_first(c, 2);
    std::cout << c[0] << ' ' << c[1] << ' ' << c[2] << '\n';
    std::array<int, 3> b = a;                       // arrays copy like values
    b[0] = 99;
    std::cout << "a[0] " << a[0] << ", b[0] " << b[0] << ", sizeof(span<int>) " << sizeof(std::span<int>) << '\n';
}
