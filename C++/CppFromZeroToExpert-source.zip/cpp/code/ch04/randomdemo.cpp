// file: randomdemo.cpp
#include <iostream>
#include <map>
#include <random>

int main() {
    std::mt19937 engine(42);                                  // fixed seed: the same sequence every run
    std::uniform_int_distribution<int> die(1, 6);
    std::normal_distribution<double> height(170.0, 10.0);
    std::map<int, int> counts;
    for (int i = 0; i < 60000; ++i) ++counts[die(engine)];
    for (auto [face, n] : counts) std::cout << face << ": " << n << '\n';
    double sum = 0;
    for (int i = 0; i < 10000; ++i) sum += height(engine);
    std::cout << "average height " << sum / 10000 << '\n';
    std::random_device rd;                                    // non-deterministic seed source
    std::mt19937 seeded(rd());
    std::cout << "a seeded die roll is between 1 and 6: " << std::boolalpha << (die(seeded) >= 1) << '\n';
}
