// file: fsdemo.cpp
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <system_error>

namespace fs = std::filesystem;

int main() {
    fs::path root = fs::temp_directory_path() / "fsdemo";
    fs::remove_all(root);                                          // start clean; no error if missing
    fs::create_directories(root / "src" / "util");
    for (auto name : {"src/main.cpp", "src/util/str.cpp", "src/util/str.hpp", "README.md"}) {
        std::ofstream(root / name) << "// " << name << '\n';      // a temporary stream: written and closed
    }

    fs::path p = root / "src" / "util" / "str.cpp";
    std::cout << "filename " << p.filename() << ", stem " << p.stem() << ", extension " << p.extension()
              << ", parent ends in " << p.parent_path().filename() << '\n';

    std::map<std::string, int> by_ext;
    std::uintmax_t bytes = 0;
    for (const auto& e : fs::recursive_directory_iterator(root)) {
        if (!e.is_regular_file()) continue;
        ++by_ext[e.path().extension().string()];
        bytes += e.file_size();
    }
    for (const auto& [ext, n] : by_ext) std::cout << ext << ": " << n << '\n';
    std::cout << "total bytes " << bytes << '\n';

    std::ifstream in(root / "README.md");
    std::string line;
    std::getline(in, line);
    std::cout << "README first line: " << line << '\n';

    std::error_code ec;                                            // the non-throwing overloads
    auto size = fs::file_size(root / "missing.txt", ec);
    std::cout << "missing.txt: " << (ec ? ec.message() : std::to_string(size)) << '\n';
    try {
        (void)fs::file_size(root / "missing.txt");                 // the throwing overload
    } catch (const fs::filesystem_error& e) {
        std::cout << std::boolalpha << "filesystem_error mentions the path: " << (std::string(e.what()).find("missing.txt") != std::string::npos) << '\n';
    }
    std::cout << "removed " << fs::remove_all(root) << " entries\n";
}
