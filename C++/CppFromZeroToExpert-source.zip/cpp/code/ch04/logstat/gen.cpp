// file: logstat/gen.cpp
// Generates a reproducible synthetic access log.
#include <cstdio>
#include <random>

int main(int argc, char* argv[]) {
    int n = argc > 1 ? std::atoi(argv[1]) : 100000;
    std::mt19937 rng{2026};
    const char* paths[] = {"/", "/login", "/api/users", "/api/orders", "/static/app.js", "/static/style.css",
                           "/api/search", "/health", "/admin", "/api/orders/42"};
    std::discrete_distribution<int> path_dist{30, 5, 15, 10, 12, 12, 8, 4, 1, 3};    // skewed popularity
    std::discrete_distribution<int> status_dist{90, 3, 5, 2};
    const int statuses[] = {200, 304, 404, 500};
    std::lognormal_distribution<double> latency{2.5, 0.7};                           // long tail
    for (int i = 0; i < n; ++i) {
        long long sec = static_cast<long long>(i) * 86400 / n;   // i * 86400 overflows int
        if (i % 997 == 0) { std::puts("garbage line"); continue; }
        std::printf("2026-11-15T%02lld:%02lld:%02lldZ GET %s %d %.1f\n", sec / 3600, sec / 60 % 60, sec % 60,
                    paths[path_dist(rng)], statuses[status_dist(rng)], latency(rng));
    }
}
