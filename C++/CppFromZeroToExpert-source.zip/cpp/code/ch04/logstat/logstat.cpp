// file: logstat/logstat.cpp
#include <algorithm>
#include <array>
#include <charconv>
#include <chrono>
#include <iostream>
#include <map>
#include <optional>
#include <print>
#include <ranges>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

struct Entry {
    int hour;
    std::string_view path;
    int status;
    double latency_ms;
};

// parse splits on spaces; returns nullopt for malformed lines. Views point into 'line'.
std::optional<Entry> parse(std::string_view line) {
    std::array<std::string_view, 5> f;
    std::size_t n = 0;
    for (auto part : line | std::views::split(' ')) {
        if (n == f.size()) return std::nullopt;
        f[n++] = std::string_view(part.begin(), part.end());
    }
    if (n != 5 || f[0].size() < 13) return std::nullopt;
    Entry e{};
    auto ok = [](auto r, std::string_view s) { return r.ec == std::errc{} && r.ptr == s.data() + s.size(); };
    if (!ok(std::from_chars(f[0].data() + 11, f[0].data() + 13, e.hour), f[0].substr(11, 2)) ||
        !ok(std::from_chars(f[3].data(), f[3].data() + f[3].size(), e.status), f[3]) ||
        !ok(std::from_chars(f[4].data(), f[4].data() + f[4].size(), e.latency_ms), f[4]))
        return std::nullopt;
    e.path = f[2];
    return e;
}

template <typename Map>
double count_paths(const std::vector<Entry>& entries, Map& counts) {
    auto t0 = std::chrono::steady_clock::now();
    for (const auto& e : entries)
        ++counts[e.path];
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    std::vector<std::string> lines;                    // owns the text the views point into
    for (std::string line; std::getline(std::cin, line);)
        lines.push_back(std::move(line));
    std::vector<Entry> entries;
    entries.reserve(lines.size());
    for (const auto& l : lines)
        if (auto e = parse(l)) entries.push_back(*e);
    const auto malformed = lines.size() - entries.size();

    std::unordered_map<std::string_view, long> by_path;
    std::map<std::string_view, long> by_path_ordered;
    double t_hash = count_paths(entries, by_path);
    double t_tree = count_paths(entries, by_path_ordered);

    std::array<long, 6> by_class{};
    for (const auto& e : entries) ++by_class[std::clamp(e.status / 100, 0, 5)];

    std::vector<std::pair<std::string_view, long>> top(by_path.begin(), by_path.end());
    auto k = std::min<std::size_t>(5, top.size());
    std::ranges::partial_sort(top, top.begin() + static_cast<long>(k), std::ranges::greater{}, &std::pair<std::string_view, long>::second);

    std::vector<double> lat;
    std::ranges::transform(entries, std::back_inserter(lat), &Entry::latency_ms);
    auto pct = [&lat](double p) {
        auto idx = static_cast<std::size_t>(p * static_cast<double>(lat.size() - 1));
        std::ranges::nth_element(lat, lat.begin() + static_cast<long>(idx));
        return lat[idx];
    };

    std::array<long, 24> per_hour{};
    for (int h : entries | std::views::transform(&Entry::hour)) ++per_hour[static_cast<std::size_t>(h) % 24];
    auto busiest = std::ranges::max_element(per_hour) - per_hour.begin();

    std::println("requests: {} parsed, {} malformed", entries.size(), malformed);
    std::println("status: 2xx={} 3xx={} 4xx={} 5xx={}", by_class[2], by_class[3], by_class[4], by_class[5]);
    std::println("top paths:");
    for (const auto& [path, count] : top | std::views::take(k))
        std::println("  {:<20} {:>7}", path, count);
    std::println("latency ms: p50={:.1f} p90={:.1f} p99={:.1f}", pct(0.50), pct(0.90), pct(0.99));
    std::println("busiest hour: {:02}:00 with {} requests", busiest, per_hour[static_cast<std::size_t>(busiest)]);
    std::println("counting {} entries: unordered_map {:.1f} ms, map {:.1f} ms", entries.size(), t_hash, t_tree);
}
