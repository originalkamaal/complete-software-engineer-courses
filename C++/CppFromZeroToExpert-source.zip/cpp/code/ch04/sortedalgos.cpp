// file: sortedalgos.cpp
#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

int main() {
    std::vector<int> v{5, 1, 4, 1, 5, 9, 2, 6};
    std::cout << std::boolalpha << "binary_search(2) on unsorted data: " << std::binary_search(v.begin(), v.end(), 2) << '\n';
    std::vector<int> u = v;
    u.erase(std::unique(u.begin(), u.end()), u.end());
    std::cout << "unique on unsorted data leaves " << u.size() << " of 8 elements\n";

    std::sort(v.begin(), v.end());
    std::cout << "binary_search(2) after sort: " << std::binary_search(v.begin(), v.end(), 2) << '\n';
    v.erase(std::unique(v.begin(), v.end()), v.end());
    std::cout << "unique after sort: ";
    std::copy(v.begin(), v.end(), std::ostream_iterator<int>(std::cout, " "));
    auto [lo, hi] = std::equal_range(v.begin(), v.end(), 5);
    std::cout << "\nposition of 5: " << (lo - v.begin()) << ", count " << (hi - lo) << '\n';

    std::vector<int> a{1, 3, 5, 7, 9}, b{3, 4, 5, 6, 7}, both;
    std::set_intersection(a.begin(), a.end(), b.begin(), b.end(), std::back_inserter(both));
    std::cout << "intersection: ";
    for (int x : both) std::cout << x << ' ';
    std::cout << '\n';
}
