// file: chronodemo.cpp
#include <chrono>
#include <iostream>
#include <thread>

using namespace std::chrono_literals;

int main() {
    std::chrono::milliseconds timeout = 2s + 500ms;           // converted exactly: 2500ms
    auto minutes = std::chrono::duration_cast<std::chrono::minutes>(90s);   // truncates: lossy, so explicit
    std::cout << timeout << ", 90s is " << minutes << " when truncated\n";
    // std::chrono::seconds s = 1500ms;                        // error: would lose precision implicitly

    auto t0 = std::chrono::steady_clock::now();               // steady: for measuring intervals
    std::this_thread::sleep_for(20ms);
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0);
    std::cout << "slept at least 20ms: " << std::boolalpha << (elapsed >= 20ms) << '\n';

    using namespace std::chrono;
    year_month_day d = 2024y / February / 29;                  // C++20 calendar types
    std::cout << d << " valid: " << d.ok() << ", 2023-02-29 valid: " << (2023y / February / 29).ok() << '\n';
    sys_days next = sys_days(d) + days(1);
    std::cout << "day after: " << year_month_day(next) << ", weekday " << weekday(next) << '\n';
    std::cout << "days from 2024-01-01 to 2026-11-16: " << (sys_days(2026y / November / 16) - sys_days(2024y / January / 1)).count() << '\n';
}
