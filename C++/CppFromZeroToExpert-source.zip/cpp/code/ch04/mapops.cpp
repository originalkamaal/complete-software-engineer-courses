// file: mapops.cpp
#include <iostream>
#include <map>
#include <memory>
#include <string>

int main() {
    std::map<std::string, std::unique_ptr<int>> m;
    auto p = std::make_unique<int>(1);
    auto [it, inserted] = m.try_emplace("a", std::move(p));
    auto q = std::make_unique<int>(2);
    auto [it2, inserted2] = m.try_emplace("a", std::move(q));   // "a" exists: q is NOT moved from
    std::cout << std::boolalpha << "first insert " << inserted << ", second insert " << inserted2
              << ", q still owns its int: " << (q != nullptr) << '\n';

    m.insert_or_assign("a", std::make_unique<int>(10));
    std::cout << "a = " << *m["a"] << '\n';

    std::map<std::string, int> ages{{"alice", 30}, {"bob", 25}};
    auto node = ages.extract("bob");
    node.key() = "robert";                                      // change a key without copying the value
    ages.insert(std::move(node));
    for (auto& [name, age] : ages) std::cout << name << ' ' << age << '\n';
}
