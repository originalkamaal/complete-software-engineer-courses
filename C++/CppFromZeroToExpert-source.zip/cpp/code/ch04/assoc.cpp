// file: assoc.cpp
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <unordered_map>

struct Point {
    int x, y;
    bool operator==(const Point&) const = default;
};

struct PointHash {                                   // a hash for a user-defined key
    std::size_t operator()(const Point& p) const noexcept {
        std::size_t h = std::hash<int>{}(p.x);
        return h ^ (std::hash<int>{}(p.y) + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2));   // hash_combine
    }
};

int main() {
    std::map<std::string, int> stock{{"pear", 3}, {"apple", 5}};
    stock["banana"] += 7;                             // operator[] inserts a default value if absent
    stock.insert({"apple", 100});                     // insert does NOT overwrite
    stock.insert_or_assign("pear", 9);                // this does
    if (auto [it, inserted] = stock.try_emplace("kiwi", 2); inserted)
        std::cout << "added " << it->first << '\n';
    for (const auto& [fruit, n] : stock)              // sorted by key
        std::cout << fruit << '=' << n << ' ';
    std::cout << '\n';

    if (stock.contains("plum") == false)              // C++20; count() before that
        std::cout << "no plums; lookups with find() don't insert: size still " << stock.size() << '\n';

    auto lo = stock.lower_bound("b"), hi = stock.upper_bound("k");   // range query: keys in [b, k]
    std::cout << "keys from b to k:";
    for (auto it = lo; it != hi; ++it) std::cout << ' ' << it->first;
    std::cout << '\n';

    std::unordered_map<Point, std::string, PointHash> grid{{{0, 0}, "origin"}, {{3, 4}, "target"}};
    std::cout << "grid[3,4] = " << grid.at({3, 4}) << ", buckets " << grid.bucket_count()
              << ", load factor " << grid.load_factor() << '\n';

    std::set<int> s{5, 1, 4, 1, 3};                   // unique, sorted
    std::multiset<int> ms{5, 1, 4, 1, 3};             // duplicates allowed
    std::cout << "set size " << s.size() << ", multiset size " << ms.size() << ", count(1) " << ms.count(1) << '\n';
}
