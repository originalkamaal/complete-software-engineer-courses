// file: ranges.cpp
#include <algorithm>
#include <iostream>
#include <ranges>
#include <string>
#include <vector>

struct Employee { std::string name; int salary; };

int main() {
    std::vector<Employee> staff{{"ada", 120}, {"bob", 80}, {"cy", 95}, {"ed", 150}, {"flo", 70}};

    std::ranges::sort(staff, std::ranges::greater{}, &Employee::salary);   // projection: sort by salary
    for (const auto& e : staff) std::cout << e.name << ' ';
    std::cout << '\n';

    auto it = std::ranges::find(staff, "cy", &Employee::name);              // project, then compare
    std::cout << "cy earns " << it->salary << '\n';

    namespace vw = std::views;
    auto squares_of_odds = vw::iota(1)                         // 1, 2, 3, ... (infinite, lazy)
                         | vw::filter([](int n) { return n % 2 == 1; })
                         | vw::transform([](int n) { return n * n; })
                         | vw::take(5);
    for (int x : squares_of_odds) std::cout << x << ' ';      // computed only as needed
    std::cout << '\n';

    for (const auto& name : staff | vw::transform(&Employee::name) | vw::reverse)
        std::cout << name << ' ';
    std::cout << '\n';

    std::string csv = "red,green,,blue";
    for (auto part : csv | vw::split(','))                     // lazy split
        std::cout << '[' << std::string_view(part.begin(), part.end()) << ']';
    std::cout << '\n';

    for (auto [i, e] : vw::enumerate(staff) | vw::take(2))     // C++23 enumerate
        std::cout << i << ':' << e.name << ' ';
    std::cout << '\n';
}
