// file: vecbool.cpp
#include <iostream>
#include <type_traits>
#include <vector>

int main() {
    std::vector<bool> flags(8, false);
    auto first = flags[0];                       // a proxy, not a copy of the bool
    flags[0] = true;
    std::cout << std::boolalpha << "auto copy sees the later change: " << bool(first) << '\n';
    std::cout << "flags[0] is a bool&: " << std::is_same_v<decltype(flags[0]), bool&> << '\n';
    std::cout << "sizeof(vector<bool>) " << sizeof(flags) << ", and 8 flags fit in one byte of storage\n";
}
