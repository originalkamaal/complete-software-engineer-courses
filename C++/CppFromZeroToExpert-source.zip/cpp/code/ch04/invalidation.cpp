// file: invalidation.cpp
#include <iostream>
#include <vector>

int main() {
    std::cout << std::unitbuf;         // flush after every output: the program aborts below
    std::vector<int> v{1, 2, 3};
    int& first = v[0];                 // reference into the vector's buffer
    auto it = v.begin();
    std::cout << "capacity before " << v.capacity() << '\n';
    v.push_back(4);                    // capacity 3 -> 6: reallocation moves every element
    std::cout << "capacity after " << v.capacity() << '\n';
    std::cout << first << ' ' << *it << '\n';   // both dangle: reading freed memory
}
