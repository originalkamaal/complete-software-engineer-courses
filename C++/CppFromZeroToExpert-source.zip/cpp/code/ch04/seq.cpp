// file: seq.cpp
#include <chrono>
#include <deque>
#include <iostream>
#include <list>
#include <numeric>
#include <vector>

template <typename C>
long long time_sum(const C& c) {
    auto t0 = std::chrono::steady_clock::now();
    long long s = 0;
    for (int rep = 0; rep < 20; ++rep)
        s += std::accumulate(c.begin(), c.end(), 0LL);
    auto t1 = std::chrono::steady_clock::now();
    std::cout << std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count() << " ms ";
    return s;
}

int main() {
    const int n = 2'000'000;
    std::vector<int> v(n, 1);
    std::deque<int> d(n, 1);
    std::list<int> l(n, 1);
    std::cout << "sum 20x over 2M ints: vector "; auto a = time_sum(v);
    std::cout << "| deque "; auto b = time_sum(d);
    std::cout << "| list "; auto c = time_sum(l);
    std::cout << "(checksums " << a << ' ' << b << ' ' << c << ")\n";   // using the results keeps the work

    std::vector<int> w;
    std::cout << "capacity growth:";
    std::size_t last = 0;
    for (int i = 0; i < 100; ++i) {
        w.push_back(i);
        if (w.capacity() != last) { last = w.capacity(); std::cout << ' ' << last; }
    }
    std::cout << '\n';
    w.reserve(1000);                           // pre-allocate when the size is known
    w.shrink_to_fit();                         // non-binding request to release spare capacity
    std::cout << "after reserve(1000) and shrink_to_fit: capacity " << w.capacity() << '\n';
}
