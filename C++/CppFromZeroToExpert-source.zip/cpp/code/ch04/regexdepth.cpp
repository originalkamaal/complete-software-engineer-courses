// file: regexdepth.cpp
#include <iostream>
#include <regex>
#include <string>

int main(int argc, char** argv) {
    std::size_t n = argc > 1 ? std::stoul(argv[1]) : 1000;
    std::string input(n, 'a');
    std::cout << "length " << n << ": " << std::flush;
    bool ok = std::regex_match(input, std::regex("(a|b)*"));
    std::cout << (ok ? "matched" : "no match") << '\n';
}
