// file: algos.cpp
#include <algorithm>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

struct Employee { std::string name; std::string dept; int salary; };

int main() {
    std::vector<Employee> staff{
        {"ada", "eng", 120}, {"bob", "ops", 80}, {"cy", "eng", 95}, {"di", "ops", 80},
        {"ed", "eng", 150}, {"flo", "sales", 70}, {"gus", "sales", 90},
    };

    auto rich = std::count_if(staff.begin(), staff.end(), [](const Employee& e) { return e.salary >= 100; });
    auto total = std::accumulate(staff.begin(), staff.end(), 0, [](int s, const Employee& e) { return s + e.salary; });
    std::cout << rich << " earn >= 100; payroll " << total << '\n';

    // stable_sort keeps the original order among equal keys
    std::stable_sort(staff.begin(), staff.end(), [](const auto& a, const auto& b) { return a.salary > b.salary; });
    for (const auto& e : staff) std::cout << e.name << ':' << e.salary << ' ';
    std::cout << '\n';

    // top 3 by salary without sorting everything: O(n log k)
    std::vector<Employee> top(3, Employee{});
    std::partial_sort_copy(staff.begin(), staff.end(), top.begin(), top.end(),
                           [](const auto& a, const auto& b) { return a.salary > b.salary; });
    std::cout << "top 3: " << top[0].name << ' ' << top[1].name << ' ' << top[2].name << '\n';

    // median salary in O(n): nth_element partially orders around the middle
    std::vector<int> sal;
    std::transform(staff.begin(), staff.end(), std::back_inserter(sal), [](const auto& e) { return e.salary; });
    std::nth_element(sal.begin(), sal.begin() + sal.size() / 2, sal.end());
    std::cout << "median " << sal[sal.size() / 2] << '\n';

    // partition: engineers first
    auto mid = std::stable_partition(staff.begin(), staff.end(), [](const auto& e) { return e.dept == "eng"; });
    std::cout << "engineers: " << (mid - staff.begin()) << ", first non-engineer: " << mid->name << '\n';

    // binary search on sorted data
    std::vector<int> sorted{2, 3, 5, 7, 11, 13, 17};
    auto lb = std::lower_bound(sorted.begin(), sorted.end(), 10);
    std::cout << "first prime >= 10: " << *lb << ", is 13 present: " << std::binary_search(sorted.begin(), sorted.end(), 13) << '\n';
}
