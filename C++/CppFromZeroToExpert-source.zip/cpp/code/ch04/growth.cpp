// file: growth.cpp
#include <cstdio>
#include <vector>

int main() {
    std::vector<int> v;
    std::size_t last = v.capacity();
    int reallocations = 0;
    std::printf("capacity after push_back: ");
    for (int i = 0; i < 1000; ++i) {
        v.push_back(i);
        if (v.capacity() != last) { last = v.capacity(); ++reallocations; std::printf("%zu ", last); }
    }
    std::printf("\nreallocations for 1000 elements: %d\n", reallocations);

    std::vector<int> w;
    w.reserve(1000);
    const int* before = w.data();
    for (int i = 0; i < 1000; ++i) w.push_back(i);
    std::printf("with reserve(1000): buffer moved? %s\n", w.data() == before ? "no" : "yes");

    v.clear();
    std::printf("after clear(): size %zu, capacity %zu\n", v.size(), v.capacity());
    v.shrink_to_fit();
    std::printf("after shrink_to_fit(): capacity %zu\n", v.capacity());
}
