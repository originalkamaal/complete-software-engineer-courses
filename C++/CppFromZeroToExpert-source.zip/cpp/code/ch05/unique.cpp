// file: unique.cpp
#include <cstdio>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

struct Shape {
    virtual ~Shape() = default;                       // virtual destructor: deleting via Shape* is safe
    virtual double area() const = 0;
};
struct Circle : Shape { double r; explicit Circle(double r) : r{r} {} double area() const override { return 3.14159 * r * r; } };
struct Square : Shape { double s; explicit Square(double s) : s{s} {} double area() const override { return s * s; } };

std::unique_ptr<Shape> make_shape(char kind, double size) {   // factory: returns ownership
    if (kind == 'c') return std::make_unique<Circle>(size);
    return std::make_unique<Square>(size);
}

void consume(std::unique_ptr<Shape> s) {                     // sink: takes ownership
    std::cout << "consumed shape with area " << s->area() << '\n';
}                                                            // deleted here

struct FileCloser { void operator()(std::FILE* f) const { if (f) { std::fclose(f); std::cout << "  file closed\n"; } } };
using FilePtr = std::unique_ptr<std::FILE, FileCloser>;      // RAII for FILE* in one line

int main() {
    std::vector<std::unique_ptr<Shape>> shapes;              // a container of owned, polymorphic objects
    shapes.push_back(make_shape('c', 1.0));
    shapes.push_back(make_shape('s', 2.0));
    for (const auto& s : shapes) std::cout << s->area() << ' ';
    std::cout << '\n';

    auto mine = make_shape('s', 3.0);
    // auto copy = mine;            error: unique_ptr cannot be copied
    consume(std::move(mine));       // explicit transfer
    std::cout << "after move, mine is " << (mine ? "non-null" : "null") << '\n';

    {
        FilePtr f{std::fopen("unique_demo.txt", "w")};
        std::fprintf(f.get(), "hello\n");                    // get(): the raw pointer, non-owning
    }
    std::cout << "sizeof(unique_ptr<Shape>) = " << sizeof(std::unique_ptr<Shape>)
              << ", sizeof(FilePtr) = " << sizeof(FilePtr) << '\n';
}
