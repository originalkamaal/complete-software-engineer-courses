#include <string>
int main(){ auto* p = new std::string[3]; delete p; }
