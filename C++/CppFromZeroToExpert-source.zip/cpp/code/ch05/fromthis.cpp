// file: fromthis.cpp
#include <functional>
#include <iostream>
#include <memory>
#include <vector>

std::vector<std::function<void()>> pending;           // a simple "event loop" queue

class Session : public std::enable_shared_from_this<Session> {
public:
    explicit Session(int id) : id_(id) {}
    ~Session() { std::cout << "session " << id_ << " destroyed\n"; }
    void start() {
        auto self = shared_from_this();               // keeps the session alive inside the callback
        pending.push_back([self] { std::cout << "callback for session " << self->id_ << '\n'; });
    }
private:
    int id_;
};

int main() {
    std::make_shared<Session>(1)->start();            // the caller's pointer dies immediately ...
    std::cout << "caller dropped its pointer\n";
    for (auto& f : pending) f();                      // ... but the session is still alive here
    pending.clear();                                  // last owner gone: destroyed now
    std::cout << "done\n";
    try {
        Session on_stack(2);
        on_stack.start();                             // not owned by any shared_ptr
    } catch (const std::bad_weak_ptr& e) {
        std::cout << "bad_weak_ptr: " << e.what() << '\n';
    }
}
