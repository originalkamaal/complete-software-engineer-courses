// file: placement.cpp
#include <cstdio>
#include <memory>
#include <new>
#include <string>

struct Loud {
    std::string name;
    explicit Loud(std::string n) : name(std::move(n)) { std::printf("construct %s\n", name.c_str()); }
    ~Loud() { std::printf("destroy %s\n", name.c_str()); }
};

int main() {
    alignas(Loud) unsigned char storage[sizeof(Loud)];   // raw bytes, no object yet
    Loud* p = new (storage) Loud("in-place");             // construct inside our buffer
    std::printf("object lives at the start of the buffer: %s\n", static_cast<void*>(p) == storage ? "yes" : "no");
    p->~Loud();                                           // destroy explicitly; nothing to free
    std::destroy_at(std::construct_at(p, "again"));       // C++20 spelling of the same two steps
}
