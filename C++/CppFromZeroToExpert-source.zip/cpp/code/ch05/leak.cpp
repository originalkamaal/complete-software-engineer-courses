// file: leak.cpp
#include <iostream>
#include <stdexcept>
#include <string>

struct Widget {
    std::string name;
    explicit Widget(std::string n) : name{std::move(n)} {}
};

void risky(bool fail) {
    Widget* w = new Widget{"manual"};
    if (fail)
        throw std::runtime_error("oops");   // leak: delete is never reached
    delete w;
}

int main() {
    try {
        risky(true);
    } catch (const std::exception& e) {
        std::cout << "caught " << e.what() << '\n';
    }
    int* arr = new int[10];
    delete arr;                             // wrong form: must be delete[]
}
