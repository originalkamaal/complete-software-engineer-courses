// file: scene/scene.cpp
#include <cassert>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

struct Texture {
    static inline int alive = 0, loads = 0;
    std::string path;
    explicit Texture(std::string p) : path{std::move(p)} { ++alive; ++loads; }
    ~Texture() { --alive; }
};

class AssetCache {                                  // observes textures; never keeps them alive
public:
    std::shared_ptr<const Texture> get(const std::string& path) {
        if (auto it = cache_.find(path); it != cache_.end())
            if (auto tex = it->second.lock())       // still alive somewhere: reuse it
                return tex;
        auto tex = std::make_shared<const Texture>(path);
        cache_[path] = tex;                         // store a weak reference only
        return tex;
    }
    std::size_t purge() {                           // forget entries whose textures died
        return std::erase_if(cache_, [](const auto& kv) { return kv.second.expired(); });
    }
private:
    std::unordered_map<std::string, std::weak_ptr<const Texture>> cache_;
};

class Node {
public:
    static inline int alive = 0;
    explicit Node(std::string name, std::shared_ptr<const Texture> tex = nullptr)
        : name_{std::move(name)}, tex_{std::move(tex)} { ++alive; }
    ~Node() { --alive; }
    Node(const Node&) = delete;
    Node& operator=(const Node&) = delete;

    Node& add_child(std::unique_ptr<Node> child) {   // takes ownership
        child->parent_ = this;                       // non-owning back pointer
        children_.push_back(std::move(child));
        return *children_.back();
    }
    std::unique_ptr<Node> detach(const std::string& name) {   // gives ownership back
        for (auto it = children_.begin(); it != children_.end(); ++it)
            if ((*it)->name_ == name) {
                auto node = std::move(*it);
                children_.erase(it);
                node->parent_ = nullptr;
                return node;
            }
        return nullptr;
    }
    std::string path() const { return parent_ ? parent_->path() + "/" + name_ : name_; }
    int count() const {
        int n = 1;
        for (const auto& c : children_) n += c->count();
        return n;
    }
    const Node* find(const std::string& name) const {
        if (name_ == name) return this;
        for (const auto& c : children_)
            if (auto f = c->find(name)) return f;
        return nullptr;
    }
private:
    std::string name_;
    std::shared_ptr<const Texture> tex_;
    Node* parent_ = nullptr;                          // safe: a parent always outlives its children
    std::vector<std::unique_ptr<Node>> children_;
};

int main() {
    AssetCache cache;
    {
        Node root{"world"};
        auto& level = root.add_child(std::make_unique<Node>("level1"));
        auto& house = level.add_child(std::make_unique<Node>("house", cache.get("brick.png")));
        house.add_child(std::make_unique<Node>("door", cache.get("wood.png")));
        house.add_child(std::make_unique<Node>("wall", cache.get("brick.png")));   // reused
        level.add_child(std::make_unique<Node>("tree", cache.get("wood.png")));    // reused

        std::cout << "nodes: " << root.count() << ", textures loaded: " << Texture::loads
                  << ", alive: " << Texture::alive << '\n';
        std::cout << "path of door: " << root.find("door")->path() << '\n';

        auto tree = level.detach("tree");             // ownership moves out of the graph
        std::cout << "after detach: nodes in graph " << root.count() << ", detached path " << tree->path() << '\n';
        tree.reset();                                 // tree destroyed; wood.png still used by the door
        std::cout << "textures alive after tree destroyed: " << Texture::alive << '\n';
    }                                                 // whole graph destroyed: all textures released
    std::cout << "after scene destroyed: nodes alive " << Node::alive << ", textures alive " << Texture::alive
              << ", stale cache entries purged " << cache.purge() << '\n';
    auto again = cache.get("brick.png");              // must reload: the old one is gone
    std::cout << "reloaded brick.png: total loads " << Texture::loads << '\n';
    assert(Node::alive == 0 && Texture::alive == 1);
}
