// file: deleters.cpp
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>

struct FileCloser { void operator()(std::FILE* f) const { std::printf("fclose\n"); std::fclose(f); } };
using File = std::unique_ptr<std::FILE, FileCloser>;

struct FreeDeleter { void operator()(void* p) const { std::free(p); } };

int main() {
    {
        File f(std::fopen("/tmp/deleters_demo.txt", "w"));
        if (!f) return 1;
        std::fputs("written through a unique_ptr\n", f.get());
    }                                                            // fclose runs here

    std::unique_ptr<char, FreeDeleter> buf(static_cast<char*>(std::malloc(32)));
    std::strcpy(buf.get(), "malloc'd, freed with free");
    std::printf("%s\n", buf.get());

    auto fnptr = std::unique_ptr<std::FILE, int (*)(std::FILE*)>(std::fopen("/dev/null", "r"), &std::fclose);
    std::printf("sizes: plain %zu, empty-struct deleter %zu, function-pointer deleter %zu\n",
                sizeof(std::unique_ptr<int>), sizeof(File), sizeof(fnptr));
}
