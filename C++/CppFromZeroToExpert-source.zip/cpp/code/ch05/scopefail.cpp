// file: scopefail.cpp
#include <exception>
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

template <typename F> class ScopeFail {
public:
    explicit ScopeFail(F f) : f_(std::move(f)), count_(std::uncaught_exceptions()) {}
    ~ScopeFail() { if (std::uncaught_exceptions() > count_) f_(); }
    ScopeFail(const ScopeFail&) = delete;
    ScopeFail& operator=(const ScopeFail&) = delete;
private:
    F f_;
    int count_;
};

void add_all(std::vector<int>& v, const std::vector<int>& items) {
    std::size_t old_size = v.size();
    ScopeFail rollback([&] { v.resize(old_size); std::cout << "  rolled back to " << old_size << " items\n"; });
    for (int x : items) {
        if (x < 0) throw std::invalid_argument("negative item");
        v.push_back(x);
    }
}

int main() {
    std::vector<int> v{1, 2};
    add_all(v, {3, 4});
    std::cout << "after good batch: " << v.size() << " items\n";
    try { add_all(v, {5, 6, -1, 7}); } catch (const std::exception& e) { std::cout << "caught: " << e.what() << '\n'; }
    std::cout << "after bad batch: " << v.size() << " items\n";
}
