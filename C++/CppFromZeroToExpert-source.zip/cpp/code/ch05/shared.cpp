// file: shared.cpp
#include <iostream>
#include <memory>
#include <string>
#include <vector>

struct Texture {
    std::string file;
    explicit Texture(std::string f) : file{std::move(f)} { std::cout << "  load " << file << '\n'; }
    ~Texture() { std::cout << "  unload " << file << '\n'; }
};

struct Sprite { std::shared_ptr<const Texture> tex; int x, y; };

int main() {
    std::vector<Sprite> sprites;
    {
        auto grass = std::make_shared<const Texture>("grass.png");   // one allocation: object + control block
        std::cout << "use_count after make_shared: " << grass.use_count() << '\n';
        for (int i = 0; i < 3; ++i)
            sprites.push_back({grass, i * 10, 0});
        std::cout << "use_count with 3 sprites: " << grass.use_count() << '\n';
    }                                                                 // 'grass' gone; sprites keep it alive
    std::cout << "local handle gone, sprites remain: " << sprites.size() << '\n';
    sprites.pop_back();
    sprites.pop_back();
    std::cout << "one sprite left, use_count " << sprites[0].tex.use_count() << '\n';
    sprites.clear();                                                  // last owner: texture unloaded
    std::cout << "sizeof(shared_ptr) = " << sizeof(std::shared_ptr<Texture>)
              << ", sizeof(unique_ptr) = " << sizeof(std::unique_ptr<Texture>) << '\n';
}
