// file: cycles.cpp
#include <iostream>
#include <memory>
#include <string>

struct NodeStrong {
    std::string name;
    std::shared_ptr<NodeStrong> partner;      // strong both ways: a cycle
    ~NodeStrong() { std::cout << "  ~" << name << '\n'; }
};

struct NodeWeak {
    std::string name;
    std::shared_ptr<NodeWeak> child;          // owner -> owned: strong
    std::weak_ptr<NodeWeak> parent;           // back-reference: weak
    ~NodeWeak() { std::cout << "  ~" << name << '\n'; }
};

int main() {
    std::cout << std::unitbuf;               // flush each line: LeakSanitizer ends the process at exit
    std::cout << "strong cycle:\n";
    {
        auto a = std::make_shared<NodeStrong>();
        auto b = std::make_shared<NodeStrong>();
        a->name = "A";
        b->name = "B";
        a->partner = b;
        b->partner = a;
    }                                         // no destructor runs: leaked
    std::cout << "weak back-reference:\n";
    {
        auto parent = std::make_shared<NodeWeak>();
        parent->name = "parent";
        parent->child = std::make_shared<NodeWeak>();
        parent->child->name = "child";
        parent->child->parent = parent;
        if (auto p = parent->child->parent.lock())
            std::cout << "  child sees parent " << p->name << '\n';
    }                                         // both destroyed
    std::weak_ptr<int> observer;
    {
        auto value = std::make_shared<int>(42);
        observer = value;
        std::cout << "observer expired? " << observer.expired() << '\n';
    }
    std::cout << "after owner gone, expired? " << observer.expired() << ", lock() is "
              << (observer.lock() ? "non-null" : "null") << '\n';
}
