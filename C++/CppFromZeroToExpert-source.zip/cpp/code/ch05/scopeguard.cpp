// file: scopeguard.cpp
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <utility>

template <typename F>
class ScopeGuard {
public:
    explicit ScopeGuard(F f) : f_{std::move(f)} {}
    ~ScopeGuard() { if (active_) f_(); }
    void dismiss() { active_ = false; }               // commit: don't run the cleanup
    ScopeGuard(const ScopeGuard&) = delete;
    ScopeGuard& operator=(const ScopeGuard&) = delete;
private:
    F f_;
    bool active_ = true;
};

bool write_report(bool fail) {
    std::FILE* f = std::fopen("report.tmp", "w");
    if (!f) return false;
    ScopeGuard close_file{[f] { std::fclose(f); }};
    ScopeGuard remove_tmp{[] { std::remove("report.tmp"); std::cout << "  rolled back: temp file removed\n"; }};
    std::fputs("data\n", f);
    if (fail)
        throw std::runtime_error("validation failed");
    std::fflush(f);
    if (std::rename("report.tmp", "report.txt") != 0) return false;
    remove_tmp.dismiss();                              // success: keep the result
    std::cout << "  committed report.txt\n";
    return true;
}

int main() {
    write_report(false);
    try { write_report(true); } catch (const std::exception& e) { std::cout << "  error: " << e.what() << '\n'; }
}
