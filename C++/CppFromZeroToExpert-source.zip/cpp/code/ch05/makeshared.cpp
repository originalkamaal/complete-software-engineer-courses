// file: makeshared.cpp
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <new>

static int allocations = 0;
void* operator new(std::size_t n) { ++allocations; if (void* p = std::malloc(n)) return p; throw std::bad_alloc(); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

struct Big { char data[1024]; };

int main() {
    int before = allocations;
    std::shared_ptr<Big> a(new Big);
    std::printf("shared_ptr(new Big): %d allocations\n", allocations - before);
    before = allocations;
    auto b = std::make_shared<Big>();
    std::printf("make_shared<Big>():  %d allocation\n", allocations - before);
    std::printf("sizeof(shared_ptr) = %zu (object pointer + control block pointer)\n", sizeof(a));
}
