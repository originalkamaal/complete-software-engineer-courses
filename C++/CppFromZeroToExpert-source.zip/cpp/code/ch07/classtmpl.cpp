// file: classtmpl.cpp
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

template <typename T>
class Stack {
public:
    Stack() = default;
    Stack(std::initializer_list<T> init) : items_{init} {}
    template <typename It>
    Stack(It first, It last) : items_(first, last) {}

    void push(T value) { items_.push_back(std::move(value)); }
    T pop();                                          // defined outside the class below
    const T& top() const { return items_.back(); }
    bool empty() const { return items_.empty(); }
    std::size_t size() const { return items_.size(); }
    void print() const {                              // requires operator<< for T, but only if called
        for (const auto& x : items_) std::cout << x << ' ';
        std::cout << '\n';
    }
private:
    std::vector<T> items_;
};

template <typename T>
T Stack<T>::pop() {                                    // out-of-class member definition
    if (items_.empty()) throw std::out_of_range("pop on empty stack");
    T v = std::move(items_.back());
    items_.pop_back();
    return v;
}

template <typename It>
Stack(It, It) -> Stack<typename std::iterator_traits<It>::value_type>;   // deduction guide

struct NoPrint { int x; };

int main() {
    Stack s{1, 2, 3};                        // CTAD: Stack<int>
    s.push(4);
    std::cout << "pop " << s.pop() << ", size " << s.size() << '\n';
    s.print();

    std::vector<std::string> words{"a", "b", "c"};
    Stack w(words.begin(), words.end());     // the guide deduces Stack<std::string>
    std::cout << "top of w: " << w.top() << '\n';

    Stack<NoPrint> np;                       // fine: print() is never instantiated for NoPrint
    np.push({7});
    std::cout << "NoPrint stack size " << np.size() << '\n';
    // np.print();   error only if called: no operator<< for NoPrint
}
