// file: deduction.cpp
#include <iostream>
#include <type_traits>
#include <typeinfo>

template <typename T> const char* by_value(T)        { return std::is_pointer_v<T> ? "pointer (decayed)" : std::is_const_v<T> ? "const" : "plain"; }
template <typename T> const char* by_ref(T&)         { return std::is_array_v<T> ? "array (not decayed)" : std::is_const_v<T> ? "const" : "plain"; }
template <typename T> const char* by_fwd(T&&)        { return std::is_lvalue_reference_v<T> ? "T is an lvalue reference" : "T is a plain type"; }
template <typename T, std::size_t N> std::size_t array_size(T (&)[N]) { return N; }   // deduces N

int main() {
    const int ci = 1;
    int arr[5] = {};
    std::cout << "by_value(ci): " << by_value(ci) << '\n';     // top-level const dropped
    std::cout << "by_value(arr): " << by_value(arr) << '\n';
    std::cout << "by_ref(ci): " << by_ref(ci) << '\n';         // const kept
    std::cout << "by_ref(arr): " << by_ref(arr) << '\n';
    std::cout << "by_fwd(ci): " << by_fwd(ci) << '\n';
    std::cout << "by_fwd(42): " << by_fwd(42) << '\n';
    std::cout << "array_size(arr) = " << array_size(arr) << '\n';
}
