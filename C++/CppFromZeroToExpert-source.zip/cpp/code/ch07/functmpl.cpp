// file: functmpl.cpp
#include <iostream>
#include <string>
#include <vector>

template <typename T>
T max_of(T a, T b) { return a < b ? b : a; }

template <typename Container>
auto sum(const Container& c) {
    typename Container::value_type total{};     // 'typename': value_type names a type
    for (const auto& x : c) total += x;
    return total;
}

template <typename T, typename U>
auto mixed_add(T a, U b) { return a + b; }       // return type deduced from the expression

int main() {
    std::cout << max_of(3, 7) << ' ' << max_of(2.5, 1.5) << ' ' << max_of<std::string>("pear", "apple") << '\n';
    // max_of(3, 7.5);   error: deduced conflicting types for T ('int' and 'double')
    std::cout << max_of<double>(3, 7.5) << '\n';  // explicit argument: both convert to double
    std::cout << sum(std::vector<int>{1, 2, 3}) << ' ' << sum(std::vector<std::string>{"a", "b", "c"}) << '\n';
    std::cout << mixed_add(1, 2.5) << ' ' << mixed_add(std::string("x"), "y") << '\n';
}
