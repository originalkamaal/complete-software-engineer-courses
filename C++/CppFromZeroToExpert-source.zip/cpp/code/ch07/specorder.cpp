// file: specorder.cpp
#include <iostream>

template <typename T> void f(T)  { std::cout << "f(T)\n"; }          // primary 1
template <> void f<int*>(int*)   { std::cout << "f<int*> specialisation of f(T)\n"; }
template <typename T> void f(T*) { std::cout << "f(T*)\n"; }         // primary 2, declared later

int main() {
    int x = 0;
    f(&x);       // primary 2 is more specialised than primary 1, so it wins; its own specialisations: none
}
