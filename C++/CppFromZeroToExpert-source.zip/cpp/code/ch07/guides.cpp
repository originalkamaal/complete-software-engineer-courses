// file: guides.cpp
#include <iostream>
#include <iterator>
#include <list>
#include <string>
#include <vector>

template <typename T> class Bag {
public:
    template <typename It> Bag(It first, It last) : items_(first, last) {}
    std::size_t size() const { return items_.size(); }
    const T& front() const { return items_.front(); }
private:
    std::vector<T> items_;
};
template <typename It> Bag(It, It) -> Bag<typename std::iterator_traits<It>::value_type>;   // the guide

template <typename T> struct Named { std::string name; T value; };
Named(const char*, double) -> Named<double>;                                              // guide for an aggregate

int main() {
    std::list<std::string> words{"alpha", "beta"};
    Bag b(words.begin(), words.end());           // deduces Bag<std::string> from the guide
    std::cout << b.size() << " items, first " << b.front() << '\n';
    Named n{"pi", 3.14};
    std::cout << n.name << " = " << n.value << '\n';
    std::vector v{1, 2, 3};                      // CTAD in the standard library: vector<int>
    std::vector w{v.begin(), v.end()};           // careful: vector<vector<int>::iterator>, two elements!
    std::cout << "v has " << v.size() << " ints; w has " << w.size() << " iterators\n";
}
