// file: deduce2.cpp
#include <algorithm>
#include <cstddef>
#include <iostream>

template <typename T> void by_value(T) { std::cout << "by value: sizeof(T) = " << sizeof(T) << '\n'; }
template <typename T> void by_ref(T&) { std::cout << "by ref:   sizeof(T) = " << sizeof(T) << '\n'; }
template <typename T, std::size_t N> constexpr std::size_t length(const T (&)[N]) { return N; }

int main() {
    int arr[10]{};
    by_value(arr);                       // T = int*
    by_ref(arr);                         // T = int[10]
    std::cout << "length(arr) = " << length(arr) << '\n';
    std::cout << "max = " << std::max<double>(1, 2.5) << '\n';
    // std::max(1, 2.5);                 // error: deduced conflicting types for 'T' ('int' and 'double')
}
