// file: special.cpp
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

template <typename T>
struct TypeName { static std::string get() { return "unknown"; } };          // primary template

template <> struct TypeName<int> { static std::string get() { return "int"; } };              // full
template <> struct TypeName<double> { static std::string get() { return "double"; } };
template <typename T> struct TypeName<T*> { static std::string get() { return TypeName<T>::get() + "*"; } };   // partial
template <typename T> struct TypeName<std::vector<T>> { static std::string get() { return "vector<" + TypeName<T>::get() + ">"; } };

// Functions: overloads instead of partial specialisation
template <typename T> bool equal(const T& a, const T& b) { return a == b; }
inline bool equal(const char* a, const char* b) { return std::strcmp(a, b) == 0; }   // compare contents

int main() {
    std::cout << TypeName<int>::get() << ", " << TypeName<double**>::get() << ", "
              << TypeName<std::vector<int*>>::get() << ", " << TypeName<char>::get() << '\n';
    char a[] = "hi", b[] = "hi";
    std::cout << std::boolalpha << "equal(a, b) = " << equal<const char*>(a, b) << " via template with T = const char*? no: "
              << equal(static_cast<const char*>(a), static_cast<const char*>(b)) << " via the overload\n";
}
