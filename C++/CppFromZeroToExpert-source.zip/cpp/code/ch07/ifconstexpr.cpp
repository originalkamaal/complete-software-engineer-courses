// file: ifconstexpr.cpp
#include <iostream>
#include <string>
#include <type_traits>

template <typename T> std::string describe(const T& x) {
    if constexpr (std::is_arithmetic_v<T>)
        return "number " + std::to_string(x);       // would not compile for std::string
    else if constexpr (requires { x.size(); })
        return "sized thing of size " + std::to_string(x.size());
    else
        return "something else";
}

int main() {
    std::cout << describe(42) << '\n' << describe(2.5) << '\n' << describe(std::string("hey")) << '\n'
              << describe(nullptr) << '\n';
}
