// file: twophase.cpp
#include <iostream>
#include <vector>

template <typename T> struct Base {
    int count = 3;
    void hello() const { std::cout << "Base::hello, count " << count << '\n'; }
};

template <typename T> struct Derived : Base<T> {
    void run() const {
        // hello();               // error: there are no arguments to 'hello' that depend on a template parameter
        this->hello();            // OK: 'this' is dependent, so lookup waits until instantiation
        std::cout << "count via Base<T>:: " << Base<T>::count << '\n';
    }
};

template <typename C> typename C::value_type first(const C& c) {   // C::value_type is a dependent type
    typename C::const_iterator it = c.begin();
    return *it;
}

int main() {
    Derived<int>{}.run();
    std::cout << "first: " << first(std::vector<int>{7, 8}) << '\n';
}
