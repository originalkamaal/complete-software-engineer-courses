// file: nttp.cpp
#include <algorithm>
#include <array>
#include <cstddef>
#include <iostream>
#include <string_view>

template <std::size_t N>
struct FixedString {                                    // a string usable as a template argument (C++20)
    char data[N]{};
    constexpr FixedString(const char (&s)[N]) { std::copy_n(s, N, data); }
    constexpr std::string_view view() const { return {data, N - 1}; }
};

template <FixedString Name, typename T = int, T Default = T{}>
struct Setting {
    T value = Default;
    static constexpr std::string_view name() { return Name.view(); }
};

template <int Base>
constexpr int digits(unsigned v) {                       // one function per base, computed at compile time
    int n = 1;
    while (v >= static_cast<unsigned>(Base)) { v /= Base; ++n; }
    return n;
}

int main() {
    Setting<"timeout", int, 30> timeout;
    Setting<"retries"> retries;                          // T = int, Default = 0
    std::cout << timeout.name() << '=' << timeout.value << ", " << retries.name() << '=' << retries.value << '\n';
    static_assert(digits<10>(12345) == 5 && digits<2>(255) == 8 && digits<16>(255) == 2);
    std::array<int, digits<10>(1000000)> buf{};          // array size computed from a template
    std::cout << "buffer for 1000000 has " << buf.size() << " digits\n";
}
