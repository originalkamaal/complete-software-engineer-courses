// file: traits.cpp
#include <iostream>
#include <string>
#include <type_traits>
#include <vector>

template <typename T>
std::string describe(const T& value) {
    if constexpr (std::is_integral_v<T>)                  // only the matching branch is compiled
        return "integer " + std::to_string(value) + (value % 2 == 0 ? " (even)" : " (odd)");
    else if constexpr (std::is_floating_point_v<T>)
        return "floating " + std::to_string(value);
    else if constexpr (std::is_convertible_v<T, std::string>)
        return "string \"" + std::string(value) + "\"";
    else
        return "something with sizeof " + std::to_string(sizeof(T));
}

template <typename T>
T safe_average(const std::vector<T>& v) {
    static_assert(std::is_arithmetic_v<T>, "safe_average needs a numeric element type");
    T sum{};
    for (const T& x : v) sum += x;
    return v.empty() ? T{} : sum / static_cast<T>(v.size());
}

int main() {
    std::cout << describe(42) << '\n' << describe(2.5) << '\n' << describe("text") << '\n'
              << describe(std::vector<int>{}) << '\n';
    std::cout << safe_average(std::vector<double>{1, 2, 4}) << '\n';
    // safe_average(std::vector<std::string>{"a"});   error: "safe_average needs a numeric element type"
}
