// file: externtmpl/user.cpp
#include "heavy.hpp"
void use() { Heavy<int> h{{3, 1, 2}}; h.process(); }
