// file: externtmpl/heavy.cpp
#include "heavy.hpp"
template struct Heavy<int>;             // the one place it is instantiated
