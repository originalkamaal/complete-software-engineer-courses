// file: externtmpl/heavy.hpp
#pragma once
#include <algorithm>
#include <vector>
template <typename T> struct Heavy {
    std::vector<T> data;
    void process() { for (int i = 0; i < 50; ++i) std::sort(data.begin(), data.end()); std::reverse(data.begin(), data.end()); }
};
#ifdef USE_EXTERN
extern template struct Heavy<int>;      // users must not instantiate Heavy<int>
#endif
