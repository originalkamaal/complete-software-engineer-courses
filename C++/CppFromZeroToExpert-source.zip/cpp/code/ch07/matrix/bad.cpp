#include "matrix.hpp"
int main() { Matrix<double, 2, 3> a; auto bad = a * a; (void)bad; }
