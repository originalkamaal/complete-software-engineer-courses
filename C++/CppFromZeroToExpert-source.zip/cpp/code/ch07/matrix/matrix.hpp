// file: matrix/matrix.hpp
#pragma once
#include <array>
#include <cstddef>
#include <initializer_list>
#include <ostream>
#include <stdexcept>
#include <type_traits>

template <typename T, std::size_t R, std::size_t C>
class Matrix {
    static_assert(std::is_arithmetic_v<T>, "Matrix elements must be numbers");
    static_assert(R > 0 && C > 0, "Matrix dimensions must be positive");
public:
    constexpr Matrix() = default;
    constexpr Matrix(std::initializer_list<std::initializer_list<T>> rows) {
        if (rows.size() != R) throw std::invalid_argument("wrong number of rows");
        std::size_t r = 0;
        for (const auto& row : rows) {
            if (row.size() != C) throw std::invalid_argument("wrong number of columns");
            std::size_t c = 0;
            for (T v : row) data_[r * C + c++] = v;
            ++r;
        }
    }
    static constexpr Matrix identity() requires (R == C) {        // only square matrices
        Matrix m;
        for (std::size_t i = 0; i < R; ++i) m(i, i) = T{1};
        return m;
    }

    constexpr T& operator()(std::size_t r, std::size_t c) { return data_[r * C + c]; }
    constexpr const T& operator()(std::size_t r, std::size_t c) const { return data_[r * C + c]; }
    static constexpr std::size_t rows() { return R; }
    static constexpr std::size_t cols() { return C; }

    constexpr Matrix<T, C, R> transposed() const {
        Matrix<T, C, R> t;
        for (std::size_t r = 0; r < R; ++r)
            for (std::size_t c = 0; c < C; ++c) t(c, r) = (*this)(r, c);
        return t;
    }

    friend constexpr Matrix operator+(const Matrix& a, const Matrix& b) {   // same R, C enforced by the type
        Matrix out;
        for (std::size_t i = 0; i < R * C; ++i) out.data_[i] = a.data_[i] + b.data_[i];
        return out;
    }
    friend constexpr bool operator==(const Matrix&, const Matrix&) = default;

    friend std::ostream& operator<<(std::ostream& os, const Matrix& m) {
        for (std::size_t r = 0; r < R; ++r) {
            os << (r == 0 ? "[" : " ");
            for (std::size_t c = 0; c < C; ++c) os << (c ? " " : "") << m(r, c);
            os << (r + 1 == R ? "]" : "\n");
        }
        return os;
    }
private:
    std::array<T, R * C> data_{};
};

// (R x K) * (K x C) -> (R x C): the shared K must match, or this template doesn't apply
template <typename T, std::size_t R, std::size_t K, std::size_t C>
constexpr Matrix<T, R, C> operator*(const Matrix<T, R, K>& a, const Matrix<T, K, C>& b) {
    Matrix<T, R, C> out;
    for (std::size_t r = 0; r < R; ++r)
        for (std::size_t k = 0; k < K; ++k)              // i-k-j order: cache-friendly
            for (std::size_t c = 0; c < C; ++c) out(r, c) += a(r, k) * b(k, c);
    return out;
}
