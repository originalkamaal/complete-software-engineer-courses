// file: matrix/test.cpp
#include <iostream>
#include "matrix.hpp"

constexpr auto rotation90 = Matrix<int, 2, 2>{{0, -1}, {1, 0}};
static_assert(rotation90 * rotation90 * rotation90 * rotation90 == Matrix<int, 2, 2>::identity());   // compile time

int main() {
    Matrix<double, 2, 3> a{{1, 2, 3}, {4, 5, 6}};
    Matrix<double, 3, 2> b{{7, 8}, {9, 10}, {11, 12}};
    auto c = a * b;                                       // 2x3 * 3x2 = 2x2
    std::cout << "a * b =\n" << c << '\n';
    std::cout << "a + a =\n" << a + a << '\n';
    std::cout << "transpose(a) =\n" << a.transposed() << '\n';
    std::cout << "dimensions of a * b: " << c.rows() << 'x' << c.cols() << ", sizeof(c) = " << sizeof(c) << '\n';
    // auto bad = a + b;   error: no match for operator+ (Matrix<double,2,3> and Matrix<double,3,2>)
    // auto bad2 = a * a;  error: no match for operator* (inner dimensions 3 and 2 differ)
    // Matrix<double, 2, 3>::identity();   error: constraints not satisfied (R == C)
}
