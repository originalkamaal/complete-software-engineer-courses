// file: inst/big.hpp
#pragma once
#include <algorithm>
#include <vector>

template <typename T>
T median(std::vector<T> v) {                          // defined in the header: usable with any T
    std::nth_element(v.begin(), v.begin() + v.size() / 2, v.end());
    return v[v.size() / 2];
}

extern template double median<double>(std::vector<double>);   // "instantiated elsewhere: don't instantiate here"
