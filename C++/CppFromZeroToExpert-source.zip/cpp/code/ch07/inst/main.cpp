// file: inst/main.cpp
#include <iostream>
#include "big.hpp"

int main() {
    std::cout << median(std::vector<double>{3, 1, 2}) << ' ' << median(std::vector<int>{9, 7, 8}) << '\n';
}
