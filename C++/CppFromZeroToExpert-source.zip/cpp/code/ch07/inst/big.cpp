// file: inst/big.cpp
#include "big.hpp"
template double median<double>(std::vector<double>);           // explicit instantiation: the one copy
