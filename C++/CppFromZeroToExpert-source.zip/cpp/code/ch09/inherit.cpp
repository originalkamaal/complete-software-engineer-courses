// file: inherit.cpp
#include <iostream>
#include <string>

struct Logger {
    std::string tag;
    explicit Logger(std::string t) : tag{std::move(t)} { std::cout << "  Logger(" << tag << ")\n"; }
    ~Logger() { std::cout << "  ~Logger(" << tag << ")\n"; }
};

class Animal {
public:
    explicit Animal(std::string name) : name_{std::move(name)}, log_{"animal"} { std::cout << "  Animal\n"; }
    ~Animal() { std::cout << "  ~Animal\n"; }
    const std::string& name() const { return name_; }
protected:                                      // visible to derived classes, not to users
    int legs_ = 4;
private:
    std::string name_;
    Logger log_;
};

class Bird : public Animal {
public:
    explicit Bird(std::string name) : Animal{std::move(name)}, log_{"bird"} {   // base initialised first
        legs_ = 2;
        std::cout << "  Bird\n";
    }
    ~Bird() { std::cout << "  ~Bird\n"; }
    int legs() const { return legs_; }
private:
    Logger log_;
};

int main() {
    std::cout << "constructing:\n";
    {
        Bird b{"robin"};
        std::cout << b.name() << " has " << b.legs() << " legs\ndestroying:\n";
    }
}
