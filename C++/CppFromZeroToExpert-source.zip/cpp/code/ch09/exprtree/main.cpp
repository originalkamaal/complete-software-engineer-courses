// file: exprtree/main.cpp
#include <chrono>
#include <iostream>
#include "expr_variant.hpp"
#include "expr_virtual.hpp"

// Build the same balanced tree of 'depth' levels in both representations.
oo::ExprPtr build_oo(int depth, int& leaf) {
    if (depth == 0) return (leaf++ % 3 == 0) ? oo::ExprPtr{std::make_unique<oo::Var>("x")} : oo::ExprPtr{std::make_unique<oo::Num>(leaf % 7 + 1)};
    const char ops[] = "+-*+";
    auto l = build_oo(depth - 1, leaf);
    auto r = build_oo(depth - 1, leaf);
    return std::make_unique<oo::Bin>(ops[depth % 4], std::move(l), std::move(r));
}
std::unique_ptr<vt::Expr> build_vt(int depth, int& leaf) {
    if (depth == 0) return (leaf++ % 3 == 0) ? vt::var("x") : vt::num(leaf % 7 + 1);
    const char ops[] = "+-*+";
    auto l = build_vt(depth - 1, leaf);
    auto r = build_vt(depth - 1, leaf);
    return vt::bin(ops[depth % 4], std::move(l), std::move(r));
}

template <typename F>
double timed(const char* label, F f) {
    auto t0 = std::chrono::steady_clock::now();
    double r = 0;
    for (int rep = 0; rep < 20; ++rep) r += f();
    std::cout << label << std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() << " ms\n";
    return r;
}

int main() {
    // A small expression in both forms: sqrt((x * x) + 16) at x = 3
    oo::Sqrt e1{std::make_unique<oo::Bin>('+', std::make_unique<oo::Bin>('*', std::make_unique<oo::Var>("x"), std::make_unique<oo::Var>("x")), std::make_unique<oo::Num>(16))};
    auto e2 = vt::sqrt_(vt::bin('+', vt::bin('*', vt::var("x"), vt::var("x")), vt::num(16)));
    oo::Env env{{"x", 3}};
    std::cout << e1.str() << " = " << e1.eval(env) << " (virtual)\n";
    std::cout << vt::str(*e2) << " = " << vt::eval(*e2, env) << " (variant)\n";

    int leaf1 = 0, leaf2 = 0;
    auto big_oo = build_oo(18, leaf1);                  // 2^18 leaves, ~524k nodes
    auto big_vt = build_vt(18, leaf2);
    double a = timed("virtual tree, 20 evaluations: ", [&] { return big_oo->eval(env); });
    double b = timed("variant tree, 20 evaluations: ", [&] { return vt::eval(*big_vt, env); });
    std::cout << "results agree: " << std::boolalpha << (a == b) << '\n';
}
