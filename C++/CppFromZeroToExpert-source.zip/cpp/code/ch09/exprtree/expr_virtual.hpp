// file: exprtree/expr_virtual.hpp
#pragma once
#include <cmath>
#include <map>
#include <memory>
#include <string>

namespace oo {
using Env = std::map<std::string, double>;

struct Expr {
    virtual ~Expr() = default;
    virtual double eval(const Env& env) const = 0;
    virtual std::string str() const = 0;
};
using ExprPtr = std::unique_ptr<Expr>;

struct Num final : Expr {
    double v;
    explicit Num(double v) : v{v} {}
    double eval(const Env&) const override { return v; }
    std::string str() const override { auto s = std::to_string(v); s.erase(s.find_last_not_of('0') + 1); if (s.back() == '.') s.pop_back(); return s; }
};
struct Var final : Expr {
    std::string name;
    explicit Var(std::string n) : name{std::move(n)} {}
    double eval(const Env& env) const override { return env.at(name); }
    std::string str() const override { return name; }
};
struct Bin final : Expr {
    char op;
    ExprPtr l, r;
    Bin(char o, ExprPtr a, ExprPtr b) : op{o}, l{std::move(a)}, r{std::move(b)} {}
    double eval(const Env& env) const override {
        double a = l->eval(env), b = r->eval(env);
        switch (op) { case '+': return a + b; case '-': return a - b; case '*': return a * b; default: return a / b; }
    }
    std::string str() const override { return "(" + l->str() + " " + op + " " + r->str() + ")"; }
};
struct Sqrt final : Expr {
    ExprPtr arg;
    explicit Sqrt(ExprPtr a) : arg{std::move(a)} {}
    double eval(const Env& env) const override { return std::sqrt(arg->eval(env)); }
    std::string str() const override { return "sqrt(" + arg->str() + ")"; }
};
}  // namespace oo
