// file: exprtree/expr_variant.hpp
#pragma once
#include <cmath>
#include <map>
#include <memory>
#include <string>
#include <variant>

namespace vt {
using Env = std::map<std::string, double>;
struct Num; struct Var; struct Bin; struct Sqrt;
using Expr = std::variant<Num, Var, Bin, Sqrt>;     // closed set of node types

struct Num { double v; };
struct Var { std::string name; };
struct Bin { char op; std::unique_ptr<Expr> l, r; };  // recursion needs indirection
struct Sqrt { std::unique_ptr<Expr> arg; };

template <typename... Fs> struct overloaded : Fs... { using Fs::operator()...; };

inline double eval(const Expr& e, const Env& env) {
    return std::visit(overloaded{
        [](const Num& n) { return n.v; },
        [&](const Var& v) { return env.at(v.name); },
        [&](const Bin& b) {
            double a = eval(*b.l, env), c = eval(*b.r, env);
            switch (b.op) { case '+': return a + c; case '-': return a - c; case '*': return a * c; default: return a / c; }
        },
        [&](const Sqrt& s) { return std::sqrt(eval(*s.arg, env)); },
    }, e);
}

inline std::string str(const Expr& e) {                 // a second operation: just another visitor
    return std::visit(overloaded{
        [](const Num& n) { auto s = std::to_string(n.v); s.erase(s.find_last_not_of('0') + 1); if (s.back() == '.') s.pop_back(); return s; },
        [](const Var& v) { return v.name; },
        [](const Bin& b) { return "(" + str(*b.l) + " " + b.op + " " + str(*b.r) + ")"; },
        [](const Sqrt& s) { return "sqrt(" + str(*s.arg) + ")"; },
    }, e);
}

inline std::unique_ptr<Expr> num(double v) { return std::make_unique<Expr>(Num{v}); }
inline std::unique_ptr<Expr> var(std::string n) { return std::make_unique<Expr>(Var{std::move(n)}); }
inline std::unique_ptr<Expr> bin(char op, std::unique_ptr<Expr> a, std::unique_ptr<Expr> b) { return std::make_unique<Expr>(Bin{op, std::move(a), std::move(b)}); }
inline std::unique_ptr<Expr> sqrt_(std::unique_ptr<Expr> a) { return std::make_unique<Expr>(Sqrt{std::move(a)}); }
}  // namespace vt
