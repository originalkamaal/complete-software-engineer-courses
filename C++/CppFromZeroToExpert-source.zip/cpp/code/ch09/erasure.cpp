// file: erasure.cpp
#include <chrono>
#include <iostream>
#include <memory>
#include <numbers>
#include <random>
#include <variant>
#include <vector>

// --- 1. classic virtual hierarchy
struct VShape { virtual ~VShape() = default; virtual double area() const = 0; };
struct VCircle : VShape { double r; explicit VCircle(double r) : r{r} {} double area() const override { return std::numbers::pi * r * r; } };
struct VRect : VShape { double w, h; VRect(double w, double h) : w{w}, h{h} {} double area() const override { return w * h; } };

// --- 2. variant
struct Circle { double r; double area() const { return std::numbers::pi * r * r; } };
struct Rect { double w, h; double area() const { return w * h; } };
using VarShape = std::variant<Circle, Rect>;

// --- 3. type erasure: any type with area() const, held by value
class AnyShape {
public:
    template <typename T>
    AnyShape(T shape) : self_{std::make_unique<Model<T>>(std::move(shape))} {}   // implicit: wraps anything shape-like
    AnyShape(const AnyShape& o) : self_{o.self_->clone()} {}
    AnyShape(AnyShape&&) noexcept = default;
    AnyShape& operator=(AnyShape o) noexcept { self_ = std::move(o.self_); return *this; }
    double area() const { return self_->area(); }
private:
    struct Concept { virtual ~Concept() = default; virtual double area() const = 0; virtual std::unique_ptr<Concept> clone() const = 0; };
    template <typename T> struct Model final : Concept {
        T obj;
        explicit Model(T o) : obj{std::move(o)} {}
        double area() const override { return obj.area(); }
        std::unique_ptr<Concept> clone() const override { return std::make_unique<Model>(obj); }
    };
    std::unique_ptr<Concept> self_;
};

// --- 4. CRTP: static dispatch to the derived class
template <typename Derived>
struct ShapeBase {
    double scaled_area(double k) const { return k * k * static_cast<const Derived&>(*this).area(); }
};
struct CCircle : ShapeBase<CCircle> { double r; explicit CCircle(double r) : r{r} {} double area() const { return std::numbers::pi * r * r; } };

template <typename F>
void bench(const char* name, F&& f) {
    auto t0 = std::chrono::steady_clock::now();
    double s = f();
    auto ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::cout << name << ms << " ms (sum " << s << ")\n";
}

int main() {
    const int n = 2'000'000;
    std::mt19937 rng{1};
    std::vector<std::unique_ptr<VShape>> vs;
    std::vector<VarShape> var;
    std::vector<AnyShape> anys;
    for (int i = 0; i < n; ++i) {
        double x = 1 + rng() % 10;
        if (rng() % 2) { vs.push_back(std::make_unique<VCircle>(x)); var.push_back(Circle{x}); anys.push_back(Circle{x}); }
        else { vs.push_back(std::make_unique<VRect>(x, x)); var.push_back(Rect{x, x}); anys.push_back(Rect{x, x}); }
    }
    bench("virtual (heap objects): ", [&] { double s = 0; for (const auto& p : vs) s += p->area(); return s; });
    bench("variant (contiguous):   ", [&] { double s = 0; for (const auto& v : var) s += std::visit([](const auto& x) { return x.area(); }, v); return s; });
    bench("type erasure:           ", [&] { double s = 0; for (const auto& a : anys) s += a.area(); return s; });
    std::cout << "CRTP scaled_area: " << CCircle{1}.scaled_area(2) << '\n';
}
