// file: hiding.cpp
#include <iostream>
#include <string>

struct Base {
    void f(int) { std::cout << "Base::f(int)\n"; }
    void f(double) { std::cout << "Base::f(double)\n"; }
};
struct Hides : Base {
    void f(const std::string&) { std::cout << "Hides::f(string)\n"; }
};
struct Unhides : Base {
    using Base::f;                                        // all Base::f overloads join this scope
    void f(const std::string&) { std::cout << "Unhides::f(string)\n"; }
};

int main() {
    Hides h;
    h.f("text");
    // h.f(1);                                            // error: no matching function, Base::f is hidden
    h.Base::f(1);                                         // still reachable when named explicitly
    Unhides u;
    u.f(1); u.f(2.5); u.f("text");
}
