// file: ctorvirtual.cpp
#include <iostream>

struct Base {
    Base() { std::cout << "Base ctor calls: "; describe(); }
    virtual ~Base() { std::cout << "Base dtor calls: "; describe(); }
    virtual void describe() const { std::cout << "Base::describe\n"; }
};
struct Derived : Base {
    int value = 42;
    Derived() { std::cout << "Derived ctor calls: "; describe(); }
    void describe() const override { std::cout << "Derived::describe, value " << value << '\n'; }
};

int main() { Derived d; std::cout << "--- end of main\n"; }
