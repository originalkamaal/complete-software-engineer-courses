// file: virtual.cpp
#include <iostream>
#include <memory>
#include <numbers>
#include <vector>

class Shape {
public:
    virtual ~Shape() = default;                        // required for deleting through Shape*
    virtual double area() const = 0;                   // pure virtual: Shape is abstract
    virtual const char* name() const { return "shape"; }
    void describe() const {                            // non-virtual, calls virtuals (template method)
        std::cout << name() << " with area " << area() << '\n';
    }
};

class Circle final : public Shape {                    // final: no further derivation
public:
    explicit Circle(double r) : r_{r} {}
    double area() const override { return std::numbers::pi * r_ * r_; }
    const char* name() const override { return "circle"; }
private:
    double r_;
};

class Rect : public Shape {
public:
    Rect(double w, double h) : w_{w}, h_{h} {}
    double area() const override { return w_ * h_; }
    const char* name() const override { return "rect"; }
protected:
    double w_, h_;
};

class Square : public Rect {
public:
    explicit Square(double s) : Rect{s, s} {}
    const char* name() const override { return "square"; }   // area() inherited from Rect
};

int main() {
    std::vector<std::unique_ptr<Shape>> shapes;
    shapes.push_back(std::make_unique<Circle>(1));
    shapes.push_back(std::make_unique<Rect>(2, 3));
    shapes.push_back(std::make_unique<Square>(2));
    for (const auto& s : shapes) s->describe();       // dynamic dispatch through the base

    std::cout << "sizeof(Rect) = " << sizeof(Rect) << " (two doubles + a vtable pointer)\n";
}
