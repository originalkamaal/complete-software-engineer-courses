// file: casts.cpp
#include <bit>
#include <cstdint>
#include <iostream>
#include <memory>
#include <typeinfo>

struct Base { virtual ~Base() = default; };
struct Dog : Base { void bark() const { std::cout << "  woof\n"; } };
struct Cat : Base {};

void maybe_bark(const Base& b) {
    if (auto d = dynamic_cast<const Dog*>(&b))        // checked at run time: null if not a Dog
        d->bark();
    else
        std::cout << "  not a dog: " << typeid(b).name() << '\n';
}

int main() {
    Dog dog;
    Cat cat;
    maybe_bark(dog);
    maybe_bark(cat);

    double d = 3.9;
    int i = static_cast<int>(d);                      // explicit, visible conversion
    float f = 1.0f;
    auto bits = std::bit_cast<std::uint32_t>(f);      // the bytes of f as an integer: no aliasing UB
    std::cout << "static_cast<int>(3.9) = " << i << ", bits of 1.0f = 0x" << std::hex << bits << std::dec << '\n';

    const int frozen = 5;
    int* p = const_cast<int*>(&frozen);               // compiles ...
    (void)p;                                          // ... but *p = 6 would be undefined behaviour
}
