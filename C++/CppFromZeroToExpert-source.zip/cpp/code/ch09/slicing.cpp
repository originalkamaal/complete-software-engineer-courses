// file: slicing.cpp
#include <iostream>
#include <memory>
#include <string>
#include <vector>

struct Animal {
    virtual ~Animal() = default;
    virtual std::string sound() const { return "..."; }
};
struct Dog : Animal {
    std::string name = "Rex";
    std::string sound() const override { return "woof (" + name + ")"; }
};

void by_value(Animal a) { std::cout << "by value:     " << a.sound() << '\n'; }
void by_ref(const Animal& a) { std::cout << "by reference: " << a.sound() << '\n'; }

int main() {
    Dog d;
    by_value(d);
    by_ref(d);
    std::vector<Animal> values{d};                         // sliced on the way in
    std::vector<std::unique_ptr<Animal>> owners;
    owners.push_back(std::make_unique<Dog>());
    std::cout << "vector<Animal>: " << values[0].sound() << ", vector<unique_ptr<Animal>>: " << owners[0]->sound() << '\n';
}
