// file: dyncost.cpp
#include <chrono>
#include <cstdio>
#include <memory>
#include <vector>

struct Base { virtual ~Base() = default; };
struct Mid : Base {};
struct Leaf : Mid { int v = 1; };
struct Other : Base {};

int main() {
    std::vector<std::unique_ptr<Base>> objs;
    for (int i = 0; i < 1000; ++i) {
        if (i % 2) objs.push_back(std::make_unique<Leaf>()); else objs.push_back(std::make_unique<Other>());
    }
    long hits = 0;
    auto t0 = std::chrono::steady_clock::now();
    for (int rep = 0; rep < 10000; ++rep)
        for (auto& p : objs) if (auto* l = dynamic_cast<Leaf*>(p.get())) hits += l->v;
    double ns = std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - t0).count() / 1e7;
    std::printf("dynamic_cast: %ld hits, %s\n", hits, ns > 1.0 ? "more than 1 ns per cast" : "under 1 ns per cast");
}
