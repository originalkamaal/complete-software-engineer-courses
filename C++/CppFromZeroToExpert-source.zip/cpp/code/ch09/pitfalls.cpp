// file: pitfalls.cpp
#include <iostream>
#include <string>

class Base {
public:
    Base() { std::cout << "  Base() calls who(): " << who() << '\n'; }   // virtual call in a constructor
    virtual ~Base() = default;
    virtual std::string who() const { return "Base"; }
    void f(int) const { std::cout << "  Base::f(int)\n"; }
    void f(double) const { std::cout << "  Base::f(double)\n"; }
};

class Derived : public Base {
public:
    Derived() { std::cout << "  Derived() calls who(): " << who() << '\n'; }
    std::string who() const override { return "Derived"; }
    void f(const std::string&) const { std::cout << "  Derived::f(string)\n"; }   // hides BOTH Base::f
};

void by_value(Base b) { std::cout << "  by value: " << b.who() << '\n'; }      // slices
void by_ref(const Base& b) { std::cout << "  by reference: " << b.who() << '\n'; }

int main() {
    std::cout << "construction:\n";
    Derived d;
    std::cout << "slicing:\n";
    by_value(d);
    by_ref(d);
    std::cout << "hiding:\n";
    d.f(std::string("x"));
    // d.f(42);              error: Base::f(int) is hidden by Derived::f
    d.Base::f(42);          // still reachable explicitly ('using Base::f;' in Derived would unhide)
}
