// file: variant.cpp
#include <iostream>
#include <numbers>
#include <string>
#include <variant>
#include <vector>

struct Circle { double r; };
struct Rect { double w, h; };
struct Triangle { double base, height; };
using Shape = std::variant<Circle, Rect, Triangle>;

template <typename... Fs> struct overloaded : Fs... { using Fs::operator()...; };   // the "overloaded" idiom

double area(const Shape& s) {
    return std::visit(overloaded{
        [](const Circle& c) { return std::numbers::pi * c.r * c.r; },
        [](const Rect& r) { return r.w * r.h; },
        [](const Triangle& t) { return 0.5 * t.base * t.height; },
    }, s);                                            // omit a case: compile error
}

int main() {
    std::vector<Shape> shapes{Circle{1}, Rect{2, 3}, Triangle{4, 5}};
    for (const auto& s : shapes)
        std::cout << "index " << s.index() << " area " << area(s) << '\n';
    if (const Rect* r = std::get_if<Rect>(&shapes[1])) std::cout << "shapes[1] is a Rect of width " << r->w << '\n';
    try {
        std::get<Circle>(shapes[1]);                  // wrong alternative: throws
    } catch (const std::bad_variant_access& e) {
        std::cout << "bad_variant_access: " << e.what() << '\n';
    }
    std::cout << "sizeof(Shape) = " << sizeof(Shape) << " (largest alternative + index)\n";
}
