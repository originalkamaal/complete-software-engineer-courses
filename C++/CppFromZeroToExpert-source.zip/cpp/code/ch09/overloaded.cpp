// file: overloaded.cpp
#include <iostream>
#include <string>
#include <variant>
#include <vector>

template <typename... Fs> struct overloaded : Fs... { using Fs::operator()...; };

using Json = std::variant<std::nullptr_t, bool, double, std::string>;

int main() {
    std::vector<Json> values{nullptr, true, 3.5, std::string("hi")};
    for (const auto& v : values)
        std::visit(overloaded{
                       [](std::nullptr_t) { std::cout << "null\n"; },
                       [](bool b) { std::cout << (b ? "true" : "false") << '\n'; },
                       [](double d) { std::cout << d << '\n'; },
                       [](const std::string& s) { std::cout << '"' << s << "\"\n"; },
                   },
                   v);
    std::cout << "sizeof(Json) = " << sizeof(Json) << " (largest alternative std::string is " << sizeof(std::string)
              << ", plus the index)\n";
}
