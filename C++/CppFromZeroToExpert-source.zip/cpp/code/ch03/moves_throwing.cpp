// file: moves.cpp
#include <cstring>
#include <iostream>
#include <utility>
#include <vector>

static int copies, moves;

class Text {
public:
    explicit Text(const char* s = "") : len_{std::strlen(s)}, data_{new char[len_ + 1]} {
        std::memcpy(data_, s, len_ + 1);
    }
    ~Text() { delete[] data_; }

    Text(const Text& o) : len_{o.len_}, data_{new char[o.len_ + 1]} {      // copy: allocate
        std::memcpy(data_, o.data_, len_ + 1);
        ++copies;
    }
    Text(Text&& o) : len_{o.len_}, data_{o.data_} {               // move: steal
        o.len_ = 0;
        o.data_ = nullptr;                                                  // leave o destructible
        ++moves;
    }
    Text& operator=(Text o) noexcept {      // copy-and-swap, unified: o is copied or moved in
        std::swap(len_, o.len_);
        std::swap(data_, o.data_);
        return *this;
    }
    const char* c_str() const { return data_ ? data_ : ""; }

private:
    std::size_t len_;
    char* data_;
};

int main() {
    std::vector<Text> v;
    for (int i = 0; i < 1000; ++i)
        v.push_back(Text{"some text that needs a heap allocation"});   // temporaries: moved in
    std::cout << "push_back of temporaries: copies=" << copies << " moves=" << moves << '\n';

    copies = moves = 0;
    Text a{"source"};
    Text b = a;              // copy
    Text c = std::move(a);   // move: a is now empty but valid
    std::cout << "b=" << b.c_str() << " c=" << c.c_str() << " a=\"" << a.c_str() << "\"\n";
    a = Text{"reassigned"};  // a moved-from object can be assigned to
    std::cout << "a=" << a.c_str() << ", copies=" << copies << " moves=" << moves << '\n';
}
