// file: nrvo.cpp
#include <iostream>

struct Tracer {
    Tracer() { std::cout << "  construct\n"; }
    Tracer(const Tracer&) { std::cout << "  copy\n"; }
    Tracer(Tracer&&) noexcept { std::cout << "  move\n"; }
};

Tracer prvalue() { return Tracer(); }                // guaranteed: no copy, no move
Tracer named() { Tracer t; return t; }               // NRVO: usually no copy, no move
Tracer two_names(bool f) {                           // NRVO impossible: which one to build in place?
    Tracer a, b;
    if (f) return a;
    return b;
}
struct NoMove { NoMove() = default; NoMove(const NoMove&) = delete; NoMove(NoMove&&) = delete; };
NoMove factory() { return NoMove(); }                // compiles only because of C++17 guaranteed elision

int main() {
    std::cout << "prvalue:\n";   Tracer a = prvalue();
    std::cout << "named:\n";     Tracer b = named();
    std::cout << "two names:\n"; Tracer c = two_names(true);
    NoMove n = factory();
    (void)a; (void)b; (void)c; (void)n;
}
