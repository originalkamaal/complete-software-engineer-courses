// file: dynarray/test.cpp
#include <cassert>
#include <iostream>
#include <string>
#include "dynarray.hpp"

struct Counted {
    static inline int copies = 0, moves = 0, alive = 0;
    std::string s;
    explicit Counted(std::string v) : s{std::move(v)} { ++alive; }
    Counted(const Counted& o) : s{o.s} { ++copies; ++alive; }
    Counted(Counted&& o) noexcept : s{std::move(o.s)} { ++moves; ++alive; }
    ~Counted() { --alive; }
};

struct ThrowingMove {                       // move not noexcept: DynArray must copy on growth
    static inline int copies = 0, moves = 0;
    int v;
    explicit ThrowingMove(int x) : v{x} {}
    ThrowingMove(const ThrowingMove& o) : v{o.v} { ++copies; }
    ThrowingMove(ThrowingMove&& o) : v{o.v} { ++moves; }
};

int main() {
    {
        DynArray<Counted> a;
        for (int i = 0; i < 100; ++i)
            a.emplace_back("item " + std::to_string(i));       // constructed in place
        std::cout << "100 emplace_backs: copies=" << Counted::copies << " moves=" << Counted::moves
                  << " capacity=" << a.capacity() << '\n';
        assert(Counted::copies == 0);

        DynArray<Counted> b = a;                                 // deep copy
        assert(Counted::copies == 100 && b[42].s == "item 42");
        DynArray<Counted> c = std::move(a);                      // steals: no element touched
        assert(Counted::copies == 100 && a.size() == 0 && c.size() == 100);
        b = c;                                                   // copy-assign
        c = DynArray<Counted>{};                                 // move-assign an empty one
        assert(c.size() == 0 && b.size() == 100);
        assert(Counted::alive == 100);                           // only b's elements are alive
    }
    assert(Counted::alive == 0);                                 // nothing leaked

    DynArray<ThrowingMove> t;
    for (int i = 0; i < 100; ++i)
        t.emplace_back(i);
    std::cout << "throwing-move type, 100 emplace_backs: copies=" << ThrowingMove::copies
              << " moves=" << ThrowingMove::moves << '\n';
    assert(ThrowingMove::moves == 0);

    bool threw = false;
    try { t.at(100); } catch (const std::out_of_range&) { threw = true; }
    assert(threw);
    std::cout << "all DynArray tests passed\n";
}
