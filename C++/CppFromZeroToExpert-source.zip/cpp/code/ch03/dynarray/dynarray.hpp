// file: dynarray/dynarray.hpp
#pragma once
#include <cstddef>
#include <memory>
#include <new>
#include <stdexcept>
#include <type_traits>
#include <utility>

template <typename T>
class DynArray {
public:
    DynArray() = default;
    ~DynArray() { clear(); ::operator delete(data_, std::align_val_t{alignof(T)}); }

    DynArray(const DynArray& o) {                          // copy: deep, element by element
        reserve(o.size_);
        for (std::size_t i = 0; i < o.size_; ++i)
            emplace_back(o.data_[i]);
    }
    DynArray(DynArray&& o) noexcept                        // move: steal the buffer
        : data_{std::exchange(o.data_, nullptr)}, size_{std::exchange(o.size_, 0)}, cap_{std::exchange(o.cap_, 0)} {}
    DynArray& operator=(DynArray o) noexcept {             // copy-and-swap covers both assignments
        swap(o);
        return *this;
    }
    void swap(DynArray& o) noexcept {
        std::swap(data_, o.data_);
        std::swap(size_, o.size_);
        std::swap(cap_, o.cap_);
    }

    void push_back(const T& v) { emplace_back(v); }
    void push_back(T&& v) { emplace_back(std::move(v)); }

    template <typename... Args>
    T& emplace_back(Args&&... args) {                      // construct in place
        if (size_ == cap_)
            reserve(cap_ ? cap_ * 2 : 4);
        T* p = std::construct_at(data_ + size_, std::forward<Args>(args)...);
        ++size_;
        return *p;
    }

    void reserve(std::size_t n) {
        if (n <= cap_) return;
        T* fresh = static_cast<T*>(::operator new(n * sizeof(T), std::align_val_t{alignof(T)}));
        std::size_t i = 0;
        try {
            for (; i < size_; ++i)                         // move if noexcept, else copy
                std::construct_at(fresh + i, std::move_if_noexcept(data_[i]));
        } catch (...) {
            std::destroy_n(fresh, i);                      // roll back: old buffer untouched
            ::operator delete(fresh, std::align_val_t{alignof(T)});
            throw;
        }
        std::destroy_n(data_, size_);
        ::operator delete(data_, std::align_val_t{alignof(T)});
        data_ = fresh;
        cap_ = n;
    }

    void clear() noexcept { std::destroy_n(data_, size_); size_ = 0; }
    T& operator[](std::size_t i) { return data_[i]; }
    const T& operator[](std::size_t i) const { return data_[i]; }
    T& at(std::size_t i) { if (i >= size_) throw std::out_of_range("DynArray::at"); return data_[i]; }
    std::size_t size() const { return size_; }
    std::size_t capacity() const { return cap_; }
    T* begin() { return data_; }
    T* end() { return data_ + size_; }

private:
    T* data_ = nullptr;
    std::size_t size_ = 0, cap_ = 0;
};
