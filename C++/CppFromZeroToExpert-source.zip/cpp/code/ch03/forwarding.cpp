// file: forwarding.cpp
#include <iostream>
#include <memory>
#include <string>
#include <utility>

struct Tracer {
    std::string name;
    explicit Tracer(std::string n) : name{std::move(n)} {}
    Tracer(const Tracer& o) : name{o.name} { std::cout << "  copy " << name << '\n'; }
    Tracer(Tracer&& o) noexcept : name{std::move(o.name)} { std::cout << "  move " << name << '\n'; }
};

struct Box {
    Tracer item;
    explicit Box(const Tracer& t) : item{t} {}            // copies
    explicit Box(Tracer&& t) : item{std::move(t)} {}      // moves
};

template <typename T, typename... Args>
std::unique_ptr<T> make(Args&&... args) {                 // forwarding references
    return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}

template <typename T, typename... Args>
std::unique_ptr<T> make_broken(Args&&... args) {          // forgets std::forward
    return std::unique_ptr<T>(new T(args...));            // args are lvalues here: always copies
}

int main() {
    Tracer t{"lvalue-tracer"};
    std::cout << "make<Box>(t):\n";
    auto b1 = make<Box>(t);                               // lvalue in -> copy
    std::cout << "make<Box>(Tracer{...}):\n";
    auto b2 = make<Box>(Tracer{"temp-tracer"});           // rvalue in -> move
    std::cout << "make_broken<Box>(Tracer{...}):\n";
    auto b3 = make_broken<Box>(Tracer{"temp-tracer-2"});  // rvalue in -> copied anyway
}
