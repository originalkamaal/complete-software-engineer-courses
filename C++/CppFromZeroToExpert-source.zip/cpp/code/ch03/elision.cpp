// file: elision.cpp
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Tracer {
    Tracer() { std::cout << "  construct\n"; }
    Tracer(const Tracer&) { std::cout << "  copy\n"; }
    Tracer(Tracer&&) noexcept { std::cout << "  move\n"; }
};

Tracer prvalue() { return Tracer{}; }              // guaranteed elision (C++17)
Tracer named() { Tracer t; return t; }            // NRVO (allowed, done by GCC/Clang)
Tracer pessimised() { Tracer t; return std::move(t); }   // prevents NRVO: forces a move
Tracer two_paths(bool b) {                        // NRVO impossible: which object is returned?
    Tracer x, y;
    if (b) return x;
    return y;                                     // implicitly moved, not copied
}

std::vector<int> big() {
    std::vector<int> v(1'000'000, 7);
    return v;                                     // no copy of a million ints
}

int main() {
    std::cout << "prvalue:\n"; [[maybe_unused]] auto a = prvalue();
    std::cout << "named:\n"; [[maybe_unused]] auto b = named();
    std::cout << "pessimised:\n"; [[maybe_unused]] auto c = pessimised();
    std::cout << "two_paths:\n"; [[maybe_unused]] auto d = two_paths(true);
    auto v = big();
    std::cout << "big() returned " << v.size() << " elements\n";
}
