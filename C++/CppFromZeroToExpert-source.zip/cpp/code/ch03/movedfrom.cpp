// file: movedfrom.cpp
#include <iostream>
#include <string>
#include <utility>
#include <vector>

int main() {
    std::string shortstr = "hi", longstr(40, 'x');
    std::vector<int> v{1, 2, 3};
    std::string a = std::move(shortstr), b = std::move(longstr);
    std::vector<int> w = std::move(v);
    std::cout << "moved-from short string size " << shortstr.size() << ", long string size " << longstr.size()
              << ", vector size " << v.size() << '\n';
    shortstr = "reused";                 // assigning gives it a known value again: always fine
    std::cout << shortstr << '\n';
}
