// file: categories2.cpp
#include <iostream>
#include <string>
#include <type_traits>
#include <utility>

template <typename T> const char* category() {
    if constexpr (std::is_lvalue_reference_v<T>) return "lvalue";
    else if constexpr (std::is_rvalue_reference_v<T>) return "xvalue";
    else return "prvalue";
}
#define SHOW(expr) std::cout << #expr << ": " << category<decltype((expr))>() << '\n'

std::string make() { return "temp"; }
std::string& ref(std::string& s) { return s; }

int main() {
    std::string s = "x";
    int a[3]{};
    SHOW(s);
    SHOW(s + "y");
    SHOW(std::move(s));
    SHOW(make());
    SHOW(ref(s));
    SHOW(a[1]);
    SHOW(42);
    SHOW("literal");
    SHOW(++a[0]);
    SHOW(a[0]++);
}
