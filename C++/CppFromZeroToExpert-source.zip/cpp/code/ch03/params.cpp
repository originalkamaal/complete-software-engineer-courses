// file: params.cpp
#include <iostream>
#include <string>
#include <utility>
#include <vector>

static int allocations;
struct Str {                                   // instrumented string wrapper
    std::string s;
    Str(const char* p) : s{p} { ++allocations; }
    Str(const Str& o) : s{o.s} { ++allocations; }
    Str(Str&& o) noexcept = default;
    Str& operator=(Str&&) noexcept = default;
};

class Person {
public:
    explicit Person(Str name) : name_{std::move(name)} {}   // sink: by value, then move
private:
    Str name_;
};

int main() {
    Str n{"a long name that does not fit in the small string buffer"};
    allocations = 0;
    Person p1{n};                     // lvalue: one copy (into the parameter), then a move
    std::cout << "from lvalue: " << allocations << " allocation(s)\n";
    allocations = 0;
    Person p2{Str{"another long name that will not fit in SSO storage"}};   // temporary: zero copies
    std::cout << "from temporary: " << allocations << " allocation(s) (the temporary itself)\n";
    allocations = 0;
    Person p3{std::move(n)};          // explicitly given up: zero copies
    std::cout << "from std::move: " << allocations << " allocation(s)\n";
}
