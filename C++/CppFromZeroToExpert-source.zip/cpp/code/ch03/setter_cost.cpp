// file: setter_cost.cpp
#include <chrono>
#include <cstdio>
#include <string>
#include <utility>

struct ByValue { std::string name; void set(std::string s) { name = std::move(s); } };
struct ByRef { std::string name; void set(const std::string& s) { name = s; } };

template <typename T> double run(const char* label) {
    T obj;
    std::string input(40, 'n');
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 1'000'000; ++i) { input[0] = char('a' + i % 26); obj.set(input); }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::printf("%-9s %6.1f ms (last: %c)\n", label, ms, obj.name[0]);
    return ms;
}

int main() {
    double v = run<ByValue>("by value");
    double r = run<ByRef>("const&");
    std::printf("by value / const& = %.1fx\n", v / r);
}
