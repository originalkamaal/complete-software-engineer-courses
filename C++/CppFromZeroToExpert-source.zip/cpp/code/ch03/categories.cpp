// file: categories.cpp
#include <iostream>
#include <string>
#include <utility>

void take(const std::string& s) { std::cout << "const& (lvalue or anything): " << s << '\n'; }
void take(std::string&& s) { std::cout << "&& (rvalue: may steal): " << s << '\n'; }

std::string make() { return "from a function"; }

int main() {
    std::string name = "named";
    take(name);                       // lvalue -> const&
    take(std::string("temporary"));   // prvalue -> &&
    take(make());                     // prvalue -> &&
    take(std::move(name));            // xvalue -> &&  (std::move is just a cast)
    take("literal");                  // creates a temporary std::string -> &&

    std::string&& r = make();         // an rvalue reference variable ...
    take(r);                          // ... is itself an lvalue (it has a name): const&
}
