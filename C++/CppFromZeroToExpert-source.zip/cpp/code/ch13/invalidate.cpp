// file: invalidate.cpp
#include <iostream>
#include <vector>

int main() {
    std::vector<int> v{1, 2, 3};
    int& first = v[0];                      // reference into the vector's buffer
    for (int i = 0; i < 10; ++i) v.push_back(i);   // reallocation moves the elements
    std::cout << "first = " << first << '\n';      // use-after-free
}
