// file: fuzzdemo/parse.cpp
#include <cstddef>
#include <cstdint>
#include <cstring>

// Parses "LEN:BYTES" where LEN is one decimal digit. Bug: trusts LEN.
int parse_record(const uint8_t* data, size_t size, char* out /* 8 bytes */) {
    if (size < 2 || data[1] != ':' || data[0] < '0' || data[0] > '9') return -1;
    size_t len = data[0] - '0';
    if (len > 8) return -1;                       // checks the output buffer ...
    std::memcpy(out, data + 2, len);              // ... but not that the input has len bytes
    return static_cast<int>(len);
}

volatile char sink;                               // keeps the result alive, so the optimiser cannot drop the call

extern "C" int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
    char out[8];
    int n = parse_record(data, size, out);
    if (n > 0) sink = out[n - 1];
    return 0;
}
