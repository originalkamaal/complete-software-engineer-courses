// file: gsl_lite.cpp
#include <iostream>
#include <stdexcept>
#include <type_traits>

template <typename P> class not_null {
public:
    not_null(P p) : p_(p) { if (!p_) throw std::invalid_argument("not_null constructed from null"); }
    not_null(std::nullptr_t) = delete;              // a literal nullptr is a compile error
    auto operator->() const { return p_; }
    auto& operator*() const { return *p_; }
private:
    P p_;
};

template <typename To, typename From> To narrow(From x) {
    To y = static_cast<To>(x);
    if (static_cast<From>(y) != x || (std::is_signed_v<From> != std::is_signed_v<To> && ((x < From{}) != (y < To{}))))
        throw std::range_error("narrow: value changed");
    return y;
}

struct Engine { int rpm = 900; };
int read_rpm(not_null<Engine*> e) { return e->rpm; }         // no null check needed here

int main() {
    Engine e;
    std::cout << read_rpm(&e) << '\n';
    Engine* missing = nullptr;
    try { read_rpm(missing); } catch (const std::exception& ex) { std::cout << ex.what() << '\n'; }
    std::cout << narrow<unsigned char>(200) << " fits\n";
    try { narrow<unsigned char>(300); } catch (const std::exception& ex) { std::cout << ex.what() << " (300)\n"; }
    try { narrow<unsigned>(-1); } catch (const std::exception& ex) { std::cout << ex.what() << " (-1 to unsigned)\n"; }
    // read_rpm(nullptr);                            // compile error
}
