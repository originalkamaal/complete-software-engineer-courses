// file: harden.cpp
#include <iostream>
#include <vector>

int main(int argc, char*[]) {
    std::vector<int> v{1, 2, 3};
    std::cout << "reading v[" << argc + 2 << "]" << std::endl;
    std::cout << v[static_cast<std::size_t>(argc + 2)] << std::endl;        // out of bounds
    for (auto it = v.begin(); it != v.end(); ++it)
        if (*it == 2) v.push_back(4);                                         // invalidates it
    std::cout << "done" << std::endl;
}
