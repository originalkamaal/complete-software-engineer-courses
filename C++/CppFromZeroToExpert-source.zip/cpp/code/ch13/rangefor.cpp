// file: rangefor.cpp
#include <iostream>
#include <vector>

struct Holder {
    std::vector<int> v{1, 2, 3};
    const std::vector<int>& items() const { return v; }
};
Holder make_holder() { return {}; }

int main() {
    int sum = 0;
    for (int x : make_holder().items()) sum += x;      // Holder destroyed before the first iteration
    std::cout << sum << '\n';
}
