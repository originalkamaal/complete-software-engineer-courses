// file: race.cpp
#include <iostream>
#include <thread>
#include <vector>

struct Stats { long hits = 0; };

int main() {
    Stats s;
    std::vector<std::jthread> ts;
    for (int t = 0; t < 4; ++t)
        ts.emplace_back([&s] { for (int i = 0; i < 100000; ++i) ++s.hits; });   // unsynchronised
    ts.clear();                                                               // join
    std::cout << "hits = " << s.hits << " (expected 400000)\n";
}
