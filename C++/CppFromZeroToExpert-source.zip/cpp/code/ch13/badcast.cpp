// file: badcast.cpp
#include <iostream>

struct Shape { virtual ~Shape() = default; virtual double area() const = 0; };
struct Circle : Shape { double r = 1; double area() const override { return 3.14159 * r * r; } };
struct Square : Shape { double s = 2; double area() const override { return s * s; } long extra = 42; };

int main() {
    Circle c;
    Shape* p = &c;
    auto* sq = static_cast<Square*>(p);            // wrong: p points to a Circle
    std::cout << sq->extra << '\n';
}
