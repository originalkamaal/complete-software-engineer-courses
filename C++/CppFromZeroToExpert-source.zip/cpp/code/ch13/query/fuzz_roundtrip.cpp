// file: query/fuzz_roundtrip.cpp
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string_view>
#include "query.hpp"

extern "C" int LLVMFuzzerTestOneInput(const std::uint8_t* data, std::size_t size) {
    std::string_view input{reinterpret_cast<const char*>(data), size};
    query::Pairs once = query::parse(input);
    query::Pairs twice = query::parse(query::serialize(once));
    if (once != twice) {                                                   // the round-trip property
        std::fprintf(stderr, "round-trip mismatch: %zu pairs became %zu\n", once.size(), twice.size());
        std::abort();
    }
    return 0;
}
