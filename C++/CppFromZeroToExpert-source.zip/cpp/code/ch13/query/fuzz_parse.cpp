// file: query/fuzz_parse.cpp
#include <cstdint>
#include <string_view>
#include "query.hpp"

extern "C" int LLVMFuzzerTestOneInput(const std::uint8_t* data, std::size_t size) {
    std::string_view input{reinterpret_cast<const char*>(data), size};   // exact length, not NUL-terminated
    (void)query::parse(input);
    return 0;
}
