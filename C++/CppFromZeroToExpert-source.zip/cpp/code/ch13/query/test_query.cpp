// file: query/test_query.cpp
#include <cassert>
#include <iostream>
#include "query.hpp"

int main() {
    using query::Pairs;
    assert((query::parse("a=1&b=two%20words") == Pairs{{"a", "1"}, {"b", "two words"}}));
    assert((query::parse("name=Ada+L&lang=c%2B%2B&x") == Pairs{{"name", "Ada L"}, {"lang", "c++"}, {"x", ""}}));
    assert((query::parse("&&a=&") == Pairs{{"a", ""}}));
    assert((query::parse("bad=%zz") == Pairs{{"bad", "%zz"}}));
    assert(query::serialize({{"q", "x & y"}, {"n", "1"}}) == "q=x+%26+y&n=1");
    Pairs p{{"k", "v=w"}, {"empty", ""}};
    assert(query::parse(query::serialize(p)) == p);
    std::cout << "all unit tests passed\n";
}
