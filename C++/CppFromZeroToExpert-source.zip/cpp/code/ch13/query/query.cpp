// file: query/query.cpp
#include "query.hpp"
#include <cctype>

namespace query {
namespace {
int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

std::string decode(std::string_view s) {
    std::string out;
    for (std::size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '+') {
            out += ' ';
        } else if (s[i] == '%') {
            int hi = i + 2 < s.size() ? hexval(s[i + 1]) : -1;      // fixed: never read past the end
            int lo = i + 2 < s.size() ? hexval(s[i + 2]) : -1;
            if (hi >= 0 && lo >= 0) { out += static_cast<char>(hi * 16 + lo); i += 2; }
            else out += '%';
        } else {
            out += s[i];
        }
    }
    return out;
}

std::string encode(std::string_view s) {
    static constexpr char hex[] = "0123456789ABCDEF";
    std::string out;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') out += static_cast<char>(c);
        else if (c == ' ') out += '+';
        else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
    }
    return out;
}
}  // namespace

Pairs parse(std::string_view s) {
    Pairs out;
    while (!s.empty()) {
        std::size_t amp = s.find('&');
        std::string_view item = s.substr(0, amp);
        s = amp == std::string_view::npos ? std::string_view{} : s.substr(amp + 1);
        if (item.empty()) continue;
        std::size_t eq = item.find('=');
        if (eq == std::string_view::npos) out.emplace_back(decode(item), "");
        else out.emplace_back(decode(item.substr(0, eq)), decode(item.substr(eq + 1)));
    }
    return out;
}

std::string serialize(const Pairs& ps) {
    std::string out;
    for (const auto& p : ps) {
        const auto& [k, v] = p;
        if (&p != ps.data()) out += '&';                     // fixed: separator by position
        out += encode(k);
        if (!v.empty() || k.empty()) { out += '='; out += encode(v); }   // fixed: ("", "") -> "="
    }
    return out;
}
}  // namespace query
