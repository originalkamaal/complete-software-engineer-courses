// file: query/test_regressions.cpp
#include <cassert>
#include <iostream>
#include <string>
#include "query.hpp"

int main() {
    using query::Pairs;
    std::string trailing = "a=%2";                                  // found1: a truncated escape at the very end
    assert((query::parse(std::string_view{trailing.data(), trailing.size()}) == Pairs{{"a", "%2"}}));
    assert((query::parse("x=%") == Pairs{{"x", "%"}}));
    Pairs p{{"", ""}, {"u", ""}};                                    // found2: empty key and value, then another pair
    assert(query::parse(query::serialize(p)) == p);
    std::cout << "regression tests passed\n";
}
