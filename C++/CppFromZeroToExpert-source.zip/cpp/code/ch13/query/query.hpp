// file: query/query.hpp
#pragma once
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace query {
using Pairs = std::vector<std::pair<std::string, std::string>>;
Pairs parse(std::string_view s);          // "a=1&b=two%20words" -> {{"a","1"},{"b","two words"}}
std::string serialize(const Pairs& ps);   // inverse of parse
}
