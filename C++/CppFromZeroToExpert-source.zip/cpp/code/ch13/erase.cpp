// file: erase.cpp
#include <iostream>
#include <map>
#include <vector>

int main() {
    std::vector<int> v{1, 2, 3, 4, 5, 6};
    std::erase_if(v, [](int x) { return x % 2 == 0; });          // C++20: one call, linear time
    std::map<int, char> m{{1, 'a'}, {2, 'b'}, {3, 'c'}, {4, 'd'}};
    for (auto it = m.begin(); it != m.end();)                      // manual: erase returns the next iterator
        it = (it->first % 2 == 0) ? m.erase(it) : std::next(it);
    for (int x : v) std::cout << x << ' ';
    for (auto& [k, c] : m) std::cout << k << c << ' ';
    std::cout << '\n';
}
