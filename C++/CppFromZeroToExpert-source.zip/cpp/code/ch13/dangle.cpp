// file: dangle.cpp
#include <algorithm>
#include <iostream>
#include <string>
#include <string_view>

std::string make_name() { return "a name long enough to be on the heap"; }

int main() {
    const int& m = std::max(1, 2);               // max returns a reference to one of its (temporary) arguments
    std::cout << "max: " << m << '\n';           // the temporaries died at the end of the previous line

    std::string_view v = make_name();            // view of a temporary std::string, destroyed at the ';'
    std::cout << "view: " << v << '\n';
}
