// file: assertions.cpp
#include <chrono>
#include <cstdio>
#include <vector>

int main(int argc, char**) {
    std::vector<int> v(10'000'000, 1);
    long sum = 0;
    auto t0 = std::chrono::steady_clock::now();
    for (int rep = 0; rep < 20; ++rep)
        for (std::size_t i = 0; i < v.size(); ++i) sum += v[i];
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::printf("sum %ld (%s)\n", sum, ms < 1000 ? "under a second" : "slow");
    if (argc > 1) std::printf("v[v.size()] = %d\n", v[v.size()]);    // one past the end
}
