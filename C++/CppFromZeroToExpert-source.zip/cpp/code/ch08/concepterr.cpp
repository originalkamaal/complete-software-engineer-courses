// file: concepterr.cpp
#include <algorithm>
#include <concepts>
#include <list>
#include <vector>

template <typename C> void sort_all(C& c) { std::sort(c.begin(), c.end()); }

template <typename C>
    requires std::random_access_iterator<typename C::iterator>
void sort_all_c(C& c) { std::sort(c.begin(), c.end()); }

int main() {
    std::vector<int> v{3, 1, 2};
    sort_all(v);
    sort_all_c(v);
#ifdef BAD_PLAIN
    std::list<int> l{3, 1, 2};
    sort_all(l);
#endif
#ifdef BAD_CONCEPT
    std::list<int> l{3, 1, 2};
    sort_all_c(l);
#endif
}
