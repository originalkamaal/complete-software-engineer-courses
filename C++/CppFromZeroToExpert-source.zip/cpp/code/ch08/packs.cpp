// file: packs.cpp
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <utility>

struct Widget {
    Widget(std::string n, int w, int h) : name(std::move(n)), area(w * h) {}
    std::string name; int area;
};

template <typename T, typename... Args> std::unique_ptr<T> make(Args&&... args) {
    std::cout << "make with " << sizeof...(args) << " arguments\n";
    return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}

template <std::size_t N, typename... Ts> decltype(auto) nth(Ts&&... ts) {
    return std::get<N>(std::forward_as_tuple(std::forward<Ts>(ts)...));
}

template <typename... Ts> void print_all(const Ts&... ts) {
    std::size_t i = 0;
    ((std::cout << (i++ ? ", " : "") << ts), ...);       // fold over the comma operator
    std::cout << '\n';
}

int main() {
    auto w = make<Widget>(std::string("panel"), 3, 4);
    std::cout << w->name << " area " << w->area << '\n';
    std::cout << "nth<1>: " << nth<1>("a", 2.5, 'c') << '\n';
    print_all(1, "two", 3.0, '4');
}
