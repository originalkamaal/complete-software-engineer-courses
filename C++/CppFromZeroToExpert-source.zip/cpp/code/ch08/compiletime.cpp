// file: compiletime.cpp
#include <algorithm>
#include <array>
#include <iostream>
#include <string_view>
#include <vector>

constexpr std::array<bool, 100> sieve() {               // primes below 100, at compile time
    std::array<bool, 100> prime{};
    prime.fill(true);
    prime[0] = prime[1] = false;
    for (std::size_t i = 2; i * i < prime.size(); ++i)
        if (prime[i])
            for (std::size_t j = i * i; j < prime.size(); j += i) prime[j] = false;
    return prime;
}

constexpr int count_unique(std::initializer_list<int> values) {
    std::vector<int> v(values);                         // a std::vector inside a constant expression (C++20)
    std::sort(v.begin(), v.end());
    return static_cast<int>(std::unique(v.begin(), v.end()) - v.begin());
}

consteval std::size_t checked_index(std::string_view key) {
    constexpr std::string_view keys[] = {"red", "green", "blue"};
    for (std::size_t i = 0; i < 3; ++i)
        if (keys[i] == key) return i;
    throw "unknown key";                                // in consteval: becomes a compile error
}

constexpr auto PRIMES = sieve();
static_assert(PRIMES[97] && !PRIMES[91]);
static_assert(count_unique({3, 1, 3, 2, 1}) == 3);

int main() {
    int n = 0;
    for (bool p : PRIMES) n += p;
    std::cout << n << " primes below 100 (table built by the compiler)\n";
    std::cout << "index of green: " << checked_index("green") << '\n';
    // checked_index("purple");   error: 'throw' is not a constant expression: caught at compile time
}
