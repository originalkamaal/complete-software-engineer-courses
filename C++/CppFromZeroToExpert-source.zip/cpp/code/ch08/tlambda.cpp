// file: tlambda.cpp
#include <concepts>
#include <iostream>
#include <string>
#include <vector>

int main() {
    auto first_or = []<typename T>(const std::vector<T>& v, T fallback) {   // names T: both args must agree
        return v.empty() ? fallback : v.front();
    };
    auto twice = []<std::integral T>(T x) { return 2 * x; };                  // constrained
    std::cout << first_or(std::vector<int>{}, -1) << ' ' << first_or(std::vector<std::string>{"a"}, std::string("z"))
              << ' ' << twice(21) << '\n';
    // twice(1.5);   error: constraints not satisfied
}
