// file: tlambda2.cpp
#include <iostream>
#include <string>
#include <vector>

int main() {
    auto same_type_max = []<typename T>(const T& a, const T& b) { return a < b ? b : a; };
    auto element_size = []<typename T>(const std::vector<T>&) { return sizeof(T); };
    auto loose = [](auto a, auto b) { return a < b ? b : a; };

    std::cout << same_type_max(3, 9) << ' ' << same_type_max(std::string("a"), std::string("b")) << '\n';
    std::cout << element_size(std::vector<double>{}) << ' ' << element_size(std::vector<char>{}) << '\n';
    std::cout << loose(1, 2.5) << '\n';          // int and double mixed: compiles, result type double
    // same_type_max(1, 2.5);                    // error: T deduced as both int and double
}
