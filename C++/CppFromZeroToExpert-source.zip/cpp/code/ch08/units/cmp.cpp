#include "units.hpp"
double f(double a, double b) { return a / b; }
auto g(Length a, Time b) { return a / b; }
