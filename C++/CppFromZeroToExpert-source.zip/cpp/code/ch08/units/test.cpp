// file: units/test.cpp
#include <iostream>
#include "units.hpp"

using namespace literals;

constexpr Energy kinetic_energy(Mass m, Velocity v) { return 0.5 * (m * v * v); }

static_assert(std::is_same_v<decltype(1.0_m / 1.0_s), Velocity>);
static_assert(std::is_same_v<decltype(1.0_kg * (1.0_m / (1.0_s * 1.0_s))), Force>);
static_assert(kinetic_energy(2.0_kg, Velocity{3.0}).value() == 9.0);       // checked by the compiler
static_assert(sizeof(Length) == sizeof(double));                          // zero overhead in size

int main() {
    Length trip = 42.195_km;
    Time duration = 2.0_h + 1.0_s * 2340;                       // 2:39:00
    Velocity pace = trip / duration;
    std::cout << "marathon distance: " << trip << '\n';
    std::cout << "average speed: " << pace << " = " << in(pace, Velocity{1000.0 / 3600}) << " km/h\n";

    Mass m = 70.0_kg;
    Acceleration g{9.81};
    Force weight = m * g;
    std::cout << "weight: " << weight << '\n';
    std::cout << "kinetic energy: " << kinetic_energy(m, pace) << '\n';
    std::cout << "is the trip longer than 40 km? " << std::boolalpha << (trip > 40.0_km) << '\n';
    // auto nonsense = trip + duration;   error: no match for 'operator+' (Length and Time)
    // Velocity wrong = trip * duration;  error: cannot convert Quantity<Dim<1,0,1>> to Velocity
}
