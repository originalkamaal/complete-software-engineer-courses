// file: units/units.hpp
#pragma once
#include <concepts>
#include <ostream>
#include <ratio>

template <int L, int M, int T>            // exponents of length, mass, time
struct Dim {
    static constexpr int length = L, mass = M, time = T;
};

template <typename D1, typename D2>
using dim_multiply = Dim<D1::length + D2::length, D1::mass + D2::mass, D1::time + D2::time>;
template <typename D1, typename D2>
using dim_divide = Dim<D1::length - D2::length, D1::mass - D2::mass, D1::time - D2::time>;

template <typename D>
class Quantity {
public:
    constexpr explicit Quantity(double v) : value_{v} {}
    constexpr double value() const { return value_; }      // in SI base units

    constexpr Quantity& operator+=(Quantity o) { value_ += o.value_; return *this; }
    friend constexpr Quantity operator+(Quantity a, Quantity b) { return a += b; }   // same D only
    friend constexpr Quantity operator-(Quantity a, Quantity b) { return Quantity{a.value_ - b.value_}; }
    friend constexpr auto operator<=>(Quantity, Quantity) = default;
    friend constexpr Quantity operator*(double k, Quantity q) { return Quantity{k * q.value_}; }
    friend constexpr Quantity operator*(Quantity q, double k) { return Quantity{q.value_ * k}; }

    template <typename D2>
    friend constexpr auto operator*(Quantity a, Quantity<D2> b) { return Quantity<dim_multiply<D, D2>>{a.value_ * b.value()}; }
    template <typename D2>
    friend constexpr auto operator/(Quantity a, Quantity<D2> b) { return Quantity<dim_divide<D, D2>>{a.value_ / b.value()}; }

private:
    double value_;
};

using Dimensionless = Dim<0, 0, 0>;
using Length = Quantity<Dim<1, 0, 0>>;
using Mass = Quantity<Dim<0, 1, 0>>;
using Time = Quantity<Dim<0, 0, 1>>;
using Velocity = Quantity<Dim<1, 0, -1>>;
using Acceleration = Quantity<Dim<1, 0, -2>>;
using Force = Quantity<Dim<1, 1, -2>>;
using Energy = Quantity<Dim<2, 1, -2>>;

namespace literals {
constexpr Length operator""_m(long double v) { return Length{static_cast<double>(v)}; }
constexpr Length operator""_km(long double v) { return Length{static_cast<double>(v) * 1000}; }
constexpr Mass operator""_kg(long double v) { return Mass{static_cast<double>(v)}; }
constexpr Time operator""_s(long double v) { return Time{static_cast<double>(v)}; }
constexpr Time operator""_h(long double v) { return Time{static_cast<double>(v) * 3600}; }
}

template <typename D>
concept PhysicalDim = requires { D::length; D::mass; D::time; };

template <PhysicalDim D>
std::ostream& operator<<(std::ostream& os, Quantity<D> q) {
    os << q.value();
    auto unit = [&os](const char* sym, int e) { if (e) { os << ' ' << sym; if (e != 1) os << '^' << e; } };
    unit("m", D::length);
    unit("kg", D::mass);
    unit("s", D::time);
    return os;
}

template <typename D>
constexpr double in(Quantity<D> q, Quantity<D> unit) { return q.value() / unit.value(); }   // explicit conversion
