#include "units.hpp"
using namespace literals;
int main() { auto x = 1.0_m + 1.0_s; (void)x; }
