// file: concepts.cpp
#include <algorithm>
#include <concepts>
#include <iostream>
#include <list>
#include <string>
#include <vector>

template <typename T>
concept Shape = requires(const T& s) {               // a custom concept: what a Shape must support
    { s.area() } -> std::convertible_to<double>;
    { s.name() } -> std::convertible_to<std::string>;
};

struct Circle { double r; double area() const { return 3.14159 * r * r; } std::string name() const { return "circle"; } };
struct Square { double s; double area() const { return s * s; } std::string name() const { return "square"; } };
struct Blob { int size; };

void describe(const Shape auto& s) {                 // abbreviated function template with a constraint
    std::cout << s.name() << " with area " << s.area() << '\n';
}

// Overloading by constraint: the more specific concept wins.
template <std::integral T> std::string kind(T) { return "integral"; }
template <std::signed_integral T> std::string kind(T) { return "signed integral (more constrained)"; }
template <std::floating_point T> std::string kind(T) { return "floating point"; }

template <typename C>
    requires std::ranges::random_access_range<C>     // requires clause
void sort_container(C& c) { std::sort(c.begin(), c.end()); }

int main() {
    describe(Circle{1});
    describe(Square{2});
    // describe(Blob{3});   error: the constraint 'Shape<Blob>' is not satisfied
    std::cout << kind(1u) << " | " << kind(-1) << " | " << kind(2.5) << '\n';
    std::vector<int> v{3, 1, 2};
    sort_container(v);
    std::cout << v[0] << v[1] << v[2] << '\n';
}
