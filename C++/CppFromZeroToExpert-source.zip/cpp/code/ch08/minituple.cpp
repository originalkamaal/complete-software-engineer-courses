// file: minituple.cpp
#include <iostream>
#include <string>

template <typename... Ts> struct Tuple {};                       // empty case ends the recursion

template <typename Head, typename... Tail>
struct Tuple<Head, Tail...> {
    Head head;
    Tuple<Tail...> tail;
};

template <std::size_t I, typename Head, typename... Tail>
auto& get(Tuple<Head, Tail...>& t) {
    if constexpr (I == 0) return t.head;
    else return get<I - 1>(t.tail);
}

int main() {
    Tuple<int, std::string, double> t{1, {"two", {3.0, {}}}};
    get<1>(t) += "!";
    std::cout << get<0>(t) << ' ' << get<1>(t) << ' ' << get<2>(t) << '\n';
    std::cout << "sizeof(Tuple<int, std::string, double>) = " << sizeof(t)
              << ", sizeof(std::tuple<...>) = " << sizeof(std::tuple<int, std::string, double>) << '\n';
}
