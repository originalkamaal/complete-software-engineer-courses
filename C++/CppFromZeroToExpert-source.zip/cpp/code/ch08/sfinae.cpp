// file: sfinae.cpp
#include <iostream>
#include <string>
#include <type_traits>

// C++11: enable_if in the return type
template <typename T>
std::enable_if_t<std::is_integral_v<T>, std::string> kind11(T) { return "integral"; }
template <typename T>
std::enable_if_t<!std::is_integral_v<T>, std::string> kind11(T) { return "not integral"; }

// C++11: expression SFINAE — this overload exists only if t.size() is valid
template <typename T> auto size_or(const T& t, int) -> decltype(t.size(), std::size_t{}) { return t.size(); }
template <typename T> std::size_t size_or(const T&, long) { return 0; }

// C++20: the same with requires
template <typename T> std::size_t size20(const T& t) {
    if constexpr (requires { t.size(); }) return t.size(); else return 0;
}

int main() {
    std::cout << kind11(3) << ", " << kind11(3.5) << '\n';
    std::cout << size_or(std::string("abcd"), 0) << ", " << size_or(42, 0) << '\n';
    std::cout << size20(std::string("abcd")) << ", " << size20(42) << '\n';
}
