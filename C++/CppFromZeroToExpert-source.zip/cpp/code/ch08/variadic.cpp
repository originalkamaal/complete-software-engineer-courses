// file: variadic.cpp
#include <algorithm>
#include <iostream>
#include <string>
#include <utility>

template <typename... Ts>
auto sum(Ts... xs) { return (xs + ... + 0); }                 // binary right fold with an initial value

template <typename... Ts>
void print_all(const Ts&... xs) {
    ((std::cout << xs << ' '), ...);                         // comma fold: one output per argument
    std::cout << "(" << sizeof...(xs) << " args)\n";
}

template <typename T, typename... Ts>
bool all_equal(const T& first, const Ts&... rest) { return ((first == rest) && ...); }   // && fold

template <typename F, typename... Args>
auto call_logged(const std::string& name, F&& f, Args&&... args) {   // perfect forwarding of a pack
    std::cout << "calling " << name << " with " << sizeof...(Args) << " argument(s)\n";
    return std::forward<F>(f)(std::forward<Args>(args)...);
}

// Recursive style (pre-C++17), still useful when each step differs:
void print_typed() { std::cout << '\n'; }
template <typename T, typename... Rest>
void print_typed(const T& x, const Rest&... rest) {
    if constexpr (std::is_same_v<T, std::string>) std::cout << '"' << x << "\" ";
    else std::cout << x << ' ';
    print_typed(rest...);
}

int main() {
    std::cout << sum(1, 2, 3, 4) << ' ' << sum(1.5, 2) << ' ' << sum() << '\n';
    print_all("mixed", 42, 3.5, 'c');
    std::cout << std::boolalpha << all_equal(7, 7, 7) << ' ' << all_equal(1, 1, 2) << '\n';
    auto r = call_logged("max", [](int a, int b, int c) { return std::max({a, b, c}); }, 4, 9, 2);
    std::cout << "result " << r << '\n';
    print_typed(std::string("name"), 3, std::string("x"), 2.5);
}
