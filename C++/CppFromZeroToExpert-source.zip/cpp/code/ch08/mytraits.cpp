// file: mytraits.cpp
#include <iostream>
#include <list>
#include <string>
#include <type_traits>
#include <vector>

template <typename T> struct is_vector : std::false_type {};               // primary: false
template <typename T, typename A> struct is_vector<std::vector<T, A>> : std::true_type {};   // partial: true
template <typename T> constexpr bool is_vector_v = is_vector<T>::value;

template <typename T, typename = void>
struct has_size : std::false_type {};
template <typename T>
struct has_size<T, std::void_t<decltype(std::declval<const T&>().size())>> : std::true_type {};   // detection idiom

// Legacy SFINAE: enable_if removes the overload when the condition is false
template <typename T, std::enable_if_t<std::is_integral_v<T>, int> = 0>
std::string old_style(T) { return "integral (enable_if)"; }
template <typename T, std::enable_if_t<!std::is_integral_v<T>, int> = 0>
std::string old_style(T) { return "other (enable_if)"; }

// The same with a concept-style requires clause
template <typename T> requires std::is_integral_v<T> std::string new_style(T) { return "integral (requires)"; }
template <typename T> std::string new_style(T) { return "other (unconstrained)"; }

int main() {
    std::cout << std::boolalpha << is_vector_v<std::vector<int>> << ' ' << is_vector_v<std::list<int>> << '\n';
    std::cout << has_size<std::string>::value << ' ' << has_size<int>::value << '\n';
    std::cout << old_style(1) << ", " << old_style(1.5) << '\n';
    std::cout << new_style(1) << ", " << new_style(1.5) << '\n';
    decltype(1 + 2.0) d = 0;                                                // double
    std::cout << "decltype(1 + 2.0) is double: " << std::is_same_v<decltype(d), double> << '\n';
}
