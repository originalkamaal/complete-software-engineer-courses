// file: tuples.cpp
#include <iostream>
#include <string>
#include <tuple>
#include <utility>

template <typename Tuple, std::size_t... I>
void print_tuple_impl(const Tuple& t, std::index_sequence<I...>) {
    ((std::cout << (I == 0 ? "(" : ", ") << std::get<I>(t)), ...);
    std::cout << ")\n";
}

template <typename... Ts>
void print_tuple(const std::tuple<Ts...>& t) {
    print_tuple_impl(t, std::index_sequence_for<Ts...>{});     // 0, 1, ..., N-1
}

template <typename... Ts>
class TypeList {                                               // a compile-time list of types
public:
    static constexpr std::size_t size = sizeof...(Ts);
    template <typename T>
    static constexpr bool contains = (std::is_same_v<T, Ts> || ...);
};

int main() {
    auto record = std::make_tuple(std::string("ada"), 36, 1.75);
    print_tuple(record);
    auto [name, age, height] = record;                         // structured bindings work on tuples
    std::cout << name << " is " << age << '\n';
    auto total = std::apply([](const auto&... xs) { return sizeof...(xs); }, record);
    std::cout << "apply sees " << total << " elements\n";

    using Numbers = TypeList<int, long, double>;
    static_assert(Numbers::size == 3 && Numbers::contains<long> && !Numbers::contains<char>);
    std::cout << "TypeList checks passed at compile time\n";
}
