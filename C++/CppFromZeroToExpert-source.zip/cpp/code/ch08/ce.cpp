#include <string_view>
consteval int f(std::string_view k) { if (k == "ok") return 1; throw "bad key"; }
int main() { return f("typo"); }
