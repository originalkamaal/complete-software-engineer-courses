// file: ob/src/order_book.cpp
#include "ob/order_book.hpp"
#include <algorithm>
#include <iterator>

namespace ob {

OrderBook::OrderBook(std::pmr::memory_resource* mr) : mr_{mr}, bids_{mr}, asks_{mr}, index_{mr} {}

template <typename Book>
void OrderBook::match(Book& opposite, Order& in, std::vector<Trade>& trades) {
    while (in.qty > 0 && !opposite.empty()) {
        auto level = opposite.begin();                               // best opposite price
        bool crosses = in.side == Side::Buy ? level->first <= in.price : level->first >= in.price;
        if (!crosses) break;
        Level& lvl = level->second;
        while (in.qty > 0 && !lvl.queue.empty()) {
            Resting& maker = lvl.queue.front();                      // oldest order at this price
            Qty q = std::min(in.qty, maker.qty);
            trades.push_back({in.id, maker.id, level->first, q});   // at the maker's price
            in.qty -= q;
            maker.qty -= q;
            lvl.total -= q;
            if (maker.qty == 0) {
                index_.erase(maker.id);
                lvl.queue.pop_front();
            }
        }
        if (lvl.queue.empty()) opposite.erase(level);
    }
}

template <typename Book>
void OrderBook::rest(Book& book, const Order& o) {
    auto [level, inserted] = book.try_emplace(o.price, mr_);
    Level& lvl = level->second;
    lvl.queue.push_back({o.id, o.qty});
    lvl.total += o.qty;
    index_.emplace(o.id, Locator{o.side, o.price, std::prev(lvl.queue.end())});
}

template <typename Book>
void OrderBook::remove(Book& book, const Locator& loc) {
    auto level = book.find(loc.price);
    Level& lvl = level->second;
    lvl.total -= loc.it->qty;
    lvl.queue.erase(loc.it);                                         // O(1): we hold the iterator
    if (lvl.queue.empty()) book.erase(level);
}

AddResult OrderBook::add(const Order& order, std::vector<Trade>& trades) {
    if (order.qty <= 0) return AddResult::InvalidQty;
    if (index_.contains(order.id)) return AddResult::DuplicateId;
    Order in = order;
    if (in.side == Side::Buy) match(asks_, in, trades);
    else match(bids_, in, trades);
    if (in.qty > 0 && in.kind == Kind::Limit) {
        if (in.side == Side::Buy) rest(bids_, in);
        else rest(asks_, in);
    }
    return AddResult::Ok;
}

bool OrderBook::cancel(OrderId id) {
    auto it = index_.find(id);
    if (it == index_.end()) return false;
    Locator loc = it->second;
    index_.erase(it);
    if (loc.side == Side::Buy) remove(bids_, loc);
    else remove(asks_, loc);
    return true;
}

std::optional<Price> OrderBook::best_bid() const {
    if (bids_.empty()) return std::nullopt;
    return bids_.begin()->first;
}

std::optional<Price> OrderBook::best_ask() const {
    if (asks_.empty()) return std::nullopt;
    return asks_.begin()->first;
}

Qty OrderBook::depth(Side side, Price price) const {
    auto total = [price](const auto& book) -> Qty {
        auto level = book.find(price);
        return level == book.end() ? 0 : level->second.total;
    };
    return side == Side::Buy ? total(bids_) : total(asks_);
}

}  // namespace ob
