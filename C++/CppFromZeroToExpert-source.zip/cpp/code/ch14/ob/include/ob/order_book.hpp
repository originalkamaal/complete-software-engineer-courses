// file: ob/include/ob/order_book.hpp
#pragma once
#include <cstdint>
#include <functional>
#include <list>
#include <map>
#include <memory_resource>
#include <optional>
#include <unordered_map>
#include <vector>

namespace ob {

using OrderId = std::uint64_t;
using Price = std::int64_t;                       // in ticks: never a floating-point price
using Qty = std::int64_t;

enum class Side : std::uint8_t { Buy, Sell };
enum class Kind : std::uint8_t { Limit, IOC };    // IOC: immediate-or-cancel, never rests

struct Order {
    OrderId id;
    Side side;
    Price price;
    Qty qty;
    Kind kind = Kind::Limit;
};

struct Trade {
    OrderId taker;                                // the incoming order
    OrderId maker;                                // the resting order it matched
    Price price;                                  // always the maker's price
    Qty qty;
    friend bool operator==(const Trade&, const Trade&) = default;
};

enum class AddResult : std::uint8_t { Ok, DuplicateId, InvalidQty };

class OrderBook {
public:
    explicit OrderBook(std::pmr::memory_resource* mr = std::pmr::get_default_resource());
    OrderBook(const OrderBook&) = delete;         // the index holds iterators into the book: no copies
    OrderBook& operator=(const OrderBook&) = delete;

    AddResult add(const Order& order, std::vector<Trade>& trades);   // appends any trades
    bool cancel(OrderId id);

    [[nodiscard]] std::optional<Price> best_bid() const;
    [[nodiscard]] std::optional<Price> best_ask() const;
    [[nodiscard]] Qty depth(Side side, Price price) const;
    [[nodiscard]] std::size_t order_count() const { return index_.size(); }

private:
    struct Resting { OrderId id; Qty qty; };
    struct Level {
        std::pmr::list<Resting> queue;            // FIFO: front is the oldest order
        Qty total = 0;
        explicit Level(std::pmr::memory_resource* mr) : queue{mr} {}
    };
    using Bids = std::pmr::map<Price, Level, std::greater<>>;   // begin() = highest bid
    using Asks = std::pmr::map<Price, Level, std::less<>>;      // begin() = lowest ask
    struct Locator { Side side; Price price; std::pmr::list<Resting>::iterator it; };

    template <typename Book> void match(Book& opposite, Order& incoming, std::vector<Trade>& trades);
    template <typename Book> void rest(Book& book, const Order& order);
    template <typename Book> void remove(Book& book, const Locator& loc);

    std::pmr::memory_resource* mr_;
    Bids bids_;
    Asks asks_;
    std::pmr::unordered_map<OrderId, Locator> index_;
};

}  // namespace ob
