// file: ob/tests/order_book_test.cpp
#include <gtest/gtest.h>
#include <algorithm>
#include <random>
#include <vector>
#include "ob/order_book.hpp"

using namespace ob;

namespace {
std::vector<Trade> add(OrderBook& b, OrderId id, Side s, Price p, Qty q, Kind k = Kind::Limit) {
    std::vector<Trade> t;
    EXPECT_EQ(b.add({id, s, p, q, k}, t), AddResult::Ok);
    return t;
}
}  // namespace

TEST(OrderBook, RestsWhenNotCrossing) {
    OrderBook b;
    EXPECT_TRUE(add(b, 1, Side::Buy, 99, 10).empty());
    EXPECT_TRUE(add(b, 2, Side::Sell, 101, 5).empty());
    EXPECT_EQ(b.best_bid(), 99);
    EXPECT_EQ(b.best_ask(), 101);
    EXPECT_EQ(b.order_count(), 2u);
}

TEST(OrderBook, TradesAtMakerPrice) {
    OrderBook b;
    add(b, 1, Side::Sell, 100, 5);
    auto t = add(b, 2, Side::Buy, 105, 5);                // willing to pay 105, pays 100
    ASSERT_EQ(t.size(), 1u);
    EXPECT_EQ(t[0], (Trade{2, 1, 100, 5}));
    EXPECT_FALSE(b.best_ask());
    EXPECT_FALSE(b.best_bid());
}

TEST(OrderBook, PartialFillRestsRemainder) {
    OrderBook b;
    add(b, 1, Side::Sell, 100, 3);
    auto t = add(b, 2, Side::Buy, 100, 10);
    EXPECT_EQ(t, (std::vector<Trade>{{2, 1, 100, 3}}));
    EXPECT_EQ(b.best_bid(), 100);
    EXPECT_EQ(b.depth(Side::Buy, 100), 7);
}

TEST(OrderBook, PriceThenTimePriority) {
    OrderBook b;
    add(b, 1, Side::Sell, 100, 1);
    add(b, 2, Side::Sell, 100, 1);
    add(b, 3, Side::Sell, 99, 1);                         // better price, arrived last
    auto t = add(b, 4, Side::Buy, 100, 3);
    EXPECT_EQ(t, (std::vector<Trade>{{4, 3, 99, 1}, {4, 1, 100, 1}, {4, 2, 100, 1}}));
}

TEST(OrderBook, SweepsLevelsAndStopsAtLimit) {
    OrderBook b;
    add(b, 1, Side::Buy, 100, 2);
    add(b, 2, Side::Buy, 99, 2);
    add(b, 3, Side::Buy, 98, 2);
    auto t = add(b, 4, Side::Sell, 99, 10);               // takes 100 and 99, not 98
    EXPECT_EQ(t, (std::vector<Trade>{{4, 1, 100, 2}, {4, 2, 99, 2}}));
    EXPECT_EQ(b.best_bid(), 98);
    EXPECT_EQ(b.best_ask(), 99);                          // remainder rests at its limit
    EXPECT_EQ(b.depth(Side::Sell, 99), 6);
}

TEST(OrderBook, CancelRemovesOrderAndEmptyLevel) {
    OrderBook b;
    add(b, 1, Side::Buy, 100, 5);
    add(b, 2, Side::Buy, 100, 7);
    EXPECT_TRUE(b.cancel(1));
    EXPECT_EQ(b.depth(Side::Buy, 100), 7);
    EXPECT_TRUE(b.cancel(2));
    EXPECT_FALSE(b.best_bid());
    EXPECT_FALSE(b.cancel(2));                            // already gone
    EXPECT_FALSE(b.cancel(42));                           // never existed
}

TEST(OrderBook, RejectsInvalidOrdersWithoutSideEffects) {
    OrderBook b;
    std::vector<Trade> t;
    add(b, 1, Side::Sell, 100, 5);
    EXPECT_EQ(b.add({1, Side::Buy, 100, 5}, t), AddResult::DuplicateId);
    EXPECT_EQ(b.add({2, Side::Buy, 100, 0}, t), AddResult::InvalidQty);
    EXPECT_EQ(b.add({3, Side::Buy, 100, -4}, t), AddResult::InvalidQty);
    EXPECT_TRUE(t.empty());
    EXPECT_EQ(b.depth(Side::Sell, 100), 5);
}

TEST(OrderBook, IocNeverRests) {
    OrderBook b;
    add(b, 1, Side::Sell, 100, 2);
    auto t = add(b, 2, Side::Buy, 100, 5, Kind::IOC);
    EXPECT_EQ(t, (std::vector<Trade>{{2, 1, 100, 2}}));
    EXPECT_FALSE(b.best_bid());                           // the remaining 3 were cancelled
    EXPECT_EQ(b.order_count(), 0u);
}

// ---- differential test against a reference model ----
namespace {
class ReferenceBook {                                     // obviously correct, O(n) everything
public:
    AddResult add(Order o, std::vector<Trade>& trades) {
        if (o.qty <= 0) return AddResult::InvalidQty;
        for (const auto& r : rest_) if (r.o.id == o.id) return AddResult::DuplicateId;
        while (o.qty > 0) {
            Entry* best = nullptr;
            for (auto& r : rest_) {
                if (r.o.side == o.side) continue;
                bool crosses = o.side == Side::Buy ? r.o.price <= o.price : r.o.price >= o.price;
                bool better = !best || (o.side == Side::Buy ? r.o.price < best->o.price : r.o.price > best->o.price) ||
                              (r.o.price == best->o.price && r.seq < best->seq);
                if (crosses && better) best = &r;
            }
            if (!best) break;
            Qty q = std::min(o.qty, best->o.qty);
            trades.push_back({o.id, best->o.id, best->o.price, q});
            o.qty -= q;
            best->o.qty -= q;
            std::erase_if(rest_, [](const Entry& e) { return e.o.qty == 0; });
        }
        if (o.qty > 0 && o.kind == Kind::Limit) rest_.push_back({o, seq_++});
        return AddResult::Ok;
    }
    bool cancel(OrderId id) { return std::erase_if(rest_, [id](const Entry& e) { return e.o.id == id; }) > 0; }
    std::optional<Price> best(Side s) const {
        std::optional<Price> p;
        for (const auto& r : rest_)
            if (r.o.side == s && (!p || (s == Side::Buy ? r.o.price > *p : r.o.price < *p))) p = r.o.price;
        return p;
    }
    std::size_t size() const { return rest_.size(); }

private:
    struct Entry { Order o; std::uint64_t seq; };
    std::vector<Entry> rest_;
    std::uint64_t seq_ = 0;
};
}  // namespace

TEST(OrderBook, MatchesReferenceModelOnRandomOperations) {
    std::mt19937_64 rng{12345};
    for (int round = 0; round < 20; ++round) {
        OrderBook real;
        ReferenceBook ref;
        std::vector<OrderId> ids;
        OrderId next = 1;
        for (int op = 0; op < 2000; ++op) {
            std::vector<Trade> t1, t2;
            unsigned r = rng() % 100;
            if (r < 25 && !ids.empty()) {                           // cancel (possibly already filled)
                OrderId id = ids[rng() % ids.size()];
                ASSERT_EQ(real.cancel(id), ref.cancel(id)) << "op " << op;
            } else {
                OrderId id = r < 28 && !ids.empty() ? ids[rng() % ids.size()] : next++;   // some duplicate ids
                Order o{id, rng() % 2 ? Side::Buy : Side::Sell, 95 + static_cast<Price>(rng() % 11),
                        static_cast<Qty>(rng() % 6), rng() % 10 == 0 ? Kind::IOC : Kind::Limit};  // qty 0 sometimes
                ASSERT_EQ(real.add(o, t1), ref.add(o, t2)) << "op " << op;
                ASSERT_EQ(t1, t2) << "op " << op;
                ids.push_back(id);
            }
            ASSERT_EQ(real.best_bid(), ref.best(Side::Buy)) << "op " << op;
            ASSERT_EQ(real.best_ask(), ref.best(Side::Sell)) << "op " << op;
            ASSERT_EQ(real.order_count(), ref.size()) << "op " << op;
            if (real.best_bid() && real.best_ask()) ASSERT_LT(*real.best_bid(), *real.best_ask());   // never crossed
        }
    }
}
