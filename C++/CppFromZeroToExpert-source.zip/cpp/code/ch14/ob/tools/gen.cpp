// file: ob/tools/gen.cpp
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>

int main(int argc, char* argv[]) {
    long n = argc > 1 ? std::atol(argv[1]) : 1'000'000;
    std::mt19937_64 rng{42};
    std::normal_distribution<double> offset{0.0, 6.0};
    std::uniform_int_distribution<int> qty{1, 100}, pct{0, 99};
    std::vector<unsigned long> live;                     // ids that may still be resting
    double mid = 10'000;
    unsigned long next = 1;
    for (long i = 0; i < n; ++i) {
        mid += (pct(rng) - 49.5) * 0.002;                // slow random walk
        int r = pct(rng);
        if (r < 40 && !live.empty()) {                   // 40%: cancel a random earlier order
            std::size_t k = rng() % live.size();
            std::printf("X %lu\n", live[k]);
            live[k] = live.back();
            live.pop_back();
            continue;
        }
        bool buy = rng() % 2;
        long away = std::lround(std::abs(offset(rng)));
        bool aggressive = r >= 92;                       // 8%: crosses the spread
        long price = std::lround(mid) + (buy == aggressive ? away : -away) + (buy ? -1 : 1);
        std::printf("A %lu %c %ld %d%s\n", next, buy ? 'B' : 'S', price, qty(rng), r >= 97 ? " I" : "");
        live.push_back(next++);
    }
}
