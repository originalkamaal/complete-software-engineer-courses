// file: ob/tools/replay.cpp
#include <algorithm>
#include <charconv>
#include <chrono>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <memory_resource>
#include <string>
#include <string_view>
#include <vector>
#include "ob/order_book.hpp"

namespace {
struct Op { bool cancel; ob::Order order; };

template <typename T>
bool number(std::string_view& s, T& out) {                       // parse one field, advance past it
    while (!s.empty() && s.front() == ' ') s.remove_prefix(1);
    auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), out);
    if (ec != std::errc{}) return false;
    s.remove_prefix(static_cast<std::size_t>(p - s.data()));
    return true;
}

std::vector<Op> load(const char* path) {
    std::ifstream in{path};
    std::string text{std::istreambuf_iterator<char>{in}, {}};
    std::vector<Op> ops;
    std::string_view rest{text};
    while (!rest.empty()) {
        auto nl = rest.find('\n');
        std::string_view line = rest.substr(0, nl);
        rest = nl == std::string_view::npos ? std::string_view{} : rest.substr(nl + 1);
        if (line.size() < 3) continue;
        Op op{line[0] == 'X', {}};
        std::string_view f = line.substr(1);
        if (!number(f, op.order.id)) continue;
        if (!op.cancel) {
            while (!f.empty() && f.front() == ' ') f.remove_prefix(1);
            if (f.empty()) continue;
            op.order.side = f.front() == 'B' ? ob::Side::Buy : ob::Side::Sell;
            f.remove_prefix(1);
            if (!number(f, op.order.price) || !number(f, op.order.qty)) continue;
            op.order.kind = f.find('I') != std::string_view::npos ? ob::Kind::IOC : ob::Kind::Limit;
        }
        ops.push_back(op);
    }
    return ops;
}

void run(const std::vector<Op>& ops, std::pmr::memory_resource* mr, const char* label) {
    ob::OrderBook book{mr};
    std::vector<ob::Trade> trades;
    trades.reserve(64);
    std::vector<std::uint32_t> ns(ops.size());
    std::uint64_t checksum = 1469598103934665603ull, ntrades = 0, volume = 0, rejected = 0;
    auto start = std::chrono::steady_clock::now();
    for (std::size_t i = 0; i < ops.size(); ++i) {
        auto t0 = std::chrono::steady_clock::now();
        if (ops[i].cancel) book.cancel(ops[i].order.id);
        else if (book.add(ops[i].order, trades) != ob::AddResult::Ok) ++rejected;
        auto t1 = std::chrono::steady_clock::now();
        ns[i] = static_cast<std::uint32_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count());
        for (const auto& t : trades) {                                 // FNV-1a over every trade
            for (std::uint64_t v : {t.taker, t.maker, static_cast<std::uint64_t>(t.price), static_cast<std::uint64_t>(t.qty)})
                checksum = (checksum ^ v) * 1099511628211ull;
            ++ntrades;
            volume += static_cast<std::uint64_t>(t.qty);
        }
        trades.clear();
    }
    double total_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    std::sort(ns.begin(), ns.end());
    auto pct = [&](double p) { return ns[static_cast<std::size_t>(p * static_cast<double>(ns.size() - 1))]; };
    std::printf("%-8s %zu ops in %.0f ms (%.2f M ops/s), %llu trades, volume %llu, rejected %llu\n", label, ops.size(),
                total_ms, static_cast<double>(ops.size()) / total_ms / 1000.0, static_cast<unsigned long long>(ntrades),
                static_cast<unsigned long long>(volume), static_cast<unsigned long long>(rejected));
    std::printf("         latency ns: p50 %u  p90 %u  p99 %u  p99.9 %u  max %u\n", pct(0.5), pct(0.9), pct(0.99),
                pct(0.999), ns.back());
    std::printf("         resting orders %zu, best bid %lld, best ask %lld, trade checksum %016llx\n",
                book.order_count(), static_cast<long long>(book.best_bid().value_or(-1)),
                static_cast<long long>(book.best_ask().value_or(-1)), static_cast<unsigned long long>(checksum));
}
}  // namespace

int main(int argc, char* argv[]) {
    if (argc < 2) { std::fprintf(stderr, "usage: replay FILE [default|pool|both]\n"); return 2; }
    std::vector<Op> ops = load(argv[1]);
    std::string_view mode = argc > 2 ? argv[2] : "default";
    if (mode == "default" || mode == "both") run(ops, std::pmr::new_delete_resource(), "default");
    if (mode == "pool" || mode == "both") {
        std::pmr::unsynchronized_pool_resource pool;                   // recycles list/map/hash nodes
        run(ops, &pool, "pool");
    }
}
