# file: ob/CMakeLists.txt
cmake_minimum_required(VERSION 3.24)
project(ob VERSION 1.0 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

option(OB_SANITIZE "Build everything with ASan, UBSan and libstdc++ assertions" OFF)
if(OB_SANITIZE)
  add_compile_options(-fsanitize=address,undefined -fno-omit-frame-pointer -fno-sanitize-recover=all -D_GLIBCXX_ASSERTIONS)
  add_link_options(-fsanitize=address,undefined)
endif()

add_library(ob src/order_book.cpp)
target_include_directories(ob PUBLIC include)
target_compile_options(ob PRIVATE -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Werror)

add_executable(replay tools/replay.cpp)
target_link_libraries(replay PRIVATE ob)
add_executable(gen tools/gen.cpp)

include(FetchContent)
FetchContent_Declare(googletest
  GIT_REPOSITORY https://github.com/google/googletest.git GIT_TAG v1.15.2
  FIND_PACKAGE_ARGS NAMES GTest)
FetchContent_MakeAvailable(googletest)
enable_testing()
add_executable(ob_test tests/order_book_test.cpp)
target_link_libraries(ob_test PRIVATE ob GTest::gtest_main)
include(GoogleTest)
gtest_discover_tests(ob_test)
