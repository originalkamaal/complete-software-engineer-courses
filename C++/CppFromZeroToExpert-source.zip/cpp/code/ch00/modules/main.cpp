// file: modules/main.cpp
import math;
#include <cstdio>

int main() {
    std::printf("gcd(84, 36) = %d\n", gcd(84, 36));
    // helper();  error: not visible
}
