#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <ranges>
#include <format>
