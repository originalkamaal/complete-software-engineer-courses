// file: which_driver.cpp
#include <iostream>
#include <string>

int main() {
    std::string s = "linked by the right driver";
    std::cout << s << '\n';
}
