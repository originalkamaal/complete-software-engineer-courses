// file: odr/main.cpp
#include <iostream>
#include "shape.h"

int main() {
    Shape s{"square"};
    std::cout << s.name << " area " << s.area() << ", scaled " << s.scaled(2)
              << ", api v" << shape_api_version() << ", twice(21) = " << twice(21) << '\n';
}
