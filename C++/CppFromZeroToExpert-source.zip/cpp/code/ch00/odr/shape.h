// file: odr/shape.h
#pragma once
#include <string>

struct Shape {                       // a class definition may appear in many TUs
    std::string name;
    double area() const;             // declared here, defined once in shape.cpp
    double scaled(double k) const {  // defined in the class: implicitly inline
        return area() * k * k;
    }
};

inline int shape_api_version() { return 2; }   // inline: may be defined in every TU

template <typename T>
T twice(T x) { return x + x; }       // templates: the definition must be visible to every user
