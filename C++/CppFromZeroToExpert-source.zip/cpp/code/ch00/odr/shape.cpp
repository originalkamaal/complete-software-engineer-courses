// file: odr/shape.cpp
#include "shape.h"

double Shape::area() const { return 42.0; }
