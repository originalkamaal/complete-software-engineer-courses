// file: mangle/overloads.cpp
#include <cstdio>

namespace geo {
int area(int side) { return side * side; }
double area(double w, double h) { return w * h; }
}

extern "C" int c_compatible(int x) { return x + 1; }    // plain C symbol name

int main() {
    std::printf("%d %.1f %d\n", geo::area(3), geo::area(2.0, 1.5), c_compatible(41));
}
