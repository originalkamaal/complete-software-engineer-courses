// file: twolang/wrap.hpp
#pragma once
#include <cstdint>
#include <string_view>

std::uint32_t crc32(std::string_view s);

extern "C" int cpp_word_count(const char *text);   // usable from C
