// file: twolang/crc.h
#ifndef CRC_H
#define CRC_H
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* crc32_compute returns the IEEE CRC-32 of n bytes. */
uint32_t crc32_compute(const void *data, size_t n);

#ifdef __cplusplus
}
#endif
#endif
