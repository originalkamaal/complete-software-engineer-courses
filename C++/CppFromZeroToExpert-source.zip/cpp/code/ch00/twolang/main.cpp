// file: twolang/main.cpp
#include <cstdio>
#include "wrap.hpp"

int main() {
    std::printf("crc32(\"123456789\") = %08X (expected CBF43926)\n", crc32("123456789"));
    std::printf("words: %d\n", cpp_word_count("the quick  brown\tfox"));
}
