// file: twolang/cmain.c
#include <stdio.h>

int cpp_word_count(const char *text);   /* implemented in C++, exported with extern "C" */

int main(void) {
    printf("C calling C++: %d words\n", cpp_word_count("one two three"));
    return 0;
}
