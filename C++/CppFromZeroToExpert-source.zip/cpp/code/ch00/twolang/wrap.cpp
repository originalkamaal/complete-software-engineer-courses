// file: twolang/wrap.cpp
#include "wrap.hpp"

#include <sstream>
#include <string>
#include "crc.h"

std::uint32_t crc32(std::string_view s) { return crc32_compute(s.data(), s.size()); }

extern "C" int cpp_word_count(const char *text) {
    std::istringstream in{text};
    std::string word;
    int n = 0;
    while (in >> word)
        ++n;
    return n;
}
