// file: bounds.cpp
#include <iostream>
#include <vector>

int main() {
    std::vector<int> v{1, 2, 3};
    std::cout << v[3] << '\n';     // out of bounds: undefined behaviour
}
