// file: mangle2.cpp
#include <string>
#include <vector>

namespace geo {
struct Point { double x, y; };
double dist(const Point& a, const Point& b) { return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y); }
}
int count(const std::vector<std::string>& v) { return static_cast<int>(v.size()); }
extern "C" int plain_c_name(int x) { return x + 1; }
