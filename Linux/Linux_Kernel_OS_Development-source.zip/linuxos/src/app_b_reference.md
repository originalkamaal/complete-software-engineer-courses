# Appendix B — Reference Tables

The numbers and encodings used throughout the book, in one place. Each table names the unit where the topic is taught.

## x86-64 exceptions (Unit 3.1)

| Vector | Name | Error code | Kind | Typical cause |
| --- | --- | --- | --- | --- |
| 0 | Divide error (#DE) | no | fault | `div` by zero, quotient overflow |
| 3 | Breakpoint (#BP) | no | trap | `int3` |
| 6 | Invalid opcode (#UD) | no | fault | `ud2`, unsupported instruction |
| 8 | Double fault (#DF) | yes (0) | abort | exception while delivering an exception |
| 13 | General protection (#GP) | yes | fault | privileged instruction in ring 3, non-canonical address, bad segment |
| 14 | Page fault (#PF) | yes | fault | not-present page or access-rights violation; address in CR2 |

Page-fault error code bits: 0 P (page was present: protection violation), 1 W/R (write), 2 U/S (user mode), 3 RSVD (reserved bit set), 4 I/D (instruction fetch, with NX or SMEP enabled).

## Page-table entry bits (Units 4.2, 5.3)

| Bit | Name | Meaning |
| --- | --- | --- |
| 0 | P | present |
| 1 | R/W | writable (AND across all levels) |
| 2 | U/S | user-accessible (AND across all levels — DT-11) |
| 3 | PWT | write-through |
| 4 | PCD | cache disable (device memory — Unit 7.4) |
| 5 | A | accessed (set by the CPU) |
| 6 | D | dirty (set by the CPU, last level only) |
| 7 | PS | page size: 2 MiB in a PD entry, 1 GiB in a PDPT entry |
| 12–51 | address | physical address of the next table or page |
| 63 | XD/NX | no-execute (when EFER.NXE = 1) |

Virtual address split (4-level paging): bits 47–39 PML4 index, 38–30 PDPT, 29–21 PD, 20–12 PT, 11–0 offset; bits 63–48 copy bit 47 (canonical form).

## The hobby kernel's GDT and system calls (Units 5.3, 5.4, 6.4)

| Selector | Descriptor | | Number | System call | Arguments → result |
| --- | --- | --- | --- | --- | --- |
| 0x08 | kernel code (64-bit) | | 0 | write | buf, len → len or -errno |
| 0x10 | kernel data | | 1 | exit | code → does not return |
| 0x18 (0x1B) | user data, RPL 3 | | 2 | getpid | → pid |
| 0x20 (0x23) | user code, RPL 3 | | 3 | sleep | ms → 0 |
| 0x28 | TSS (two slots) | | 4–5 | yield, ticks | → 0, ticks |
| | | | 6–9 | open, read, close, readdir | Unit 6.4 |
| | | | 10–11 | spawn, wait | path, args → pid; pid → status |

System calls enter through `int 0x80` (gate DPL 3); number in RAX, arguments in RDI, RSI, RDX, result in RAX.

## Legacy PC I/O ports used (Chapters 2–7)

| Port(s) | Device | Used for |
| --- | --- | --- |
| 0x20–0x21, 0xA0–0xA1 | 8259 PICs | remap, mask, EOI (Unit 3.2) |
| 0x40–0x43 | 8254 PIT | 100 Hz timer (Unit 3.2) |
| 0x70–0x71 | CMOS RTC | clock check, periodic IRQ 8 (Units 3.2, 7.3) |
| 0x80 | POST port | I/O delay |
| 0x1F0–0x1F7, 0x3F6 | primary ATA channel | PIO disk access (Unit 6.1) |
| 0x3F8–0x3FF | COM1 (16550 UART) | console output and input (Units 2.3, 3.3) |
| 0xF4 | QEMU `isa-debug-exit` | end the run with status (v << 1) \| 1 |

## Linux kernel taint flags (Units 9.4, 9.5)

| Bit | Value | Letter | Meaning |
| --- | --- | --- | --- |
| 0 | 1 | P | proprietary (non-GPL) module loaded |
| 7 | 128 | D | kernel died recently (oops or BUG) |
| 9 | 512 | W | a warning was issued |
| 12 | 4096 | O | out-of-tree module loaded |
| 13 | 8192 | E | unsigned module loaded (with module signing) |

`/proc/sys/kernel/tainted` holds the sum; `Documentation/admin-guide/tainted-kernels.rst` lists all flags.

## ioctl number encoding (Unit 10.2)

| Bits | Field | Example: `_IOR('r', 1, struct ring_stats)` = 0x80287201 |
| --- | --- | --- |
| 0–7 | command number | 0x01 |
| 8–15 | type ("magic") | 0x72 = `'r'` |
| 16–29 | argument size | 0x028 = 40 bytes |
| 30–31 | direction: 0 none, 1 write (user → kernel), 2 read (kernel → user) | 2 |

## Choosing a lock in Linux (Unit 12.1)

| Situation | Use |
| --- | --- |
| a single counter or flag | `atomic_t`, `refcount_t` (for object lifetimes) |
| short section, no sleeping, not used from IRQ | `spin_lock` |
| shared with an interrupt handler | `spin_lock_irqsave` outside the handler (DT-17) |
| section may sleep (allocation, user copies, I/O) | `struct mutex` |
| many readers, few writers, readers may sleep | `struct rw_semaphore` |
| very many readers, rare updates, readers must be fast | RCU (`rcu_read_lock`, `rcu_assign_pointer`, `kfree_rcu`) |
| per-CPU statistics | per-CPU variables (`this_cpu_inc`) |

## Debug options used by this book's kernel (Chapters 8, 9, 12)

| Option | Finds | Report starts with |
| --- | --- | --- |
| `CONFIG_KASAN` | out-of-bounds and use-after-free accesses | `BUG: KASAN: slab-use-after-free in …` |
| `CONFIG_PROVE_LOCKING` (lockdep) | lock-order inversions, irq-safety violations | `WARNING: possible circular locking dependency detected` |
| `CONFIG_PROVE_RCU` (with lockdep) | RCU dereferences outside read-side sections | `WARNING: suspicious RCU usage` |
| `CONFIG_DEBUG_ATOMIC_SLEEP` | sleeping (or possibly sleeping) in atomic context | `BUG: sleeping function called from invalid context` |
| `CONFIG_FTRACE`, `CONFIG_KPROBES` | (tracing, not checking) | tracefs: `/sys/kernel/tracing` |

## Further reading

- Intel® 64 and IA-32 Architectures Software Developer's Manual, Volume 3 (System Programming Guide) — the reference for Part I.
- The Multiboot2 Specification; the UEFI Specification; System V AMD64 ABI; ELF-64 Object File Format.
- Linux `Documentation/`: `process/` (submitting patches, coding style), `core-api/`, `locking/`, `RCU/`, `dev-tools/` (KASAN, KUnit, kselftest), `trace/`, `bpf/`, `driver-api/`.
- *Linux Device Drivers* (3rd ed.) for driver concepts — read with the current kernel source at hand, as its APIs are from 2.6.10.
- *Is Parallel Programming Hard, And, If So, What Can You Do About It?* (Paul E. McKenney) — memory ordering and RCU in depth.
- *Operating Systems: Three Easy Pieces* (Arpaci-Dusseau) — the theory behind Part I, free online.
