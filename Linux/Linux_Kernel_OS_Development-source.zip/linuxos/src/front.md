---
title: "Linux Kernel & OS Development from Zero to Advanced"
subtitle: "Build an operating system kernel from the first boot sector to processes, files, and multiple CPUs — then work inside Linux 6.12: modules, drivers, memory, scheduling, locking, RCU, tracing, networking, BPF, and upstream patches"
lang: en
---

# Preface

An operating system kernel is the program that every other program trusts. It decides which code runs, which memory it may touch, and what happens when something goes wrong. Learning it from documentation alone is hard, because the interesting parts happen where nobody is watching: during boot, inside an interrupt, between two CPUs.

This book teaches the kernel by building and running one. **Part I (Chapters 0–7)** builds a small 64-bit kernel from nothing: a boot sector and a UEFI application, the switch to long mode, C without a library, interrupts and the timer, physical and virtual memory with demand paging, a kernel heap, threads and preemption, user mode and system calls, a disk driver and a file system with its own `mkfs` tool, an ELF loader and a shell in user space, and finally the other CPUs, atomics, and locks. **Part II (Chapters 8–14)** moves to Linux 6.12: building and booting it under QEMU, writing modules and a character device driver, measuring processes, memory, and scheduling through `/proc`, using lockdep, KASAN, RCU, ftrace, and kprobes, following packets through the network stack, loading eBPF programs with the raw system call, and preparing an upstream-style patch series.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth — the Intel Software Developer's Manual, the Multiboot2 or ELF specification, the C standard, a datasheet, an RFC, or a named file in the Linux source or its `Documentation/` tree.
2. **Evidence.** Every program shown with output was run, and the output is real: QEMU exit statuses, kernel panics, lockdep and KASAN reports, page-fault counts, verifier logs, packet captures. Most *Deep & Tricky* entries come with an experiment switch that builds the wrong version so you can watch it fail. Several examples were wrong in their first draft, and the book shows what happened when that taught something: a bitmap allocator that destroyed the bootloader's data, a timer that stopped because of a missing EOI, a ticket lock that collapsed under virtualisation, a NULL dereference that KASAN turned into a general protection fault.
3. **Order.** Nothing is used before it is taught; Part II refers back to the hobby kernel wherever Linux solves the same problem.

# How to use this book

## Who it is for

- **C programmers new to systems work:** read in order. Part I gives you a working mental model of the machine before Linux's scale arrives.
- **Linux users and application developers:** Chapters 0–2 can be read quickly; read Chapters 3–7 carefully — interrupts, paging, and concurrency are what Part II assumes.
- **Engineers who want to work on Linux:** you may start Part II at Chapter 8, but read every *Deep & Tricky* entry in Part I first; Chapters 9, 10, 12, and 14 are the core of everyday kernel work.

You should be comfortable with C — pointers, structs, the preprocessor, and building with `gcc` and `make` — and with the command line. The C and DSA books of this series cover what you need.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | Complete code — assembly, C, scripts — and its real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, labelled with their source of truth, usually with an experiment that shows the failure. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a realistic piece of work with complete code, real output, and a review checklist.

## The hobby kernel grows chapter by chapter

From Chapter 2 on, the kernel lives in a directory `os/`. Each chapter starts from the previous chapter's finished kernel, adds or replaces files from its `new/` directory, and its project adds `proj/` to make `final/`. A file listing in the text is always the complete file. The kernel runs headless in QEMU: output goes to the serial port, and the kernel ends a run by writing to QEMU's `isa-debug-exit` device, so every run ends with an exit status — 33 for success, 35 for a kernel panic, 124 when the time limit was hit. Tests are registered with `KTEST(name)` and selected with `make run CMDLINE="test=name"`; Chapter 14 runs all of them.

## Running the code

The source archive has one directory per chapter, with the files exactly as listed (each starts with a one-line `// file:` or `# file:` comment that names it). The console blocks show the exact commands, run from the chapter's directory.

**Part I** needs a Linux x86-64 machine (or VM) with `gcc`, `nasm`, `qemu-system-x86_64`, GRUB's `grub-mkrescue` with `xorriso` and the PC (`grub-pc-bin`) modules, OVMF (UEFI firmware for QEMU, Chapter 0), `clang` and `lld` (Chapter 0's UEFI program), and Python 3. On Debian or Ubuntu: `apt install build-essential nasm qemu-system-x86 grub-pc-bin grub-common xorriso mtools ovmf clang lld python3`.

**Part II** needs, in addition, the kernel build dependencies (`flex bison bc libelf-dev libssl-dev dwarves`), `busybox-static`, `cpio`, `kmod`, `curl`, `python3-ply` and `python3-git` (for `checkpatch.pl`'s SPDX check), and the Linux 6.12 source: `git clone --depth 1 --branch v6.12 https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git`. Chapter 8 builds it out of tree with this book's configuration (`book_defconfig`, listed in Unit 8.2). In the code directories, `linux` and `build` are symbolic links to the source and build directories; adjust them to your paths.

Everything was run on Ubuntu 24.04 with GCC 13.3, NASM 2.16, QEMU 8.2, GRUB 2.12, and Linux 6.12, on a two-core x86-64 host without hardware virtualisation. Timings — boot times, lock throughput, the cost of `synchronize_rcu` — are from that machine under emulation and with a debug kernel; expect different numbers on yours, and the same shape.

## Reading order

| Part | Chapters | Builds on |
| --- | --- | --- |
| I — Building a kernel | 0 Boot · 1 x86-64 · 2 Freestanding C · 3 Interrupts · 4 Memory · 5 Processes · 6 Disks and files · 7 SMP and locks | C, DSA |
| II — Working in Linux | 8 Build and boot · 9 Modules · 10 Char devices · 11 Processes, memory, scheduling · 12 Locking, RCU, debugging, tracing · 13 Networking and BPF · 14 Testing and patches | Part I |
