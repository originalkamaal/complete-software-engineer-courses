# file: inspect_boot.py
import struct
import sys

def bios_image(path):
    data = open(path, "rb").read(512)
    sig = data[510:512]
    print(f"{path}: BIOS boot sector, signature {sig.hex(' ')} -> {'bootable' if sig == b'\x55\xaa' else 'NOT bootable'}; "
          f"first bytes {data[:5].hex(' ')} (EA = far jump)")

def uefi_app(path):
    data = open(path, "rb").read()
    pe = struct.unpack_from("<I", data, 0x3C)[0]                    # offset of the PE header
    assert data[:2] == b"MZ" and data[pe:pe + 4] == b"PE\0\0"
    machine = struct.unpack_from("<H", data, pe + 4)[0]
    subsystem = struct.unpack_from("<H", data, pe + 24 + 68)[0]    # optional header: Subsystem field
    names = {0x8664: "x86-64", 10: "EFI application"}
    print(f"{path}: PE file, machine {names.get(machine, hex(machine))}, subsystem {names.get(subsystem, subsystem)}")

def multiboot2(path):
    data = open(path, "rb").read(32768)
    for off in range(0, len(data) - 16, 8):                        # header must be 8-byte aligned in the first 32 KiB
        magic, arch, length, checksum = struct.unpack_from("<IIII", data, off)
        if magic == 0xE85250D6:
            ok = (magic + arch + length + checksum) & 0xFFFFFFFF == 0
            print(f"{path}: Multiboot2 header at file offset {off:#x}, architecture {arch}, length {length}, checksum {'valid' if ok else 'INVALID'}")
            return
    print(f"{path}: no Multiboot2 header in the first 32 KiB")

bios_image("boot.img")
uefi_app("BOOTX64.EFI")
multiboot2("mb2/kernel.elf")
