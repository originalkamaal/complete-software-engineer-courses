; file: mb2/header.asm
section .multiboot2
align 8
mb2_start:
    dd 0xE85250D6                                    ; magic
    dd 0                                             ; architecture 0 = i386 protected mode
    dd mb2_end - mb2_start                           ; header length
    dd -(0xE85250D6 + 0 + (mb2_end - mb2_start))     ; checksum: the four fields sum to 0 (mod 2^32)
    dw 0, 0                                          ; end tag: type 0, flags 0
    dd 8                                             ;          size 8
mb2_end:

section .text
bits 32
global _start
_start:
    cmp eax, 0x36D76289         ; did a Multiboot2 loader start us?
    jne .bad
    mov dx, 0x3F8
    mov esi, ok
.loop:
    lodsb
    test al, al
    jz .exit
    out dx, al
    jmp .loop
.bad:
.exit:
    mov al, 0x10
    out 0xF4, al
    hlt
section .rodata
ok: db "GRUB started us in 32-bit protected mode with the Multiboot2 magic in EAX", 13, 10, 0
