# file: mb2/linker.ld
ENTRY(_start)
SECTIONS {
    . = 1M;                          /* load the kernel at 1 MiB, above the legacy BIOS area */
    .boot : { KEEP(*(.multiboot2)) } /* the header must be within the first 32 KiB of the file */
    .text : { *(.text*) }
    .rodata : { *(.rodata*) }
}
