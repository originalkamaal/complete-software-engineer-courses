; file: boot.asm
bits 16
org 0x7C00
start:
    jmp 0:.norm                ; normalise CS:IP to 0000:7C00 (some BIOSes use 07C0:0000)
.norm:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00             ; stack grows down, below the boot sector
    mov [boot_drive], dl       ; the BIOS passes the boot drive number in DL
    mov si, msg1
    call print
    ; load sector 2 to 0x7E00 with BIOS int 13h, function 02h (cylinder/head/sector addressing)
    mov ah, 0x02
    mov al, 1                  ; number of sectors
    mov ch, 0                  ; cylinder
    mov cl, 2                  ; sector (numbered from 1)
    mov dh, 0                  ; head
    mov dl, [boot_drive]
    mov bx, 0x7E00             ; ES:BX = destination
    int 0x13
    jc disk_error              ; carry flag set on failure
    jmp 0x7E00                 ; run stage 2
disk_error:
    mov si, err
    call print
    hlt

print:                         ; SI -> zero-terminated string, written to COM1 (port 0x3F8)
    lodsb
    test al, al
    jz .done
    mov dx, 0x3F8 + 5          ; line status register
.wait:
    mov ah, al
    in al, dx
    test al, 0x20              ; transmitter ready?
    mov al, ah
    jz .wait
    mov dx, 0x3F8
    out dx, al
    jmp print
.done:
    ret

boot_drive: db 0
msg1: db "Stage 1: BIOS loaded 512 bytes at 0x7C00", 13, 10, 0
err:  db "disk error", 13, 10, 0
times 510 - ($ - $$) db 0      ; pad to 510 bytes
dw 0xAA55                      ; boot signature (stored little-endian: 55 AA)

; ---- stage 2: the second sector, loaded at 0x7E00 by stage 1 ----
stage2:
    mov si, msg2
    call print
    mov al, 0x10
    out 0xF4, al               ; QEMU isa-debug-exit: end the run
    hlt
msg2: db "Stage 2: loaded from disk by stage 1 via int 13h", 13, 10, 0
times 1024 - ($ - $$) db 0
