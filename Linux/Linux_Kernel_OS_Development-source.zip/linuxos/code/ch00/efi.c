// file: efi.c
/* A minimal UEFI application, with just enough of the UEFI type definitions written out by hand. */
typedef unsigned long long UINT64;
typedef unsigned short CHAR16;
typedef UINT64 EFI_STATUS;
typedef void *EFI_HANDLE;
typedef struct { UINT64 Signature; unsigned Revision, HeaderSize, CRC32, Reserved; } EFI_TABLE_HEADER;
struct SIMPLE_TEXT_OUTPUT;
typedef EFI_STATUS (*TEXT_STRING)(struct SIMPLE_TEXT_OUTPUT *self, CHAR16 *text);
typedef struct SIMPLE_TEXT_OUTPUT { void *Reset; TEXT_STRING OutputString; } SIMPLE_TEXT_OUTPUT;
typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16 *FirmwareVendor;
    unsigned FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    void *ConIn;
    EFI_HANDLE ConsoleOutHandle;
    SIMPLE_TEXT_OUTPUT *ConOut;
} EFI_SYSTEM_TABLE;

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st) {
    (void)image;
    st->ConOut->OutputString(st->ConOut, (CHAR16 *)L"Hello from a UEFI application!\r\nFirmware vendor: ");
    st->ConOut->OutputString(st->ConOut, st->FirmwareVendor);
    st->ConOut->OutputString(st->ConOut, (CHAR16 *)L"\r\n");
    __asm__ volatile("outb %0, %1" : : "a"((unsigned char)0x10), "Nd"((unsigned short)0xf4));   /* exit QEMU */
    return 0;
}
