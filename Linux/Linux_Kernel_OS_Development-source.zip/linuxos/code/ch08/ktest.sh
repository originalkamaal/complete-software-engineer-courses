# file: ktest.sh
#!/bin/sh
# ktest.sh [TESTDIR]: rebuild the kernel if needed, build the guest, boot, run the tests, report.
set -e
tests=${1:-tests}
here=$(pwd)
(cd linux && make -s O=../build ARCH=x86_64 -j"$(nproc)" bzImage)
work=$(mktemp -d)
mkdir -p "$work/bin" "$work/tests"
gcc -static -O2 -Wall -Wextra -Werror -o "$work/bin/syscalls" guest/syscalls.c
cp "$tests"/* "$work/tests/" && chmod +x "$work/tests/"*
sh mkinitramfs.sh "$here/ktest.cpio" init-ktest.sh "$work" > /dev/null
rm -rf "$work"
bash boot.sh ktest.cpio quiet > ktest.log 2>&1 || true
grep -E "^(TEST|KTEST|  )" ktest.log | tr -d '\r'
summary=$(grep -a "KTEST SUMMARY" ktest.log | tr -d '\r') || { echo "ktest: no summary - the guest did not finish"; exit 2; }
case "$summary" in *"failed=0"*) exit 0 ;; *) exit 1 ;; esac
