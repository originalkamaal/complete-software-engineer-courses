// file: guest/syscalls.c
/* Runs inside the guest: a few system calls and their observable results. */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static int failures;
#define CHECK(cond) do { if (!(cond)) { printf("  check failed: %s (errno %d)\n", #cond, errno); failures++; } } while (0)

int main(void) {
    struct utsname u;
    CHECK(uname(&u) == 0 && strstr(u.release, "-book") != NULL);
    printf("  uname: %s %s\n", u.sysname, u.release);

    pid_t child = fork();
    if (child == 0) _exit(42);
    int status;
    CHECK(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 42);

    char *p = mmap(NULL, 1 << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    CHECK(p != MAP_FAILED);
    for (int i = 0; i < (1 << 20); i += 4096) p[i] = 1;          /* demand paging: 256 page faults */
    CHECK(munmap(p, 1 << 20) == 0);

    CHECK(open("/no/such/file", O_RDONLY) == -1 && errno == ENOENT);
    errno = 0;
    const char *volatile bad = NULL;                              /* volatile: hide the NULL from the compiler */
    CHECK(write(1, bad, 1) == -1 && errno == EFAULT);             /* the kernel validates user pointers */

    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    usleep(20000);
    clock_gettime(CLOCK_MONOTONIC, &b);
    long ms = (b.tv_sec - a.tv_sec) * 1000 + (b.tv_nsec - a.tv_nsec) / 1000000;
    CHECK(ms >= 20 && ms < 1000);
    printf("  usleep(20 ms) took %ld ms\n", ms);
    return failures ? 1 : 0;
}
