# file: tests/30-syscalls.sh
exec /bin/syscalls
