# file: tests/10-proc.sh
# /proc reflects the running kernel
[ "$(cat /proc/sys/kernel/osrelease)" = "$(uname -r)" ] || exit 1
grep -q "^processor" /proc/cpuinfo || exit 1
[ "$(grep -c ^processor /proc/cpuinfo)" -eq 2 ] || exit 1
[ -r /proc/self/maps ] && grep -q "\[stack\]" /proc/self/maps
