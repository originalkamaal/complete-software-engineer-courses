# file: tests/20-sysfs.sh
# the e1000 card is visible as a PCI device and a network interface
ls /sys/bus/pci/drivers/e1000/ | grep -q "0000:" || exit 1
[ -d /sys/class/net/eth0 ] || exit 1
echo "  eth0 MAC: $(cat /sys/class/net/eth0/address)"
