# file: init-ktest.sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
passed=0; failed=0
for t in /tests/*; do
    name=$(basename "$t")
    if timeout 60 sh "$t"; then echo "TEST $name: PASS"; passed=$((passed + 1))
    else echo "TEST $name: FAIL"; failed=$((failed + 1)); fi
done
echo "KTEST SUMMARY passed=$passed failed=$failed"
reboot -f
