# file: init-hello.sh
# The first user-space program: PID 1.
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
echo "init: hello from PID $$, running $(uname -sr) on $(nproc) CPUs"
echo "init: command line: $(cat /proc/cmdline)"
echo "init: memory: $(grep MemTotal /proc/meminfo)"
echo "init: kernel config has $(zcat /proc/config.gz | grep -c '=y') options set to y"
echo "init: debugging features:" $(zcat /proc/config.gz | grep -oE '^CONFIG_(KASAN|PROVE_LOCKING|DEBUG_ATOMIC_SLEEP)=y' | cut -c8-)
echo "init: uptime at this point: $(cut -d' ' -f1 /proc/uptime) s"
reboot -f                                   # with -no-reboot, the reboot makes QEMU exit
