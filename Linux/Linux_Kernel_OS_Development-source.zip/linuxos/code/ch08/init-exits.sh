# file: init-exits.sh
echo "init: I am PID $$ and I am about to return"
exit 0
