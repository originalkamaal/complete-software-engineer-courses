# file: mkinitramfs.sh
#!/bin/sh
# mkinitramfs.sh OUT.cpio INIT [EXTRA_DIR]: BusyBox + an init script (+ optional extra files) -> newc cpio archive
set -e
out=$(realpath -m "$1"); init=$2; extra=$3
root=$(mktemp -d)
mkdir -p "$root/bin" "$root/sbin" "$root/proc" "$root/sys" "$root/dev" "$root/tmp" "$root/etc" "$root/root"
cp /usr/bin/busybox "$root/bin/busybox"
for applet in $(/usr/bin/busybox --list); do
    [ -e "$root/bin/$applet" ] || ln -s busybox "$root/bin/$applet"
done
{ echo '#!/bin/sh'; cat "$init"; } > "$root/init"      # the kernel executes /init directly
chmod +x "$root/init"
[ -n "$extra" ] && cp -r "$extra"/. "$root/"
(cd "$root" && find . | sort | cpio --quiet -o -H newc) > "$out"
rm -rf "$root"
echo "$out: $(wc -c < "$out") bytes"
