# file: tests/40-expected-failure.sh
# Shows that failures are reported. Remove it to get a green run.
[ -e /this/file/does/not/exist ]
