# file: boot.sh
# boot.sh INITRAMFS [EXTRA KERNEL ARGS...]: boot the book's kernel in QEMU on the serial console.
# Run with bash. Firmware chatter (SeaBIOS, the network card's iPXE ROM) and terminal escape codes are filtered out.
set -o pipefail
initrd=$1; shift
timeout 300 qemu-system-x86_64 -kernel build/arch/x86/boot/bzImage -initrd "$initrd" \
    -append "console=ttyS0 panic=-1 $*" -m 512M -smp 2 -nographic -no-reboot $QEMU_EXTRA < /dev/null 2>&1 |
    sed -u -e 's/\x1b\[[0-9;?]*[a-zA-Z]//g' -e 's/\x1bc//g' -e 's/\r$//' -e 's/^Booting from ROM\.*//' |
    grep -av --line-buffered -E '^(SeaBIOS|iPXE|Press Ctrl-B|$)|reboot: Restarting system'
