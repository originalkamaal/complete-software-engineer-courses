// file: new/include/mm.h
#pragma once
#include <kernel.h>

#define PAGE_SIZE 4096UL
#define ALIGN_UP(x, a)   (((x) + (a) - 1) & ~((uint64_t)(a) - 1))
#define ALIGN_DOWN(x, a) ((x) & ~((uint64_t)(a) - 1))

/* boot information (multiboot2.c) */
struct mb2_mmap_entry { uint64_t base, length; uint32_t type, reserved; };
extern struct mb2_mmap_entry usable_regions[16];
extern int usable_region_count;
extern uintptr_t mb_info_start, mb_info_end;

/* physical frames (pmm.c) */
void     pmm_init(void);
uint64_t pmm_alloc(void);                 /* physical address of a free frame, or 0 when out of memory */
void     pmm_free(uint64_t frame);
uint64_t pmm_free_count(void);
uint64_t pmm_total_count(void);

/* page tables (vmm.c) */
#define PTE_PRESENT  (1UL << 0)
#define PTE_WRITABLE (1UL << 1)
#define PTE_USER     (1UL << 2)
#define PTE_HUGE     (1UL << 7)
#define PTE_ADDR     0x000FFFFFFFFFF000UL
#define LAZY_START   0xFFFFC00000000000UL    /* pages here are mapped on first touch */
#define LAZY_END     0xFFFFC00040000000UL
void      vmm_init(void);
bool      vmm_map(uint64_t virt, uint64_t phys, uint64_t flags);
uint64_t  vmm_unmap(uint64_t virt);           /* returns the frame that was mapped, or 0 */
bool      vmm_translate(uint64_t virt, uint64_t *phys);
uint64_t *vmm_pte(uint64_t virt, bool create);
void      vmm_walk(uint64_t virt);           /* print every level of the translation */
bool      vmm_handle_fault(struct trap_frame *f);
extern uint64_t lazy_faults;
static inline void invlpg(uint64_t virt) { __asm__ volatile("invlpg (%0)" : : "r"(virt) : "memory"); }

/* kernel heap (heap.c) */
#define HEAP_START 0xFFFF800000000000UL
void *kmalloc(size_t n);
void  kfree(void *p);
void *morecore(size_t bytes);                 /* extend the heap region by bytes; returns its old end */
struct heap_stats { size_t blocks, free_blocks, used_bytes, free_bytes, largest_free, heap_bytes; };
void  kheap_check(struct heap_stats *s);      /* validates every block; panics on corruption */
