// file: proj/include/shell.h
#pragma once
#include <kernel.h>

struct shell_cmd { const char *name, *help; void (*fn)(const char *arg); } __attribute__((aligned(32)));
#define SHELL_CMD(n, helptext)                                                                    \
    static void cmd_##n(const char *arg);                                                         \
    __attribute__((used, section(".shellcmds"))) static const struct shell_cmd shellcmd_##n = {   \
        #n, helptext, cmd_##n};                                                                   \
    static void cmd_##n(const char *arg)
uint64_t parse_hex(const char *s);
