// file: new/kernel/test_heap.c
#include <mm.h>

static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1103515245 + 12345; return rng >> 8; }

KTEST(heap) {
    struct heap_stats s;
    char *a = kmalloc(100), *b = kmalloc(200), *c = kmalloc(300);
    kprintf("kmalloc(100)=%p kmalloc(200)=%p kmalloc(300)=%p\n", (void *)a, (void *)b, (void *)c);
    kprintf("gaps: %ld and %ld bytes (16-byte rounding + 32-byte header)\n", (long)(b - a), (long)(c - b));
    kfree(b);
    char *d = kmalloc(150);
    kprintf("after kfree(b), kmalloc(150)=%p: %s\n", (void *)d, d == b ? "reuses b's block (first fit)" : "new block");
    kfree(a); kfree(c); kfree(d);
    kheap_check(&s);
    kprintf("all freed: %zu block(s), %zu free bytes in one piece\n", s.blocks, s.largest_free);

    static char *ptr[500];
    static size_t len[500];
    uint64_t frames_before = pmm_free_count();
    for (int op = 0; op < 20000; op++) {
        int i = (int)(rnd() % 500);
        if (ptr[i]) {
            for (size_t k = 0; k < len[i]; k++) KASSERT(ptr[i][k] == (char)i);   /* contents intact? */
            kfree(ptr[i]);
            ptr[i] = NULL;
        } else {
            len[i] = 1 + rnd() % (rnd() % 8 == 0 ? 16384 : 256);
            ptr[i] = kmalloc(len[i]);
            KASSERT(ptr[i] && (uintptr_t)ptr[i] % 16 == 0);
            memset(ptr[i], i, len[i]);
        }
        if (op % 5000 == 0) kheap_check(&s);
    }
    kheap_check(&s);
    kprintf("after 20000 random operations: %zu blocks (%zu free), used %zu, free %zu, largest free %zu, heap %zu KiB\n",
            s.blocks, s.free_blocks, s.used_bytes, s.free_bytes, s.largest_free, s.heap_bytes >> 10);
    for (int i = 0; i < 500; i++) kfree(ptr[i]);
    kheap_check(&s);
    kprintf("all freed again: %zu block(s); heap took %lu frames from the frame allocator\n", s.blocks,
            frames_before - pmm_free_count());
    KASSERT(s.blocks == 1 && s.free_blocks == 1);
}
