// file: new/kernel/test_paging.c
#include <mm.h>

KTEST(paging) {
    vmm_walk((uint64_t)&pmm_alloc);                           /* kernel code: inside the 2 MiB boot pages */

    uint64_t frame = pmm_alloc();
    uint64_t a = 0xFFFF800000003000UL, b = 0xFFFFA00000000000UL;
    KASSERT(vmm_map(a, frame, PTE_WRITABLE) && vmm_map(b, frame, PTE_WRITABLE));
    vmm_walk(a);
    char *pa = (char *)a, *pb = (char *)b;
    memcpy(pa, "written through a", 18);
    kprintf("read through b: \"%s\" (two virtual pages, one frame)\n", pb);
    KASSERT(vmm_unmap(a) == frame && vmm_unmap(b) == frame);
    uint64_t phys;
    kprintf("after unmap: translate(a) %s\n", vmm_translate(a, &phys) ? "succeeds" : "fails");
    pmm_free(frame);
}

KTEST(lazy) {
    uint64_t free_before = pmm_free_count();
    volatile uint64_t *zone = (volatile uint64_t *)LAZY_START;
    kprintf("lazy zone at %p: first read returns %lu\n", (void *)zone, zone[0]);
    zone[1] = 42;                                              /* same page: no new fault */
    zone[512 * 5] = 7;                                         /* 5 pages further: one more fault */
    for (int page = 100; page < 110; page++) zone[512 * page] = (uint64_t)page;
    kprintf("page faults handled: %lu; frames used: %lu (data pages + new page tables)\n", lazy_faults,
            free_before - pmm_free_count());
    KASSERT(lazy_faults == 12 && zone[1] == 42 && zone[512 * 105] == 105);
}
