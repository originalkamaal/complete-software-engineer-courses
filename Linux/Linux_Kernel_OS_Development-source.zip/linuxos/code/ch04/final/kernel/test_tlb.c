// file: new/kernel/test_tlb.c
#include <mm.h>

KTEST(tlb) {
    uint64_t fa = pmm_alloc(), fb = pmm_alloc();
    *(volatile uint64_t *)fa = 0xAAAA;                         /* write the frames through the identity map */
    *(volatile uint64_t *)fb = 0xBBBB;
    uint64_t v = 0xFFFFB00000000000UL;
    vmm_map(v, fa, PTE_WRITABLE);
    kprintf("v -> frame A: reads 0x%lx\n", *(volatile uint64_t *)v);       /* the translation is now cached */
    uint64_t *pte = vmm_pte(v, false);
    *pte = fb | PTE_PRESENT | PTE_WRITABLE;                                /* retarget v to frame B ... */
    kprintf("PTE now says frame B, no flush: reads 0x%lx\n", *(volatile uint64_t *)v);
    invlpg(v);                                                             /* ... but only now does the CPU notice */
    kprintf("after invlpg: reads 0x%lx\n", *(volatile uint64_t *)v);
}
