// file: proj/kernel/shell.c
#include <shell.h>
#include <mm.h>

extern const struct shell_cmd __shellcmds_start[], __shellcmds_end[];

uint64_t parse_hex(const char *s) {
    uint64_t v = 0;
    if (s[0] == '0' && s[1] == 'x') s += 2;
    for (; *s && *s != ' '; s++) {
        int d = *s >= '0' && *s <= '9' ? *s - '0' : *s >= 'a' && *s <= 'f' ? *s - 'a' + 10 : -1;
        if (d < 0) break;
        v = v * 16 + (uint64_t)d;
    }
    return v;
}

static size_t read_line(char *buf, size_t size) {
    size_t n = 0;
    kprintf("kshell> ");
    for (;;) {
        int c = serial_getc();
        if (c == '\r' || c == '\n') { kprintf("\n"); break; }
        if ((c == 0x7F || c == '\b') && n > 0) { n--; kprintf("\b \b"); continue; }
        if (c == 0x15) { while (n) { n--; kprintf("\b \b"); } continue; }
        if (c >= 0x20 && c < 0x7F && n + 1 < size) { buf[n++] = (char)c; kprintf("%c", c); }
    }
    buf[n] = '\0';
    return n;
}

SHELL_CMD(help, "list commands") {
    (void)arg;
    for (const struct shell_cmd *c = __shellcmds_start; c < __shellcmds_end; c++) kprintf("  %-8s %s\n", c->name, c->help);
}
SHELL_CMD(uptime, "time since the timer started") {
    (void)arg;
    uint64_t t = ticks;
    kprintf("up %lu.%02lu s (%lu ticks at %u Hz)\n", t / timer_hz, t % timer_hz * 100 / timer_hz, t, timer_hz);
}
SHELL_CMD(echo, "print the arguments") { kprintf("%s\n", arg); }
SHELL_CMD(crash, "write to an address: crash [hexaddr]") {
    uint64_t addr = parse_hex(arg);
    if (!addr) addr = 0xdead0000;
    kprintf("writing to 0x%lx...\n", addr);
    *(volatile uint64_t *)addr = 1;
}
SHELL_CMD(halt, "power off (exit QEMU)") { (void)arg; kprintf("halting\n"); qemu_exit(0x10); }

void shell_run(void) {
    kprintf("kshell ready; type 'help'\n");
    char line[128];
    for (;;) {
        if (!read_line(line, sizeof line)) continue;
        char *arg = line;
        while (*arg && *arg != ' ') arg++;
        if (*arg) *arg++ = '\0';
        const struct shell_cmd *c;
        for (c = __shellcmds_start; c < __shellcmds_end; c++)
            if (strncmp(line, c->name, 16) == 0) { c->fn(arg); break; }
        if (c == __shellcmds_end) kprintf("unknown command '%s'\n", line);
    }
}
