// file: new/kernel/morecore.c
/* The kernel's heap growth: map fresh frames at the end of the heap region. */
#include <mm.h>

static uint64_t heap_end = HEAP_START;

void *morecore(size_t bytes) {
    uint64_t old = heap_end;
    for (uint64_t v = heap_end; v < heap_end + bytes; v += PAGE_SIZE) {
        uint64_t frame = pmm_alloc();
        if (!frame || !vmm_map(v, frame, PTE_WRITABLE)) return NULL;   /* (a real kernel would roll back) */
    }
    heap_end += bytes;
    return (void *)old;
}
