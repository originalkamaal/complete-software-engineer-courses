// file: new/kernel/idt.c
#include <mm.h>

struct idt_gate {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t reserved;
} __attribute__((packed));
_Static_assert(sizeof(struct idt_gate) == 16, "a long-mode gate is 16 bytes");

static struct idt_gate idt[256];
extern const uint64_t isr_table[48];
static irq_handler_t irq_handlers[16];

static const char *const exception_names[32] = {
    "divide error", "debug", "NMI", "breakpoint", "overflow", "bound range", "invalid opcode", "device not available",
    "double fault", "coprocessor overrun", "invalid TSS", "segment not present", "stack fault", "general protection",
    "page fault", "reserved", "x87 FP error", "alignment check", "machine check", "SIMD FP error", "virtualization",
    "control protection", "reserved", "reserved", "reserved", "reserved", "reserved", "reserved", "hypervisor injection",
    "VMM communication", "security", "reserved"};

void idt_init(void) {
    for (int v = 0; v < 48; v++) {
        uint64_t a = isr_table[v];
        idt[v] = (struct idt_gate){ (uint16_t)a, 0x08, 0, 0x8E, (uint16_t)(a >> 16), (uint32_t)(a >> 32), 0 };
    }
    struct __attribute__((packed)) { uint16_t limit; uint64_t base; } idtr = { sizeof idt - 1, (uint64_t)idt };
    __asm__ volatile("lidt %0" : : "m"(idtr));
}

void irq_register(int irq, irq_handler_t handler) { irq_handlers[irq] = handler; }

static void dump_frame(const struct trap_frame *f) {
    kprintf("  rip=%p  cs=0x%lx  rflags=0x%lx  rsp=%p\n", (void *)f->rip, f->cs, f->rflags, (void *)f->rsp);
    kprintf("  rax=%016lx rbx=%016lx rcx=%016lx rdx=%016lx\n", f->rax, f->rbx, f->rcx, f->rdx);
    kprintf("  rsi=%016lx rdi=%016lx rbp=%016lx\n", f->rsi, f->rdi, f->rbp);
}

static void exception(struct trap_frame *f) {
    if (f->vector == 3) {
        kprintf("breakpoint at rip=%p\n", (void *)f->rip);
        return;
    }
    if (f->vector == 14 && vmm_handle_fault(f)) return;          /* demand paging: retry the instruction */
    kprintf("\nEXCEPTION %lu: %s, error code 0x%lx\n", f->vector, exception_names[f->vector], f->error);
    if (f->vector == 14) {
        kprintf("  faulting address (cr2) = %p: %s, %s, %s mode\n", (void *)read_cr2(),
                f->error & 1 ? "protection violation" : "page not present",
                f->error & 2 ? "write" : "read", f->error & 4 ? "user" : "kernel");
    }
    dump_frame(f);
    panic("unhandled exception %lu at rip %p", f->vector, (void *)f->rip);
}

void interrupt_dispatch(struct trap_frame *f) {
    if (f->vector < 32) { exception(f); return; }
    int irq = (int)f->vector - 32;
    if (irq_handlers[irq]) irq_handlers[irq](f);
    pic_eoi(irq);
}
