// file: proj/kernel/cmd_mm.c
#include <shell.h>
#include <mm.h>

SHELL_CMD(pt, "walk the page tables: pt <hexaddr>") { vmm_walk(parse_hex(arg)); }

SHELL_CMD(frames, "physical frame allocator statistics") {
    (void)arg;
    uint64_t f = pmm_free_count(), t = pmm_total_count();
    kprintf("frames: %lu free of %lu (%lu MiB free)\n", f, t, f * PAGE_SIZE >> 20);
}

SHELL_CMD(heap, "kernel heap statistics: heap [n] allocates n bytes first") {
    uint64_t n = 0;
    for (const char *p = arg; *p >= '0' && *p <= '9'; p++) n = n * 10 + (uint64_t)(*p - '0');
    if (n) kprintf("kmalloc(%lu) = %p\n", n, kmalloc(n));
    struct heap_stats s;
    kheap_check(&s);
    kprintf("heap: %zu KiB mapped, %zu blocks, %zu used bytes, %zu free bytes (largest %zu)\n", s.heap_bytes >> 10,
            s.blocks, s.used_bytes, s.free_bytes, s.largest_free);
}

SHELL_CMD(touch, "touch n pages of the lazy zone: touch <n>") {
    uint64_t n = 0;
    for (const char *p = arg; *p >= '0' && *p <= '9'; p++) n = n * 10 + (uint64_t)(*p - '0');
    uint64_t before = lazy_faults;
    for (uint64_t i = 0; i < n; i++) ((volatile char *)LAZY_START)[i * PAGE_SIZE] = 1;
    kprintf("touched %lu pages: %lu new page faults\n", n, lazy_faults - before);
}
