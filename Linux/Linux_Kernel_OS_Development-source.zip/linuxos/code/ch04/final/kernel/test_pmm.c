// file: new/kernel/test_pmm.c
#include <mm.h>

KTEST(pmm) {
    kprintf("kernel %p-%p, boot info %p-%p\n", (void *)_kernel_start, (void *)_kernel_end,
            (void *)mb_info_start, (void *)mb_info_end);
    uint64_t before = pmm_free_count();
    static uint64_t frames[1000];
    for (int i = 0; i < 1000; i++) {
        frames[i] = pmm_alloc();
        KASSERT(frames[i] != 0 && frames[i] % PAGE_SIZE == 0);
        memset((void *)frames[i], 0, PAGE_SIZE);                               /* use it, as a page table would */
    }
    kprintf("command line after zeroing 1000 allocated frames: \"%s\"\n", kernel_cmdline);
    for (int i = 0; i < 1000; i++) {
        KASSERT(frames[i] >= 0x100000);                                        /* never low memory */
        KASSERT(frames[i] >= (uint64_t)_kernel_end || frames[i] + PAGE_SIZE <= (uint64_t)_kernel_start);
        KASSERT(frames[i] >= ALIGN_UP(mb_info_end, PAGE_SIZE) || frames[i] + PAGE_SIZE <= mb_info_start);
        for (int j = i + 1; j < 1000; j++) KASSERT(frames[i] != frames[j]);    /* no frame handed out twice */
    }
    kprintf("1000 frames allocated: first 0x%lx, last 0x%lx; free %lu -> %lu\n", frames[0], frames[999], before,
            pmm_free_count());
    for (int i = 0; i < 1000; i++) pmm_free(frames[i]);
    KASSERT(pmm_free_count() == before);
    uint64_t n = 0;
    while (pmm_alloc()) n++;                                                   /* exhaust physical memory */
    kprintf("allocated every free frame: %lu frames = %lu MiB; then pmm_alloc() returns 0\n", n, n * PAGE_SIZE >> 20);
    KASSERT(n == before);
}
