// file: new/kernel/vmm.c
#include <mm.h>

extern uint64_t boot_pml4[512];               /* from boot.asm; CR3 points to it */
static uint64_t *pml4 = boot_pml4;
uint64_t lazy_faults;

static unsigned idx(uint64_t virt, int level) { return (virt >> (12 + 9 * level)) & 511; }   /* level 3 = PML4 */

static uint64_t *next_table(uint64_t *table, unsigned i, bool create) {
    if (!(table[i] & PTE_PRESENT)) {
        if (!create) return NULL;
        uint64_t frame = pmm_alloc();
        if (!frame) return NULL;
        memset((void *)frame, 0, PAGE_SIZE);   /* identity mapped: physical address usable as a pointer */
        table[i] = frame | PTE_PRESENT | PTE_WRITABLE;
    }
    if (table[i] & PTE_HUGE) return NULL;      /* a 2 MiB or 1 GiB page: there is no lower table */
    return (uint64_t *)(table[i] & PTE_ADDR);
}

uint64_t *vmm_pte(uint64_t virt, bool create) {
    uint64_t *t = pml4;
    for (int level = 3; level > 0; level--)
        if (!(t = next_table(t, idx(virt, level), create))) return NULL;
    return &t[idx(virt, 0)];
}

bool vmm_map(uint64_t virt, uint64_t phys, uint64_t flags) {
    KASSERT(virt % PAGE_SIZE == 0 && phys % PAGE_SIZE == 0);
    uint64_t *pte = vmm_pte(virt, true);
    if (!pte) return false;
    if (*pte & PTE_PRESENT) panic("vmm_map: 0x%lx is already mapped", virt);
    *pte = phys | flags | PTE_PRESENT;         /* not-present -> present needs no TLB flush */
    return true;
}

uint64_t vmm_unmap(uint64_t virt) {
    uint64_t *pte = vmm_pte(virt, false);
    if (!pte || !(*pte & PTE_PRESENT)) return 0;
    uint64_t phys = *pte & PTE_ADDR;
    *pte = 0;
    invlpg(virt);                              /* DT-9: the TLB may still hold the old translation */
    return phys;
}

bool vmm_translate(uint64_t virt, uint64_t *phys) {
    uint64_t *t = pml4;
    for (int level = 3; level >= 0; level--) {
        uint64_t e = t[idx(virt, level)];
        if (!(e & PTE_PRESENT)) return false;
        if (level == 0 || (e & PTE_HUGE)) {
            uint64_t page = 1UL << (12 + 9 * level);                   /* 4 KiB, 2 MiB or 1 GiB */
            *phys = (e & PTE_ADDR & ~(page - 1)) | (virt & (page - 1));
            return true;
        }
        t = (uint64_t *)(e & PTE_ADDR);
    }
    return false;
}

void vmm_walk(uint64_t virt) {
    static const char *const names[] = {"PT", "PD", "PDPT", "PML4"};
    kprintf("walk of %p:\n", (void *)virt);
    uint64_t *t = pml4;
    for (int level = 3; level >= 0; level--) {
        unsigned i = idx(virt, level);
        uint64_t e = t[i];
        kprintf("  %-4s[%3u] = %016lx  %s%s%s%s\n", names[level], i, e, e & PTE_PRESENT ? "P" : "-",
                e & PTE_WRITABLE ? "W" : "-", e & PTE_USER ? "U" : "-", e & PTE_HUGE ? " huge" : "");
        if (!(e & PTE_PRESENT)) { kprintf("  -> not mapped\n"); return; }
        if (level == 0 || (e & PTE_HUGE)) break;
        t = (uint64_t *)(e & PTE_ADDR);
    }
    uint64_t phys;
    vmm_translate(virt, &phys);
    kprintf("  -> physical %p\n", (void *)phys);
}

/* Demand paging: a fault in the lazy zone gets a fresh zeroed frame, and the faulting instruction is retried. */
bool vmm_handle_fault(struct trap_frame *f) {
    uint64_t addr = read_cr2();
    if (addr < LAZY_START || addr >= LAZY_END || (f->error & 1)) return false;   /* error bit 0: page was present */
    uint64_t frame = pmm_alloc();
    if (!frame) return false;
    memset((void *)frame, 0, PAGE_SIZE);
    vmm_map(ALIGN_DOWN(addr, PAGE_SIZE), frame, PTE_WRITABLE);
    lazy_faults++;
    return true;
}

void vmm_init(void) {
    uint64_t cr3;
    __asm__ volatile("mov %%cr3, %0" : "=r"(cr3));
    KASSERT((cr3 & PTE_ADDR) == (uint64_t)boot_pml4);
}
