// file: new/kernel/heap.c
/* A first-fit heap with boundary checks. Portable C: also compiled for the host test in this chapter's project. */
#include <mm.h>

#define MAGIC 0x6B6D616Cu                        /* "kmal" */
#define GROW  (64 * 1024)                        /* extend the heap at least this much at a time */

struct block {
    uint32_t magic;
    uint32_t free;
    size_t size;                                 /* payload bytes, multiple of 16 */
    struct block *prev, *next;                   /* neighbours in address order */
};
_Static_assert(sizeof(struct block) == 32, "header keeps payloads 16-byte aligned");

static struct block *head, *tail;

static void *payload(struct block *b) { return b + 1; }
static char *end_of(struct block *b) { return (char *)payload(b) + b->size; }

static void split(struct block *b, size_t n) {   /* keep n bytes in b; the rest becomes a new free block */
    if (b->size < n + sizeof(struct block) + 16) return;   /* remainder too small to be useful */
    struct block *r = (struct block *)((char *)payload(b) + n);
    *r = (struct block){MAGIC, 1, b->size - n - sizeof(struct block), b, b->next};
    if (b->next) b->next->prev = r; else tail = r;
    b->next = r;
    b->size = n;
}

static void merge_with_next(struct block *b) {    /* b and b->next are both free and adjacent */
    struct block *n = b->next;
    b->size += sizeof(struct block) + n->size;
    b->next = n->next;
    if (n->next) n->next->prev = b; else tail = b;
    n->magic = 0;                                 /* a stale pointer to n must not look valid */
}

static struct block *grow(size_t n) {
    size_t bytes = ALIGN_UP(n + sizeof(struct block), GROW);
    char *p = morecore(bytes);
    if (!p) return NULL;
    if (tail && tail->free && end_of(tail) == p) { tail->size += bytes; return tail; }
    struct block *b = (struct block *)p;
    *b = (struct block){MAGIC, 1, bytes - sizeof(struct block), tail, NULL};
    if (tail) tail->next = b; else head = b;
    tail = b;
    return b;
}

void *kmalloc(size_t n) {
    if (n == 0 || n > (1UL << 40)) return NULL;
    n = ALIGN_UP(n, 16);
    struct block *b;
    for (b = head; b; b = b->next)
        if (b->free && b->size >= n) break;
    if (!b && !(b = grow(n))) return NULL;
    split(b, n);
    b->free = 0;
    return payload(b);
}

void kfree(void *p) {
    if (!p) return;
    struct block *b = (struct block *)p - 1;
    if (b->magic != MAGIC) panic("kfree(%p): bad header magic 0x%x (corruption or not from kmalloc)", p, b->magic);
    if (b->free) panic("kfree(%p): double free", p);
    b->free = 1;
    if (b->next && b->next->free) merge_with_next(b);
    if (b->prev && b->prev->free) merge_with_next(b->prev);
}

void kheap_check(struct heap_stats *s) {
    *s = (struct heap_stats){0};
    struct block *prev = NULL;
    for (struct block *b = head; b; prev = b, b = b->next) {
        if (b->magic != MAGIC) panic("heap: block %p has bad magic 0x%x", (void *)b, b->magic);
        if (b->prev != prev) panic("heap: block %p has a broken prev link", (void *)b);
        if (b->size % 16) panic("heap: block %p has unaligned size %zu", (void *)b, b->size);
        if (prev && prev->free && b->free) panic("heap: adjacent free blocks %p and %p", (void *)prev, (void *)b);
        s->blocks++;
        s->heap_bytes += sizeof(struct block) + b->size;
        if (b->free) {
            s->free_blocks++;
            s->free_bytes += b->size;
            if (b->size > s->largest_free) s->largest_free = b->size;
        } else {
            s->used_bytes += b->size;
        }
    }
    if (prev != tail) panic("heap: tail pointer is wrong");
}
