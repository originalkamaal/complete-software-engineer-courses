// file: new/kernel/pmm.c
/* Physical memory manager: one bit per 4 KiB frame, 1 = in use. */
#include <mm.h>

static uint8_t *bitmap;
static uint64_t nframes, nfree, next_hint;

static bool used(uint64_t f) { return bitmap[f / 8] & (1 << (f % 8)); }
static void set_used(uint64_t f) { if (!used(f)) { bitmap[f / 8] |= (uint8_t)(1 << (f % 8)); nfree--; } }
static void set_free(uint64_t f) { if (used(f)) { bitmap[f / 8] &= (uint8_t)~(1 << (f % 8)); nfree++; } }

static void reserve(uint64_t start, uint64_t end) {          /* [start, end), any alignment */
    for (uint64_t f = start / PAGE_SIZE; f < ALIGN_UP(end, PAGE_SIZE) / PAGE_SIZE && f < nframes; f++) set_used(f);
}

void pmm_init(void) {
    uint64_t top = 0;
    for (int i = 0; i < usable_region_count; i++) {
        uint64_t end = usable_regions[i].base + usable_regions[i].length;
        if (end > top) top = end;
    }
    nframes = top / PAGE_SIZE;
    uint64_t bytes = (nframes + 7) / 8;
#ifdef NAIVE_BITMAP                                           /* experiment switch for DT-8: forget the boot info */
    bitmap = (uint8_t *)ALIGN_UP((uintptr_t)_kernel_end, PAGE_SIZE);
    mb_info_start = mb_info_end = 0;
#else
    uintptr_t after = (uintptr_t)_kernel_end > mb_info_end ? (uintptr_t)_kernel_end : mb_info_end;
    bitmap = (uint8_t *)ALIGN_UP(after, PAGE_SIZE);
#endif
    memset(bitmap, 0xFF, bytes);                              /* everything "used" ... */
    nfree = 0;
    for (int i = 0; i < usable_region_count; i++) {           /* ... except whole frames inside usable regions */
        uint64_t s = ALIGN_UP(usable_regions[i].base, PAGE_SIZE) / PAGE_SIZE;
        uint64_t e = ALIGN_DOWN(usable_regions[i].base + usable_regions[i].length, PAGE_SIZE) / PAGE_SIZE;
        for (uint64_t f = s; f < e; f++) { bitmap[f / 8] &= (uint8_t)~(1 << (f % 8)); nfree++; }
    }
    reserve(0, 0x100000);                                     /* real-mode area, BIOS data, legacy video */
    reserve((uintptr_t)_kernel_start, (uintptr_t)_kernel_end);
    reserve(mb_info_start, mb_info_end);
    reserve((uintptr_t)bitmap, (uintptr_t)bitmap + bytes);
    next_hint = 0;
}

uint64_t pmm_alloc(void) {
    for (uint64_t i = 0; i < nframes; i++) {
        uint64_t f = (next_hint + i) % nframes;
        if (!used(f)) {
            set_used(f);
            next_hint = f + 1;
            return f * PAGE_SIZE;
        }
    }
    return 0;                                                 /* frame 0 is reserved, so 0 means "none" */
}

void pmm_free(uint64_t frame) {
    KASSERT(frame % PAGE_SIZE == 0 && frame / PAGE_SIZE < nframes);
    if (!used(frame / PAGE_SIZE)) panic("pmm_free: double free of frame 0x%lx", frame);
    set_free(frame / PAGE_SIZE);
}

uint64_t pmm_free_count(void) { return nfree; }
uint64_t pmm_total_count(void) { return nframes; }
