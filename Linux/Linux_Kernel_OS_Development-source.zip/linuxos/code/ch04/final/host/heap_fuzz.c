// file: proj/host/heap_fuzz.c
/* Host harness for kernel/heap.c: same allocator code, a fake morecore, sanitizers on. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mm.h"

static _Alignas(4096) char arena[64 << 20];
static size_t arena_used;

void *morecore(size_t bytes) {                     /* like the kernel's: contiguous growth, NULL when full */
    if (arena_used + bytes > sizeof arena) return NULL;
    void *p = arena + arena_used;
    arena_used += bytes;
    return p;
}

_Noreturn void panic(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    fputs("PANIC: ", stdout); vprintf(fmt, ap); putchar('\n');
    va_end(ap);
    exit(2);
}

int main(int argc, char **argv) {
    enum { SLOTS = 4096 };
    static char *ptr[SLOTS];
    static size_t len[SLOTS];
    struct heap_stats s;
    srand(7);
    long ops = 2000000, mallocs = 0, checks = 0;
    if (argc > 1 && strcmp(argv[1], "overflow") == 0) {
        char *a = kmalloc(40), *b = kmalloc(40);
        printf("a=%p b=%p; writing 60 bytes into a's 48-byte block...\n", (void *)a, (void *)b);
        memset(a, 'x', 60);                         /* overruns into b's header */
        kheap_check(&s);
        puts("not detected");
        return 0;
    }
    for (long op = 0; op < ops; op++) {
        int i = rand() % SLOTS;
        if (ptr[i]) {
            for (size_t k = 0; k < len[i]; k++)
                if (ptr[i][k] != (char)(i ^ len[i])) panic("slot %d corrupted at byte %zu", i, k);
            kfree(ptr[i]);
            ptr[i] = NULL;
        } else {
            int r = rand() % 100;
            len[i] = r < 70 ? 1 + rand() % 64 : r < 97 ? 1 + rand() % 2048 : 1 + rand() % 200000;
            ptr[i] = kmalloc(len[i]);
            if (!ptr[i]) panic("out of memory at op %ld", op);
            if ((uintptr_t)ptr[i] % 16) panic("misaligned pointer %p", (void *)ptr[i]);
            memset(ptr[i], i ^ (int)len[i], len[i]);
            mallocs++;
        }
        if (op % 100000 == 0) { kheap_check(&s); checks++; }
    }
    kheap_check(&s);
    printf("%ld operations (%ld kmalloc), %ld full heap checks: no corruption\n", ops, mallocs, checks + 1);
    printf("live: %zu used bytes in %zu blocks; free: %zu bytes in %zu blocks (largest %zu); arena %zu KiB\n",
           s.used_bytes, s.blocks - s.free_blocks, s.free_bytes, s.free_blocks, s.largest_free, arena_used >> 10);
    printf("utilisation: %.1f%% of the arena holds live data\n", 100.0 * s.used_bytes / arena_used);
    for (int i = 0; i < SLOTS; i++) kfree(ptr[i]);
    kheap_check(&s);
    printf("after freeing everything: %zu block(s)\n", s.blocks);
    return 0;
}
