// file: dt13/layout.c
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>

struct naive  { uint16_t type; uint32_t size; uint16_t links; };   /* same fields, careless order */
struct sorted { uint16_t type; uint16_t links; uint32_t size; };
struct packed_naive { uint16_t type; uint32_t size; uint16_t links; } __attribute__((packed));

int main(void) {
    printf("naive:  %zu bytes (size at offset %zu)\n", sizeof(struct naive), offsetof(struct naive, size));
    printf("sorted: %zu bytes (size at offset %zu)\n", sizeof(struct sorted), offsetof(struct sorted, size));
    printf("packed: %zu bytes (size at offset %zu, misaligned)\n", sizeof(struct packed_naive),
           offsetof(struct packed_naive, size));
    return 0;
}
