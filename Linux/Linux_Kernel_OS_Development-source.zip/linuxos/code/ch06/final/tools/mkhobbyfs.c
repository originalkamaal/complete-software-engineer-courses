// file: new/tools/mkhobbyfs.c
/* mkhobbyfs IMAGE BLOCKS SRCDIR: build a hobbyfs image containing the tree under SRCDIR. */
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "hobbyfs.h"

static uint8_t *img;
static struct hbfs_super *sb;

static uint8_t *block(uint32_t b) { return img + (size_t)b * HBFS_BLOCK; }
static void die(const char *m, const char *x) { fprintf(stderr, "mkhobbyfs: %s %s\n", m, x ? x : ""); exit(1); }

static uint32_t alloc_bit(uint32_t bitmap_block, uint32_t limit, uint32_t *free_count) {
    uint8_t *bm = block(bitmap_block);
    for (uint32_t i = 0; i < limit; i++)
        if (!(bm[i / 8] & (1 << (i % 8)))) { bm[i / 8] |= (uint8_t)(1 << (i % 8)); (*free_count)--; return i; }
    die("out of space", NULL);
    return 0;
}
static uint32_t alloc_block(void) { return alloc_bit(sb->block_bitmap, sb->total_blocks, &sb->free_blocks); }
static uint32_t alloc_inode(void) { return alloc_bit(sb->inode_bitmap, sb->inode_count, &sb->free_inodes); }
static struct hbfs_inode *inode(uint32_t ino) {
    return (struct hbfs_inode *)block(sb->inode_table + ino / HBFS_INODES_PER_BLOCK) + ino % HBFS_INODES_PER_BLOCK;
}

static void write_data(uint32_t ino, const uint8_t *data, size_t size) {
    struct hbfs_inode *ip = inode(ino);
    size_t nblocks = (size + HBFS_BLOCK - 1) / HBFS_BLOCK;
    if (nblocks > HBFS_MAXBLOCKS) die("file too large", NULL);
    for (size_t n = 0; n < nblocks; n++) {
        uint32_t b = alloc_block();
        size_t len = size - n * HBFS_BLOCK < HBFS_BLOCK ? size - n * HBFS_BLOCK : HBFS_BLOCK;
        memcpy(block(b), data + n * HBFS_BLOCK, len);
        if (n < HBFS_NDIRECT) ip->direct[n] = b;
        else {
            if (!ip->indirect) ip->indirect = alloc_block();
            ((uint32_t *)block(ip->indirect))[n - HBFS_NDIRECT] = b;
        }
    }
    ip->size = (uint32_t)size;
}

static uint32_t add_tree(const char *path, uint32_t parent) {
    uint32_t ino = alloc_inode();
    if (parent == 0) parent = ino;                       /* the root is its own parent */
    inode(ino)->type = HBFS_DIR;
    inode(ino)->links = 2;
    struct dirent **names;
    int n = scandir(path, &names, NULL, alphasort);      /* sorted: the image is reproducible */
    if (n < 0) die("cannot read directory", path);
    struct hbfs_dirent *ents = calloc((size_t)n + 2, sizeof *ents);
    int count = 0;
    ents[count].inode = ino; strcpy(ents[count++].name, ".");
    ents[count].inode = parent; strcpy(ents[count++].name, "..");
    for (int i = 0; i < n; i++) {
        const char *name = names[i]->d_name;
        if (name[0] == '.') { free(names[i]); continue; }
        if (strlen(name) >= HBFS_NAME) die("name too long:", name);
        char child[4096];
        snprintf(child, sizeof child, "%s/%s", path, name);
        struct stat st;
        if (stat(child, &st) < 0) die("cannot stat", child);
        uint32_t cino;
        if (S_ISDIR(st.st_mode)) cino = add_tree(child, ino);
        else {
            FILE *f = fopen(child, "rb");
            if (!f) die("cannot open", child);
            uint8_t *data = malloc((size_t)st.st_size + 1);
            if (fread(data, 1, (size_t)st.st_size, f) != (size_t)st.st_size) die("short read", child);
            fclose(f);
            cino = alloc_inode();
            inode(cino)->type = HBFS_FILE;
            inode(cino)->links = 1;
            inode(cino)->mtime = (uint32_t)st.st_mtime;
            write_data(cino, data, (size_t)st.st_size);
            free(data);
        }
        ents[count].inode = cino;
        strcpy(ents[count++].name, name);
        free(names[i]);
    }
    free(names);
    write_data(ino, (const uint8_t *)ents, (size_t)count * sizeof *ents);
    free(ents);
    return ino;
}

int main(int argc, char **argv) {
    if (argc != 4) { fprintf(stderr, "usage: mkhobbyfs IMAGE BLOCKS SRCDIR\n"); return 2; }
    uint32_t total = (uint32_t)atoi(argv[2]);
    if (total < 64 || total > HBFS_BLOCK * 8) die("BLOCKS must be 64..8192", NULL);
    img = calloc(total, HBFS_BLOCK);
    sb = (struct hbfs_super *)block(1);
    *sb = (struct hbfs_super){HBFS_MAGIC, HBFS_BLOCK, total, 256, 2, 3, 4, 256 / HBFS_INODES_PER_BLOCK, 0, total, 256};
    sb->data_start = sb->inode_table + sb->inode_table_blocks;
    for (uint32_t b = 0; b < sb->data_start; b++) alloc_block();   /* metadata blocks are "used" */
    alloc_inode();                                                  /* inode 0 means "no inode" */
    if (add_tree(argv[3], 0) != HBFS_ROOT) die("root must be inode 1", NULL);
    FILE *out = fopen(argv[1], "wb");
    if (!out || fwrite(img, HBFS_BLOCK, total, out) != total || fclose(out)) die("cannot write", argv[1]);
    printf("%s: %u blocks (%u free), %u inodes (%u free)\n", argv[1], total, sb->free_blocks, sb->inode_count,
           sb->free_inodes);
    return 0;
}
