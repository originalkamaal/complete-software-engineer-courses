# file: new/tools/make_evil.py
"""Copy an ELF and point its first PT_LOAD at the kernel heap: a hostile executable."""
import struct, sys
data = bytearray(open(sys.argv[1], "rb").read())
phoff, = struct.unpack_from("<Q", data, 32)
for i in range(struct.unpack_from("<H", data, 56)[0]):
    off = phoff + i * 56
    if struct.unpack_from("<I", data, off)[0] == 1:          # PT_LOAD
        struct.pack_into("<Q", data, off + 16, 0xFFFF800000000000)   # p_vaddr
        break
open(sys.argv[2], "wb").write(data)
