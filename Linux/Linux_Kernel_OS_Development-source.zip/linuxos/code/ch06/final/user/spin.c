// file: new/user/spin.c
#include "ulib.h"

int main(void) {
    volatile unsigned long n = 0;
    for (;;) n++;                                 /* never yields, never makes a system call */
}
