# file: new/user/user.ld
ENTRY(_start)
SECTIONS {
    . = 0x40000000;
    .text : { *(.text.start) *(.text*) }
    .rodata : { *(.rodata*) }
    .data : { *(.data*) *(.bss*) *(COMMON) }   /* bss inside .data: the flat binary then contains its zeros */
    /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) }
}
