// file: new/user/badptr.c
#include "ulib.h"

int main(void) {
    u_puts("write(kernel image address)  = ");
    u_putnum(u_write((const char *)0x100000, 16));
    u_puts("\nwrite(kernel heap address)   = ");
    u_putnum(u_write((const char *)0xFFFF800000000000UL, 16));
    u_puts("\nwrite(0x10000000, not user)   = ");
    u_putnum(u_write((const char *)0x10000000, 16));
    u_puts("\nwrite(own string, 3 bytes)   = ");
    long r = u_write("ok ", 3);
    u_putnum(r);
    u_puts("\n");
    return 0;
}
