// file: new/user/priv.c
#include "ulib.h"

int main(void) {
    u_puts("priv: executing cli in ring 3\n");
    __asm__ volatile("cli");
    return 0;
}
