// file: proj/user/sh.c
#include "ulib.h"

static char line[128], path[64];

int main(void) {
    long fd = u_open("/etc/motd");
    if (fd >= 0) { long n; char buf[256]; while ((n = u_read(fd, buf, sizeof buf)) > 0) u_write(buf, (size_t)n); u_close(fd); }
    for (;;) {
        u_puts("$ ");
        long n = u_read(0, line, sizeof line);
        if (n <= 0) { u_puts("\n"); return 0; }          /* end of input */
        if (line[n - 1] == '\n') line[--n] = '\0';
        char *cmd = line;
        while (*cmd == ' ') cmd++;
        if (!*cmd) continue;
        char *args = cmd;
        while (*args && *args != ' ') args++;
        if (*args) *args++ = '\0';
        while (*args == ' ') args++;
        if (u_streq(cmd, "exit")) return 0;
        if (u_streq(cmd, "help")) { u_puts("built-ins: help exit; programs: ls /bin\n"); continue; }
        size_t k = 0;
        if (cmd[0] != '/') for (const char *p = "/bin/"; *p; p++) path[k++] = *p;
        for (const char *p = cmd; *p && k + 1 < sizeof path; p++) path[k++] = *p;
        path[k] = '\0';
        long t0 = u_ticks();
        long pid = u_spawn(path, args);
        if (pid < 0) {
            u_puts("sh: ");
            u_puts(cmd);
            u_puts(pid == -2 ? ": command not found\n" : pid == -8 ? ": not an executable\n" : ": cannot run\n");
            continue;
        }
        long status = u_wait(pid);
        if (status != 0) { u_puts("[exit status "); u_putnum(status); u_puts("]\n"); }
        if (u_ticks() - t0 > 100) { u_puts("[took "); u_putnum((u_ticks() - t0) * 10); u_puts(" ms]\n"); }
    }
}
