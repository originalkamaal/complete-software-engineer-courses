// file: new/user/ls.c
#include "ulib.h"

int main(void) {
    const char *path = U_ARGS[0] ? U_ARGS : "/";
    long fd = u_open(path);
    if (fd < 0) { u_puts("ls: cannot open "); u_puts(path); u_puts("\n"); return 1; }
    struct u_dirent d;
    for (long i = 0; u_readdir(fd, i, &d) == 1; i++) {
        u_puts(d.type == 2 ? "d " : "- ");
        char num[12];
        int k = 11;
        num[k] = 0;
        unsigned v = d.size;
        do { num[--k] = (char)('0' + v % 10); v /= 10; } while (v);
        while (k > 4) num[--k] = ' ';
        u_puts(num + k);
        u_puts("  ");
        u_puts(d.name);
        u_puts("\n");
    }
    u_close(fd);
    return 0;
}
