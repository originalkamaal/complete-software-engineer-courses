// file: new/user/ulib.h
#pragma once
typedef unsigned long size_t;

static inline long syscall3(long n, long a, long b, long c) {
    long r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "D"(a), "S"(b), "d"(c) : "memory");
    return r;
}
#define syscall2(n, a, b) syscall3(n, a, b, 0)
static inline long u_write(const void *buf, size_t n) { return syscall2(0, (long)buf, (long)n); }
static inline _Noreturn void u_exit(int code) { syscall2(1, code, 0); for (;;) { } }
static inline long u_getpid(void) { return syscall2(2, 0, 0); }
static inline void u_sleep_ms(long ms) { syscall2(3, ms, 0); }
static inline long u_ticks(void) { return syscall2(5, 0, 0); }
static inline long u_open(const char *path) { return syscall2(6, (long)path, 0); }
static inline long u_read(long fd, void *buf, size_t n) { return syscall3(7, fd, (long)buf, (long)n); }
static inline long u_close(long fd) { return syscall2(8, fd, 0); }
struct u_dirent { unsigned int ino, size, type; char name[28]; };
static inline long u_readdir(long fd, long index, struct u_dirent *d) { return syscall3(9, fd, index, (long)d); }
static inline long u_spawn(const char *path, const char *args) { return syscall2(10, (long)path, (long)args); }
static inline long u_wait(long pid) { return syscall2(11, pid, 0); }
#define U_ARGS ((const char *)0x7FFFFF00)     /* the kernel puts the argument string here */

static inline size_t u_strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
static inline int u_streq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static inline void u_puts(const char *s) { u_write(s, u_strlen(s)); }
static inline void u_putnum(long v) {
    char b[24];
    int i = 23;
    int neg = v < 0;
    unsigned long u = neg ? -(unsigned long)v : (unsigned long)v;
    b[i] = 0;
    do { b[--i] = (char)('0' + u % 10); u /= 10; } while (u);
    if (neg) b[--i] = '-';
    u_puts(b + i);
}
static inline void u_puthex(unsigned long v) {
    char b[19] = "0x";
    for (int i = 0; i < 16; i++) b[2 + i] = "0123456789abcdef"[(v >> (60 - 4 * i)) & 15];
    b[18] = 0;
    u_puts(b);
}

int main(void);
__attribute__((section(".text.start"), used)) void _start(void) { u_exit(main()); }
