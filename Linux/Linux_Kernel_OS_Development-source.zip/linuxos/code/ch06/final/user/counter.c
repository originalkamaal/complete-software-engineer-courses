// file: new/user/counter.c
#include "ulib.h"

static long counter;                              /* each process has its own copy at the same address */

int main(void) {
    long pid = u_getpid();
    for (int i = 0; i < 4; i++) {
        counter += pid;
        u_puts("  pid ");
        u_putnum(pid);
        u_puts(": &counter=");
        u_puthex((unsigned long)&counter);
        u_puts(" counter=");
        u_putnum(counter);
        u_puts("\n");
        u_sleep_ms(30);
    }
    return (int)counter;
}
