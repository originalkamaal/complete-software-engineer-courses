// file: new/user/cat.c
#include "ulib.h"

static char buf[2048];

int main(void) {
    long fd = u_open(U_ARGS);
    if (fd < 0) { u_puts("cat: "); u_puts(U_ARGS); u_puts(": error "); u_putnum(fd); u_puts("\n"); return 1; }
    long n;
    while ((n = u_read(fd, buf, sizeof buf)) > 0) u_write(buf, (size_t)n);
    u_close(fd);
    return n < 0 ? 1 : 0;
}
