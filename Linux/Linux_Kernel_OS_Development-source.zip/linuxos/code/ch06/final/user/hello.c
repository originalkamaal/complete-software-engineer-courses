// file: new/user/hello.c
#include "ulib.h"

int main(void) {
    unsigned short cs;
    __asm__ volatile("mov %%cs, %0" : "=r"(cs));
    u_puts("hello from user space: pid ");
    u_putnum(u_getpid());
    u_puts(", cs=");
    u_puthex(cs);
    u_puts(" -> ring ");
    u_putnum(cs & 3);
    u_puts("\n");
    return 7;
}
