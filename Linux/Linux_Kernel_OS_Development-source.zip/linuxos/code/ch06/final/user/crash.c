// file: new/user/crash.c
#include "ulib.h"

int main(void) {
    u_puts("crash: reading kernel memory at 0x100000\n");
    return *(volatile int *)0x100000;             /* identity-mapped, but without the user bit */
}
