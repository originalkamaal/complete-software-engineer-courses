// file: new/user/wc.c
#include "ulib.h"

static char buf[1024];

int main(void) {
    long fd = u_open(U_ARGS);
    if (fd < 0) { u_puts("wc: cannot open\n"); return 1; }
    long lines = 0, words = 0, bytes = 0, n;
    int in_word = 0;
    while ((n = u_read(fd, buf, sizeof buf)) > 0) {
        for (long i = 0; i < n; i++) {
            char c = buf[i];
            bytes++;
            if (c == '\n') lines++;
            int space = c == ' ' || c == '\n' || c == '\t';
            if (!space && !in_word) words++;
            in_word = !space;
        }
    }
    u_putnum(lines); u_puts(" "); u_putnum(words); u_puts(" "); u_putnum(bytes); u_puts(" "); u_puts(U_ARGS); u_puts("\n");
    return 0;
}
