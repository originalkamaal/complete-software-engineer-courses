; file: new/arch/switch.asm
bits 64
section .text
extern sched_finish_switch
extern task_exit

; void switch_to(uint64_t *save_rsp, uint64_t load_rsp)
global switch_to
switch_to:
    push rbp                      ; callee-saved registers: the caller expects them unchanged
    push rbx
    push r12
    push r13
    push r14
    push r15
    mov [rdi], rsp                ; save the old thread's stack pointer
    mov rsp, rsi                  ; ... and continue on the new thread's stack
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
    pop rbp
    ret                           ; returns wherever the new thread called switch_to (or to the trampoline)

; A new thread's first "return" lands here, with r12 = function and r13 = argument.
global thread_trampoline
thread_trampoline:
    call sched_finish_switch
    sti                           ; we came from schedule(), which runs with interrupts off
    mov rdi, r13
    call r12
    xor edi, edi
    call task_exit                ; the function returned: the thread exits with status 0

; void enter_user(uint64_t rip, uint64_t rsp): build an interrupt frame for ring 3 and "return" to it.
global enter_user
enter_user:
    mov ax, 0x1B                  ; user data selector (0x18) with RPL 3
    mov ds, ax
    mov es, ax
    push 0x1B                     ; ss
    push rsi                      ; rsp
    push 0x202                    ; rflags: IF = 1, so the timer can preempt user code
    push 0x23                     ; cs: user code selector (0x20) with RPL 3
    push rdi                      ; rip
    xor eax, eax                  ; leak no kernel values into user registers
    xor ebx, ebx
    xor ecx, ecx
    xor edx, edx
    xor esi, esi
    xor edi, edi
    xor ebp, ebp
    xor r8d, r8d
    xor r9d, r9d
    xor r10d, r10d
    xor r11d, r11d
    xor r12d, r12d
    xor r13d, r13d
    xor r14d, r14d
    xor r15d, r15d
    iretq
