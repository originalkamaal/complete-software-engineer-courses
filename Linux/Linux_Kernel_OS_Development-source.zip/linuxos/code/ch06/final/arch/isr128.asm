; file: new/arch/isr128.asm
bits 64
section .text
extern isr_common_entry
global isr128
isr128:                           ; int 0x80: the system-call vector; no error code
    push 0
    push 128
    jmp isr_common_entry
