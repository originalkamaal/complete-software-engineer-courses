// file: new/include/hobbyfs.h
#pragma once
#include <stdint.h>

#define HBFS_MAGIC       0x53464248u        /* "HBFS" as little-endian bytes */
#define HBFS_BLOCK       1024
#define HBFS_NDIRECT     12
#define HBFS_NINDIRECT   (HBFS_BLOCK / 4)
#define HBFS_MAXBLOCKS   (HBFS_NDIRECT + HBFS_NINDIRECT)
#define HBFS_ROOT        1
#define HBFS_NAME        28
enum { HBFS_FREE = 0, HBFS_FILE = 1, HBFS_DIR = 2 };

struct hbfs_super {
    uint32_t magic, block_size, total_blocks, inode_count;
    uint32_t inode_bitmap, block_bitmap, inode_table, inode_table_blocks, data_start;
    uint32_t free_blocks, free_inodes;
};
struct hbfs_inode {
    uint16_t type, links;
    uint32_t size;
    uint32_t direct[HBFS_NDIRECT];
    uint32_t indirect;
    uint32_t mtime;
};
struct hbfs_dirent {
    uint32_t inode;                          /* 0: unused slot */
    char name[HBFS_NAME];                    /* NUL-terminated unless exactly 28 bytes long */
};
#define HBFS_INODES_PER_BLOCK (HBFS_BLOCK / sizeof(struct hbfs_inode))

_Static_assert(sizeof(struct hbfs_super) == 44, "on-disk superblock layout");
_Static_assert(sizeof(struct hbfs_inode) == 64, "on-disk inode layout");
_Static_assert(sizeof(struct hbfs_dirent) == 32, "on-disk directory entry layout");
