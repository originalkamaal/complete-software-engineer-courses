// file: new/include/proc.h
#pragma once
#include <mm.h>
#include <io16.h>

#define EIO 5
#define ENOENT 2
#define ESRCH 3
#define ENOEXEC 8
#define EBADF 9
#define ENOMEM 12
#define EFAULT 14
#define ENOTDIR 20
#define EISDIR 21
#define EINVAL 22
#define EMFILE 24
#define ENAMETOOLONG 36
#define ENOSYS 38

enum task_state { TASK_RUNNABLE, TASK_RUNNING, TASK_SLEEPING, TASK_BLOCKED, TASK_ZOMBIE };
struct task;
struct waitq { struct task *head; };

#define NFILES 8
struct file { bool used, dir; uint32_t ino; uint64_t off; };

struct task {
    uint64_t rsp;
    uint64_t *pml4;
    void *kstack;
    int pid;
    enum task_state state;
    char name[16];
    bool user, killed;
    int exit_code;
    uint64_t wake_tick, runtime_ticks, switches;
    struct waitq exit_wait;
    struct task *next;
    struct task *all_next;
    struct file files[NFILES];    /* new: descriptors 3..7 (0-2 are the console) */
    uint64_t entry;               /* new: user entry point */
};
#define KSTACK_SIZE 16384

static inline uint64_t irq_save(void) {
    uint64_t f;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(f) : : "memory");
    return f;
}
static inline void irq_restore(uint64_t f) { if (f & 0x200) sti(); }

extern struct task *current;
extern volatile bool need_resched;
extern bool preempt_enabled;
void sched_init(void);
struct task *kthread_create(const char *name, void (*fn)(void *), void *arg);
struct task *task_create(const char *name, void (*fn)(void *), void *arg, uint64_t *pml4, bool user);
void schedule(void);
void yield(void);
void sleep_ticks(uint64_t n);
void wait_on(struct waitq *q);
void wake_all(struct waitq *q);
_Noreturn void task_exit(int code);
int  task_join(struct task *t);
void sched_tick(void);
struct task *task_first(void);
struct task *task_find(int pid);
const char *task_state_name(enum task_state s);

void gdt_init(void);
void tss_set_rsp0(uint64_t rsp0);
void syscall_dispatch(struct trap_frame *f);

/* disk, file system, programs */
int  ata_init(void);
int  ata_read(uint32_t lba, uint8_t count, void *buf);
int  ata_write(uint32_t lba, uint8_t count, const void *buf);
extern uint64_t ata_sectors, ata_reads, ata_writes, fs_block_reads;
extern char ata_model[41];
struct hbfs_inode;
struct hbfs_dirent;
int  fs_mount(void);
int  fs_lookup(const char *path);
int  fs_stat(uint32_t ino, struct hbfs_inode *out);
long fs_read(uint32_t ino, uint64_t off, void *buf, uint64_t n);
int  fs_dirent(uint32_t dir, uint32_t index, struct hbfs_dirent *out);
long elf_load(uint64_t *pml4, uint32_t ino, uint64_t *entry);
struct task *process_spawn(const char *path, const char *args, long *err);
long console_read_line(char *buf, uint64_t n);

#define USER_CODE_MIN    0x40000000UL       /* below: the shared, kernel-only identity map */
#define USER_STACK_TOP   0x80000000UL
#define USER_STACK_PAGES 4
#define USER_ARGS        (USER_STACK_TOP - 256)   /* the argument string lives here */
