// file: new/include/mm_extra.h
#pragma once
#include <mm.h>
bool vmm_translate_in(uint64_t *pml4, uint64_t virt, uint64_t *phys);
