// file: new/kernel/vmm_extra.c
#include <mm.h>
#include <mm_extra.h>

/* Like vmm_translate, for any address space (the walk in vmm.c is static, so repeat the four levels here). */
bool vmm_translate_in(uint64_t *pml4, uint64_t virt, uint64_t *phys) {
    uint64_t *t = pml4;
    for (int level = 3; level >= 0; level--) {
        uint64_t e = t[(virt >> (12 + 9 * level)) & 511];
        if (!(e & PTE_PRESENT)) return false;
        if (level == 0 || (e & PTE_HUGE)) {
            uint64_t page = 1UL << (12 + 9 * level);
            *phys = (e & PTE_ADDR & ~(page - 1)) | (virt & (page - 1));
            return true;
        }
        t = (uint64_t *)(e & PTE_ADDR);
    }
    return false;
}
