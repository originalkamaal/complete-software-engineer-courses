// file: new/kernel/test_user.c
#include <proc.h>

static int run(const char *path, const char *args) {
    long err;
    struct task *t = process_spawn(path, args, &err);
    if (!t) { kprintf("[%s: spawn failed, error %ld]\n", path, err); return (int)err; }
    int code = task_join(t);
    kprintf("[%s exited with status %d]\n", path, code);
    return code;
}

KTEST(user) {
    KASSERT(run("/bin/hello", "") == 7);
    KASSERT(run("/bin/badptr", "") == 0);
    KASSERT(run("/bin/crash", "") == -11);
    KASSERT(run("/bin/priv", "") == -11);
}

KTEST(isolation) {
    long err;
    struct task *a = process_spawn("/bin/counter", "", &err), *b = process_spawn("/bin/counter", "", &err);
    int ca = task_join(a), cb = task_join(b);
    kprintf("pid %d exited with %d, pid %d exited with %d\n", a->pid, ca, b->pid, cb);
    KASSERT(ca == 4 * a->pid && cb == 4 * b->pid);
}

KTEST(fs) {
    uint64_t reads0 = fs_block_reads;
    KASSERT(run("/bin/ls", "/") == 0);
    KASSERT(run("/bin/ls", "/docs") == 0);
    KASSERT(run("/bin/cat", "/etc/motd") == 0);
    KASSERT(run("/bin/wc", "/docs/numbers.txt") == 0);
    KASSERT(run("/bin/cat", "/no/such/file") == 1);
    KASSERT(run("/bin/nosuch", "") == -ENOENT);
    kprintf("block reads: %lu\n", fs_block_reads - reads0);
}

KTEST(elf) {
    KASSERT(run("/etc/motd", "") == -ENOEXEC);          /* not an ELF file at all */
    KASSERT(run("/bin/evil", "") == -ENOEXEC);          /* ELF, but it wants to load into the kernel */
}
