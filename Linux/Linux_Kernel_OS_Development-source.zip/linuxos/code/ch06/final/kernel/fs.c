// file: new/kernel/fs.c
/* hobbyfs, read-only. All functions return a negative errno on failure. */
#include <proc.h>
#include <hobbyfs.h>

static struct hbfs_super sb;
static bool mounted;
uint64_t fs_block_reads;

static int read_block(uint32_t b, void *buf) {
    if (b >= sb.total_blocks && mounted) return -EIO;
    fs_block_reads++;
    return ata_read(b * 2, 2, buf) < 0 ? -EIO : 0;
}

int fs_mount(void) {
    uint8_t buf[HBFS_BLOCK];
    mounted = false;
    if (read_block(1, buf) < 0) return -EIO;
    memcpy(&sb, buf, sizeof sb);
    if (sb.magic != HBFS_MAGIC || sb.block_size != HBFS_BLOCK) return -EINVAL;
    if ((uint64_t)sb.total_blocks * 2 > ata_sectors) return -EINVAL;     /* the disk is smaller than claimed */
    mounted = true;
    return 0;
}

int fs_stat(uint32_t ino, struct hbfs_inode *out) {
    if (ino == 0 || ino >= sb.inode_count) return -ENOENT;
    uint8_t buf[HBFS_BLOCK];
    int r = read_block(sb.inode_table + ino / HBFS_INODES_PER_BLOCK, buf);
    if (r < 0) return r;
    memcpy(out, buf + (ino % HBFS_INODES_PER_BLOCK) * sizeof *out, sizeof *out);
    return out->type == HBFS_FREE ? -ENOENT : 0;
}

static int bmap(const struct hbfs_inode *ip, uint32_t n, uint32_t *out) {   /* file block n -> disk block */
    if (n < HBFS_NDIRECT) { *out = ip->direct[n]; return 0; }
    if (n >= HBFS_MAXBLOCKS || !ip->indirect) return -EIO;
    uint32_t ind[HBFS_NINDIRECT];
    int r = read_block(ip->indirect, ind);
    *out = ind[n - HBFS_NDIRECT];
    return r;
}

long fs_read(uint32_t ino, uint64_t off, void *buf, uint64_t n) {
    struct hbfs_inode ip;
    int r = fs_stat(ino, &ip);
    if (r < 0) return r;
    if (off >= ip.size) return 0;
    if (n > ip.size - off) n = ip.size - off;
    uint8_t blk[HBFS_BLOCK];
    uint64_t done = 0;
    while (done < n) {
        uint64_t pos = off + done, in_block = pos % HBFS_BLOCK;
        uint64_t chunk = HBFS_BLOCK - in_block < n - done ? HBFS_BLOCK - in_block : n - done;
        uint32_t b;
        if ((r = bmap(&ip, (uint32_t)(pos / HBFS_BLOCK), &b)) < 0 || (r = read_block(b, blk)) < 0) return r;
        memcpy((uint8_t *)buf + done, blk + in_block, chunk);
        done += chunk;
    }
    return (long)done;
}

int fs_dirent(uint32_t dir, uint32_t index, struct hbfs_dirent *out) {   /* 1: got entry, 0: end */
    long r = fs_read(dir, (uint64_t)index * sizeof *out, out, sizeof *out);
    if (r < 0) return (int)r;
    return r == sizeof *out;
}

int fs_lookup(const char *path) {                    /* absolute path -> inode number */
    if (!mounted) return -EIO;
    if (path[0] != '/') return -ENOENT;
    uint32_t ino = HBFS_ROOT;
    while (*path) {
        while (*path == '/') path++;
        if (!*path) break;
        char name[HBFS_NAME];
        size_t len = 0;
        while (path[len] && path[len] != '/') len++;
        if (len >= HBFS_NAME) return -ENAMETOOLONG;
        memcpy(name, path, len);
        name[len] = '\0';
        path += len;
        struct hbfs_inode ip;
        int r = fs_stat(ino, &ip);
        if (r < 0) return r;
        if (ip.type != HBFS_DIR) return -ENOTDIR;
        struct hbfs_dirent d;
        uint32_t i = 0, found = 0;
        while ((r = fs_dirent(ino, i++, &d)) == 1)
            if (d.inode && strncmp(d.name, name, HBFS_NAME) == 0) { found = d.inode; break; }
        if (r < 0) return r;
        if (!found) return -ENOENT;
        ino = found;
    }
    return (int)ino;
}
