// file: new/kernel/console.c
#include <proc.h>

#define COM1 0x3F8

void serial_init(void) {
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x80);
    outb(COM1 + 0, 0x01);
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);
    outb(COM1 + 2, 0xC7);
    outb(COM1 + 4, 0x0B);
}

void serial_putc(char c) {
    if (c == '\n') serial_putc('\r');
    while (!(inb(COM1 + 5) & 0x20)) { }
    outb(COM1, (uint8_t)c);
}

#define RX_SIZE 256
static char rx_buf[RX_SIZE];
static volatile uint32_t rx_head, rx_tail;
static struct waitq rx_wait;
volatile uint64_t serial_irq_count, serial_rx_bytes;

static void serial_irq(struct trap_frame *f) {
    (void)f;
    serial_irq_count++;
    while (inb(COM1 + 5) & 0x01) {
        char c = (char)inb(COM1);
        serial_rx_bytes++;
        if (rx_head - rx_tail < RX_SIZE) rx_buf[rx_head++ % RX_SIZE] = c;
    }
    wake_all(&rx_wait);                         /* changed: wake the readers */
}

void serial_enable_rx_irq(void) {
    irq_register(4, serial_irq);
    outb(COM1 + 1, 0x01);
    pic_unmask(4);
}

int serial_getc(void) {
    uint64_t f = irq_save();
    while (rx_head == rx_tail) wait_on(&rx_wait);   /* changed: sleep this thread, run others */
    char c = rx_buf[rx_tail++ % RX_SIZE];
    irq_restore(f);
    return (unsigned char)c;
}

static volatile uint16_t *const vga = (uint16_t *)0xB8000;
static int row, col;

void vga_clear(void) {
    for (int i = 0; i < 80 * 25; i++) vga[i] = 0x0720;
    row = col = 0;
}

void vga_putc(char c) {
    if (c == '\n') { col = 0; row++; }
    else if (c == '\b') { if (col) vga[row * 80 + --col] = 0x0720; }
    else { vga[row * 80 + col] = (uint16_t)(0x0700 | (uint8_t)c); if (++col == 80) { col = 0; row++; } }
    if (row == 25) {
        memmove((void *)vga, (const void *)(vga + 80), 80 * 24 * 2);
        for (int i = 0; i < 80; i++) vga[24 * 80 + i] = 0x0720;
        row = 24;
    }
}
