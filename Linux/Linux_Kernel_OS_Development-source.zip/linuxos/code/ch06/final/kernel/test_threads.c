// file: new/kernel/test_threads.c
#include <proc.h>

static void cooperative(void *arg) {
    for (int i = 0; i < 3; i++) {
        kprintf("%s%d ", (const char *)arg, i);
        yield();                                  /* give the CPU away voluntarily */
    }
}

KTEST(threads) {
    preempt_enabled = false;                      /* only yield() switches */
    struct task *a = kthread_create("A", cooperative, "A");
    struct task *b = kthread_create("B", cooperative, "B");
    task_join(a);
    task_join(b);
    kprintf("\nA switched in %lu times, B %lu times\n", a->switches, b->switches);
    preempt_enabled = true;
}
