// file: new/kernel/main.c
#include <proc.h>

extern const struct ktest __ktests_start[], __ktests_end[];

__attribute__((weak)) void shell_run(void) { kprintf("no shell in this build\n"); }

static void run_test(const char *name) {
    for (const struct ktest *t = __ktests_start; t < __ktests_end; t++) {
        if (strncmp(t->name, name, 64) == 0) {
            kprintf("== test %s ==\n", t->name);
            t->fn();
            kprintf("== test %s passed ==\n", t->name);
            return;
        }
    }
    kprintf("unknown test '%s'; available:", name);
    for (const struct ktest *t = __ktests_start; t < __ktests_end; t++) kprintf(" %s", t->name);
    kprintf("\n");
}

void kmain(uint32_t magic, uintptr_t info) {
    serial_init();
    vga_clear();
    multiboot2_parse(magic, info);
    gdt_init();
    idt_init();
    pmm_init();
    vmm_init();
    sched_init();
    kprintf("hobby os: %lu MiB usable, command line \"%s\"\n", usable_ram_bytes >> 20, kernel_cmdline);
    if (ata_init() == 0) kprintf("disk: \"%s\", %lu sectors (%lu KiB)\n", ata_model, ata_sectors, ata_sectors / 2);
    int r = fs_mount();
    kprintf("hobbyfs: %s\n", r == 0 ? "mounted" : "mount failed");
    pic_init();
    timer_init(100);
    serial_enable_rx_irq();
    sti();
    char arg[32];
    if (cmdline_get("test", arg, sizeof arg)) run_test(arg);
    else if (cmdline_get("init", arg, sizeof arg)) {
        long err;
        struct task *t = process_spawn(arg, "", &err);
        if (!t) kprintf("cannot start %s: error %ld\n", arg, err);
        else kprintf("[init %s exited with status %d]\n", arg, task_join(t));
    } else shell_run();
    qemu_exit(0x10);
}
