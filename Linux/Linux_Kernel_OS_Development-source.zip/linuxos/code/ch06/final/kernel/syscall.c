// file: new/kernel/syscall.c
#include <proc_extra.h>
#include <hobbyfs.h>

enum { SYS_WRITE, SYS_EXIT, SYS_GETPID, SYS_SLEEP, SYS_YIELD, SYS_TICKS,
       SYS_OPEN, SYS_READ, SYS_CLOSE, SYS_READDIR, SYS_SPAWN, SYS_WAIT };

struct u_dirent { uint32_t ino, size, type; char name[HBFS_NAME]; };   /* what readdir gives user space */

static long copy_string_in(char *dst, uint64_t src, size_t max) {
    for (size_t i = 0; i < max; i++) {
        if ((i == 0 || (src + i) % PAGE_SIZE == 0) && !user_range_ok(current->pml4, src + i, 1, false)) return -EFAULT;
        if (!(dst[i] = ((const char *)src)[i])) return (long)i;
    }
    return -ENAMETOOLONG;
}

static struct file *fd_get(uint64_t fd) {
    if (fd < 3 || fd >= NFILES || !current->files[fd].used) return NULL;
    return &current->files[fd];
}

static long sys_write(uint64_t buf, uint64_t len) {
    if (len > 4096) return -EINVAL;
    if (!user_range_ok(current->pml4, buf, len, false)) return -EFAULT;
    const char *p = (const char *)buf;
    for (uint64_t i = 0; i < len; i++) { serial_putc(p[i]); vga_putc(p[i]); }
    return (long)len;
}

static long sys_open(uint64_t upath) {
    char path[128];
    long r = copy_string_in(path, upath, sizeof path);
    if (r < 0) return r;
    int ino = fs_lookup(path);
    if (ino < 0) return ino;
    struct hbfs_inode ip;
    if ((r = fs_stat((uint32_t)ino, &ip)) < 0) return r;
    for (int fd = 3; fd < NFILES; fd++) {
        if (!current->files[fd].used) {
            current->files[fd] = (struct file){true, ip.type == HBFS_DIR, (uint32_t)ino, 0};
            return fd;
        }
    }
    return -EMFILE;
}

static long sys_read(uint64_t fd, uint64_t buf, uint64_t n) {
    if (n > 65536) n = 65536;
    if (!user_range_ok(current->pml4, buf, n, true)) return -EFAULT;
    if (fd == 0) return console_read_line((char *)buf, n);
    struct file *f = fd_get(fd);
    if (!f) return -EBADF;
    if (f->dir) return -EISDIR;
    long r = fs_read(f->ino, f->off, (void *)buf, n);
    if (r > 0) f->off += (uint64_t)r;
    return r;
}

static long sys_readdir(uint64_t fd, uint64_t index, uint64_t out) {
    struct file *f = fd_get(fd);
    if (!f) return -EBADF;
    if (!f->dir) return -ENOTDIR;
    if (!user_range_ok(current->pml4, out, sizeof(struct u_dirent), true)) return -EFAULT;
    struct hbfs_dirent d;
    int r;
    do { r = fs_dirent(f->ino, (uint32_t)index++, &d); } while (r == 1 && d.inode == 0);   /* skip empty slots */
    if (r <= 0) return r;
    struct hbfs_inode ip;
    if ((r = fs_stat(d.inode, &ip)) < 0) return r;
    struct u_dirent *u = (struct u_dirent *)out;
    u->ino = d.inode;
    u->size = ip.size;
    u->type = ip.type;
    memcpy(u->name, d.name, HBFS_NAME);
    return 1;
}

static long sys_spawn(uint64_t upath, uint64_t uargs) {
    char path[128], args[128] = "";
    long r = copy_string_in(path, upath, sizeof path);
    if (r < 0) return r;
    if (uargs && (r = copy_string_in(args, uargs, sizeof args)) < 0) return r;
    struct task *t = process_spawn(path, args, &r);
    return t ? t->pid : r;
}

static long sys_wait(uint64_t pid) {
    struct task *t = task_find((int)pid);
    if (!t || !t->user || t == current) return -ESRCH;
    return task_join(t);
}

void syscall_dispatch(struct trap_frame *f) {
    long r;
    switch (f->rax) {
    case SYS_WRITE:   r = sys_write(f->rdi, f->rsi); break;
    case SYS_EXIT:    task_exit((int)f->rdi);
    case SYS_GETPID:  r = current->pid; break;
    case SYS_SLEEP:   sleep_ticks(f->rdi * timer_hz / 1000 + 1); r = 0; break;
    case SYS_YIELD:   yield(); r = 0; break;
    case SYS_TICKS:   r = (long)ticks; break;
    case SYS_OPEN:    r = sys_open(f->rdi); break;
    case SYS_READ:    sti(); r = sys_read(f->rdi, f->rsi, f->rdx); break;   /* may block for a long time */
    case SYS_CLOSE:   { struct file *fl = fd_get(f->rdi); r = fl ? (fl->used = false, 0) : -EBADF; break; }
    case SYS_READDIR: r = sys_readdir(f->rdi, f->rsi, f->rdx); break;
    case SYS_SPAWN:   sti(); r = sys_spawn(f->rdi, f->rsi); break;
    case SYS_WAIT:    r = sys_wait(f->rdi); break;
    default:          r = -ENOSYS;
    }
    f->rax = (uint64_t)r;
}
