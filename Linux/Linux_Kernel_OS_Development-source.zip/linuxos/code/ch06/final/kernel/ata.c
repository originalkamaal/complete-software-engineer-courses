// file: new/kernel/ata.c
/* ATA PIO driver for the primary channel's master drive, LBA28, polling (no interrupts). */
#include <kernel.h>
#include <io16.h>

#define ATA_DATA    0x1F0
#define ATA_ERROR   0x1F1
#define ATA_COUNT   0x1F2
#define ATA_LBA0    0x1F3
#define ATA_LBA1    0x1F4
#define ATA_LBA2    0x1F5
#define ATA_DRIVE   0x1F6
#define ATA_CMD     0x1F7          /* write: command; read: status */
#define ATA_CONTROL 0x3F6          /* write: device control; read: alternate status */

#define ST_ERR 0x01
#define ST_DRQ 0x08
#define ST_DF  0x20
#define ST_BSY 0x80

uint64_t ata_sectors, ata_reads, ata_writes;
char ata_model[41];

static void delay400ns(void) { for (int i = 0; i < 4; i++) (void)inb(ATA_CONTROL); }   /* ~100 ns per read */

static int wait_ready(void) {
    for (;;) {
        uint8_t st = inb(ATA_CMD);
        if (st & ST_BSY) continue;
        if (st & (ST_ERR | ST_DF)) return -1;
        return 0;
    }
}

static int wait_drq(void) {
    for (;;) {
        uint8_t st = inb(ATA_CMD);
        if (st & ST_BSY) continue;
        if (st & (ST_ERR | ST_DF)) return -1;
        if (st & ST_DRQ) return 0;
    }
}

int ata_init(void) {
    outb(ATA_CONTROL, 0x02);                          /* nIEN: no interrupts, we poll */
    outb(ATA_DRIVE, 0xA0);                            /* select master */
    delay400ns();
    outb(ATA_COUNT, 0); outb(ATA_LBA0, 0); outb(ATA_LBA1, 0); outb(ATA_LBA2, 0);
    outb(ATA_CMD, 0xEC);                              /* IDENTIFY DEVICE */
    if (inb(ATA_CMD) == 0) return -1;                 /* status 0: no drive */
    while (inb(ATA_CMD) & ST_BSY) { }
    if (inb(ATA_LBA1) || inb(ATA_LBA2)) return -1;    /* an ATAPI (CD-ROM) or SATA signature, not ATA */
    if (wait_drq() < 0) return -1;
    uint16_t id[256];
    for (int i = 0; i < 256; i++) id[i] = inw(ATA_DATA);
    for (int i = 0; i < 20; i++) {                    /* model string: words 27-46, bytes swapped */
        ata_model[2 * i] = (char)(id[27 + i] >> 8);
        ata_model[2 * i + 1] = (char)id[27 + i];
    }
    for (int i = 39; i >= 0 && ata_model[i] == ' '; i--) ata_model[i] = '\0';
    ata_sectors = id[60] | (uint64_t)id[61] << 16;    /* number of LBA28-addressable sectors */
    return 0;
}

static void issue(uint32_t lba, uint8_t count, uint8_t cmd) {
    outb(ATA_DRIVE, (uint8_t)(0xE0 | ((lba >> 24) & 0x0F)));  /* LBA mode, master, LBA bits 24-27 */
    outb(ATA_COUNT, count);
    outb(ATA_LBA0, (uint8_t)lba);
    outb(ATA_LBA1, (uint8_t)(lba >> 8));
    outb(ATA_LBA2, (uint8_t)(lba >> 16));
    outb(ATA_CMD, cmd);
}

int ata_read(uint32_t lba, uint8_t count, void *buf) {
    if (!count || lba + count > ata_sectors) return -1;
    uint64_t f = 0;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(f) : : "memory");   /* one command at a time */
    int r = wait_ready();
    if (r == 0) {
        issue(lba, count, 0x20);                      /* READ SECTORS */
        uint16_t *p = buf;
        for (int s = 0; s < count && r == 0; s++) {
            delay400ns();                             /* status is not valid immediately after a command */
            if ((r = wait_drq()) == 0) {
                __asm__ volatile("rep insw" : "+D"(p), "+c"((uint64_t){256}) : "d"(ATA_DATA) : "memory");
            }
        }
        ata_reads += count;
    }
    if (f & 0x200) sti();
    return r;
}

int ata_write(uint32_t lba, uint8_t count, const void *buf) {
    if (!count || lba + count > ata_sectors) return -1;
    uint64_t f = 0;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(f) : : "memory");
    int r = wait_ready();
    if (r == 0) {
        issue(lba, count, 0x30);                      /* WRITE SECTORS */
        const uint16_t *p = buf;
        for (int s = 0; s < count && r == 0; s++) {
            delay400ns();
            if ((r = wait_drq()) == 0) {
                __asm__ volatile("rep outsw" : "+S"(p), "+c"((uint64_t){256}) : "d"(ATA_DATA) : "memory");
            }
        }
        if (r == 0) { outb(ATA_CMD, 0xE7); r = wait_ready(); }   /* CACHE FLUSH: make it durable */
        ata_writes += count;
    }
    if (f & 0x200) sti();
    return r;
}
