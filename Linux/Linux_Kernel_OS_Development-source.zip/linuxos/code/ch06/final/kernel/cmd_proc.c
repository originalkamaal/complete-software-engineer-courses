// file: new/kernel/cmd_proc.c
#include <shell.h>
#include <proc.h>

static int parse_int(const char *s) {
    int v = 0;
    while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0');
    return v;
}

SHELL_CMD(run, "run a program from the disk: run /bin/name [args] [&]") {
    char path[64];
    size_t n = 0;
    while (*arg && *arg != ' ' && n + 1 < sizeof path) path[n++] = *arg++;
    path[n] = '\0';
    while (*arg == ' ') arg++;
    char args[64];
    n = 0;
    while (*arg && *arg != '&' && n + 1 < sizeof args) args[n++] = *arg++;
    while (n && args[n - 1] == ' ') n--;
    args[n] = '\0';
    bool background = *arg == '&';
    long err;
    struct task *t = process_spawn(path, args, &err);
    if (!t) { kprintf("run: %s: error %ld\n", path, err); return; }
    if (background) { kprintf("[%d] %s started in the background\n", t->pid, t->name); return; }
    kprintf("[%s exited with status %d]\n", t->name, task_join(t));
}

SHELL_CMD(ps, "list tasks") {
    (void)arg;
    kprintf("  PID  STATE     KIND    CPU(ticks)  SWITCHES  NAME\n");
    for (struct task *t = task_first(); t; t = t->all_next) {
        if (t->state == TASK_ZOMBIE) kprintf("%5d  exit %-4d %-7s %10lu  %8lu  %s\n", t->pid, t->exit_code,
                                             t->user ? "user" : "kernel", t->runtime_ticks, t->switches, t->name);
        else kprintf("%5d  %-9s %-7s %10lu  %8lu  %s\n", t->pid, task_state_name(t->state),
                     t->user ? "user" : "kernel", t->runtime_ticks, t->switches, t->name);
    }
}

SHELL_CMD(kill, "kill a user process: kill <pid>") {
    int pid = parse_int(arg);
    uint64_t f = irq_save();
    struct task *t = task_find(pid);
    if (!t || !t->user || t->state == TASK_ZOMBIE) {
        irq_restore(f);
        kprintf("no live user process %d\n", pid);
        return;
    }
    t->killed = true;
    if (t->state == TASK_SLEEPING) t->wake_tick = 0;
    irq_restore(f);
    task_join(t);
    kprintf("[%d %s] killed, exit status %d\n", pid, t->name, t->exit_code);
}
