// file: new/kernel/sched.c
#include <proc.h>

extern void switch_to(uint64_t *save_rsp, uint64_t load_rsp);
extern char thread_trampoline[];
extern char stack_top[];

#define SLICE_TICKS 5                         /* 50 ms at 100 Hz */

struct task *current;
volatile bool need_resched;
bool preempt_enabled = true;
static struct task *rq_head, *rq_tail, *idle, *all_tasks, *to_free;
static int next_pid;
static unsigned slice;

static void rq_push(struct task *t) {
    t->next = NULL;
    if (rq_tail) rq_tail->next = t; else rq_head = t;
    rq_tail = t;
    if (current == idle) need_resched = true;   /* the idle task should give way at once */
}

static struct task *rq_pop(void) {
    struct task *t = rq_head;
    if (t && !(rq_head = t->next)) rq_tail = NULL;
    return t;
}

static struct task *task_alloc(const char *name) {
    struct task *t = kmalloc(sizeof *t);
    KASSERT(t);
    memset(t, 0, sizeof *t);
    t->pid = next_pid++;
    for (int i = 0; i < 15 && name[i]; i++) t->name[i] = name[i];
    t->pml4 = kernel_pml4;
    uint64_t f = irq_save();
    t->all_next = all_tasks;
    all_tasks = t;
    irq_restore(f);
    return t;
}

static void prepare_stack(struct task *t, void (*fn)(void *), void *arg) {
    t->kstack = kmalloc(KSTACK_SIZE);
    KASSERT(t->kstack);
    uint64_t *sp = (uint64_t *)((char *)t->kstack + KSTACK_SIZE);
    *--sp = (uint64_t)thread_trampoline;
    *--sp = 0;                 /* rbp */
    *--sp = 0;                 /* rbx */
    *--sp = (uint64_t)fn;      /* r12 */
    *--sp = (uint64_t)arg;     /* r13 */
    *--sp = 0;                 /* r14 */
    *--sp = 0;                 /* r15 */
    t->rsp = (uint64_t)sp;
}

struct task *task_create(const char *name, void (*fn)(void *), void *arg, uint64_t *pml4, bool user) {
    struct task *t = task_alloc(name);
    prepare_stack(t, fn, arg);
    t->pml4 = pml4;
    t->user = user;
    uint64_t f = irq_save();
    t->state = TASK_RUNNABLE;
    rq_push(t);
    irq_restore(f);
    return t;
}

struct task *kthread_create(const char *name, void (*fn)(void *), void *arg) {
    return task_create(name, fn, arg, kernel_pml4, false);
}

static void idle_loop(void *arg) {
    (void)arg;
    for (;;) hlt();                           /* interrupts are on: any interrupt wakes us */
}

void sched_init(void) {
    current = task_alloc("kmain");           /* the boot thread becomes task 0 */
    current->kstack = (void *)((uintptr_t)stack_top - KSTACK_SIZE);   /* boot.asm reserved 16 KiB below stack_top */
    current->state = TASK_RUNNING;
    idle = task_alloc("idle");
    prepare_stack(idle, idle_loop, NULL);
    idle->state = TASK_RUNNABLE;             /* never in the run queue: chosen only when it is empty */
}

/* Runs in the context of whichever task is resuming. Frees the task that exited before us. */
void sched_finish_switch(void) {
    struct task *z = to_free;
    if (!z || z == current) return;
    to_free = NULL;
    kfree(z->kstack);
    z->kstack = NULL;
    if (z->pml4 != kernel_pml4) { vmm_destroy_space(z->pml4); z->pml4 = NULL; }
}

void schedule(void) {
    struct task *prev = current;
    if (prev->state == TASK_RUNNING) {
        prev->state = TASK_RUNNABLE;
        if (prev != idle) rq_push(prev);     /* the idle task is never queued */
    }
    struct task *next = rq_pop();
    if (!next) next = idle;
    need_resched = false;
    slice = 0;
    if (next == prev) { prev->state = TASK_RUNNING; return; }
    if (prev->state == TASK_ZOMBIE) to_free = prev;    /* cannot free the stack we are standing on */
    next->state = TASK_RUNNING;
    next->switches++;
    current = next;
    tss_set_rsp0((uint64_t)next->kstack + KSTACK_SIZE);  /* where the CPU puts the frame on an interrupt from ring 3 */
    if (next->pml4 != prev->pml4) __asm__ volatile("mov %0, %%cr3" : : "r"(next->pml4) : "memory");
    switch_to(&prev->rsp, next->rsp);
    sched_finish_switch();                   /* we are "next" now, possibly much later */
}

void yield(void) { uint64_t f = irq_save(); schedule(); irq_restore(f); }

void sleep_ticks(uint64_t n) {
    uint64_t f = irq_save();
    current->wake_tick = ticks + n;
    current->state = TASK_SLEEPING;
    schedule();
    irq_restore(f);
}

void wait_on(struct waitq *q) {
    current->state = TASK_BLOCKED;
    current->next = q->head;
    q->head = current;
    schedule();
}

void wake_all(struct waitq *q) {
    while (q->head) {
        struct task *t = q->head;
        q->head = t->next;
        if (t->state == TASK_BLOCKED) { t->state = TASK_RUNNABLE; rq_push(t); }
    }
}

_Noreturn void task_exit(int code) {
    cli();
    current->exit_code = code;
    current->state = TASK_ZOMBIE;
    wake_all(&current->exit_wait);
    schedule();
    panic("a zombie was scheduled");
}

int task_join(struct task *t) {
    uint64_t f = irq_save();
    while (t->state != TASK_ZOMBIE) wait_on(&t->exit_wait);
    irq_restore(f);
    return t->exit_code;
}

void sched_tick(void) {                       /* interrupt context */
    for (struct task *t = all_tasks; t; t = t->all_next)
        if (t->state == TASK_SLEEPING && t->wake_tick <= ticks) { t->state = TASK_RUNNABLE; rq_push(t); }
    current->runtime_ticks++;
    if (preempt_enabled && current != idle && ++slice >= SLICE_TICKS) need_resched = true;
}

struct task *task_first(void) { return all_tasks; }
struct task *task_find(int pid) {
    for (struct task *t = all_tasks; t; t = t->all_next) if (t->pid == pid) return t;
    return NULL;
}
const char *task_state_name(enum task_state s) {
    static const char *const n[] = {"runnable", "running", "sleeping", "blocked", "zombie"};
    return n[s];
}
