// file: new/kernel/gdt.c
#include <proc.h>

struct tss {
    uint32_t reserved0;
    uint64_t rsp0, rsp1, rsp2;     /* stack for interrupts arriving from ring 3 (rsp0) */
    uint64_t reserved1;
    uint64_t ist[7];
    uint64_t reserved2;
    uint16_t reserved3, iomap_base;
} __attribute__((packed));
_Static_assert(sizeof(struct tss) == 104, "64-bit TSS");

static struct tss tss;
static uint64_t gdt[7];

void gdt_init(void) {
    gdt[0] = 0;
    gdt[1] = 0x00209A0000000000;   /* 0x08 kernel code: present, DPL 0, code, long mode (L bit 53) */
    gdt[2] = 0x0000920000000000;   /* 0x10 kernel data: present, DPL 0, writable */
    gdt[3] = 0x0000F20000000000;   /* 0x18 user data:   present, DPL 3, writable */
    gdt[4] = 0x0020FA0000000000;   /* 0x20 user code:   present, DPL 3, code, long mode */
    uint64_t base = (uint64_t)&tss, limit = sizeof tss - 1;
    gdt[5] = (limit & 0xFFFF) | ((base & 0xFFFFFF) << 16) | (0x89UL << 40)   /* 0x28: available 64-bit TSS */
           | (((limit >> 16) & 0xF) << 48) | (((base >> 24) & 0xFF) << 56);
    gdt[6] = base >> 32;           /* a system descriptor takes two slots in long mode */
    tss.iomap_base = sizeof tss;   /* no I/O permission bitmap: ring 3 may not use in/out at all */
    struct __attribute__((packed)) { uint16_t limit; uint64_t base; } gdtr = { sizeof gdt - 1, (uint64_t)gdt };
    __asm__ volatile("lgdt %0\n\t"
                     "pushq $0x08\n\t"            /* reload CS with a far return */
                     "leaq 1f(%%rip), %%rax\n\t"
                     "pushq %%rax\n\t"
                     "lretq\n"
                     "1:\n\t"
                     "mov $0x10, %%ax\n\t"
                     "mov %%ax, %%ds\n\t"
                     "mov %%ax, %%es\n\t"
                     "mov %%ax, %%ss\n\t"
                     "mov $0x28, %%ax\n\t"
                     "ltr %%ax"                    /* load the task register */
                     : : "m"(gdtr) : "rax", "memory");
}

void tss_set_rsp0(uint64_t rsp0) { tss.rsp0 = rsp0; }
