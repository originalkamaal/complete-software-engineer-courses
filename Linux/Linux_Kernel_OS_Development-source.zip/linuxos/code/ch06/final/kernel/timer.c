// file: new/kernel/timer.c
#include <proc.h>

volatile uint64_t ticks;
unsigned timer_hz;

static void timer_irq(struct trap_frame *f) {
    (void)f;
    ticks++;
    sched_tick();
#ifdef SWITCH_BEFORE_EOI                    /* experiment switch for DT-10: switch inside the handler */
    if (need_resched) schedule();
#endif
}

void timer_init(unsigned hz) {
    unsigned divisor = 1193182 / hz;
    timer_hz = hz;
    outb(0x43, 0x36);
    outb(0x40, (uint8_t)divisor);
    outb(0x40, (uint8_t)(divisor >> 8));
    irq_register(0, timer_irq);
    pic_unmask(0);
}

uint8_t rtc_read(uint8_t reg) {
    while (outb(0x70, 0x0A), inb(0x71) & 0x80) { }
    outb(0x70, reg);
    return inb(0x71);
}
