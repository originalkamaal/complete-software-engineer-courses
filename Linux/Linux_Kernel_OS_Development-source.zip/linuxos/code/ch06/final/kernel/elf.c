// file: new/kernel/elf.c
#include <proc_extra.h>

struct elf64_ehdr {
    uint8_t ident[16];
    uint16_t type, machine;
    uint32_t version;
    uint64_t entry, phoff, shoff;
    uint32_t flags;
    uint16_t ehsize, phentsize, phnum, shentsize, shnum, shstrndx;
};
struct elf64_phdr {
    uint32_t type, flags;
    uint64_t offset, vaddr, paddr, filesz, memsz, align;
};
_Static_assert(sizeof(struct elf64_ehdr) == 64 && sizeof(struct elf64_phdr) == 56, "ELF64 layouts");
#define PT_LOAD 1

static uint64_t frame_of(uint64_t *pml4, uint64_t virt) {        /* map a zeroed page if needed; return its frame */
    uint64_t phys;
    if (vmm_translate_in(pml4, virt, &phys)) return phys;
    uint64_t frame = pmm_alloc();
    if (!frame) return 0;
    memset((void *)frame, 0, PAGE_SIZE);
    if (!vmm_map_in(pml4, virt, frame, PTE_WRITABLE | PTE_USER)) { pmm_free(frame); return 0; }
    return frame;
}

long elf_load(uint64_t *pml4, uint32_t ino, uint64_t *entry) {
    struct elf64_ehdr eh;
    if (fs_read(ino, 0, &eh, sizeof eh) != sizeof eh) return -ENOEXEC;
    if (memcmp(eh.ident, "\x7f" "ELF", 4) || eh.ident[4] != 2 || eh.ident[5] != 1 ||   /* 64-bit, little-endian */
        eh.type != 2 || eh.machine != 62 || eh.phentsize != sizeof(struct elf64_phdr) || eh.phnum > 16)
        return -ENOEXEC;
    bool entry_ok = false;
    for (int i = 0; i < eh.phnum; i++) {
        struct elf64_phdr ph;
        if (fs_read(ino, eh.phoff + (uint64_t)i * sizeof ph, &ph, sizeof ph) != sizeof ph) return -ENOEXEC;
        if (ph.type != PT_LOAD) continue;
#ifndef TRUST_ELF                                      /* experiment switch for DT-14 */
        if (ph.filesz > ph.memsz || ph.vaddr < USER_CODE_MIN || ph.memsz > 64 * 1024 * 1024 ||
            ph.vaddr + ph.memsz > USER_ARGS - USER_STACK_PAGES * PAGE_SIZE || ph.vaddr + ph.memsz < ph.vaddr)
            return -ENOEXEC;
#endif
        for (uint64_t va = ALIGN_DOWN(ph.vaddr, PAGE_SIZE); va < ph.vaddr + ph.memsz; va += PAGE_SIZE) {
            uint64_t frame = frame_of(pml4, va);
            if (!frame) return -ENOMEM;
            /* the part of [vaddr, vaddr + filesz) that falls in this page comes from the file */
            uint64_t lo = va > ph.vaddr ? va : ph.vaddr;
            uint64_t hi = va + PAGE_SIZE < ph.vaddr + ph.filesz ? va + PAGE_SIZE : ph.vaddr + ph.filesz;
            if (lo < hi && fs_read(ino, ph.offset + (lo - ph.vaddr), (void *)(frame + (lo - va)), hi - lo) != (long)(hi - lo))
                return -ENOEXEC;                       /* the rest of the page stays zero: .bss */
        }
        if (eh.entry >= ph.vaddr && eh.entry < ph.vaddr + ph.memsz) entry_ok = true;
    }
#ifndef TRUST_ELF
    if (!entry_ok) return -ENOEXEC;
#else
    (void)entry_ok;
#endif
    *entry = eh.entry;
    return 0;
}
