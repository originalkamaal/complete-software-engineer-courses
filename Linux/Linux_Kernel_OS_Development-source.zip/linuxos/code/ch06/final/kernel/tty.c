// file: new/kernel/tty.c
#include <proc.h>

long console_read_line(char *buf, uint64_t n) {
    uint64_t len = 0;
    while (len + 1 < n) {
        int c = serial_getc();
        if (c == '\r') c = '\n';
        if (c == 0x7F || c == '\b') { if (len) { len--; kprintf("\b \b"); } continue; }
        if (c == 0x04 && len == 0) return 0;              /* Ctrl-D on an empty line: end of input */
        if (c != '\n' && (c < 0x20 || c >= 0x7F)) continue;
        buf[len++] = (char)c;
        kprintf("%c", c);
        if (c == '\n') break;
    }
    return (long)len;
}
