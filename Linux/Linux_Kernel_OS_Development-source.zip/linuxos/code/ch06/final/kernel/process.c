// file: new/kernel/process.c
#include <proc_extra.h>

extern void enter_user(uint64_t rip, uint64_t rsp);

static void user_start(void *entry) {
    enter_user((uint64_t)entry, USER_ARGS);    /* the stack starts just below the argument string */
}

struct task *process_spawn(const char *path, const char *args, long *err) {
    int ino = fs_lookup(path);
    if (ino < 0) { *err = ino; return NULL; }
    uint64_t *pml4 = vmm_new_space();
    if (!pml4) { *err = -ENOMEM; return NULL; }
    uint64_t entry;
    long r = elf_load(pml4, (uint32_t)ino, &entry);
    uint64_t top = 0;
    for (int i = 1; r == 0 && i <= USER_STACK_PAGES; i++) {
        uint64_t frame = pmm_alloc();
        if (!frame) { r = -ENOMEM; break; }
        memset((void *)frame, 0, PAGE_SIZE);
        vmm_map_in(pml4, USER_STACK_TOP - (uint64_t)i * PAGE_SIZE, frame, PTE_WRITABLE | PTE_USER);
        if (i == 1) top = frame;
    }
    if (r < 0) { vmm_destroy_space(pml4); *err = r; return NULL; }
    size_t n = 0;                                        /* copy the arguments into the top stack page */
    for (; args && args[n] && n < 255; n++) ((char *)top)[PAGE_SIZE - 256 + n] = args[n];
    const char *base = path;
    for (const char *p = path; *p; p++) if (*p == '/') base = p + 1;
    struct task *t = task_create(base, user_start, (void *)entry, pml4, true);   /* everything set before it can run */
    t->entry = entry;                                   /* for information only (ps, debugging) */
    return t;
}
