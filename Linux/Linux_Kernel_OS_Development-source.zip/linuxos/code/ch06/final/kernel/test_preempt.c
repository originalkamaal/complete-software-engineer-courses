// file: new/kernel/test_preempt.c
#include <proc.h>

static volatile uint64_t counts[2];
static volatile bool stop;

static void spinner(void *arg) {                 /* never yields */
    int i = (int)(uintptr_t)arg;
    while (!stop) counts[i]++;
}

KTEST(preempt) {
    struct task *a = kthread_create("spin0", spinner, (void *)0);
    struct task *b = kthread_create("spin1", spinner, (void *)1);
    sleep_ticks(100);                            /* one second; the spinners share the CPU meanwhile */
    stop = true;
    task_join(a);
    task_join(b);
    kprintf("spin0: %lu iterations, %lu ticks of CPU, switched in %lu times\n", counts[0], a->runtime_ticks, a->switches);
    kprintf("spin1: %lu iterations, %lu ticks of CPU, switched in %lu times\n", counts[1], b->runtime_ticks, b->switches);
    KASSERT(a->runtime_ticks >= 40 && b->runtime_ticks >= 40);
}
