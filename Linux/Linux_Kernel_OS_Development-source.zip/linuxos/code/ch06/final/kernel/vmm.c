// file: new/kernel/vmm.c
#include <mm.h>

extern uint64_t boot_pml4[512];
uint64_t *kernel_pml4 = boot_pml4;
uint64_t lazy_faults;

static unsigned idx(uint64_t virt, int level) { return (virt >> (12 + 9 * level)) & 511; }

static uint64_t *next_table(uint64_t *table, unsigned i, bool create, uint64_t user) {
    if (!(table[i] & PTE_PRESENT)) {
        if (!create) return NULL;
        uint64_t frame = pmm_alloc();
        if (!frame) return NULL;
        memset((void *)frame, 0, PAGE_SIZE);
        table[i] = frame | PTE_PRESENT | PTE_WRITABLE;
    }
#ifndef NO_USER_INTERMEDIATE                  /* experiment switch for DT-11 */
    table[i] |= user;                          /* a user page needs the U bit at every level */
#else
    (void)user;
#endif
    if (table[i] & PTE_HUGE) return NULL;
    return (uint64_t *)(table[i] & PTE_ADDR);
}

static uint64_t *pte_in(uint64_t *pml4, uint64_t virt, bool create, uint64_t user) {
    uint64_t *t = pml4;
    for (int level = 3; level > 0; level--)
        if (!(t = next_table(t, idx(virt, level), create, user))) return NULL;
    return &t[idx(virt, 0)];
}

uint64_t *vmm_pte(uint64_t virt, bool create) { return pte_in(kernel_pml4, virt, create, 0); }

bool vmm_map_in(uint64_t *pml4, uint64_t virt, uint64_t phys, uint64_t flags) {
    KASSERT(virt % PAGE_SIZE == 0 && phys % PAGE_SIZE == 0);
    KASSERT(!(flags & PTE_USER) || virt < USER_TOP);
    uint64_t *pte = pte_in(pml4, virt, true, flags & PTE_USER);
    if (!pte) return false;
    if (*pte & PTE_PRESENT) panic("vmm_map: 0x%lx is already mapped", virt);
    *pte = phys | flags | PTE_PRESENT;
    return true;
}

bool vmm_map(uint64_t virt, uint64_t phys, uint64_t flags) { return vmm_map_in(kernel_pml4, virt, phys, flags); }

uint64_t vmm_unmap(uint64_t virt) {
    uint64_t *pte = vmm_pte(virt, false);
    if (!pte || !(*pte & PTE_PRESENT)) return 0;
    uint64_t phys = *pte & PTE_ADDR;
    *pte = 0;
    invlpg(virt);
    return phys;
}

/* Walk; succeed only if every level is present (and, if required, user-accessible / writable). */
static bool walk(uint64_t *pml4, uint64_t virt, uint64_t need, uint64_t *phys) {
    uint64_t *t = pml4;
    for (int level = 3; level >= 0; level--) {
        uint64_t e = t[idx(virt, level)];
        if ((e & (PTE_PRESENT | need)) != (PTE_PRESENT | need)) return false;
        if (level == 0 || (e & PTE_HUGE)) {
            uint64_t page = 1UL << (12 + 9 * level);
            if (phys) *phys = (e & PTE_ADDR & ~(page - 1)) | (virt & (page - 1));
            return true;
        }
        t = (uint64_t *)(e & PTE_ADDR);
    }
    return false;
}

bool vmm_translate(uint64_t virt, uint64_t *phys) { return walk(kernel_pml4, virt, 0, phys); }

bool user_range_ok(uint64_t *pml4, uint64_t addr, uint64_t len, bool write) {
    if (len == 0) return true;
    if (addr + len < addr || addr + len > USER_TOP) return false;          /* wraps, or reaches the kernel half */
    for (uint64_t p = ALIGN_DOWN(addr, PAGE_SIZE); p < addr + len; p += PAGE_SIZE)
        if (!walk(pml4, p, PTE_USER | (write ? PTE_WRITABLE : 0), NULL)) return false;
    return true;
}

void vmm_walk(uint64_t virt) {
    static const char *const names[] = {"PT", "PD", "PDPT", "PML4"};
    kprintf("walk of %p:\n", (void *)virt);
    uint64_t *t = kernel_pml4;
    for (int level = 3; level >= 0; level--) {
        unsigned i = idx(virt, level);
        uint64_t e = t[i];
        kprintf("  %-4s[%3u] = %016lx  %s%s%s%s\n", names[level], i, e, e & PTE_PRESENT ? "P" : "-",
                e & PTE_WRITABLE ? "W" : "-", e & PTE_USER ? "U" : "-", e & PTE_HUGE ? " huge" : "");
        if (!(e & PTE_PRESENT)) { kprintf("  -> not mapped\n"); return; }
        if (level == 0 || (e & PTE_HUGE)) break;
        t = (uint64_t *)(e & PTE_ADDR);
    }
    uint64_t phys;
    vmm_translate(virt, &phys);
    kprintf("  -> physical %p\n", (void *)phys);
}

bool vmm_handle_fault(struct trap_frame *f) {
    uint64_t addr = read_cr2();
    if (addr < LAZY_START || addr >= LAZY_END || (f->error & 1)) return false;
    uint64_t frame = pmm_alloc();
    if (!frame) return false;
    memset((void *)frame, 0, PAGE_SIZE);
    vmm_map(ALIGN_DOWN(addr, PAGE_SIZE), frame, PTE_WRITABLE);
    lazy_faults++;
    return true;
}

uint64_t *vmm_new_space(void) {
    uint64_t *pml4 = (uint64_t *)pmm_alloc(), *pdpt = (uint64_t *)pmm_alloc();
    if (!pml4 || !pdpt) return NULL;
    memset(pml4, 0, PAGE_SIZE);
    memset(pdpt, 0, PAGE_SIZE);
    uint64_t *kernel_pdpt = (uint64_t *)(kernel_pml4[0] & PTE_ADDR);
    pdpt[0] = kernel_pdpt[0];                          /* share the first GiB identity map (no U bit) */
    pml4[0] = (uint64_t)pdpt | PTE_PRESENT | PTE_WRITABLE;
    for (int i = 256; i < 512; i++) pml4[i] = kernel_pml4[i];   /* share the kernel half */
    return pml4;
}

static void free_table(uint64_t *t, int level) {        /* level 2 = PDPT, 1 = PD, 0 = PT */
    for (int i = 0; i < 512; i++) {
        if (!(t[i] & PTE_PRESENT)) continue;
        if (level == 0) pmm_free(t[i] & PTE_ADDR);
        else free_table((uint64_t *)(t[i] & PTE_ADDR), level - 1);
    }
    pmm_free((uint64_t)t);
}

void vmm_destroy_space(uint64_t *pml4) {
    ((uint64_t *)(pml4[0] & PTE_ADDR))[0] = 0;          /* detach the shared identity map before freeing */
    for (int i = 0; i < 256; i++)
        if (pml4[i] & PTE_PRESENT) free_table((uint64_t *)(pml4[i] & PTE_ADDR), 2);
    pmm_free((uint64_t)pml4);
}

void vmm_init(void) {
    uint64_t cr3;
    __asm__ volatile("mov %%cr3, %0" : "=r"(cr3));
    KASSERT((cr3 & PTE_ADDR) == (uint64_t)kernel_pml4);
    for (int i = 256; i < 512; i++) {                   /* pre-create the kernel half's PDPTs (1 MiB) */
        uint64_t frame = pmm_alloc();
        memset((void *)frame, 0, PAGE_SIZE);
        kernel_pml4[i] = frame | PTE_PRESENT | PTE_WRITABLE;
    }
}
