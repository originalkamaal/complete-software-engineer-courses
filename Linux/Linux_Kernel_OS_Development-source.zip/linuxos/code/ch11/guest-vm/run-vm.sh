# file: guest-vm/run-vm.sh
/bin/vm
