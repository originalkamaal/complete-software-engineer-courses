# file: guest-ptop/run-ptop.sh
spin() { while :; do :; done; }
spin & spin & sh -c 'renice -n 10 -p $$ > /dev/null; while :; do :; done' &
sleep 1000 & /bin/toucher &
sleep 2
/bin/ptop
