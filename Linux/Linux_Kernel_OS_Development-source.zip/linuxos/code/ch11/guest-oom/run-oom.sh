# file: guest-oom/run-oom.sh
/bin/oom | tail -4
dmesg | grep -E "invoked oom-killer|Out of memory: Killed" | sed 's/^\[[ 0-9.]*\] //' | cut -c1-100
