// file: lab/proc.h
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>

/* The value of "Key:" in a /proc file such as /proc/self/status or /proc/meminfo (first number, usually kB). */
static inline long proc_value(const char *file, const char *key) {
    FILE *f = fopen(file, "r");
    char line[256];
    long v = -1;
    size_t n = strlen(key);
    while (f && fgets(line, sizeof line, f))
        if (strncmp(line, key, n) == 0 && line[n] == ':') { v = atol(line + n + 1); break; }
    if (f) fclose(f);
    return v;
}

static inline long minor_faults(void) { struct rusage r; getrusage(RUSAGE_SELF, &r); return r.ru_minflt; }
