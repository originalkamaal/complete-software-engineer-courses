// file: lab/oom.c
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#include "proc.h"

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);                   /* parent and child share the output: no buffering */
    printf("MemTotal %ld kB, MemAvailable %ld kB, overcommit_memory=%ld\n", proc_value("/proc/meminfo", "MemTotal"),
           proc_value("/proc/meminfo", "MemAvailable"), (long)(fgetc(fopen("/proc/sys/vm/overcommit_memory", "r")) - '0'));
    char *huge = malloc(64L << 30);
    printf("malloc(64 GiB) on a 512 MiB machine: %s\n", huge ? "succeeded" : "NULL (refused by the heuristic)");
    pid_t pid = fork();
    if (pid == 0) {
        long got = 0;
        for (;;) {                                 /* allocate and touch 32 MiB at a time */
            char *p = malloc(32 << 20);
            if (!p) { printf("child: malloc returned NULL after %ld MiB\n", got); _exit(1); }
            memset(p, 1, 32 << 20);
            got += 32;
            printf("child: %ld MiB allocated and touched\n", got);
        }
    }
    int status;
    waitpid(pid, &status, 0);
    if (WIFSIGNALED(status)) printf("parent: child was killed by signal %d (%s)\n", WTERMSIG(status), strsignal(WTERMSIG(status)));
    return 0;
}
