// file: lab/ptop.c
#include <ctype.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>
#include "proc.h"

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }

struct sample { int pid; char comm[20], state; unsigned long utime, stime, minflt, majflt; long rss_pages; };

static int read_stat(int pid, struct sample *s) {
    char path[64], buf[1024];
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = 0;
    char *open = strchr(buf, '('), *close = strrchr(buf, ')');   /* comm may contain spaces and ')' */
    if (!open || !close) return -1;
    s->pid = pid;
    snprintf(s->comm, sizeof s->comm, "%.*s", (int)(close - open - 1), open + 1);
    /* fields after comm: 3 state ... 10 minflt 12 majflt 14 utime 15 stime ... 24 rss */
    unsigned long v[30] = {0};
    char *p = close + 2;
    s->state = *p;
    for (int i = 4; i <= 24 && p; i++) { p = strchr(p, ' '); if (p) v[i] = strtoul(++p, NULL, 10); }
    s->minflt = v[10]; s->majflt = v[12]; s->utime = v[14]; s->stime = v[15]; s->rss_pages = (long)v[24];
    return 0;
}

static int snapshot(struct sample *out, int max) {
    DIR *d = opendir("/proc");
    struct dirent *e;
    int n = 0;
    while ((e = readdir(d)) && n < max)
        if (isdigit((unsigned char)e->d_name[0]) && read_stat(atoi(e->d_name), &out[n]) == 0) n++;
    closedir(d);
    return n;
}

int main(void) {
    static struct sample a[512], b[512];
    long hz = sysconf(_SC_CLK_TCK);
    double t0 = now();
    int na = snapshot(a, 512);
    sleep(1);
    double elapsed = now() - t0;                          /* sleep(1) plus the time to read /proc: measure it */
    int nb = snapshot(b, 512);
    struct row { struct sample *s; double cpu; long minf; } rows[512];
    int nr = 0;
    for (int i = 0; i < nb; i++)
        for (int j = 0; j < na; j++)
            if (a[j].pid == b[i].pid) {
                rows[nr].s = &b[i];
                rows[nr].cpu = 100.0 * (double)(b[i].utime + b[i].stime - a[j].utime - a[j].stime) / (double)hz / elapsed;
                rows[nr].minf = (long)((double)(b[i].minflt - a[j].minflt) / elapsed);
                nr++;
            }
    for (int i = 0; i < nr; i++)                          /* sort by CPU, descending */
        for (int j = i + 1; j < nr; j++)
            if (rows[j].cpu > rows[i].cpu) { struct row t = rows[i]; rows[i] = rows[j]; rows[j] = t; }
    printf("  PID COMMAND          S   CPU%%   RSS(kB)  minflt/s  ctxsw vol/invol\n");
    for (int i = 0; i < nr && i < 10; i++) {
        struct sample *s = rows[i].s;
        char path[64];
        snprintf(path, sizeof path, "/proc/%d/status", s->pid);
        printf("%5d %-16s %c %6.1f %9ld %9ld  %6ld/%ld\n", s->pid, s->comm, s->state, rows[i].cpu, s->rss_pages * 4,
               rows[i].minf, proc_value(path, "voluntary_ctxt_switches"), proc_value(path, "nonvoluntary_ctxt_switches"));
    }
    return 0;
}
