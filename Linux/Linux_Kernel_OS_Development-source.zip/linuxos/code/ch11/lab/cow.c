// file: lab/cow.c
/* Copy-on-write, measured in page faults. */
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include "proc.h"

#define SIZE (64L << 20)                 /* 64 MiB = 16384 pages of 4 KiB */

int main(void) {
    char *p = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    long f0 = minor_faults();
    memset(p, 1, SIZE);
    printf("parent: first touch of 64 MiB:   %6ld faults (demand paging: one per page)\n", minor_faults() - f0);

    pid_t pid = fork();
    if (pid == 0) {
        long f = minor_faults();         /* fork() resets the child's counters to 0 */
        volatile long sum = 0;
        for (long i = 0; i < SIZE; i += 4096) sum += p[i];
        printf("child:  read every page:         %6ld faults (pages are shared)\n", minor_faults() - f);
        f = minor_faults();
        for (long i = 0; i < SIZE; i += 4096) p[i] = 2;
        printf("child:  write every page:        %6ld faults (copy-on-write: one copy per page)\n", minor_faults() - f);
        printf("child:  VmRSS %ld kB\n", proc_value("/proc/self/status", "VmRSS"));
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    f0 = minor_faults();
    for (long i = 0; i < SIZE; i += 4096) p[i] = 3;
    printf("parent: write after child exited: %5ld faults (still write-protected since fork)\n", minor_faults() - f0);
    printf("parent: p[0] = %d (the child's writes went to its own copies)\n", p[0]);
    return 0;
}
