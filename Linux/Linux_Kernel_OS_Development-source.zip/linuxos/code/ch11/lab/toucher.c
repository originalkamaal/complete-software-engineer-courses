// file: lab/toucher.c
/* Keep touching new memory, then give it back: a steady stream of page faults. */
#include <sys/mman.h>
#include <unistd.h>

int main(void) {
    for (;;) {
        char *p = mmap(NULL, 8 << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        for (long i = 0; i < (8 << 20); i += 4096) p[i] = 1;
        munmap(p, 8 << 20);
        usleep(10000);
    }
}
