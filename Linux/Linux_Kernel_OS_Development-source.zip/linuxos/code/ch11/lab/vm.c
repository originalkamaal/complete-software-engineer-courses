// file: lab/vm.c
#include <errno.h>
#include <sys/mman.h>
#include "proc.h"

static void show(const char *when) {
    printf("%-30s VmSize %7ld kB  VmRSS %6ld kB  Rss %6ld kB  faults %6ld\n", when,
           proc_value("/proc/self/status", "VmSize"), proc_value("/proc/self/status", "VmRSS"),
           proc_value("/proc/self/smaps_rollup", "Rss"), minor_faults());
}

int main(void) {
    FILE *f = fopen("/proc/self/maps", "r");
    char line[256];
    while (fgets(line, sizeof line, f)) {               /* the address space of a static program */
        char range[64], perms[8], path[128] = "";
        sscanf(line, "%63s %7s %*s %*s %*s %127s", range, perms, path);
        printf("  %-34s %s  %s\n", range, perms, path);
    }
    fclose(f);
    show("start");
    char *p = mmap(NULL, 256 << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    show("after mmap(256 MiB)");
    for (long i = 0; i < (64 << 20); i += 4096) p[i] = 1;
    show("after touching 64 MiB of it");
    int r = madvise(p, 32 << 20, MADV_DONTNEED);          /* try to give 32 MiB back to the kernel */
    printf("madvise(MADV_DONTNEED) returned %d (%s)\n", r, r ? strerror(errno) : "ok");
    munmap(p, 32 << 20);                                  /* unmap the first 32 MiB instead */
    show("after munmap of 32 MiB");
    munmap(p + (32 << 20), 224 << 20);
    show("after munmap of the rest");
    return 0;
}
