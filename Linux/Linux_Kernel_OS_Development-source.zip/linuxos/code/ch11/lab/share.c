// file: lab/share.c
/* share NICE_B [fifo]: two CPU-bound tasks on CPU 0 for 3 s. Task A has nice 0; task B has NICE_B (or SCHED_FIFO). */
#define _GNU_SOURCE
#include <sched.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#include "proc.h"

static pid_t spawn(int nice_value, int fifo) {
    pid_t pid = fork();
    if (pid == 0) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(0, &set);
        sched_setaffinity(0, sizeof set, &set);           /* both on CPU 0: they must share it */
        if (fifo) { struct sched_param sp = { .sched_priority = 10 }; sched_setscheduler(0, SCHED_FIFO, &sp); }
        else if (nice(nice_value) == -1) _exit(1);
        for (volatile unsigned long n = 0;; n++) { }
    }
    return pid;
}

static double cpu_seconds(pid_t pid) {                   /* utime + stime from /proc/PID/stat, in clock ticks */
    char path[64], buf[1024];
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = 0;
    char *p = strrchr(buf, ')');                           /* fields after "(comm)": state is field 3 */
    unsigned long utime = 0, stime = 0;
    if (p) sscanf(p + 2, "%*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu", &utime, &stime);
    return (double)(utime + stime) / (double)sysconf(_SC_CLK_TCK);
}

static long ctxt(pid_t pid, const char *key) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/status", pid);
    return proc_value(path, key);
}

int main(int argc, char **argv) {
    int nice_b = atoi(argv[1]), fifo = argc > 2;
    pid_t a = spawn(0, 0), b = spawn(nice_b, fifo);
    sleep(3);
    double ca = cpu_seconds(a), cb = cpu_seconds(b);
    char label[16];
    if (fifo) snprintf(label, sizeof label, "SCHED_FIFO");
    else snprintf(label, sizeof label, "nice %d", nice_b);
    printf("A nice 0: %5.2f s CPU (%4.1f%%) | B %-10s: %5.2f s CPU (%4.1f%%) | preempted: A %ld times, B %ld times\n",
           ca, 100 * ca / (ca + cb), label, cb, 100 * cb / (ca + cb),
           ctxt(a, "nonvoluntary_ctxt_switches"), ctxt(b, "nonvoluntary_ctxt_switches"));
    kill(a, SIGKILL);
    kill(b, SIGKILL);
    while (wait(NULL) > 0) { }
    return 0;
}
