// file: lab/threads.c
/* Threads share one address space: same maps, one VmRSS, different TIDs. */
#define _GNU_SOURCE
#include <pthread.h>
#include <sys/wait.h>
#include <unistd.h>
#include "proc.h"

static int shared = 0;

static void *worker(void *arg) {
    shared += 1;
    printf("thread: pid %d tid %d, sees shared=%d at %p; Threads: %ld\n", getpid(), gettid(), shared, (void *)&shared,
           proc_value("/proc/self/status", "Threads"));
    return arg;
}

int main(void) {
    pthread_t t;
    printf("main:   pid %d tid %d, shared at %p\n", getpid(), gettid(), (void *)&shared);
    pthread_create(&t, NULL, worker, NULL);
    pthread_join(t, NULL);
    printf("main:   shared=%d after the thread ran; Threads: %ld after it exited\n", shared,
           proc_value("/proc/self/status", "Threads"));
    pid_t pid = fork();
    if (pid == 0) { shared += 100; _exit(0); }
    waitpid(pid, NULL, 0);
    printf("main:   shared=%d after a forked child added 100 to its copy\n", shared);
    return 0;
}
