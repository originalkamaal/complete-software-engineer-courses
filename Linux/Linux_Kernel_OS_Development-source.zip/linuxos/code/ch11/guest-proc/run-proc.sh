# file: guest-proc/run-proc.sh
/bin/cow
/bin/threads
