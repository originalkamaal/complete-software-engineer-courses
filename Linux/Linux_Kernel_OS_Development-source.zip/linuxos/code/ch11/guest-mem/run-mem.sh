# file: guest-mem/run-mem.sh
echo "== /proc/buddyinfo (free blocks per order 0..10) =="
cat /proc/buddyinfo
echo "== largest slab caches by memory =="
awk 'NR > 2 { printf "%6d kB  %-24s %7d objects x %5d bytes\n", $3 * $4 / 1024, $1, $3, $4 }' /proc/slabinfo | sort -n -r | head -8
echo "== task_struct =="
grep "^task_struct" /proc/slabinfo | awk '{ print "  " $3 " task_structs of " $4 " bytes each (" $5 " per slab)" }'
echo "== /proc/meminfo (selected) =="
grep -E "^(MemTotal|MemFree|MemAvailable|Cached|AnonPages|Slab|SReclaimable|KernelStack|PageTables|Committed_AS)" /proc/meminfo
for i in 1 2 3 4 5 6 7 8; do sleep 30 & done
echo "== after starting 8 processes =="
grep "^task_struct" /proc/slabinfo | awk '{ print "  " $3 " task_structs" }'
grep KernelStack /proc/meminfo
