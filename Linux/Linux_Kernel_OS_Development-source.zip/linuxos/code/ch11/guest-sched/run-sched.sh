# file: guest-sched/run-sched.sh
for n in 0 1 5 10 19; do /bin/share $n; done
/bin/share 0 fifo
echo "sched_rt_runtime_us=$(cat /proc/sys/kernel/sched_rt_runtime_us) sched_rt_period_us=$(cat /proc/sys/kernel/sched_rt_period_us)"
