; file: new/arch/tramp_blob.asm
section .rodata
global tramp_start, tramp_end
tramp_start:
    incbin "arch/trampoline.bin"
tramp_end:
