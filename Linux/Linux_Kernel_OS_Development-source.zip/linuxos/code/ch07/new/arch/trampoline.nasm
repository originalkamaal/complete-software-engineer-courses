; file: new/arch/trampoline.nasm
; AP startup code. Assembled as a flat binary, copied to physical 0x8000; SIPI vector 0x08 starts it at 0x0800:0000.
bits 16
org 0x8000
start:
    jmp short real_start
align 8
tramp_cr3:   dq 0                 ; 0x8008: filled in by the BSP
tramp_stack: dq 0                 ; 0x8010
tramp_entry: dq 0                 ; 0x8018
real_start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    lgdt [gdt_ptr]
    mov eax, cr0
    or eax, 1                     ; protected mode
    mov cr0, eax
    jmp 0x08:start32

bits 32
start32:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov eax, cr4
    or eax, 1 << 5                ; PAE
    mov cr4, eax
    mov eax, [tramp_cr3]          ; the kernel's PML4 (below 4 GiB)
    mov cr3, eax
    mov ecx, 0xC0000080           ; EFER.LME
    rdmsr
    or eax, 1 << 8
    wrmsr
    mov eax, cr0
    or eax, 1 << 31               ; paging on: long mode
    mov cr0, eax
    jmp 0x18:start64

bits 64
start64:
    mov rsp, [tramp_stack]
    mov rax, [tramp_entry]
    call rax                      ; ap_main: never returns

align 8
gdt:
    dq 0
    dq 0x00CF9A000000FFFF         ; 0x08: 32-bit code, flat
    dq 0x00CF92000000FFFF         ; 0x10: 32-bit data, flat
    dq 0x00209A0000000000         ; 0x18: 64-bit code
gdt_ptr:
    dw $ - gdt - 1
    dd gdt
