// file: new/kernel/spinlock.c
#include <smp.h>

__attribute__((noinline)) void spin_lock(spinlock_t *l) {
    uint32_t me = (uint32_t)cpu_id() + 1;
    if (l->owner == me)                                          /* spinlocks are not recursive: certain deadlock */
        panic("spinlock '%s': deadlock - already held by this CPU (taken at %p, wanted again at %p)", l->name,
              l->taken_at, __builtin_return_address(0));
    if (__atomic_exchange_n(&l->locked, 1, __ATOMIC_ACQUIRE)) {
        __atomic_fetch_add(&l->contended, 1, __ATOMIC_RELAXED);
        do {
            while (__atomic_load_n(&l->locked, __ATOMIC_RELAXED)) cpu_relax();   /* spin on a read: no cache-line ping-pong */
        } while (__atomic_exchange_n(&l->locked, 1, __ATOMIC_ACQUIRE));
    }
    l->owner = me;
    l->taken_at = __builtin_return_address(0);
}

void spin_unlock(spinlock_t *l) {
    l->owner = 0;
    __atomic_store_n(&l->locked, 0, __ATOMIC_RELEASE);          /* on x86: a plain mov */
}

uint64_t spin_lock_irqsave(spinlock_t *l) {
    uint64_t f = irq_save();                                     /* interrupts off FIRST, then the lock */
    spin_lock(l);
    return f;
}

void spin_unlock_irqrestore(spinlock_t *l, uint64_t f) {
    spin_unlock(l);
    irq_restore(f);
}

/* Ticket lock: take a number, wait until it is served. First come, first served. */
void ticket_lock(ticketlock_t *l) {
    uint32_t mine = __atomic_fetch_add(&l->next, 1, __ATOMIC_RELAXED);
    while (__atomic_load_n(&l->serving, __ATOMIC_ACQUIRE) != mine) cpu_relax();
}

void ticket_unlock(ticketlock_t *l) {
    __atomic_store_n(&l->serving, l->serving + 1, __ATOMIC_RELEASE);
}
