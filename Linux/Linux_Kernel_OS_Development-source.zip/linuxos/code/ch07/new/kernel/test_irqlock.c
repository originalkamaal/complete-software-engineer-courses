// file: new/kernel/test_irqlock.c
#include <smp.h>

static spinlock_t stats_lock = SPINLOCK_INIT("stats");
static volatile uint64_t rtc_events, thread_updates;

static void rtc_irq(struct trap_frame *f) {
    (void)f;
    spin_lock(&stats_lock);                   /* interrupt context: interrupts are already off */
    rtc_events++;
    spin_unlock(&stats_lock);
    outb(0x70, 0x0C);                         /* read RTC register C: acknowledges the interrupt */
    (void)inb(0x71);
}

static void rtc_periodic(bool on) {
    outb(0x70, 0x8B);
    uint8_t b = inb(0x71);
    outb(0x70, 0x8B);
    outb(0x71, on ? (b | 0x40) : (b & ~0x40));   /* register B bit 6: periodic interrupt enable */
    outb(0x70, 0x0C);
    (void)inb(0x71);
}

KTEST(irqlock) {
    irq_register(8, rtc_irq);
    rtc_periodic(true);
    pic_unmask(8);
    for (int round = 0; round < 50; round++) {
#ifdef IRQLOCK_BUG                            /* experiment switch for DT-17 */
        spin_lock(&stats_lock);
#else
        uint64_t f = spin_lock_irqsave(&stats_lock);
#endif
        for (volatile int i = 0; i < 200000; i++) { }   /* a slow critical section */
        thread_updates++;
#ifdef IRQLOCK_BUG
        spin_unlock(&stats_lock);
#else
        spin_unlock_irqrestore(&stats_lock, f);
#endif
        sleep_ticks(1);
    }
    rtc_periodic(false);
    kprintf("50 critical sections in the thread, %lu RTC interrupts took the same lock\n", rtc_events);
    KASSERT(thread_updates == 50 && rtc_events > 0);
}
