// file: new/kernel/test_smp.c
#include <smp.h>

#define N 1000000
static volatile uint64_t plain;
static uint64_t atomic_counter, locked_counter;
static spinlock_t counter_lock = SPINLOCK_INIT("counter");

static void hello(int index) {
    int local;
    smp_printf("  AP %d: LAPIC id %d, stack near %p\n", index, cpu_id(), (void *)&local);
}
static void inc_plain(int index)  { (void)index; for (int i = 0; i < N; i++) plain++; }
static void inc_atomic(int index) { (void)index; for (int i = 0; i < N; i++) __atomic_fetch_add(&atomic_counter, 1, __ATOMIC_RELAXED); }
static void inc_locked(int index) {
    (void)index;
    for (int i = 0; i < N; i++) { spin_lock(&counter_lock); locked_counter++; spin_unlock(&counter_lock); }
}

static void phase(const char *name, void (*fn)(int), volatile uint64_t *counter) {
    uint64_t t0 = ticks;
    smp_run(fn);
    uint64_t expected = (uint64_t)(ncpus - 1) * N;
    kprintf("  %-9s %8lu of %8lu (%3lu%% lost) in %3lu ticks\n", name, *counter, expected,
            (expected - *counter) * 100 / expected, ticks - t0);
}

KTEST(smp) {
    int n = smp_init();
    kprintf("%d CPUs online\n", n);
    KASSERT(n > 1);
    smp_run(hello);
    kprintf("%d APs each increment a shared counter %d times:\n", n - 1, N);
    phase("volatile", inc_plain, &plain);
    phase("atomic", inc_atomic, (volatile uint64_t *)&atomic_counter);
    phase("spinlock", inc_locked, (volatile uint64_t *)&locked_counter);
    kprintf("  the spinlock was contended in %lu of %lu acquisitions\n", counter_lock.contended,
            (uint64_t)(n - 1) * N);
    KASSERT(atomic_counter == (uint64_t)(n - 1) * N && locked_counter == atomic_counter);
}
