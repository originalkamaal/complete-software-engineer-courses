// file: new/kernel/acpi.c
/* Find the CPUs: Multiboot2 tag 14 (ACPI 1.0 RSDP) -> RSDT -> MADT -> processor local APIC entries. */
#include <smp.h>

struct sdt_header {
    char signature[4];
    uint32_t length;
    uint8_t revision, checksum;
    char oem_id[6], oem_table_id[8];
    uint32_t oem_revision, creator_id, creator_revision;
} __attribute__((packed));
_Static_assert(sizeof(struct sdt_header) == 36, "ACPI table header");

static bool checksum_ok(const void *p, uint32_t len) {     /* every ACPI table's bytes sum to 0 mod 256 */
    uint8_t sum = 0;
    for (uint32_t i = 0; i < len; i++) sum = (uint8_t)(sum + ((const uint8_t *)p)[i]);
    return sum == 0;
}

int acpi_find_cpus(uint32_t *lapic_phys, uint8_t *apic_ids, int max) {
    const uint8_t *rsdp = NULL;
    for (uint32_t *t = (uint32_t *)(mb_info_start + 8); t[0] != 0; t = (uint32_t *)((uintptr_t)t + ((t[1] + 7) & ~7u)))
        if (t[0] == 14) rsdp = (const uint8_t *)(t + 2);       /* a copy of the RSDP, made by the bootloader */
    if (!rsdp || memcmp(rsdp, "RSD PTR ", 8) || !checksum_ok(rsdp, 20)) return -1;
    const struct sdt_header *rsdt = (const struct sdt_header *)(uintptr_t)*(const uint32_t *)(rsdp + 16);
    if (memcmp(rsdt->signature, "RSDT", 4) || !checksum_ok(rsdt, rsdt->length)) return -1;
    const uint32_t *entries = (const uint32_t *)(rsdt + 1);
    for (uint32_t i = 0; i < (rsdt->length - sizeof *rsdt) / 4; i++) {
        const struct sdt_header *h = (const struct sdt_header *)(uintptr_t)entries[i];
        if (memcmp(h->signature, "APIC", 4) || !checksum_ok(h, h->length)) continue;
        *lapic_phys = *(const uint32_t *)(h + 1);
        int n = 0;
        for (const uint8_t *p = (const uint8_t *)h + 44; p < (const uint8_t *)h + h->length && n < max; p += p[1])
            if (p[0] == 0 && (*(const uint32_t *)(p + 4) & 1)) apic_ids[n++] = p[3];   /* type 0, enabled */
        return n;
    }
    return -1;
}
