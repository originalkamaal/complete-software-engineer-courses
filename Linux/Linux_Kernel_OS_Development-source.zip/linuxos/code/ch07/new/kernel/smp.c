// file: new/kernel/smp.c
#include <smp.h>

#define LAPIC_VIRT 0xFFFFD00000000000UL
#define TRAMP_PHYS 0x8000UL

struct tramp_data { uint64_t cr3, stack, entry; };
struct __attribute__((packed)) desc_ptr { uint16_t limit; uint64_t base; };

extern const char tramp_start[], tramp_end[];
static volatile uint32_t *lapic;
static struct desc_ptr bsp_gdtr, bsp_idtr;
static spinlock_t print_lock = SPINLOCK_INIT("print");
int ncpus = 1;
static volatile int aps_online, next_index = 1;
static void (*volatile work)(int);
static volatile uint32_t generation, finished;

static uint32_t lapic_read(uint32_t reg) { return lapic[reg / 4]; }
static void lapic_write(uint32_t reg, uint32_t v) { lapic[reg / 4] = v; }

int cpu_id(void) { return lapic ? (int)(lapic_read(0x20) >> 24) : 0; }

static void send_ipi(uint8_t apic_id, uint32_t command) {
    lapic_write(0x310, (uint32_t)apic_id << 24);                 /* ICR high: destination */
    lapic_write(0x300, command);                                  /* ICR low: writing it sends the IPI */
    while (lapic_read(0x300) & (1 << 12)) cpu_relax();           /* delivery status: pending */
}

void smp_printf(const char *fmt, ...) {
    char buf[256];
    va_list ap; va_start(ap, fmt);
    kvsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    uint64_t f = spin_lock_irqsave(&print_lock);                  /* one line at a time, whole */
    for (char *p = buf; *p; p++) serial_putc(*p);
    spin_unlock_irqrestore(&print_lock, f);
}

static _Noreturn void ap_main(void) {
    __asm__ volatile("lgdt %0\n\t"                                 /* the BSP's GDT and IDT */
                     "pushq $0x08\n\t"
                     "leaq 1f(%%rip), %%rax\n\t"
                     "pushq %%rax\n\t"
                     "lretq\n"
                     "1:\n\t"
                     "mov $0x10, %%ax\n\t"
                     "mov %%ax, %%ds\n\t"
                     "mov %%ax, %%es\n\t"
                     "mov %%ax, %%ss\n\t"
                     "lidt %1"
                     : : "m"(bsp_gdtr), "m"(bsp_idtr) : "rax", "memory");
    int index = __atomic_fetch_add(&next_index, 1, __ATOMIC_RELAXED);
    __atomic_fetch_add(&aps_online, 1, __ATOMIC_RELEASE);
    uint32_t seen = 0;
    for (;;) {                                                     /* wait for work; interrupts stay off on APs */
        while (__atomic_load_n(&generation, __ATOMIC_ACQUIRE) == seen) cpu_relax();
        seen = generation;
        work(index);
        __atomic_fetch_add(&finished, 1, __ATOMIC_RELEASE);
    }
}

static void wait_ticks(uint64_t n) { uint64_t t = ticks + n; while (ticks < t) hlt(); }

int smp_init(void) {
    static bool done;
    if (done) return ncpus;
    done = true;
    uint32_t lapic_phys;
    uint8_t ids[16];
    int n = acpi_find_cpus(&lapic_phys, ids, 16);
    if (n <= 0) { kprintf("smp: no MADT, staying on one CPU\n"); return 1; }
    vmm_map(LAPIC_VIRT, lapic_phys, PTE_WRITABLE | PTE_PCD | PTE_PWT);   /* device registers: uncached */
    lapic = (volatile uint32_t *)LAPIC_VIRT;
    lapic_write(0xF0, lapic_read(0xF0) | 0x100);                  /* spurious-vector register: APIC enabled */
    int me = cpu_id();
    kprintf("smp: MADT lists %d CPUs, local APICs at 0x%x; BSP is APIC %d\n", n, lapic_phys, me);
    __asm__ volatile("sgdt %0; sidt %1" : "=m"(bsp_gdtr), "=m"(bsp_idtr));
    memcpy((void *)TRAMP_PHYS, tramp_start, (size_t)(tramp_end - tramp_start));
    volatile struct tramp_data *td = (volatile struct tramp_data *)(TRAMP_PHYS + 8);
    td->cr3 = (uint64_t)kernel_pml4;
    td->entry = (uint64_t)ap_main;
    for (int i = 0; i < n; i++) {
        if (ids[i] == me) continue;
        int before = aps_online;
        td->stack = (uint64_t)kmalloc(KSTACK_SIZE) + KSTACK_SIZE;
        send_ipi(ids[i], 0x4500);                                  /* INIT, level assert */
        wait_ticks(2);                                             /* >= 10 ms */
        for (int attempt = 0; attempt < 2 && aps_online == before; attempt++) {
            send_ipi(ids[i], 0x4600 | (TRAMP_PHYS >> 12));         /* STARTUP, vector = page 0x08 */
            for (int w = 0; w < 50 && aps_online == before; w++) wait_ticks(1);
        }
        if (aps_online == before) kprintf("smp: APIC %d did not start\n", ids[i]);
    }
    ncpus = 1 + aps_online;
    return ncpus;
}

void smp_start(void (*fn)(int)) {
    finished = 0;
    work = fn;
    __atomic_fetch_add(&generation, 1, __ATOMIC_RELEASE);
}

void smp_wait(void) {   /* the BSP sleeps between timer ticks instead of competing with the APs for host CPU time */
    while (__atomic_load_n(&finished, __ATOMIC_ACQUIRE) < (uint32_t)(ncpus - 1)) hlt();
}
void smp_run(void (*fn)(int)) { smp_start(fn); smp_wait(); }
