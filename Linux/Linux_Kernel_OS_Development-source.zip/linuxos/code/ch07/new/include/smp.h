// file: new/include/smp.h
#pragma once
#include <proc.h>

#define PTE_PWT (1UL << 3)            /* page-level write-through */
#define PTE_PCD (1UL << 4)            /* page-level cache disable: for device registers */

static inline void cpu_relax(void) { __asm__ volatile("pause" ::: "memory"); }

typedef struct {
    volatile uint32_t locked;         /* 0 free, 1 held */
    volatile uint32_t owner;          /* debugging: CPU id + 1 of the holder, 0 if free */
    const char *name;
    void *taken_at;                   /* debugging: return address of the spin_lock call */
    uint64_t contended;               /* how many acquisitions had to wait */
} spinlock_t;
#define SPINLOCK_INIT(n) { 0, 0, n, NULL, 0 }

typedef struct { volatile uint32_t next, serving; } ticketlock_t;

int  cpu_id(void);                    /* LAPIC id of the running CPU (0 before the LAPIC is mapped) */
void spin_lock(spinlock_t *l);
void spin_unlock(spinlock_t *l);
uint64_t spin_lock_irqsave(spinlock_t *l);
void spin_unlock_irqrestore(spinlock_t *l, uint64_t flags);
void ticket_lock(ticketlock_t *l);
void ticket_unlock(ticketlock_t *l);

extern int ncpus;
int  smp_init(void);                  /* start all CPUs; returns how many are online */
void smp_start(void (*fn)(int ap_index));   /* run fn on every AP (indices 1..ncpus-1) */
void smp_wait(void);                  /* wait until they have all returned */
void smp_run(void (*fn)(int ap_index));     /* smp_start + smp_wait */
void smp_printf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int  acpi_find_cpus(uint32_t *lapic_phys, uint8_t *apic_ids, int max);
