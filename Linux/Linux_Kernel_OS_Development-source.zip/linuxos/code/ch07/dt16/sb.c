// file: dt16/sb.c
/* The "store buffering" litmus test. Can r1 == 0 && r2 == 0? */
#include <pthread.h>
#include <stdio.h>
#include <stdatomic.h>
#include <string.h>

static volatile int x, y, r1, r2;
static atomic_int arrived, phase;           /* a two-thread barrier */
static int use_fence;
static long both_zero;
#define ROUNDS 200000

static void barrier(void) {
    int p = atomic_load(&phase);
    if (atomic_fetch_add(&arrived, 1) == 1) { atomic_store(&arrived, 0); atomic_fetch_add(&phase, 1); }
    else while (atomic_load(&phase) == p) { }
}

static void *thread_b(void *arg) {
    (void)arg;
    for (int i = 0; i < ROUNDS; i++) {
        barrier();                          /* round starts: x == y == 0 */
        y = 1;
        if (use_fence) atomic_thread_fence(memory_order_seq_cst);
        else __asm__ volatile("" ::: "memory");   /* stops the compiler, not the CPU */
        r2 = x;
        barrier();                          /* round ends */
        barrier();                          /* thread A has checked and reset */
    }
    return NULL;
}

int main(int argc, char **argv) {
    use_fence = argc > 1 && strcmp(argv[1], "fence") == 0;
    pthread_t b;
    pthread_create(&b, NULL, thread_b, NULL);
    for (int i = 0; i < ROUNDS; i++) {      /* the main thread is "thread A" */
        barrier();
        x = 1;
        if (use_fence) atomic_thread_fence(memory_order_seq_cst);
        else __asm__ volatile("" ::: "memory");
        r1 = y;
        barrier();
        if (r1 == 0 && r2 == 0) both_zero++;
        x = y = 0;
        barrier();
    }
    pthread_join(b, NULL);
    printf("%s: r1 == 0 && r2 == 0 in %ld of %d rounds\n", use_fence ? "with mfence" : "no fence   ", both_zero, ROUNDS);
    return 0;
}
