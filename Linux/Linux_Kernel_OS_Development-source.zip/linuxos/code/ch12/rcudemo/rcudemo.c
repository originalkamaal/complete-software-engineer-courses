// file: rcudemo/rcudemo.c
#include <linux/delay.h>
#include <linux/kthread.h>
#include <linux/ktime.h>
#include <linux/module.h>
#include <linux/rcupdate.h>
#include <linux/slab.h>

struct config {
	int a, b;			/* invariant: a + b == 100 */
	struct rcu_head rcu;
};

static struct config __rcu *cfg;
static DEFINE_MUTEX(update_lock);	/* writers serialise among themselves; readers take no lock */
static atomic_long_t reads, bad;
static int mode;			/* 0: synchronize_rcu, 1: kfree_rcu, 2: BROKEN - kfree at once */
module_param(mode, int, 0);

static int reader_fn(void *unused)
{
	while (!kthread_should_stop()) {
		struct config *c;
		int a;

		rcu_read_lock();
		c = rcu_dereference(cfg);
		a = c->a;
		udelay(20);		/* a slow reader: keeps the old version in use for a while */
		if (a + c->b != 100)
			atomic_long_inc(&bad);
		rcu_read_unlock();
		atomic_long_inc(&reads);
		cond_resched();		/* a quiescent state: lets grace periods end */
	}
	return 0;
}

static void update(int i)
{
	struct config *new = kmalloc(sizeof(*new), GFP_KERNEL), *old;

	if (!new)
		return;
	new->a = i;
	new->b = 100 - i;
	mutex_lock(&update_lock);
	old = rcu_replace_pointer(cfg, new, lockdep_is_held(&update_lock));	/* publish */
	mutex_unlock(&update_lock);
	if (mode == 0) {
		synchronize_rcu();	/* wait until no reader can still see old */
		kfree(old);
	} else if (mode == 1) {
		kfree_rcu(old, rcu);	/* free it after a grace period, without waiting */
	} else {
		kfree(old);		/* BROKEN: a reader may still be using old */
	}
}

static int __init rcudemo_init(void)
{
	struct task_struct *reader;
	struct config *c = kmalloc(sizeof(*c), GFP_KERNEL);
	int i, updates = mode == 0 ? 100 : 2000;
	ktime_t t0;

	if (!c)
		return -ENOMEM;
	c->a = 0;
	c->b = 100;
	RCU_INIT_POINTER(cfg, c);
	reader = kthread_run(reader_fn, NULL, "rcu-reader");
	if (IS_ERR(reader))
		return PTR_ERR(reader);
	t0 = ktime_get();
	for (i = 1; i <= updates; i++)
		update(i % 100);
	pr_info("rcudemo: mode %d: %d updates in %lld ms (%lld us each), %ld reads, %ld inconsistent\n", mode, updates,
		ktime_ms_delta(ktime_get(), t0), ktime_us_delta(ktime_get(), t0) / updates,
		atomic_long_read(&reads), atomic_long_read(&bad));
	kthread_stop(reader);
	synchronize_rcu();
	kfree(rcu_dereference_protected(cfg, 1));
	return 0;
}

static void __exit rcudemo_exit(void) { }
module_init(rcudemo_init);
module_exit(rcudemo_exit);
MODULE_LICENSE("GPL");
