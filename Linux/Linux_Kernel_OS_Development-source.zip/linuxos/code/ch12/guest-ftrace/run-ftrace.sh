# file: guest-ftrace/run-ftrace.sh
mount -t tracefs tracefs /sys/kernel/tracing
echo guest > /etc/hostname
cd /sys/kernel/tracing
echo "available tracers: $(cat available_tracers)"
echo "functions that can be traced: $(wc -l < available_filter_functions)"
echo do_sys_openat2 > set_graph_function
echo 2 > max_graph_depth
echo function_graph > current_tracer
cat /etc/hostname > /dev/null
echo 0 > tracing_on                         # stop recording; changing the tracer would clear the buffer
echo "== function_graph of do_sys_openat2, depth 2 =="
grep -vE "^#|^ *$" trace | head -24
echo nop > current_tracer
echo 1 > tracing_on
echo 1 > events/sched/sched_switch/enable
(i=0; while [ $i -lt 30000 ]; do i=$((i + 1)); done) &
sleep 0.3
echo 0 > events/sched/sched_switch/enable
echo "== sched_switch events: $(grep -c sched_switch trace) recorded; first three =="
grep sched_switch trace | head -3 | sed -E 's/ +/ /g' | cut -c1-140
