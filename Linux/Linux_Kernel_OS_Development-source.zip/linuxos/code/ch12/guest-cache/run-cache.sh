# file: guest-cache/run-cache.sh
dmesg -n 1
for t in 1 2 3; do
    dmesg -c > /dev/null
    insmod /modules/cache.ko test=$t && rmmod cache
    echo "== test $t: $(dmesg | grep -cE '^(\[[ 0-9.]*\] )?(BUG|WARNING):') report(s) =="
    dmesg | sed 's/^\[[ 0-9.]*\] //' | grep -E "^BUG|^WARNING|suspicious|^cache:|at .*cache\.c:|^ (cache_[a-z]+)\+|lockdep_rcu|Read of size|in_atomic|kmalloc|Freed by" | grep -v "^ *$" | head -8
done
