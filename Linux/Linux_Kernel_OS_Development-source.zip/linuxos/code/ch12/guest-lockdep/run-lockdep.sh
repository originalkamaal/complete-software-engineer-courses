# file: guest-lockdep/run-lockdep.sh
dmesg -n 8
insmod /modules/lockorder.ko && echo "insmod finished normally"
