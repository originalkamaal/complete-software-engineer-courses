# file: guest-rcu/run-rcu.sh
cd /modules
insmod rcudemo.ko mode=0 && rmmod rcudemo
insmod rcudemo.ko mode=1 && rmmod rcudemo
dmesg | grep "rcudemo:" | sed 's/^\[[ 0-9.]*\] //'
dmesg -n 8
insmod rcudemo.ko mode=2
