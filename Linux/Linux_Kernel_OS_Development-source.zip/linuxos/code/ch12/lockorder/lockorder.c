// file: lockorder/lockorder.c
#include <linux/module.h>
#include <linux/mutex.h>

static DEFINE_MUTEX(config_lock);
static DEFINE_MUTEX(stats_lock);
static int config, stats;

static noinline void update_config(void)	/* takes config, then stats */
{
	mutex_lock(&config_lock);
	config++;
	mutex_lock(&stats_lock);
	stats++;
	mutex_unlock(&stats_lock);
	mutex_unlock(&config_lock);
}

static noinline void report_stats(void)	/* takes stats, then config: the opposite order */
{
	mutex_lock(&stats_lock);
	mutex_lock(&config_lock);
	pr_info("lockorder: config=%d stats=%d\n", config, stats);
	mutex_unlock(&config_lock);
	mutex_unlock(&stats_lock);
}

static int __init lockorder_init(void)
{
	update_config();		/* one after the other, in one thread: no deadlock can happen here */
	report_stats();
	return 0;
}

static void __exit lockorder_exit(void) { }
module_init(lockorder_init);
module_exit(lockorder_exit);
MODULE_LICENSE("GPL");
