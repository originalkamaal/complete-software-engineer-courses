// file: cache/cache.c
#include <linux/module.h>
#include <linux/rculist.h>
#include <linux/slab.h>
#include <linux/spinlock.h>

struct entry {
	struct list_head node;
	int key, value;
	struct rcu_head rcu;
};

static LIST_HEAD(entries);
static DEFINE_SPINLOCK(entries_lock);
static int test;
module_param(test, int, 0);

/* Test 1: insert under the spinlock */
static int cache_insert(int key, int value)
{
	struct entry *e;

	spin_lock(&entries_lock);
	e = kmalloc(sizeof(*e), GFP_KERNEL);
	if (!e) {
		spin_unlock(&entries_lock);
		return -ENOMEM;
	}
	e->key = key;
	e->value = value;
	list_add_rcu(&e->node, &entries);
	spin_unlock(&entries_lock);
	return 0;
}

/* Test 2: lockless lookup, with a pointer to the last entry found */
static struct entry __rcu *last_hit;

static int cache_lookup(int key)
{
	struct entry *e = rcu_dereference(last_hit);

	if (e && e->key == key)
		return e->value;
	list_for_each_entry_rcu(e, &entries, node) {
		if (e->key == key) {
			rcu_assign_pointer(last_hit, e);
			return e->value;
		}
	}
	return -1;
}

/* Test 3: removal */
static void cache_remove(int key)
{
	struct entry *e;

	spin_lock(&entries_lock);
	list_for_each_entry(e, &entries, node) {
		if (e->key == key) {
			list_del_rcu(&e->node);
			if (rcu_access_pointer(last_hit) == e)
				RCU_INIT_POINTER(last_hit, NULL);
			kfree(e);
			break;
		}
	}
	spin_unlock(&entries_lock);
}

static int __init cache_init(void)
{
	int i, found = 0;

	for (i = 0; i < 10; i++)
		if (cache_insert(i, i * i))
			return -ENOMEM;
	if (test >= 2)
		found = cache_lookup(7);
	if (test >= 3) {
		struct entry *e;

		rcu_read_lock();
		e = list_first_or_null_rcu(&entries, struct entry, node);
		cache_remove(e->key);		/* remove the entry we are looking at ... */
		found += e->value;		/* ... and keep using it, as an RCU reader may */
		rcu_read_unlock();
	}
	pr_info("cache: test %d done, found %d\n", test, found);
	return 0;
}

static void __exit cache_exit(void)
{
	struct entry *e, *tmp;

	list_for_each_entry_safe(e, tmp, &entries, node) {
		list_del(&e->node);
		kfree(e);
	}
}

module_init(cache_init);
module_exit(cache_exit);
MODULE_LICENSE("GPL");
