# file: guest-kprobe/run-kprobe.sh
mount -t tracefs tracefs /sys/kernel/tracing
echo guest > /etc/hostname
cd /sys/kernel/tracing
echo 'p:myopen do_sys_openat2 dfd=%di:s32 path=+0(%si):string' >> kprobe_events
echo 'r:myopen_ret do_sys_openat2 fd=$retval:s32' >> kprobe_events
cat kprobe_events
echo 1 > events/kprobes/enable
cat /etc/hostname > /dev/null
cat /no/such/file 2> /dev/null
echo 0 > events/kprobes/enable
grep -E "myopen" trace | grep -vE '"/dev/null"|events/kprobes' | sed -E 's/^ +//; s/ +/ /g' | cut -d' ' -f1,5- | grep -A1 -E 'hostname|no/such' | grep -v "^--"
