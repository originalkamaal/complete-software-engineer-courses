# file: init-modules.sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
dmesg -n 1                       # keep the console quiet; we print what we want ourselves
for script in /run-*.sh; do sh "$script"; done
reboot -f
