# file: guest-stress/init-stress.sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
dmesg -n 1
RING=ring-unit sh /run-stress.sh
RING=ring-atomic sh /run-stress.sh
reboot -f
