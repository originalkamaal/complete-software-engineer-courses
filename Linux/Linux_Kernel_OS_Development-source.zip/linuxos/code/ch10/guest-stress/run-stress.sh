# file: guest-stress/run-stress.sh
insmod /modules/$RING.ko capacity=1024
echo "== $RING driver =="
/bin/stress 4 2000
cat /proc/ring | tr '\n' ' '; echo
sleep 0.5
rmmod ring
