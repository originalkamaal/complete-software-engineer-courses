# file: guest-ringtest/run-ringtest.sh
insmod /modules/ring.ko && /bin/ringtest
