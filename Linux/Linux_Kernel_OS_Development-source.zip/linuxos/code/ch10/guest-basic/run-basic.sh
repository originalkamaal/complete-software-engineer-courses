# file: guest-basic/run-basic.sh
insmod /modules/ring.ko
ls -l /dev/ring
echo "hello through the kernel" > /dev/ring
cat /sys/class/misc/ring/used
dd if=/dev/ring bs=64 count=1 2>/dev/null
cat /proc/ring
exec 3< /dev/ring
rmmod ring; echo "rmmod while /dev/ring is open: exit status $?"
exec 3<&-
rmmod ring && echo "rmmod after closing: ok"
