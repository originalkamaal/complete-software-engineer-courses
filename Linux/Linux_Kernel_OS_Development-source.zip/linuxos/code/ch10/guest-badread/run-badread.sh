# file: guest-badread/run-badread.sh
insmod /modules/ring.ko && /bin/badread && rmmod ring
insmod /modules/ring-buggy.ko && /bin/badread && rmmod ring
