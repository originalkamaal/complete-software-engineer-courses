# file: guest-atomic/run-atomic.sh
dmesg -n 8
insmod /modules/ring-atomic.ko
echo hi > /dev/ring
dd if=/dev/ring bs=16 count=1 2>/dev/null
