// file: ring/ring.c
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/wait.h>
#include "ring_uapi.h"

static unsigned int capacity = 4096;
module_param(capacity, uint, 0444);

static struct {
	struct mutex lock;		/* protects everything below */
	char *buf;
	size_t cap, head, len;		/* data is buf[head .. head+len), wrapping at cap */
	wait_queue_head_t readq, writeq;
	struct ring_stats st;
} ring;

static int ring_open(struct inode *inode, struct file *file)
{
	mutex_lock(&ring.lock);
	ring.st.opens++;
	mutex_unlock(&ring.lock);
	return stream_open(inode, file);	/* a stream: no file position, no lseek */
}

static ssize_t ring_read(struct file *file, char __user *ubuf, size_t n, loff_t *pos)
{
	size_t first;

	if (mutex_lock_interruptible(&ring.lock))
		return -ERESTARTSYS;
	while (ring.len == 0) {			/* empty: wait (Unit 10.2) */
		mutex_unlock(&ring.lock);
		if (file->f_flags & O_NONBLOCK)
			return -EAGAIN;
		if (wait_event_interruptible(ring.readq, READ_ONCE(ring.len) > 0))
			return -ERESTARTSYS;	/* a signal arrived */
		if (mutex_lock_interruptible(&ring.lock))
			return -ERESTARTSYS;
	}
	n = min(n, ring.len);
	first = min(n, ring.cap - ring.head);	/* the data may wrap around the end of buf */
#ifdef COPY_UNDER_SPINLOCK			/* experiment switch for DT-23 */
	{
		static DEFINE_SPINLOCK(demo);

		spin_lock(&demo);
		n -= copy_to_user(ubuf, ring.buf + ring.head, first);
		spin_unlock(&demo);
		first = n;
	}
#endif
#ifdef RETURN_COPY_RESULT			/* experiment switch for DT-22 */
	{
		unsigned long left = copy_to_user(ubuf, ring.buf + ring.head, first);

		if (left) {
			mutex_unlock(&ring.lock);
			return left;		/* BUG: a byte count, not an error */
		}
	}
#endif
	if (copy_to_user(ubuf, ring.buf + ring.head, first) ||
	    copy_to_user(ubuf + first, ring.buf, n - first)) {
		mutex_unlock(&ring.lock);
		return -EFAULT;
	}
	ring.head = (ring.head + n) % ring.cap;
	ring.len -= n;
	ring.st.bytes_out += n;
	ring.st.reads++;
	mutex_unlock(&ring.lock);
	wake_up_interruptible(&ring.writeq);	/* there is room now */
	return n;
}

static ssize_t ring_write(struct file *file, const char __user *ubuf, size_t n, loff_t *pos)
{
	size_t tail, first;

	if (n == 0)
		return 0;
	if (mutex_lock_interruptible(&ring.lock))
		return -ERESTARTSYS;
	while (ring.len == ring.cap) {		/* full: wait for a reader */
		mutex_unlock(&ring.lock);
		if (file->f_flags & O_NONBLOCK)
			return -EAGAIN;
		if (wait_event_interruptible(ring.writeq, READ_ONCE(ring.len) < READ_ONCE(ring.cap)))
			return -ERESTARTSYS;
		if (mutex_lock_interruptible(&ring.lock))
			return -ERESTARTSYS;
	}
	n = min(n, ring.cap - ring.len);	/* a partial write is allowed, like a pipe */
	tail = (ring.head + ring.len) % ring.cap;
	first = min(n, ring.cap - tail);
	if (copy_from_user(ring.buf + tail, ubuf, first) ||
	    copy_from_user(ring.buf, ubuf + first, n - first)) {
		mutex_unlock(&ring.lock);
		return -EFAULT;
	}
	ring.len += n;
	ring.st.bytes_in += n;
	ring.st.writes++;
	mutex_unlock(&ring.lock);
	wake_up_interruptible(&ring.readq);	/* there is data now */
	return n;
}

static __poll_t ring_poll(struct file *file, poll_table *wait)
{
	__poll_t mask = 0;

	poll_wait(file, &ring.readq, wait);	/* register: wake this poller when either queue is woken */
	poll_wait(file, &ring.writeq, wait);
	mutex_lock(&ring.lock);
	if (ring.len > 0)
		mask |= EPOLLIN | EPOLLRDNORM;
	if (ring.len < ring.cap)
		mask |= EPOLLOUT | EPOLLWRNORM;
	mutex_unlock(&ring.lock);
	return mask;
}

static long ring_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	struct ring_stats st;
	__u32 newcap;
	char *newbuf;
	long ret = 0;

	switch (cmd) {
	case RING_IOC_GET_STATS:
		mutex_lock(&ring.lock);
		st = ring.st;
		st.capacity = ring.cap;
		st.used = ring.len;
		mutex_unlock(&ring.lock);
		return copy_to_user((void __user *)arg, &st, sizeof(st)) ? -EFAULT : 0;
	case RING_IOC_RESET:
		mutex_lock(&ring.lock);
		ring.head = ring.len = 0;
		memset(&ring.st, 0, sizeof(ring.st));
		mutex_unlock(&ring.lock);
		wake_up_interruptible(&ring.writeq);
		return 0;
	case RING_IOC_RESIZE:
		if (get_user(newcap, (__u32 __user *)arg))
			return -EFAULT;
		if (newcap < 16 || newcap > 1 << 20)
			return -EINVAL;
		newbuf = kmalloc(newcap, GFP_KERNEL);
		if (!newbuf)
			return -ENOMEM;
		mutex_lock(&ring.lock);
		if (ring.len) {
			ret = -EBUSY;		/* only an empty ring may be resized */
		} else {
			swap(ring.buf, newbuf);
			ring.cap = newcap;
			ring.head = 0;
		}
		mutex_unlock(&ring.lock);
		kfree(newbuf);			/* the old buffer, or the unused new one */
		return ret;
	default:
		return -ENOTTY;			/* "inappropriate ioctl for device" */
	}
}

static const struct file_operations ring_fops = {
	.owner		= THIS_MODULE,		/* pins the module while a file is open */
	.open		= ring_open,
	.read		= ring_read,
	.write		= ring_write,
	.poll		= ring_poll,
	.unlocked_ioctl	= ring_ioctl,
};

/* sysfs: /sys/class/misc/ring/used and .../capacity */
static ssize_t used_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	return sysfs_emit(buf, "%zu\n", READ_ONCE(ring.len));
}
static DEVICE_ATTR_RO(used);

static ssize_t capacity_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	return sysfs_emit(buf, "%zu\n", READ_ONCE(ring.cap));
}
static DEVICE_ATTR_RO(capacity);

static struct attribute *ring_attrs[] = { &dev_attr_used.attr, &dev_attr_capacity.attr, NULL };
ATTRIBUTE_GROUPS(ring);

static struct miscdevice ring_misc = {
	.minor	= MISC_DYNAMIC_MINOR,
	.name	= "ring",
	.fops	= &ring_fops,
	.groups	= ring_groups,
	.mode	= 0666,
};

/* procfs: /proc/ring, a human-readable summary */
static int ring_proc_show(struct seq_file *m, void *v)
{
	mutex_lock(&ring.lock);
	seq_printf(m, "capacity %zu\nused %zu\nopens %u\nreads %u\nwrites %u\nbytes_in %llu\nbytes_out %llu\n",
		   ring.cap, ring.len, ring.st.opens, ring.st.reads, ring.st.writes,
		   ring.st.bytes_in, ring.st.bytes_out);
	mutex_unlock(&ring.lock);
	return 0;
}

static int __init ring_init(void)
{
	int err;

	if (capacity < 16 || capacity > 1 << 20)
		return -EINVAL;
	mutex_init(&ring.lock);
	init_waitqueue_head(&ring.readq);
	init_waitqueue_head(&ring.writeq);
	ring.cap = capacity;
	ring.buf = kmalloc(ring.cap, GFP_KERNEL);
	if (!ring.buf)
		return -ENOMEM;
	if (!proc_create_single("ring", 0444, NULL, ring_proc_show)) {
		err = -ENOMEM;
		goto free_buf;
	}
	err = misc_register(&ring_misc);
	if (err)
		goto remove_proc;
	pr_info("ring: /dev/ring is %d:%d, capacity %zu\n", MISC_MAJOR, ring_misc.minor, ring.cap);
	return 0;

remove_proc:
	remove_proc_entry("ring", NULL);
free_buf:
	kfree(ring.buf);
	return err;
}

static void __exit ring_exit(void)
{
	misc_deregister(&ring_misc);
	remove_proc_entry("ring", NULL);
	kfree(ring.buf);
}

module_init(ring_init);
module_exit(ring_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("A blocking byte ring buffer character device");
