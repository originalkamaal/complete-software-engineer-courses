// file: ring/ring_uapi.h
/* The user-space interface of /dev/ring. Included by the driver and by programs. */
#ifndef RING_UAPI_H
#define RING_UAPI_H
#include <linux/ioctl.h>
#include <linux/types.h>

struct ring_stats {
	__u64 bytes_in, bytes_out;
	__u32 reads, writes, opens, capacity, used, reserved;	/* fixed size: 40 bytes on every architecture */
};

#define RING_IOC_MAGIC		'r'
#define RING_IOC_GET_STATS	_IOR(RING_IOC_MAGIC, 1, struct ring_stats)
#define RING_IOC_RESET		_IO(RING_IOC_MAGIC, 2)
#define RING_IOC_RESIZE		_IOW(RING_IOC_MAGIC, 3, __u32)
#endif
