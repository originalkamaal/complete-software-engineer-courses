// file: user/badread.c
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void) {
    int fd = open("/dev/ring", O_RDWR);
    char *volatile bad = (char *)1;                       /* address 1: never mapped (volatile: hide it from the compiler) */
    if (write(fd, "0123456789abcdef", 16) != 16) return 1;
    ssize_t r = read(fd, bad, 16);
    printf("read into a bad pointer returned %zd%s%s\n", r, r < 0 ? ", errno " : "", r < 0 ? strerror(errno) : " (claims success!)");
    return 0;
}
