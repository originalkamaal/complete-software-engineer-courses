// file: user/stress.c
/* stress WRITERS RECORDS: writers send framed records; the reader verifies them. */
#include <fcntl.h>
#include <stdint.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static pid_t pids[256];
static int nwriters;

static int finish(int status) {                     /* stop any writer still blocked in write(), then reap */
    for (int w = 0; w < nwriters; w++) kill(pids[w], SIGKILL);
    while (wait(NULL) > 0) { }
    return status;
}

struct hdr { uint16_t len; uint8_t writer; uint8_t check; uint32_t seq; };   /* 8 bytes, then len payload bytes */

static uint8_t sum(const uint8_t *p, size_t n) { uint8_t s = 0; while (n--) s = (uint8_t)(s * 31 + *p++); return s; }

int main(int argc, char **argv) {
    int writers = atoi(argv[1]), records = atoi(argv[2]);
    nwriters = writers;
    for (int w = 0; w < writers; w++) {
        if ((pids[w] = fork()) == 0) {
            int fd = open("/dev/ring", O_WRONLY);
            srand(w + 1);
            uint8_t rec[8 + 600];
            for (int i = 0; i < records; i++) {
                struct hdr h = { (uint16_t)(1 + rand() % 600), (uint8_t)w, 0, (uint32_t)i };
                for (int k = 0; k < h.len; k++) rec[8 + k] = (uint8_t)(rand() & 0xFF);
                h.check = sum(rec + 8, h.len);
                memcpy(rec, &h, 8);
                ssize_t wr = write(fd, rec, 8 + h.len);
                if (wr != 8 + h.len) { printf("writer %d: short write, %zd of %d bytes\n", w, wr, 8 + h.len); _exit(1); }
            }
            _exit(0);
        }
    }
    int fd = open("/dev/ring", O_RDONLY);
    uint32_t next[256] = { 0 };
    long total = 0, bad = 0, bytes = 0;
    uint8_t stream[8192];
    size_t have = 0;
    while (total < (long)writers * records) {
        ssize_t r = read(fd, stream + have, sizeof stream - have);
        if (r <= 0) { perror("read"); return finish(1); }
        have += (size_t)r;
        bytes += r;
        for (;;) {                                         /* consume every complete record */
            struct hdr h;
            if (have < 8) break;
            memcpy(&h, stream, 8);
            if (h.len == 0 || h.len > 600 || h.writer >= writers) { printf("garbage header at record %ld\n", total); return finish(1); }
            if (have < 8u + h.len) break;
            if (sum(stream + 8, h.len) != h.check || h.seq != next[h.writer]) bad++;
            next[h.writer] = h.seq + 1;
            memmove(stream, stream + 8 + h.len, have - 8 - h.len);
            have -= 8 + h.len;
            total++;
        }
    }
    finish(0);
    printf("stress: %d writers x %d records = %ld records, %ld bytes, %ld bad\n", writers, records, total, bytes, bad);
    return bad != 0;
}
