// file: user/ringtest.c
/* Functional tests for /dev/ring, run inside the guest. */
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "../ring/ring_uapi.h"

static int failures;
#define CHECK(c) do { if (!(c)) { printf("  FAIL line %d: %s (errno %d)\n", __LINE__, #c, errno); failures++; } } while (0)

static long ms_since(struct timespec *a) {
    struct timespec b;
    clock_gettime(CLOCK_MONOTONIC, &b);
    return (b.tv_sec - a->tv_sec) * 1000 + (b.tv_nsec - a->tv_nsec) / 1000000;
}

static void on_alarm(int sig) { (void)sig; }

int main(void) {
    int fd = open("/dev/ring", O_RDWR);
    CHECK(fd >= 0);
    char buf[256];
    struct ring_stats st;
    struct timespec t0;

    /* 1. round trip */
    CHECK(write(fd, "abc", 3) == 3);
    CHECK(read(fd, buf, sizeof buf) == 3 && memcmp(buf, "abc", 3) == 0);

    /* 2. non-blocking read of an empty ring */
    int nb = open("/dev/ring", O_RDWR | O_NONBLOCK);
    errno = 0;
    CHECK(read(nb, buf, 1) == -1 && errno == EAGAIN);

    /* 3. ioctl: resize, partial write, full ring, unknown command */
    unsigned int cap = 64;
    CHECK(ioctl(fd, RING_IOC_RESIZE, &cap) == 0);
    memset(buf, 'x', 100);
    CHECK(write(fd, buf, 100) == 64);                       /* only 64 fit */
    errno = 0;
    CHECK(write(nb, buf, 1) == -1 && errno == EAGAIN);      /* full */
    CHECK(ioctl(fd, RING_IOC_RESIZE, &cap) == -1 && errno == EBUSY);
    CHECK(ioctl(fd, RING_IOC_GET_STATS, &st) == 0 && st.used == 64 && st.capacity == 64);
    CHECK(ioctl(fd, _IO('r', 99)) == -1 && errno == ENOTTY);
    CHECK(ioctl(fd, RING_IOC_RESET) == 0);
    printf("  ioctl numbers: GET_STATS=0x%08lx RESET=0x%08lx RESIZE=0x%08lx\n",
           (unsigned long)RING_IOC_GET_STATS, (unsigned long)RING_IOC_RESET, (unsigned long)RING_IOC_RESIZE);

    /* 4. a blocked reader is woken by a writer in another process */
    clock_gettime(CLOCK_MONOTONIC, &t0);
    if (fork() == 0) { usleep(200000); _exit(write(fd, "wake", 4) == 4 ? 0 : 1); }
    CHECK(read(fd, buf, sizeof buf) == 4);
    long waited = ms_since(&t0);
    CHECK(waited >= 190);
    printf("  blocking read waited %ld ms for the writer\n", waited);
    wait(NULL);

    /* 5. poll: not readable now; readable after a delayed write */
    struct pollfd p = { fd, POLLIN, 0 };
    CHECK(poll(&p, 1, 0) == 0);
    clock_gettime(CLOCK_MONOTONIC, &t0);
    if (fork() == 0) { usleep(100000); _exit(write(fd, "p", 1) == 1 ? 0 : 1); }
    CHECK(poll(&p, 1, 2000) == 1 && (p.revents & POLLIN));
    printf("  poll returned POLLIN after %ld ms\n", ms_since(&t0));
    CHECK(read(fd, buf, 1) == 1);
    wait(NULL);

    /* 6. a signal interrupts a blocked read: EINTR */
    struct sigaction sa = { 0 };
    sa.sa_handler = on_alarm;                                /* no SA_RESTART */
    sigaction(SIGALRM, &sa, NULL);
    alarm(1);
    errno = 0;
    CHECK(read(fd, buf, 1) == -1 && errno == EINTR);

    CHECK(ioctl(fd, RING_IOC_GET_STATS, &st) == 0);
    printf("  stats: opens %u reads %u writes %u in %llu out %llu\n", st.opens, st.reads, st.writes,
           (unsigned long long)st.bytes_in, (unsigned long long)st.bytes_out);
    printf("ringtest: %s\n", failures ? "FAILED" : "all checks passed");
    return failures != 0;
}
