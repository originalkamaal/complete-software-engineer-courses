# file: guest-bpf/run-bpf.sh
. /net-up.sh
echo "bpf_jit_enable=$(cat /proc/sys/net/core/bpf_jit_enable)"
/bin/bpfcount 4 &
sleep 1
wget -q -O /dev/null http://10.0.2.2:8099/hello.txt
nslookup example.org 10.0.2.3 > /dev/null 2>&1
ping -c 2 -W 1 10.0.2.2 > /dev/null 2>&1
wait
/bin/verifier
