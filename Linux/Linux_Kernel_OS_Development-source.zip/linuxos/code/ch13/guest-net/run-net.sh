# file: guest-net/run-net.sh
. /net-up.sh
ip addr show eth0 | grep -E "link/ether|inet "
ip route
echo "e1000 driver: $(readlink /sys/class/net/eth0/device/driver | xargs basename), PCI $(basename $(readlink /sys/class/net/eth0/device))"
grep -E "eth0|CPU0" /proc/interrupts | sed -E 's/ +/ /g'
wget -q -O - http://10.0.2.2:8099/hello.txt
cat /proc/net/arp
grep eth0 /proc/net/dev | awk '{ print "eth0: received " $2 " bytes in " $3 " packets, sent " $10 " bytes in " $11 " packets" }'
grep -E "eth0" /proc/interrupts | sed -E 's/ +/ /g'
