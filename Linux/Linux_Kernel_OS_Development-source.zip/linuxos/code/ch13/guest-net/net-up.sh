# file: guest-net/net-up.sh
# Bring eth0 up by hand: what a DHCP client would do.
ip link set lo up
ip link set eth0 up
ip addr add 10.0.2.15/24 dev eth0
ip route add default via 10.0.2.2
