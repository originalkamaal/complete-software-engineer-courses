# file: guest-sniff/run-sniff.sh
. /net-up.sh
/bin/sniff 12 &
sleep 1
wget -q -O /dev/null http://10.0.2.2:8099/hello.txt
wait
