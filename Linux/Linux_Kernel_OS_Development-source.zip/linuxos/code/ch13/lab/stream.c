// file: lab/stream.c
/* Three writes on a TCP connection, one read on the other side; then the same with UDP. */
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

static void put(int fd, const char *s) { if (write(fd, s, strlen(s)) < 0) _exit(1); }

int main(void) {
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_port = htons(5555), .sin_addr.s_addr = htonl(INADDR_LOOPBACK) };
    int ls = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    bind(ls, (struct sockaddr *)&a, sizeof a);
    listen(ls, 1);
    if (fork() == 0) {
        int c = socket(AF_INET, SOCK_STREAM, 0);
        connect(c, (struct sockaddr *)&a, sizeof a);
        put(c, "one;");
        put(c, "two;");
        put(c, "three;");
        close(c);
        _exit(0);
    }
    int s = accept(ls, NULL, NULL);
    usleep(200000);                                          /* let all three writes arrive */
    char buf[64];
    ssize_t n = read(s, buf, sizeof buf);
    printf("TCP: 3 writes (4+4+6 bytes) -> first read returned %zd bytes: \"%.*s\"\n", n, (int)n, buf);
    wait(NULL);

    int u = socket(AF_INET, SOCK_DGRAM, 0);
    a.sin_port = htons(5556);
    bind(u, (struct sockaddr *)&a, sizeof a);
    if (fork() == 0) {
        int c = socket(AF_INET, SOCK_DGRAM, 0);
        sendto(c, "one;", 4, 0, (struct sockaddr *)&a, sizeof a);
        sendto(c, "two;", 4, 0, (struct sockaddr *)&a, sizeof a);
        sendto(c, "three;", 6, 0, (struct sockaddr *)&a, sizeof a);
        _exit(0);
    }
    usleep(200000);
    for (int i = 0; i < 3; i++) {
        n = recv(u, buf, sizeof buf, 0);
        printf("UDP: recv %d returned %zd bytes: \"%.*s\"\n", i + 1, n, (int)n, buf);
    }
    wait(NULL);
    return 0;
}
