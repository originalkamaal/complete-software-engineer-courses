// file: lab/bpfcount.c
/* bpfcount SECONDS: count every frame on every interface by protocol, in the kernel, with eBPF. */
#include <arpa/inet.h>
#include <linux/if_ether.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include "bpfprog.h"

int main(int argc, char **argv) {
    static char log[65536];
    int map = create_counter_map();
    int prog = load_counter_prog(map, 1, log, sizeof log);
    if (prog < 0) { printf("load failed:\n%s", log); return 1; }
    printf("program loaded: fd %d, verifier says: %s", prog, strrchr(log, '\n') ? "" : "\n");
    char *last = log + strlen(log) - 1;                          /* print the verifier's final statistics line */
    while (last > log && last[-1] != '\n') last--;
    printf("%s", last);
    int s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (setsockopt(s, SOL_SOCKET, SO_ATTACH_BPF, &prog, sizeof prog) < 0) { perror("SO_ATTACH_BPF"); return 1; }
    sleep((unsigned)atoi(argv[1]));
    static const char *names[256] = { [1] = "ICMP", [6] = "TCP", [17] = "UDP", [255] = "not IPv4 (ARP, ...)" };
    for (unsigned k = 0; k < 256; k++) {
        unsigned long v = map_get(map, k);
        if (v) printf("  %-20s %lu packets\n", names[k] ? names[k] : "other", v);
    }
    return 0;
}
