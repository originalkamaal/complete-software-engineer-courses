// file: lab/bpfprog.h
/* A socket-filter eBPF program, written as raw instructions, that counts packets by IP protocol. */
#pragma once
#include <linux/bpf.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

#define INSN(c, d, s, o, i) ((struct bpf_insn){ .code = (c), .dst_reg = (d), .src_reg = (s), .off = (o), .imm = (i) })
#define MOV64_REG(d, s)      INSN(BPF_ALU64 | BPF_MOV | BPF_X, d, s, 0, 0)
#define MOV64_IMM(d, i)      INSN(BPF_ALU64 | BPF_MOV | BPF_K, d, 0, 0, i)
#define ADD64_IMM(d, i)      INSN(BPF_ALU64 | BPF_ADD | BPF_K, d, 0, 0, i)
#define LD_ABS(size, off)    INSN(BPF_LD | BPF_ABS | (size), 0, 0, 0, off)     /* r0 = packet[off], big-endian */
#define STX_MEM(size, d, s, o) INSN(BPF_STX | BPF_MEM | (size), d, s, o, 0)
#define JEQ_IMM(d, i, o)     INSN(BPF_JMP | BPF_JEQ | BPF_K, d, 0, o, i)
#define JNE_IMM(d, i, o)     INSN(BPF_JMP | BPF_JNE | BPF_K, d, 0, o, i)
#define JA(o)                INSN(BPF_JMP | BPF_JA, 0, 0, o, 0)
#define CALL(f)              INSN(BPF_JMP | BPF_CALL, 0, 0, 0, f)
#define EXIT()               INSN(BPF_JMP | BPF_EXIT, 0, 0, 0, 0)
#define ATOMIC_ADD64(d, s, o) INSN(BPF_STX | BPF_ATOMIC | BPF_DW, d, s, o, BPF_ADD)
#define LD_MAP_FD(d, fd)     INSN(BPF_LD | BPF_IMM | BPF_DW, d, BPF_PSEUDO_MAP_FD, 0, fd), INSN(0, 0, 0, 0, 0)

static inline long bpf(int cmd, union bpf_attr *attr) { return syscall(SYS_bpf, cmd, attr, sizeof(*attr)); }

static inline int create_counter_map(void) {
    union bpf_attr a;
    memset(&a, 0, sizeof a);
    a.map_type = BPF_MAP_TYPE_ARRAY;
    a.key_size = 4;
    a.value_size = 8;
    a.max_entries = 256;                     /* index 0-254: IP protocol number; 255: not IPv4 */
    return (int)bpf(BPF_MAP_CREATE, &a);
}

/* Returns a program fd, or -1 with the verifier's log in log[]. */
static inline int load_counter_prog(int map_fd, int with_null_check, char *log, unsigned log_size) {
    struct bpf_insn prog[] = {
        MOV64_REG(BPF_REG_6, BPF_REG_1),            /* r6 = skb context (needed by LD_ABS) */
        LD_ABS(BPF_H, 12),                          /* r0 = EtherType */
        MOV64_IMM(BPF_REG_7, 255),                  /* key = 255 ("not IPv4") */
        JNE_IMM(BPF_REG_0, 0x0800, 2),              /* not IPv4? skip the next 2 instructions */
        LD_ABS(BPF_B, 14 + 9),                      /* r0 = IPv4 protocol byte */
        MOV64_REG(BPF_REG_7, BPF_REG_0),            /* key = protocol */
        STX_MEM(BPF_W, BPF_REG_10, BPF_REG_7, -4),  /* *(u32 *)(fp - 4) = key */
        LD_MAP_FD(BPF_REG_1, map_fd),               /* r1 = map */
        MOV64_REG(BPF_REG_2, BPF_REG_10),
        ADD64_IMM(BPF_REG_2, -4),                   /* r2 = &key */
        CALL(BPF_FUNC_map_lookup_elem),             /* r0 = &value, or NULL */
        with_null_check ? JEQ_IMM(BPF_REG_0, 0, 2) : JA(0),  /* if (r0 == NULL) goto out */
        MOV64_IMM(BPF_REG_1, 1),
        ATOMIC_ADD64(BPF_REG_0, BPF_REG_1, 0),      /* __sync_fetch_and_add(value, 1) */
        MOV64_IMM(BPF_REG_0, 0),                    /* out: return 0 = the socket gets no copy */
        EXIT(),
    };
    union bpf_attr a;
    memset(&a, 0, sizeof a);
    a.prog_type = BPF_PROG_TYPE_SOCKET_FILTER;
    a.insns = (unsigned long)prog;
    a.insn_cnt = sizeof prog / sizeof prog[0];
    a.license = (unsigned long)"GPL";
    a.log_buf = (unsigned long)log;
    a.log_size = log_size;
    a.log_level = 1;
    log[0] = 0;
    return (int)bpf(BPF_PROG_LOAD, &a);
}

static inline unsigned long map_get(int map_fd, unsigned key) {
    unsigned long value = 0;
    union bpf_attr a;
    memset(&a, 0, sizeof a);
    a.map_fd = (unsigned)map_fd;
    a.key = (unsigned long)&key;
    a.value = (unsigned long)&value;
    bpf(BPF_MAP_LOOKUP_ELEM, &a);
    return value;
}
