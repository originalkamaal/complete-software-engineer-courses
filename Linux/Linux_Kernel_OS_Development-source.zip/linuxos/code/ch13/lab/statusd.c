// file: lab/statusd.c
#include <arpa/inet.h>
#include <linux/if_ether.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/utsname.h>
#include "bpfprog.h"

static char out[16384];

static void add_file(size_t *len, const char *path, int max_lines) {
    FILE *f = fopen(path, "r");
    char line[256];
    for (int i = 0; f && i < max_lines && fgets(line, sizeof line, f); i++)
        *len += (size_t)snprintf(out + *len, sizeof out - *len, "%s", line);
    if (f) fclose(f);
}

int main(void) {
    static char log[65536];
    int map = create_counter_map(), prog = load_counter_prog(map, 1, log, sizeof log);
    int ps = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (prog < 0 || setsockopt(ps, SOL_SOCKET, SO_ATTACH_BPF, &prog, sizeof prog) < 0) { puts("bpf setup failed"); return 1; }
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_port = htons(80), .sin_addr.s_addr = htonl(INADDR_ANY) };
    int ls = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0 || listen(ls, 8) < 0) { perror("bind/listen"); return 1; }
    puts("statusd: listening on port 80");
    fflush(stdout);
    for (int quit = 0; !quit; ) {
        struct sockaddr_in peer;
        socklen_t pl = sizeof peer;
        int c = accept(ls, (struct sockaddr *)&peer, &pl);
        char req[1024];
        size_t got = 0;
        ssize_t n;
        while (got < sizeof req - 1 && (n = read(c, req + got, sizeof req - 1 - got)) > 0) {   /* DT-29: loop */
            got += (size_t)n;
            req[got] = 0;
            if (strstr(req, "\r\n\r\n")) break;              /* end of the request headers */
        }
        char path[64] = "/";
        sscanf(req, "GET %63s", path);
        size_t len = 0;
        if (strcmp(path, "/quit") == 0) { quit = 1; len = (size_t)snprintf(out, sizeof out, "bye\n"); }
        else if (strcmp(path, "/meminfo") == 0) add_file(&len, "/proc/meminfo", 6);
        else if (strcmp(path, "/net") == 0) {
            static const char *names[256] = { [1] = "icmp", [6] = "tcp", [17] = "udp", [255] = "non-ip" };
            for (unsigned k = 0; k < 256; k++) {
                unsigned long v = map_get(map, k);
                if (v) len += (size_t)snprintf(out + len, sizeof out - len, "%s %lu\n", names[k] ? names[k] : "other", v);
            }
        } else {
            struct utsname u;
            uname(&u);
            len += (size_t)snprintf(out, sizeof out, "%s %s on %s\nuptime: ", u.sysname, u.release, u.machine);
            add_file(&len, "/proc/uptime", 1);
            len += (size_t)snprintf(out + len, sizeof out - len, "loadavg: ");
            add_file(&len, "/proc/loadavg", 1);
        }
        char hdr[128];
        int hl = snprintf(hdr, sizeof hdr, "HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\nContent-Length: %zu\r\n\r\n", len);
        if (write(c, hdr, (size_t)hl) != hl || write(c, out, len) != (ssize_t)len) perror("write");
        close(c);
        printf("statusd: served %s to %s:%u\n", path, inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));
        fflush(stdout);
    }
    return 0;
}
