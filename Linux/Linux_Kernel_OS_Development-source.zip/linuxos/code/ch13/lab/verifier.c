// file: lab/verifier.c
/* Load the same program without the NULL check and show why the verifier refuses it. */
#include <errno.h>
#include <stdio.h>
#include "bpfprog.h"

int main(void) {
    static char log[65536];
    int map = create_counter_map();
    int prog = load_counter_prog(map, 0, log, sizeof log);
    printf("BPF_PROG_LOAD without the NULL check: %s (errno %d, EACCES: refused by the verifier)\n", prog < 0 ? "rejected" : "accepted", errno);
    char *p = log, *line;
    while ((line = strsep(&p, "\n")))                            /* the last few lines tell the story */
        if (strstr(line, "map_lookup") || strstr(line, "invalid mem") || strstr(line, "R0=") || strstr(line, "processed"))
            printf("  %s\n", line);
    return 0;
}
