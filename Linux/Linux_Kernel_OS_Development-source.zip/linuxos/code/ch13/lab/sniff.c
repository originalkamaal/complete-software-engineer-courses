// file: lab/sniff.c
/* sniff N: print N frames seen on any interface. */
#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>

int main(int argc, char **argv) {
    int count = atoi(argv[1]);
    int s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (s < 0) { perror("socket"); return 1; }
    unsigned char f[2048];
    for (int i = 0; i < count; i++) {
        struct sockaddr_ll from;
        socklen_t fl = sizeof from;
        ssize_t n = recvfrom(s, f, sizeof f, 0, (struct sockaddr *)&from, &fl);
        if (n < 14 || from.sll_ifindex == 1) { i--; continue; }   /* skip loopback */
        struct ether_header *eh = (struct ether_header *)f;
        printf("%s %4zd B  ", from.sll_pkttype == PACKET_OUTGOING ? "out" : "in ", n);
        if (ntohs(eh->ether_type) == ETHERTYPE_ARP) { printf("ARP\n"); continue; }
        if (ntohs(eh->ether_type) != ETHERTYPE_IP) { printf("ethertype 0x%04x\n", ntohs(eh->ether_type)); continue; }
        struct iphdr *ip = (struct iphdr *)(f + 14);
        char src[16], dst[16];
        inet_ntop(AF_INET, &ip->saddr, src, sizeof src);
        inet_ntop(AF_INET, &ip->daddr, dst, sizeof dst);
        unsigned char *l4 = f + 14 + ip->ihl * 4;
        if (ip->protocol == IPPROTO_TCP) {
            struct tcphdr *t = (struct tcphdr *)l4;
            int payload = ntohs(ip->tot_len) - ip->ihl * 4 - t->doff * 4;
            printf("TCP %s:%u > %s:%u [%s%s%s%s] seq %u len %d\n", src, ntohs(t->source), dst, ntohs(t->dest),
                   t->syn ? "S" : "", t->fin ? "F" : "", t->psh ? "P" : "", t->ack ? "." : "", ntohl(t->seq), payload);
        } else if (ip->protocol == IPPROTO_UDP) {
            struct udphdr *u = (struct udphdr *)l4;
            printf("UDP %s:%u > %s:%u len %u\n", src, ntohs(u->source), dst, ntohs(u->dest), ntohs(u->len) - 8);
        } else {
            printf("IP proto %u %s > %s\n", ip->protocol, src, dst);
        }
        fflush(stdout);
    }
    return 0;
}
