# file: guest-stream/run-stream.sh
ip link set lo up
/bin/stream
