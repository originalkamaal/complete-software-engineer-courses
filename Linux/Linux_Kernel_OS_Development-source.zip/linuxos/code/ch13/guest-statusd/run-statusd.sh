# file: guest-statusd/run-statusd.sh
. /net-up.sh
/bin/statusd
