// file: new/include/kernel.h
#pragma once
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ---- port I/O and CPU control ---- */
static inline void outb(uint16_t port, uint8_t v) { __asm__ volatile("outb %0, %1" : : "a"(v), "Nd"(port)); }
static inline uint8_t inb(uint16_t port) { uint8_t v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(port)); return v; }
static inline void io_wait(void) { outb(0x80, 0); }                 /* a write to an unused port: a short delay */
static inline void cli(void) { __asm__ volatile("cli" ::: "memory"); }
static inline void sti(void) { __asm__ volatile("sti" ::: "memory"); }
static inline void hlt(void) { __asm__ volatile("hlt" ::: "memory"); }
static inline uint64_t read_cr2(void) { uint64_t v; __asm__ volatile("mov %%cr2, %0" : "=r"(v)); return v; }
static inline void qemu_exit(uint8_t code) { outb(0xF4, code); }   /* QEMU exits with status (code << 1) | 1 */

/* ---- console ---- */
void serial_init(void);
void serial_putc(char c);
void serial_enable_rx_irq(void);
int  serial_getc(void);                     /* blocks (sleeping) until a byte arrives */
extern volatile uint64_t serial_irq_count, serial_rx_bytes;
void vga_clear(void);
void vga_putc(char c);
void kprintf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int  ksnprintf(char *buf, size_t size, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
int  kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
_Noreturn void panic(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
void print_backtrace(void);

/* ---- boot information ---- */
void multiboot2_parse(uint32_t magic, uintptr_t info);
extern const char *kernel_cmdline;
extern uint64_t usable_ram_bytes;
bool cmdline_get(const char *key, char *out, size_t n);

/* ---- interrupts ---- */
struct trap_frame {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8, rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t vector, error;
    uint64_t rip, cs, rflags, rsp, ss;                               /* pushed by the CPU */
};
typedef void (*irq_handler_t)(struct trap_frame *);
void idt_init(void);
void irq_register(int irq, irq_handler_t handler);
void pic_init(void);
void pic_unmask(int irq);
void pic_eoi(int irq);
void timer_init(unsigned hz);
extern volatile uint64_t ticks;
extern unsigned timer_hz;
uint8_t rtc_read(uint8_t reg);

/* ---- kernel self-tests, registered in the .ktests linker section ---- */
struct ktest { const char *name; void (*fn)(void); } __attribute__((aligned(16)));
#define KTEST(n)                                                                              \
    static void ktest_##n(void);                                                              \
    __attribute__((used, section(".ktests"))) static const struct ktest ktest_entry_##n = {   \
        #n, ktest_##n};                                                                       \
    static void ktest_##n(void)

/* ---- library ---- */
void *memset(void *dst, int c, size_t n);
void *memcpy(void *restrict dst, const void *restrict src, size_t n);
void *memmove(void *dst, const void *src, size_t n);
int memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
int strncmp(const char *a, const char *b, size_t n);

#define KASSERT(cond) do { if (!(cond)) panic("assertion failed: %s at %s:%d", #cond, __FILE__, __LINE__); } while (0)
extern char _kernel_start[], _kernel_end[];
