; file: new/arch/isr.asm
; Interrupt entry stubs for vectors 0-47 and the common path into C.
bits 64
section .text
extern interrupt_dispatch

%macro ISR_NOERR 1                ; the CPU pushed no error code: push a 0 so every frame has the same layout
isr%1:
    push 0
    push %1
    jmp isr_common
%endmacro
%macro ISR_ERR 1                  ; the CPU already pushed an error code
isr%1:
    push %1
    jmp isr_common
%endmacro

%assign v 0
%rep 48
  %if v == 8 || (v >= 10 && v <= 14) || v == 17 || v == 21 || v == 29 || v == 30
    ISR_ERR v
  %else
    ISR_NOERR v
  %endif
  %assign v v + 1
%endrep

isr_common:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    cld                           ; the System V ABI requires DF = 0 on function entry
    mov rdi, rsp                  ; argument: pointer to the struct trap_frame we just built
    call interrupt_dispatch
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    add rsp, 16                   ; drop vector and error code
    iretq                         ; pops rip, cs, rflags, rsp, ss: resumes the interrupted code

section .rodata
global isr_table
isr_table:
%assign v 0
%rep 48
    dq isr %+ v
  %assign v v + 1
%endrep
