; file: os/arch/boot.asm
section .multiboot2
align 8
mb2_start:
    dd 0xE85250D6, 0, mb2_end - mb2_start, -(0xE85250D6 + (mb2_end - mb2_start))
    dw 0, 0
    dd 8
mb2_end:

section .bss
align 4096
global boot_pml4
boot_pml4: resb 4096
boot_pdpt: resb 4096
boot_pd:   resb 4096
stack_bottom: resb 16384
global stack_top
stack_top:

section .rodata
align 8
gdt64:
    dq 0                                              ; 0x00: null
    dq (1<<43) | (1<<44) | (1<<47) | (1<<53)          ; 0x08: kernel code, 64-bit
    dq (1<<41) | (1<<44) | (1<<47)                    ; 0x10: kernel data
gdt64_ptr:
    dw $ - gdt64 - 1
    dq gdt64

section .text
bits 32
global _start
extern kmain
_start:
    mov esp, stack_top
    mov edi, eax                  ; Multiboot2 magic -> first argument (rdi), upper half zeroed below
    mov esi, ebx                  ; boot information pointer -> second argument (rsi)
    ; PML4[0] -> PDPT, PDPT[0] -> PD, PD[i] = i * 2 MiB (present | writable | huge)
    mov eax, boot_pdpt
    or eax, 0b11
    mov [boot_pml4], eax
    mov eax, boot_pd
    or eax, 0b11
    mov [boot_pdpt], eax
    xor ecx, ecx
.map:
    mov eax, ecx
    shl eax, 21                   ; i * 2 MiB
    or eax, 0b10000011
    mov [boot_pd + ecx * 8], eax
    inc ecx
    cmp ecx, 512
    jne .map
    mov eax, boot_pml4
    mov cr3, eax
    mov eax, cr4
    or eax, 1 << 5                ; CR4.PAE
    mov cr4, eax
    mov ecx, 0xC0000080           ; IA32_EFER
    rdmsr
    or eax, 1 << 8                ; EFER.LME
    wrmsr
    mov eax, cr0
    or eax, 1 << 31               ; CR0.PG: paging on -> long mode active (compatibility mode)
    mov cr0, eax
    lgdt [gdt64_ptr]
    jmp 0x08:long_mode            ; far jump loads CS with the 64-bit code segment

bits 64
long_mode:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    xor ax, ax
    mov fs, ax
    mov gs, ax
    mov edi, edi                  ; zero-extend the two 32-bit arguments
    mov esi, esi
    xor ebp, ebp                  ; terminates frame-pointer stack traces
    call kmain
.hang:
    cli
    hlt
    jmp .hang
