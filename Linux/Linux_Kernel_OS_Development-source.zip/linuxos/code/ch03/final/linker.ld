# file: new/linker.ld
ENTRY(_start)
SECTIONS {
    . = 1M;
    _kernel_start = .;
    .boot   : { KEEP(*(.multiboot2)) }
    .text   : ALIGN(4K) { *(.text*) }
    .rodata : ALIGN(4K) {
        *(.rodata*)
        . = ALIGN(16);
        __ktests_start = .;
        KEEP(*(.ktests))
        __ktests_end = .;
    }
    .data   : ALIGN(4K) { *(.data*) }
    .bss    : ALIGN(4K) { *(COMMON) *(.bss*) }
    _kernel_end = .;
    /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) }
}
