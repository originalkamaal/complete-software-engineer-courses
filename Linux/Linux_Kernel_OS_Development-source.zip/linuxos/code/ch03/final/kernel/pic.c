// file: new/kernel/pic.c
/* The legacy 8259A PIC pair: master at ports 0x20/0x21, slave at 0xA0/0xA1, slave wired to master's IRQ 2. */
#include <kernel.h>

#define PIC1_CMD 0x20
#define PIC1_DATA 0x21
#define PIC2_CMD 0xA0
#define PIC2_DATA 0xA1

void pic_init(void) {
    outb(PIC1_CMD, 0x11);  io_wait();      /* ICW1: start initialisation, ICW4 will follow */
    outb(PIC2_CMD, 0x11);  io_wait();
    outb(PIC1_DATA, 32);   io_wait();      /* ICW2: master IRQ 0-7  -> vectors 32-39 */
    outb(PIC2_DATA, 40);   io_wait();      /*       slave  IRQ 8-15 -> vectors 40-47 */
    outb(PIC1_DATA, 0x04); io_wait();      /* ICW3: master has a slave on IRQ 2 */
    outb(PIC2_DATA, 0x02); io_wait();      /*       slave's cascade identity is 2 */
    outb(PIC1_DATA, 0x01); io_wait();      /* ICW4: 8086 mode */
    outb(PIC2_DATA, 0x01); io_wait();
    outb(PIC1_DATA, 0xFF);                 /* mask everything; drivers unmask their own line */
    outb(PIC2_DATA, 0xFF);
}

void pic_unmask(int irq) {
    if (irq >= 8) {
        outb(PIC2_DATA, inb(PIC2_DATA) & ~(1 << (irq - 8)));
        irq = 2;                           /* the slave's interrupts arrive through master line 2 */
    }
    outb(PIC1_DATA, inb(PIC1_DATA) & ~(1 << irq));
}

void pic_eoi(int irq) {
#ifndef NO_EOI                             /* experiment switch for DT-6 */
    if (irq >= 8) outb(PIC2_CMD, 0x20);
    outb(PIC1_CMD, 0x20);
#else
    (void)irq;
#endif
}
