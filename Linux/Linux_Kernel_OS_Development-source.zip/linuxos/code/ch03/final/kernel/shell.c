// file: proj/kernel/shell.c
#include <kernel.h>

static size_t read_line(char *buf, size_t size) {
    size_t n = 0;
    kprintf("kshell> ");
    for (;;) {
        int c = serial_getc();
        if (c == '\r' || c == '\n') { kprintf("\n"); break; }
        if ((c == 0x7F || c == '\b') && n > 0) { n--; kprintf("\b \b"); continue; }   /* backspace */
        if (c == 0x15) { while (n) { n--; kprintf("\b \b"); } continue; }            /* Ctrl-U */
        if (c >= 0x20 && c < 0x7F && n + 1 < size) { buf[n++] = (char)c; kprintf("%c", c); }
    }
    buf[n] = '\0';
    return n;
}

static void cmd_help(const char *arg);
static void cmd_uptime(const char *arg) {
    (void)arg;
    uint64_t t = ticks;
    kprintf("up %lu.%02lu s (%lu ticks at %u Hz)\n", t / timer_hz, t % timer_hz * 100 / timer_hz, t, timer_hz);
}
static void cmd_mem(const char *arg) {
    (void)arg;
    kprintf("usable RAM %lu KiB; kernel image %p-%p (%lu KiB)\n", usable_ram_bytes >> 10, (void *)_kernel_start,
            (void *)_kernel_end, (uint64_t)(_kernel_end - _kernel_start) >> 10);
}
static void cmd_echo(const char *arg) { kprintf("%s\n", arg); }
static void cmd_int3(const char *arg) { (void)arg; __asm__ volatile("int3"); }
static void cmd_crash(const char *arg) {
    uint64_t addr = 0;
    for (const char *p = arg; *p; p++) {                         /* parse a hex address, default 0xdead0000 */
        int d = *p >= '0' && *p <= '9' ? *p - '0' : *p >= 'a' && *p <= 'f' ? *p - 'a' + 10 : -1;
        if (d >= 0) addr = addr * 16 + (uint64_t)d;
    }
    if (!addr) addr = 0xdead0000;
    kprintf("writing to 0x%lx...\n", addr);
    *(volatile uint64_t *)addr = 1;
}
static void cmd_irqs(const char *arg) {
    (void)arg;
    kprintf("timer ticks %lu, serial interrupts %lu, serial bytes %lu\n", ticks, serial_irq_count, serial_rx_bytes);
}
static void cmd_halt(const char *arg) { (void)arg; kprintf("halting\n"); qemu_exit(0x10); }

static const struct { const char *name, *help; void (*fn)(const char *); } commands[] = {
    {"help", "list commands", cmd_help},
    {"uptime", "time since the timer started", cmd_uptime},
    {"mem", "memory summary", cmd_mem},
    {"echo", "print the arguments", cmd_echo},
    {"int3", "execute a breakpoint (handled, continues)", cmd_int3},
    {"crash", "write to an unmapped address: crash [hexaddr]", cmd_crash},
    {"irqs", "interrupt counters", cmd_irqs},
    {"halt", "power off (exit QEMU)", cmd_halt},
};
#define NCOMMANDS (sizeof commands / sizeof commands[0])

static void cmd_help(const char *arg) {
    (void)arg;
    for (size_t i = 0; i < NCOMMANDS; i++) kprintf("  %-8s %s\n", commands[i].name, commands[i].help);
}

void shell_run(void) {
    kprintf("kshell ready; type 'help'\n");
    char line[128];
    for (;;) {
        if (!read_line(line, sizeof line)) continue;
        char *arg = line;
        while (*arg && *arg != ' ') arg++;
        if (*arg) *arg++ = '\0';
        size_t i;
        for (i = 0; i < NCOMMANDS; i++)
            if (strncmp(line, commands[i].name, 16) == 0) { commands[i].fn(arg); break; }
        if (i == NCOMMANDS) kprintf("unknown command '%s'\n", line);
    }
}
