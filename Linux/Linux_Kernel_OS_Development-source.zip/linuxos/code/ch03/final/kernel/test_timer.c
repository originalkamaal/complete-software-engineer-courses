// file: new/kernel/test_timer.c
#include <kernel.h>

static void wait_for_rtc_second(void) {
    uint8_t s = rtc_read(0x00);
    while (rtc_read(0x00) == s) { }
}

KTEST(timer) {
    wait_for_rtc_second();
    uint64_t t0 = ticks;
    wait_for_rtc_second();
    uint64_t t1 = ticks;
    kprintf("timer interrupts during one RTC second: %lu (PIT programmed for %u Hz); %lu since boot\n",
            t1 - t0, timer_hz, t1);
    KASSERT(t1 - t0 >= timer_hz - 2 && t1 - t0 <= timer_hz + 2);
}
