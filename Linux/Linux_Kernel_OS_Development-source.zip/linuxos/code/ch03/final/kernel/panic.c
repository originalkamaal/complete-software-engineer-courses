// file: proj/kernel/panic.c
#include <kernel.h>

struct frame { struct frame *next; uintptr_t ret; };

void print_backtrace(void) {
    struct frame *f;
    __asm__ volatile("mov %%rbp, %0" : "=r"(f));
    kprintf("backtrace (symbolise with: addr2line -f -e kernel.elf <addresses>):\n");
    for (int depth = 0; f && depth < 16; depth++, f = f->next) {
        if ((uintptr_t)f < (uintptr_t)_kernel_start || (uintptr_t)f >= 0x40000000) break;   /* sanity check */
        kprintf("  #%d %p\n", depth, (void *)f->ret);
    }
}

_Noreturn void panic(const char *fmt, ...) {
    char buf[256];
    va_list ap; va_start(ap, fmt);
    kvsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    __asm__ volatile("cli");
    kprintf("\nKERNEL PANIC: %s\n", buf);
    print_backtrace();
    qemu_exit(0x11);
    for (;;) __asm__ volatile("hlt");
}
