// file: new/kernel/multiboot2.c
#include <kernel.h>

struct mb2_tag { uint32_t type, size; };
struct mb2_mmap_entry { uint64_t base, length; uint32_t type, reserved; };
struct mb2_tag_mmap { uint32_t type, size, entry_size, entry_version; struct mb2_mmap_entry entries[]; };

const char *kernel_cmdline = "";
uint64_t usable_ram_bytes;
struct mb2_mmap_entry usable_regions[16];
int usable_region_count;

void multiboot2_parse(uint32_t magic, uintptr_t info) {
    if (magic != 0x36D76289) panic("not started by a Multiboot2 loader (magic 0x%x)", magic);
    for (struct mb2_tag *t = (struct mb2_tag *)(info + 8); t->type != 0;
         t = (struct mb2_tag *)((uintptr_t)t + ((t->size + 7) & ~7u))) {
        if (t->type == 1) kernel_cmdline = (const char *)(t + 1);
        if (t->type == 6) {
            struct mb2_tag_mmap *m = (struct mb2_tag_mmap *)t;
            int n = (int)((m->size - sizeof *m) / m->entry_size);
            for (int i = 0; i < n; i++) {
                struct mb2_mmap_entry *e = (struct mb2_mmap_entry *)((uintptr_t)m->entries + (uintptr_t)i * m->entry_size);
                if (e->type == 1 && usable_region_count < 16) {
                    usable_regions[usable_region_count++] = *e;
                    usable_ram_bytes += e->length;
                }
            }
        }
    }
}

/* Find "key=value" in the command line; copy value into out. */
bool cmdline_get(const char *key, char *out, size_t n) {
    size_t klen = strlen(key);
    for (const char *p = kernel_cmdline; *p; ) {
        while (*p == ' ') p++;
        if (strncmp(p, key, klen) == 0 && p[klen] == '=') {
            p += klen + 1;
            size_t i = 0;
            while (*p && *p != ' ' && i + 1 < n) out[i++] = *p++;
            out[i] = '\0';
            return true;
        }
        while (*p && *p != ' ') p++;
    }
    return false;
}
