// file: new/kernel/main.c
#include <kernel.h>

extern const struct ktest __ktests_start[], __ktests_end[];

__attribute__((weak)) void shell_run(void) { kprintf("no shell in this build\n"); }

static void run_test(const char *name) {
    for (const struct ktest *t = __ktests_start; t < __ktests_end; t++) {
        if (strncmp(t->name, name, 64) == 0) {
            kprintf("== test %s ==\n", t->name);
            t->fn();
            kprintf("== test %s passed ==\n", t->name);
            return;
        }
    }
    kprintf("unknown test '%s'; available:", name);
    for (const struct ktest *t = __ktests_start; t < __ktests_end; t++) kprintf(" %s", t->name);
    kprintf("\n");
}

void kmain(uint32_t magic, uintptr_t info) {
    serial_init();
    vga_clear();
    multiboot2_parse(magic, info);
    kprintf("hobby os: %lu MiB usable, command line \"%s\"\n", usable_ram_bytes >> 20, kernel_cmdline);
    idt_init();
    pic_init();
    timer_init(100);
    serial_enable_rx_irq();
    sti();
    char name[32];
    if (cmdline_get("test", name, sizeof name)) run_test(name);
    else shell_run();
    qemu_exit(0x10);
}
