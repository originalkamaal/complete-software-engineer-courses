// file: new/kernel/console.c
#include <kernel.h>

#define COM1 0x3F8

void serial_init(void) {
    outb(COM1 + 1, 0x00);         /* disable UART interrupts (for now) */
    outb(COM1 + 3, 0x80);         /* DLAB = 1: next two ports are the baud divisor */
    outb(COM1 + 0, 0x01);         /* divisor 1 -> 115200 baud */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);         /* 8 data bits, no parity, 1 stop bit; DLAB = 0 */
    outb(COM1 + 2, 0xC7);         /* enable and clear FIFOs */
    outb(COM1 + 4, 0x0B);         /* DTR, RTS, OUT2 (OUT2 connects the UART's interrupt line to the PIC) */
}

void serial_putc(char c) {
    if (c == '\n') serial_putc('\r');
    while (!(inb(COM1 + 5) & 0x20)) { }   /* wait for an empty transmit holding register */
    outb(COM1, (uint8_t)c);
}

/* ---- receive path: IRQ 4 fills a ring buffer, serial_getc empties it ---- */
#define RX_SIZE 256                       /* a power of two, so the indices can wrap freely */
static char rx_buf[RX_SIZE];
static volatile uint32_t rx_head, rx_tail; /* head: written only by the IRQ handler; tail: only by serial_getc */
volatile uint64_t serial_irq_count, serial_rx_bytes;

static void serial_irq(struct trap_frame *f) {
    (void)f;
    serial_irq_count++;
    while (inb(COM1 + 5) & 0x01) {        /* data ready: drain everything the FIFO holds */
        char c = (char)inb(COM1);
        serial_rx_bytes++;
        if (rx_head - rx_tail < RX_SIZE) rx_buf[rx_head++ % RX_SIZE] = c;   /* full buffer: drop the byte */
    }
}

void serial_enable_rx_irq(void) {
    irq_register(4, serial_irq);
    outb(COM1 + 1, 0x01);                 /* IER: interrupt when received data is available */
    pic_unmask(4);
}

int serial_getc(void) {
    for (;;) {
        cli();
        if (rx_head != rx_tail) {
            char c = rx_buf[rx_tail++ % RX_SIZE];
            sti();
            return (unsigned char)c;
        }
        __asm__ volatile("sti; hlt" ::: "memory");   /* DT-7: no interrupt can arrive between these two */
    }
}

static volatile uint16_t *const vga = (uint16_t *)0xB8000;
static int row, col;

void vga_clear(void) {
    for (int i = 0; i < 80 * 25; i++) vga[i] = 0x0720;   /* space, light grey on black */
    row = col = 0;
}

void vga_putc(char c) {
    if (c == '\n') { col = 0; row++; }
    else if (c == '\b') { if (col) vga[row * 80 + --col] = 0x0720; }
    else { vga[row * 80 + col] = (uint16_t)(0x0700 | (uint8_t)c); if (++col == 80) { col = 0; row++; } }
    if (row == 25) {                                      /* scroll up one line */
        memmove((void *)vga, (const void *)(vga + 80), 80 * 24 * 2);
        for (int i = 0; i < 80; i++) vga[24 * 80 + i] = 0x0720;
        row = 24;
    }
}
