// file: proj/kernel/printf.c
#include <kernel.h>

struct out { char *buf; size_t size, len; };

static void put(struct out *o, char c) {
    if (o->len + 1 < o->size) o->buf[o->len] = c;
    o->len++;
}

static void put_num(struct out *o, unsigned long long v, unsigned base, bool neg, int width, char pad, bool upper, bool left) {
    char tmp[24];
    const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int n = 0;
    do { tmp[n++] = digits[v % base]; v /= base; } while (v);
    if (neg) tmp[n++] = '-';
    int len = n;
    if (left) { while (n) put(o, tmp[--n]); for (int i = len; i < width; i++) put(o, ' '); return; }
    if (pad == '0' && neg) { put(o, '-'); n--; len--; width--; }
    for (int i = len; i < width; i++) put(o, pad);
    while (n) put(o, tmp[--n]);
}

int kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap) {
    struct out o = { buf, size, 0 };
    for (; *fmt; fmt++) {
        if (*fmt != '%') { put(&o, *fmt); continue; }
        fmt++;
        char pad = ' ';
        bool left = false;
        int width = 0, longs = 0;
        for (;; fmt++) {
            if (*fmt == '-') left = true;
            else if (*fmt == '0') pad = '0';
            else break;
        }
        while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
        while (*fmt == 'l') { longs++; fmt++; }
        if (*fmt == 'z') { longs = 1; fmt++; }
        switch (*fmt) {
        case 'd': case 'i': {
            long long v = longs ? va_arg(ap, long long) : va_arg(ap, int);
            put_num(&o, v < 0 ? -(unsigned long long)v : (unsigned long long)v, 10, v < 0, width, pad, false, left);
            break;
        }
        case 'u': case 'x': case 'X': {
            unsigned long long v = longs ? va_arg(ap, unsigned long long) : va_arg(ap, unsigned);
            put_num(&o, v, *fmt == 'u' ? 10 : 16, false, width, pad, *fmt == 'X', left);
            break;
        }
        case 'p':
            put(&o, '0'); put(&o, 'x');
            put_num(&o, (uintptr_t)va_arg(ap, void *), 16, false, 16, '0', false, false);
            break;
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            size_t len = strlen(s);
            if (!left) for (size_t i = len; i < (size_t)width; i++) put(&o, ' ');
            while (*s) put(&o, *s++);
            if (left) for (size_t i = len; i < (size_t)width; i++) put(&o, ' ');
            break;
        }
        case 'c': put(&o, (char)va_arg(ap, int)); break;
        case '%': put(&o, '%'); break;
        default: put(&o, '%'); put(&o, *fmt); break;
        }
    }
    if (size) buf[o.len < size ? o.len : size - 1] = '\0';
    return (int)o.len;
}

int ksnprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int n = kvsnprintf(buf, size, fmt, ap);
    va_end(ap);
    return n;
}

void kprintf(const char *fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt);
    kvsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    for (char *p = buf; *p; p++) { serial_putc(*p); vga_putc(*p); }
}
