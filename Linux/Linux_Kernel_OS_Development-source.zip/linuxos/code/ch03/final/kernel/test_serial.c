// file: new/kernel/test_serial.c
#include <kernel.h>

KTEST(echo) {
    char line[80];
    size_t n = 0;
    for (;;) {
        int c = serial_getc();
        if (c == '\n' || c == '\r') break;
        if (n + 1 < sizeof line) line[n++] = (char)c;
    }
    line[n] = '\0';
    for (size_t i = 0; i < n / 2; i++) { char t = line[i]; line[i] = line[n - 1 - i]; line[n - 1 - i] = t; }
    kprintf("received %zu characters, reversed: \"%s\"\n", n, line);
    kprintf("%lu bytes arrived in %lu serial interrupts\n", serial_rx_bytes, serial_irq_count);
}
