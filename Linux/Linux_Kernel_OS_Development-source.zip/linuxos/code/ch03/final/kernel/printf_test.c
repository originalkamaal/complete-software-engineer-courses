// file: proj/kernel/printf_test.c
/* Host-side test: build kernel/printf.c into a normal program and compare with glibc's snprintf. */
#ifdef HOST_TEST
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int ksnprintf(char *buf, size_t size, const char *fmt, ...);
void serial_putc(char c) { (void)c; }                /* stubs: kprintf's output functions are kernel-only */
void vga_putc(char c) { (void)c; }

int main(void) {
    const char *fmts[] = {"[%d]", "[%5d]", "[%-5d]", "[%05d]", "[%x]", "[%08x]", "[%X]", "[%s]", "[%-8s|]", "[%8s]",
                          "[%c]", "[%u]", "[%lld]", "[%llu]", "[%%]"};
    srand(2);
    int checked = 0;
    for (int trial = 0; trial < 20000; trial++) {
        const char *f = fmts[rand() % 15];
        char a[128], b[128];
        int v = rand() - RAND_MAX / 2;
        long long big = ((long long)rand() << 32) ^ rand();
        const char *s = (const char *[]){"ok", "", "kernel", "hobby os!"}[rand() % 4];
        int na, nb;
        if (strstr(f, "s")) { na = ksnprintf(a, sizeof a, f, s); nb = snprintf(b, sizeof b, f, s); }
        else if (strstr(f, "ll")) { na = ksnprintf(a, sizeof a, f, big); nb = snprintf(b, sizeof b, f, big); }
        else if (strstr(f, "c")) { na = ksnprintf(a, sizeof a, f, 'A' + v % 26 + 26 * (v < 0)); nb = snprintf(b, sizeof b, f, 'A' + v % 26 + 26 * (v < 0)); }
        else { na = ksnprintf(a, sizeof a, f, v); nb = snprintf(b, sizeof b, f, v); }
        if (na != nb || strcmp(a, b) != 0) { printf("MISMATCH for %s: kernel '%s' (%d) vs libc '%s' (%d)\n", f, a, na, b, nb); return 1; }
        checked++;
    }
    char small[6];
    int n = ksnprintf(small, sizeof small, "%s", "truncated output");
    printf("%d random format cases match glibc; truncation: '%s' (would need %d chars)\n", checked, small, n);
    return 0;
}
#endif
