// file: new/kernel/timer.c
#include <kernel.h>

volatile uint64_t ticks;
unsigned timer_hz;

static void timer_irq(struct trap_frame *f) {
    (void)f;
    ticks++;
}

void timer_init(unsigned hz) {
    unsigned divisor = 1193182 / hz;
    timer_hz = hz;
    outb(0x43, 0x36);                      /* channel 0, low byte then high byte, mode 3 (square wave) */
    outb(0x40, (uint8_t)divisor);
    outb(0x40, (uint8_t)(divisor >> 8));
    irq_register(0, timer_irq);
    pic_unmask(0);
}

/* The CMOS real-time clock: an independent clock to check the PIT against. */
uint8_t rtc_read(uint8_t reg) {
    while (outb(0x70, 0x0A), inb(0x71) & 0x80) { }     /* wait while an update is in progress */
    outb(0x70, reg);
    return inb(0x71);
}
