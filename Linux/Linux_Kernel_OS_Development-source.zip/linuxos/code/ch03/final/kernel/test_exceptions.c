// file: new/kernel/test_exceptions.c
#include <kernel.h>

KTEST(breakpoint) {
    __asm__ volatile("int3");                         /* vector 3: a "trap" - RIP already points past it */
    kprintf("execution continued after int3\n");
}

KTEST(pagefault) {
    volatile uint64_t *p = (volatile uint64_t *)0x80000000;   /* 2 GiB: outside our 1 GiB identity map */
    kprintf("reading %p...\n", (void *)p);
    (void)*p;
}

KTEST(divide) {
    __asm__ volatile("xor %%edx, %%edx; mov $7, %%eax; xor %%ecx, %%ecx; div %%ecx" ::: "rax", "rcx", "rdx");
}

KTEST(invalid_opcode) {
    __asm__ volatile("ud2");
}
