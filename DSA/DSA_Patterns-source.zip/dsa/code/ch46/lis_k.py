# file: lis_k.py
from check import stress, rand_list
from segtree import SegTree

def lis_bounded(a, k):
    if not a:
        return 0
    V = max(a) + 1
    st = SegTree([0] * V, max, 0)
    for x in a:
        best = st.query(max(0, x - k), x) + 1          # values in [x-k, x-1]
        if best > st.get(x):
            st.update(x, best)
    return st.query(0, V)

def brute(a, k):
    dp = [1] * len(a)
    for i in range(len(a)):
        for j in range(i):
            if 0 < a[i] - a[j] <= k:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp, default=0)

print(stress(lis_bounded, brute, lambda rng: (rand_list(rng, 0, 15, 12), rng.randint(1, 5))))
