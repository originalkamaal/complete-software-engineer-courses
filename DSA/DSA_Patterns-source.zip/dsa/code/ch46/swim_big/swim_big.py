# file: swim_big/swim_big.py
import random
import time
from swim import by_binary_search, by_dijkstra, by_dsu

rng = random.Random(43)
n = 300
vals = rng.sample(range(n * n), n * n)
grid = [vals[i * n:(i + 1) * n] for i in range(n)]
answers = {}
for name, f in (("binary search + BFS", by_binary_search), ("Dijkstra (bottleneck)", by_dijkstra), ("sorted cells + DSU", by_dsu)):
    t = time.perf_counter()
    answers[name] = f(grid)
    print(f"{name:>22}: t = {answers[name]:,} in {time.perf_counter() - t:.2f} s")
print("all agree:", len(set(answers.values())) == 1)
