# file: hire.py
import heapq
from fractions import Fraction
from itertools import combinations
from check import stress

def min_cost(quality, wage, k):
    workers = sorted(zip(quality, wage), key=lambda w: Fraction(w[1], w[0]))
    heap, qsum, best = [], 0, None
    for q, w in workers:                                 # ratio is non-decreasing: current worker sets the rate
        heapq.heappush(heap, -q); qsum += q
        if len(heap) > k:
            qsum += heapq.heappop(heap)                  # drop the largest quality
        if len(heap) == k:
            cost = Fraction(w, q) * qsum
            best = cost if best is None else min(best, cost)
    return best

def brute(quality, wage, k):
    best = None
    for grp in combinations(range(len(quality)), k):
        rate = max(Fraction(wage[i], quality[i]) for i in grp)
        cost = rate * sum(quality[i] for i in grp)
        best = cost if best is None else min(best, cost)
    return best

gen = lambda rng: ((q := [rng.randint(1, 10) for _ in range(rng.randint(1, 7))]), [rng.randint(1, 20) for _ in q], rng.randint(1, len(q)))
print(stress(min_cost, brute, gen))
