# file: swim.py
import heapq
from collections import deque
from check import stress
from dsu import DSU

def by_binary_search(g):
    n = len(g)
    def ok(t):                                          # BFS through cells with height <= t
        if g[0][0] > t:
            return False
        seen, q = {(0, 0)}, deque([(0, 0)])
        while q:
            r, c = q.popleft()
            if (r, c) == (n - 1, n - 1):
                return True
            for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if 0 <= nr < n and 0 <= nc < n and (nr, nc) not in seen and g[nr][nc] <= t:
                    seen.add((nr, nc)); q.append((nr, nc))
        return False
    lo, hi = 0, n * n - 1                               # first t with ok(t): ok is monotone in t
    while lo < hi:
        mid = (lo + hi) // 2
        if ok(mid): hi = mid
        else: lo = mid + 1
    return lo

def by_dijkstra(g):
    n = len(g)
    best = {(0, 0): g[0][0]}
    h = [(g[0][0], 0, 0)]
    while h:
        t, r, c = heapq.heappop(h)
        if (r, c) == (n - 1, n - 1):
            return t
        if t > best[(r, c)]:
            continue
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < n and 0 <= nc < n:
                nt = max(t, g[nr][nc])                  # path cost = maximum height on it
                if nt < best.get((nr, nc), float("inf")):
                    best[(nr, nc)] = nt; heapq.heappush(h, (nt, nr, nc))

def by_dsu(g):
    n = len(g)
    d, open_ = DSU(n * n), set()
    for t, r, c in sorted((g[r][c], r, c) for r in range(n) for c in range(n)):
        open_.add((r, c))
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if (nr, nc) in open_:
                d.union(r * n + c, nr * n + nc)
        if (0, 0) in open_ and d.same(0, n * n - 1):
            return t

def gen(rng):
    n = rng.randint(1, 6)
    vals = rng.sample(range(n * n), n * n)
    return ([vals[i * n:(i + 1) * n] for i in range(n)],)

if __name__ == "__main__":
    print(stress(by_binary_search, by_dsu, gen))
    print(stress(by_dijkstra, by_dsu, gen))
