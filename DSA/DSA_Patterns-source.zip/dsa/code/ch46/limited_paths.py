# file: limited_paths.py
from collections import deque
from check import stress
from dsu import DSU

def limited_paths(n, edges, queries):
    edges = sorted(edges, key=lambda e: e[2])
    order = sorted(range(len(queries)), key=lambda i: queries[i][2])
    d, ans, k = DSU(n), [False] * len(queries), 0
    for qi in order:
        u, v, limit = queries[qi]
        while k < len(edges) and edges[k][2] < limit:   # add every edge strictly below the limit
            d.union(edges[k][0], edges[k][1]); k += 1
        ans[qi] = d.same(u, v)
    return ans

def brute(n, edges, queries):
    out = []
    for u, v, limit in queries:
        adj = [[] for _ in range(n)]
        for a, b, w in edges:
            if w < limit:
                adj[a].append(b); adj[b].append(a)
        seen, q = {u}, deque([u])
        while q:
            x = q.popleft()
            for y in adj[x]:
                if y not in seen: seen.add(y); q.append(y)
        out.append(v in seen)
    return out

gen = lambda rng: ((n := rng.randint(1, 7)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 10)) for _ in range(rng.randint(0, 10))],
                   [(rng.randrange(n), rng.randrange(n), rng.randint(1, 11)) for _ in range(5)])
print(stress(limited_paths, brute, gen))
