# file: job_scheduling.py
import bisect
from itertools import combinations
from check import stress

def max_profit(jobs):
    jobs = sorted(jobs, key=lambda j: j[1])
    ends = [e for _, e, _ in jobs]
    best = [0] * (len(jobs) + 1)
    for i, (s, e, p) in enumerate(jobs, 1):
        k = bisect.bisect_right(ends, s, 0, i - 1)      # jobs ending at or before s (half-open intervals)
        best[i] = max(best[i - 1], best[k] + p)
    return best[-1]

def brute(jobs):
    best = 0
    for r in range(len(jobs) + 1):
        for sub in combinations(sorted(jobs), r):
            if all(a[1] <= b[0] for a, b in zip(sub, sub[1:])):
                best = max(best, sum(p for _, _, p in sub))
    return best

gen = lambda rng: ([(s := rng.randint(0, 10), s + rng.randint(1, 5), rng.randint(1, 20)) for _ in range(rng.randint(0, 8))],)
print(stress(max_profit, brute, gen))
