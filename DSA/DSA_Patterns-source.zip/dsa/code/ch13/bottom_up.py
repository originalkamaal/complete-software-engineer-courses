# file: bottom_up.py
from check import stress
from tree import TreeNode, random_tree

def is_balanced(root):
    def h(node):                                       # height, or -1 if unbalanced below
        if not node:
            return 0
        l, r = h(node.left), h(node.right)
        if l < 0 or r < 0 or abs(l - r) > 1:
            return -1
        return 1 + max(l, r)
    return h(root) >= 0

def diameter(root):                                    # longest path in edges
    best = 0
    def depth(node):
        nonlocal best
        if not node:
            return 0
        l, r = depth(node.left), depth(node.right)
        best = max(best, l + r)                        # path bending at node
        return 1 + max(l, r)                           # path continuing to parent
    depth(root)
    return best

def max_path_sum(root):                                # any node-to-node path, values may be negative
    best = float("-inf")
    def down(node):                                    # best downward path starting at node
        nonlocal best
        if not node:
            return 0
        l, r = max(down(node.left), 0), max(down(node.right), 0)   # drop negative branches
        best = max(best, node.val + l + r)
        return node.val + max(l, r)
    down(root)
    return best

# --- brute forces: enumerate all paths between pairs of nodes ---
def all_nodes(root):
    return [] if not root else [root] + all_nodes(root.left) + all_nodes(root.right)

def parents(root):
    par, stack = {root: None}, [root]
    while stack:
        n = stack.pop()
        for c in (n.left, n.right):
            if c:
                par[c] = n; stack.append(c)
    return par

def path_between(a, b, par):
    anc, x = [], a
    while x:
        anc.append(x); x = par[x]
    pos = {n: i for i, n in enumerate(anc)}
    tail, y = [], b
    while y not in pos:
        tail.append(y); y = par[y]
    return anc[:pos[y] + 1] + tail[::-1]

def brute_paths(root):
    if not root:
        return []
    par, ns = parents(root), all_nodes(root)
    return [path_between(a, b, par) for a in ns for b in ns]

def height_brute(node):
    return 0 if not node else 1 + max(height_brute(node.left), height_brute(node.right))
def balanced_brute(node):
    return not node or (abs(height_brute(node.left) - height_brute(node.right)) <= 1 and balanced_brute(node.left) and balanced_brute(node.right))

if __name__ == "__main__":
    gen = lambda rng: (random_tree(rng, rng.randint(0, 10), -5, 5),)
    print(stress(is_balanced, balanced_brute, gen))
    print(stress(diameter, lambda r: max((len(p) - 1 for p in brute_paths(r)), default=0), gen))
    print(stress(max_path_sum, lambda r: max(sum(n.val for n in p) for p in brute_paths(r)),
                 lambda rng: (random_tree(rng, rng.randint(1, 10), -5, 5),)))
