# file: serialize.py
from check import stress
from tree import random_tree, to_values
from traversals import preorder_rec, inorder_rec

def serialize(root):
    out = []
    def go(node):
        if not node:
            out.append("#"); return
        out.append(str(node.val)); go(node.left); go(node.right)
    go(root)
    return ",".join(out)

def deserialize(s):
    from tree import TreeNode
    tokens = iter(s.split(","))
    def go():
        t = next(tokens)
        if t == "#":
            return None
        node = TreeNode(int(t))
        node.left, node.right = go(), go()             # same order as serialize
        return node
    return go()

def build_pre_in(pre, ino):
    from tree import TreeNode
    pos = {v: i for i, v in enumerate(ino)}            # distinct values
    it = iter(pre)
    def go(lo, hi):                                    # subtree whose inorder is ino[lo:hi]
        if lo >= hi:
            return None
        v = next(it)
        node = TreeNode(v)
        node.left = go(lo, pos[v])
        node.right = go(pos[v] + 1, hi)
        return node
    return go(0, len(ino))

def distinct_tree(rng):
    root = random_tree(rng, rng.randint(0, 12))
    vals = iter(rng.sample(range(100), 12))
    def relabel(n):
        if n:
            n.val = next(vals); relabel(n.left); relabel(n.right)
    relabel(root)
    return root

print(stress(lambda r: to_values(deserialize(serialize(r))), to_values, lambda rng: (random_tree(rng, rng.randint(0, 12), -50, 50),)))
print(stress(lambda r: to_values(build_pre_in(preorder_rec(r), inorder_rec(r))), to_values, lambda rng: (distinct_tree(rng),)))
print(serialize(deserialize("1,2,#,#,3,4,#,#,5,#,#")))
