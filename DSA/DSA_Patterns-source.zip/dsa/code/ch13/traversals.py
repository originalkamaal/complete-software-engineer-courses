# file: traversals.py
from collections import deque
from check import stress
from tree import TreeNode, build, random_tree

def preorder_rec(root):
    return [root.val] + preorder_rec(root.left) + preorder_rec(root.right) if root else []

def inorder_rec(root):
    return inorder_rec(root.left) + [root.val] + inorder_rec(root.right) if root else []

def postorder_rec(root):
    return postorder_rec(root.left) + postorder_rec(root.right) + [root.val] if root else []

def preorder_it(root):
    out, stack = [], [root] if root else []
    while stack:
        node = stack.pop()
        out.append(node.val)
        if node.right: stack.append(node.right)        # right first so left is popped first
        if node.left: stack.append(node.left)
    return out

def inorder_it(root):
    out, stack, node = [], [], root
    while stack or node:
        while node:                                    # go as far left as possible
            stack.append(node)
            node = node.left
        node = stack.pop()
        out.append(node.val)
        node = node.right
    return out

def postorder_it(root):                                # reverse of (node, right, left) preorder
    out, stack = [], [root] if root else []
    while stack:
        node = stack.pop()
        out.append(node.val)
        if node.left: stack.append(node.left)
        if node.right: stack.append(node.right)
    return out[::-1]

def level_order(root):
    out, q = [], deque([root] if root else [])
    while q:
        level = []
        for _ in range(len(q)):                        # exactly the nodes of this depth
            node = q.popleft()
            level.append(node.val)
            if node.left: q.append(node.left)
            if node.right: q.append(node.right)
        out.append(level)
    return out

if __name__ == "__main__":
    gen = lambda rng: (random_tree(rng, rng.randint(0, 12)),)
    print(stress(preorder_it, preorder_rec, gen))
    print(stress(inorder_it, inorder_rec, gen))
    print(stress(postorder_it, postorder_rec, gen))
    root = build([3, 9, 20, None, None, 15, 7])
    print(preorder_it(root), inorder_it(root), postorder_it(root), level_order(root))
