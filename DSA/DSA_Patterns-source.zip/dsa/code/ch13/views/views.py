# file: views/views.py
import sys
import time
from collections import defaultdict, deque
from check import stress
from tree import TreeNode, random_tree

def right_view(root):
    out, q = [], deque([root] if root else [])
    while q:
        for i in range(len(q)):
            node = q.popleft()
            if node.left: q.append(node.left)
            if node.right: q.append(node.right)
        out.append(node.val)                            # last node popped on this level
    return out

def vertical_order(root):
    cols = defaultdict(list)
    stack = [(root, 0, 0)] if root else []
    while stack:
        node, row, col = stack.pop()
        cols[col].append((row, node.val))
        if node.left: stack.append((node.left, row + 1, col - 1))
        if node.right: stack.append((node.right, row + 1, col + 1))
    return [[v for _, v in sorted(cols[c])] for c in sorted(cols)]

def right_view_rec(root):
    out = []
    def go(n, d):
        if n:
            if d == len(out): out.append(None)
            out[d] = n.val                              # later (more right, same depth) overwrites
            go(n.left, d + 1); go(n.right, d + 1)
    go(root, 0)
    return out

def vertical_rec(root):
    cells = []
    def go(n, r, c):
        if n:
            cells.append((c, r, n.val)); go(n.left, r + 1, c - 1); go(n.right, r + 1, c + 1)
    go(root, 0, 0)
    out, last = [], None
    for c, r, v in sorted(cells):
        if c != last:
            out.append([]); last = c
        out[-1].append(v)
    return out

gen = lambda rng: (random_tree(rng, rng.randint(0, 15)),)
print(stress(right_view, right_view_rec, gen))
print(stress(vertical_order, vertical_rec, gen))

n = 200_000                                             # a zig-zag path: depth n
root = node = TreeNode(0)
for i in range(1, n):
    child = TreeNode(i)
    if i % 2: node.left = child
    else: node.right = child
    node = child
t = time.perf_counter()
rv, vo = right_view(root), vertical_order(root)
print(f"depth {n:,} (zig-zag, so only columns 0 and -1): right view has {len(rv):,} entries, {len(vo)} columns, in {(time.perf_counter() - t) * 1000:.0f} ms")
try:
    right_view_rec(root)
except RecursionError as e:
    print("recursive version:", type(e).__name__, "at limit", sys.getrecursionlimit())
