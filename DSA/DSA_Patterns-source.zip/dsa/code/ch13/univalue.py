# file: univalue.py
from tree import random_tree
from check import stress

def count_unival(root):
    count = 0
    def go(n):
        nonlocal count
        if not n:
            return True
        left, right = go(n.left), go(n.right)          # visit both, no short-circuit
        if left and right and all(c is None or c.val == n.val for c in (n.left, n.right)):
            count += 1
            return True
        return False
    go(root)
    return count

def brute(root):
    def vals(n):
        return [] if not n else vals(n.left) + [n.val] + vals(n.right)
    def nodes(n):
        return [] if not n else [n] + nodes(n.left) + nodes(n.right)
    return sum(len(set(vals(n))) == 1 for n in nodes(root))

print(stress(count_unival, brute, lambda rng: (random_tree(rng, rng.randint(0, 12), 0, 1),)))
