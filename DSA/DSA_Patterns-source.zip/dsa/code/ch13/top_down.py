# file: top_down.py
from collections import Counter
from check import stress
from tree import random_tree

def root_to_leaf_paths(root, target):                  # all root-to-leaf paths summing to target
    out, path = [], []
    def go(node, remain):
        if not node:
            return
        path.append(node.val)
        if not node.left and not node.right and remain == node.val:
            out.append(path[:])
        go(node.left, remain - node.val)
        go(node.right, remain - node.val)
        path.pop()                                     # backtrack
    go(root, target)
    return out

def count_good_nodes(root):                            # nodes not smaller than any ancestor
    def go(node, mx):
        if not node:
            return 0
        good = node.val >= mx
        return good + go(node.left, max(mx, node.val)) + go(node.right, max(mx, node.val))
    return go(root, float("-inf"))

def path_sum_count(root, k):                           # downward paths (any start, any end) with sum k
    seen = Counter({0: 1})
    def go(node, prefix):
        if not node:
            return 0
        prefix += node.val
        found = seen[prefix - k]
        seen[prefix] += 1
        found += go(node.left, prefix) + go(node.right, prefix)
        seen[prefix] -= 1                              # leave this root path: undo
        return found
    return go(root, 0)

def downward_paths(root):                              # brute: all root-paths' contiguous slices
    out = []
    def go(node, path):
        if not node:
            return
        path = path + [node.val]
        out.extend(path[i:] for i in range(len(path)))  # every downward path ending here
        go(node.left, path); go(node.right, path)
    go(root, [])
    return out

def leaf_paths(root):
    if not root:
        return []
    if not root.left and not root.right:
        return [[root.val]]
    return [[root.val] + p for p in leaf_paths(root.left) + leaf_paths(root.right)]

gen = lambda rng: (random_tree(rng, rng.randint(0, 10), -3, 3), rng.randint(-3, 3))
print(stress(lambda r, t: sorted(root_to_leaf_paths(r, t)), lambda r, t: sorted(p for p in leaf_paths(r) if sum(p) == t), gen))
print(stress(path_sum_count, lambda r, k: sum(sum(p) == k for p in downward_paths(r)), gen))
def good_brute(root):                                  # check each node against its whole root path
    def go(node, path):
        if not node:
            return 0
        path = path + [node.val]
        return (node.val >= max(path)) + go(node.left, path) + go(node.right, path)
    return go(root, [])
print(stress(count_good_nodes, good_brute, lambda rng: (random_tree(rng, rng.randint(0, 10)),)))
