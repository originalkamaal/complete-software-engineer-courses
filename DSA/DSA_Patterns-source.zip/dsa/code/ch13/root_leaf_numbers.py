# file: root_leaf_numbers.py
from tree import random_tree
from check import stress

def sum_numbers(root):
    def go(n, acc):
        if not n:
            return 0
        acc = acc * 10 + n.val
        if not n.left and not n.right:
            return acc
        return go(n.left, acc) + go(n.right, acc)
    return go(root, 0)

def brute(root):
    paths = []
    def dfs(n, path):
        if n:
            path = path + str(n.val)
            if not n.left and not n.right:
                paths.append(int(path))
            dfs(n.left, path)
            dfs(n.right, path)
    dfs(root, "")
    return sum(paths)

print(stress(sum_numbers, brute, lambda rng: (random_tree(rng, rng.randint(0, 10)),)))
