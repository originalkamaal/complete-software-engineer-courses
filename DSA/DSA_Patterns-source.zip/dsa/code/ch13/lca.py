# file: lca.py
from check import stress
from tree import random_tree
from bottom_up import all_nodes, parents

def lca(root, p, q):
    if root is None or root is p or root is q:
        return root
    l, r = lca(root.left, p, q), lca(root.right, p, q)
    if l and r:
        return root                                    # p and q are on different sides
    return l or r

def lca_brute(root, p, q):
    par = parents(root)
    anc = set()
    while p:
        anc.add(p); p = par[p]
    while q not in anc:
        q = par[q]
    return q

def gen(rng):
    root = random_tree(rng, rng.randint(1, 12))
    ns = all_nodes(root)
    return (root, rng.choice(ns), rng.choice(ns))

print(stress(lca, lca_brute, gen))
