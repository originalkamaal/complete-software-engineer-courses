# file: zigzag.py
from collections import deque
from tree import random_tree
from check import stress

def zigzag(root):
    out, q, left_to_right = [], deque([root] if root else []), True
    while q:
        level = [q.popleft() for _ in range(len(q))]          # exactly one level
        vals = [n.val for n in level]
        out.append(vals if left_to_right else vals[::-1])
        left_to_right = not left_to_right
        for n in level:
            q.extend(c for c in (n.left, n.right) if c)
    return out

def brute(root):
    levels = {}
    def dfs(n, d):
        if n:
            levels.setdefault(d, []).append(n.val)
            dfs(n.left, d + 1)
            dfs(n.right, d + 1)
    dfs(root, 0)
    return [levels[d] if d % 2 == 0 else levels[d][::-1] for d in sorted(levels)]

print(stress(zigzag, brute, lambda rng: (random_tree(rng, rng.randint(0, 12)),)))
