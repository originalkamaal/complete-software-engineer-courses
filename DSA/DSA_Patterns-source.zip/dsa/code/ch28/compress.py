# file: compress.py
from check import stress, rand_list
from recipe import rob, min_path, gen_grid

def rob_o1(a):
    prev2 = prev1 = 0                             # dp[i-2], dp[i-1]
    for x in a:
        prev2, prev1 = prev1, max(prev1, prev2 + x)
    return prev1

def min_path_row(grid):
    C = len(grid[0])
    row = [float("inf")] * C
    row[0] = 0
    for r in grid:
        row[0] += r[0]
        for c in range(1, C):
            row[c] = r[c] + min(row[c], row[c - 1])   # row[c] = from above (old), row[c-1] = from left (new)
    return row[-1]

print(stress(rob_o1, rob, lambda rng: (rand_list(rng, 0, 9, 12),)))
print(stress(min_path_row, min_path, lambda rng: gen_grid(rng, 6)))
