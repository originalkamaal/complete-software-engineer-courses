# file: word_break.py
from functools import cache
from check import stress, examples

def word_break_all(s, words):
    """Feasible? number of segmentations? fewest words? and one fewest-word segmentation."""
    W = set(words)
    L = max(map(len, W), default=0)
    n = len(s)
    can, count, fewest, choice = [False] * (n + 1), [0] * (n + 1), [float("inf")] * (n + 1), [-1] * (n + 1)
    can[0], count[0], fewest[0] = True, 1, 0
    for i in range(1, n + 1):
        for j in range(max(0, i - L), i):         # last word is s[j:i]
            if can[j] and s[j:i] in W:
                can[i] = True
                count[i] += count[j]
                if fewest[j] + 1 < fewest[i]:
                    fewest[i], choice[i] = fewest[j] + 1, j
    seg, i = [], n
    while can[n] and i > 0:                        # walk the stored choices back
        seg.append(s[choice[i]:i]); i = choice[i]
    return can[n], count[n], (fewest[n] if can[n] else -1), seg[::-1]

def brute(s, words):
    W = set(words)
    @cache
    def go(i):                                     # list of all segmentations of s[i:]
        if i == len(s):
            return [[]]
        return [[s[i:j]] + rest for j in range(i + 1, len(s) + 1) if s[i:j] in W for rest in go(j)]
    segs = go(0)
    return bool(segs), len(segs), min(map(len, segs), default=-1)

def check(s, words):
    can, cnt, few, seg = word_break_all(s, words)
    return (can, cnt, few), (not can) or ("".join(seg) == s and len(seg) == few and all(w in words for w in seg))

gen = lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(0, 10))), ["".join(rng.choice("ab") for _ in range(rng.randint(1, 3))) for _ in range(rng.randint(1, 4))])
print(stress(check, lambda s, w: (brute(s, w), True), gen))
print(word_break_all("catsanddogs", ["cat", "cats", "and", "sand", "dog", "dogs", "s"]))
