# file: linebreak/linebreak.py
import random
from check import stress

def cost_of(lines, W):
    return sum((W - len(" ".join(l))) ** 3 for l in lines[:-1])

def greedy(words, W):
    lines, cur = [], []
    for w in words:
        if cur and len(" ".join(cur + [w])) > W:
            lines.append(cur); cur = []
        cur.append(w)
    return lines + ([cur] if cur else [])

def dp_breaks(words, W):
    n = len(words)
    INF = float("inf")
    best, nxt = [INF] * (n + 1), [n] * (n + 1)
    best[n] = 0
    for i in range(n - 1, -1, -1):                # best layout of words[i:]
        length = -1
        for j in range(i, n):                     # first line holds words[i..j]
            length += len(words[j]) + 1
            if length > W:
                break
            c = 0 if j == n - 1 else (W - length) ** 3 + best[j + 1]
            if c < best[i]:
                best[i], nxt[i] = c, j + 1
    lines, i = [], 0
    while i < n:
        lines.append(words[i:nxt[i]]); i = nxt[i]
    return lines

def brute(words, W):                              # try every set of break positions
    n, best = len(words), float("inf")
    for mask in range(1 << max(0, n - 1)):
        lines, cur = [], [words[0]]
        for k in range(1, n):
            if mask >> (k - 1) & 1:
                lines.append(cur); cur = []
            cur.append(words[k])
        lines.append(cur)
        if all(len(" ".join(l)) <= W for l in lines):
            best = min(best, cost_of(lines, W))
    return best

gen = lambda rng: (["x" * rng.randint(1, 5) for _ in range(rng.randint(1, 9))], 6)
print(stress(lambda w, W: cost_of(dp_breaks(w, W), W), brute, gen))

text = ("Dynamic programming is not a bag of tricks it is one idea when the answer to a problem is built from "
        "answers to smaller versions of the same problem and those smaller versions repeat compute each one once").split()
W = 33
for name, f in (("greedy", greedy), ("DP", dp_breaks)):
    lines = f(text, W)
    print(f"--- {name}: cost {cost_of(lines, W)}")
    for l in lines:
        s = " ".join(l)
        print(f"|{s}{' ' * (W - len(s))}|")
