# file: as_graph.py
import heapq
from check import stress, rand_list

def min_coins_dp(coins, amount):                  # state: remaining amount; edge: use one coin
    INF = float("inf")
    dp = [0] + [INF] * amount
    for a in range(1, amount + 1):
        dp[a] = min((dp[a - c] + 1 for c in coins if c <= a), default=INF)
    return dp[amount] if dp[amount] < INF else -1

def min_coins_dijkstra(coins, amount):            # same state graph, searched as a graph
    dist, h = {amount: 0}, [(0, amount)]
    while h:
        d, a = heapq.heappop(h)
        if a == 0:
            return d
        if d > dist[a]:
            continue
        for c in coins:
            if c <= a and d + 1 < dist.get(a - c, float("inf")):
                dist[a - c] = d + 1
                heapq.heappush(h, (d + 1, a - c))
    return -1

print(stress(min_coins_dp, min_coins_dijkstra, lambda rng: (sorted(set(rand_list(rng, 1, 12, 4, 1))), rng.randint(0, 60))))
