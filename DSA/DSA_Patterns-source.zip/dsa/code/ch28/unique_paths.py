# file: unique_paths.py
from check import stress

def unique_paths(grid):
    R, C = len(grid), len(grid[0])
    dp = [0] * C                                   # one row, reused (Unit 28.3)
    dp[0] = 1 if grid[0][0] == 0 else 0
    for r in range(R):
        for c in range(C):
            if grid[r][c] == 1:
                dp[c] = 0
            elif c > 0:
                dp[c] += dp[c - 1]                 # dp[c] still holds the value from the row above
    return dp[-1]

def brute(grid):
    R, C = len(grid), len(grid[0])
    def walk(r, c):
        if r >= R or c >= C or grid[r][c] == 1:
            return 0
        if (r, c) == (R - 1, C - 1):
            return 1
        return walk(r + 1, c) + walk(r, c + 1)
    return walk(0, 0)

def gen(rng):
    R, C = rng.randint(1, 5), rng.randint(1, 5)
    return ([[1 if rng.random() < 0.2 else 0 for _ in range(C)] for _ in range(R)],)

print(unique_paths([[0, 0, 0], [0, 1, 0], [0, 0, 0]]))
print(stress(unique_paths, brute, gen))
