# file: recipe.py
from itertools import product
from check import stress, rand_list

def rob(a):
    dp = [0] * (len(a) + 1)                       # dp[i]: best loot from a[:i]
    for i in range(1, len(a) + 1):
        dp[i] = max(dp[i - 1], (dp[i - 2] if i >= 2 else 0) + a[i - 1])
    return dp[-1]

def decode_ways(s):
    dp = [1] + [0] * len(s)                       # dp[i]: decodings of s[:i]; empty prefix has 1
    for i in range(1, len(s) + 1):
        if s[i - 1] != "0":
            dp[i] += dp[i - 1]                    # last letter from one digit
        if i >= 2 and "10" <= s[i - 2:i] <= "26":
            dp[i] += dp[i - 2]                    # last letter from two digits
    return dp[-1]

def min_path(grid):
    R, C = len(grid), len(grid[0])
    INF = float("inf")
    dp = [[INF] * C for _ in range(R)]
    for r in range(R):
        for c in range(C):
            if r == c == 0:
                dp[r][c] = grid[0][0]
            else:
                dp[r][c] = grid[r][c] + min(dp[r - 1][c] if r else INF, dp[r][c - 1] if c else INF)
    return dp[-1][-1]

def rob_brute(a):
    return max(sum(x for x, t in zip(a, pick) if t) for pick in product((0, 1), repeat=len(a))
               if all(not (p and q) for p, q in zip(pick, pick[1:])))

def decode_brute(s):
    if not s:
        return 1
    total = 0
    if s[0] != "0":
        total += decode_brute(s[1:])
        if len(s) >= 2 and 10 <= int(s[:2]) <= 26:
            total += decode_brute(s[2:])
    return total

def path_brute(grid):
    R, C = len(grid), len(grid[0])
    best = float("inf")
    for moves in set(product("DR", repeat=R + C - 2)):
        if moves.count("D") == R - 1:
            r = c = 0; s = grid[0][0]
            for m in moves:
                r, c = (r + 1, c) if m == "D" else (r, c + 1)
                s += grid[r][c]
            best = min(best, s)
    return best

def gen_grid(rng, max_side):
    R, C = rng.randint(1, max_side), rng.randint(1, max_side)
    return ([[rng.randint(0, 9) for _ in range(C)] for _ in range(R)],)

if __name__ == "__main__":
    print(stress(rob, rob_brute, lambda rng: (rand_list(rng, 0, 9, 10),)))
    print(stress(decode_ways, decode_brute, lambda rng: ("".join(rng.choice("0122367") for _ in range(rng.randint(0, 8))),)))
    print(stress(min_path, path_brute, lambda rng: gen_grid(rng, 4), trials=500))
