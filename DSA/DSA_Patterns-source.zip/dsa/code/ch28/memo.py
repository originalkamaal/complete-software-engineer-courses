# file: memo.py
import sys
import time
from functools import cache

calls = 0
def ways_naive(n):                                    # climb n stairs taking 1 or 2 steps
    global calls
    calls += 1
    return 1 if n <= 1 else ways_naive(n - 1) + ways_naive(n - 2)

@cache
def ways_memo(n):
    return 1 if n <= 1 else ways_memo(n - 1) + ways_memo(n - 2)

t = time.perf_counter()
print("naive n=30:", ways_naive(30), f"with {calls:,} calls in {(time.perf_counter() - t) * 1000:.0f} ms")
t = time.perf_counter()
print("memo  n=30:", ways_memo(30), f"with {ways_memo.cache_info().currsize} cached states in {(time.perf_counter() - t) * 1000:.2f} ms")
try:
    ways_memo.cache_clear()
    ways_memo(5000)
except RecursionError:
    print("memo n=5000: RecursionError - top-down depth is n (DT-17); go bottom-up")
