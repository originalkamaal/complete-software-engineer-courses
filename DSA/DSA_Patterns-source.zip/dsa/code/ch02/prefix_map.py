# file: prefix_map.py
from collections import defaultdict
from check import stress, rand_list, examples

def count_sum_k(a, k):
    count = defaultdict(int)
    count[0] = 1                                 # the empty prefix: subarrays starting at index 0
    s = result = 0
    for x in a:
        s += x
        result += count[s - k]                   # each earlier prefix s-k starts a subarray summing to k
        count[s] += 1
    return result

def count_sum_k_brute(a, k):
    return sum(1 for i in range(len(a)) for j in range(i, len(a)) if sum(a[i:j + 1]) == k)

def longest_sum_k(a, k):
    first = {0: -1}                              # prefix sum -> first index where it occurred
    s = best = 0
    for j, x in enumerate(a):
        s += x
        if s - k in first:
            best = max(best, j - first[s - k])
        first.setdefault(s, j)                   # keep the FIRST occurrence: longest subarray
    return best

def longest_sum_k_brute(a, k):
    return max([j - i + 1 for i in range(len(a)) for j in range(i, len(a)) if sum(a[i:j + 1]) == k], default=0)

def count_divisible(a, k):
    count = defaultdict(int)
    count[0] = 1
    s = result = 0
    for x in a:
        s = (s + x) % k                          # Python's % is never negative for k > 0
        result += count[s]
        count[s] += 1
    return result

def count_divisible_brute(a, k):
    return sum(1 for i in range(len(a)) for j in range(i, len(a)) if sum(a[i:j + 1]) % k == 0)

def longest_balanced(bits):                      # equal numbers of 0s and 1s
    return longest_sum_k([1 if b else -1 for b in bits], 0)

def longest_balanced_brute(bits):
    return max([j - i + 1 for i in range(len(bits)) for j in range(i, len(bits)) if 2 * sum(bits[i:j + 1]) == j - i + 1], default=0)

print(examples(count_sum_k, [(([1, 1, 1], 2), 2), (([1, 2, 3], 3), 2), (([1, -1, 0], 0), 3)]))
print(stress(count_sum_k, count_sum_k_brute, lambda rng: (rand_list(rng), rng.randint(-3, 3))))
print(stress(longest_sum_k, longest_sum_k_brute, lambda rng: (rand_list(rng), rng.randint(-3, 3))))
print(stress(count_divisible, count_divisible_brute, lambda rng: (rand_list(rng), rng.randint(1, 5))))
print(stress(longest_balanced, longest_balanced_brute, lambda rng: (rand_list(rng, 0, 1, 10),)))
