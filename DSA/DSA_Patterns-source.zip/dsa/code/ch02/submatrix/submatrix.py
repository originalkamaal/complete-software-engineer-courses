# file: submatrix/submatrix.py
import random
import time
from check import stress

def max_submatrix_brute(a):                          # O(R^2 C^2) with 2-D prefix sums
    R, C = len(a), len(a[0])
    P = [[0] * (C + 1) for _ in range(R + 1)]
    for i in range(R):
        for j in range(C):
            P[i + 1][j + 1] = a[i][j] + P[i][j + 1] + P[i + 1][j] - P[i][j]
    best = a[0][0]
    for r1 in range(R):
        for r2 in range(r1, R):
            for c1 in range(C):
                for c2 in range(c1, C):
                    best = max(best, P[r2 + 1][c2 + 1] - P[r1][c2 + 1] - P[r2 + 1][c1] + P[r1][c1])
    return best

def kadane(xs):
    best = cur = xs[0]
    for x in xs[1:]:
        cur = max(x, cur + x)
        best = max(best, cur)
    return best

def max_submatrix(a):                                # O(min(R,C)^2 * max(R,C))
    if len(a) > len(a[0]):
        a = [list(col) for col in zip(*a)]          # transpose so the squared dimension is the smaller one
    R, C = len(a), len(a[0])
    col_prefix = [[0] * C for _ in range(R + 1)]     # col_prefix[i][j] = a[0][j] + ... + a[i-1][j]
    for i in range(R):
        for j in range(C):
            col_prefix[i + 1][j] = col_prefix[i][j] + a[i][j]
    best = a[0][0]
    for top in range(R):
        for bottom in range(top, R):
            strip = [col_prefix[bottom + 1][j] - col_prefix[top][j] for j in range(C)]   # 1-D compression
            best = max(best, kadane(strip))
    return best

def gen(rng):
    R, C = rng.randint(1, 4), rng.randint(1, 5)
    return ([[rng.randint(-6, 6) for _ in range(C)] for _ in range(R)],)

print(stress(max_submatrix, max_submatrix_brute, gen))
rng = random.Random(3)
for n in (40, 80):
    m = [[rng.randint(-100, 100) for _ in range(n)] for _ in range(n)]
    t = time.perf_counter(); b1 = max_submatrix_brute(m); t1 = time.perf_counter() - t
    t = time.perf_counter(); b2 = max_submatrix(m); t2 = time.perf_counter() - t
    print(f"{n}x{n}: brute {t1 * 1000:7.0f} ms, compressed+Kadane {t2 * 1000:5.0f} ms, same answer: {b1 == b2}")
m = [[rng.randint(-100, 100) for _ in range(300)] for _ in range(60)]
t = time.perf_counter(); best = max_submatrix(m)
print(f"60x300 (transposed so 60 is squared): {(time.perf_counter() - t) * 1000:.0f} ms, best sum {best}")
