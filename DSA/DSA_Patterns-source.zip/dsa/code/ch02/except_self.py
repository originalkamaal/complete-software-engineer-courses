# file: except_self.py
from math import prod
from check import stress, rand_list

def product_except_self(a):
    n = len(a)
    out = [1] * n
    left = 1
    for i in range(n):                       # out[i] = product of a[0..i-1]
        out[i] = left
        left *= a[i]
    right = 1
    for i in range(n - 1, -1, -1):           # multiply in product of a[i+1..n-1]
        out[i] *= right
        right *= a[i]
    return out

def brute(a):
    return [prod(a[:i] + a[i + 1:]) for i in range(len(a))]

print(product_except_self([1, 2, 3, 4]), product_except_self([0, 4, 0]), product_except_self([2, 0, 5]))
print(stress(product_except_self, brute, lambda rng: (rand_list(rng, -3, 3),)))
