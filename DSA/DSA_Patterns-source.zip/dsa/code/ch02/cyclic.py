# file: cyclic.py
from check import stress, rand_list

def first_missing_positive(a):
    a, n = list(a), len(a)
    for i in range(n):
        while 1 <= a[i] <= n and a[a[i] - 1] != a[i]:     # place value v at index v-1
            j = a[i] - 1
            a[i], a[j] = a[j], a[i]                          # each swap places one value for good: O(n) total
    for i in range(n):
        if a[i] != i + 1:
            return i + 1
    return n + 1

def first_missing_positive_brute(a):
    s, k = set(a), 1
    while k in s:
        k += 1
    return k

def find_duplicates(a):                                      # values in 1..n; returns values appearing twice
    a, out = list(a), []
    for x in a:
        v = abs(x)
        if a[v - 1] < 0:
            out.append(v)                                    # already marked: v was seen before
        else:
            a[v - 1] = -a[v - 1]                             # mark "v seen" by negating position v-1
    return sorted(out)

def find_duplicates_brute(a):
    return sorted(v for v in set(a) if a.count(v) == 2)

def gen_dups(rng):                                           # guarantee: n values in 1..n, each at most twice
    n = rng.randint(1, 9)
    return (rng.sample(list(range(1, n + 1)) * 2, n),)

def valid_dups(a):
    return all(1 <= x <= len(a) for x in a) and all(a.count(x) <= 2 for x in a)

print(stress(first_missing_positive, first_missing_positive_brute, lambda rng: (rand_list(rng, -3, 9, 9),)))
print(stress(find_duplicates, find_duplicates_brute, gen_dups, valid=valid_dups))
