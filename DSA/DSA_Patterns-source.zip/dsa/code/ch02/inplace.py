# file: inplace.py
from check import stress, rand_list

def reverse(a, i, j):
    while i < j:
        a[i], a[j] = a[j], a[i]
        i, j = i + 1, j - 1

def rotate_right(a, k):                          # in place, O(1) extra memory
    n = len(a)
    if n == 0:
        return a
    k %= n
    reverse(a, 0, n - 1)                         # [1,2,3,4,5], k=2 -> [5,4,3,2,1]
    reverse(a, 0, k - 1)                         # -> [4,5,3,2,1]
    reverse(a, k, n - 1)                         # -> [4,5,1,2,3]
    return a

def move_zeros(a):                               # stable for the non-zeros
    w = 0
    for x in a:
        if x != 0:
            a[w] = x
            w += 1
    for i in range(w, len(a)):
        a[i] = 0
    return a

def dutch_flag(a):
    lo, mid, hi = 0, 0, len(a) - 1
    while mid <= hi:
        if a[mid] == 0:
            a[lo], a[mid] = a[mid], a[lo]
            lo, mid = lo + 1, mid + 1
        elif a[mid] == 1:
            mid += 1
        else:
            a[mid], a[hi] = a[hi], a[mid]
            hi -= 1                              # do NOT advance mid: the swapped-in value is unexamined
    return a

print(stress(lambda a, k: rotate_right(list(a), k), lambda a, k: (a[-(k % len(a)):] + a[:-(k % len(a))]) if a else [],
             lambda rng: (rand_list(rng), rng.randint(0, 20))))
print(stress(lambda a: move_zeros(list(a)), lambda a: [x for x in a if x] + [0] * a.count(0), lambda rng: (rand_list(rng, 0, 3),)))
print(stress(lambda a: dutch_flag(list(a)), sorted, lambda rng: (rand_list(rng, 0, 2, 12),)))
