# file: prefix2d.py
from check import stress

def build2d(a):
    rows, cols = len(a), len(a[0])
    P = [[0] * (cols + 1) for _ in range(rows + 1)]
    for i in range(rows):
        for j in range(cols):
            P[i + 1][j + 1] = a[i][j] + P[i][j + 1] + P[i + 1][j] - P[i][j]
    return P

def rect_sum(P, r1, c1, r2, c2):                   # inclusive corners
    return P[r2 + 1][c2 + 1] - P[r1][c2 + 1] - P[r2 + 1][c1] + P[r1][c1]

def queries(a, qs):
    P = build2d(a)
    return [rect_sum(P, *q) for q in qs]

def queries_brute(a, qs):
    return [sum(a[i][j] for i in range(r1, r2 + 1) for j in range(c1, c2 + 1)) for r1, c1, r2, c2 in qs]

def gen(rng):
    rows, cols = rng.randint(1, 4), rng.randint(1, 4)
    a = [[rng.randint(-5, 5) for _ in range(cols)] for _ in range(rows)]
    qs = []
    for _ in range(4):
        r1, c1 = rng.randrange(rows), rng.randrange(cols)
        qs.append((r1, c1, rng.randint(r1, rows - 1), rng.randint(c1, cols - 1)))
    return a, qs

print(stress(queries, queries_brute, gen))
