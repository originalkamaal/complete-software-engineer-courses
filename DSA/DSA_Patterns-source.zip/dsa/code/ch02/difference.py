# file: difference.py
from itertools import accumulate
from check import stress

def apply_updates(n, updates):                   # updates: (l, r, v) inclusive
    D = [0] * (n + 1)
    for l, r, v in updates:
        D[l] += v
        D[r + 1] -= v
    return list(accumulate(D[:n]))

def apply_updates_brute(n, updates):
    a = [0] * n
    for l, r, v in updates:
        for i in range(l, r + 1):
            a[i] += v
    return a

# Problem: car pooling — trips (passengers, start, end); can a car of the given capacity serve them all?
def car_pooling(trips, capacity):
    if not trips:
        return True
    end = max(t for _, _, t in trips)
    D = [0] * (end + 1)
    for p, s, t in trips:                        # passengers are in the car on [s, t)
        D[s] += p
        D[t] -= p
    load = 0
    for x in D:
        load += x
        if load > capacity:
            return False
    return True

def car_pooling_brute(trips, capacity):
    return all(sum(p for p, s, t in trips if s <= x < t) <= capacity for x in range(0, 12))

def gen_updates(rng):
    n = rng.randint(1, 8)
    ups = []
    for _ in range(rng.randint(0, 5)):
        l = rng.randrange(n)
        ups.append((l, rng.randint(l, n - 1), rng.randint(-3, 3)))
    return n, ups

def gen_trips(rng):
    trips = []
    for _ in range(rng.randint(0, 5)):
        s = rng.randint(0, 8)
        trips.append((rng.randint(1, 4), s, rng.randint(s + 1, 10)))
    return trips, rng.randint(1, 8)

print(stress(apply_updates, apply_updates_brute, gen_updates))
print(stress(car_pooling, car_pooling_brute, gen_trips))
