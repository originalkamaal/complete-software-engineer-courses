# file: parity_partition.py
from check import stress, rand_list

def even_first(a):
    """In place: evens before odds. Invariant: a[:w] are even, a[w:i] are odd."""
    w = 0
    for i in range(len(a)):
        if a[i] % 2 == 0:
            a[w], a[i] = a[i], a[w]
            w += 1
    return a

def ok(result, _brute, args):
    (orig,) = args
    split = next((i for i, x in enumerate(result) if x % 2), len(result))
    return sorted(result) == sorted(orig) and all(x % 2 for x in result[split:]) and all(x % 2 == 0 for x in result[:split])

print(even_first([3, 1, 2, 4, 7, 6]))
print(stress(lambda a: even_first(list(a)), lambda a: None, lambda rng: (rand_list(rng, 0, 9),), same=ok))
