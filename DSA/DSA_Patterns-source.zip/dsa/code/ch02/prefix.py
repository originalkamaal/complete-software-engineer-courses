# file: prefix.py
from itertools import accumulate
from check import stress, rand_list, examples

def build(a):
    return [0] + list(accumulate(a))            # P[0] = 0, P[i] = sum of a[:i]

def range_sum(P, l, r):                         # inclusive l..r
    return P[r + 1] - P[l]

# Problem: pivot index — the first i where the sum left of i equals the sum right of i.
def pivot_index(a):
    total, left = sum(a), 0
    for i, x in enumerate(a):
        if left == total - left - x:
            return i
        left += x
    return -1

def pivot_index_brute(a):
    for i in range(len(a)):
        if sum(a[:i]) == sum(a[i + 1:]):
            return i
    return -1

# Problem: answer q range-sum queries.
def answer_queries(a, queries):
    P = build(a)
    return [range_sum(P, l, r) for l, r in queries]

def answer_queries_brute(a, queries):
    return [sum(a[l:r + 1]) for l, r in queries]

def gen_queries(rng):
    a = rand_list(rng, min_len=1)
    qs = []
    for _ in range(rng.randint(0, 5)):
        l = rng.randint(0, len(a) - 1)
        qs.append((l, rng.randint(l, len(a) - 1)))
    return a, qs

print(examples(pivot_index, [(([1, 7, 3, 6, 5, 6],), 3), (([1, 2, 3],), -1), (([2, 1, -1],), 0)]))
print(stress(pivot_index, pivot_index_brute, lambda rng: (rand_list(rng),)))
print(stress(answer_queries, answer_queries_brute, gen_queries))
