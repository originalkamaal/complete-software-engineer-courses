# file: majority.py
from check import stress, rand_list
from collections import Counter

def majority(a):
    """The element occurring more than len(a)//2 times, or None."""
    candidate, count = None, 0
    for x in a:
        if count == 0:
            candidate = x
        count += 1 if x == candidate else -1
    return candidate if a.count(candidate) > len(a) // 2 else None     # verify: the vote only finds a candidate

def majority_brute(a):
    for v, c in Counter(a).items():
        if c > len(a) // 2:
            return v
    return None

def over_third(a):
    """All elements occurring more than len(a)//3 times (at most two)."""
    c1 = c2 = None
    n1 = n2 = 0
    for x in a:
        if x == c1: n1 += 1
        elif x == c2: n2 += 1
        elif n1 == 0: c1, n1 = x, 1
        elif n2 == 0: c2, n2 = x, 1
        else: n1, n2 = n1 - 1, n2 - 1
    return sorted(v for v in {c1, c2} if v is not None and a.count(v) > len(a) // 3)

def over_third_brute(a):
    return sorted(v for v, c in Counter(a).items() if c > len(a) // 3)

print(stress(majority, majority_brute, lambda rng: (rand_list(rng, 0, 2, 9),)))
print(stress(over_third, over_third_brute, lambda rng: (rand_list(rng, 0, 3, 10),)))
