# file: submatrix_target.py
from collections import defaultdict
from check import stress, rand_list

def count_submatrices(a, target):
    if not a or not a[0]:
        return 0
    R, C, total = len(a), len(a[0]), 0
    for top in range(R):
        col = [0] * C                                  # column sums for rows top..bottom
        for bottom in range(top, R):
            for c in range(C):
                col[c] += a[bottom][c]
            seen, s = defaultdict(int), 0              # 1-D: subarrays of col summing to target
            seen[0] = 1
            for v in col:
                s += v
                total += seen[s - target]
                seen[s] += 1
    return total

def brute(a, target):
    R, C = len(a), len(a[0]) if a else 0
    return sum(sum(a[r][c] for r in range(r1, r2 + 1) for c in range(c1, c2 + 1)) == target
               for r1 in range(R) for r2 in range(r1, R) for c1 in range(C) for c2 in range(c1, C))

def gen(rng):
    R, C = rng.randint(1, 4), rng.randint(1, 4)
    return [[rng.randint(-2, 2) for _ in range(C)] for _ in range(R)], rng.randint(-2, 2)

print(count_submatrices([[0, 1, 0], [1, 1, 1], [0, 1, 0]], 0), count_submatrices([[1, -1], [-1, 1]], 0))
print(stress(count_submatrices, brute, gen, trials=500))
