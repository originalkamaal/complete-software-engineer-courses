# file: quickselect.py
import random
from check import stress, rand_list

def quickselect(a, k, rng=random.Random(0)):       # k-th smallest, 0-based
    a = list(a)
    lo, hi = 0, len(a) - 1
    while True:
        p = a[rng.randint(lo, hi)]
        lt, i, gt = lo, lo, hi                      # three-way partition of a[lo..hi]
        while i <= gt:
            if a[i] < p:
                a[lt], a[i] = a[i], a[lt]; lt += 1; i += 1
            elif a[i] > p:
                a[i], a[gt] = a[gt], a[i]; gt -= 1
            else:
                i += 1
        if k < lt:
            hi = lt - 1
        elif k > gt:
            lo = gt + 1
        else:
            return p                                # k falls in the band equal to the pivot

print(stress(quickselect, lambda a, k: sorted(a)[k], lambda rng: ((a := rand_list(rng, -5, 5, 12, 1)), rng.randrange(len(a)))))
