# file: bench/bench.py
import random
import sys
import time
sys.setrecursionlimit(100_000)
from sorts import merge_sort, quicksort, heap_sort

def naive_quicksort(a):                            # last element as pivot, Lomuto two-way partition
    a = list(a)
    def sort(lo, hi):
        if lo >= hi:
            return
        p, i = a[hi], lo
        for j in range(lo, hi):
            if a[j] < p:
                a[i], a[j] = a[j], a[i]
                i += 1
        a[i], a[hi] = a[hi], a[i]
        sort(lo, i - 1)
        sort(i + 1, hi)
    sort(0, len(a) - 1)
    return a

def run(f, data, limit_ms=4000):
    t = time.perf_counter()
    out = f(data)
    ms = (time.perf_counter() - t) * 1000
    assert out == sorted(data)
    return ms

rng = random.Random(5)
n = 5000
families = {
    "random": [rng.randint(0, 10**6) for _ in range(n)],
    "sorted": list(range(n)),
    "reversed": list(range(n, 0, -1)),
    "few distinct (0..3)": [rng.randint(0, 3) for _ in range(n)],
}
print(f"{'n=' + str(n):<22}" + "".join(f"{name:>22}" for name in families))
for f in (sorted, merge_sort, quicksort, heap_sort, naive_quicksort):
    print(f"{f.__name__:<22}" + "".join(f"{run(f, d):>19.1f} ms" for d in families.values()))
