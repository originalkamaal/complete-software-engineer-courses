# file: k_closest.py
import random
from check import stress

def k_closest(points, k, rng=random.Random(1)):
    pts = list(points)
    d = lambda p: p[0] * p[0] + p[1] * p[1]
    lo, hi = 0, len(pts) - 1
    while lo < hi:
        pivot = d(pts[rng.randint(lo, hi)])
        i, j = lo, hi
        while i <= j:                                  # Hoare-style partition by distance
            while d(pts[i]) < pivot: i += 1
            while d(pts[j]) > pivot: j -= 1
            if i <= j:
                pts[i], pts[j] = pts[j], pts[i]
                i, j = i + 1, j - 1
        if k - 1 <= j:
            hi = j
        elif k - 1 >= i:
            lo = i
        else:
            break
    return pts[:k]

def same_set(fast, _brute, args):
    points, k = args
    d = lambda p: p[0] ** 2 + p[1] ** 2
    return len(fast) == k and sorted(map(d, fast)) == sorted(map(d, points))[:k]

def gen(rng):
    pts = [(rng.randint(-4, 4), rng.randint(-4, 4)) for _ in range(rng.randint(1, 10))]
    return pts, rng.randint(1, len(pts))

print(sorted(k_closest([(1, 3), (-2, 2), (5, 8), (0, 1)], 2)))
print(stress(k_closest, lambda p, k: None, gen, same=same_set))
