# file: linear_sorts.py
import random
import time
from check import stress, rand_list

def counting_sort(a, lo, hi):                     # values in [lo, hi]
    count = [0] * (hi - lo + 1)
    for x in a:
        count[x - lo] += 1
    out = []
    for v, c in enumerate(count):
        out.extend([v + lo] * c)
    return out

def radix_sort(a, base=256):                      # non-negative integers, LSD radix with stable buckets
    if not a:
        return []
    out, shift, biggest = list(a), 0, max(a)
    while biggest >> shift:
        buckets = [[] for _ in range(base)]
        for x in out:
            buckets[(x >> shift) & (base - 1)].append(x)   # stable: keeps the order of the previous pass
        out = [x for b in buckets for x in b]
        shift += base.bit_length() - 1
    return out

print(stress(lambda a: counting_sort(a, -5, 5), sorted, lambda rng: (rand_list(rng, -5, 5, 15),)))
print(stress(radix_sort, sorted, lambda rng: (rand_list(rng, 0, 100_000, 15),)))
rng = random.Random(1)
a = [rng.randrange(1 << 30) for _ in range(500_000)]
for name, f in [("sorted() (TimSort, in C)", sorted), ("radix_sort (pure Python)", radix_sort)]:
    t = time.perf_counter(); f(a); print(f"{name:<26} n=500,000: {(time.perf_counter() - t) * 1000:.0f} ms")
