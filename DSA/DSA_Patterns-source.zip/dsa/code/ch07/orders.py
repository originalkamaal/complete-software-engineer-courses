# file: orders.py
from functools import cmp_to_key
from itertools import permutations
from check import stress

def largest_number(nums):
    """Arrange non-negative integers to form the largest number: '3' + '30' > '30' + '3'."""
    strs = [str(x) for x in nums]
    strs.sort(key=cmp_to_key(lambda a, b: -1 if a + b > b + a else (1 if a + b < b + a else 0)))
    s = "".join(strs)
    return "0" if s and s[0] == "0" else s       # [0, 0] -> "0", not "00"

def largest_number_brute(nums):
    best = max("".join(map(str, p)) for p in permutations(nums))
    return str(int(best))

def sort_by_freq_then_value_desc(a):
    from collections import Counter
    c = Counter(a)
    return sorted(a, key=lambda x: (c[x], -x))   # rarer first; among equal frequency, larger first

records = [("bob", 25), ("ann", 30), ("cy", 25), ("dee", 30), ("eve", 25)]
by_age_then_name = sorted(sorted(records, key=lambda r: r[0]), key=lambda r: r[1])   # two stable passes
print(by_age_then_name == sorted(records, key=lambda r: (r[1], r[0])), by_age_then_name)
print(stress(largest_number, largest_number_brute, lambda rng: ([rng.choice([0, 1, 3, 9, 10, 30, 34, 5, 98]) for _ in range(rng.randint(1, 5))],)))
print(sort_by_freq_then_value_desc([2, 3, 1, 3, 2]))
