# file: sort_first.py
from itertools import combinations
from check import stress, rand_list

def min_abs_difference(a):                         # closest pair of values: only sorted neighbours matter
    b = sorted(a)
    return min(b[i + 1] - b[i] for i in range(len(b) - 1))

def can_pair_with_sum_at_least(a, k):
    """Can the 2m elements be split into m pairs, each with sum >= k? Greedy: smallest with largest."""
    b = sorted(a)
    return all(b[i] + b[-1 - i] >= k for i in range(len(b) // 2))

def can_pair_brute(a, k):
    if not a:
        return True
    first, rest = a[0], a[1:]
    return any(first + rest[i] >= k and can_pair_brute(rest[:i] + rest[i + 1:], k) for i in range(len(rest)))

def h_index(citations):                            # largest h: h papers with >= h citations each
    c = sorted(citations, reverse=True)
    h = 0
    while h < len(c) and c[h] >= h + 1:
        h += 1
    return h

print(stress(min_abs_difference, lambda a: min(abs(x - y) for x, y in combinations(a, 2)), lambda rng: (rand_list(rng, -20, 20, 9, 2),)))
print(stress(can_pair_with_sum_at_least, can_pair_brute, lambda rng: (rand_list(rng, 0, 9, 4, 0) * 2, rng.randint(0, 15))))
print(stress(h_index, lambda c: max(h for h in range(len(c) + 1) if sum(x >= h for x in c) >= h), lambda rng: (rand_list(rng, 0, 8, 9),)))
