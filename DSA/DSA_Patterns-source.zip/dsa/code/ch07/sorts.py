# file: sorts.py
import random
from check import stress, rand_list

def merge_sort(a):
    if len(a) <= 1:
        return list(a)
    mid = len(a) // 2
    left, right = merge_sort(a[:mid]), merge_sort(a[mid:])
    out, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:                   # <= keeps equal elements in original order: stable
            out.append(left[i]); i += 1
        else:
            out.append(right[j]); j += 1
    return out + left[i:] + right[j:]

def quicksort(a, rng=random.Random(0)):
    a = list(a)
    def sort(lo, hi):                             # sorts a[lo:hi+1]
        while lo < hi:
            p = a[rng.randint(lo, hi)]            # random pivot: expected O(n log n) on every input
            lt, i, gt = lo, lo, hi                # a[lo:lt] < p, a[lt:i] == p, a[gt+1:hi+1] > p
            while i <= gt:
                if a[i] < p:
                    a[lt], a[i] = a[i], a[lt]; lt += 1; i += 1
                elif a[i] > p:
                    a[i], a[gt] = a[gt], a[i]; gt -= 1
                else:
                    i += 1
            if lt - lo < hi - gt:                 # recurse on the smaller side, loop on the larger:
                sort(lo, lt - 1); lo = gt + 1     # stack depth O(log n) even in bad cases
            else:
                sort(gt + 1, hi); hi = lt - 1
    sort(0, len(a) - 1)
    return a

def heap_sort(a):
    a = list(a)
    n = len(a)
    def sift_down(i, size):
        while True:
            big, l, r = i, 2 * i + 1, 2 * i + 2
            if l < size and a[l] > a[big]: big = l
            if r < size and a[r] > a[big]: big = r
            if big == i:
                return
            a[i], a[big] = a[big], a[i]
            i = big
    for i in range(n // 2 - 1, -1, -1):           # build a max-heap bottom-up: O(n)
        sift_down(i, n)
    for end in range(n - 1, 0, -1):               # move the max to the end, restore the heap
        a[0], a[end] = a[end], a[0]
        sift_down(0, end)
    return a

if __name__ == "__main__":
    for f in (merge_sort, quicksort, heap_sort):
        print(f.__name__, stress(f, sorted, lambda rng: (rand_list(rng, -5, 5, 15),)))
