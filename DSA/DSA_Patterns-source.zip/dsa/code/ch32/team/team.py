# file: team/team.py
import random
import time
from rooted import root_tree, random_tree
from tree_knapsack import tree_knapsack, NEG

def tree_knapsack_naive(n, edges, value, k):           # loops always run to k: O(n * k^2)
    adj, parent, _, order = root_tree(n, edges)
    dp = [None] * n
    for v in reversed(order):
        cur = [NEG] * (k + 1)
        cur[1] = value[v]
        for c in adj[v]:
            if c == parent[v]:
                continue
            merged = cur[:]
            for a in range(1, k + 1):                  # no size bounds, no skipping of impossible entries
                for b in range(1, k + 1 - a):
                    if cur[a] + dp[c][b] > merged[a + b]:
                        merged[a + b] = cur[a] + dp[c][b]
            cur = merged
        dp[v] = cur
    return dp[0][k]

rng = random.Random(26)
n = 3000
edges = random_tree(rng, n)
_, _, depth, _ = root_tree(n, edges)
value = [rng.randint(-50, 100) for _ in range(n)]
for k in (20, 40, 80):
    t = time.perf_counter()
    fast = tree_knapsack(n, edges, value, k)
    t1 = time.perf_counter() - t
    t = time.perf_counter()
    slow = tree_knapsack_naive(n, edges, value, k)
    t2 = time.perf_counter() - t
    print(f"n={n:,}, k={k:>2}: best team skill {fast}; size-bounded {t1 * 1000:5.0f} ms, naive {t2 * 1000:6.0f} ms, agree: {fast == slow}")
