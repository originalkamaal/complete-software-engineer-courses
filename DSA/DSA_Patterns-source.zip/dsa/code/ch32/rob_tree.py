# file: rob_tree.py
from tree import random_tree
from check import stress

def rob(root):
    def go(n):
        if not n:
            return 0, 0
        lr, ln = go(n.left)
        rr, rn = go(n.right)
        take = n.val + ln + rn                     # children must be skipped
        skip = max(lr, ln) + max(rr, rn)
        return take, skip
    return max(go(root))

def brute(root):
    nodes, edges = [], []
    def collect(n, parent):
        if n:
            i = len(nodes)
            nodes.append(n.val)
            if parent is not None:
                edges.append((parent, i))
            collect(n.left, i)
            collect(n.right, i)
    collect(root, None)
    best = 0
    for mask in range(1 << len(nodes)):
        if all(not (mask >> a & 1 and mask >> b & 1) for a, b in edges):
            best = max(best, sum(v for i, v in enumerate(nodes) if mask >> i & 1))
    return best

print(stress(rob, brute, lambda rng: (random_tree(rng, rng.randint(0, 10)),)))
