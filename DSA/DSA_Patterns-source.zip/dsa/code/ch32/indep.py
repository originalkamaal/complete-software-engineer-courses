# file: indep.py
from itertools import product
from check import stress
from rooted import root_tree, random_tree

def tree_dp(n, edges, w):
    adj, parent, _, order = root_tree(n, edges)
    take, skip = [0] * n, [0] * n                      # independent set
    ctake, cskip = [0] * n, [0] * n                    # vertex cover
    for v in reversed(order):
        take[v], ctake[v] = w[v], 1
        for c in adj[v]:
            if c != parent[v]:
                take[v] += skip[c]
                skip[v] += max(take[c], skip[c])
                ctake[v] += min(ctake[c], cskip[c])
                cskip[v] += ctake[c]
    return max(take[0], skip[0]), min(ctake[0], cskip[0])

def brute(n, edges, w):
    best_is, best_vc = 0, n
    for pick in product((0, 1), repeat=n):
        if all(not (pick[u] and pick[v]) for u, v in edges):
            best_is = max(best_is, sum(x for x, p in zip(w, pick) if p))
        if all(pick[u] or pick[v] for u, v in edges):
            best_vc = min(best_vc, sum(pick))
    return best_is, best_vc

gen = lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n), [rng.randint(0, 9) for _ in range(n)])
print(stress(tree_dp, brute, gen))
