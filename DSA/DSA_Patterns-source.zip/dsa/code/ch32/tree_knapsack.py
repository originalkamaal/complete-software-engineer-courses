# file: tree_knapsack.py
from itertools import product
from check import stress
from rooted import root_tree, random_tree

NEG = float("-inf")

def tree_knapsack(n, edges, value, k):
    adj, parent, _, order = root_tree(n, edges)
    dp = [None] * n
    for v in reversed(order):
        cur = [NEG, value[v]]                          # cur[j]: best with j chosen in processed part (v included)
        for c in adj[v]:
            if c == parent[v]:
                continue
            child = dp[c]
            merged = cur + [NEG] * min(len(child) - 1, k + 1 - len(cur))
            for a in range(1, len(cur)):               # bounded by sizes so far, not by k alone
                if cur[a] == NEG:
                    continue
                for b in range(1, min(len(child), k + 1 - a)):
                    if cur[a] + child[b] > merged[a + b]:
                        merged[a + b] = cur[a] + child[b]
            cur = merged
            dp[c] = None                               # free memory: child no longer needed
        dp[v] = cur[:k + 1]
    return dp[0][k] if k < len(dp[0]) else None

def brute(n, edges, value, k):
    _, parent, _, _ = root_tree(n, edges)
    best = None
    for pick in product((0, 1), repeat=n):
        if sum(pick) == k and pick[0] and all(not pick[v] or v == 0 or pick[parent[v]] for v in range(n)):
            s = sum(x for x, p in zip(value, pick) if p)
            best = s if best is None else max(best, s)
    return best

gen = lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n), [rng.randint(-5, 9) for _ in range(n)], rng.randint(1, n))
if __name__ == "__main__":
    print(stress(tree_knapsack, brute, gen))
