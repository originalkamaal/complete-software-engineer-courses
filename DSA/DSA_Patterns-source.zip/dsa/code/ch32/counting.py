# file: counting.py
from itertools import product
from check import stress
from rooted import root_tree, random_tree

def connected_subsets(n, edges):
    adj, parent, _, order = root_tree(n, edges)
    f = [1] * n
    for v in reversed(order):
        for c in adj[v]:
            if c != parent[v]:
                f[v] *= 1 + f[c]
    return sum(f)

def brute(n, edges):
    from dsu import DSU
    count = 0
    for pick in product((0, 1), repeat=n):
        chosen = [v for v in range(n) if pick[v]]
        if chosen:
            d = DSU(n)
            for u, v in edges:
                if pick[u] and pick[v]:
                    d.union(u, v)
            count += len({d.find(v) for v in chosen}) == 1
    return count

print(stress(connected_subsets, brute, lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n))))
print("star with 5 leaves:", connected_subsets(6, [(0, i) for i in range(1, 6)]), "| path of 6:", connected_subsets(6, [(i, i + 1) for i in range(5)]))
