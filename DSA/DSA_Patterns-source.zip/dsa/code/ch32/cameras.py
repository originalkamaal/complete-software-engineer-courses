# file: cameras.py
from itertools import product
from check import stress
from rooted import root_tree, random_tree

INF = float("inf")

def min_cameras(n, edges):
    adj, parent, _, order = root_tree(n, edges)
    has, cov, need = [0] * n, [0] * n, [0] * n
    for v in reversed(order):
        kids = [c for c in adj[v] if c != parent[v]]
        has[v] = 1 + sum(min(has[c], cov[c], need[c]) for c in kids)
        need[v] = sum(cov[c] for c in kids)            # no child may need us, none has a camera
        # covered: every child HAS or COVERED, and at least one HAS
        base = sum(min(has[c], cov[c]) for c in kids)
        extra = min((has[c] - min(has[c], cov[c]) for c in kids), default=INF)   # cost to force one HAS
        cov[v] = base + extra
    return min(has[0], cov[0])                          # the root has no parent to cover it

def brute(n, edges):
    adj = root_tree(n, edges)[0]
    for k in range(n + 1):
        for pick in product((0, 1), repeat=n):
            if sum(pick) == k and all(pick[v] or any(pick[u] for u in adj[v]) for v in range(n)):
                return k

print(stress(min_cameras, brute, lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n))))
