# file: word_search2.py
from check import stress

def find_words(board, words):
    root = {}
    for w in words:
        node = root
        for ch in w:
            node = node.setdefault(ch, {})
        node["$"] = w
    R, C = len(board), len(board[0])
    found = []
    def dfs(r, c, parent):
        ch = board[r][c]
        node = parent[ch]
        if "$" in node:
            found.append(node.pop("$"))                  # report once
        board[r][c] = "#"
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < R and 0 <= nc < C and board[nr][nc] in node:
                dfs(nr, nc, node)
        board[r][c] = ch
        if not node:
            parent.pop(ch)                               # prune: nothing left below
    for r in range(R):
        for c in range(C):
            if board[r][c] in root:
                dfs(r, c, root)
    return sorted(found)

def exists(board, word):                                 # single-word backtracking (Unit 10.4)
    R, C = len(board), len(board[0])
    def go(r, c, i):
        if i == len(word): return True
        if not (0 <= r < R and 0 <= c < C) or board[r][c] != word[i]: return False
        s, board[r][c] = board[r][c], "#"
        ok = any(go(r + a, c + b, i + 1) for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        board[r][c] = s
        return ok
    return any(go(r, c, 0) for r in range(R) for c in range(C))

def gen(rng):
    R, C = rng.randint(1, 4), rng.randint(1, 4)
    board = [[rng.choice("abc") for _ in range(C)] for _ in range(R)]
    words = list({"".join(rng.choice("abc") for _ in range(rng.randint(1, 5))) for _ in range(6)})
    return (board, words)

print(stress(lambda b, ws: find_words([r[:] for r in b], ws), lambda b, ws: sorted(w for w in ws if exists([r[:] for r in b], w)), gen))
board = [list("oaan"), list("etae"), list("ihkr"), list("iflv")]
print(find_words(board, ["oath", "pea", "eat", "rain"]))
