# file: aho_test.py
from check import stress
from aho import AhoCorasick

def ac_matches(patterns, text):
    return sorted((end - len(patterns[pid]), pid) for end, pid in AhoCorasick(patterns).find_all(text))

def brute(patterns, text):
    return sorted((i, pid) for pid, p in enumerate(patterns) for i in range(len(text) - len(p) + 1) if text.startswith(p, i))

def gen(rng):
    pats = ["".join(rng.choice("ab") for _ in range(rng.randint(1, 4))) for _ in range(rng.randint(1, 5))]
    return (pats, "".join(rng.choice("ab") for _ in range(rng.randint(0, 20))))

print(stress(ac_matches, brute, gen))
print(ac_matches(["he", "she", "his", "hers"], "ushers"))
