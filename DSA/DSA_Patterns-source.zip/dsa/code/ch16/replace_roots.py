# file: replace_roots.py
from check import stress

def replace_words(roots, sentence):
    trie = {}
    for r in roots:
        node = trie
        for ch in r:
            node = node.setdefault(ch, {})
        node["$"] = r
    out = []
    for w in sentence.split():
        node, rep = trie, w
        for ch in w:
            if "$" in node:
                rep = node["$"]; break
            if ch not in node:
                break
            node = node[ch]
        else:
            rep = node.get("$", w)
        out.append(rep)
    return " ".join(out)

def brute(roots, sentence):
    def best(w):
        cands = [r for r in roots if w.startswith(r)]
        return min(cands, key=len) if cands else w
    return " ".join(best(w) for w in sentence.split())

def gen(rng):
    word = lambda n: "".join(rng.choice("ab") for _ in range(rng.randint(1, n)))
    return [word(3) for _ in range(rng.randint(0, 4))], " ".join(word(5) for _ in range(rng.randint(1, 5)))

print(replace_words(["cat", "bat", "rat"], "the cattle was rattled by the battery"))
print(stress(replace_words, brute, gen))
