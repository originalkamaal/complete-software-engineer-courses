# file: xor_trie.py
from check import stress, rand_list

class XorTrie:
    def __init__(self, bits=31):
        self.bits = bits
        self.child = [[0, 0]]                           # node 0 = root; 0 means "no child"
        self.cnt = [0]
    def update(self, x, delta):                         # insert (delta=+1) or delete (delta=-1)
        node = 0
        for b in range(self.bits - 1, -1, -1):
            bit = x >> b & 1
            if not self.child[node][bit]:
                self.child[node][bit] = len(self.cnt)
                self.child.append([0, 0]); self.cnt.append(0)
            node = self.child[node][bit]
            self.cnt[node] += delta
    def max_xor(self, x):                               # assumes at least one stored value
        node, res = 0, 0
        for b in range(self.bits - 1, -1, -1):
            want = (x >> b & 1) ^ 1
            nxt = self.child[node][want]
            if nxt and self.cnt[nxt] > 0:
                res |= 1 << b
                node = nxt
            else:
                node = self.child[node][want ^ 1]
        return res

def run(ops):
    t, live, out = XorTrie(bits=8), [], []
    for op, x in ops:
        if op == "add":
            t.update(x, 1); live.append(x)
        elif op == "del" and x in live:
            t.update(x, -1); live.remove(x)
        elif op == "query" and live:
            out.append(t.max_xor(x))
    return out

def brute(ops):
    live, out = [], []
    for op, x in ops:
        if op == "add": live.append(x)
        elif op == "del" and x in live: live.remove(x)
        elif op == "query" and live: out.append(max(x ^ y for y in live))
    return out

print(stress(run, brute, lambda rng: ([(rng.choice(["add", "add", "del", "query"]), rng.randint(0, 255)) for _ in range(rng.randint(0, 25))],)))
