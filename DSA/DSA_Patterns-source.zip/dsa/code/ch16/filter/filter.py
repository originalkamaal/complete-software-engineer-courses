# file: filter/filter.py
import random
import re
import time
from aho import AhoCorasick

rng = random.Random(10)
alphabet = "abcdefgh"
patterns = list({"".join(rng.choice(alphabet) for _ in range(rng.randint(4, 8))) for _ in range(2000)})
text = "".join(rng.choice(alphabet) for _ in range(1_000_000))

def naive_count():
    total = 0
    for p in patterns:
        i = text.find(p)
        while i != -1:
            total += 1
            i = text.find(p, i + 1)                    # +1: overlapping occurrences count
    return total

def regex_count():                                     # lookahead so overlapping matches are found
    rx = re.compile("(?=(" + "|".join(map(re.escape, patterns)) + "))")
    return sum(1 for _ in rx.finditer(text))

def ac_count():
    return sum(1 for _ in AhoCorasick(patterns).find_all(text))

for name, f in (("naive str.find", naive_count), ("regex alternation", regex_count), ("Aho-Corasick", ac_count)):
    t = time.perf_counter()
    c = f()
    print(f"{name:>18}: {c:,} matches in {(time.perf_counter() - t) * 1000:,.0f} ms")

def mask(text, patterns):
    diff = [0] * (len(text) + 1)
    for end, pid in AhoCorasick(patterns).find_all(text):
        diff[end - len(patterns[pid])] += 1
        diff[end] -= 1
    out, run = [], 0
    for i, ch in enumerate(text):
        run += diff[i]
        out.append("*" if run else ch)
    return "".join(out)

print(mask("the cat scattered catalogues", ["cat", "scat", "logue", "tter"]))
