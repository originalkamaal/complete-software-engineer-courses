# file: trie.py
from check import stress

class Trie:
    def __init__(self):
        self.root = {}                                   # node = dict: char -> node; "$" marks word end
        self.END = "$"
    def insert(self, word):
        node = self.root
        for ch in word:
            node = node.setdefault(ch, {})
            node["#"] = node.get("#", 0) + 1             # how many words pass through this prefix
        node[self.END] = True
    def _walk(self, s):
        node = self.root
        for ch in s:
            if ch not in node:
                return None
            node = node[ch]
        return node
    def search(self, word):
        node = self._walk(word)
        return bool(node) and self.END in node
    def count_prefix(self, prefix):
        node = self._walk(prefix)
        if node is None:
            return 0
        return node.get("#", 0) if prefix else sum(1 for _ in self.words())
    def words(self, node=None, prefix=""):
        node = self.root if node is None else node
        if self.END in node:
            yield prefix
        for ch in sorted(k for k in node if len(k) == 1 and k not in "$#"):
            yield from self.words(node[ch], prefix + ch)
    def autocomplete(self, prefix, k=3):
        node = self._walk(prefix)
        if node is None:
            return []
        out = []
        for w in self.words(node, prefix):
            out.append(w)
            if len(out) == k:
                break
        return out

def run(words, queries):
    t = Trie()
    for w in words:
        t.insert(w)
    return [(t.search(q), t.count_prefix(q)) for q in queries]

def brute(words, queries):
    return [(q in words, sum(w.startswith(q) for w in words)) for q in queries]

rw = lambda rng: "".join(rng.choice("ab") for _ in range(rng.randint(1, 4)))
print(stress(run, brute, lambda rng: ([rw(rng) for _ in range(rng.randint(0, 8))], [rw(rng) for _ in range(5)])))
t = Trie()
for w in ["car", "card", "care", "cart", "cat", "dog"]:
    t.insert(w)
print(t.autocomplete("car"), t.count_prefix("ca"), t.search("ca"))
