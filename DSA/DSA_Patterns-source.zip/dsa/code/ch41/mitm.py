# file: mitm.py
import bisect
import random
import time
from itertools import product
from check import stress, rand_list

def all_sums(items):
    sums = [0]
    for x in items:
        sums += [s + x for s in sums]                    # doubles each time: 2^len(items) sums
    return sums

def closest_subset_sum(a, target):                       # minimise |sum(subset) - target|
    left, right = all_sums(a[:len(a) // 2]), sorted(all_sums(a[len(a) // 2:]))
    best = float("inf")
    for s in left:
        i = bisect.bisect_left(right, target - s)
        for j in (i - 1, i):
            if 0 <= j < len(right):
                best = min(best, abs(s + right[j] - target))
    return best

def brute(a, target):
    return min(abs(sum(x for x, t in zip(a, p) if t) - target) for p in product((0, 1), repeat=len(a)))

print(stress(closest_subset_sum, brute, lambda rng: (rand_list(rng, -20, 20, 10), rng.randint(-50, 50))))
rng = random.Random(36)
a = [rng.randint(-10**9, 10**9) for _ in range(40)]
target = rng.randint(-10**9, 10**9)
t = time.perf_counter()
r = closest_subset_sum(a, target)
print(f"n=40 (2^40 = {2**40:,} subsets): closest distance {r:,} in {time.perf_counter() - t:.1f} s")
