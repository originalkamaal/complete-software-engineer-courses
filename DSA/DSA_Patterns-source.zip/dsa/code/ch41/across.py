# file: across.py
from check import stress, rand_list

def count_across(a, ok_right_range):
    """Generic: merge sort a, counting pairs (i<j) where a[j] lies in ok_right_range(a[i]) = (lo, hi) inclusive."""
    def go(lo, hi):
        if hi - lo <= 1:
            return 0
        mid = (lo + hi) // 2
        count = go(lo, mid) + go(mid, hi)
        L, R = a[lo:mid], a[mid:hi]                     # both sorted now
        p = q = 0
        for x in L:                                     # as x grows, both bounds move right
            lo_v, hi_v = ok_right_range(x)
            while p < len(R) and R[p] < lo_v: p += 1
            while q < len(R) and R[q] <= hi_v: q += 1
            count += max(0, q - p)
        a[lo:hi] = sorted(L + R)                         # merge (sorted() on two runs is linear: Timsort)
        return count
    return go(0, len(a))

def reverse_pairs(nums):                                 # i < j and nums[i] > 2 * nums[j]
    return count_across(nums[:], lambda x: (float("-inf"), (x - 1) // 2))

def range_sums(nums, lo, hi):                            # subarrays with lo <= sum <= hi
    P = [0]
    for x in nums:
        P.append(P[-1] + x)
    return count_across(P, lambda x: (x + lo, x + hi))   # P[j] - P[i] in [lo, hi]

print(stress(reverse_pairs, lambda a: sum(a[i] > 2 * a[j] for i in range(len(a)) for j in range(i + 1, len(a))), lambda rng: (rand_list(rng, -9, 9, 12),)))
print(stress(range_sums, lambda a, lo, hi: sum(lo <= sum(a[i:j]) <= hi for i in range(len(a)) for j in range(i + 1, len(a) + 1)),
             lambda rng: (rand_list(rng, -5, 5, 10), (lo := rng.randint(-5, 5)), lo + rng.randint(0, 5))))
