# file: karatsuba.py
import random
import time
from check import stress

def schoolbook(x, y):                                    # digit lists, least significant first, base 10
    out = [0] * (len(x) + len(y))
    for i, a in enumerate(x):
        carry = 0
        for j, b in enumerate(y):
            cur = out[i + j] + a * b + carry
            out[i + j], carry = cur % 10, cur // 10
        out[i + len(y)] += carry
    return out

def add(x, y):
    out, carry = [], 0
    for i in range(max(len(x), len(y))):
        s = (x[i] if i < len(x) else 0) + (y[i] if i < len(y) else 0) + carry
        out.append(s % 10); carry = s // 10
    return out + [carry] if carry else out

def sub(x, y):                                           # x >= y
    out, borrow = [], 0
    for i in range(len(x)):
        s = x[i] - (y[i] if i < len(y) else 0) - borrow
        borrow = s < 0
        out.append(s + 10 if borrow else s)
    return out

def karatsuba(x, y):
    n = max(len(x), len(y))
    if n <= 32:
        return schoolbook(x, y)                          # small cases: schoolbook is faster
    x, y = x + [0] * (n - len(x)), y + [0] * (n - len(y))   # equal lengths: both halves non-empty
    m = n // 2
    x0, x1, y0, y1 = x[:m], x[m:], y[:m], y[m:]
    z0, z2 = karatsuba(x0, y0), karatsuba(x1, y1)
    z1 = sub(sub(karatsuba(add(x0, x1), add(y0, y1)), z0), z2)
    out = [0] * (2 * n + 4)                              # room for z1's and z2's carries
    for shift, z in ((0, z0), (m, z1), (2 * m, z2)):
        carry = 0
        for i, d in enumerate(z):
            cur = out[shift + i] + d + carry
            out[shift + i], carry = cur % 10, cur // 10
        k = shift + len(z)
        while carry:
            cur = out[k] + carry
            out[k], carry = cur % 10, cur // 10; k += 1
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out

to_digits = lambda v: [int(c) for c in reversed(str(v))]
to_int = lambda d: int("".join(map(str, reversed(d))) or "0")
print(stress(lambda a, b: to_int(karatsuba(to_digits(a), to_digits(b))), lambda a, b: a * b,
             lambda rng: (rng.randint(0, 10 ** rng.randint(1, 120)), rng.randint(0, 10 ** rng.randint(1, 120))), trials=500))
rng = random.Random(35)
for n in (500, 1000, 2000):
    a, b = rng.randint(10 ** (n - 1), 10 ** n), rng.randint(10 ** (n - 1), 10 ** n)
    da, db = to_digits(a), to_digits(b)
    t = time.perf_counter(); schoolbook(da, db); ts = time.perf_counter() - t
    t = time.perf_counter(); karatsuba(da, db); tk = time.perf_counter() - t
    print(f"{n:>5} digits: schoolbook {ts * 1000:6.0f} ms, Karatsuba {tk * 1000:5.0f} ms")
