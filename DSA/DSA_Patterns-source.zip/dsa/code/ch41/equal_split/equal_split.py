# file: equal_split/equal_split.py
import bisect
import random
import time
from itertools import combinations
from check import stress

def sums_by_count(items):
    by = [[] for _ in range(len(items) + 1)]
    n = len(items)
    for mask in range(1 << n):
        s, k = 0, 0
        for i in range(n):
            if mask >> i & 1:
                s += items[i]; k += 1
        by[k].append(s)
    return by

def min_split_difference(a):
    n2 = len(a); m = n2 // 2
    total = sum(a)
    L, R = sums_by_count(a[:m]), sums_by_count(a[m:])
    best = float("inf")
    for k in range(m + 1):
        right = sorted(R[m - k])
        for s in L[k]:                                    # group A takes s + r; want 2(s + r) close to total
            want = total / 2 - s
            i = bisect.bisect_left(right, want)
            for j in (i - 1, i):
                if 0 <= j < len(right):
                    best = min(best, abs(total - 2 * (s + right[j])))
    return best

def brute(a):
    m, total = len(a) // 2, sum(a)
    return min(abs(total - 2 * sum(c)) for c in combinations(a, m))

print(stress(min_split_difference, brute, lambda rng: ([rng.randint(-50, 50) for _ in range(2 * rng.randint(1, 5))],)))
rng = random.Random(37)
a = [rng.randint(-10**7, 10**7) for _ in range(30)]
t = time.perf_counter()
r = min_split_difference(a)
print(f"30 numbers up to 1e7: minimum difference {r:,} in {time.perf_counter() - t:.1f} s (vs C(30,15) = 155,117,520 splits)")
