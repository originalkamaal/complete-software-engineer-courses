# file: rpn.py
from check import stress

def eval_rpn(tokens):
    st = []
    for t in tokens:
        if t in "+-*/" and len(t) == 1:
            b, a = st.pop(), st.pop()                 # order matters for - and /
            if t == "+": st.append(a + b)
            elif t == "-": st.append(a - b)
            elif t == "*": st.append(a * b)
            else: st.append(int(a / b))              # truncate toward zero; not a // b
        else:
            st.append(int(t))
    return st[0]

def to_rpn(rng, depth=0):
    if depth > 2 or rng.random() < 0.3:
        return [str(rng.randint(-9, 9))], None
    left, _ = to_rpn(rng, depth + 1)
    right, _ = to_rpn(rng, depth + 1)
    return left + right + [rng.choice("+-*")], None

def brute(tokens):
    st = []
    for t in tokens:
        if t in "+-*":
            b, a = st.pop(), st.pop()
            st.append(eval(f"({a}){t}({b})"))
        else:
            st.append(int(t))
    return st[0]

print(eval_rpn(["2", "1", "+", "3", "*"]), eval_rpn(["4", "13", "5", "/", "+"]), eval_rpn(["-7", "2", "/"]), -7 // 2)
print(stress(eval_rpn, brute, lambda rng: (to_rpn(rng)[0],)))
