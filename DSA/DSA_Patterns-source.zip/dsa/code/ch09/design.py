# file: design.py
import random
from collections import deque

class MinStack:
    def __init__(self):
        self.s = []                                  # (value, min so far)
    def push(self, x):
        self.s.append((x, min(x, self.s[-1][1]) if self.s else x))
    def pop(self):
        return self.s.pop()[0]
    def get_min(self):
        return self.s[-1][1]

class TwoStackQueue:
    def __init__(self):
        self.inbox, self.outbox = [], []
    def push(self, x):
        self.inbox.append(x)
    def pop(self):
        if not self.outbox:
            while self.inbox:
                self.outbox.append(self.inbox.pop())  # reverse once: oldest on top
        return self.outbox.pop()
    def __len__(self):
        return len(self.inbox) + len(self.outbox)

rng = random.Random(3)
ms, ref = MinStack(), []
q, qref = TwoStackQueue(), deque()
for _ in range(20_000):
    if ref and rng.random() < 0.45:
        assert ms.pop() == ref.pop()
    else:
        x = rng.randint(-1000, 1000)
        ms.push(x); ref.append(x)
    if ref:
        assert ms.get_min() == min(ref)
    if qref and rng.random() < 0.5:
        assert q.pop() == qref.popleft()
    else:
        x = rng.random()
        q.push(x); qref.append(x)
print("20,000 random operations: MinStack and TwoStackQueue agree with reference implementations")
