# file: shortest_k.py
from collections import deque
from check import stress, rand_list

def shortest_subarray_at_least(a, k):
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    dq, best = deque(), float("inf")
    for j in range(len(P)):
        while dq and P[j] - P[dq[0]] >= k:
            best = min(best, j - dq.popleft())
        while dq and P[dq[-1]] >= P[j]:
            dq.pop()
        dq.append(j)
    return -1 if best == float("inf") else best

def brute(a, k):
    return min([j - i for i in range(len(a)) for j in range(i + 1, len(a) + 1) if sum(a[i:j]) >= k], default=-1)

print(stress(shortest_subarray_at_least, brute, lambda rng: (rand_list(rng, -5, 5, 10), rng.randint(1, 10))))
