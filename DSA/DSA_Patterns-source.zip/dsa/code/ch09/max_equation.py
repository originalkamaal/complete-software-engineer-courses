# file: max_equation.py
from collections import deque
from check import stress

def max_value(points, k):
    dq, best = deque(), float("-inf")           # (y - x, x), decreasing in y - x
    for x, y in points:
        while dq and x - dq[0][1] > k:
            dq.popleft()                        # too far to the left
        if dq:
            best = max(best, dq[0][0] + y + x)
        while dq and dq[-1][0] <= y - x:
            dq.pop()                            # dominated by the new point
        dq.append((y - x, x))
    return best

def brute(points, k):
    return max((yi + yj + xj - xi for i, (xi, yi) in enumerate(points) for xj, yj in points[i + 1:] if xj - xi <= k),
               default=float("-inf"))

def gen(rng):
    xs = sorted(rng.sample(range(0, 20), rng.randint(2, 8)))
    return [(x, rng.randint(-5, 5)) for x in xs], rng.randint(1, 6)

print(max_value([(1, 3), (2, 0), (5, 10), (6, -10)], 1))
print(stress(max_value, brute, gen))
