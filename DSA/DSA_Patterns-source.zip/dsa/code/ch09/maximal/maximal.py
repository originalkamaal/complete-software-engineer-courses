# file: maximal/maximal.py
import random
import time
from check import stress
from applications import largest_rectangle

def maximal_rectangle(grid):
    if not grid:
        return 0
    heights = [0] * len(grid[0])
    best = 0
    for row in grid:
        for j, cell in enumerate(row):
            heights[j] = heights[j] + 1 if cell else 0    # 1s stacked above, ending at this row
        best = max(best, largest_rectangle(heights))
    return best

def maximal_brute(grid):
    R, C = len(grid), len(grid[0])
    best = 0
    for r1 in range(R):
        for r2 in range(r1, R):
            for c1 in range(C):
                for c2 in range(c1, C):
                    if all(grid[i][j] for i in range(r1, r2 + 1) for j in range(c1, c2 + 1)):
                        best = max(best, (r2 - r1 + 1) * (c2 - c1 + 1))
    return best

def gen(rng):
    R, C = rng.randint(1, 5), rng.randint(1, 5)
    return ([[int(rng.random() < 0.7) for _ in range(C)] for _ in range(R)],)

print(stress(maximal_rectangle, maximal_brute, gen))
rng = random.Random(4)
g = [[int(rng.random() < 0.9) for _ in range(500)] for _ in range(500)]
t = time.perf_counter()
print(f"500x500 matrix (90% ones): largest rectangle {maximal_rectangle(g)} in {(time.perf_counter() - t) * 1000:.0f} ms")
