# file: calculator.py
import operator
import random
from check import stress

OPS = {"+": (1, operator.add), "-": (1, operator.sub), "*": (2, operator.mul), "/": (2, lambda a, b: int(a / b))}

def calculate(s):
    """Integers, + - * /, parentheses, unary minus. Division truncates toward zero."""
    nums, ops = [], []
    def apply():
        b, a = nums.pop(), nums.pop()
        nums.append(OPS[ops.pop()][1](a, b))
    i, expect_operand = 0, True
    while i < len(s):
        ch = s[i]
        if ch == " ":
            i += 1
            continue
        if ch.isdigit():
            j = i
            while j < len(s) and s[j].isdigit():
                j += 1
            nums.append(int(s[i:j]))
            i, expect_operand = j, False
            continue
        if ch == "(":
            ops.append(ch)
        elif ch == ")":
            while ops[-1] != "(":
                apply()
            ops.pop()
            expect_operand = False
            i += 1
            continue
        elif ch == "-" and expect_operand:           # unary minus: rewrite -x as 0 - x
            nums.append(0)
            ops.append("-")
            i += 1
            continue
        else:
            while ops and ops[-1] != "(" and OPS[ops[-1]][0] >= OPS[ch][0]:
                apply()
            ops.append(ch)
        expect_operand = True
        i += 1
    while ops:
        apply()
    return nums[-1]

def random_expr(rng, depth=0):
    if depth > 2 or rng.random() < 0.3:
        return str(rng.randint(0, 9))
    kind = rng.random()
    if kind < 0.15:
        return "(" + random_expr(rng, depth + 1) + ")"
    op = rng.choice("+-*")
    return random_expr(rng, depth + 1) + f" {op} " + random_expr(rng, depth + 1)

def reference(s):                                    # Python evaluates + - * with the same rules
    return eval(s)

print(stress(calculate, reference, lambda rng: (random_expr(rng),)))
print(calculate("2*(3+4) - -5"), calculate("14/3*2"), calculate("-(2+3)*2"))
