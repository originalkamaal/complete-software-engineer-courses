# file: applications.py
from check import stress, rand_list

def largest_rectangle(h):
    stack, best = [], 0                            # increasing heights (indices)
    for i, x in enumerate(h + [0]):                # sentinel 0 flushes the stack at the end
        while stack and h[stack[-1]] >= x:
            height = h[stack.pop()]
            left = stack[-1] if stack else -1      # previous smaller
            best = max(best, height * (i - left - 1))
        stack.append(i)
    return best

def largest_rectangle_brute(h):
    return max([min(h[i:j]) * (j - i) for i in range(len(h)) for j in range(i + 1, len(h) + 1)], default=0)

def sum_subarray_mins(a):
    n = len(a)
    left, right, stack = [0] * n, [0] * n, []
    for i in range(n):                             # previous strictly smaller
        while stack and a[stack[-1]] >= a[i]:
            stack.pop()
        left[i] = stack[-1] if stack else -1
        stack.append(i)
    stack = []
    for i in range(n - 1, -1, -1):                 # next smaller-or-equal: ties go to the leftmost minimum
        while stack and a[stack[-1]] > a[i]:
            stack.pop()
        right[i] = stack[-1] if stack else n
        stack.append(i)
    return sum(a[i] * (i - left[i]) * (right[i] - i) for i in range(n))

def remove_k_digits(num, k):
    stack = []
    for d in num:
        while k and stack and stack[-1] > d:       # a larger digit before a smaller one: remove it
            stack.pop()
            k -= 1
        stack.append(d)
    stack = stack[:len(stack) - k] if k else stack # remaining removals come off the end
    return "".join(stack).lstrip("0") or "0"

def remove_k_brute(num, k):
    from itertools import combinations
    best = None
    for keep in combinations(range(len(num)), len(num) - k):
        s = "".join(num[i] for i in keep).lstrip("0") or "0"
        if best is None or (len(s), s) < (len(best), best):
            best = s
    return best

if __name__ == "__main__":
    print(stress(largest_rectangle, largest_rectangle_brute, lambda rng: (rand_list(rng, 0, 6, 10),)))
    print(stress(sum_subarray_mins, lambda a: sum(min(a[i:j]) for i in range(len(a)) for j in range(i + 1, len(a) + 1)),
                 lambda rng: (rand_list(rng, 1, 4, 10),)))
    print(stress(remove_k_digits, remove_k_brute, lambda rng: ((s := "".join(rng.choice("01239") for _ in range(rng.randint(1, 7)))), rng.randint(0, len(s)))))
