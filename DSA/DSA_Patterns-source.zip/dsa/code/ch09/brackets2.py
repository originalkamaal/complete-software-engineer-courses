# file: brackets2.py
from check import stress

def min_add_to_make_valid(s):
    open_needed = balance = 0
    for ch in s:
        if ch == "(":
            balance += 1
        elif balance:
            balance -= 1
        else:
            open_needed += 1                 # a ')' with nothing to match
    return open_needed + balance             # plus every '(' left unmatched

def longest_valid(s):
    stack, best = [-1], 0                    # stack of indices; bottom = last unmatched position
    for i, ch in enumerate(s):
        if ch == "(":
            stack.append(i)
        else:
            stack.pop()
            if not stack:
                stack.append(i)              # unmatched ')': new base
            else:
                best = max(best, i - stack[-1])
    return best

def is_valid(t):
    bal = 0
    for ch in t:
        bal += 1 if ch == "(" else -1
        if bal < 0:
            return False
    return bal == 0

def brute_longest(s):
    return max((j - i for i in range(len(s)) for j in range(i, len(s) + 1) if is_valid(s[i:j])), default=0)

def gen(rng):
    return ("".join(rng.choice("()") for _ in range(rng.randint(0, 12))),)

print(min_add_to_make_valid("())"), min_add_to_make_valid("((("), longest_valid(")()())"), longest_valid("(()"))
print(stress(longest_valid, brute_longest, gen))
