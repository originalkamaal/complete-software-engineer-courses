# file: monotonic.py
from check import stress, rand_list

def next_greater(a):                              # value of the next strictly greater element, or -1
    out, stack = [-1] * len(a), []
    for i, x in enumerate(a):
        while stack and a[stack[-1]] < x:
            out[stack.pop()] = x                  # x is the first greater element to the right
        stack.append(i)
    return out

def next_greater_brute(a):
    return [next((a[j] for j in range(i + 1, len(a)) if a[j] > a[i]), -1) for i in range(len(a))]

def next_greater_circular(a):                     # wrap around: scan the array twice
    n, out, stack = len(a), [-1] * len(a), []
    for i in range(2 * n):
        x = a[i % n]
        while stack and a[stack[-1]] < x:
            out[stack.pop()] = x
        if i < n:
            stack.append(i)
    return out

def daily_temperatures(t):                        # days to wait for a warmer day
    out, stack = [0] * len(t), []
    for i, x in enumerate(t):
        while stack and t[stack[-1]] < x:
            j = stack.pop()
            out[j] = i - j
        stack.append(i)
    return out

def previous_smaller(a):                          # index of the previous strictly smaller element, or -1
    out, stack = [-1] * len(a), []
    for i, x in enumerate(a):
        while stack and a[stack[-1]] >= x:
            stack.pop()
        out[i] = stack[-1] if stack else -1
        stack.append(i)
    return out

print(stress(next_greater, next_greater_brute, lambda rng: (rand_list(rng, 0, 5, 10),)))
print(stress(next_greater_circular, lambda a: [next((a[(i + d) % len(a)] for d in range(1, len(a)) if a[(i + d) % len(a)] > a[i]), -1) for i in range(len(a))],
             lambda rng: (rand_list(rng, 0, 5, 10),)))
print(stress(daily_temperatures, lambda t: [next((j - i for j in range(i + 1, len(t)) if t[j] > t[i]), 0) for i in range(len(t))],
             lambda rng: (rand_list(rng, 30, 35, 10),)))
print(stress(previous_smaller, lambda a: [next((j for j in range(i - 1, -1, -1) if a[j] < a[i]), -1) for i in range(len(a))],
             lambda rng: (rand_list(rng, 0, 5, 10),)))
