# file: matching.py
from check import stress, examples

def valid_brackets(s):
    pairs, stack = {")": "(", "]": "[", "}": "{"}, []
    for ch in s:
        if ch in "([{":
            stack.append(ch)
        elif not stack or stack.pop() != pairs[ch]:
            return False
    return not stack

def valid_brackets_brute(s):                     # repeatedly delete adjacent matched pairs
    prev = None
    while prev != s:
        prev, s = s, s.replace("()", "").replace("[]", "").replace("{}", "")
    return s == ""

def decode(s):                                   # "3[a2[c]]" -> "accaccacc"
    stack, cur, num = [], "", 0
    for ch in s:
        if ch.isdigit():
            num = num * 10 + int(ch)
        elif ch == "[":
            stack.append((cur, num))             # save the context we are leaving
            cur, num = "", 0
        elif ch == "]":
            prev, k = stack.pop()
            cur = prev + cur * k
        else:
            cur += ch
    return cur

def simplify_path(path):
    stack = []
    for part in path.split("/"):
        if part == "..":
            if stack:
                stack.pop()
        elif part and part != ".":
            stack.append(part)
    return "/" + "/".join(stack)

print(stress(valid_brackets, valid_brackets_brute, lambda rng: ("".join(rng.choice("()[]{}") for _ in range(rng.randint(0, 8))),)))
print(examples(decode, [(("3[a]2[bc]",), "aaabcbc"), (("3[a2[c]]",), "accaccacc"), (("2[abc]3[cd]ef",), "abcabccdcdcdef"), (("10[a]",), "a" * 10)]))
print(examples(simplify_path, [(("/home//foo/",), "/home/foo"), (("/../",), "/"), (("/a/./b/../../c/",), "/c")]))
