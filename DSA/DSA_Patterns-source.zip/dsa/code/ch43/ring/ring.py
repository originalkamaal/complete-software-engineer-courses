# file: ring/ring.py
import bisect
import hashlib
from collections import Counter

def h(s):
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8], "big")

class Ring:
    def __init__(self, servers, vnodes):
        self.vnodes, self.points, self.owner = vnodes, [], {}
        for s in servers:
            self.add(s)
    def add(self, server):
        for i in range(self.vnodes):
            p = h(f"{server}#{i}")
            bisect.insort(self.points, p)
            self.owner[p] = server
    def remove(self, server):
        for i in range(self.vnodes):
            p = h(f"{server}#{i}")
            self.points.pop(bisect.bisect_left(self.points, p))
            del self.owner[p]
    def lookup(self, key):
        i = bisect.bisect(self.points, h(key)) % len(self.points)   # first point clockwise (wrap around)
        return self.owner[self.points[i]]

keys = [f"user:{i}" for i in range(100_000)]
servers = [f"s{i}" for i in range(10)]
for v in (1, 10, 100, 500):
    ring = Ring(servers, v)
    loads = Counter(ring.lookup(k) for k in keys)
    mean = len(keys) / len(servers)
    print(f"{v:>3} virtual nodes/server: max load / mean = {max(loads.values()) / mean:.2f}, "
          f"min load / mean = {min(loads.values()) / mean:.2f}")

ring = Ring(servers, 200)
before = {k: ring.lookup(k) for k in keys}
ring.add("s10")
moved = sum(before[k] != ring.lookup(k) for k in keys)
print(f"add an 11th server: {moved / len(keys):.1%} of keys move (ideal 1/11 = {1 / 11:.1%}); all of them move TO the new server: "
      f"{all(ring.lookup(k) == 's10' for k in keys if before[k] != ring.lookup(k))}")
naive_moved = sum(h(k) % 10 != h(k) % 11 for k in keys)
print(f"naive hash mod n, 10 -> 11 servers: {naive_moved / len(keys):.1%} of keys move")
ring.remove("s10")
print("after removing it again, every key is back on its old server:", all(ring.lookup(k) == before[k] for k in keys))
