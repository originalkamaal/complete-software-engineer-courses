# file: lfu.py
from collections import OrderedDict, defaultdict
from check import stress

class LFU:
    def __init__(self, cap):
        self.cap, self.vals, self.freq = cap, {}, {}
        self.buckets = defaultdict(OrderedDict)          # freq -> keys in recency order (oldest first)
        self.min_freq = 0
    def _touch(self, key):
        f = self.freq[key]
        del self.buckets[f][key]
        if not self.buckets[f]:
            del self.buckets[f]
            if self.min_freq == f:
                self.min_freq = f + 1
        self.freq[key] = f + 1
        self.buckets[f + 1][key] = None
    def get(self, key):
        if key not in self.vals:
            return -1
        self._touch(key)
        return self.vals[key]
    def put(self, key, val):
        if self.cap == 0:
            return
        if key in self.vals:
            self.vals[key] = val
            self._touch(key)
            return
        if len(self.vals) == self.cap:
            old, _ = self.buckets[self.min_freq].popitem(last=False)   # least recent among least frequent
            if not self.buckets[self.min_freq]:
                del self.buckets[self.min_freq]
            del self.vals[old], self.freq[old]
        self.vals[key], self.freq[key] = val, 1
        self.buckets[1][key] = None
        self.min_freq = 1

def model(cap, ops):                                      # scan everything: obviously correct
    vals, freq, last, t, out = {}, {}, {}, 0, []
    for op, k, v in ops:
        t += 1
        if op == "get":
            if k in vals:
                freq[k] += 1; last[k] = t; out.append(vals[k])
            else:
                out.append(-1)
        elif cap:
            if k in vals:
                vals[k] = v; freq[k] += 1; last[k] = t
                continue
            if len(vals) == cap:
                victim = min(vals, key=lambda x: (freq[x], last[x]))
                del vals[victim], freq[victim], last[victim]
            vals[k], freq[k], last[k] = v, 1, t
    return out

def run(cap, ops):
    c, out = LFU(cap), []
    for op, k, v in ops:
        if op == "get": out.append(c.get(k))
        else: c.put(k, v)
    return out

print(stress(run, model, lambda rng: (rng.randint(0, 3), [(rng.choice(["get", "put"]), rng.randint(0, 4), rng.randint(0, 9)) for _ in range(rng.randint(0, 25))])))
