# file: designs.py
import bisect
import random
from collections import Counter, defaultdict
from check import stress

class RandomizedSet:
    def __init__(self, rng):
        self.vals, self.pos, self.rng = [], {}, rng
    def insert(self, x):
        if x in self.pos: return False
        self.pos[x] = len(self.vals); self.vals.append(x)
        return True
    def remove(self, x):
        if x not in self.pos: return False
        i, last = self.pos[x], self.vals[-1]
        self.vals[i], self.pos[last] = last, i           # move the last element into the hole
        self.vals.pop(); del self.pos[x]
        return True
    def get_random(self):
        return self.vals[self.rng.randrange(len(self.vals))]

class TimeMap:
    def __init__(self):
        self.times, self.vals = defaultdict(list), defaultdict(list)
    def set(self, key, value, t):                        # timestamps strictly increase per key
        self.times[key].append(t); self.vals[key].append(value)
    def get(self, key, t):
        i = bisect.bisect_right(self.times[key], t)
        return self.vals[key][i - 1] if i else ""

def flatten(nested):
    for x in nested:
        if isinstance(x, list):
            yield from flatten(x)
        else:
            yield x

class Peeking:
    _END = object()
    def __init__(self, it):
        self.it = iter(it)
        self.nxt = next(self.it, self._END)
    def has_next(self):
        return self.nxt is not self._END
    def peek(self):
        return self.nxt
    def __next__(self):
        x = self.nxt
        self.nxt = next(self.it, self._END)
        return x

def rs_run(ops):
    s, out = RandomizedSet(random.Random(0)), []
    for op, x in ops:
        out.append(s.insert(x) if op == "ins" else s.remove(x))
    return out, sorted(s.vals), all(s.vals[i] == v for v, i in s.pos.items())

def rs_model(ops):
    s, out = set(), []
    for op, x in ops:
        if op == "ins": out.append(x not in s); s.add(x)
        else: out.append(x in s); s.discard(x)
    return out, sorted(s), True

print(stress(rs_run, rs_model, lambda rng: ([(rng.choice(["ins", "del"]), rng.randint(0, 5)) for _ in range(rng.randint(0, 20))],)))
rs = RandomizedSet(random.Random(1))
for x in range(5): rs.insert(x)
c = Counter(rs.get_random() for _ in range(50_000))
print("get_random frequencies:", [round(c[x] / 50_000, 3) for x in range(5)])
tm = TimeMap(); tm.set("k", "a", 1); tm.set("k", "b", 4)
print([tm.get("k", t) for t in (0, 1, 3, 4, 9)], list(flatten([1, [2, [3, [4]], 5], [], [[6]]])))
p = Peeking([1, 2, 3])
print(p.peek(), next(p), p.peek(), next(p), next(p), p.has_next())
