# file: lru.py
from collections import OrderedDict
from check import stress

class Node:
    __slots__ = ("key", "val", "prev", "next")
    def __init__(self, key=None, val=None):
        self.key, self.val, self.prev, self.next = key, val, None, None

class LRU:                                          # explicit doubly linked list with sentinels
    def __init__(self, cap):
        self.cap, self.map = cap, {}
        self.head, self.tail = Node(), Node()       # head.next = most recent, tail.prev = least recent
        self.head.next, self.tail.prev = self.tail, self.head
    def _unlink(self, n):
        n.prev.next, n.next.prev = n.next, n.prev
    def _push_front(self, n):
        n.prev, n.next = self.head, self.head.next
        self.head.next.prev = n
        self.head.next = n
    def get(self, key):
        n = self.map.get(key)
        if n is None:
            return -1
        self._unlink(n); self._push_front(n)
        return n.val
    def put(self, key, val):
        n = self.map.get(key)
        if n:
            n.val = val
            self._unlink(n); self._push_front(n)
            return
        if len(self.map) == self.cap:
            old = self.tail.prev
            self._unlink(old); del self.map[old.key]
        n = Node(key, val)
        self.map[key] = n; self._push_front(n)

class LRUOrdered:                                   # the idiomatic Python version
    def __init__(self, cap):
        self.cap, self.d = cap, OrderedDict()
    def get(self, key):
        if key not in self.d:
            return -1
        self.d.move_to_end(key, last=False)
        return self.d[key]
    def put(self, key, val):
        self.d[key] = val
        self.d.move_to_end(key, last=False)
        if len(self.d) > self.cap:
            self.d.popitem(last=True)

def model(cap, ops):                                # list of (key, val) in recency order: obviously correct
    items, out = [], []
    for op, k, v in ops:
        idx = next((i for i, (kk, _) in enumerate(items) if kk == k), None)
        if op == "get":
            if idx is None:
                out.append(-1)
            else:
                item = items.pop(idx); items.insert(0, item); out.append(item[1])
        else:
            if idx is not None:
                items.pop(idx)
            items.insert(0, (k, v))
            del items[cap:]
    return out

def run(cls, cap, ops):
    c, out = cls(cap), []
    for op, k, v in ops:
        if op == "get": out.append(c.get(k))
        else: c.put(k, v)
    return out

gen = lambda rng: (rng.randint(1, 3), [(rng.choice(["get", "put"]), rng.randint(0, 4), rng.randint(0, 9)) for _ in range(rng.randint(0, 20))])
print(stress(lambda c, o: run(LRU, c, o), model, gen))
print(stress(lambda c, o: run(LRUOrdered, c, o), model, gen))
