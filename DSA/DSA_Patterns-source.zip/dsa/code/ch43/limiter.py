# file: limiter.py
from collections import deque
from check import stress

class TokenBucket:
    def __init__(self, rate, burst):
        self.rate, self.burst, self.tokens, self.last = rate, burst, float(burst), 0.0
    def allow(self, now):
        self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)   # lazy refill
        self.last = now
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False

class SlidingLog:
    def __init__(self, limit, window):
        self.limit, self.window, self.log = limit, window, deque()
    def allow(self, now):
        while self.log and self.log[0] <= now - self.window:
            self.log.popleft()
        if len(self.log) < self.limit:
            self.log.append(now)
            return True
        return False

def log_model(limit, window, times):                     # recount the whole history each time
    accepted, out = [], []
    for t in times:
        ok = sum(1 for a in accepted if a > t - window) < limit
        out.append(ok)
        if ok:
            accepted.append(t)
    return out

def run_log(limit, window, times):
    rl = SlidingLog(limit, window)
    return [rl.allow(t) for t in times]

gen = lambda rng: (rng.randint(1, 4), rng.randint(1, 10), sorted(rng.randint(0, 30) for _ in range(rng.randint(0, 20))))
print(stress(run_log, log_model, gen))
tb = TokenBucket(rate=2, burst=5)                        # 2 requests/second, bursts of 5
times = [0.0] * 8 + [1.0] * 3 + [3.0] * 6
print("token bucket:", "".join("Y" if tb.allow(t) else "n" for t in times))
