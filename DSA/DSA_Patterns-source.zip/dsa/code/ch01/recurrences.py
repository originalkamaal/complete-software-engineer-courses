# file: recurrences.py
import math
from functools import lru_cache

def solve(a, b, f, n):
    @lru_cache(maxsize=None)
    def T(m):
        return 1 if m <= 1 else a * T(m // b) + f(m)
    return T(n)

cases = [("binary search  T=T(n/2)+1", 1, 2, lambda n: 1, lambda n: math.log2(n)),
         ("merge sort     T=2T(n/2)+n", 2, 2, lambda n: n, lambda n: n * math.log2(n)),
         ("traversal      T=2T(n/2)+1", 2, 2, lambda n: 1, lambda n: n),
         ("quickselect    T=T(n/2)+n", 1, 2, lambda n: n, lambda n: n),
         ("Karatsuba      T=3T(n/2)+n", 3, 2, lambda n: n, lambda n: n ** math.log2(3))]
for name, a, b, f, guess in cases:
    ratios = [solve(a, b, f, 2 ** k) / guess(2 ** k) for k in (10, 15, 20)]
    print(f"{name:<28} T(n)/guess at n=2^10, 2^15, 2^20: {', '.join(f'{r:.3f}' for r in ratios)}")
