# file: doubling.py
import random
import time

def best_time(f, arg, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t = time.perf_counter()
        f(arg)
        best = min(best, time.perf_counter() - t)
    return best

def has_duplicate_quadratic(a):
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i] == a[j]:
                return True
    return False

def has_duplicate_sort(a):
    b = sorted(a)
    return any(b[i] == b[i + 1] for i in range(len(b) - 1))

def has_duplicate_set(a):
    return len(set(a)) != len(a)

rng = random.Random(1)
for f, sizes in [(has_duplicate_quadratic, [500, 1000, 2000, 4000]), (has_duplicate_sort, [10**5, 2 * 10**5, 4 * 10**5, 8 * 10**5]),
                 (has_duplicate_set, [10**5, 2 * 10**5, 4 * 10**5, 8 * 10**5])]:
    times = [best_time(f, rng.sample(range(10**9), n)) for n in sizes]     # distinct values: worst case
    ratios = " ".join(f"{times[i + 1] / times[i]:.1f}" for i in range(len(times) - 1))
    print(f"{f.__name__:<26} sizes {sizes[0]:,}..{sizes[-1]:,}: last time {times[-1] * 1000:7.1f} ms, doubling ratios {ratios}")
