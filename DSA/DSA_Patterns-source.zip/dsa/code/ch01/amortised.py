# file: amortised.py
def appends_cost(n, grow):
    """Total element copies plus writes for n appends, with a given growth rule."""
    capacity, size, cost = 1, 0, 0
    worst_single = 0
    for _ in range(n):
        step = 1
        if size == capacity:
            new_capacity = grow(capacity)
            step += size                       # copy every existing element
            capacity = new_capacity
        size += 1
        cost += step
        worst_single = max(worst_single, step)
    return cost, worst_single

for n in (1_000, 10_000, 100_000):
    d_cost, d_worst = appends_cost(n, lambda c: 2 * c)
    a_cost, a_worst = appends_cost(n, lambda c: c + 100)
    print(f"n={n:>7,}: doubling total {d_cost:>12,} ({d_cost / n:.2f} per append, worst single {d_worst:,})   "
          f"+100 growth total {a_cost:>14,} ({a_cost / n:,.0f} per append)")

import sys
lst, last, growths = [], sys.getsizeof([]), []
for i in range(64):
    lst.append(i)
    if sys.getsizeof(lst) != last:
        last = sys.getsizeof(lst)
        growths.append(len(lst))
print("CPython list capacity grows at lengths:", growths)
