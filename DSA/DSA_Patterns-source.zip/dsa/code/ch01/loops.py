# file: loops.py
def count_ops(f, n):
    c = [0]
    def tick():
        c[0] += 1
    f(n, tick)
    return c[0]

def nested(n, tick):                 # n * n
    for i in range(n):
        for j in range(n):
            tick()

def triangle(n, tick):               # sum_{i} i = n(n-1)/2
    for i in range(n):
        for j in range(i):
            tick()

def halving(n, tick):                # log2 n
    while n > 1:
        n //= 2
        tick()

def harmonic(n, tick):               # sum_{i=1..n} n/i = n * H(n) ~ n ln n
    for i in range(1, n + 1):
        for j in range(0, n, i):
            tick()

def two_pointer(n, tick):            # nested loops, yet each pointer only moves forward: <= 2n
    j = 0
    for i in range(n):
        while j < n and (j - i) < 3:
            j += 1
            tick()
        tick()

def sqrt_loop(n, tick):              # i * i <= n  ->  sqrt(n)
    i = 1
    while i * i <= n:
        i += 1
        tick()

import math
for name, f, formula in [("nested", nested, lambda n: n * n), ("triangle", triangle, lambda n: n * (n - 1) // 2),
                         ("halving", halving, lambda n: math.floor(math.log2(n))), ("harmonic", harmonic, lambda n: round(n * (math.log(n) + 0.5772))),
                         ("two pointer", two_pointer, lambda n: 2 * n), ("sqrt", sqrt_loop, lambda n: math.isqrt(n))]:
    counts = [count_ops(f, n) for n in (1000, 2000, 4000)]
    print(f"{name:<12} n=1000,2000,4000 -> {counts}   formula at 4000: {formula(4000)}   ratio when n doubles: {counts[2] / counts[1]:.2f}")
