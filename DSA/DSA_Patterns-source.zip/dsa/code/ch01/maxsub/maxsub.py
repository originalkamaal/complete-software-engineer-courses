# file: maxsub/maxsub.py
import random
import time

def brute(a):                                   # Theta(n^2): every start, running sum
    best = a[0]
    for i in range(len(a)):
        s = 0
        for j in range(i, len(a)):
            s += a[j]
            if s > best:
                best = s
    return best

def divide_conquer(a):                          # T(n) = 2T(n/2) + O(n) = Theta(n log n)
    def solve(lo, hi):
        if hi - lo == 1:
            return a[lo]
        mid = (lo + hi) // 2
        best_left_suffix, s = float("-inf"), 0
        for i in range(mid - 1, lo - 1, -1):    # best sum ending exactly at mid-1
            s += a[i]
            best_left_suffix = max(best_left_suffix, s)
        best_right_prefix, s = float("-inf"), 0
        for i in range(mid, hi):                # best sum starting exactly at mid
            s += a[i]
            best_right_prefix = max(best_right_prefix, s)
        return max(solve(lo, mid), solve(mid, hi), best_left_suffix + best_right_prefix)
    return solve(0, len(a))

def kadane(a):                                  # Theta(n): best sum ending at each position
    best = cur = a[0]
    for x in a[1:]:
        cur = x if cur < 0 else cur + x
        if cur > best:
            best = cur
    return best

rng = random.Random(7)
for _ in range(3000):
    a = [rng.randint(-10, 10) for _ in range(rng.randint(1, 12))]
    assert brute(a) == divide_conquer(a) == kadane(a), a
print("3000 random arrays: all three agree")

def best_time(f, a):
    t = time.perf_counter()
    f(a)
    return time.perf_counter() - t

for f, sizes in [(brute, [1000, 2000, 4000]), (divide_conquer, [100_000, 200_000, 400_000]), (kadane, [1_000_000, 2_000_000, 4_000_000])]:
    times = [min(best_time(f, [rng.randint(-100, 100) for _ in range(n)]) for _ in range(2)) for n in sizes]
    print(f"{f.__name__:<15} n={sizes}: {', '.join(f'{t * 1000:.0f} ms' for t in times)}; ratios {times[1] / times[0]:.2f}, {times[2] / times[1]:.2f}")
