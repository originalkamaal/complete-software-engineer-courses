# file: sparse.py
import math
from check import stress, rand_list

class SparseTable:
    def __init__(self, a, op=min):
        self.op = op
        self.sp = [list(a)]
        k = 1
        while 1 << k <= len(a):
            prev, half = self.sp[-1], 1 << (k - 1)
            self.sp.append([op(prev[i], prev[i + half]) for i in range(len(a) - (1 << k) + 1)])
            k += 1
    def query(self, l, r):                               # non-empty [l, r)
        k = (r - l).bit_length() - 1
        return self.op(self.sp[k][l], self.sp[k][r - (1 << k)])

def run(a, qs, op):
    st = SparseTable(a, op)
    return [st.query(l, r) for l, r in qs]

def gen(rng):
    a = rand_list(rng, -9, 9, 20, 1)
    qs = []
    for _ in range(10):
        l = rng.randrange(len(a)); qs.append((l, rng.randint(l + 1, len(a))))
    return (a, qs)

from functools import reduce
valid = lambda a, qs: all(0 <= l < r <= len(a) for l, r in qs)      # keep shrunk inputs meaningful
for op in (min, max):
    print(op.__name__, stress(lambda a, qs: run(a, qs, op), lambda a, qs: [reduce(op, a[l:r]) for l, r in qs], gen, valid=valid))
nonneg = lambda rng: (lambda a, qs: ([abs(x) for x in a], qs))(*gen(rng))
print("gcd", stress(lambda a, qs: run(a, qs, math.gcd), lambda a, qs: [reduce(math.gcd, a[l:r]) for l, r in qs], nonneg, valid=valid))
print("gcd(-4, -4) =", math.gcd(-4, -4), "-> gcd is idempotent only on non-negative values")
