# file: range_sum_count.py
from bisect import bisect_left, bisect_right
from itertools import accumulate
from check import stress, rand_list

def count_in_range(a, lower, upper):
    P = [0] + list(accumulate(a))
    vals = sorted(set(P))
    tree = [0] * (len(vals) + 1)
    def add(i):
        i += 1
        while i <= len(vals):
            tree[i] += 1
            i += i & -i
    def prefix(i):                      # count of inserted ranks < i
        s = 0
        while i > 0:
            s += tree[i]
            i -= i & -i
        return s
    total = 0
    for p in P:
        lo, hi = bisect_left(vals, p - upper), bisect_right(vals, p - lower)
        total += prefix(hi) - prefix(lo)
        add(bisect_left(vals, p))
    return total

def brute(a, lower, upper):
    return sum(lower <= sum(a[i:j]) <= upper for i in range(len(a)) for j in range(i + 1, len(a) + 1))

print(count_in_range([-2, 5, -1], -2, 2))
print(stress(count_in_range, brute, lambda rng: (rand_list(rng, -5, 5, max_len=10), (lo := rng.randint(-5, 3)), lo + rng.randint(0, 5))))
