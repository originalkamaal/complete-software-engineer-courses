# file: inversions.py
import bisect
from check import stress, rand_list
from fenwick import Fenwick

def compress(values):
    ranks = sorted(set(values))
    return [bisect.bisect_left(ranks, v) for v in values], len(ranks)

def count_inversions(a):                              # pairs i < j with a[i] > a[j]
    r, m = compress(a)
    f, inv = Fenwick(m), 0
    for i, x in enumerate(r):
        inv += i - f.prefix(x + 1)                    # earlier elements greater than x
        f.add(x, 1)
    return inv

def count_smaller_after(a):
    r, m = compress(a)
    f, out = Fenwick(m), []
    for x in reversed(r):
        out.append(f.prefix(x))
        f.add(x, 1)
    return out[::-1]

def count_range_sum(a, lower, upper):                 # subarrays with lower <= sum <= upper
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    ranks = sorted(set(P))
    f, total = Fenwick(len(ranks)), 0
    for p in P:                                       # earlier prefix q with p - upper <= q <= p - lower
        lo = bisect.bisect_left(ranks, p - upper)
        hi = bisect.bisect_right(ranks, p - lower)
        total += f.range_sum(lo, hi)
        f.add(bisect.bisect_left(ranks, p), 1)
    return total

gen = lambda rng: (rand_list(rng, -10**9, 10**9, 12) if rng.random() < 0.5 else rand_list(rng, 0, 3, 12),)
print(stress(count_inversions, lambda a: sum(a[i] > a[j] for i in range(len(a)) for j in range(i + 1, len(a))), gen))
print(stress(count_smaller_after, lambda a: [sum(y < x for y in a[i + 1:]) for i, x in enumerate(a)], gen))
print(stress(count_range_sum, lambda a, lo, hi: sum(lo <= sum(a[i:j]) <= hi for i in range(len(a)) for j in range(i + 1, len(a) + 1)),
             lambda rng: (rand_list(rng, -5, 5, 10), (lo := rng.randint(-5, 5)), lo + rng.randint(0, 5))))
