# file: range_fenwick.py
from check import stress, rand_list
from fenwick import Fenwick

class RangeFenwick:
    """Range add, range sum. prefix(i) = sum(data[0:i])."""
    def __init__(self, n):
        self.b1, self.b2 = Fenwick(n + 1), Fenwick(n + 1)
    def _add(self, i, v):                              # add v to data[i:]
        self.b1.add(i, v)
        self.b2.add(i, v * i)
    def range_add(self, l, r, v):
        self._add(l, v); self._add(r, -v)
    def prefix(self, i):
        # sum_{j<i} data[j] = sum_{k<i} d[k] * (i - k) = i * sum d[k] - sum d[k]*k
        return self.b1.prefix(i) * i - self.b2.prefix(i)
    def range_sum(self, l, r):
        return self.prefix(r) - self.prefix(l)

def run(n, ops):
    f, out = RangeFenwick(n), []
    for kind, l, r, v in ops:
        if kind == "add": f.range_add(l, r, v)
        else: out.append(f.range_sum(l, r))
    return out

def brute(n, ops):
    a, out = [0] * n, []
    for kind, l, r, v in ops:
        if kind == "add":
            for i in range(l, r): a[i] += v
        else:
            out.append(sum(a[l:r]))
    return out

def gen(rng):
    n = rng.randint(1, 12)
    ops = []
    for _ in range(15):
        l = rng.randint(0, n); r = rng.randint(l, n)
        ops.append((rng.choice(["add", "sum"]), l, r, rng.randint(-5, 5)))
    return (n, ops)

print(stress(run, brute, gen))
