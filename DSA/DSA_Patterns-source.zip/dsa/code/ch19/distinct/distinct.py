# file: distinct/distinct.py
import random
import time
from check import stress, rand_list
from fenwick import Fenwick
from mo import mo_distinct

def distinct_offline(a, queries):
    by_r = sorted(range(len(queries)), key=lambda i: queries[i][1])
    f, last, ans, r = Fenwick(len(a)), {}, [0] * len(queries), 0
    for qi in by_r:
        l, qr = queries[qi]
        while r < qr:
            v = a[r]
            if v in last:
                f.add(last[v], -1)                      # only the latest occurrence counts
            f.add(r, 1)
            last[v] = r
            r += 1
        ans[qi] = f.range_sum(l, qr)
    return ans

def gen(rng):
    a = rand_list(rng, 0, 5, 15, 1)
    qs = []
    for _ in range(rng.randint(1, 10)):
        l = rng.randint(0, len(a)); qs.append((l, rng.randint(l, len(a))))
    return (a, qs)

print(stress(distinct_offline, lambda a, qs: [len(set(a[l:r])) for l, r in qs], gen))
rng = random.Random(13)
n = q = 100_000
a = [rng.randint(1, 1000) for _ in range(n)]
qs = []
for _ in range(q):
    l = rng.randint(0, n - 1); qs.append((l, rng.randint(l + 1, n)))
results = {}
for name, f in (("offline Fenwick", distinct_offline), ("Mo's algorithm", mo_distinct)):
    t = time.perf_counter()
    results[name] = f(a, qs)
    print(f"{name:>15}: {(time.perf_counter() - t):.1f} s")
print("answers agree:", results["offline Fenwick"] == results["Mo's algorithm"])
