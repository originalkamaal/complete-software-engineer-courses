# file: mo.py
import math
from check import stress, rand_list

def mo_distinct(a, queries):                          # number of distinct values in a[l:r]
    B = max(1, int(len(a) / max(1, math.isqrt(len(queries) or 1))))
    order = sorted(range(len(queries)), key=lambda i: (queries[i][0] // B,
                   queries[i][1] if (queries[i][0] // B) % 2 == 0 else -queries[i][1]))   # odd-even trick
    cnt, distinct = {}, 0
    cur_l = cur_r = 0                                 # current window a[cur_l:cur_r]
    ans = [0] * len(queries)
    def add(i):
        nonlocal distinct
        c = cnt.get(a[i], 0)
        if c == 0: distinct += 1
        cnt[a[i]] = c + 1
    def remove(i):
        nonlocal distinct
        cnt[a[i]] -= 1
        if cnt[a[i]] == 0: distinct -= 1
    for qi in order:
        l, r = queries[qi]
        while cur_r < r: add(cur_r); cur_r += 1
        while cur_l > l: cur_l -= 1; add(cur_l)
        while cur_r > r: cur_r -= 1; remove(cur_r)
        while cur_l < l: remove(cur_l); cur_l += 1
        ans[qi] = distinct
    return ans

def gen(rng):
    a = rand_list(rng, 0, 5, 15, 1)
    qs = []
    for _ in range(rng.randint(1, 10)):
        l = rng.randint(0, len(a)); qs.append((l, rng.randint(l, len(a))))
    return (a, qs)

if __name__ == "__main__":
    print(stress(mo_distinct, lambda a, qs: [len(set(a[l:r])) for l, r in qs], gen))
