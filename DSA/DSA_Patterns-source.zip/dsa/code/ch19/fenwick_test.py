# file: fenwick_test.py
from itertools import accumulate
from check import stress, rand_list
from fenwick import Fenwick

def run(a, ops):
    f, out = Fenwick.from_list(a), []
    for kind, x, y in ops:
        if kind == "add":
            f.add(x, y)
        elif kind == "sum":
            out.append(f.range_sum(min(x, y), max(x, y)))
        else:
            out.append(f.lower_bound(x))
    return out

def brute(a, ops):
    a, out = a[:], []
    for kind, x, y in ops:
        if kind == "add":
            a[x] += y
        elif kind == "sum":
            out.append(sum(a[min(x, y):max(x, y)]))
        else:
            out.append(next((i for i, p in enumerate(accumulate(a)) if p >= x), len(a)))
    return out

def gen(rng):
    a = rand_list(rng, 0, 5, 12, 1)
    n = len(a)
    return (a, [rng.choice([("add", rng.randrange(n), rng.randint(0, 4)), ("sum", rng.randint(0, n), rng.randint(0, n)), ("kth", rng.randint(1, 40), 0)]) for _ in range(15)])

print(stress(run, brute, gen))
