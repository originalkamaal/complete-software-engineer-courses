# file: unbounded.py
from functools import cache
from check import stress, rand_list

def min_coins(coins, amount):
    INF = float("inf")
    dp = [0] + [INF] * amount
    for c in coins:
        for a in range(c, amount + 1):                   # forwards: coin c may be reused
            dp[a] = min(dp[a], dp[a - c] + 1)
    return -1 if dp[amount] == INF else dp[amount]

def count_combinations(coins, amount):                   # {1,2} and {2,1} are the same
    dp = [1] + [0] * amount
    for c in coins:                                      # coins outer
        for a in range(c, amount + 1):
            dp[a] += dp[a - c]
    return dp[amount]

def count_permutations(coins, amount):                   # 1+2 and 2+1 are different
    dp = [1] + [0] * amount
    for a in range(1, amount + 1):                       # amounts outer
        for c in coins:
            if c <= a:
                dp[a] += dp[a - c]
    return dp[amount]

def brute(coins, amount):
    coins = sorted(set(coins))
    @cache
    def combos(i, left):                                 # use coins[i:] in non-decreasing order
        if left == 0: return 1
        return sum(combos(j, left - c) for j, c in enumerate(coins) if j >= i and c <= left)
    @cache
    def perms(left):
        if left == 0: return 1
        return sum(perms(left - c) for c in coins if c <= left)
    @cache
    def fewest(left):
        if left == 0: return 0
        return min((fewest(left - c) + 1 for c in coins if c <= left), default=float("inf"))
    f = fewest(amount)
    return (-1 if f == float("inf") else f), combos(0, amount), perms(amount)

gen = lambda rng: (sorted(set(rand_list(rng, 1, 9, 4, 1))), rng.randint(0, 25))
print(stress(lambda c, a: (min_coins(c, a), count_combinations(c, a), count_permutations(c, a)), brute, gen))
print(count_combinations([1, 2, 5], 5), count_permutations([1, 2, 5], 5))
