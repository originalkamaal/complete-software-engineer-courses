# file: zero_one.py
from itertools import product
from check import stress

def knapsack01(items, W):
    dp = [0] * (W + 1)
    for wt, val in items:
        for w in range(W, wt - 1, -1):                   # backwards: dp[w - wt] is still "without this item"
            dp[w] = max(dp[w], dp[w - wt] + val)
    return dp[W]

def knapsack01_choose(items, W):                         # 2-D table to reconstruct the chosen items
    n = len(items)
    dp = [[0] * (W + 1) for _ in range(n + 1)]
    for i, (wt, val) in enumerate(items, 1):
        for w in range(W + 1):
            dp[i][w] = dp[i - 1][w]
            if wt <= w and dp[i - 1][w - wt] + val > dp[i][w]:
                dp[i][w] = dp[i - 1][w - wt] + val
    chosen, w = [], W
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:                     # value changed: item i-1 was taken
            chosen.append(i - 1); w -= items[i - 1][0]
    return dp[n][W], chosen[::-1]

def forwards_bug(items, W):                              # iterating upwards lets an item be reused
    dp = [0] * (W + 1)
    for wt, val in items:
        for w in range(wt, W + 1):
            dp[w] = max(dp[w], dp[w - wt] + val)
    return dp[W]

def brute(items, W):
    return max(sum(v for (wt, v), t in zip(items, pick) if t) for pick in product((0, 1), repeat=len(items))
               if sum(wt for (wt, _), t in zip(items, pick) if t) <= W)

def check(items, W):
    best, chosen = knapsack01_choose(items, W)
    return best, len(set(chosen)) == len(chosen) and sum(items[i][0] for i in chosen) <= W and sum(items[i][1] for i in chosen) == best

gen = lambda rng: ([(rng.randint(1, 6), rng.randint(0, 9)) for _ in range(rng.randint(0, 7))], rng.randint(0, 15))
if __name__ == "__main__":
    print(stress(knapsack01, brute, gen))
    print(stress(check, lambda items, W: (brute(items, W), True), gen))
    try:
        stress(forwards_bug, brute, gen)
    except AssertionError as e:
        print("forward iteration is wrong for 0/1:", str(e).split(": ", 1)[1])
