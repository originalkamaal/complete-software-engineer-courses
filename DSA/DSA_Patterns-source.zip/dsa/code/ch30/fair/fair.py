# file: fair/fair.py
import random
import time
from check import stress, rand_list
from subset_sum import min_difference

def fair_split(a):
    total = sum(a)
    snapshots = [1]                                       # snapshots[i]: reachable sums using a[:i]
    for x in a:
        snapshots.append(snapshots[-1] | (snapshots[-1] << x))
    bits = snapshots[-1]
    s = next(t for t in range(total // 2, -1, -1) if bits >> t & 1)    # next(), not max(): stop at the first hit
    group, target = [], s
    for i in range(len(a), 0, -1):
        if not (snapshots[i - 1] >> target & 1):          # not reachable without a[i-1] -> must use it
            group.append(i - 1)
            target -= a[i - 1]
    assert target == 0
    return total - 2 * s, group

def check(a):
    diff, group = fair_split(a)
    chosen = sum(a[i] for i in group)
    return diff, abs((sum(a) - chosen) - chosen) == diff and len(set(group)) == len(group)

print(stress(check, lambda a: (min_difference(a) if a else 0, True), lambda rng: (rand_list(rng, 1, 30, 12),)))
rng = random.Random(24)
a = [rng.randint(1, 1000) for _ in range(2000)]
t = time.perf_counter()
diff, group = fair_split(a)
chosen = sum(a[i] for i in group)
print(f"n=2,000, total {sum(a):,}: groups of {len(group)} and {len(a) - len(group)} items, sums {chosen:,} and {sum(a) - chosen:,}, "
      f"difference {diff}  [{time.perf_counter() - t:.2f} s]")
