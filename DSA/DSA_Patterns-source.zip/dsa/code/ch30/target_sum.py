# file: target_sum.py
from itertools import product
from check import stress, rand_list

def find_target_ways(nums, S):
    total = sum(nums)
    if (total + S) % 2 or total + S < 0:
        return 0
    P = (total + S) // 2
    ways = [1] + [0] * P
    for x in nums:
        for s in range(P, x - 1, -1):          # downwards: each number used at most once
            ways[s] += ways[s - x]
    return ways[P]

def brute(nums, S):
    return sum(sum(sign * x for sign, x in zip(signs, nums)) == S for signs in product((1, -1), repeat=len(nums)))

print(find_target_ways([1, 1, 1, 1, 1], 3), find_target_ways([0, 0, 1], 1))
print(stress(find_target_ways, brute, lambda rng: (rand_list(rng, 0, 4, max_len=9), rng.randint(-6, 6))))
