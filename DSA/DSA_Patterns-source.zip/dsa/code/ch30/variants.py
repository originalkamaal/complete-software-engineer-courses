# file: variants.py
from itertools import product
from check import stress
from zero_one import knapsack01

def bounded(items, W):                                   # items: (weight, value, count)
    parts = []
    for wt, val, cnt in items:
        k = 1
        while cnt > 0:
            take = min(k, cnt)
            parts.append((wt * take, val * take))        # one 0/1 item representing `take` copies
            cnt -= take; k *= 2
    return knapsack01(parts, W)

def bounded_brute(items, W):
    best = 0
    for counts in product(*(range(c + 1) for _, _, c in items)):
        if sum(k * wt for k, (wt, _, _) in zip(counts, items)) <= W:
            best = max(best, sum(k * v for k, (_, v, _) in zip(counts, items)))
    return best

def ones_and_zeroes(strs, m, n):                          # largest subset with <= m zeros and <= n ones
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for s in strs:
        z, o = s.count("0"), s.count("1")
        for i in range(m, z - 1, -1):
            for j in range(n, o - 1, -1):
                dp[i][j] = max(dp[i][j], dp[i - z][j - o] + 1)
    return dp[m][n]

def knapsack_by_value(items, W):                          # weights up to 1e9, values small
    V = sum(v for _, v in items)
    INF = float("inf")
    dp = [0] + [INF] * V                                  # dp[v]: min weight to get value exactly v
    for wt, val in items:
        for v in range(V, val - 1, -1):
            dp[v] = min(dp[v], dp[v - val] + wt)
    return max(v for v in range(V + 1) if dp[v] <= W)

print(stress(bounded, bounded_brute, lambda rng: ([(rng.randint(1, 5), rng.randint(0, 9), rng.randint(0, 5)) for _ in range(rng.randint(0, 4))], rng.randint(0, 20))))
print(stress(ones_and_zeroes, lambda strs, m, n: max(sum(p) for p in product((0, 1), repeat=len(strs))
             if sum(s.count("0") for s, t in zip(strs, p) if t) <= m and sum(s.count("1") for s, t in zip(strs, p) if t) <= n),
             lambda rng: (["".join(rng.choice("01") for _ in range(rng.randint(1, 4))) for _ in range(rng.randint(0, 7))], rng.randint(0, 5), rng.randint(0, 5))))
print(stress(knapsack_by_value, lambda items, W:
             max(sum(v for (w, v), t in zip(items, p) if t) for p in product((0, 1), repeat=len(items)) if sum(w for (w, _), t in zip(items, p) if t) <= W),
             lambda rng: ([(rng.randint(1, 10**9), rng.randint(0, 9)) for _ in range(rng.randint(0, 7))], rng.randint(0, 3 * 10**9))))
