# file: subset_sum.py
import random
import time
from itertools import product
from check import stress, rand_list

def reachable_sums(a):
    bits = 1                                             # bit s set <=> sum s is reachable (start: 0)
    for x in a:
        bits |= bits << x
    return bits

def can_partition(a):
    total = sum(a)
    return total % 2 == 0 and bool(reachable_sums(a) >> (total // 2) & 1)

def min_difference(a):
    total, bits = sum(a), reachable_sums(a)
    best = next(s for s in range(total // 2, -1, -1) if bits >> s & 1)   # first hit from the top
    return total - 2 * best

def subset_list(a, T):                                   # plain boolean DP, for timing comparison
    dp = [False] * (T + 1)
    dp[0] = True
    for x in a:
        for s in range(T, x - 1, -1):
            if dp[s - x]:
                dp[s] = True
    return dp[T]

def brute_sums(a):
    return {sum(x for x, t in zip(a, pick) if t) for pick in product((0, 1), repeat=len(a))}

if __name__ == "__main__":
  print(stress(can_partition, lambda a: sum(a) % 2 == 0 and sum(a) // 2 in brute_sums(a), lambda rng: (rand_list(rng, 1, 12, 10),)))
  print(stress(min_difference, lambda a: min(abs(sum(a) - 2 * s) for s in brute_sums(a)), lambda rng: (rand_list(rng, 1, 12, 10),)))
  
  rng = random.Random(23)
  a = [rng.randint(1, 1000) for _ in range(500)]
  T = sum(a) // 2
  for name, f in (("bitset (big int)", lambda: bool(reachable_sums(a) >> T & 1)), ("list of booleans", lambda: subset_list(a, T))):
      t = time.perf_counter()
      r = f()
      print(f"n=500, target {T:,}: {name:>17} -> {r} in {(time.perf_counter() - t) * 1000:,.0f} ms")
