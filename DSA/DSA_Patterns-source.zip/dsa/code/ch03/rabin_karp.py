# file: rabin_karp.py
from check import stress

class RollingHash:
    MOD = (1 << 61) - 1                               # a Mersenne prime: collisions ~ 1 in 2.3e18 per comparison

    def __init__(self, s, base=911382323):
        self.n, M = len(s), self.MOD
        self.H, self.P = [0] * (self.n + 1), [1] * (self.n + 1)
        for i, ch in enumerate(s):
            self.H[i + 1] = (self.H[i] * base + ord(ch)) % M
            self.P[i + 1] = (self.P[i] * base) % M

    def get(self, l, r):                              # hash of s[l:r]
        return (self.H[r] - self.H[l] * self.P[r - l]) % self.MOD

def find_all(text, pattern):
    """All start indices of pattern in text, confirming each hash match."""
    if not pattern or len(pattern) > len(text):
        return [] if pattern else list(range(len(text) + 1))
    ht, target = RollingHash(text), RollingHash(pattern).get(0, len(pattern))
    m = len(pattern)
    return [i for i in range(len(text) - m + 1) if ht.get(i, i + m) == target and text[i:i + m] == pattern]

def find_all_brute(text, pattern):
    return [i for i in range(len(text) - len(pattern) + 1) if text[i:i + len(pattern)] == pattern]

def distinct_substrings_of_length(s, k):
    h = RollingHash(s)
    return len({h.get(i, i + k) for i in range(len(s) - k + 1)})

def s_gen(rng, alphabet="ab"):
    return "".join(rng.choice(alphabet) for _ in range(rng.randint(0, 9)))

print(stress(find_all, find_all_brute, lambda rng: (s_gen(rng), s_gen(rng)[:3])))
print(stress(distinct_substrings_of_length, lambda s, k: len({s[i:i + k] for i in range(len(s) - k + 1)}),
             lambda rng: (s_gen(rng), rng.randint(1, 4))))

# A weak hash collides easily: base 31 modulo 2^16, with no confirmation
def weak(s):
    h = 0
    for ch in s:
        h = (h * 31 + ord(ch)) % 65536
    return h
import itertools
seen, collision = {}, None
for t in itertools.product("abcdefghij", repeat=5):
    w = "".join(t)
    if weak(w) in seen:
        collision = (seen[weak(w)], w)
        break
    seen[weak(w)] = w
print(f"weak 16-bit hash: first collision after {len(seen):,} strings: {collision}")
