# file: canonical.py
from collections import defaultdict
from check import stress

def pattern_key(s):
    """Isomorphism class: 'paper' -> (0,1,0,2,3), 'title' -> (0,1,0,2,3)."""
    first = {}
    return tuple(first.setdefault(ch, len(first)) for ch in s)

def isomorphic(s, t):
    return len(s) == len(t) and pattern_key(s) == pattern_key(t)

def isomorphic_brute(s, t):                           # a bijection must exist between characters
    if len(s) != len(t):
        return False
    m1, m2 = {}, {}
    for a, b in zip(s, t):
        if m1.setdefault(a, b) != b or m2.setdefault(b, a) != a:
            return False
    return True

def shift_key(s):
    return tuple((ord(s[i]) - ord(s[i - 1])) % 26 for i in range(1, len(s)))

def group_shifted(words):
    groups = defaultdict(list)
    for w in words:
        groups[(len(w), shift_key(w))].append(w)
    return sorted(sorted(g) for g in groups.values())

def group_shifted_brute(words):
    def same(a, b):
        return len(a) == len(b) and any(all(chr((ord(x) - 97 + k) % 26 + 97) == y for x, y in zip(a, b)) for k in range(26))
    groups = []
    for w in words:
        for g in groups:
            if same(g[0], w):
                g.append(w)
                break
        else:
            groups.append([w])
    return sorted(sorted(g) for g in groups)

def word(rng, alphabet="abcz"):
    return "".join(rng.choice(alphabet) for _ in range(rng.randint(0, 4)))

print(stress(isomorphic, isomorphic_brute, lambda rng: (word(rng), word(rng))))
print(stress(group_shifted, group_shifted_brute, lambda rng: ([word(rng) for _ in range(rng.randint(0, 6))],)))
