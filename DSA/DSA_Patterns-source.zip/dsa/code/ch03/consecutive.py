# file: consecutive.py
from check import stress, rand_list

def longest_consecutive(nums):
    s = set(nums)
    best = 0
    for x in s:
        if x - 1 not in s:                            # x starts a run
            y = x
            while y + 1 in s:
                y += 1
            best = max(best, y - x + 1)
    return best

def longest_consecutive_brute(nums):
    s, best = sorted(set(nums)), 0
    run = 0
    for i, x in enumerate(s):
        run = run + 1 if i and x == s[i - 1] + 1 else 1
        best = max(best, run)
    return best

print(stress(longest_consecutive, longest_consecutive_brute, lambda rng: (rand_list(rng, -6, 6, 10),)))
