# file: unique_freq.py
from collections import Counter
from itertools import product
from check import stress

def min_deletions(s):
    deletions, allowed = 0, float("inf")
    for f in sorted(Counter(s).values(), reverse=True):
        keep = min(f, max(allowed, 0))
        deletions += f - keep
        allowed = keep - 1                     # the next frequency must be smaller (or zero)
    return deletions

def brute(s):
    counts = list(Counter(s).values())
    best = sum(counts)
    for kept in product(*[range(c + 1) for c in counts]):
        nonzero = [k for k in kept if k]
        if len(nonzero) == len(set(nonzero)):
            best = min(best, sum(counts) - sum(kept))
    return best

def gen(rng):
    return ("".join(rng.choice("abcd") for _ in range(rng.randint(0, 9))),)

print(min_deletions("aab"), min_deletions("aaabbbcc"), min_deletions("ceabaacb"))
print(stress(min_deletions, brute, gen, trials=500))
