# file: repeat/repeat.py
import random
import time
from check import stress

MOD = (1 << 61) - 1

def longest_repeat_brute(s):
    n, best = len(s), ""
    for i in range(n):
        for j in range(i + 1, n):
            k = 0
            while j + k < n and s[i + k] == s[j + k]:
                k += 1
            if k > len(best) or (k == len(best) and k > 0 and s[i:i + k] < best):
                best = s[i:i + k]
    return best

def longest_repeat(s, base=None):
    n = len(s)
    base = base or random.Random(n).randrange(256, MOD - 1)      # randomised base (DT-8)
    H, P = [0] * (n + 1), [1] * (n + 1)
    for i, ch in enumerate(s):
        H[i + 1] = (H[i] * base + ord(ch)) % MOD
        P[i + 1] = (P[i] * base) % MOD

    def repeated(L):
        """Smallest repeated substring of length L, or None. Hash matches are confirmed by comparing."""
        first, found = {}, None
        for i in range(n - L + 1):
            h = (H[i + L] - H[i] * P[L]) % MOD
            j = first.setdefault(h, i)
            if j != i and s[j:j + L] == s[i:i + L]:
                if found is None or s[i:i + L] < found:
                    found = s[i:i + L]
        return found

    lo, hi, best = 1, n - 1, ""                                   # invariant: answer length is in [lo-1, hi]
    while lo <= hi:
        mid = (lo + hi) // 2
        r = repeated(mid)
        if r is not None:
            best, lo = r, mid + 1                                 # a repeat of length mid exists: try longer
        else:
            hi = mid - 1
    return best

def gen(rng):
    return ("".join(rng.choice("ab") for _ in range(rng.randint(0, 12))),)

print(stress(longest_repeat, longest_repeat_brute, gen))
print([longest_repeat(w) for w in ("banana", "abcd", "aaaaa", "mississippi")])
rng = random.Random(1)
text = "".join(rng.choice("acgt") for _ in range(200_000))
planted = text[1000:1040]
text = text[:150_000] + planted + text[150_000:]                  # plant a 40-letter repeat in random DNA
t = time.perf_counter()
r = longest_repeat(text)
print(f"n={len(text):,} random DNA with a planted repeat: found length {len(r)} in {(time.perf_counter() - t) * 1000:.0f} ms; planted found: {planted in r}")
