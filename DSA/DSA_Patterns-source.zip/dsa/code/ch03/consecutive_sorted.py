# file: consecutive_sorted.py
from check import stress, rand_list

def longest_consecutive_sorted(nums):
    if not nums:
        return 0
    s = sorted(set(nums))
    best = cur = 1
    for prev, x in zip(s, s[1:]):
        cur = cur + 1 if x == prev + 1 else 1
        best = max(best, cur)
    return best

def longest_consecutive_hash(nums):
    have, best = set(nums), 0
    for x in have:
        if x - 1 not in have:                       # x starts a run
            y = x
            while y + 1 in have:
                y += 1
            best = max(best, y - x + 1)
    return best

print(longest_consecutive_sorted([100, 4, 200, 1, 3, 2]), longest_consecutive_sorted([1, 2, 2, 3]))
print(stress(longest_consecutive_sorted, longest_consecutive_hash, lambda rng: (rand_list(rng, -6, 6, max_len=12),)))
