# file: counting.py
from collections import Counter, defaultdict
from check import stress, examples

def first_unique_char(s):
    counts = Counter(s)
    for i, ch in enumerate(s):
        if counts[ch] == 1:
            return i
    return -1

def can_construct(note, magazine):
    need = Counter(note)
    need.subtract(Counter(magazine))
    return all(v <= 0 for v in need.values())        # or: not (Counter(note) - Counter(magazine))

def group_anagrams(words):
    groups = defaultdict(list)
    for w in words:
        groups[tuple(sorted(w))].append(w)           # canonical form: sorted letters (O(k log k) per word)
    return sorted(sorted(g) for g in groups.values())

def group_anagrams_counts(words):                    # O(k) per word: letter-count signature
    groups = defaultdict(list)
    for w in words:
        sig = [0] * 26
        for ch in w:
            sig[ord(ch) - 97] += 1
        groups[tuple(sig)].append(w)                 # lists are not hashable; tuples are
    return sorted(sorted(g) for g in groups.values())

def top_k_frequent(nums, k):                         # bucket sort by frequency: O(n)
    counts = Counter(nums)
    buckets = [[] for _ in range(len(nums) + 1)]
    for v, c in counts.items():
        buckets[c].append(v)
    out = []
    for c in range(len(buckets) - 1, 0, -1):
        for v in sorted(buckets[c]):
            out.append(v)
            if len(out) == k:
                return out
    return out

def rand_word(rng):
    return "".join(rng.choice("abc") for _ in range(rng.randint(0, 4)))

print(examples(first_unique_char, [(("leetcode",), 0), (("loveleetcode",), 2), (("aabb",), -1)]))
print(stress(can_construct, lambda n, m: all(n.count(c) <= m.count(c) for c in set(n)), lambda rng: (rand_word(rng), rand_word(rng))))
print(stress(group_anagrams_counts, group_anagrams, lambda rng: ([rand_word(rng) for _ in range(rng.randint(0, 6))],)))
print(stress(top_k_frequent, lambda a, k: [v for v, _ in sorted(Counter(a).items(), key=lambda p: (-p[1], p[0]))][:k],
             lambda rng: ([rng.randint(0, 4) for _ in range(rng.randint(1, 9))], rng.randint(1, 3))))
