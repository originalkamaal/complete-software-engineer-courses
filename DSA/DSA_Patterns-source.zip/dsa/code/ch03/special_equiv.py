# file: special_equiv.py
from itertools import permutations
from check import stress

def key(w):
    return "".join(sorted(w[0::2])), "".join(sorted(w[1::2]))

def count_groups(words):
    return len({key(w) for w in words})

def reachable(w):
    ev, od = w[0::2], w[1::2]
    out = set()
    for pe in set(permutations(ev)):
        for po in set(permutations(od)):
            s = [""] * len(w)
            s[0::2], s[1::2] = pe, po
            out.add("".join(s))
    return frozenset(out)

def brute(words):
    return len({reachable(w) for w in words})

def gen(rng):
    n = rng.randint(1, 4)
    return ([("".join(rng.choice("ab") for _ in range(n))) for _ in range(rng.randint(1, 6))],)

print(count_groups(["abcd", "cdab", "cbad", "xyzz", "zzxy", "zzyx"]))
print(stress(count_groups, brute, gen, trials=500))
