# file: complement.py
from collections import Counter
from itertools import product
from check import stress, rand_list

def count_pairs_with_diff(a, k):                      # pairs i<j with |a[i] - a[j]| == k
    seen, count = Counter(), 0
    for x in a:
        count += seen[x - k] + (seen[x + k] if k != 0 else 0)
        seen[x] += 1
    return count

def count_pairs_with_diff_brute(a, k):
    return sum(1 for i in range(len(a)) for j in range(i + 1, len(a)) if abs(a[i] - a[j]) == k)

def four_sum_count(A, B, C, D):                       # tuples (i,j,k,l) with A[i]+B[j]+C[k]+D[l] == 0
    ab = Counter(a + b for a in A for b in B)         # O(n^2) pair sums
    return sum(ab[-(c + d)] for c in C for d in D)

def four_sum_count_brute(A, B, C, D):
    return sum(1 for a, b, c, d in product(A, B, C, D) if a + b + c + d == 0)

print(stress(count_pairs_with_diff, count_pairs_with_diff_brute, lambda rng: (rand_list(rng), rng.randint(0, 3))))
print(stress(four_sum_count, four_sum_count_brute, lambda rng: tuple(rand_list(rng, -3, 3, 4) for _ in range(4))))
