# file: exactly_k.py
from collections import Counter
from check import stress, rand_list

def at_most_k_distinct(a, k):
    count, left, total = Counter(), 0, 0
    for right, x in enumerate(a):
        count[x] += 1
        while len(count) > k:
            count[a[left]] -= 1
            if count[a[left]] == 0:
                del count[a[left]]
            left += 1
        total += right - left + 1                 # all windows ending at right that start in [left, right]
    return total

def exactly_k_distinct(a, k):
    return at_most_k_distinct(a, k) - (at_most_k_distinct(a, k - 1) if k > 0 else 0)

def exactly_k_distinct_brute(a, k):
    return sum(1 for i in range(len(a)) for j in range(i + 1, len(a) + 1) if len(set(a[i:j])) == k)

def count_nice(a, k):                             # subarrays with exactly k odd numbers
    odd = [x % 2 for x in a]
    def at_most(k):
        left = s = total = 0
        for right, x in enumerate(odd):
            s += x
            while s > k:
                s -= odd[left]
                left += 1
            total += right - left + 1
        return total
    return at_most(k) - (at_most(k - 1) if k > 0 else 0)

print(stress(exactly_k_distinct, exactly_k_distinct_brute, lambda rng: (rand_list(rng, 0, 3, 10), rng.randint(0, 3))))
print(stress(count_nice, lambda a, k: sum(1 for i in range(len(a)) for j in range(i + 1, len(a) + 1) if sum(x % 2 for x in a[i:j]) == k),
             lambda rng: (rand_list(rng, 0, 9, 10), rng.randint(0, 3))))
