# file: binary_goal.py
from check import stress, rand_list

def at_most(bits, goal):
    if goal < 0:
        return 0
    left = total = count = 0
    for right, b in enumerate(bits):
        total += b
        while total > goal:
            total -= bits[left]
            left += 1
        count += right - left + 1               # every window ending at right, starting at left..right
    return count

def exactly(bits, goal):
    return at_most(bits, goal) - at_most(bits, goal - 1)

def brute(bits, goal):
    return sum(sum(bits[i:j]) == goal for i in range(len(bits)) for j in range(i + 1, len(bits) + 1))

print(exactly([1, 0, 1, 0, 1], 2), exactly([0, 0, 0, 0, 0], 0))
print(stress(exactly, brute, lambda rng: (rand_list(rng, 0, 1, max_len=10), rng.randint(0, 3))))
