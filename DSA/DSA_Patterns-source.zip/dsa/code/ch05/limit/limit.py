# file: limit/limit.py
from collections import deque
import random
import time
from check import stress, rand_list

def longest_within_limit(a, limit):
    maxq, minq = deque(), deque()                # decreasing values / increasing values (indices)
    left = best = 0
    for right, x in enumerate(a):
        while maxq and a[maxq[-1]] <= x:
            maxq.pop()
        maxq.append(right)
        while minq and a[minq[-1]] >= x:
            minq.pop()
        minq.append(right)
        while a[maxq[0]] - a[minq[0]] > limit:     # invalid: shrink from the left
            left += 1
            if maxq[0] < left:
                maxq.popleft()
            if minq[0] < left:
                minq.popleft()
        best = max(best, right - left + 1)
    return best

def count_within_limit(a, limit):
    maxq, minq = deque(), deque()
    left = total = 0
    for right, x in enumerate(a):
        while maxq and a[maxq[-1]] <= x:
            maxq.pop()
        maxq.append(right)
        while minq and a[minq[-1]] >= x:
            minq.pop()
        minq.append(right)
        while a[maxq[0]] - a[minq[0]] > limit:
            left += 1
            if maxq[0] < left:
                maxq.popleft()
            if minq[0] < left:
                minq.popleft()
        total += right - left + 1
    return total

def all_windows(a):
    return [(i, j) for i in range(len(a)) for j in range(i + 1, len(a) + 1)]

print(stress(longest_within_limit, lambda a, l: max([j - i for i, j in all_windows(a) if max(a[i:j]) - min(a[i:j]) <= l], default=0),
             lambda rng: (rand_list(rng, 0, 9, 12), rng.randint(0, 5))))
print(stress(count_within_limit, lambda a, l: sum(1 for i, j in all_windows(a) if max(a[i:j]) - min(a[i:j]) <= l),
             lambda rng: (rand_list(rng, 0, 9, 12), rng.randint(0, 5))))
rng = random.Random(9)
a = [rng.randint(0, 10**6) for _ in range(500_000)]
t = time.perf_counter()
print(f"n=500,000: longest {longest_within_limit(a, 50_000)}, count {count_within_limit(a, 50_000):,}, {(time.perf_counter() - t) * 1000:.0f} ms for both")
