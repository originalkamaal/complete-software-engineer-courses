# file: variable.py
from collections import Counter
from check import stress, rand_list

def longest_no_repeat(s):
    last, left, best = {}, 0, 0
    for right, ch in enumerate(s):
        if ch in last and last[ch] >= left:
            left = last[ch] + 1                   # jump left past the previous occurrence
        last[ch] = right
        best = max(best, right - left + 1)
    return best

def longest_no_repeat_brute(s):
    return max([j - i for i in range(len(s)) for j in range(i + 1, len(s) + 1) if len(set(s[i:j])) == j - i], default=0)

def longest_ones_with_k_flips(bits, k):           # longest run of 1s if at most k zeros may be flipped
    left = zeros = best = 0
    for right, b in enumerate(bits):
        zeros += b == 0
        while zeros > k:                          # invalid: shrink
            zeros -= bits[left] == 0
            left += 1
        best = max(best, right - left + 1)
    return best

def min_len_sum_at_least(a, target):              # positive numbers only
    left, s, best = 0, 0, float("inf")
    for right, x in enumerate(a):
        s += x
        while s >= target:                        # valid: record, then try to shrink
            best = min(best, right - left + 1)
            s -= a[left]
            left += 1
    return 0 if best == float("inf") else best

def longest_at_most_k_distinct(s, k):
    count, left, best = Counter(), 0, 0
    for right, ch in enumerate(s):
        count[ch] += 1
        while len(count) > k:
            count[s[left]] -= 1
            if count[s[left]] == 0:
                del count[s[left]]
            left += 1
        best = max(best, right - left + 1)
    return best

def windows(n):
    return [(i, j) for i in range(n) for j in range(i + 1, n + 1)]

def word(rng):
    return "".join(rng.choice("abcd") for _ in range(rng.randint(0, 9)))

print(stress(longest_no_repeat, longest_no_repeat_brute, lambda rng: (word(rng),)))
print(stress(longest_ones_with_k_flips, lambda b, k: max([j - i for i, j in windows(len(b)) if b[i:j].count(0) <= k], default=0),
             lambda rng: (rand_list(rng, 0, 1, 10), rng.randint(0, 2))))
print(stress(min_len_sum_at_least, lambda a, t: min([j - i for i, j in windows(len(a)) if sum(a[i:j]) >= t], default=0),
             lambda rng: (rand_list(rng, 1, 5), rng.randint(1, 12))))
print(stress(longest_at_most_k_distinct, lambda s, k: max([j - i for i, j in windows(len(s)) if len(set(s[i:j])) <= k], default=0),
             lambda rng: (word(rng), rng.randint(0, 3))))
