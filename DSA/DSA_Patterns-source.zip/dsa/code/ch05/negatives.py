# file: negatives.py
from check import stress, rand_list
from variable import min_len_sum_at_least

def brute(a, t):
    return min([j - i for i in range(len(a)) for j in range(i + 1, len(a) + 1) if sum(a[i:j]) >= t], default=0)

try:
    print(stress(min_len_sum_at_least, brute, lambda rng: (rand_list(rng, -5, 5), rng.randint(1, 8))))
except AssertionError as e:
    print("with negative numbers:", e)
