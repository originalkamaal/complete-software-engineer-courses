# file: min_window.py
from collections import Counter
from check import stress

def min_window(s, t):
    if not t:
        return ""
    need = Counter(t)
    missing = len(t)                                # characters (with multiplicity) still to cover
    left = 0
    best = (float("inf"), 0, 0)
    for right, ch in enumerate(s):
        if need[ch] > 0:
            missing -= 1                            # this character was still needed
        need[ch] -= 1                               # negative counts = surplus inside the window
        while missing == 0:
            if right - left + 1 < best[0]:
                best = (right - left + 1, left, right + 1)
            need[s[left]] += 1
            if need[s[left]] > 0:
                missing += 1                        # removing it made the window invalid
            left += 1
    return s[best[1]:best[2]] if best[0] != float("inf") else ""

def min_window_brute(s, t):
    need = Counter(t)
    best = None
    for i in range(len(s)):
        for j in range(i + 1, len(s) + 1):
            if not need - Counter(s[i:j]) and (best is None or j - i < len(best)):
                best = s[i:j]
                break
    return best or ""

def same_length(x, y, args):                        # several windows may tie: compare lengths and validity
    s, t = args
    return len(x) == len(y) and (not y or not (Counter(t) - Counter(x))) and x in s

def word(rng, n):
    return "".join(rng.choice("abc") for _ in range(rng.randint(1, n)))

print(stress(min_window, min_window_brute, lambda rng: (word(rng, 10), word(rng, 3)), same=same_length))
print(repr(min_window("ADOBECODEBANC", "ABC")))
