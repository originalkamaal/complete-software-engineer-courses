# file: anagram_matches.py
from collections import Counter
from check import stress

def find_anagrams_o1(s, p):
    k, need = len(p), Counter(p)
    have, matches, out = Counter(), 0, []
    def change(ch, delta):
        nonlocal matches
        if have[ch] == need[ch]:
            matches -= 1                         # was right, about to change
        have[ch] += delta
        if have[ch] == need[ch]:
            matches += 1
    alphabet = set(s) | set(p)
    matches = sum(1 for ch in alphabet if need[ch] == 0)   # letters needing 0 start out right
    for i, ch in enumerate(s):
        change(ch, +1)
        if i >= k:
            change(s[i - k], -1)
        if i >= k - 1 and matches == len(alphabet):
            out.append(i - k + 1)
    return out

def brute(s, p):
    return [i for i in range(len(s) - len(p) + 1) if sorted(s[i:i + len(p)]) == sorted(p)]

def word(rng, n):
    return "".join(rng.choice("abc") for _ in range(rng.randint(1, n)))

print(find_anagrams_o1("cbaebabacd", "abc"), find_anagrams_o1("abab", "ab"))
print(stress(find_anagrams_o1, brute, lambda rng: (word(rng, 10), word(rng, 3))))
