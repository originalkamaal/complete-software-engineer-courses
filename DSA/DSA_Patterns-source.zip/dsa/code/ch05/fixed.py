# file: fixed.py
from collections import Counter
from check import stress, rand_list

def max_sum_k(a, k):
    s = sum(a[:k])
    best = s
    for i in range(k, len(a)):
        s += a[i] - a[i - k]                      # one in, one out
        best = max(best, s)
    return best

def find_anagrams(s, p):
    """Start indices of substrings of s that are anagrams of p."""
    k, need, have, out = len(p), Counter(p), Counter(), []
    for i, ch in enumerate(s):
        have[ch] += 1
        if i >= k:
            old = s[i - k]
            have[old] -= 1
            if have[old] == 0:
                del have[old]                     # keep the Counter comparable: no zero entries
        if i >= k - 1 and have == need:
            out.append(i - k + 1)
    return out

def find_anagrams_brute(s, p):
    return [i for i in range(len(s) - len(p) + 1) if sorted(s[i:i + len(p)]) == sorted(p)]

def word(rng, n=8):
    return "".join(rng.choice("abc") for _ in range(rng.randint(0, n)))

print(stress(max_sum_k, lambda a, k: max(sum(a[i:i + k]) for i in range(len(a) - k + 1)),
             lambda rng: ((a := rand_list(rng, min_len=1)), rng.randint(1, len(a)))))
print(stress(find_anagrams, find_anagrams_brute, lambda rng: (word(rng), word(rng, 3) or "a")))
