# file: cover_distinct.py
from collections import Counter
from check import stress, rand_list

def shortest_with_all_distinct(a):
    """Length of the shortest subarray containing every distinct value of a."""
    need = len(set(a))
    if need == 0:
        return 0
    have, left, best, covered = Counter(), 0, len(a), 0
    for right, x in enumerate(a):
        have[x] += 1
        if have[x] == 1:
            covered += 1
        while covered == need:                         # valid: record, then shrink
            best = min(best, right - left + 1)
            have[a[left]] -= 1
            if have[a[left]] == 0:
                covered -= 1
            left += 1
    return best

def brute(a):
    need = set(a)
    return min((j - i for i in range(len(a)) for j in range(i + 1, len(a) + 1) if set(a[i:j]) == need), default=0)

print(shortest_with_all_distinct([7, 3, 7, 3, 1, 3, 4, 1]), shortest_with_all_distinct([1, 1, 1]))
print(stress(shortest_with_all_distinct, brute, lambda rng: (rand_list(rng, 0, 3, max_len=10),)))
