# file: window_max.py
from collections import deque
from check import stress, rand_list

def window_max(a, k):
    dq, out = deque(), []
    for i, x in enumerate(a):
        while dq and a[dq[-1]] <= x:
            dq.pop()                              # dominated: smaller and older
        dq.append(i)
        if dq[0] <= i - k:
            dq.popleft()                          # out of the window
        if i >= k - 1:
            out.append(a[dq[0]])
    return out

print(stress(window_max, lambda a, k: [max(a[i:i + k]) for i in range(len(a) - k + 1)],
             lambda rng: ((a := rand_list(rng, min_len=1)), rng.randint(1, len(a)))))
