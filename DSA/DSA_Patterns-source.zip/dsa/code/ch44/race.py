# file: race.py
import sys
import threading

sys.setswitchinterval(1e-6)                           # switch threads very often: expose races quickly

class Counter:
    def __init__(self):
        self.n = 0
        self.lock = threading.Lock()

def noop():
    pass

def unsafe(c, k):
    for _ in range(k):
        v = c.n
        noop()                                        # a call: the interpreter may switch threads here
        c.n = v + 1

def safe(c, k):
    for _ in range(k):
        with c.lock:
            v = c.n
            noop()
            c.n = v + 1

for name, f in (("unsafe", unsafe), ("locked", safe)):
    c = Counter()
    threads = [threading.Thread(target=f, args=(c, 100_000)) for _ in range(4)]
    for t in threads: t.start()
    for t in threads: t.join()
    print(f"{name}: expected 400,000, got {c.n:,}")
