# file: pool/pool.py
import queue
import random
import threading
import time

class Future:
    def __init__(self):
        self._done = threading.Event()
        self._result = self._exc = None
    def _set(self, result=None, exc=None):
        self._result, self._exc = result, exc
        self._done.set()
    def result(self, timeout=None):
        if not self._done.wait(timeout):
            raise TimeoutError
        if self._exc:
            raise self._exc
        return self._result

class ThreadPool:
    _STOP = object()
    def __init__(self, workers):
        self.tasks = queue.Queue()
        self.threads = [threading.Thread(target=self._worker, daemon=True) for _ in range(workers)]
        for t in self.threads:
            t.start()
    def _worker(self):
        while True:
            item = self.tasks.get()
            if item is self._STOP:
                return
            fut, fn, args = item
            try:
                fut._set(result=fn(*args))
            except Exception as e:                      # deliver errors to the caller
                fut._set(exc=e)
    def submit(self, fn, *args):
        fut = Future()
        self.tasks.put((fut, fn, args))
        return fut
    def shutdown(self):
        for _ in self.threads:
            self.tasks.put(self._STOP)
        for t in self.threads:
            t.join()

rng = random.Random(42)
N = 2_000
links = {p: rng.sample(range(N), 4) for p in range(N)}  # simulated web: each page links to 4 others

def fetch(page):                                         # pretend network I/O
    time.sleep(0.002)
    if page == 1234:
        raise ConnectionError("page 1234 timed out")
    return links[page]

def crawl(workers):
    pool = ThreadPool(workers)
    seen, frontier, errors = {0}, [0], 0
    while frontier:                                      # level by level: submit all, then collect
        futures = [(p, pool.submit(fetch, p)) for p in frontier]
        frontier = []
        for p, f in futures:
            try:
                for q in f.result():
                    if q not in seen:
                        seen.add(q); frontier.append(q)
            except ConnectionError:
                errors += 1
    pool.shutdown()
    return len(seen), errors

for w in (1, 8, 32):
    t = time.perf_counter()
    pages, errors = crawl(w)
    print(f"{w:>2} workers: {pages:,} pages discovered, {errors} fetch error(s), {time.perf_counter() - t:.2f} s")
