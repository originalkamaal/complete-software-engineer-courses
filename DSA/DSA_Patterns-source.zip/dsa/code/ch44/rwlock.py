# file: rwlock.py
import random
import sys
import threading
import time

sys.setswitchinterval(1e-6)

class RWLock:
    def __init__(self):
        self.cond = threading.Condition()
        self.readers = 0
        self.writer = False
        self.waiting_writers = 0
    def acquire_read(self):
        with self.cond:
            while self.writer or self.waiting_writers:  # writer preference
                self.cond.wait()
            self.readers += 1
    def release_read(self):
        with self.cond:
            self.readers -= 1
            if self.readers == 0:
                self.cond.notify_all()
    def acquire_write(self):
        with self.cond:
            self.waiting_writers += 1
            while self.writer or self.readers:
                self.cond.wait()
            self.waiting_writers -= 1
            self.writer = True
    def release_write(self):
        with self.cond:
            self.writer = False
            self.cond.notify_all()

class Barrier:
    def __init__(self, n):
        self.n, self.count, self.generation = n, 0, 0
        self.cond = threading.Condition()
    def wait(self):
        with self.cond:
            gen = self.generation
            self.count += 1
            if self.count == self.n:
                self.count, self.generation = 0, self.generation + 1   # release everyone, start a new round
                self.cond.notify_all()
            else:
                while gen == self.generation:
                    self.cond.wait()

rw, state = RWLock(), {"readers": 0, "writers": 0, "violations": 0}
guard = threading.Lock()
def reader():
    for _ in range(2_000):
        rw.acquire_read()
        with guard:
            state["readers"] += 1
            state["violations"] += state["writers"] > 0
        with guard:
            state["readers"] -= 1
        rw.release_read()
def writer():
    for _ in range(500):
        rw.acquire_write()
        with guard:
            state["writers"] += 1
            state["violations"] += state["writers"] > 1 or state["readers"] > 0
        with guard:
            state["writers"] -= 1
        rw.release_write()
ts = [threading.Thread(target=reader) for _ in range(6)] + [threading.Thread(target=writer) for _ in range(2)]
for t in ts: t.start()
for t in ts: t.join()
print("readers-writer lock: exclusion violations =", state["violations"])

b, rounds, log, llock = Barrier(4), 200, [], threading.Lock()
def worker(i):
    for r in range(rounds):
        with llock:
            log.append(r)
        b.wait()
ts = [threading.Thread(target=worker, args=(i,)) for i in range(4)]
for t in ts: t.start()
for t in ts: t.join()
print("barrier: every round's 4 arrivals happened before any arrival of the next round:",
      all(log[4 * r: 4 * r + 4] == [r] * 4 for r in range(rounds)))
