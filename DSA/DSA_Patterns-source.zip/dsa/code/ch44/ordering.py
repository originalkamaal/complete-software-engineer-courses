# file: ordering.py
import random
import sys
import threading

sys.setswitchinterval(1e-6)

def print_in_order(order_of_start):
    out, e1, e2 = [], threading.Event(), threading.Event()
    def first():  out.append("first");  e1.set()
    def second(): e1.wait(); out.append("second"); e2.set()
    def third():  e2.wait(); out.append("third")
    fs = {"first": first, "second": second, "third": third}
    threads = [threading.Thread(target=fs[name]) for name in order_of_start]
    for t in threads: t.start()
    for t in threads: t.join()
    return out

def foo_bar(n):
    out = []
    can_foo, can_bar = threading.Semaphore(1), threading.Semaphore(0)
    def foo():
        for _ in range(n):
            can_foo.acquire(); out.append("foo"); can_bar.release()
    def bar():
        for _ in range(n):
            can_bar.acquire(); out.append("bar"); can_foo.release()
    ts = [threading.Thread(target=bar), threading.Thread(target=foo)]
    for t in ts: t.start()
    for t in ts: t.join()
    return out

rng = random.Random(41)
ok = all(print_in_order(rng.sample(["first", "second", "third"], 3)) == ["first", "second", "third"] for _ in range(300))
print("print in order, 300 random start orders:", ok)
res = foo_bar(10_000)
print("foo/bar alternation, 10,000 rounds:", res == ["foo", "bar"] * 10_000)
