# file: philosophers.py
import sys
import threading

sys.setswitchinterval(1e-6)

def dine(n, meals, ordered):
    forks = [threading.Lock() for _ in range(n)]
    eaten = [0] * n
    def philosopher(i):
        left, right = i, (i + 1) % n
        first, second = (min(left, right), max(left, right)) if ordered else (left, right)
        for _ in range(meals):
            with forks[first]:
                with forks[second]:
                    eaten[i] += 1
    ts = [threading.Thread(target=philosopher, args=(i,), daemon=True) for i in range(n)]
    for t in ts: t.start()
    for t in ts: t.join(timeout=3)
    return sum(eaten), any(t.is_alive() for t in ts)

total, stuck = dine(5, 20_000, ordered=True)
print(f"ordered forks: {total:,} meals eaten, deadlocked: {stuck}")
total, stuck = dine(5, 20_000, ordered=False)
print(f"left-then-right: {total:,} meals eaten before stopping, deadlocked: {stuck}")
