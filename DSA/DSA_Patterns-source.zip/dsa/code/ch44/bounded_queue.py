# file: bounded_queue.py
import sys
import threading
from collections import deque

sys.setswitchinterval(1e-6)

class BoundedQueue:
    def __init__(self, cap):
        self.cap, self.items = cap, deque()
        self.lock = threading.Lock()
        self.not_full = threading.Condition(self.lock)
        self.not_empty = threading.Condition(self.lock)
        self.max_seen = 0
    def put(self, x):
        with self.not_full:
            while len(self.items) == self.cap:         # while, not if
                self.not_full.wait()
            self.items.append(x)
            self.max_seen = max(self.max_seen, len(self.items))
            self.not_empty.notify()
    def get(self):
        with self.not_empty:
            while not self.items:
                self.not_empty.wait()
            x = self.items.popleft()
            self.not_full.notify()
            return x

q = BoundedQueue(5)
P, C, PER = 4, 3, 5_000
results, rlock = [], threading.Lock()
def producer(pid):
    for i in range(PER):
        q.put((pid, i))
def consumer():
    while True:
        x = q.get()
        if x is None:
            return
        with rlock:
            results.append(x)
producers = [threading.Thread(target=producer, args=(p,)) for p in range(P)]
consumers = [threading.Thread(target=consumer) for _ in range(C)]
for t in producers + consumers: t.start()
for t in producers: t.join()
for _ in consumers: q.put(None)                         # one "poison pill" per consumer
for t in consumers: t.join()
print(f"{len(results):,} items consumed, all distinct: {len(set(results)) == P * PER}, "
      f"queue never exceeded capacity: {q.max_seen <= 5}")
per_producer_in_order = all([i for p, i in results if p == pid] == sorted(i for p, i in results if p == pid) for pid in range(P))
print("each producer's items kept their relative order:", per_producer_in_order)
