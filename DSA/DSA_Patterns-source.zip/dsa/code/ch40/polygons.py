# file: polygons.py
import math
from check import stress
from geom import cross, on_segment, area2

def point_in_polygon(p, poly):                          # 1 inside, 0 on boundary, -1 outside
    inside = False
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        if cross(a, b, p) == 0 and on_segment(p, a, b):
            return 0
        if (a[1] > p[1]) != (b[1] > p[1]):              # edge straddles the horizontal line through p
            # x of intersection > p.x  <=>  sign test, done exactly without division
            if (cross(a, b, p) > 0) == (b[1] > a[1]):
                inside = not inside
    return 1 if inside else -1

def lattice_counts(poly):                               # (interior, boundary) by Pick's theorem
    A2 = abs(area2(poly))
    B = sum(math.gcd(abs(poly[i][0] - poly[i - 1][0]), abs(poly[i][1] - poly[i - 1][1])) for i in range(len(poly)))
    return (A2 - B + 2) // 2, B

def random_simple_polygon(rng):                         # star-shaped: sort random points by angle around a centre
    pts = {(rng.randint(-6, 6), rng.randint(-6, 6)) for _ in range(rng.randint(3, 7))}
    if len(pts) < 3:
        return [(0, 0), (3, 0), (0, 3)]
    cx = sum(x for x, _ in pts) / len(pts); cy = sum(y for _, y in pts) / len(pts)
    poly = sorted(pts, key=lambda p: (math.atan2(p[1] - cy, p[0] - cx), (p[0] - cx) ** 2 + (p[1] - cy) ** 2))
    return poly if area2(poly) != 0 else [(0, 0), (3, 0), (0, 3)]

def brute_counts(poly):                                 # classify every lattice point in the bounding box
    xs, ys = [x for x, _ in poly], [y for _, y in poly]
    inner = boundary = 0
    for x in range(min(xs), max(xs) + 1):
        for y in range(min(ys), max(ys) + 1):
            r = point_in_polygon((x, y), poly)
            inner += r == 1; boundary += r == 0
    return inner, boundary

def simple(poly):                                       # no two non-adjacent edges intersect
    from geom import segments_intersect
    n = len(poly)
    edges = [(poly[i], poly[(i + 1) % n]) for i in range(n)]
    return all(not segments_intersect(*edges[i], *edges[j]) for i in range(n) for j in range(i + 1, n)
               if j != i + 1 and not (i == 0 and j == n - 1))

print(stress(lattice_counts, brute_counts, lambda rng: (random_simple_polygon(rng),), valid=simple))
print(lattice_counts([(0, 0), (4, 0), (4, 3), (0, 3)]))
