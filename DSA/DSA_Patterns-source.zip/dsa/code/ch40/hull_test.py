# file: hull_test.py
from check import stress
from geom import cross
from hull import convex_hull

def hull_brute(points):                                 # a point is a hull vertex iff it is an extreme point
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts
    verts = set()
    for a in pts:
        for b in pts:
            if a != b and all(cross(a, b, c) >= 0 for c in pts):     # every point left of or on line a->b
                on = [c for c in pts if cross(a, b, c) == 0]
                verts |= {min(on), max(on)}                           # only the endpoints of that edge
    return sorted(verts)

gen = lambda rng: ([(rng.randint(-4, 4), rng.randint(-4, 4)) for _ in range(rng.randint(1, 10))],)
print(stress(lambda p: sorted(convex_hull(p)), hull_brute, gen))
print(convex_hull([(0, 0), (1, 1), (2, 2), (2, 0), (0, 2), (1, 0)]))
