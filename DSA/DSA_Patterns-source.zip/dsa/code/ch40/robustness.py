# file: robustness.py
import random

def cross_f(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

rng = random.Random(33)
bad = 0
for _ in range(100_000):
    x = rng.uniform(0, 1)
    p, q = (0.5 + x * 1e-12, 0.5), (12.0, 12.0)
    r = (24.0, 24.0 + rng.uniform(-1e-12, 1e-12))
    s = {(cross_f(p, q, r) > 0) - (cross_f(p, q, r) < 0), (cross_f(q, r, p) > 0) - (cross_f(q, r, p) < 0),
         (cross_f(r, p, q) > 0) - (cross_f(r, p, q) < 0)}
    bad += len(s) > 1
print(f"near-collinear float triples with inconsistent orientation: {bad:,} of 100,000")
