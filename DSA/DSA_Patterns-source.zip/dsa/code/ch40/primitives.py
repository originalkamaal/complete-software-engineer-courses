# file: primitives.py
from fractions import Fraction
from check import stress
from geom import cross, segments_intersect, area2

def point_on(p, a, b):                                  # independent check: p = a + t(b - a), 0 <= t <= 1
    if a == b:
        return p == a
    t = Fraction((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1]), (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)
    return 0 <= t <= 1 and (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])) == p

def intersect_brute(a, b, c, d):                        # exact: parametric solve with Fractions, or overlap on a line
    if a == b:
        return point_on(a, c, d)
    if c == d:
        return point_on(c, a, b)
    r = (b[0] - a[0], b[1] - a[1]); s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    if den != 0:
        t = Fraction((c[0] - a[0]) * s[1] - (c[1] - a[1]) * s[0], den)
        u = Fraction((c[0] - a[0]) * r[1] - (c[1] - a[1]) * r[0], den)
        return 0 <= t <= 1 and 0 <= u <= 1
    if (c[0] - a[0]) * r[1] - (c[1] - a[1]) * r[0] != 0:
        return False                                    # parallel, not collinear
    key = (lambda p: p[0]) if (a[0], b[0], c[0], d[0]) != (a[0],) * 4 else (lambda p: p[1])
    lo1, hi1 = sorted((key(a), key(b))); lo2, hi2 = sorted((key(c), key(d)))
    return max(lo1, lo2) <= min(hi1, hi2)

P = lambda rng: (rng.randint(-3, 3), rng.randint(-3, 3))
print(stress(segments_intersect, intersect_brute, lambda rng: (P(rng), P(rng), P(rng), P(rng)), trials=5000))
print("turn:", cross((0, 0), (1, 0), (1, 1)), cross((0, 0), (1, 0), (2, 0)), cross((0, 0), (1, 0), (1, -1)))
print("square area x2:", area2([(0, 0), (2, 0), (2, 2), (0, 2)]))
