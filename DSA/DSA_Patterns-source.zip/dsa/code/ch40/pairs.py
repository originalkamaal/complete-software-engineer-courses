# file: pairs.py
import math
from sortedcontainers import SortedList
from check import stress
from geom import cross
from hull import convex_hull

def closest_pair_sq(points):                             # squared distance, exact
    pts = sorted(points)
    best = float("inf")
    active = SortedList()                                # (y, x) of points with x within sqrt(best)
    left = 0
    for x, y in pts:
        d = math.isqrt(best) + 1 if best != float("inf") else float("inf")
        while left < len(pts) and pts[left][0] < x - d:
            active.remove((pts[left][1], pts[left][0])); left += 1
        lo = active.bisect_left((y - d, -math.inf)) if d != float("inf") else 0
        for yy, xx in active.islice(lo):
            if yy > y + d:
                break
            best = min(best, (x - xx) ** 2 + (y - yy) ** 2)
        active.add((y, x))
    return best

def diameter_sq(points):
    h = convex_hull(points)
    if len(h) == 1:
        return 0
    if len(h) == 2:
        return (h[0][0] - h[1][0]) ** 2 + (h[0][1] - h[1][1]) ** 2
    best, j, n = 0, 1, len(h)
    for i in range(n):
        ni = (i + 1) % n
        while abs(cross(h[i], h[ni], h[(j + 1) % n])) > abs(cross(h[i], h[ni], h[j])):
            j = (j + 1) % n                                # farther from edge i -> i+1
        for p in (h[i], h[ni]):
            best = max(best, (p[0] - h[j][0]) ** 2 + (p[1] - h[j][1]) ** 2)
    return best

d2 = lambda a, b: (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
gen = lambda rng: ([(rng.randint(-20, 20), rng.randint(-20, 20)) for _ in range(rng.randint(2, 15))],)
if __name__ == "__main__":
  print(stress(closest_pair_sq, lambda p: min(d2(p[i], p[j]) for i in range(len(p)) for j in range(i + 1, len(p))), gen))
  print(stress(diameter_sq, lambda p: max(d2(a, b) for a in p for b in p), gen))
