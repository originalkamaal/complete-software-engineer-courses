# file: bigpoints/bigpoints.py
import random
import time
from collections import defaultdict
from hull import convex_hull
from pairs import closest_pair_sq, diameter_sq

def closest_by_grid(points, cell):                         # bucket points; compare neighbouring cells only
    grid = defaultdict(list)
    for p in points:
        grid[(p[0] // cell, p[1] // cell)].append(p)
    best = float("inf")
    for (gx, gy), ps in grid.items():
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for q in grid.get((gx + dx, gy + dy), ()):
                    for p in ps:
                        if p < q:
                            best = min(best, (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2)
    return best

rng = random.Random(34)
pts = list({(rng.randint(0, 10**6), rng.randint(0, 10**6)) for _ in range(100_000)})
t = time.perf_counter(); h = convex_hull(pts); th = time.perf_counter() - t
t = time.perf_counter(); dia = diameter_sq(pts); td = time.perf_counter() - t
brute_dia = max((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 for a in h for b in h)
t = time.perf_counter(); cp = closest_pair_sq(pts); tc = time.perf_counter() - t
grid = closest_by_grid(pts, 5_000)
print(f"{len(pts):,} points: hull has {len(h)} vertices [{th * 1000:.0f} ms]")
print(f"diameter^2 = {dia:,} [{td * 1000:.0f} ms], brute force over hull vertices agrees: {dia == brute_dia}")
print(f"closest pair distance^2 = {cp:,} [{tc * 1000:.0f} ms], grid method agrees: {cp == grid}")
