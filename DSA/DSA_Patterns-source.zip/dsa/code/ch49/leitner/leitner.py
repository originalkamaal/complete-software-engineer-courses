# file: leitner/leitner.py
import random

DT_COUNT, P_COUNT = 57, 50
cards = [f"DT-{i}" for i in range(1, DT_COUNT + 1)] + [f"P-{i}" for i in range(1, P_COUNT + 1)]
INTERVAL = {1: 1, 2: 2, 3: 4, 4: 8, 5: 16}

def recall_probability(box):                         # a simple learner model: stronger memory in higher boxes
    return {1: 0.55, 2: 0.70, 3: 0.82, 4: 0.90, 5: 0.95}[box]

def simulate(days, rng, daily_new=8):
    box, due, introduced, reviews = {}, {}, 0, 0
    for day in range(days):
        while introduced < len(cards) and introduced < (day + 1) * daily_new:
            c = cards[introduced]; box[c], due[c] = 1, day; introduced += 1
        for c in [c for c in box if due[c] <= day]:
            reviews += 1
            if rng.random() < recall_probability(box[c]):
                box[c] = min(5, box[c] + 1)
            else:
                box[c] = 1
            due[c] = day + INTERVAL[box[c]]
    return box, reviews

rng = random.Random(46)
box, reviews = simulate(60, rng)
dist = {b: sum(1 for v in box.values() if v == b) for b in range(1, 6)}
print(f"{len(cards)} cards (DT-1..DT-{DT_COUNT}, P-1..P-{P_COUNT}), 60 days, 8 new cards per day")
print("cards per box:", dist)
print(f"total reviews: {reviews:,} (about {reviews / 60:.0f} per day) vs reviewing every card daily: "
      f"{sum(min(len(cards), (d + 1) * 8) for d in range(60)):,}")
