# file: gambler.py
import random

def ruin_probability(n, s, steps=10_000):
    p = [0.0] * (n + 1)
    p[s] = 1.0
    absorbed0 = 0.0
    for _ in range(steps):
        q = [0.0] * (n + 1)
        for i in range(1, n):
            q[i - 1] += p[i] / 2
            q[i + 1] += p[i] / 2
        absorbed0 += q[0]
        q[0] = q[n] = 0.0                     # absorbed mass leaves the table
        p = q
    return absorbed0

def simulate(n, s, games, rng):
    zero = 0
    for _ in range(games):
        x = s
        while 0 < x < n:
            x += rng.choice((-1, 1))
        zero += x == 0
    return zero / games

rng = random.Random(7)
for n, s in [(10, 3), (6, 5)]:
    dp = ruin_probability(n, s)
    print(f"n={n} s={s}: dp {dp:.4f}, formula {1 - s / n:.4f}, simulation within 0.02: {abs(simulate(n, s, 20_000, rng) - dp) < 0.02}")
