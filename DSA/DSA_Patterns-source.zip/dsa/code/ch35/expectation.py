# file: expectation.py
import random
from fractions import Fraction
from itertools import permutations
from check import stress

def expected_rolls_to_reach(n):                    # roll a die repeatedly, moving forward; expected rolls to pass/reach n
    E = [Fraction(0)] * (n + 6)                    # E[s] for s >= n is 0
    for s in range(n - 1, -1, -1):
        E[s] = 1 + sum(E[s + f] for f in range(1, 7)) / 6
    return E[0]

def coupon_collector(n):                            # expected draws to see all n coupons
    return sum(Fraction(n, k) for k in range(1, n + 1))   # n/n + n/(n-1) + ... + n/1

def expected_fixed_points(n):                       # linearity: each of n positions is fixed w.p. 1/n
    return Fraction(n, n) if n else Fraction(0)

def fixed_points_brute(n):
    perms = list(permutations(range(n)))
    return Fraction(sum(sum(p[i] == i for i in range(n)) for p in perms), len(perms))

print(stress(expected_fixed_points, fixed_points_brute, lambda rng: (rng.randint(0, 7),), trials=50))
print("expected rolls to reach 10:", expected_rolls_to_reach(10), "=", float(expected_rolls_to_reach(10)))
def draws_until_all(n, rng):
    seen, draws = set(), 0
    while len(seen) < n:
        seen.add(rng.randrange(n)); draws += 1
    return draws

rng = random.Random(28)
sim = sum(draws_until_all(50, rng) for _ in range(2000)) / 2000
print(f"coupon collector n=50: exact {float(coupon_collector(50)):.2f}, simulated over 2,000 runs {sim:.2f}")
