# file: games.py
from functools import cache
from check import stress

def can_win_take_away(n, k):                        # take 1..k stones; who takes the last stone wins
    win = [False] * (n + 1)
    for s in range(1, n + 1):
        win[s] = any(not win[s - t] for t in range(1, min(k, s) + 1))
    return win[n]

def predict_divisor_game(n):                         # choose x with 0 < x < n and n % x == 0, replace n by n - x
    @cache
    def win(m):
        return any(not win(m - x) for x in range(1, m) if m % x == 0)
    return win(n)

print(stress(can_win_take_away, lambda n, k: n % (k + 1) != 0, lambda rng: (rng.randint(0, 60), rng.randint(1, 6))))
print(stress(predict_divisor_game, lambda n: n % 2 == 0, lambda rng: (rng.randint(1, 200),)))
