# file: prob.py
from fractions import Fraction
from itertools import product
from check import stress

def knight_stays(n, k, r, c):                     # probability a knight making k random moves stays on an n x n board
    moves = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
    P = {(r, c): Fraction(1)}
    for _ in range(k):
        nxt = {}
        for (x, y), p in P.items():
            for dx, dy in moves:
                nx, ny = x + dx, y + dy
                if 0 <= nx < n and 0 <= ny < n:            # mass leaving the board is lost
                    nxt[(nx, ny)] = nxt.get((nx, ny), 0) + p / 8
        P = nxt
    return sum(P.values(), Fraction(0))

def brute(n, k, r, c):
    moves = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
    ok = 0
    for seq in product(moves, repeat=k):
        x, y, inside = r, c, True
        for dx, dy in seq:
            x, y = x + dx, y + dy
            inside = inside and 0 <= x < n and 0 <= y < n
        ok += inside
    return Fraction(ok, 8 ** k)

def dice_sum_distribution(n, faces=6):
    dist = {0: Fraction(1)}
    for _ in range(n):
        nxt = {}
        for s, p in dist.items():
            for f in range(1, faces + 1):
                nxt[s + f] = nxt.get(s + f, 0) + p / faces
        dist = nxt
    return dist

print(stress(knight_stays, brute, lambda rng: ((n := rng.randint(1, 5)), rng.randint(0, 4), rng.randrange(n), rng.randrange(n)), trials=300))
print("knight 8x8, 3 moves from a corner:", knight_stays(8, 3, 0, 0))
d = dice_sum_distribution(3)
print("three dice: P(sum = 10) =", d[10], "  most likely sums:", sorted(d, key=d.get, reverse=True)[:2])
