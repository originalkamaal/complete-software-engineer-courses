# file: snakes/snakes.py
import random
import time
from fractions import Fraction
from check import stress

LADDERS = {1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100}
SNAKES = {16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78}

def next_square(s, roll, N, jumps):
    t = s + roll
    if t > N:
        return s                                     # overshoot: stay
    return jumps.get(t, t)

def solve(A, b):
    """Gaussian elimination over Fractions (exact)."""
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        piv = next(r for r in range(col, n) if M[r][col] != 0)
        M[col], M[piv] = M[piv], M[col]
        inv = 1 / M[col][col]
        M[col] = [x * inv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [x - f * y for x, y in zip(M[r], M[col])]
    return [M[i][n] for i in range(n)]

def expected_turns(N, jumps):
    states = list(range(N))                          # squares 0..N-1; N is the goal (E = 0)
    idx = {s: i for i, s in enumerate(states)}
    A = [[Fraction(0)] * N for _ in range(N)]
    b = [Fraction(1)] * N
    for s in states:                                 # E[s] - (1/6) * sum E[next] = 1
        A[idx[s]][idx[s]] += 1
        for f in range(1, 7):
            t = next_square(s, f, N, jumps)
            if t != N:
                A[idx[s]][idx[t]] -= Fraction(1, 6)
    return solve(A, b)[0]

def simulate(N, jumps, games, rng):
    total = 0
    for _ in range(games):
        s, turns = 0, 0
        while s != N:
            s = next_square(s, rng.randint(1, 6), N, jumps); turns += 1
        total += turns
    return total / games

def value_iteration(N, jumps, sweeps):               # the "just iterate" approach, for comparison
    E = [0.0] * (N + 1)
    for _ in range(sweeps):
        E = [0.0 if s == N else 1 + sum(E[next_square(s, f, N, jumps)] for f in range(1, 7)) / 6 for s in range(N + 1)]
    return E[0]

def gen(rng):                                        # small random boards, checked against long simulation
    N = rng.randint(6, 15)
    jumps = {}
    for _ in range(rng.randint(0, 3)):
        a, b = rng.sample(range(1, N), 2)
        if a not in jumps and b not in jumps:
            jumps[a] = b
    return (N, jumps)

def close(N, jumps):
    exact = float(expected_turns(N, jumps))
    return abs(exact - value_iteration(N, jumps, 3000)) < 1e-6

print(stress(close, lambda N, j: True, gen, trials=100))
t = time.perf_counter()
E = expected_turns(100, {**LADDERS, **SNAKES})
el = time.perf_counter() - t
print(f"exact expected turns: {float(E):.6f}  (a fraction with a {len(str(E.denominator))}-digit denominator)  [{el:.1f} s]")
print(f"Monte Carlo, 100,000 games: {simulate(100, {**LADDERS, **SNAKES}, 100_000, random.Random(29)):.3f}")
for sweeps in (10, 50, 200, 1000):
    print(f"value iteration, {sweeps:>4} sweeps: {value_iteration(100, {**LADDERS, **SNAKES}, sweeps):.6f}")
