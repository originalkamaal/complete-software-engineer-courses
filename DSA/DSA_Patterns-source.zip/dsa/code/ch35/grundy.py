# file: grundy.py
from functools import cache, reduce
from operator import xor
from check import stress

def mex(s):
    m = 0
    while m in s:
        m += 1
    return m

@cache
def g_subtraction(n, moves):                        # remove any amount in `moves` from a pile
    return mex({g_subtraction(n - m, moves) for m in moves if m <= n})

def first_player_wins(piles, moves):                # several independent piles
    return reduce(xor, (g_subtraction(p, moves) for p in piles), 0) != 0

def brute(piles, moves):                            # direct search over tuples of piles
    @cache
    def win(state):
        return any(not win(tuple(sorted(state[:i] + (state[i] - m,) + state[i + 1:])))
                   for i in range(len(state)) for m in moves if m <= state[i])
    return win(tuple(sorted(piles)))

gen = lambda rng: ([rng.randint(0, 8) for _ in range(rng.randint(1, 3))], tuple(sorted(rng.sample(range(1, 5), rng.randint(1, 3)))))
print(stress(first_player_wins, brute, gen, trials=500))
print("Nim [3, 4, 5]:", "first player wins" if 3 ^ 4 ^ 5 else "second player wins", "| Grundy of pile 10 with moves {1,3,4}:", g_subtraction(10, (1, 3, 4)))
