# file: navigate.py
import bisect
from check import stress, rand_list
from bst import insert

def floor_key(root, x):
    best = None
    while root:
        if root.val <= x:
            best, root = root.val, root.right            # candidate; a larger one may be on the right
        else:
            root = root.left
    return best

def ceil_key(root, x):
    best = None
    while root:
        if root.val >= x:
            best, root = root.val, root.left
        else:
            root = root.right
    return best

def kth_smallest(root, k):                              # iterative in-order, stops early
    stack = []
    while True:
        while root:
            stack.append(root); root = root.left
        root = stack.pop()
        k -= 1
        if k == 0:
            return root.val
        root = root.right

def build_bst(keys):
    root = None
    for k in keys:
        root = insert(root, k)
    return root

def floor_brute(keys, x):
    s = sorted(set(keys)); i = bisect.bisect_right(s, x)
    return s[i - 1] if i else None
def ceil_brute(keys, x):
    s = sorted(set(keys)); i = bisect.bisect_left(s, x)
    return s[i] if i < len(s) else None

gen = lambda rng: (rand_list(rng, 0, 30, 12), rng.randint(-2, 32))
print(stress(lambda ks, x: floor_key(build_bst(ks), x), floor_brute, gen))
print(stress(lambda ks, x: ceil_key(build_bst(ks), x), ceil_brute, gen))
print(stress(lambda ks, k: kth_smallest(build_bst(ks), k), lambda ks, k: sorted(set(ks))[k - 1],
             lambda rng: ((ks := rand_list(rng, 0, 30, 12, 1)), rng.randint(1, len(set(ks))))))
