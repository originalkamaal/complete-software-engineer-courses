# file: orderstat/orderstat.py
import bisect
import random
import time
from check import stress, rand_list
from sortedcontainers import SortedList
from treap import Treap

def count_smaller_treap(a):
    t, out = Treap(), []
    for x in reversed(a):
        out.append(t.rank(x))
        t.add(x)
    return out[::-1]

def count_smaller_sl(a):
    s, out = SortedList(), []
    for x in reversed(a):
        out.append(s.bisect_left(x))
        s.add(x)
    return out[::-1]

def count_smaller_bisect(a):
    s, out = [], []
    for x in reversed(a):
        out.append(bisect.bisect_left(s, x))
        bisect.insort(s, x)
    return out[::-1]

def window_medians(a, k, kind):
    s = Treap() if kind == "treap" else SortedList()
    get = (lambda i: s.select(i)) if kind == "treap" else (lambda i: s[i])
    out = []
    for i, x in enumerate(a):
        s.add(x)
        if i >= k:
            s.remove(a[i - k])
        if i >= k - 1:
            out.append((get((k - 1) // 2) + get(k // 2)) / 2)
    return out

def medians_brute(a, k):
    return [(sorted(a[i:i + k])[(k - 1) // 2] + sorted(a[i:i + k])[k // 2]) / 2 for i in range(len(a) - k + 1)]

brute = lambda a: [sum(y < x for y in a[i + 1:]) for i, x in enumerate(a)]
gen = lambda rng: (rand_list(rng, -5, 5, 15),)
print(stress(count_smaller_treap, brute, gen))
print(stress(count_smaller_sl, brute, gen))
print(stress(lambda a, k: window_medians(a, k, "treap"), medians_brute, lambda rng: ((a := rand_list(rng, -5, 5, 12, 1)), rng.randint(1, len(a)))))

rng = random.Random(8)
a = [rng.randint(-10**9, 10**9) for _ in range(100_000)]
for name, f in (("treap", count_smaller_treap), ("SortedList", count_smaller_sl), ("bisect+insort", count_smaller_bisect)):
    t = time.perf_counter()
    r = f(a)
    print(f"count smaller, n=100,000, {name:>13}: {(time.perf_counter() - t) * 1000:6.0f} ms  (checksum {sum(r)})")
for kind in ("treap", "SortedList"):
    t = time.perf_counter()
    m = window_medians(a, 1001, kind)
    print(f"window medians, k=1001, {kind:>10}: {(time.perf_counter() - t) * 1000:6.0f} ms  (first {m[0]})")
