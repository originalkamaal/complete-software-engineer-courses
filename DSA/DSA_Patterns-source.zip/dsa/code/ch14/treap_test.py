# file: treap_test.py
import random
import bisect
import time
from check import stress
from treap import Treap

def run_treap(ops):
    t, out = Treap(), []
    for op, x in ops:
        if op == "add": t.add(x)
        elif op == "remove": out.append(t.remove(x))
        elif op == "rank": out.append(t.rank(x))
        elif op == "select" and len(t): out.append(t.select(x % len(t)))
    return out

def run_list(ops):
    s, out = [], []
    for op, x in ops:
        if op == "add": bisect.insort(s, x)
        elif op == "remove":
            i = bisect.bisect_left(s, x)
            ok = i < len(s) and s[i] == x
            if ok: s.pop(i)
            out.append(ok)
        elif op == "rank": out.append(bisect.bisect_left(s, x))
        elif op == "select" and s: out.append(s[x % len(s)])
    return out

gen = lambda rng: ([(rng.choice(["add", "add", "remove", "rank", "select"]), rng.randint(0, 8)) for _ in range(rng.randint(0, 30))],)
print(stress(run_treap, run_list, gen))

n = 200_000
t = Treap()
start = time.perf_counter()
for k in range(n):                                    # sorted insertions: the bad case for a plain BST
    t.add(k)
mid = t.select(n // 2)
print(f"{n:,} sorted inserts + select: median {mid} in {(time.perf_counter() - start) * 1000:.0f} ms")
