# file: bst.py
from check import stress
from tree import TreeNode, random_tree

def insert(root, key):
    if not root:
        return TreeNode(key)
    if key < root.val:
        root.left = insert(root.left, key)
    elif key > root.val:
        root.right = insert(root.right, key)
    return root                                         # duplicates ignored

def delete(root, key):
    if not root:
        return None
    if key < root.val:
        root.left = delete(root.left, key)
    elif key > root.val:
        root.right = delete(root.right, key)
    else:
        if not root.left:
            return root.right                           # 0 or 1 child: splice out
        if not root.right:
            return root.left
        succ = root.right                               # 2 children: copy the successor, delete it
        while succ.left:
            succ = succ.left
        root.val = succ.val
        root.right = delete(root.right, succ.val)
    return root

def is_valid_bst(root, lo=float("-inf"), hi=float("inf")):
    if not root:
        return True
    return lo < root.val < hi and is_valid_bst(root.left, lo, root.val) and is_valid_bst(root.right, root.val, hi)

def is_valid_wrong(root):                               # checks only children: misses grandchildren
    if not root:
        return True
    if root.left and root.left.val >= root.val: return False
    if root.right and root.right.val <= root.val: return False
    return is_valid_wrong(root.left) and is_valid_wrong(root.right)

def inorder(root):
    return inorder(root.left) + [root.val] + inorder(root.right) if root else []

def bst_ops(ops):
    root = None
    for op, k in ops:
        root = insert(root, k) if op == "+" else delete(root, k)
    return inorder(root), is_valid_bst(root)

def set_ops(ops):
    s = set()
    for op, k in ops:
        (s.add if op == "+" else s.discard)(k)
    return sorted(s), True

if __name__ == "__main__":
  print(stress(bst_ops, set_ops, lambda rng: ([(rng.choice("++-"), rng.randint(0, 9)) for _ in range(rng.randint(0, 20))],)))
  print(stress(is_valid_bst, lambda r: (v := inorder(r)) == sorted(set(v)) and len(v) == len(set(v)), lambda rng: (random_tree(rng, rng.randint(0, 6), 0, 6),)))
  try:
      print(stress(is_valid_wrong, lambda r: (v := inorder(r)) == sorted(set(v)) and len(v) == len(set(v)), lambda rng: (random_tree(rng, rng.randint(0, 6), 0, 6),)))
  except AssertionError:
      from tree import build, to_values
      bad = build([5, 3, 8, None, 6])                 # 6 sits in 5's left subtree
      print("parent-child check is wrong on", to_values(bad), "->", is_valid_wrong(bad), "; range check ->", is_valid_bst(bad))
