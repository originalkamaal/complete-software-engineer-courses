# file: height.py
import random
import sys
from bst import insert

sys.setrecursionlimit(10_000)

def height(root):
    h, level = 0, [root] if root else []
    while level:
        h += 1
        level = [c for n in level for c in (n.left, n.right) if c]
    return h

n = 2000
for name, keys in (("sorted", list(range(n))), ("random", random.Random(1).sample(range(n), n))):
    root = None
    for k in keys:
        root = insert(root, k)
    print(f"{name:>6} insertion order, n={n}: height {height(root)}")
