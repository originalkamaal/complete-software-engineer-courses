# file: sorted_to_bst.py
from tree import TreeNode
from check import stress

def to_bst(a, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    if lo >= hi:
        return None
    mid = (lo + hi) // 2
    return TreeNode(a[mid], to_bst(a, lo, mid), to_bst(a, mid + 1, hi))

def check(a):
    root = to_bst(a)
    out = []
    def go(n):                                   # returns height; -1 marks "unbalanced"
        if not n:
            return 0
        l = go(n.left)
        out.append(n.val)
        r = go(n.right)
        return -1 if min(l, r) < 0 or abs(l - r) > 1 else 1 + max(l, r)
    balanced = go(root) >= 0
    return balanced and out == a

print(stress(check, lambda a: True, lambda rng: (sorted(rng.sample(range(100), rng.randint(0, 20))),)))
