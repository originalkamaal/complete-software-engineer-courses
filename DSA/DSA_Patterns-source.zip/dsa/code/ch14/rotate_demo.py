# file: rotate_demo.py
from tree import TreeNode, random_tree
from check import stress

def rotate_right(y):
    x = y.left
    y.left, x.right = x.right, y
    return x

def inorder(n):
    return [] if not n else inorder(n.left) + [n.val] + inorder(n.right)

def height(n):
    return 0 if not n else 1 + max(height(n.left), height(n.right))

def chain(n):                                   # a left-leaning chain n, n-1, ..., 1
    root = None
    for v in range(1, n + 1):
        root = TreeNode(v, root)
    return root

def rotations_preserve_order(root):
    if not root or not root.left:
        return True
    before = inorder(root)
    return inorder(rotate_right(root)) == before

t = chain(7)
print("chain height", height(t), "-> after one rotation at the root:", height(rotate_right(t)))
print(stress(rotations_preserve_order, lambda r: True, lambda rng: (random_tree(rng, rng.randint(0, 10)),)))
