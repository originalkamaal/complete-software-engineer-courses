# file: bst_two_sum.py
from tree import TreeNode
from check import stress

def insert(root, k):
    if not root:
        return TreeNode(k)
    if k < root.val:
        root.left = insert(root.left, k)
    else:
        root.right = insert(root.right, k)
    return root

def iterate(root, forward):
    stack, n = [], root
    while stack or n:
        while n:
            stack.append(n)
            n = n.left if forward else n.right
        n = stack.pop()
        yield n.val
        n = n.right if forward else n.left

def has_pair(root, target):
    lo, hi = iterate(root, True), iterate(root, False)
    a, b = next(lo, None), next(hi, None)
    while a is not None and b is not None and a < b:
        s = a + b
        if s == target:
            return True
        if s < target:
            a = next(lo, None)
        else:
            b = next(hi, None)
    return False

def gen(rng):
    keys = rng.sample(range(-20, 20), rng.randint(0, 10))
    root = None
    for k in keys:
        root = insert(root, k)
    return root, rng.randint(-20, 20), keys

def run(root, t, keys):
    return has_pair(root, t)

def brute(root, t, keys):
    return any(keys[i] + keys[j] == t for i in range(len(keys)) for j in range(i + 1, len(keys)))

print(stress(run, brute, gen))
