# file: template.py
import bisect
from check import stress, rand_list

def first_true(lo, hi, ok):
    """Smallest i in [lo, hi) with ok(i) True, assuming ok is monotone (F..F T..T). Returns hi if none."""
    while lo < hi:
        mid = (lo + hi) // 2                  # mid < hi always, so hi = mid makes progress
        if ok(mid):
            hi = mid                          # mid is true: the answer is at mid or to the left
        else:
            lo = mid + 1                      # mid is false: the answer is strictly to the right
    return lo

def lower_bound(a, x):                        # first index with a[i] >= x
    return first_true(0, len(a), lambda i: a[i] >= x)

def upper_bound(a, x):                        # first index with a[i] > x
    return first_true(0, len(a), lambda i: a[i] > x)

def search_range(a, x):                       # first and last index of x, or (-1, -1)
    l, r = lower_bound(a, x), upper_bound(a, x)
    return (l, r - 1) if l < r else (-1, -1)

def last_true(lo, hi, ok):
    """Largest i in [lo, hi) with ok(i) True for a T..T F..F predicate. Returns lo-1 if none."""
    return first_true(lo, hi, lambda i: not ok(i)) - 1

def isqrt(n):                                 # largest r with r*r <= n
    return last_true(0, n + 2, lambda r: r * r <= n)

def gen(rng):
    return sorted(rand_list(rng, 0, 6, 10)), rng.randint(-1, 7)

if __name__ == "__main__":                     # this file is also imported by later programs
    print(stress(lower_bound, bisect.bisect_left, gen))
    print(stress(upper_bound, bisect.bisect_right, gen))
    print(stress(search_range, lambda a, x: (a.index(x), len(a) - 1 - a[::-1].index(x)) if x in a else (-1, -1), gen))
    print(stress(isqrt, lambda n: int(n ** 0.5), lambda rng: (rng.randint(0, 10**6),)))
