# file: rotated_dups.py
from check import stress, rand_list

def find_min_rotated_dups(a):
    lo, hi = 0, len(a) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] > a[hi]:
            lo = mid + 1                 # the minimum is to the right of mid
        elif a[mid] < a[hi]:
            hi = mid                     # mid could be the minimum
        else:
            hi -= 1                      # cannot tell: a[hi] has a copy at mid, drop it
    return a[lo]

def gen(rng):
    a = sorted(rand_list(rng, 0, 3, min_len=1))
    k = rng.randint(0, len(a) - 1)
    return (a[k:] + a[:k],)

print(find_min_rotated_dups([2, 2, 2, 0, 1]), find_min_rotated_dups([1, 0, 1, 1, 1]), find_min_rotated_dups([1, 1, 1, 0, 1]))
print(stress(find_min_rotated_dups, min, gen))
