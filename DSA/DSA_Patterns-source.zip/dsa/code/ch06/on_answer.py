# file: on_answer.py
from itertools import combinations
from check import stress, rand_list
from template import first_true, last_true

def ship_within_days(weights, days):
    """Smallest ship capacity that ships all packages, in order, within `days` days."""
    def can(cap):
        used, load = 1, 0
        for w in weights:
            if load + w > cap:
                used, load = used + 1, 0
            load += w
        return used <= days
    return first_true(max(weights), sum(weights) + 1, can)

def ship_brute(weights, days):
    n = len(weights)
    best = sum(weights)
    for k in range(min(days, n)):                   # choose k cut points
        for cuts in combinations(range(1, n), k):
            parts = [weights[i:j] for i, j in zip((0,) + cuts, cuts + (n,))]
            best = min(best, max(sum(p) for p in parts))
    return best

def koko(piles, hours):
    """Smallest eating speed k (bananas/hour, one pile per hour at most) to finish within `hours`."""
    return first_true(1, max(piles) + 1, lambda k: sum((p + k - 1) // k for p in piles) <= hours)

def aggressive_cows(stalls, cows):
    """Largest minimum distance between `cows` cows placed in the stalls."""
    stalls = sorted(stalls)
    def can(d):
        count, last = 1, stalls[0]
        for s in stalls[1:]:
            if s - last >= d:
                count, last = count + 1, s
        return count >= cows
    return last_true(0, stalls[-1] - stalls[0] + 1, can)

def cows_brute(stalls, cows):
    return max(min(b - a for a, b in zip(c, c[1:])) for c in combinations(sorted(stalls), cows))

print(stress(ship_within_days, ship_brute, lambda rng: (rand_list(rng, 1, 9, 7, 1), rng.randint(1, 4))))
print(stress(koko, lambda p, h: next(k for k in range(1, max(p) + 1) if sum(-(-x // k) for x in p) <= h),
             lambda rng: ((p := rand_list(rng, 1, 20, 5, 1)), rng.randint(len(p), 3 * len(p)))))
print(stress(aggressive_cows, cows_brute, lambda rng: (rng.sample(range(0, 30), rng.randint(2, 7)), 2 + rng.randint(0, 2)),
             valid=lambda s, c: len(s) >= c))
