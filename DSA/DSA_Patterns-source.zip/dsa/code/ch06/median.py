# file: median.py
from check import stress, rand_list

def median_two_sorted(a, b):
    if len(a) > len(b):
        a, b = b, a                                   # binary search over the shorter array
    m, n = len(a), len(b)
    half = (m + n + 1) // 2
    lo, hi = 0, m
    NEG, POS = float("-inf"), float("inf")
    while lo <= hi:
        i = (lo + hi) // 2                            # take i elements from a ...
        j = half - i                                  # ... and j from b for the left half
        a_left = a[i - 1] if i > 0 else NEG
        a_right = a[i] if i < m else POS
        b_left = b[j - 1] if j > 0 else NEG
        b_right = b[j] if j < n else POS
        if a_left <= b_right and b_left <= a_right:   # a valid partition
            if (m + n) % 2:
                return float(max(a_left, b_left))
            return (max(a_left, b_left) + min(a_right, b_right)) / 2
        if a_left > b_right:
            hi = i - 1                                # took too many from a
        else:
            lo = i + 1                                # took too few from a
    raise ValueError("inputs must be sorted")

def median_brute(a, b):
    c = sorted(a + b)
    n = len(c)
    return float(c[n // 2]) if n % 2 else (c[n // 2 - 1] + c[n // 2]) / 2

print(stress(median_two_sorted, median_brute, lambda rng: (sorted(rand_list(rng)), sorted(rand_list(rng))),
             valid=lambda a, b: len(a) + len(b) > 0))
