# file: real.py
import math

def cube_root(x):
    lo, hi = min(-1.0, x), max(1.0, x)
    for _ in range(100):                         # each iteration halves the interval
        mid = (lo + hi) / 2
        if mid ** 3 < x:
            lo = mid
        else:
            hi = mid
    return lo

def max_average_subarray_len_at_least_k(a, k):
    """Largest average of a contiguous subarray of length >= k: binary search the average,
    check 'is there a subarray of length >= k with mean >= m?' via prefix sums of (a[i] - m)."""
    def can(m):
        P, min_prefix = [0.0], 0.0
        for x in a:
            P.append(P[-1] + x - m)
        for i in range(k, len(a) + 1):
            min_prefix = min(min_prefix, P[i - k])
            if P[i] - min_prefix >= 0:
                return True
        return False
    lo, hi = min(a), max(a)
    for _ in range(60):
        mid = (lo + hi) / 2
        if can(mid):
            lo = mid
        else:
            hi = mid
    return lo

for x in (27.0, 2.0, -8.0, 1e-9):
    print(f"cube_root({x}) = {cube_root(x):.12g}   (check: {math.copysign(abs(x) ** (1 / 3), x):.12g})")
a = [1, 12, -5, -6, 50, 3]
brute = max(sum(a[i:j]) / (j - i) for i in range(len(a)) for j in range(i + 4, len(a) + 1))
print(f"max average of length >= 4: {max_average_subarray_len_at_least_k(a, 4):.6f} (brute force {brute:.6f})")
