# file: rotated.py
from check import stress, rand_list

def find_min_rotated(a):                       # distinct values, rotated sorted
    lo, hi = 0, len(a) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] > a[hi]:
            lo = mid + 1                       # the drop is to the right of mid
        else:
            hi = mid                           # mid..hi is sorted: the minimum is at mid or left
    return a[lo]

def search_rotated(a, target):                 # distinct values; index or -1
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if a[mid] == target:
            return mid
        if a[lo] <= a[mid]:                    # left half [lo, mid] is sorted
            if a[lo] <= target < a[mid]:
                hi = mid - 1
            else:
                lo = mid + 1
        else:                                  # right half [mid, hi] is sorted
            if a[mid] < target <= a[hi]:
                lo = mid + 1
            else:
                hi = mid - 1
    return -1

def find_peak(a):                              # a[i] != a[i+1]; returns an index of some peak
    lo, hi = 0, len(a) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] < a[mid + 1]:
            lo = mid + 1                       # uphill to the right: a peak exists there
        else:
            hi = mid
    return lo

def gen_rotated(rng):
    a = sorted(rng.sample(range(-20, 20), rng.randint(1, 9)))
    k = rng.randrange(len(a))
    return a[k:] + a[:k], rng.randint(-21, 21)

def gen_peak(rng):
    a = [rng.randint(0, 3)]
    for _ in range(rng.randint(0, 8)):
        a.append(a[-1] + rng.choice([-2, -1, 1, 2]))       # adjacent elements differ
    return (a,)

def is_peak(i, _b, args):
    a = args[0]
    return (i == 0 or a[i - 1] < a[i]) and (i == len(a) - 1 or a[i + 1] < a[i])

print(stress(find_min_rotated, min, lambda rng: (gen_rotated(rng)[0],)))
print(stress(search_rotated, lambda a, t: a.index(t) if t in a else -1, gen_rotated))
print(stress(find_peak, lambda a: None, gen_peak, same=is_peak))
