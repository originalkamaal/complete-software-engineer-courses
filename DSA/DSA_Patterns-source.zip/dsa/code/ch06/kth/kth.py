# file: kth/kth.py
import random
import time
from check import stress, rand_list
from template import first_true

def count_pairs_within(a, d):                       # a sorted: pairs i<j with a[j]-a[i] <= d
    count, i = 0, 0
    for j in range(len(a)):
        while a[j] - a[i] > d:
            i += 1
        count += j - i                              # a[j] pairs with every element in [i, j)
    return count

def kth_smallest_distance(nums, k):
    a = sorted(nums)
    return first_true(0, a[-1] - a[0] + 1, lambda d: count_pairs_within(a, d) >= k)

def kth_brute(nums, k):
    return sorted(abs(nums[i] - nums[j]) for i in range(len(nums)) for j in range(i + 1, len(nums)))[k - 1]

def gen(rng):
    a = rand_list(rng, 0, 15, 9, 2)
    return a, rng.randint(1, len(a) * (len(a) - 1) // 2)

print(stress(kth_smallest_distance, kth_brute, gen))
rng = random.Random(2)
a = [rng.randint(0, 10**6) for _ in range(100_000)]
for k in (1, 10**6, 2_500_000_000):
    t = time.perf_counter()
    d = kth_smallest_distance(a, k)
    print(f"n=100,000, k={k:>13,}: distance {d:>7,} in {(time.perf_counter() - t) * 1000:.0f} ms")
