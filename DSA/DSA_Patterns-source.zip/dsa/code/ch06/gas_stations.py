# file: gas_stations.py
import math
import heapq
from check import stress

def min_max_gap(stations, k):
    lo, hi = 0.0, max(b - a for a, b in zip(stations, stations[1:]))
    for _ in range(100):                                       # fixed iteration count
        mid = (lo + hi) / 2
        need = sum(math.ceil((b - a) / mid) - 1 for a, b in zip(stations, stations[1:]))
        if need <= k:
            hi = mid                                           # feasible: try smaller
        else:
            lo = mid
    return hi

def greedy(stations, k):
    """Exact for small k: repeatedly split the gap whose current piece is largest."""
    heap = [(-(b - a), b - a, 1) for a, b in zip(stations, stations[1:])]
    heapq.heapify(heap)
    for _ in range(k):
        _, g, parts = heapq.heappop(heap)
        heapq.heappush(heap, (-g / (parts + 1), g, parts + 1))
    return -heap[0][0]

def gen(rng):
    s = sorted(rng.sample(range(0, 30), rng.randint(2, 6)))
    return s, rng.randint(0, 6)

print(round(min_max_gap([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 9), 6), round(min_max_gap([0, 10], 3), 6))
print(stress(min_max_gap, greedy, gen, same=lambda x, y, args: abs(x - y) < 1e-6))
