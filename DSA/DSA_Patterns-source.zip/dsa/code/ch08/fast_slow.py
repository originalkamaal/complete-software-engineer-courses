# file: fast_slow.py
from check import stress, rand_list
from linked import ListNode, from_list, to_list

def middle(head):                                  # second middle for even lengths
    slow = fast = head
    while fast and fast.next:
        slow, fast = slow.next, fast.next.next
    return slow

def kth_from_end(head, k):
    lead = trail = head
    for _ in range(k):
        lead = lead.next
    while lead:
        lead, trail = lead.next, trail.next
    return trail

def cycle_entry(head):
    slow = fast = head
    while fast and fast.next:
        slow, fast = slow.next, fast.next.next
        if slow is fast:                           # met inside the cycle
            p = head
            while p is not slow:
                p, slow = p.next, slow.next
            return p
    return None

def build_with_cycle(values, pos):                 # tail links to node at index pos (or no cycle if pos < 0)
    nodes = [ListNode(v) for v in values]
    for a, b in zip(nodes, nodes[1:]):
        a.next = b
    if pos >= 0:
        nodes[-1].next = nodes[pos]
    return nodes[0], nodes

def cycle_case(values, pos):
    head, nodes = build_with_cycle(values, pos)
    e = cycle_entry(head)
    return None if e is None else nodes.index(e)

if __name__ == "__main__":
    print(stress(lambda a: middle(from_list(a)).val, lambda a: a[len(a) // 2], lambda rng: (rand_list(rng, 0, 9, 9, 1),)))
    print(stress(lambda a, k: kth_from_end(from_list(a), k).val, lambda a, k: a[-k],
                 lambda rng: ((a := rand_list(rng, 0, 9, 9, 1)), rng.randint(1, len(a)))))
    print(stress(cycle_case, lambda v, pos: pos if pos >= 0 else None,
                 lambda rng: ((v := list(range(rng.randint(1, 9)))), rng.randint(-1, len(v) - 1))))
