# file: rotate_list.py
from check import stress, rand_list

class Node:
    __slots__ = ("val", "next")
    def __init__(self, val, nxt=None):
        self.val, self.next = val, nxt

def build(vals):
    head = None
    for v in reversed(vals):
        head = Node(v, head)
    return head

def to_list(h):
    out = []
    while h:
        out.append(h.val)
        h = h.next
    return out

def rotate_right(head, k):
    if not head:
        return None
    n, tail = 1, head
    while tail.next:
        tail, n = tail.next, n + 1
    k %= n
    if k == 0:
        return head
    tail.next = head                           # make a ring
    new_tail = head
    for _ in range(n - k - 1):
        new_tail = new_tail.next
    new_head = new_tail.next
    new_tail.next = None                       # cut the ring
    return new_head

def brute(vals, k):
    if not vals:
        return []
    k %= len(vals)
    return vals[-k:] + vals[:-k] if k else vals

print(to_list(rotate_right(build([1, 2, 3, 4, 5]), 2)), to_list(rotate_right(build([0, 1, 2]), 4)))
print(stress(lambda v, k: to_list(rotate_right(build(v), k)), brute, lambda rng: (rand_list(rng), rng.randint(0, 20))))
