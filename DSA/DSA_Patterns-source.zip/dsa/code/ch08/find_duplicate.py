# file: find_duplicate.py
from check import stress

def find_duplicate(a):                              # n+1 values in [1, n]; exactly one value repeats (possibly many times)
    slow = fast = 0
    while True:
        slow, fast = a[slow], a[a[fast]]
        if slow == fast:
            break
    p = 0
    while p != slow:
        p, slow = a[p], a[slow]
    return p

def gen(rng):
    n = rng.randint(1, 8)
    dup = rng.randint(1, n)
    others = rng.sample([v for v in range(1, n + 1) if v != dup], rng.randint(0, n - 1))
    a = others + [dup] * (n + 1 - len(others))
    rng.shuffle(a)
    return (a,)

print(stress(find_duplicate, lambda a: next(x for x in a if a.count(x) > 1), gen))
