# file: reverse.py
from check import stress, rand_list
from linked import ListNode, from_list, to_list

def reverse(head):
    prev, cur = None, head
    while cur:
        nxt = cur.next                             # save before overwriting
        cur.next = prev
        prev, cur = cur, nxt
    return prev

def reverse_between(head, m, n):                   # 1-based positions m..n inclusive
    dummy = ListNode(0, head)
    before = dummy
    for _ in range(m - 1):
        before = before.next
    first = before.next                            # will become the last of the reversed part
    prev, cur = None, first
    for _ in range(n - m + 1):
        nxt = cur.next
        cur.next = prev
        prev, cur = cur, nxt
    before.next = prev                             # reconnect: front -> new first
    first.next = cur                               # old first -> rest
    return dummy.next

def reverse_k_group(head, k):
    dummy = ListNode(0, head)
    before = dummy
    while True:
        check = before
        for _ in range(k):                          # are there k nodes left?
            check = check.next
            if check is None:
                return dummy.next
        first, prev, cur = before.next, None, before.next
        for _ in range(k):
            nxt = cur.next
            cur.next = prev
            prev, cur = cur, nxt
        before.next, first.next = prev, cur
        before = first

def rev_k_brute(a, k):
    out = []
    for i in range(0, len(a), k):
        chunk = a[i:i + k]
        out += chunk[::-1] if len(chunk) == k else chunk
    return out

if __name__ == "__main__":
    print(stress(lambda a: to_list(reverse(from_list(a))), lambda a: a[::-1], lambda rng: (rand_list(rng),)))
    print(stress(lambda a, m, n: to_list(reverse_between(from_list(a), m, n)), lambda a, m, n: a[:m - 1] + a[m - 1:n][::-1] + a[n:],
                 lambda rng: ((a := rand_list(rng, 0, 9, 9, 1)), (m := rng.randint(1, len(a))), rng.randint(m, len(a)))))
    print(stress(lambda a, k: to_list(reverse_k_group(from_list(a), k)), rev_k_brute, lambda rng: (rand_list(rng, 0, 9, 10), rng.randint(1, 4))))
