# file: combined.py
from check import stress, rand_list
from linked import ListNode, from_list, to_list
from fast_slow import middle
from reverse import reverse

def merge(a, b):
    dummy = tail = ListNode()
    while a and b:
        if a.val <= b.val:
            tail.next, a = a, a.next
        else:
            tail.next, b = b, b.next
        tail = tail.next
    tail.next = a or b
    return dummy.next

def reorder(head):
    if not head or not head.next:
        return head
    slow, fast = head, head.next                    # slow ends at the end of the first half
    while fast and fast.next:
        slow, fast = slow.next, fast.next.next
    second = reverse(slow.next)
    slow.next = None
    first = head
    while second:                                   # interleave
        n1, n2 = first.next, second.next
        first.next, second.next = second, n1
        first, second = n1, n2
    return head

def reorder_brute(a):
    out, i, j = [], 0, len(a) - 1
    while i <= j:
        out.append(a[i])
        if i != j:
            out.append(a[j])
        i, j = i + 1, j - 1
    return out

def is_palindrome(head):
    if not head:
        return True
    slow, fast = head, head.next
    while fast and fast.next:
        slow, fast = slow.next, fast.next.next
    second = reverse(slow.next)
    p, q, ok = head, second, True
    while q:
        if p.val != q.val:
            ok = False
            break
        p, q = p.next, q.next
    slow.next = reverse(second)                     # restore the input: good manners for a predicate
    return ok

print(stress(lambda a, b: to_list(merge(from_list(a), from_list(b))), lambda a, b: sorted(a + b),
             lambda rng: (sorted(rand_list(rng)), sorted(rand_list(rng)))))
print(stress(lambda a: to_list(reorder(from_list(a))), reorder_brute, lambda rng: (rand_list(rng, 0, 9, 9),)))
def pal_and_restored(a):
    h = from_list(a)
    r = is_palindrome(h)
    return r, to_list(h)
print(stress(pal_and_restored, lambda a: (a == a[::-1], a), lambda rng: (rand_list(rng, 0, 1, 7),)))
