# file: basics.py
from check import stress, rand_list
from linked import ListNode, from_list, to_list

def remove_value(head, val):                       # delete every node with this value
    dummy = ListNode(0, head)
    prev = dummy
    while prev.next:
        if prev.next.val == val:
            prev.next = prev.next.next             # unlink; prev stays, its next is new
        else:
            prev = prev.next
    return dummy.next

def remove_duplicates_sorted_all(head):            # sorted list: remove ALL values that appear more than once
    dummy = ListNode(0, head)
    prev = dummy
    while prev.next:
        cur = prev.next
        if cur.next and cur.next.val == cur.val:
            while cur.next and cur.next.val == cur.val:
                cur = cur.next
            prev.next = cur.next                   # skip the whole run
        else:
            prev = cur
    return dummy.next

print(stress(lambda a, v: to_list(remove_value(from_list(a), v)), lambda a, v: [x for x in a if x != v],
             lambda rng: (rand_list(rng, 0, 3), rng.randint(0, 3))))
print(stress(lambda a: to_list(remove_duplicates_sorted_all(from_list(a))), lambda a: [x for x in a if a.count(x) == 1],
             lambda rng: (sorted(rand_list(rng, 0, 4, 10)),)))
