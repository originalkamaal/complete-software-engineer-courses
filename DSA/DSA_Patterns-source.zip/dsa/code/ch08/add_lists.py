# file: add_lists.py
from check import stress

class Node:
    __slots__ = ("val", "next")
    def __init__(self, val, nxt=None):
        self.val, self.next = val, nxt

def from_digits(n):
    dummy = tail = Node(0)
    for ch in reversed(str(n)):
        tail.next = Node(int(ch))
        tail = tail.next
    return dummy.next

def to_int(head):
    digits = []
    while head:
        digits.append(str(head.val))
        head = head.next
    return int("".join(reversed(digits)))

def add(a, b):
    dummy = tail = Node(0)
    carry = 0
    while a or b or carry:
        s = carry + (a.val if a else 0) + (b.val if b else 0)
        carry, digit = divmod(s, 10)
        tail.next = Node(digit)
        tail = tail.next
        a = a.next if a else None
        b = b.next if b else None
    return dummy.next

print(to_int(add(from_digits(342), from_digits(465))), to_int(add(from_digits(9999), from_digits(1))))
print(stress(lambda x, y: to_int(add(from_digits(x), from_digits(y))), lambda x, y: x + y,
             lambda rng: (rng.randint(0, 10 ** rng.randint(1, 12)), rng.randint(0, 10 ** rng.randint(1, 12)))))
