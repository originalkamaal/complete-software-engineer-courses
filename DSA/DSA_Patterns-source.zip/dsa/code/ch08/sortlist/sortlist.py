# file: sortlist/sortlist.py
import random
import time
from check import stress, rand_list
from linked import ListNode, from_list, to_list

def split(head, size):
    """Cut `size` nodes off the front of `head`; return the rest."""
    for _ in range(size - 1):
        if not head:
            return None
        head = head.next
    if not head:
        return None
    rest, head.next = head.next, None
    return rest

def merge_into(tail, a, b):
    """Merge sorted lists a and b after `tail`; return the new tail."""
    while a and b:
        if a.val <= b.val:
            tail.next, a = a, a.next
        else:
            tail.next, b = b, b.next
        tail = tail.next
    tail.next = a or b
    while tail.next:
        tail = tail.next
    return tail

def sort_list(head):
    n, p = 0, head
    while p:
        n, p = n + 1, p.next
    dummy = ListNode(0, head)
    size = 1
    while size < n:
        tail, cur = dummy, dummy.next
        while cur:
            left = cur
            right = split(left, size)
            cur = split(right, size)
            tail = merge_into(tail, left, right)
        size *= 2
    return dummy.next

def stable_check(a):                                  # sort (key, original index) pairs by key, check stability
    head = from_list([(x, i) for i, x in enumerate(a)])
    # compare only keys: wrap values so that <= looks at the key
    class K:
        __slots__ = ("k", "i")
        def __init__(self, p): self.k, self.i = p
        def __le__(self, o): return self.k <= o.k
    p = head
    while p:
        p.val = K(p.val)
        p = p.next
    out = to_list(sort_list(head))
    return [(v.k, v.i) for v in out]

print(stress(lambda a: to_list(sort_list(from_list(a))), sorted, lambda rng: (rand_list(rng, -5, 5, 16),)))
print(stress(stable_check, lambda a: sorted(((x, i) for i, x in enumerate(a)), key=lambda p: p[0]), lambda rng: (rand_list(rng, 0, 2, 12),)))
rng = random.Random(1)
vals = [rng.randint(0, 10**9) for _ in range(300_000)]
t = time.perf_counter()
out = to_list(sort_list(from_list(vals)), limit=10**7)
print(f"n=300,000: sorted in {(time.perf_counter() - t) * 1000:.0f} ms, correct: {out == sorted(vals)}")
