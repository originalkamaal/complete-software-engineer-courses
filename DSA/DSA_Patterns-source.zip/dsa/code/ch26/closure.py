# file: closure.py
from itertools import product
from check import stress
from flow import MaxFlow

def best_selection(weights, requires):              # choose a set closed under "i requires j", maximise sum
    n = len(weights)
    mf = MaxFlow(n + 2)
    s, t, INF = n, n + 1, float("inf")
    for i, w in enumerate(weights):
        if w > 0: mf.add_edge(s, i, w)
        elif w < 0: mf.add_edge(i, t, -w)
    for i, j in requires:
        mf.add_edge(i, j, INF)                       # cannot be cut: choosing i forces j
    cut = mf.max_flow(s, t)
    chosen = sorted(v for v in mf.min_cut_side(s) if v < n)
    return sum(w for w in weights if w > 0) - cut, chosen

def brute(weights, requires):
    best = 0
    for pick in product((0, 1), repeat=len(weights)):
        if all(not pick[i] or pick[j] for i, j in requires):
            best = max(best, sum(w for w, p in zip(weights, pick) if p))
    return best

def check(weights, requires):
    val, chosen = best_selection(weights, requires)
    closed = all(i not in chosen or j in chosen for i, j in requires)
    return val, closed and sum(weights[i] for i in chosen) == val

gen = lambda rng: ((w := [rng.randint(-9, 9) for _ in range(rng.randint(1, 7))]), [(rng.randrange(len(w)), rng.randrange(len(w))) for _ in range(rng.randint(0, 6))])
print(stress(check, lambda w, r: (brute(w, r), True), gen))
print(best_selection([10, -4, -3, 6, -8], [(0, 1), (0, 2), (3, 4)]))
