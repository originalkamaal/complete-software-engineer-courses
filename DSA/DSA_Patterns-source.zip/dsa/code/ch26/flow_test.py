# file: flow_test.py
from itertools import product
from check import stress
from flow import MaxFlow

def run(n, edges):
    mf = MaxFlow(n)
    for u, v, c in edges:
        mf.add_edge(u, v, c)
    f = mf.max_flow(0, n - 1)
    side = mf.min_cut_side(0)
    cut = sum(c for u, v, c in edges if u in side and v not in side)
    return f, cut                                    # max-flow = capacity of the cut found

def brute(n, edges):                                 # minimum over all s-t cuts (2^(n-2) subsets)
    best = float("inf")
    for bits in product((0, 1), repeat=n - 2):
        side = {0} | {i + 1 for i, b in enumerate(bits) if b}
        best = min(best, sum(c for u, v, c in edges if u in side and v not in side))
    return best, best

gen = lambda rng: ((n := rng.randint(2, 7)), [(rng.randrange(n), rng.randrange(n), rng.randint(0, 9)) for _ in range(rng.randint(0, 14))])
print(stress(run, brute, gen))
