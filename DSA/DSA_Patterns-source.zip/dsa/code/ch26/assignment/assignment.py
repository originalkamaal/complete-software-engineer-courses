# file: assignment/assignment.py
import random
import time
from check import stress
from mincost import MinCostFlow

def assign_bitmask(c):
    n = len(c)
    INF = float("inf")
    best = [INF] * (1 << n); best[0] = 0
    for mask in range(1 << n):
        if best[mask] == INF: continue
        i = mask.bit_count()
        if i == n: continue
        for j in range(n):
            if not mask >> j & 1:
                nm = mask | 1 << j
                if best[mask] + c[i][j] < best[nm]:
                    best[nm] = best[mask] + c[i][j]
    return best[-1]

def assign_flow(c):
    n = len(c)
    m = MinCostFlow(2 * n + 2)
    s, t = 2 * n, 2 * n + 1
    for i in range(n):
        m.add_edge(s, i, 1, 0); m.add_edge(n + i, t, 1, 0)
        for j in range(n):
            m.add_edge(i, n + j, 1, c[i][j])
    return m.flow(s, t)[1]

def assign_hungarian(c):
    """O(n^3) Hungarian algorithm with potentials (rows u, columns v); 1-based internally."""
    n = len(c)
    INF = float("inf")
    u, v, p, way = [0] * (n + 1), [0] * (n + 1), [0] * (n + 1), [0] * (n + 1)   # p[j] = row matched to column j
    for i in range(1, n + 1):
        p[0], j0 = i, 0
        minv, used = [INF] * (n + 1), [False] * (n + 1)
        while True:                                  # grow an alternating tree from row i (Dijkstra-like)
            used[j0] = True
            i0, delta, j1 = p[j0], INF, 0
            for j in range(1, n + 1):
                if not used[j]:
                    cur = c[i0 - 1][j - 1] - u[i0] - v[j]     # reduced cost
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n + 1):                   # shift potentials so a new zero edge appears
                if used[j]:
                    u[p[j]] += delta; v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0:                                    # augment along the found path
            j1 = way[j0]; p[j0] = p[j1]; j0 = j1
    return sum(c[p[j] - 1][j - 1] for j in range(1, n + 1))

gen = lambda rng: ([[rng.randint(0, 20) for _ in range(n)] for n in [rng.randint(1, 6)] for _ in range(n)],)
print(stress(assign_hungarian, assign_bitmask, gen))
print(stress(assign_flow, assign_bitmask, gen, trials=500))

rng = random.Random(20)
for n, methods in ((12, ("bitmask DP", "min-cost flow", "Hungarian")), (60, ("min-cost flow", "Hungarian")), (300, ("Hungarian",))):
    c = [[rng.randint(0, 10**6) for _ in range(n)] for _ in range(n)]
    res = []
    for name in methods:
        f = {"bitmask DP": assign_bitmask, "min-cost flow": assign_flow, "Hungarian": assign_hungarian}[name]
        t = time.perf_counter()
        val = f(c)
        res.append(val)
        print(f"n={n:>3} {name:>13}: cost {val:,} in {(time.perf_counter() - t) * 1000:,.0f} ms")
    assert len(set(res)) == 1
