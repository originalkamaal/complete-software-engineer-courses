# file: matching.py
from itertools import combinations
from check import stress
from flow import MaxFlow

def max_matching(L, R, edges):
    mf = MaxFlow(L + R + 2)
    s, t = L + R, L + R + 1
    for u in range(L):
        mf.add_edge(s, u, 1)
    for v in range(R):
        mf.add_edge(L + v, t, 1)
    ids = {(u, v): mf.add_edge(u, L + v, 1) for u, v in set(edges)}
    size = mf.max_flow(s, t)
    pairs = sorted((u, v) for (u, v), e in ids.items() if mf.cap[e] == 0)   # saturated = used
    reach = mf.min_cut_side(s)
    cover = [("L", u) for u in range(L) if u not in reach] + [("R", v) for v in range(R) if L + v in reach]
    return size, pairs, cover

def check(L, R, edges):
    size, pairs, cover = max_matching(L, R, edges)
    is_matching = len({u for u, _ in pairs}) == len(pairs) == len({v for _, v in pairs}) and set(pairs) <= set(edges)
    is_cover = all(("L", u) in cover or ("R", v) in cover for u, v in edges)
    return size, is_matching and len(pairs) == size and is_cover and len(cover) == size

def brute(L, R, edges):
    E = sorted(set(edges))
    for k in range(min(L, R), -1, -1):
        for sub in combinations(E, k):
            if len({u for u, _ in sub}) == k == len({v for _, v in sub}):
                return k, True
    return 0, True

gen = lambda rng: ((L := rng.randint(1, 5)), (R := rng.randint(1, 5)), [(rng.randrange(L), rng.randrange(R)) for _ in range(rng.randint(0, 10))])
print(stress(check, brute, gen))
