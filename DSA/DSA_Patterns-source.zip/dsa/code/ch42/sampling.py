# file: sampling.py
import random
from collections import Counter
from itertools import permutations

def fisher_yates(a, rng):
    a = a[:]
    for i in range(len(a) - 1, 0, -1):
        j = rng.randint(0, i)
        a[i], a[j] = a[j], a[i]
    return a

def naive_shuffle(a, rng):                              # swap with ANY position: biased
    a = a[:]
    for i in range(len(a)):
        j = rng.randint(0, len(a) - 1)
        a[i], a[j] = a[j], a[i]
    return a

def reservoir(stream, k, rng):
    sample = []
    for i, x in enumerate(stream):
        if i < k:
            sample.append(x)
        else:
            j = rng.randint(0, i)
            if j < k:
                sample[j] = x                           # probability k / (i + 1)
    return sample

rng = random.Random(38)
trials = 120_000
for name, f in (("Fisher-Yates", fisher_yates), ("naive swap-any", naive_shuffle)):
    c = Counter(tuple(f([1, 2, 3], rng)) for _ in range(trials))
    freqs = [c[p] / trials for p in permutations([1, 2, 3])]
    print(f"{name:>15}: permutation frequencies {[f'{x:.3f}' for x in freqs]} (uniform = 0.167)")
c = Counter(x for _ in range(20_000) for x in reservoir(range(10), 3, rng))
print("reservoir k=3 of 10: inclusion frequency per item", [round(c[i] / 20_000, 3) for i in range(10)], "(expected 0.3)")
