# file: measure/measure.py
import math
import random
from collections import Counter
from sketches import Bloom, CountMin, HyperLogLog

rng = random.Random(40)
U, N = 50_000, 200_000
weights = [1 / (r + 1) ** 0.9 for r in range(U)]
stream = rng.choices(range(U), weights=weights, k=N)
true = Counter(stream)
distinct = list(true)

n = len(distinct)
bloom = Bloom(10 * n, 7)
for x in distinct:
    bloom.add(x)
assert all(bloom.might_contain(x) for x in distinct)        # no false negatives, ever
probes = range(10**7, 10**7 + 100_000)
fp = sum(bloom.might_contain(x) for x in probes) / 100_000
print(f"Bloom ({n:,} keys, 10 bits/key, k=7): false positives {fp:.4%}, formula {(1 - math.exp(-7 / 10)) ** 7:.4%}")

cm = CountMin(0.001, 0.01)
for x in stream:
    cm.add(x)
over = [cm.count(x) - true[x] for x in distinct]
print(f"Count-Min ({cm.d} x {cm.w} counters): underestimates {sum(o < 0 for o in over)}, "
      f"overestimates > eps*N={0.001 * N:.0f}: {sum(o > 0.001 * N for o in over)} of {n:,} keys (bound: <= 1% expected)")
top = [x for x, _ in true.most_common(5)]
print("  heaviest keys, true vs estimate:", [(true[x], cm.count(x)) for x in top])

hll = HyperLogLog(12)
for x in stream:
    hll.add(x)
est = hll.estimate()
print(f"HyperLogLog (4,096 registers = {4096 * 6 // 8:,} bytes at 6 bits each): estimate {est:,.0f} vs true {n:,} "
      f"-> error {abs(est - n) / n:.2%} (typical: {1.04 / math.sqrt(4096):.2%})")
