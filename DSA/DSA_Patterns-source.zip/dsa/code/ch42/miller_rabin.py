# file: miller_rabin.py
import random
import time
from check import stress

def is_prime(n):
    if n < 2:
        return False
    small = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)
    for p in small:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    for a in small:                                     # deterministic for n < 3.3e24
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False                                # a is a witness: n is composite
    return True

def trial_division(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

print(stress(is_prime, trial_division, lambda rng: (rng.randint(0, 10**6),), trials=20_000))
carmichael = [561, 1105, 1729, 2465, 2821, 6601, 8911]
print("Carmichael numbers (fool the Fermat test):", [is_prime(c) for c in carmichael])
t = time.perf_counter()
p = next(n for n in range(10**18, 10**18 + 1000) if is_prime(n))
print(f"smallest prime >= 10^18: {p}  [{(time.perf_counter() - t) * 1000:.1f} ms]")
print("Mersenne 2^61 - 1 prime:", is_prime(2**61 - 1), "| 2^67 - 1 prime:", is_prime(2**67 - 1))
