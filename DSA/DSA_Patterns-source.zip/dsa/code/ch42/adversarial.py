# file: adversarial.py
import random
import time

def build(keys):
    t = time.perf_counter()
    d = {}
    for k in keys:
        d[k] = 1
    return time.perf_counter() - t

n = 20_000
# CPython: hash(int) is the int itself modulo 2^61 - 1, so multiples of 2^61 - 1 all hash to 0
evil = [i * (2**61 - 1) for i in range(n)]
plain = list(range(n))
print(f"{n:,} ordinary ints:        {build(plain) * 1000:7.1f} ms")
print(f"{n:,} colliding ints:      {build(evil) * 1000:7.1f} ms  (all have hash {hash(evil[1])})")
salt = random.Random(39).getrandbits(64)
print(f"{n:,} (salt, key) tuples: {build([(salt, k) for k in evil]) * 1000:7.1f} ms  (still slow: a tuple's hash combines the components' hashes)")
print(f"{n:,} keys as bytes:      {build([k.to_bytes(16, 'little') for k in evil]) * 1000:7.1f} ms  (bytes use randomised SipHash)")
mult = random.Random(39).getrandbits(64) | 1
print(f"{n:,} random odd multiplier: {build([(k * mult) & (2**64 - 1) for k in evil]) * 1000:7.1f} ms  (keys scrambled by a secret)")
