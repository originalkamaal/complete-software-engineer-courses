# file: envelopes.py
from functools import cache
from check import stress
from lis import lis

def max_envelopes(env):
    env = sorted(env, key=lambda e: (e[0], -e[1]))
    return len(lis([h for _, h in env]))

def brute(env):
    env = sorted(set(env))
    @cache
    def best(i):                                        # longest chain ending with env[i]
        return 1 + max((best(j) for j in range(i) if env[j][0] < env[i][0] and env[j][1] < env[i][1]), default=0)
    return max((best(i) for i in range(len(env))), default=0)

print(stress(max_envelopes, brute, lambda rng: ([(rng.randint(1, 5), rng.randint(1, 5)) for _ in range(rng.randint(0, 9))],)))
print(max_envelopes([(5, 4), (6, 4), (6, 7), (2, 3)]))
