# file: lcs_edit.py
from functools import cache
from check import stress

def lcs(a, b):
    n, m = len(a), len(b)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            dp[i][j] = dp[i - 1][j - 1] + 1 if a[i - 1] == b[j - 1] else max(dp[i - 1][j], dp[i][j - 1])
    out, i, j = [], n, m                               # reconstruct by retracing the choices
    while i and j:
        if a[i - 1] == b[j - 1]:
            out.append(a[i - 1]); i -= 1; j -= 1
        elif dp[i - 1][j] >= dp[i][j - 1]:
            i -= 1
        else:
            j -= 1
    return out[::-1]

def edit_distance(a, b):                              # two rows
    prev = list(range(len(b) + 1))                    # distance from "" to b[:j]
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                cur[j] = prev[j - 1]
            else:
                cur[j] = 1 + min(prev[j],             # delete a[i-1]
                                 cur[j - 1],          # insert b[j-1]
                                 prev[j - 1])         # replace
        prev = cur
    return prev[-1]

def edit_brute(a, b):
    @cache
    def go(i, j):
        if i == len(a): return len(b) - j
        if j == len(b): return len(a) - i
        if a[i] == b[j]: return go(i + 1, j + 1)
        return 1 + min(go(i + 1, j), go(i, j + 1), go(i + 1, j + 1))
    return go(0, 0)

def lcs_brute(a, b):
    @cache
    def go(i, j):
        if i == len(a) or j == len(b): return 0
        return max(go(i + 1, j), go(i, j + 1), go(i + 1, j + 1) + 1 if a[i] == b[j] else 0)
    return go(0, 0)

def lcs_check(a, b):
    s = lcs(a, b)
    sub = lambda s, t: (lambda it: all(c in it for c in s))(iter(t))
    return len(s), sub(s, a) and sub(s, b)

gen = lambda rng: ("".join(rng.choice("abc") for _ in range(rng.randint(0, 8))), "".join(rng.choice("abc") for _ in range(rng.randint(0, 8))))
if __name__ == "__main__":
    print(stress(lcs_check, lambda a, b: (lcs_brute(a, b), True), gen))
    print(stress(edit_distance, edit_brute, gen))
    print("".join(lcs("ABCBDAB", "BDCABA")), edit_distance("intention", "execution"))
