# file: squares.py
from check import stress

def largest_square(g):
    R, C = len(g), len(g[0])
    dp = [[0] * (C + 1) for _ in range(R + 1)]
    best = total = 0
    for r in range(R):
        for c in range(C):
            if g[r][c]:
                dp[r + 1][c + 1] = 1 + min(dp[r][c + 1], dp[r + 1][c], dp[r][c])
                best = max(best, dp[r + 1][c + 1])
                total += dp[r + 1][c + 1]                 # a side-k square ends here => k squares end here
    return best * best, total

def brute(g):
    R, C = len(g), len(g[0])
    best = total = 0
    for r in range(R):
        for c in range(C):
            for k in range(1, min(R - r, C - c) + 1):
                if all(g[i][j] for i in range(r, r + k) for j in range(c, c + k)):
                    best = max(best, k * k); total += 1
    return best, total

def gen(rng):
    R, C = rng.randint(1, 6), rng.randint(1, 6)
    return ([[int(rng.random() < 0.75) for _ in range(C)] for _ in range(R)],)
print(stress(largest_square, brute, gen))
