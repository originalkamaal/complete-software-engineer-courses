# file: lis.py
import bisect
from itertools import combinations
from check import stress, rand_list

def lis_quadratic(a):
    dp = [1] * len(a)
    for i in range(len(a)):
        for j in range(i):
            if a[j] < a[i]:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp, default=0)

def lis(a, strict=True):
    """Return one longest (strictly) increasing subsequence."""
    tails, tails_idx, parent = [], [], [-1] * len(a)
    find = bisect.bisect_left if strict else bisect.bisect_right
    for i, x in enumerate(a):
        k = find(tails, x)                          # first tail >= x (strict) / > x (non-strict)
        if k == len(tails):
            tails.append(x); tails_idx.append(i)
        else:
            tails[k], tails_idx[k] = x, i
        parent[i] = tails_idx[k - 1] if k else -1
    out, i = [], tails_idx[-1] if tails_idx else -1
    while i != -1:
        out.append(a[i]); i = parent[i]
    return out[::-1]

def brute(a, strict=True):
    for k in range(len(a), 0, -1):
        if any(all((x < y) if strict else (x <= y) for x, y in zip(c, c[1:])) for c in combinations(a, k)):
            return k
    return 0

def check(a):
    s = lis(a)
    it = iter(a)
    is_subseq = all(x in it for x in s)                 # consumes the iterator: order is respected
    return len(s), is_subseq and all(x < y for x, y in zip(s, s[1:]))

if __name__ == "__main__":
    print(stress(lis_quadratic, brute, lambda rng: (rand_list(rng, 0, 9, 10),)))
    print(stress(check, lambda a: (brute(a), True), lambda rng: (rand_list(rng, 0, 9, 10),)))
    print(stress(lambda a: len(lis(a, strict=False)), lambda a: brute(a, strict=False), lambda rng: (rand_list(rng, 0, 4, 10),)))
    print(lis([10, 9, 2, 5, 3, 7, 101, 18]))
