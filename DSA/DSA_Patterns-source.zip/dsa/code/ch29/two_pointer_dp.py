# file: two_pointer_dp.py
import fnmatch
import re
from functools import cache
from check import stress

def num_distinct(s, t):
    dp = [1] + [0] * len(t)                              # dp[j]: ways to form t[:j] from the prefix of s so far
    for ch in s:
        for j in range(len(t), 0, -1):                   # right to left: use the previous row's dp[j-1]
            if t[j - 1] == ch:
                dp[j] += dp[j - 1]
    return dp[-1]

def is_interleave(s1, s2, s3):
    if len(s1) + len(s2) != len(s3):
        return False
    dp = [[False] * (len(s2) + 1) for _ in range(len(s1) + 1)]
    dp[0][0] = True
    for i in range(len(s1) + 1):
        for j in range(len(s2) + 1):
            if i and s1[i - 1] == s3[i + j - 1] and dp[i - 1][j]: dp[i][j] = True
            if j and s2[j - 1] == s3[i + j - 1] and dp[i][j - 1]: dp[i][j] = True
    return dp[-1][-1]

def wildcard(s, p):
    dp = [[False] * (len(p) + 1) for _ in range(len(s) + 1)]
    dp[0][0] = True
    for j in range(1, len(p) + 1):
        dp[0][j] = dp[0][j - 1] and p[j - 1] == "*"
    for i in range(1, len(s) + 1):
        for j in range(1, len(p) + 1):
            if p[j - 1] == "*":
                dp[i][j] = dp[i][j - 1] or dp[i - 1][j]   # empty match, or eat one more char
            else:
                dp[i][j] = dp[i - 1][j - 1] and p[j - 1] in (s[i - 1], "?")
    return dp[-1][-1]

def distinct_brute(s, t):
    @cache
    def go(i, j):
        if j == len(t): return 1
        if i == len(s): return 0
        return go(i + 1, j) + (go(i + 1, j + 1) if s[i] == t[j] else 0)
    return go(0, 0)

def interleave_brute(s1, s2, s3):
    @cache
    def go(i, j):
        if i + j == len(s3): return i == len(s1) and j == len(s2)
        return (i < len(s1) and s1[i] == s3[i + j] and go(i + 1, j)) or (j < len(s2) and s2[j] == s3[i + j] and go(i, j + 1))
    return len(s1) + len(s2) == len(s3) and go(0, 0)

w = lambda rng, k: "".join(rng.choice("ab") for _ in range(rng.randint(0, k)))
print(stress(num_distinct, distinct_brute, lambda rng: (w(rng, 9), w(rng, 3))))
print(stress(is_interleave, interleave_brute, lambda rng: (w(rng, 4), w(rng, 4), w(rng, 8))))
print(stress(wildcard, lambda s, p: re.fullmatch(fnmatch.translate(p), s) is not None,
             lambda rng: (w(rng, 6), "".join(rng.choice("ab?*") for _ in range(rng.randint(0, 5))))))
