# file: scs.py
from itertools import product
from check import stress

def shortest_supersequence(a, b):
    n, m = len(a), len(b)
    L = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            L[i][j] = L[i + 1][j + 1] + 1 if a[i] == b[j] else max(L[i + 1][j], L[i][j + 1])
    out, i, j = [], 0, 0
    while i < n and j < m:
        if a[i] == b[j]:
            out.append(a[i]); i += 1; j += 1          # shared character: write once
        elif L[i + 1][j] >= L[i][j + 1]:
            out.append(a[i]); i += 1
        else:
            out.append(b[j]); j += 1
    return "".join(out) + a[i:] + b[j:]

def is_subseq(s, t):
    it = iter(t)
    return all(ch in it for ch in s)

def brute_len(a, b):
    for k in range(max(len(a), len(b)), len(a) + len(b) + 1):
        for cand in product(set(a + b) or "x", repeat=k):
            s = "".join(cand)
            if is_subseq(a, s) and is_subseq(b, s):
                return k

def ok(res, expected_len, args):
    a, b = args
    return is_subseq(a, res) and is_subseq(b, res) and len(res) == expected_len

def gen(rng):
    w = lambda: "".join(rng.choice("ab") for _ in range(rng.randint(0, 4)))
    return w(), w()

print(shortest_supersequence("abac", "cab"))
print(stress(shortest_supersequence, brute_len, gen, trials=500, same=ok))
