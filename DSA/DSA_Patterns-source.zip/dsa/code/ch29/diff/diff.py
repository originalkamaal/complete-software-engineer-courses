# file: diff/diff.py
import difflib
import random
from check import stress

def diff(old, new):
    n, m = len(old), len(new)
    dp = [[0] * (m + 1) for _ in range(n + 1)]          # dp[i][j]: LCS of old[i:], new[j:] (suffixes)
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            dp[i][j] = dp[i + 1][j + 1] + 1 if old[i] == new[j] else max(dp[i + 1][j], dp[i][j + 1])
    out, i, j = [], 0, 0                                 # walk forwards: output in natural order
    while i < n and j < m:
        if old[i] == new[j]:
            out.append("  " + old[i]); i += 1; j += 1
        elif dp[i + 1][j] >= dp[i][j + 1]:
            out.append("- " + old[i]); i += 1
        else:
            out.append("+ " + new[j]); j += 1
    out += ["- " + x for x in old[i:]] + ["+ " + x for x in new[j:]]
    return out

def apply(old, script):
    it, result = iter(old), []
    for line in script:
        tag, text = line[:2], line[2:]
        if tag == "  ":
            assert next(it) == text; result.append(text)
        elif tag == "- ":
            assert next(it) == text
        else:
            result.append(text)
    assert next(it, None) is None
    return result

def changes(script):
    return sum(1 for l in script if l[:2] in ("- ", "+ "))

def check(old, new):
    s = diff(old, new)
    return apply(old, s) == new, changes(s)

def brute_changes(old, new):                           # minimal changes = n + m - 2 * LCS
    from lcs_edit import lcs_brute
    return True, len(old) + len(new) - 2 * lcs_brute(tuple(old), tuple(new))

gen = lambda rng: ([rng.choice("abc") for _ in range(rng.randint(0, 7))], [rng.choice("abc") for _ in range(rng.randint(0, 7))])
print(stress(check, brute_changes, gen))

old = "the quick brown fox jumps over the lazy dog".split()
new = "the quick red fox jumped over the very lazy dog".split()
print("\n".join(diff(old, new)))

rng = random.Random(22)
worse = 0
for _ in range(300):
    a = [rng.choice("abcd") for _ in range(30)]
    b = a[:]
    for _ in range(8):
        k = rng.randrange(3)
        if k == 0 and b: b.pop(rng.randrange(len(b)))
        elif k == 1: b.insert(rng.randrange(len(b) + 1), rng.choice("abcd"))
        elif b: b[rng.randrange(len(b))] = rng.choice("abcd")
    ours = changes(diff(a, b))
    theirs = sum(1 for l in difflib.ndiff(a, b) if l[:2] in ("- ", "+ "))
    worse += theirs > ours
    assert theirs >= ours
print(f"300 random edits of 30-line files: difflib produced a longer diff in {worse} cases, never a shorter one")
