# file: budget.py
import math

def feasible(n, ops_per_sec=1e8, seconds=1.0):
    """The most expensive classic complexity that fits ~1e8 simple operations (compiled-language speed)."""
    budget = ops_per_sec * seconds
    candidates = {
        "O(log n)": math.log2(max(n, 2)), "O(sqrt n)": math.sqrt(n), "O(n)": n, "O(n log n)": n * math.log2(max(n, 2)),
        "O(n sqrt n)": n ** 1.5, "O(n^2)": n ** 2, "O(n^3)": n ** 3, "O(2^(n/2) n)": 2 ** (n / 2) * n if n < 200 else math.inf,
        "O(2^n n)": 2 ** n * n if n < 100 else math.inf, "O(n!)": math.factorial(n) if n < 30 else math.inf,
    }
    ok = [(cost, name) for name, cost in candidates.items() if cost <= budget]
    return max(ok)[1] if ok else "nothing - rethink"

for n in (10, 20, 40, 300, 3000, 2 * 10**5, 10**7, 10**12):
    print(f"n = {n:>16,}: most expensive that fits: {feasible(n)}")
