# file: confirm.py
from functools import cache
from check import stress, rand_list

# Problem: maximise the sum of chosen elements, no two adjacent, array may contain negatives.
def greedy_largest_first(a):                           # candidate 1: take largest available, block neighbours
    taken, blocked, total = set(), set(), 0
    for i in sorted(range(len(a)), key=lambda i: -a[i]):
        if a[i] > 0 and i not in blocked:
            taken.add(i); blocked |= {i - 1, i + 1}; total += a[i]
    return total

def dp(a):                                              # candidate 2: house robber (Unit 28.2)
    take, skip = 0, 0
    for x in a:
        take, skip = skip + x, max(take, skip)
    return max(take, skip)

def brute(a):
    @cache
    def go(i):
        return 0 if i >= len(a) else max(go(i + 1), a[i] + go(i + 2))
    return go(0)

gen = lambda rng: (rand_list(rng, -5, 9, 8),)
try:
    stress(greedy_largest_first, brute, gen)
except AssertionError as e:
    print("greedy refuted:", str(e).split(": ", 1)[1])
print("dp:", stress(dp, brute, gen))
