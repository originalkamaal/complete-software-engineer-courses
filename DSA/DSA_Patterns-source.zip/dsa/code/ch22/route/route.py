# file: route/route.py
import heapq
import random
import time
from check import stress

def search(grid, h_weight):
    """A* with h = h_weight * manhattan * min_cost; h_weight = 0 gives Dijkstra."""
    R, C = len(grid), len(grid[0])
    tr, tc = R - 1, C - 1
    mn = min(x for row in grid for x in row if x)
    h = lambda r, c: h_weight * mn * (abs(r - tr) + abs(c - tc))
    INF = float("inf")
    g = [[INF] * C for _ in range(R)]
    g[0][0] = 0
    heap = [(h(0, 0), 0, 0, 0)]                      # (f, -g, r, c): ties prefer larger g (deeper)
    settled = 0
    while heap:
        f, neg_d, r, c = heapq.heappop(heap)
        d = -neg_d
        if d > g[r][c]:
            continue
        settled += 1
        if (r, c) == (tr, tc):
            return d, settled
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < R and 0 <= nc < C and grid[nr][nc]:
                nd = d + grid[nr][nc]
                if nd < g[nr][nc]:
                    g[nr][nc] = nd
                    heapq.heappush(heap, (nd + h(nr, nc), -nd, nr, nc))
    return -1, settled

def make_grid(rng, R, C, wall=0.2, costs=range(1, 10)):
    g = [[0 if rng.random() < wall else rng.choice(costs) for _ in range(C)] for _ in range(R)]
    g[0][0] = g[R - 1][C - 1] = 1
    return g

gen = lambda rng: (make_grid(rng, rng.randint(1, 6), rng.randint(1, 6)),)
print(stress(lambda g: search(g, 1)[0], lambda g: search(g, 0)[0], gen))

for terrain, costs in (("uniform cost 1", [1]), ("costs 1-9", range(1, 10))):
    grid = make_grid(random.Random(16), 400, 400, costs=costs)
    print(f"400x400, 20% walls, {terrain}:")
    for name, w in (("Dijkstra", 0), ("A* (admissible)", 1), ("A* (h x 3, inadmissible)", 3)):
        t = time.perf_counter()
        cost, settled = search(grid, w)
        print(f"  {name:>25}: cost {cost:,}, settled {settled:>7,} cells, {(time.perf_counter() - t) * 1000:5.0f} ms")
