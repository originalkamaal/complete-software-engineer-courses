# file: zero_one.py
from collections import deque
from check import stress
from dijkstra import dijkstra

def min_cost_grid(grid):                            # cell arrows 1 right, 2 left, 3 down, 4 up; changing costs 1
    R, C = len(grid), len(grid[0])
    dirs = {1: (0, 1), 2: (0, -1), 3: (1, 0), 4: (-1, 0)}
    dist = [[float("inf")] * C for _ in range(R)]
    dist[0][0] = 0
    dq = deque([(0, 0)])
    while dq:
        r, c = dq.popleft()
        d = dist[r][c]
        for k, (dr, dc) in dirs.items():
            nr, nc = r + dr, c + dc
            if 0 <= nr < R and 0 <= nc < C:
                w = 0 if grid[r][c] == k else 1
                if d + w < dist[nr][nc]:
                    dist[nr][nc] = d + w
                    (dq.appendleft if w == 0 else dq.append)((nr, nc))
    return dist[R - 1][C - 1]

def via_dijkstra(grid):
    R, C = len(grid), len(grid[0])
    dirs = {1: (0, 1), 2: (0, -1), 3: (1, 0), 4: (-1, 0)}
    edges = [(r * C + c, (r + dr) * C + (c + dc), 0 if grid[r][c] == k else 1)
             for r in range(R) for c in range(C) for k, (dr, dc) in dirs.items() if 0 <= r + dr < R and 0 <= c + dc < C]
    return dijkstra(R * C, edges, 0)[0][R * C - 1]

def gen_arrows(rng):
    R, C = rng.randint(1, 5), rng.randint(1, 5)
    return ([[rng.randint(1, 4) for _ in range(C)] for _ in range(R)],)
print(stress(min_cost_grid, via_dijkstra, gen_arrows))
print(min_cost_grid([[1, 1, 1, 1], [2, 2, 2, 2], [1, 1, 1, 1], [2, 2, 2, 2]]))
