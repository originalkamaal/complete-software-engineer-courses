# file: obstacles.py
from collections import deque
import heapq
from check import stress

def min_removals(grid):
    R, C = len(grid), len(grid[0])
    dist = [[float("inf")] * C for _ in range(R)]
    dist[0][0] = grid[0][0]
    dq = deque([(0, 0)])
    while dq:
        r, c = dq.popleft()
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < R and 0 <= nc < C:
                w = grid[nr][nc]
                if dist[r][c] + w < dist[nr][nc]:
                    dist[nr][nc] = dist[r][c] + w
                    (dq.appendleft if w == 0 else dq.append)((nr, nc))
    return dist[R - 1][C - 1]

def dijkstra(grid):
    R, C = len(grid), len(grid[0])
    best = {(0, 0): grid[0][0]}
    pq = [(grid[0][0], 0, 0)]
    while pq:
        d, r, c = heapq.heappop(pq)
        if d > best[(r, c)]:
            continue
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < R and 0 <= nc < C and d + grid[nr][nc] < best.get((nr, nc), float("inf")):
                best[(nr, nc)] = d + grid[nr][nc]
                heapq.heappush(pq, (best[(nr, nc)], nr, nc))
    return best[(R - 1, C - 1)]

def gen(rng):
    R, C = rng.randint(1, 6), rng.randint(1, 6)
    return ([[rng.randint(0, 1) for _ in range(C)] for _ in range(R)],)

print(min_removals([[0, 1, 1], [1, 1, 0], [1, 1, 0]]))
print(stress(min_removals, dijkstra, gen))
