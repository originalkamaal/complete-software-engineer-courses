# file: states.py
import heapq
from check import stress
INF = float("inf")

def cheapest_with_coupons(n, edges, s, t, k):        # each coupon halves one edge's cost (floor)
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((v, w)); adj[v].append((u, w))
    dist = {(s, k): 0}
    h = [(0, s, k)]
    while h:
        d, u, left = heapq.heappop(h)
        if d > dist.get((u, left), INF):
            continue
        if u == t:
            return d                                 # first pop of t (any coupons left) is optimal
        for v, w in adj[u]:
            for nl, cost in ((left, w), (left - 1, w // 2)):
                if nl >= 0 and d + cost < dist.get((v, nl), INF):
                    dist[(v, nl)] = d + cost
                    heapq.heappush(h, (d + cost, v, nl))
    return -1

def coupons_brute(n, edges, s, t, k):                 # layered graph + Bellman-Ford style relaxation
    best = {(s, k): 0}
    for _ in range(n * (k + 1) * 2):
        for u, v, w in edges + [(b, a, c) for a, b, c in edges]:
            for left in range(k + 1):
                if (u, left) in best:
                    for nl, cost in ((left, w), (left - 1, w // 2)):
                        if nl >= 0 and best[(u, left)] + cost < best.get((v, nl), INF):
                            best[(v, nl)] = best[(u, left)] + cost
    vals = [best[(t, l)] for l in range(k + 1) if (t, l) in best]
    return min(vals) if vals else -1

gen = lambda rng: ((n := rng.randint(2, 6)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 20)) for _ in range(rng.randint(0, 8))], 0, n - 1, rng.randint(0, 2))
print(stress(cheapest_with_coupons, coupons_brute, gen, trials=800))
