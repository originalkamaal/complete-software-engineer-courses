# file: dijkstra.py
import heapq
from check import stress

INF = float("inf")

def dijkstra(n, edges, s):
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((v, w))
    dist, parent = [INF] * n, [-1] * n
    dist[s] = 0
    h = [(0, s)]
    while h:
        d, u = heapq.heappop(h)
        if d > dist[u]:
            continue                                # stale entry: u was settled with a smaller d
        for v, w in adj[u]:
            nd = d + w
            if nd < dist[v]:
                dist[v], parent[v] = nd, u
                heapq.heappush(h, (nd, v))
    return dist, parent

def path_to(parent, t):
    path = []
    while t != -1:
        path.append(t); t = parent[t]
    return path[::-1]

def bellman_ford_ref(n, edges, s):
    dist = [INF] * n; dist[s] = 0
    for _ in range(n - 1):
        for u, v, w in edges:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
    return dist

def gen(rng):
    n = rng.randint(1, 8)
    return (n, [(rng.randrange(n), rng.randrange(n), rng.randint(0, 9)) for _ in range(rng.randint(0, 15))], rng.randrange(n))

if __name__ == "__main__":
    print(stress(lambda n, e, s: dijkstra(n, e, s)[0], bellman_ford_ref, gen))
    def path_consistent(n, e, s):
        dist, parent = dijkstra(n, e, s)
        w = {}
        for u, v, c in e:
            w[(u, v)] = min(w.get((u, v), INF), c)
        return all(dist[t] == INF or sum(w[(a, b)] for a, b in zip(p, p[1:])) == dist[t]
                   for t in range(n) for p in [path_to(parent, t)])
    print(stress(path_consistent, lambda n, e, s: True, gen))
