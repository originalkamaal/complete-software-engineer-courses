# file: negative.py
import heapq
from dijkstra import dijkstra, bellman_ford_ref

def dijkstra_settled(n, edges, s):                  # textbook form: a settled vertex is never processed again
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((v, w))
    dist, done, h = [float("inf")] * n, [False] * n, [(0, s)]
    dist[s] = 0
    while h:
        d, u = heapq.heappop(h)
        if done[u]:
            continue
        done[u] = True
        for v, w in adj[u]:
            if not done[v] and d + w < dist[v]:
                dist[v] = d + w
                heapq.heappush(h, (dist[v], v))
    return dist

edges = [(0, 1, 1), (0, 2, 2), (2, 1, -2), (1, 3, 1)]
print("settled-set Dijkstra:", dijkstra_settled(4, edges, 0))
print("lazy Dijkstra:       ", dijkstra(4, edges, 0)[0])
print("Bellman-Ford:        ", bellman_ford_ref(4, edges, 0))
