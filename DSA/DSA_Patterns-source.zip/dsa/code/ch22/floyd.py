# file: floyd.py
from check import stress
from dijkstra import dijkstra
INF = float("inf")

def floyd_warshall(n, edges):
    d = [[0 if i == j else INF for j in range(n)] for i in range(n)]
    for u, v, w in edges:
        d[u][v] = min(d[u][v], w)
    for k in range(n):                               # k must be the OUTER loop
        dk = d[k]
        for i in range(n):
            dik = d[i][k]
            if dik == INF:
                continue
            di = d[i]
            for j in range(n):
                if dik + dk[j] < di[j]:
                    di[j] = dik + dk[j]
    return d

def wrong_order(n, edges):                           # k as the inner loop: a common bug
    d = [[0 if i == j else INF for j in range(n)] for i in range(n)]
    for u, v, w in edges:
        d[u][v] = min(d[u][v], w)
    for i in range(n):
        for j in range(n):
            for k in range(n):
                d[i][j] = min(d[i][j], d[i][k] + d[k][j])
    return d

gen = lambda rng: ((n := rng.randint(1, 7)), [(rng.randrange(n), rng.randrange(n), rng.randint(0, 9)) for _ in range(rng.randint(0, 14))])
all_pairs_dijkstra = lambda n, e: [dijkstra(n, e, s)[0] for s in range(n)]
print(stress(floyd_warshall, all_pairs_dijkstra, gen))
try:
    stress(wrong_order, all_pairs_dijkstra, gen)
except AssertionError as e:
    print("k innermost fails, e.g.", str(e).split("->")[0].replace("wrong_order: counterexample ", ""))
