# file: bellman.py
from check import stress
INF = float("inf")

def bellman_ford(n, edges, s):
    dist = [INF] * n
    dist[s] = 0
    for _ in range(n - 1):
        changed = False
        for u, v, w in edges:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w; changed = True
        if not changed:
            break                                    # early exit: already converged
    has_neg_cycle = any(dist[u] + w < dist[v] for u, v, w in edges if dist[u] < INF)
    return dist, has_neg_cycle

def cheapest_within_k(n, flights, src, dst, k):     # at most k intermediate stops = k + 1 edges
    dist = [INF] * n
    dist[src] = 0
    for _ in range(k + 1):
        prev = dist[:]                               # relax only from last round's values
        for u, v, w in flights:
            if prev[u] + w < dist[v]:
                dist[v] = prev[u] + w
    return -1 if dist[dst] == INF else dist[dst]

def cheapest_brute(n, flights, src, dst, k):
    best = INF
    def go(u, cost, edges_used):
        nonlocal best
        if u == dst: best = min(best, cost)
        if edges_used == k + 1: return
        for a, b, w in flights:
            if a == u: go(b, cost + w, edges_used + 1)
    go(src, 0, 0)
    return -1 if best == INF else best

def neg_cycle_brute(n, edges, s):                   # does some reachable cycle have negative total?
    reach, frontier = {s}, [s]
    while frontier:
        u = frontier.pop()
        for a, b, _ in edges:
            if a == u and b not in reach: reach.add(b); frontier.append(b)
    found = False
    def go(start, u, cost, used):                    # simple cycles from start
        nonlocal found
        for a, b, w in edges:
            if a == u:
                if b == start and cost + w < 0: found = True
                elif b not in used and b > start: go(start, b, cost + w, used | {b})
    for v in reach:
        go(v, v, 0, {v})
    return found

gen = lambda rng: ((n := rng.randint(1, 6)), [(rng.randrange(n), rng.randrange(n), rng.randint(-3, 9)) for _ in range(rng.randint(0, 9))], 0)
print(stress(lambda n, e, s: bellman_ford(n, e, s)[1], neg_cycle_brute, gen))
print(stress(cheapest_within_k, cheapest_brute,
             lambda rng: ((n := rng.randint(2, 6)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 9)) for _ in range(rng.randint(0, 9))], 0, n - 1, rng.randint(0, 3)), trials=1000))
