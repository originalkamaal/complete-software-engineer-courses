# file: xor_subarrays.py
from collections import Counter
from functools import reduce
from operator import xor
from check import stress, rand_list

def count_xor_k(a, k):
    seen, x, total = Counter({0: 1}), 0, 0
    for v in a:
        x ^= v
        total += seen[x ^ k]                    # earlier prefix p with p ^ x == k
        seen[x] += 1
    return total

def brute(a, k):
    return sum(reduce(xor, a[i:j], 0) == k for i in range(len(a)) for j in range(i + 1, len(a) + 1))

print(count_xor_k([4, 2, 2, 6, 4], 6), count_xor_k([5, 6, 7, 8, 9], 5))
print(stress(count_xor_k, brute, lambda rng: (rand_list(rng, 0, 7, max_len=10), rng.randint(0, 7))))
