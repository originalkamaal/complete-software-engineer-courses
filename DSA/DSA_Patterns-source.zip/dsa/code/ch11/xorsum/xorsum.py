# file: xorsum/xorsum.py
import random
import time
from itertools import permutations
from check import stress, rand_list

def min_xor_sum(a, b):
    n = len(a)
    INF = float("inf")
    best = [INF] * (1 << n)
    best[0] = 0
    for mask in range(1 << n):
        if best[mask] == INF:
            continue
        i = mask.bit_count()                       # next element of a to match
        if i == n:
            continue
        for j in range(n):
            if not mask >> j & 1:
                nm = mask | 1 << j
                cost = best[mask] + (a[i] ^ b[j])
                if cost < best[nm]:
                    best[nm] = cost
    return best[(1 << n) - 1]

def brute(a, b):
    return min(sum(x ^ y for x, y in zip(a, p)) for p in permutations(b))

def gen(rng):
    n = rng.randint(1, 6)
    return ([rng.randint(0, 31) for _ in range(n)], [rng.randint(0, 31) for _ in range(n)])

print(stress(min_xor_sum, brute, gen, trials=500))
rng = random.Random(6)
a = [rng.randint(0, 10**7) for _ in range(14)]
b = [rng.randint(0, 10**7) for _ in range(14)]
t = time.perf_counter()
r = min_xor_sum(a, b)
print(f"n=14: minimum XOR sum {r} in {(time.perf_counter() - t) * 1000:.0f} ms (vs 14! = {__import__('math').factorial(14):,} permutations)")
