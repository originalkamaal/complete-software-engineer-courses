# file: xor.py
from collections import Counter
from functools import reduce
from operator import xor
from check import stress

def single(a):
    return reduce(xor, a, 0)

def two_singles(a):
    ab = reduce(xor, a, 0)
    bit = ab & -ab                               # a bit where the two singles differ
    x = reduce(xor, (v for v in a if v & bit), 0)
    return sorted((x, ab ^ x))

def single_among_triples(a):                     # 32-bit signed inputs
    result = 0
    for i in range(32):
        if sum(v >> i & 1 for v in a) % 3:
            result |= 1 << i
    return result - (1 << 32) if result >> 31 else result   # sign-correct (DT-19)

def missing_number(a):                           # 0..n with one missing
    return reduce(xor, a, 0) ^ reduce(xor, range(len(a) + 1), 0)

def gen_pairs(rng, singles, times):
    vals = rng.sample(range(-1000, 1000), rng.randint(0, 5) + singles)
    a = [v for v in vals[singles:] for _ in range(times)] + vals[:singles]
    rng.shuffle(a)
    return (a,)

def odd_out(a):
    return sorted(v for v, c in Counter(a).items() if c % 2 == 1 or c == 1)

print(stress(single, lambda a: odd_out(a)[0], lambda rng: gen_pairs(rng, 1, 2)))
print(stress(two_singles, odd_out, lambda rng: gen_pairs(rng, 2, 2)))
print(stress(single_among_triples, lambda a: [v for v, c in Counter(a).items() if c == 1][0], lambda rng: gen_pairs(rng, 1, 3)))
print(stress(missing_number, lambda a: (set(range(len(a) + 1)) - set(a)).pop(),
             lambda rng: ((lambda n, m: [v for v in range(n + 1) if v != m])(*(lambda n: (n, rng.randint(0, n)))(rng.randint(0, 10))),)))
