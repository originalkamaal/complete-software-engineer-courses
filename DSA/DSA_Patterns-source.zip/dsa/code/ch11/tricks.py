# file: tricks.py
from check import stress

def popcount_kernighan(x):                     # one iteration per set bit
    c = 0
    while x:
        x &= x - 1
        c += 1
    return c

def counting_bits(n):                          # popcount of 0..n in O(n): drop the lowest bit
    out = [0] * (n + 1)
    for i in range(1, n + 1):
        out[i] = out[i & (i - 1)] + 1
    return out

def reverse_bits32(x):
    r = 0
    for _ in range(32):
        r = (r << 1) | (x & 1)
        x >>= 1
    return r

x = 0b101100
print(bin(x & -x), bin(x & (x - 1)), x.bit_length(), x.bit_count())
print(stress(popcount_kernighan, lambda x: bin(x).count("1"), lambda rng: (rng.randint(0, 2**40),)))
print(stress(counting_bits, lambda n: [bin(i).count("1") for i in range(n + 1)], lambda rng: (rng.randint(0, 50),)))
print(stress(reverse_bits32, lambda x: int(f"{x:032b}"[::-1], 2), lambda rng: (rng.randint(0, 2**32 - 1),)))
print("is power of two:", [n for n in range(1, 70) if n & (n - 1) == 0])
