# file: masks.py
from check import stress

def submasks(mask):
    out, sub = [], mask
    while True:
        out.append(sub)
        if sub == 0:
            break
        sub = (sub - 1) & mask                   # next smaller submask
    return out

def subsets_of(a):                               # bitmask enumeration instead of recursion
    n = len(a)
    return [[a[i] for i in range(n) if m >> i & 1] for m in range(1 << n)]

def gosper_next(x):                              # next larger integer with the same popcount
    c = x & -x
    r = x + c
    return (((r ^ x) >> 2) // c) | r

print(stress(lambda m: sorted(submasks(m)), lambda m: [s for s in range(m + 1) if s & m == s], lambda rng: (rng.randint(0, 255),)))
for n in range(1, 11):
    pairs = sum(len(submasks(m)) for m in range(1 << n))
    assert pairs == 3 ** n
print("sum over masks of #submasks == 3^n for n = 1..10")
print(len(subsets_of(list("abcd"))), subsets_of(list("abc")))
x, out = 0b0111, []
while x < 1 << 6:
    out.append(f"{x:06b}")
    x = gosper_next(x)
print(len(out), "6-bit masks with 3 ones, e.g.", out[:4])
