# file: word_masks.py
from check import stress

def max_product(words):
    masks = {}
    for w in words:
        m = 0
        for ch in w:
            m |= 1 << (ord(ch) - 97)
        masks[m] = max(masks.get(m, 0), len(w))          # keep the longest word per letter set
    items = list(masks.items())
    best = 0
    for i, (m1, l1) in enumerate(items):
        for m2, l2 in items[i + 1:]:
            if m1 & m2 == 0:
                best = max(best, l1 * l2)
    return best

def brute(words):
    return max((len(a) * len(b) for i, a in enumerate(words) for b in words[i + 1:] if not set(a) & set(b)), default=0)

def gen(rng):
    return (["".join(rng.choice("abcdef") for _ in range(rng.randint(1, 4))) for _ in range(rng.randint(0, 7))],)

print(max_product(["abcw", "baz", "foo", "bar", "xtfn", "abcdef"]), max_product(["a", "aa", "aaa"]))
print(stress(max_product, brute, gen))
