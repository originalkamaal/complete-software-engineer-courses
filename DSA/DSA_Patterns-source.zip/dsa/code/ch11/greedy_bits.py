# file: greedy_bits.py
from check import stress, rand_list

def max_xor_pair(a):
    best = 0
    for k in range(max(a).bit_length() - 1, -1, -1):
        want = best | 1 << k
        prefixes = {v >> k for v in a}
        # is there p, q in prefixes with p ^ q == want >> k ?  (p ^ q = t  <=>  q = p ^ t)
        if any((p ^ (want >> k)) in prefixes for p in prefixes):
            best = want
    return best

MASK = 0xFFFFFFFF
def add32(a, b):
    a, b = a & MASK, b & MASK
    while b:
        a, b = (a ^ b) & MASK, ((a & b) << 1) & MASK
    return a - (1 << 32) if a >> 31 else a

print(stress(max_xor_pair, lambda a: max(x ^ y for x in a for y in a), lambda rng: (rand_list(rng, 0, 1000, 12, 1),)))
print(stress(add32, lambda a, b: (a + b + 2**31) % 2**32 - 2**31, lambda rng: (rng.randint(-2**31, 2**31 - 1), rng.randint(-2**31, 2**31 - 1))))
print(add32(2**31 - 1, 1), add32(-7, 3))
