# file: deep.py
import sys
import threading

def depth(n):
    return 0 if n == 0 else 1 + depth(n - 1)

try:
    depth(5_000)
except RecursionError as e:
    print("default limit:", sys.getrecursionlimit(), "->", type(e).__name__)

def iterative_depth(n):            # the same computation with an explicit loop/stack: no limit
    d = 0
    while n:
        n -= 1
        d += 1
    return d

print("iterative:", iterative_depth(1_000_000))

def run_deep():
    sys.setrecursionlimit(1_100_000)
    print("recursive with a raised limit and a 512 MB thread stack:", depth(1_000_000))

threading.stack_size(512 * 1024 * 1024)
t = threading.Thread(target=run_deep)
t.start()
t.join()
