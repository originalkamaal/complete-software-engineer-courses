# file: budget.py
import time

def ops(n):
    s = 0
    for i in range(n):
        s += i & 7
    return s

for n in (10**6, 10**7):
    t = time.perf_counter()
    ops(n)
    dt = time.perf_counter() - t
    print(f"{n:>10,} loop iterations: {dt*1000:7.1f} ms  ->  about {n/dt/1e6:.0f} million simple iterations per second")

t = time.perf_counter()
s = sum(i & 7 for i in range(10**7))
print(f"same work as a generator inside sum(): {(time.perf_counter()-t)*1000:.0f} ms")
t = time.perf_counter()
xs = sorted(range(10**6, 0, -1))
print(f"sorted() of 10^6 ints: {(time.perf_counter()-t)*1000:.0f} ms (C code: the per-element cost is much lower)")
