# file: harness/demo.py
import random
from harness import check_examples, stress, timeit

# --- Two Sum: indices i < j with a[i] + a[j] == target, or None ---
def two_sum_brute(a, target):
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i] + a[j] == target:
                return (i, j)
    return None

def two_sum(a, target):
    seen = {}                                    # value -> index where it was seen
    for j, x in enumerate(a):
        if target - x in seen:
            return (seen[target - x], j)
        seen[x] = j
    return None

def two_sum_valid(fast_result, brute_result, args):
    a, target = args                             # many index pairs may be valid: check the property
    if brute_result is None:
        return fast_result is None
    if fast_result is None:
        return False
    i, j = fast_result
    return i < j and a[i] + a[j] == target

# --- Count inversions: pairs i < j with a[i] > a[j] ---
def inversions_brute(a):
    return sum(1 for i in range(len(a)) for j in range(i + 1, len(a)) if a[i] > a[j])

def inversions_wrong(a):                         # a plausible-looking but wrong idea: compare neighbours only
    return sum(1 for i in range(len(a) - 1) if a[i] > a[i + 1])

def inversions(a):
    """Merge sort, counting: when an element of the right half is placed, every remaining left element exceeds it."""
    def sort(lo, hi):
        if hi - lo <= 1:
            return a[lo:hi], 0
        mid = (lo + hi) // 2
        left, x = sort(lo, mid)
        right, y = sort(mid, hi)
        merged, count, i = [], x + y, 0
        for r in right:
            while i < len(left) and left[i] <= r:  # <= : equal elements are not inversions
                merged.append(left[i])
                i += 1
            count += len(left) - i
            merged.append(r)
        merged.extend(left[i:])
        return merged, count
    return sort(0, len(a))[1]

gen_two_sum = lambda rng: ([rng.randint(-5, 5) for _ in range(rng.randint(0, 7))], rng.randint(-6, 6))
gen_array = lambda rng: ([rng.randint(0, 4) for _ in range(rng.randint(0, 8))],)

print("two_sum examples:", check_examples(two_sum, [(([2, 7, 11, 15], 9), (0, 1)), (([3, 3], 6), (0, 1)), (([1, 2], 7), None)]))
print("two_sum stress:", stress(two_sum, two_sum_brute, gen_two_sum, same=two_sum_valid), "trials passed")
try:
    stress(inversions_wrong, inversions_brute, gen_array)
except AssertionError as e:
    print("inversions_wrong:", e)
print("inversions stress:", stress(inversions, inversions_brute, gen_array), "trials passed")

big = [random.Random(5).randint(0, 10**9) for _ in range(200_000)]
print(f"inversions on n=200,000: {timeit(inversions, big):.0f} ms (brute force would need ~2*10^10 comparisons)")
print(f"two_sum on n=200,000 with no solution: {timeit(two_sum, big, -1):.0f} ms")
