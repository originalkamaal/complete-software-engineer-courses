# file: harness/harness.py
"""A tiny test harness: examples, random stress tests with shrinking, and timing."""
import random
import time

def check_examples(f, cases):
    for args, expected in cases:
        got = f(*args)
        if got != expected:
            raise AssertionError(f"{f.__name__}{args}: expected {expected!r}, got {got!r}")
    return len(cases)

def shrink(args, fails):
    """Greedily remove list elements while the failure persists, to get a minimal counterexample."""
    args = list(args)
    changed = True
    while changed:
        changed = False
        for k, a in enumerate(args):
            if isinstance(a, list):
                for i in range(len(a)):
                    trial = args[:k] + [a[:i] + a[i + 1:]] + args[k + 1:]
                    if trial[k] and fails(trial):
                        args, changed = trial, True
                        break
            if changed:
                break
    return args

def stress(fast, brute, gen, trials=3000, seed=0, same=None):
    """`gen(rng)` returns an argument tuple. `same(a, b, args)` compares results (default: ==)."""
    rng = random.Random(seed)
    same = same or (lambda a, b, args: a == b)
    def fails(args):
        try:
            return not same(fast(*args), brute(*args), args)
        except Exception:
            return True
    for t in range(trials):
        args = list(gen(rng))
        if fails(args):
            small = shrink(args, fails)
            raise AssertionError(f"counterexample (trial {t}, shrunk from {args}): {small} -> fast {fast(*small)!r}, brute {brute(*small)!r}")
    return trials

def timeit(f, *args, repeat=1):
    best = float("inf")
    for _ in range(repeat):
        t = time.perf_counter()
        f(*args)
        best = min(best, time.perf_counter() - t)
    return best * 1000
