# file: stress.py
import random

def max_subarray_brute(a):
    best = a[0]
    for i in range(len(a)):
        s = 0
        for j in range(i, len(a)):
            s += a[j]
            best = max(best, s)
    return best

def max_subarray_buggy(a):
    best = cur = 0                      # BUG: assumes the answer is at least 0
    for x in a:
        cur = max(x, cur + x)
        best = max(best, cur)
    return best

def max_subarray(a):
    best = cur = a[0]                   # start from a real element
    for x in a[1:]:
        cur = max(x, cur + x)           # extend, or start fresh at x
        best = max(best, cur)
    return best

def stress(fast, brute, trials=2000, seed=1):
    rng = random.Random(seed)
    for t in range(trials):
        n = rng.randint(1, 8)                       # small inputs: easy to read when they fail
        a = [rng.randint(-10, 10) for _ in range(n)]
        if fast(a) != brute(a):
            return f"MISMATCH on {a}: fast={fast(a)} brute={brute(a)} (trial {t})"
    return f"{trials} random tests passed"

print("buggy:", stress(max_subarray_buggy, max_subarray_brute))
print("fixed:", stress(max_subarray, max_subarray_brute))
