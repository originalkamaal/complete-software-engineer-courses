# file: traps.py
import time
from collections import deque

def timed(label, f):
    t = time.perf_counter()
    f()
    print(f"{label:<44} {(time.perf_counter() - t) * 1000:8.1f} ms")

n = 100_000
def queue_list():
    q = list(range(n))
    while q:
        q.pop(0)                  # O(n) each: shifts every element
def queue_deque():
    q = deque(range(n))
    while q:
        q.popleft()               # O(1)
def membership_list():
    seen = list(range(0, 2 * n, 2))
    sum(1 for x in range(20_000) if x in seen)
def membership_set():
    seen = set(range(0, 2 * n, 2))
    sum(1 for x in range(20_000) if x in seen)
def concat_strings():
    s = ""
    for i in range(n):
        s = s + str(i % 10) + ","     # CPython may optimise this in place, but do not rely on it
def join_strings():
    ",".join(str(i % 10) for i in range(n))

timed("queue as list, pop(0) x 100k", queue_list)
timed("queue as deque, popleft() x 100k", queue_deque)
timed("20k membership tests in a 100k list", membership_list)
timed("20k membership tests in a 100k set", membership_set)
timed("build a string by + in a loop", concat_strings)
timed("build a string with join", join_strings)
