# file: manacher.py
from check import stress

def manacher(s):
    t = "#" + "#".join(s) + "#"
    n = len(t)
    p = [0] * n
    c = r = 0                                         # centre and right edge of the rightmost palindrome
    for i in range(n):
        if i < r:
            p[i] = min(r - i, p[2 * c - i])
        while i - p[i] - 1 >= 0 and i + p[i] + 1 < n and t[i - p[i] - 1] == t[i + p[i] + 1]:
            p[i] += 1
        if i + p[i] > r:
            c, r = i, i + p[i]
    return p

def longest_palindrome(s):
    if not s:
        return ""
    p = manacher(s)
    i = max(range(len(p)), key=p.__getitem__)
    start = (i - p[i]) // 2
    return s[start:start + p[i]]

def count_palindromes(s):
    # a radius r at position i of t covers palindromes of original lengths r, r-2, ...: (r + 1) // 2 of them
    return sum((r + 1) // 2 for r in manacher(s))

def brute_longest(s):
    return max((s[i:j] for i in range(len(s)) for j in range(i + 1, len(s) + 1) if s[i:j] == s[i:j][::-1]), key=len, default="")

def brute_count(s):
    return sum(s[i:j] == s[i:j][::-1] for i in range(len(s)) for j in range(i + 1, len(s) + 1))

w = lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(0, 12))),)
print(stress(lambda s: len(longest_palindrome(s)), lambda s: len(brute_longest(s)), w))
print(stress(count_palindromes, brute_count, w))
print(longest_palindrome("forgeeksskeegfor"), count_palindromes("aaa"))
