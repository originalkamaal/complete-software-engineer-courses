# file: sa_test.py
from check import stress
from suffix_array import suffix_array, lcp_array

def distinct_substrings(s):
    sa = suffix_array(s)
    return len(s) * (len(s) + 1) // 2 - sum(lcp_array(s, sa))

def longest_repeated(s):
    sa = suffix_array(s)
    lcp = lcp_array(s, sa)
    if not lcp or max(lcp) == 0:
        return ""
    i = max(range(len(lcp)), key=lcp.__getitem__)
    return s[sa[i]:sa[i] + lcp[i]]

w = lambda rng: ("".join(rng.choice("abc") for _ in range(rng.randint(0, 14))),)
print(stress(suffix_array, lambda s: sorted(range(len(s)), key=lambda i: s[i:]), w))
print(stress(distinct_substrings, lambda s: len({s[i:j] for i in range(len(s)) for j in range(i + 1, len(s) + 1)}), w))
print(stress(lambda s: len(longest_repeated(s)), lambda s: max((j - i for i in range(len(s)) for j in range(i + 1, len(s) + 1)
                                                               if s.find(s[i:j], i + 1) != -1), default=0), w))
print(suffix_array("banana"), lcp_array("banana", suffix_array("banana")), longest_repeated("banana"))
