# file: repeated/repeated.py
import random
import time
from sam import SuffixAutomaton
from suffix_array import suffix_array, lcp_array

def lrs_hash(s):
    MOD, B = (1 << 61) - 1, 911382323
    n = len(s)
    pw, h = [1] * (n + 1), [0] * (n + 1)
    for i, ch in enumerate(s):
        h[i + 1] = (h[i] * B + ord(ch)) % MOD
        pw[i + 1] = pw[i] * B % MOD
    def repeat_of(L):
        seen = {}
        for i in range(n - L + 1):
            x = (h[i + L] - h[i] * pw[L]) % MOD
            if x in seen and s[seen[x]:seen[x] + L] == s[i:i + L]:   # verify: no false positives
                return i
            seen.setdefault(x, i)
        return -1
    lo, hi, best = 1, n - 1, ""
    while lo <= hi:
        mid = (lo + hi) // 2
        i = repeat_of(mid)
        if i >= 0:
            best, lo = s[i:i + mid], mid + 1
        else:
            hi = mid - 1
    return best

def lrs_sa(s):
    sa = suffix_array(s)
    lcp = lcp_array(s, sa)
    i = max(range(len(lcp)), key=lcp.__getitem__)
    return s[sa[i]:sa[i] + lcp[i]]

def lrs_sam(s):
    sam = SuffixAutomaton()
    first_end = [0]                                     # some end position of each state's strings
    for i, ch in enumerate(s):
        sam.extend(ch)
        while len(first_end) < len(sam.len):
            first_end.append(i)                         # strings of a new state (or clone) end at position i
    n_states = len(sam.len)
    cnt = [0] * n_states
    v = 0
    for ch in s:                                        # each prefix's state gets one end position
        v = sam.next[v][ch]
        cnt[v] += 1
    for u in sorted(range(1, n_states), key=lambda u: -sam.len[u]):
        if sam.link[u] > 0:
            cnt[sam.link[u]] += cnt[u]                  # a suffix occurs wherever its extensions occur
    best = max((u for u in range(1, n_states) if cnt[u] >= 2), key=lambda u: sam.len[u], default=None)
    if best is None:
        return ""
    end = first_end[best]
    return s[end - sam.len[best] + 1:end + 1]

rng = random.Random(32)
base = "".join(rng.choice("abcd") for _ in range(200_000))
s = base[:150_000] + base[10_000:10_150] + base[150_150:]          # plant a 150-character repeat
results = {}
for name, f in (("hash + binary search", lrs_hash), ("suffix array + LCP", lrs_sa), ("suffix automaton", lrs_sam)):
    t = time.perf_counter()
    r = f(s)
    results[name] = r
    print(f"{name:>21}: length {len(r)} in {time.perf_counter() - t:.1f} s")
print("all three agree on the length:", len({len(r) for r in results.values()}) == 1,
      "| each result occurs twice:", all(s.find(r) != s.rfind(r) for r in results.values()))
