# file: zfunc.py
from check import stress

def z_function(s):
    n = len(s)
    z = [0] * n
    if n:
        z[0] = n
    l = r = 0
    for i in range(1, n):
        if i < r:
            z[i] = min(r - i, z[i - l])               # reuse the mirrored value inside the Z-box
        while i + z[i] < n and s[z[i]] == s[i + z[i]]:
            z[i] += 1
        if i + z[i] > r:
            l, r = i, i + z[i]
    return z

def z_brute(s):
    out = []
    for i in range(len(s)):
        k = 0
        while i + k < len(s) and s[k] == s[i + k]:
            k += 1
        out.append(k)
    return out

print(stress(z_function, z_brute, lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(0, 15))),)))
print(z_function("aaabaab"))
