# file: kmp.py
from check import stress

def prefix_function(s):
    pi = [0] * len(s)
    for i in range(1, len(s)):
        k = pi[i - 1]
        while k and s[i] != s[k]:
            k = pi[k - 1]                             # fall back to the next shorter border
        if s[i] == s[k]:
            k += 1
        pi[i] = k
    return pi

def find_all(text, pat):                              # start indices of pat in text
    if not pat:
        return list(range(len(text) + 1))
    pi = prefix_function(pat + "\0" + text)           # "\0" never occurs in either string
    m = len(pat)
    return [i - 2 * m for i in range(len(pi)) if pi[i] == m]

def smallest_period(s):
    p = len(s) - prefix_function(s)[-1]
    return p if len(s) % p == 0 else len(s)           # a full repetition, or the string itself

w = lambda rng, k: "".join(rng.choice("ab") for _ in range(rng.randint(0, k)))
print(stress(find_all, lambda t, p: [i for i in range(len(t) - len(p) + 1) if t.startswith(p, i)], lambda rng: (w(rng, 15), w(rng, 3) or "a")))
print(stress(smallest_period, lambda s: next(p for p in range(1, len(s) + 1) if len(s) % p == 0 and s[:p] * (len(s) // p) == s),
             lambda rng: ((w(rng, 3) or "a") * rng.randint(1, 4),)))
print(prefix_function("aabaaab"), find_all("abababab", "abab"), smallest_period("abcabcabc"))
