# file: sam_test.py
from check import stress
from sam import SuffixAutomaton

def lcs_brute(s, t):
    return max((j - i for i in range(len(t)) for j in range(i + 1, len(t) + 1) if t[i:j] in s), default=0)

w = lambda rng, k=12: "".join(rng.choice("abc") for _ in range(rng.randint(0, k)))
print(stress(lambda s: SuffixAutomaton(s).distinct_substrings(), lambda s: len({s[i:j] for i in range(len(s)) for j in range(i + 1, len(s) + 1)}),
             lambda rng: (w(rng),)))
print(stress(lambda s, t: len(SuffixAutomaton(s).longest_common_substring(t)), lcs_brute, lambda rng: (w(rng), w(rng))))
sam = SuffixAutomaton("abcbc")
print("states:", len(sam.len), "distinct substrings:", sam.distinct_substrings())
