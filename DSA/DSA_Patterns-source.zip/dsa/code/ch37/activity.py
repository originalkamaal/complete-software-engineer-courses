# file: activity.py
from itertools import combinations
from check import stress

def max_non_overlapping(intervals):                  # half-open [s, e)
    count, end = 0, float("-inf")
    for s, e in sorted(intervals, key=lambda iv: iv[1]):
        if s >= end:
            count, end = count + 1, e
    return count

def by_start(intervals):                             # tempting but wrong: earliest start first
    count, end = 0, float("-inf")
    for s, e in sorted(intervals):
        if s >= end:
            count, end = count + 1, e
    return count

def by_length(intervals):                            # tempting but wrong: shortest first
    chosen = []
    for s, e in sorted(intervals, key=lambda iv: iv[1] - iv[0]):
        if all(e <= a or s >= b for a, b in chosen):
            chosen.append((s, e))
    return len(chosen)

def brute(intervals):
    for k in range(len(intervals), 0, -1):
        for sub in combinations(sorted(intervals), k):
            if all(a[1] <= b[0] for a, b in zip(sub, sub[1:])):
                return k
    return 0

gen = lambda rng: ([(s := rng.randint(0, 10), s + rng.randint(1, 6)) for _ in range(rng.randint(0, 7))],)
print("earliest finish:", stress(max_non_overlapping, brute, gen))
for wrong in (by_start, by_length):
    try:
        stress(wrong, brute, gen)
    except AssertionError as e:
        print(f"{wrong.__name__:>9} fails:", str(e).split(": ", 1)[1])
