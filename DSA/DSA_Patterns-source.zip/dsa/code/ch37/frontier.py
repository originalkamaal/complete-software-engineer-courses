# file: frontier.py
from collections import deque
from check import stress, rand_list

def min_jumps(a):                                    # a[i] = max jump length from i; -1 if unreachable
    jumps, cur_end, farthest = 0, 0, 0
    for i in range(len(a) - 1):
        if i > farthest:
            return -1
        farthest = max(farthest, i + a[i])
        if i == cur_end:                             # end of this layer: must jump
            jumps, cur_end = jumps + 1, farthest
    return jumps if farthest >= len(a) - 1 or len(a) == 1 else -1

def jumps_bfs(a):
    dist, q = {0: 0}, deque([0])
    while q:
        i = q.popleft()
        for j in range(i + 1, min(len(a), i + a[i] + 1)):
            if j not in dist:
                dist[j] = dist[i] + 1; q.append(j)
    return dist.get(len(a) - 1, -1)

def gas_station(gas, cost):
    if sum(gas) < sum(cost):
        return -1
    start, tank = 0, 0
    for i in range(len(gas)):
        tank += gas[i] - cost[i]
        if tank < 0:
            start, tank = i + 1, 0                   # no station in [start, i] can work
    return start

def gas_brute(gas, cost):
    n = len(gas)
    for s in range(n):
        tank = 0
        for k in range(n):
            i = (s + k) % n
            tank += gas[i] - cost[i]
            if tank < 0:
                break
        else:
            return s
    return -1

def candy(r):
    n = len(r)
    c = [1] * n
    for i in range(1, n):
        if r[i] > r[i - 1]: c[i] = c[i - 1] + 1
    for i in range(n - 2, -1, -1):
        if r[i] > r[i + 1]: c[i] = max(c[i], c[i + 1] + 1)
    return sum(c)

def candy_brute(r):                                   # relax constraints until stable
    c = [1] * len(r)
    changed = True
    while changed:
        changed = False
        for i in range(len(r)):
            for j in (i - 1, i + 1):
                if 0 <= j < len(r) and r[i] > r[j] and c[i] <= c[j]:
                    c[i] = c[j] + 1; changed = True
    return sum(c)

print(stress(min_jumps, jumps_bfs, lambda rng: (rand_list(rng, 0, 3, 10, 1),)))
print(stress(gas_station, gas_brute, lambda rng: ((g := rand_list(rng, 0, 5, 7, 1)), [rng.randint(0, 5) for _ in g])))
print(stress(candy, candy_brute, lambda rng: (rand_list(rng, 0, 4, 10, 1),)))
