# file: scheduling.py
import heapq
from itertools import permutations, combinations
from check import stress

def min_max_lateness(jobs):                          # (duration, deadline)
    t, worst = 0, 0
    for d, dl in sorted(jobs, key=lambda j: j[1]):
        t += d
        worst = max(worst, t - dl)
    return worst

def lateness_brute(jobs):
    best = float("inf")
    for order in permutations(jobs):
        t, worst = 0, 0
        for d, dl in order:
            t += d; worst = max(worst, t - dl)
        best = min(best, worst)
    return best if jobs else 0

def max_courses(courses):                            # (duration, last day); take as many as possible
    t, chosen = 0, []                                # max-heap of durations (negated)
    for d, last in sorted(courses, key=lambda c: c[1]):
        heapq.heappush(chosen, -d); t += d
        if t > last:
            t += heapq.heappop(chosen)               # drop the longest so far (pop returns -longest)
    return len(chosen)

def courses_brute(courses):
    for k in range(len(courses), 0, -1):
        for sub in combinations(courses, k):
            t, ok = 0, True
            for d, last in sorted(sub, key=lambda c: c[1]):   # EDF is optimal for a fixed set
                t += d; ok = ok and t <= last
            if ok:
                return k
    return 0

gen = lambda rng: ([(rng.randint(1, 5), rng.randint(1, 12)) for _ in range(rng.randint(0, 6))],)
print(stress(min_max_lateness, lateness_brute, gen))
print(stress(max_courses, courses_brute, gen))
