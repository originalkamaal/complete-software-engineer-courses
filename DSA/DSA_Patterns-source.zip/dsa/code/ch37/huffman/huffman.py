# file: huffman/huffman.py
import heapq
import math
from collections import Counter
from functools import cache
from check import stress

def huffman_codes(freq):
    if len(freq) == 1:
        return {next(iter(freq)): "0"}
    h = [(f, i, sym) for i, (sym, f) in enumerate(sorted(freq.items()))]
    heapq.heapify(h)
    counter = len(h)
    while len(h) > 1:
        f1, _, a = heapq.heappop(h)
        f2, _, b = heapq.heappop(h)
        heapq.heappush(h, (f1 + f2, counter, (a, b)))   # internal node: a pair of subtrees
        counter += 1
    codes = {}
    stack = [(h[0][2], "")]
    while stack:
        node, code = stack.pop()
        if isinstance(node, tuple):
            stack.append((node[0], code + "0")); stack.append((node[1], code + "1"))
        else:
            codes[node] = code
    return codes

def encoded_bits(freq, codes):
    return sum(freq[s] * len(codes[s]) for s in freq)

def optimal_brute(freq):
    """Minimum total cost of a full binary tree with leaves of these weights (merge any two, recursively)."""
    @cache
    def go(ws):
        if len(ws) == 1:
            return 0
        best = float("inf")
        for i in range(len(ws)):
            for j in range(i + 1, len(ws)):
                rest = ws[:i] + ws[i + 1:j] + ws[j + 1:]
                best = min(best, ws[i] + ws[j] + go(tuple(sorted(rest + (ws[i] + ws[j],)))))
        return best
    return go(tuple(sorted(freq.values()))) if len(freq) > 1 else sum(freq.values())

def check(freq):
    codes = huffman_codes(freq)
    words = list(codes.values())
    prefix_free = not any(a != b and b.startswith(a) for a in words for b in words)
    return encoded_bits(freq, codes), prefix_free

gen = lambda rng: ({chr(97 + i): rng.randint(1, 20) for i in range(rng.randint(1, 6))},)
print(stress(check, lambda f: (optimal_brute(f), True), gen, trials=500))

text = open(__file__).read() * 3                      # this program's own source as the test text
freq = Counter(text)
codes = huffman_codes(freq)
bits = "".join(codes[ch] for ch in text)
decode = {v: k for k, v in codes.items()}
out, cur = [], ""
for b in bits:
    cur += b
    if cur in decode:
        out.append(decode[cur]); cur = ""
n = len(text)
entropy = -sum(f / n * math.log2(f / n) for f in freq.values())
print(f"{n:,} characters, {len(freq)} distinct: {len(bits):,} bits = {len(bits) / n:.3f} bits/char "
      f"(entropy {entropy:.3f}, fixed-length {math.ceil(math.log2(len(freq)))}); decodes correctly: {''.join(out) == text}")
