# file: dsu_test.py
import random
import time
from check import stress
from dsu import DSU

def run(n, ops):
    d, out = DSU(n), []
    for op, a, b in ops:
        if op == "u":
            out.append(d.union(a, b))
        else:
            out.append(d.same(a, b))
    return out, d.groups

def brute(n, ops):                                   # relabel the whole group on each union
    label, out = list(range(n)), []
    for op, a, b in ops:
        if op == "u":
            la, lb = label[a], label[b]
            out.append(la != lb)
            label = [la if l == lb else l for l in label]
        else:
            out.append(label[a] == label[b])
    return out, len(set(label))

def gen(rng):
    n = rng.randint(1, 8)
    return (n, [(rng.choice("uq"), rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 15))])

print(stress(run, brute, gen))

class NaiveDSU(DSU):                                  # no compression, no size: link b's root under a's
    def find(self, x):
        while self.parent[x] != x:
            x = self.parent[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb: return False
        self.parent[ra] = rb
        self.groups -= 1
        return True

n = 20_000
for cls in (NaiveDSU, DSU):
    d = cls(n)
    t = time.perf_counter()
    for i in range(1, n):
        d.union(0, i)                                  # adversarial for the naive version: builds a path
    for i in range(n):
        d.find(i)
    print(f"{cls.__name__:>8}: chain of {n:,} unions + finds in {(time.perf_counter() - t) * 1000:,.0f} ms")
