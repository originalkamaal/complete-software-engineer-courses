# file: percolation/percolation.py
import random
import statistics
import time
from dsu import DSU

def percolation_fraction(N, rng):
    d = DSU(N * N + 2)
    TOP, BOTTOM = N * N, N * N + 1
    open_ = bytearray(N * N)
    order = list(range(N * N))
    rng.shuffle(order)
    for k, cell in enumerate(order, 1):
        open_[cell] = 1
        r, c = divmod(cell, N)
        if r == 0: d.union(cell, TOP)
        if r == N - 1: d.union(cell, BOTTOM)
        for nr, nc in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
            if 0 <= nr < N and 0 <= nc < N and open_[nr * N + nc]:
                d.union(cell, nr * N + nc)
        if d.same(TOP, BOTTOM):
            return k / (N * N)

rng = random.Random(11)
for N, trials in ((20, 200), (100, 100), (200, 30)):
    t = time.perf_counter()
    xs = [percolation_fraction(N, rng) for _ in range(trials)]
    m, s = statistics.mean(xs), statistics.stdev(xs)
    print(f"N={N:>3}, {trials:>3} trials: p* ≈ {m:.4f} ± {1.96 * s / trials ** 0.5:.4f} (95% CI)  [{time.perf_counter() - t:.1f} s]")
