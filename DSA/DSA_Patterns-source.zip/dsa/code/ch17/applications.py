# file: applications.py
from collections import defaultdict
from check import stress, examples
from dsu import DSU

def count_components(n, edges):
    d = DSU(n)
    for a, b in edges:
        d.union(a, b)
    return d.groups

def redundant_edge(edges):                          # nodes 1..n, n edges, exactly one extra
    d = DSU(len(edges) + 1)
    for a, b in edges:
        if not d.union(a, b):
            return [a, b]

def accounts_merge(accounts):                       # [name, email1, email2, ...]
    d = DSU(len(accounts))
    owner = {}
    for i, acc in enumerate(accounts):
        for email in acc[1:]:
            if email in owner:
                d.union(i, owner[email])
            else:
                owner[email] = i
    groups = defaultdict(set)
    for email, i in owner.items():
        groups[d.find(i)].add(email)
    return sorted([accounts[r][0]] + sorted(es) for r, es in groups.items())

def components_bfs(n, edges):
    adj = defaultdict(list)
    for a, b in edges:
        adj[a].append(b); adj[b].append(a)
    seen, c = set(), 0
    for s in range(n):
        if s not in seen:
            c += 1
            stack = [s]; seen.add(s)
            while stack:
                for v in adj[stack.pop()]:
                    if v not in seen:
                        seen.add(v); stack.append(v)
    return c

if __name__ == "__main__":
  print(stress(count_components, components_bfs,
             lambda rng: ((n := rng.randint(1, 9)), [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 8))])))
  print(examples(redundant_edge, [(([[1, 2], [1, 3], [2, 3]],), [2, 3]), (([[1, 2], [2, 3], [3, 4], [1, 4], [1, 5]],), [1, 4])]))
  print(accounts_merge([["John", "a@x", "b@x"], ["John", "c@x"], ["John", "b@x", "d@x"], ["Mary", "m@x"]]))
