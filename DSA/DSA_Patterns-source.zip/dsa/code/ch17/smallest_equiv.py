# file: smallest_equiv.py
from check import stress

def smallest_equivalent(s1, s2, base):
    parent = list(range(26))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]               # path halving
            x = parent[x]
        return x
    for a, b in zip(s1, s2):
        ra, rb = find(ord(a) - 97), find(ord(b) - 97)
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)            # the smaller letter is the root
    return "".join(chr(find(ord(c) - 97) + 97) for c in base)

def brute(s1, s2, base):
    eq = {c: {c} for c in "abcdefghijklmnopqrstuvwxyz"}
    changed = True
    pairs = list(zip(s1, s2))
    while changed:
        changed = False
        for a, b in pairs:
            u = eq[a] | eq[b]
            for c in u:
                if eq[c] != u:
                    eq[c], changed = u, True
    return "".join(min(eq[c]) for c in base)

def gen(rng):
    n = rng.randint(0, 6)
    w = lambda k: "".join(rng.choice("abcdef") for _ in range(k))
    return w(n), w(n), w(rng.randint(1, 6))

print(smallest_equivalent("parker", "morris", "parser"))
print(stress(smallest_equivalent, brute, gen))
