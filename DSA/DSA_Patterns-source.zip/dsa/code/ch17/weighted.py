# file: weighted.py
from fractions import Fraction
from check import stress

class RatioDSU:
    """Maintains value(x) / value(root(x)) for each x."""
    def __init__(self):
        self.parent, self.ratio = {}, {}               # ratio[x] = value(x) / value(parent[x])
    def add(self, x):
        if x not in self.parent:
            self.parent[x], self.ratio[x] = x, Fraction(1)
    def find(self, x):
        path = []
        while self.parent[x] != x:
            path.append(x)
            x = self.parent[x]
        root, acc = x, Fraction(1)
        for node in reversed(path):                    # nearest to root first
            acc *= self.ratio[node]
            self.ratio[node], self.parent[node] = acc, root
        return root
    def union(self, a, b, w):                          # value(a) / value(b) == w
        self.add(a); self.add(b)
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            # value(a) = ratio[a]*value(ra), value(b) = ratio[b]*value(rb); want value(a) = w*value(b)
            self.parent[ra] = rb
            self.ratio[ra] = w * self.ratio[b] / self.ratio[a]
    def query(self, a, b):
        if a not in self.parent or b not in self.parent or self.find(a) != self.find(b):
            return None
        return self.ratio[a] / self.ratio[b]

def run(facts, queries):
    d = RatioDSU()
    for a, b, w in facts:
        d.union(a, b, w)
    return [d.query(a, b) for a, b in queries]

def brute(facts, queries):                             # BFS over the graph of ratios
    from collections import defaultdict, deque
    g = defaultdict(list)
    for a, b, w in facts:
        g[a].append((b, w)); g[b].append((a, 1 / w))
    out = []
    for a, b in queries:
        if a not in g or b not in g:
            out.append(None); continue
        seen, q, ans = {a: Fraction(1)}, deque([a]), None
        while q:
            u = q.popleft()
            for v, w in g[u]:
                if v not in seen:
                    seen[v] = seen[u] / w              # seen[x] = value(x) / value(a)
                    q.append(v)
        out.append(1 / seen[b] if b in seen else None)
    return out

def gen(rng):                                          # consistent facts from hidden values
    names = "abcdef"
    val = {c: Fraction(rng.randint(1, 9)) for c in names}
    facts = []
    for _ in range(rng.randint(0, 5)):
        a, b = rng.sample(names, 2)
        facts.append((a, b, val[a] / val[b]))
    return (facts, [tuple(rng.sample(names, 2)) for _ in range(4)])

print(stress(run, brute, gen))
print(run([("a", "b", Fraction(2)), ("b", "c", Fraction(3))], [("a", "c"), ("c", "a"), ("a", "x")]))
