# file: islands.py
from check import stress
from dsu import DSU

def islands_online(R, C, positions):
    d, land, out, count = DSU(R * C), set(), [], 0
    for r, c in positions:
        if (r, c) not in land:
            land.add((r, c)); count += 1
            for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if (nr, nc) in land and d.union(r * C + c, nr * C + nc):
                    count -= 1                         # merged two islands
        out.append(count)
    return out

def count_islands(land):
    seen, k = set(), 0
    for cell in land:
        if cell not in seen:
            k += 1
            stack = [cell]; seen.add(cell)
            while stack:
                r, c = stack.pop()
                for n in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                    if n in land and n not in seen:
                        seen.add(n); stack.append(n)
    return k

def islands_brute(R, C, positions):
    land, out = set(), []
    for p in positions:
        land.add(p)
        out.append(count_islands(land))
    return out

def components_after_deletions(n, edges, deletions):
    """Edges are removed one by one (by index); report the component count after each removal."""
    deleted = set(deletions)
    d = DSU(n)
    for i, (a, b) in enumerate(edges):
        if i not in deleted:
            d.union(a, b)                              # final state: all deletions applied
    answers = []
    for i in reversed(deletions):
        answers.append(d.groups)                       # count after deletion i (before re-adding it)
        d.union(*edges[i])
    return answers[::-1]

def deletions_brute(n, edges, deletions):
    from applications import components_bfs
    alive, out = set(range(len(edges))), []
    for i in deletions:
        alive.discard(i)
        out.append(components_bfs(n, [edges[j] for j in alive]))
    return out

def gen_islands(rng):
    R, C = rng.randint(1, 4), rng.randint(1, 4)
    return (R, C, [(rng.randrange(R), rng.randrange(C)) for _ in range(rng.randint(0, 10))])

def gen_del(rng):
    n = rng.randint(1, 7)
    edges = [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 9))]
    return (n, edges, rng.sample(range(len(edges)), rng.randint(0, len(edges))))

print(stress(islands_online, islands_brute, gen_islands))
print(stress(components_after_deletions, deletions_brute, gen_del))
