# file: rollback.py
from check import stress

class RollbackDSU:
    def __init__(self, n):
        self.parent, self.size, self.groups, self.history = list(range(n)), [1] * n, n, []
    def find(self, x):                                 # no compression: rollback must stay exact
        while self.parent[x] != x:
            x = self.parent[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            self.history.append(None)                  # record a no-op so rollbacks stay paired
            return False
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        self.size[ra] += self.size[rb]
        self.groups -= 1
        self.history.append((ra, rb))
        return True
    def rollback(self):
        op = self.history.pop()
        if op:
            ra, rb = op
            self.parent[rb] = rb
            self.size[ra] -= self.size[rb]
            self.groups += 1

def run(n, ops):                                       # ops: ("u", a, b) or ("undo",) or ("q", a, b)
    d, out = RollbackDSU(n), []
    for op in ops:
        if op[0] == "u": d.union(op[1], op[2])
        elif op[0] == "undo":
            if d.history: d.rollback()
        else: out.append((d.find(op[1]) == d.find(op[2]), d.groups))
    return out

def brute(n, ops):                                     # replay the surviving unions from scratch
    from applications import components_bfs
    stack, out = [], []
    for op in ops:
        if op[0] == "u": stack.append((op[1], op[2]))
        elif op[0] == "undo":
            if stack: stack.pop()
        else:
            from dsu import DSU
            d = DSU(n)
            for a, b in stack: d.union(a, b)
            out.append((d.same(op[1], op[2]), components_bfs(n, stack)))
    return out

def gen(rng):
    n = rng.randint(1, 7)
    ops = [rng.choice([("u", rng.randrange(n), rng.randrange(n)), ("undo",), ("q", rng.randrange(n), rng.randrange(n))]) for _ in range(rng.randint(0, 15))]
    return (n, ops)

print(stress(run, brute, gen))
