# file: cht.py
from check import stress, rand_list
from lichao import LiChao

def lines_min(lines, xs):
    t = LiChao(-50, 51)
    for m, c in lines:
        t.add(m, c)
    return [t.query(x) for x in xs]

def frog(h, C):                                       # dp[i] = min_j dp[j] + (h[i]-h[j])^2 + C
    # (h_i - h_j)^2 = h_i^2 - 2 h_j h_i + h_j^2 : a line in x = h_i with slope -2h_j and intercept dp[j] + h_j^2
    t = LiChao(0, max(h) + 1)
    dp = [0] * len(h)
    t.add(-2 * h[0], dp[0] + h[0] ** 2)
    for i in range(1, len(h)):
        dp[i] = t.query(h[i]) + h[i] ** 2 + C
        t.add(-2 * h[i], dp[i] + h[i] ** 2)
    return dp[-1]

def frog_brute(h, C):
    dp = [0] * len(h)
    for i in range(1, len(h)):
        dp[i] = min(dp[j] + (h[i] - h[j]) ** 2 + C for j in range(i))
    return dp[-1]

print(stress(lines_min, lambda L, xs: [min(m * x + c for m, c in L) for x in xs],
             lambda rng: ([(rng.randint(-9, 9), rng.randint(-50, 50)) for _ in range(rng.randint(1, 8))], [rng.randint(-50, 50) for _ in range(6)])))
print(stress(frog, frog_brute, lambda rng: (sorted(rand_list(rng, 1, 40, 10, 1)), rng.randint(0, 30))))
