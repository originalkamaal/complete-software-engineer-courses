# file: obst_knuth/obst_knuth.py
import random
import time
from check import stress
from obst import optimal_bst

def optimal_bst_knuth(freq):
    n = len(freq)
    pre = [0]
    for f in freq:
        pre.append(pre[-1] + f)
    cost = [[0] * (n + 1) for _ in range(n + 2)]       # half-open [i, j), as in Chapter 31
    root = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n):
        cost[i][i + 1], root[i][i + 1] = freq[i], i
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length
            best, arg = float("inf"), -1
            for r in range(root[i][j - 1], root[i + 1][j] + 1):   # Knuth: opt[i][j-1] <= opt[i][j] <= opt[i+1][j]
                c = cost[i][r] + cost[r + 1][j]
                if c < best:
                    best, arg = c, r
            cost[i][j], root[i][j] = best + pre[j] - pre[i], arg
    return cost[0][n]

print(stress(optimal_bst_knuth, lambda f: optimal_bst(f)[0], lambda rng: ([rng.randint(0, 20) for _ in range(rng.randint(0, 25))],), trials=500))
rng = random.Random(30)
for n in (100, 200, 400, 800):
    freq = [rng.randint(1, 1000) for _ in range(n)]
    t = time.perf_counter()
    a = optimal_bst_knuth(freq)
    tk = time.perf_counter() - t
    if n <= 400:
        t = time.perf_counter()
        b = optimal_bst(freq)[0]
        tc = time.perf_counter() - t
        print(f"n={n:>3}: Knuth {tk * 1000:6.0f} ms, cubic {tc * 1000:7.0f} ms, same cost: {a == b}")
    else:
        print(f"n={n:>3}: Knuth {tk * 1000:6.0f} ms  (cubic skipped: expected ~8x the n=400 time)")
