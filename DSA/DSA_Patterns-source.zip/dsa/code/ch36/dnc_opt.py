# file: dnc_opt.py
from check import stress, rand_list

def partition_min_cost(a, K):                         # split a into K contiguous groups; cost of a group = (sum)^2
    n = len(a)
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    C = lambda j, i: (P[i] - P[j]) ** 2               # cost of group a[j:i]
    INF = float("inf")
    prev = [0] + [INF] * n                            # 0 groups: only the empty prefix is free
    for _ in range(K):
        cur = [INF] * (n + 1)
        stack = [(1, n, 0, n - 1)]                     # (i_lo, i_hi, opt_lo, opt_hi), iterative recursion
        while stack:
            lo, hi, olo, ohi = stack.pop()
            if lo > hi:
                continue
            mid = (lo + hi) // 2
            best, arg = INF, olo
            for j in range(olo, min(mid - 1, ohi) + 1):
                v = prev[j] + C(j, mid)
                if v < best:
                    best, arg = v, j
            cur[mid] = best
            stack.append((lo, mid - 1, olo, arg))
            stack.append((mid + 1, hi, arg, ohi))
        prev = cur
    return prev[n]

def brute(a, K):
    n = len(a)
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    INF = float("inf")
    prev = [0] + [INF] * n
    for _ in range(K):
        prev = [INF] + [min(prev[j] + (P[i] - P[j]) ** 2 for j in range(i)) for i in range(1, n + 1)]
    return prev[n]

if __name__ == "__main__":
    print(stress(partition_min_cost, brute, lambda rng: ((a := rand_list(rng, 0, 9, 12, 1)), rng.randint(1, len(a)))))
