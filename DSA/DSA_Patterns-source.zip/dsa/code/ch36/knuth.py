# file: knuth.py
from check import stress, rand_list

def merge_piles(a):                                   # merge adjacent piles; cost of a merge = combined size
    n = len(a)
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    dp = [[0] * n for _ in range(n)]
    opt = [[i] * n for i in range(n)]
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            best, arg = float("inf"), -1
            for k in range(opt[i][j - 1], min(opt[i + 1][j], j - 1) + 1):   # Knuth's range
                v = dp[i][k] + dp[k + 1][j]
                if v < best:
                    best, arg = v, k
            dp[i][j], opt[i][j] = best + P[j + 1] - P[i], arg
    return dp[0][n - 1] if n else 0

def brute(a):
    n = len(a)
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    dp = [[0] * n for _ in range(n)]
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            dp[i][j] = min(dp[i][k] + dp[k + 1][j] for k in range(i, j)) + P[j + 1] - P[i]
    return dp[0][n - 1] if n else 0

print(stress(merge_piles, brute, lambda rng: (rand_list(rng, 0, 20, 12),)))
