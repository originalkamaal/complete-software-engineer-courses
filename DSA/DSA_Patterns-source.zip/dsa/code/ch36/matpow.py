# file: matpow.py
from check import stress

MOD = 10**9 + 7

def mat_mul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) % MOD for j in range(len(B[0]))] for i in range(len(A))]

def mat_pow(M, n):
    R = [[int(i == j) for j in range(len(M))] for i in range(len(M))]
    while n:
        if n & 1:
            R = mat_mul(R, M)
        M = mat_mul(M, M)
        n >>= 1
    return R

def linear_recurrence(coeffs, init, n):              # x[k] = sum coeffs[t] * x[k-1-t]; init = x[0..d-1]
    d = len(coeffs)
    if n < d:
        return init[n] % MOD
    M = [coeffs] + [[int(j == i) for j in range(d)] for i in range(d - 1)]   # companion matrix
    P = mat_pow(M, n - d + 1)
    state = init[::-1]                               # [x[d-1], ..., x[0]]
    return sum(P[0][j] * state[j] for j in range(d)) % MOD

def brute(coeffs, init, n):
    x = list(init)
    while len(x) <= n:
        x.append(sum(c * x[-1 - t] for t, c in enumerate(coeffs)) % MOD)
    return x[n] % MOD

def walks(adj, length):                               # number of walks of a given length between all pairs
    return mat_pow(adj, length)

print(stress(linear_recurrence, brute, lambda rng: ((c := [rng.randint(0, 5) for _ in range(rng.randint(1, 4))]), [rng.randint(0, 5) for _ in c], rng.randint(0, 60))))
print("Fibonacci(10^18) mod p =", linear_recurrence([1, 1], [0, 1], 10**18))
print("walks of length 10 from 0 to 0 in a triangle:", walks([[0, 1, 1], [1, 0, 1], [1, 1, 0]], 10)[0][0])
