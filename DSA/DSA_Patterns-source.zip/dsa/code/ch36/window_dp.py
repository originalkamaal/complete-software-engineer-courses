# file: window_dp.py
from collections import deque
from check import stress, rand_list

def max_jump_score(a, k):                            # start at 0, jump 1..k forward, end at n-1, maximise sum of visited
    n = len(a)
    dp = [0] * n
    dp[0] = a[0]
    dq = deque([0])                                  # indices with decreasing dp
    for i in range(1, n):
        while dq[0] < i - k:
            dq.popleft()                             # out of the window
        dp[i] = dp[dq[0]] + a[i]
        while dq and dp[dq[-1]] <= dp[i]:
            dq.pop()
        dq.append(i)
    return dp[-1]

def brute(a, k):
    dp = [a[0]] + [float("-inf")] * (len(a) - 1)
    for i in range(1, len(a)):
        dp[i] = max(dp[j] for j in range(max(0, i - k), i)) + a[i]
    return dp[-1]

print(stress(max_jump_score, brute, lambda rng: (rand_list(rng, -9, 9, 15, 1), rng.randint(1, 4))))
