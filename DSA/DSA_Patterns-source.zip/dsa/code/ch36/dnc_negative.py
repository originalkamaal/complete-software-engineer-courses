# file: dnc_negative.py
from check import stress, rand_list
from dnc_opt import partition_min_cost, brute

try:
    stress(partition_min_cost, brute, lambda rng: ((a := rand_list(rng, -9, 9, 10, 1)), rng.randint(1, len(a))))
    print("no counterexample found")
except AssertionError as e:
    print("with negative values the optimisation fails:", str(e).split(": ", 1)[1])
