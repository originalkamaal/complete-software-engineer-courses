# file: superstring/superstring.py
import random
import time
from itertools import permutations
from check import stress

def shortest_superstring(words):
    words = sorted(set(words))
    words = [w for w in words if not any(w != x and w in x for x in words)]
    n = len(words)
    if n == 0:
        return ""
    ov = [[0] * n for _ in range(n)]
    for i, a in enumerate(words):
        for j, b in enumerate(words):
            if i != j:
                ov[i][j] = next((k for k in range(min(len(a), len(b)), 0, -1) if a.endswith(b[:k])), 0)
    NEG = -1
    dp = [[NEG] * n for _ in range(1 << n)]
    par = [[-1] * n for _ in range(1 << n)]
    for i in range(n):
        dp[1 << i][i] = 0
    for mask in range(1 << n):
        for last in range(n):
            cur = dp[mask][last]
            if cur < 0:
                continue
            for nxt in range(n):
                if not mask >> nxt & 1:
                    nm = mask | 1 << nxt
                    val = cur + ov[last][nxt]
                    if val > dp[nm][nxt] or (val == dp[nm][nxt] and par[nm][nxt] > last):
                        dp[nm][nxt], par[nm][nxt] = val, last
    full = (1 << n) - 1
    last = max(range(n), key=lambda v: dp[full][v])
    order, mask = [], full
    while last != -1:
        order.append(last)
        mask, last = mask ^ (1 << last), par[mask][last]
    order.reverse()
    s = words[order[0]]
    for a, b in zip(order, order[1:]):
        s += words[b][ov[a][b]:]
    return s

def brute(words):
    words = list(set(words))
    best = None
    for p in permutations(words):
        s = ""
        for w in p:                                   # greedy merge in this order (max overlap)
            if w in s:
                continue
            k = next((k for k in range(min(len(s), len(w)), 0, -1) if s.endswith(w[:k])), 0)
            s += w[k:]
        if best is None or len(s) < len(best):
            best = s
    return len(best)

def check(words):
    s = shortest_superstring(words)
    return len(s), all(w in s for w in words)

gen = lambda rng: (["".join(rng.choice("ab") for _ in range(rng.randint(1, 4))) for _ in range(rng.randint(1, 5))],)
print(stress(check, lambda w: (brute(w), True), gen, trials=800))
print(shortest_superstring(["catg", "ctaagt", "gcta", "ttca", "atgcatc"]))

rng = random.Random(21)
genome = "".join(rng.choice("ACGT") for _ in range(120))
for label, starts in (("tiled every 10 bases", list(range(0, 101, 10)) + [55]), ("12 random starts", rng.sample(range(0, 101), 12))):
    reads = sorted({genome[i:i + 20] for i in starts})
    t = time.perf_counter()
    s = shortest_superstring(reads)
    print(f"{label:>20}: {len(reads)} reads -> superstring of length {len(s)} in {(time.perf_counter() - t) * 1000:.0f} ms;"
          f" equals the genome: {s == genome}; substring of it: {s in genome}")
