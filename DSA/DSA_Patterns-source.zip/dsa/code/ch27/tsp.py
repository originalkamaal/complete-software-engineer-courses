# file: tsp.py
from itertools import permutations
from check import stress

INF = float("inf")

def tsp_cycle(d):                                     # minimum Hamiltonian cycle through 0; d is n x n
    n = len(d)
    if n == 1:
        return 0, [0, 0]                              # the trivial cycle 0 -> 0
    dp = [[INF] * n for _ in range(1 << n)]
    par = [[-1] * n for _ in range(1 << n)]
    dp[1][0] = 0
    for mask in range(1 << n):
        if not mask & 1:
            continue                                  # paths start at 0
        row = dp[mask]
        for v in range(n):
            cur = row[v]
            if cur == INF:
                continue
            for w in range(n):
                if not mask >> w & 1:
                    nm = mask | 1 << w
                    if cur + d[v][w] < dp[nm][w]:
                        dp[nm][w], par[nm][w] = cur + d[v][w], v
    full = (1 << n) - 1
    best, last = min((dp[full][v] + d[v][0], v) for v in range(1, n))
    tour, mask, v = [], full, last
    while v != -1:                                    # walk predecessors back to 0
        tour.append(v)
        mask, v = mask ^ (1 << v), par[mask][v]
    return best, tour[::-1] + [0]

def brute(d):
    n = len(d)
    if n == 1:
        return 0
    return min(sum(d[a][b] for a, b in zip((0,) + p, p + (0,))) for p in permutations(range(1, n)))

def check(d):
    best, tour = tsp_cycle(d)
    return best, sorted(tour[:-1]) == list(range(len(d))) and sum(d[a][b] for a, b in zip(tour, tour[1:])) == best

gen = lambda rng: ([[0 if i == j else rng.randint(1, 20) for j in range(n)] for n in [rng.randint(1, 7)] for i in range(n)],)
square = lambda d: all(len(row) == len(d) for row in d) and len(d) >= 1
if __name__ == "__main__":
    print(stress(check, lambda d: (brute(d), True), gen, trials=800, valid=square))
