# file: colouring.py
from itertools import product
from check import stress

def greedy_colour(n, edges, order=None):
    adj = [set() for _ in range(n)]
    for u, v in edges:
        if u != v:
            adj[u].add(v); adj[v].add(u)
    colour = [-1] * n
    for v in order or range(n):
        used = {colour[w] for w in adj[v]}
        colour[v] = next(c for c in range(n + 1) if c not in used)
    return colour

def chromatic_number(n, edges):                       # DP over subsets: fewest independent sets covering mask
    if n == 0:
        return 0
    adjm = [0] * n
    for u, v in edges:
        if u != v:
            adjm[u] |= 1 << v; adjm[v] |= 1 << u
    full = (1 << n) - 1
    indep = [False] * (1 << n)
    indep[0] = True
    for m in range(1, 1 << n):
        v = (m & -m).bit_length() - 1
        rest = m & (m - 1)
        indep[m] = indep[rest] and not (adjm[v] & rest)
    best = [n + 1] * (1 << n)
    best[0] = 0
    for m in range(1, 1 << n):
        low = m & -m                                  # the set containing the lowest vertex: avoids recounting
        sub = m
        while sub:
            if sub & low and indep[sub] and best[m ^ sub] + 1 < best[m]:
                best[m] = best[m ^ sub] + 1
            sub = (sub - 1) & m
    return best[full]

def brute(n, edges):
    for k in range(1, n + 1):
        if any(all(c[u] != c[v] for u, v in edges) for c in product(range(k), repeat=n)):
            return k
    return 0

def gen(rng):
    n = rng.randint(0, 7)
    return (n, [(u, v) for u, v in ((rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 12))) if u != v] if n else [])

print(stress(chromatic_number, brute, gen, trials=800))
print(stress(lambda n, e: all(c[u] != c[v] for c in [greedy_colour(n, e)] for u, v in e) and max(greedy_colour(n, e), default=-1) + 1 >= chromatic_number(n, e),
             lambda n, e: True, gen, trials=800))
crown = [(i, 4 + j) for i in range(4) for j in range(4) if i != j]                 # crown graph: bipartite
bad_order = [0, 4, 1, 5, 2, 6, 3, 7]
print("crown graph S4: chromatic", chromatic_number(8, crown), "| greedy in a bad order uses", max(greedy_colour(8, crown, bad_order)) + 1)
