# file: debruijn.py
from itertools import product
from check import stress
from euler import euler_path

def de_bruijn(k, n):
    alphabet = "0123456789"[:k]
    if n == 1:
        return alphabet
    nodes = ["".join(p) for p in product(alphabet, repeat=n - 1)]
    edges = [(u, u[1:] + ch) for u in nodes for ch in alphabet]
    path = euler_path(edges)
    return path[0] + "".join(v[-1] for v in path[1:])

def ok(k, n):
    s = de_bruijn(k, n)
    alphabet = "0123456789"[:k]
    subs = {s[i:i + n] for i in range(len(s) - n + 1)}
    return len(s) == k ** n + n - 1 and all("".join(p) in subs for p in product(alphabet, repeat=n))

print(stress(ok, lambda k, n: True, lambda rng: (rng.randint(1, 4), rng.randint(1, 4)), trials=200))
print(de_bruijn(2, 3), de_bruijn(10, 4)[:30] + "...", len(de_bruijn(10, 4)))
