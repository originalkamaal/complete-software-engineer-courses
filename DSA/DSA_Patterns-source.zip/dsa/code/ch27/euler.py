# file: euler.py
from collections import defaultdict
from itertools import permutations
from check import stress

def euler_path(edges):
    """Directed multigraph. Returns a vertex list using every edge once, or None."""
    adj, indeg, outdeg = defaultdict(list), defaultdict(int), defaultdict(int)
    for u, v in edges:
        adj[u].append(v); outdeg[u] += 1; indeg[v] += 1
    if not edges:
        return []
    verts = set(indeg) | set(outdeg)
    starts = [v for v in verts if outdeg[v] - indeg[v] == 1]
    ends = [v for v in verts if indeg[v] - outdeg[v] == 1]
    if any(abs(outdeg[v] - indeg[v]) > 1 for v in verts) or len(starts) > 1 or len(ends) > 1 or len(starts) != len(ends):
        return None
    start = starts[0] if starts else min(v for v in verts if outdeg[v])
    for u in adj:
        adj[u].sort(reverse=True)                     # pop() from the end = smallest first
    stack, out = [start], []
    while stack:
        u = stack[-1]
        if adj[u]:
            stack.append(adj[u].pop())
        else:
            out.append(stack.pop())
    out.reverse()
    return out if len(out) == len(edges) + 1 else None   # disconnected edges left unused

def brute(edges):                                       # lexicographically smallest Euler path by trying orders
    if not edges:
        return []
    best = None
    for perm in permutations(range(len(edges))):
        es = [edges[i] for i in perm]
        if all(a[1] == b[0] for a, b in zip(es, es[1:])):
            path = [es[0][0]] + [v for _, v in es]
            if best is None or path < best:
                best = path
    return best

gen = lambda rng: ([(rng.randint(0, 3), rng.randint(0, 3)) for _ in range(rng.randint(0, 6))],)
if __name__ == "__main__":
    print(stress(euler_path, brute, gen, trials=1500))
    tickets = [("JFK", "SFO"), ("JFK", "ATL"), ("SFO", "ATL"), ("ATL", "JFK"), ("ATL", "SFO")]
    print(euler_path(tickets))
