# file: centroid_test.py
import math
from check import stress
from rooted import root_tree, random_tree
from centroid import centroid_decomposition

def depth_of_centroid_tree(n, edges):
    adj = root_tree(n, edges)[0]
    cpar = centroid_decomposition(n, adj)
    def d(v):
        k = 0
        while cpar[v] != -1:
            v, k = cpar[v], k + 1
        return k
    return max(d(v) for v in range(n)), sum(p == -1 for p in cpar)

print(stress(lambda n, e: (lambda d, roots: d <= math.log2(n) and roots == 1)(*depth_of_centroid_tree(n, e)), lambda n, e: True,
             lambda rng: ((n := rng.randint(1, 40)), random_tree(rng, n))))
path = [(i, i + 1) for i in range(1023)]
print("path of 1024 vertices: centroid tree depth", depth_of_centroid_tree(1024, path)[0])
