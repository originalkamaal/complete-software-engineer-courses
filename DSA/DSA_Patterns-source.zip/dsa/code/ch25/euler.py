# file: euler.py
from check import stress
from rooted import root_tree, subtree_sizes, random_tree
from fenwick import Fenwick

def euler_tin(n, adj, root=0):
    tin, timer = [0] * n, 0
    stack, seen = [root], [False] * n
    seen[root] = True
    while stack:                                     # iterative preorder
        u = stack.pop()
        tin[u] = timer; timer += 1
        for v in reversed(adj[u]):
            if not seen[v]:
                seen[v] = True; stack.append(v)
    return tin

def subtree_queries(n, edges, values, ops):
    adj, parent, _, order = root_tree(n, edges)
    size, tin = subtree_sizes(parent, order), euler_tin(n, adj)
    f = Fenwick(n)
    for v in range(n):
        f.add(tin[v], values[v])
    out = []
    for kind, v, x in ops:
        if kind == "add":
            f.add(tin[v], x)
        else:
            out.append(f.range_sum(tin[v], tin[v] + size[v]))
    return out

def brute(n, edges, values, ops):
    adj, parent, _, _ = root_tree(n, edges)
    vals, out = values[:], []
    def total(u):
        return vals[u] + sum(total(w) for w in adj[u] if w != parent[u])
    for kind, v, x in ops:
        if kind == "add": vals[v] += x
        else: out.append(total(v))
    return out

def gen(rng):
    n = rng.randint(1, 10)
    return (n, random_tree(rng, n), [rng.randint(-5, 5) for _ in range(n)],
            [(rng.choice(["add", "sum"]), rng.randrange(n), rng.randint(-5, 5)) for _ in range(8)])

print(stress(subtree_queries, brute, gen))
