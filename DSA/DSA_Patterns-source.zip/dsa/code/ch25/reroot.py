# file: reroot.py
from collections import deque
from check import stress
from rooted import root_tree, subtree_sizes, random_tree

def sum_of_distances(n, edges):
    adj, parent, depth, order = root_tree(n, edges)
    size = subtree_sizes(parent, order)
    ans = [0] * n
    ans[0] = sum(depth)                              # root 0: sum of depths
    for u in order:                                  # parents before children
        for v in adj[u]:
            if v != parent[u]:
                ans[v] = ans[u] - size[v] + (n - size[v])
    return ans

def brute(n, edges):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v); adj[v].append(u)
    out = []
    for s in range(n):
        dist, q = {s: 0}, deque([s])
        while q:
            u = q.popleft()
            for v in adj[u]:
                if v not in dist:
                    dist[v] = dist[u] + 1; q.append(v)
        out.append(sum(dist.values()))
    return out

print(stress(sum_of_distances, brute, lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n))))
