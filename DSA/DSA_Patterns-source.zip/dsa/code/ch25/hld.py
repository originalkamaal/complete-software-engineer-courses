# file: hld.py
import operator
from check import stress
from rooted import root_tree, subtree_sizes, random_tree
from segtree import SegTree

class HLD:
    def __init__(self, n, edges, values, op=max, identity=float("-inf")):
        adj, parent, depth, order = root_tree(n, edges)
        size = subtree_sizes(parent, order)
        heavy = [-1] * n
        for u in order:
            best = -1
            for v in adj[u]:
                if v != parent[u] and (best == -1 or size[v] > size[best]):
                    best = v
            heavy[u] = best
        head, pos, cur = [0] * n, [0] * n, 0
        stack = [0]                                   # DFS: heavy child processed right after its parent
        head[0] = 0
        while stack:
            u = stack.pop()
            pos[u] = cur; cur += 1
            for v in adj[u]:
                if v != parent[u] and v != heavy[u]:
                    head[v] = v; stack.append(v)      # light child starts a new chain
            if heavy[u] != -1:
                head[heavy[u]] = head[u]; stack.append(heavy[u])   # pushed last = popped next
        self.parent, self.depth, self.head, self.pos, self.op, self.e = parent, depth, head, pos, op, identity
        arr = [identity] * n
        for v in range(n):
            arr[pos[v]] = values[v]
        self.st = SegTree(arr, op, identity)

    def update(self, v, value):
        self.st.update(self.pos[v], value)

    def path_query(self, u, v):
        res = self.e
        while self.head[u] != self.head[v]:
            if self.depth[self.head[u]] < self.depth[self.head[v]]:
                u, v = v, u
            h = self.head[u]                           # climb the chain whose head is deeper
            res = self.op(res, self.st.query(self.pos[h], self.pos[u] + 1))
            u = self.parent[h]
        a, b = sorted((self.pos[u], self.pos[v]))
        return self.op(res, self.st.query(a, b + 1))

def run(n, edges, values, ops):
    h, out = HLD(n, edges, values), []
    for kind, u, v in ops:
        if kind == "set": h.update(u, v)
        else: out.append(h.path_query(u, v))
    return out

def brute(n, edges, values, ops):
    _, parent, depth, _ = root_tree(n, edges)
    vals, out = values[:], []
    for kind, u, v in ops:
        if kind == "set":
            vals[u] = v; continue
        best = float("-inf")
        while u != v:                                  # climb the deeper one
            if depth[u] < depth[v]: u, v = v, u
            best = max(best, vals[u]); u = parent[u]
        out.append(max(best, vals[u]))
    return out

def gen(rng):
    n = rng.randint(1, 12)
    return (n, random_tree(rng, n), [rng.randint(-9, 9) for _ in range(n)],
            [(rng.choice(["set", "q", "q"]), rng.randrange(n), rng.randrange(n) if rng.random() < 0.5 else rng.randint(-9, 9)) for _ in range(10)])

def valid(n, edges, values, ops):
    return all(0 <= u < n and (kind == "set" or 0 <= v < n) for kind, u, v in ops)

print(stress(run, brute, gen, valid=valid))
