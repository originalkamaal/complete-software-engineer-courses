# file: lifting_test.py
from check import stress
from rooted import root_tree, random_tree
from lifting import Lifting

def run(n, edges, queries):
    _, parent, depth, _ = root_tree(n, edges)
    L = Lifting(parent, depth)
    return [(L.kth_ancestor(u, k), L.lca(u, v)) for u, v, k in queries]

def brute(n, edges, queries):
    _, parent, depth, _ = root_tree(n, edges)
    def anc(u, k):
        for _ in range(k):
            u = parent[u]
            if u == -1:
                return -1
        return u
    def lca(u, v):
        path = set()
        while u != -1:
            path.add(u); u = parent[u]
        while v not in path:
            v = parent[v]
        return v
    return [(anc(u, k), lca(u, v)) for u, v, k in queries]

def gen(rng):
    n = rng.randint(1, 12)
    return (n, random_tree(rng, n), [(rng.randrange(n), rng.randrange(n), rng.randint(0, n)) for _ in range(6)])

print(stress(run, brute, gen))
