# file: rooted_test.py
from check import stress
from rooted import root_tree, subtree_sizes, random_tree

def sizes_brute(n, edges):
    adj, parent, _, _ = root_tree(n, edges)
    def count(u):                                   # recursive, fine for small n
        return 1 + sum(count(v) for v in adj[u] if v != parent[u])
    return [count(u) for u in range(n)]

print(stress(lambda n, e: subtree_sizes(*[root_tree(n, e)[i] for i in (1, 3)]), sizes_brute,
             lambda rng: ((n := rng.randint(1, 10)), random_tree(rng, n))))
