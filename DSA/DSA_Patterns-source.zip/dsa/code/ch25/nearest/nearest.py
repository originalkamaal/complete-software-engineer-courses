# file: nearest/nearest.py
import random
import time
from collections import deque
from check import stress
from rooted import root_tree, random_tree
from lifting import Lifting
from centroid import centroid_decomposition

class NearestMarked:
    def __init__(self, n, edges):
        adj, parent, depth, _ = root_tree(n, edges)
        self.L = Lifting(parent, depth)
        self.cpar = centroid_decomposition(n, adj)
        self.best = [float("inf")] * n
        self.mark(0)
    def mark(self, v):
        c = v
        while c != -1:
            self.best[c] = min(self.best[c], self.L.dist(v, c))
            c = self.cpar[c]
    def query(self, v):
        res, c = float("inf"), v
        while c != -1:
            res = min(res, self.best[c] + self.L.dist(v, c))
            c = self.cpar[c]
        return res

def run(n, edges, ops):
    nm, out = NearestMarked(n, edges), []
    for kind, v in ops:
        if kind == "mark": nm.mark(v)
        else: out.append(nm.query(v))
    return out

def brute(n, edges, ops):                             # multi-source BFS from all marked vertices
    adj = root_tree(n, edges)[0]
    marked, out = {0}, []
    for kind, v in ops:
        if kind == "mark":
            marked.add(v); continue
        dist, q = {m: 0 for m in marked}, deque(marked)
        while q:
            u = q.popleft()
            for w in adj[u]:
                if w not in dist:
                    dist[w] = dist[u] + 1; q.append(w)
        out.append(dist[v])
    return out

def gen(rng):
    n = rng.randint(1, 15)
    return (n, random_tree(rng, n), [(rng.choice(["mark", "query"]), rng.randrange(n)) for _ in range(10)])

print(stress(run, brute, gen))
rng = random.Random(19)
n = 100_000
edges = random_tree(rng, n)
t = time.perf_counter()
nm = NearestMarked(n, edges)
build = time.perf_counter() - t
ops = [(rng.choice(["mark", "query"]), rng.randrange(n)) for _ in range(100_000)]
t = time.perf_counter()
answers = [nm.query(v) if kind == "query" else nm.mark(v) for kind, v in ops]
qs = [a for a in answers if a is not None]
print(f"n={n:,}: build {build:.1f} s, 100,000 operations {time.perf_counter() - t:.1f} s; "
      f"first answers {qs[:8]}, last {qs[-3:]}")
