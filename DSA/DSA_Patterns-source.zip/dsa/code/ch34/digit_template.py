# file: digit_template.py
from functools import cache
from check import stress

def count_digit_sum_mod(N, k):
    """How many x in [1, N] have digit sum divisible by k?"""
    digits = list(map(int, str(N)))
    @cache
    def go(pos, tight, started, s):
        if pos == len(digits):
            return int(started and s == 0)
        limit = digits[pos] if tight else 9
        total = 0
        for d in range(limit + 1):
            total += go(pos + 1, tight and d == limit, started or d > 0, (s + d) % k)
        return total
    return go(0, True, False, 0)

def brute(N, k):
    return sum(sum(map(int, str(x))) % k == 0 for x in range(1, N + 1))

print(stress(count_digit_sum_mod, brute, lambda rng: (rng.randint(1, 3000), rng.randint(1, 12))))
print(count_digit_sum_mod(10**18, 7), "numbers in [1, 10^18] have digit sum divisible by 7")
