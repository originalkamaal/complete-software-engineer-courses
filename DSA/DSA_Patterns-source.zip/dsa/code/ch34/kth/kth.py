# file: kth/kth.py
import time
from functools import cache
from check import stress

K = 7

@cache
def completions(remaining, s):
    """Number of digit strings of length `remaining` (any digits, leading zeros allowed) bringing sum s to 0 mod K."""
    if remaining == 0:
        return int(s % K == 0)
    return sum(completions(remaining - 1, (s + d) % K) for d in range(10))

def kth(k):
    length = 1
    while True:                                        # numbers with exactly `length` digits
        block = sum(completions(length - 1, d % K) for d in range(1, 10))
        if k <= block:
            break
        k -= block
        length += 1
    out, s = [], 0
    for pos in range(length):
        for d in range(1 if pos == 0 else 0, 10):
            c = completions(length - pos - 1, (s + d) % K)
            if k <= c:
                out.append(d); s = (s + d) % K
                break
            k -= c
    return int("".join(map(str, out)))

def brute(k):
    x = 0
    while k:
        x += 1
        if sum(map(int, str(x))) % K == 0:
            k -= 1
    return x

print(stress(kth, brute, lambda rng: (rng.randint(1, 3000),)))
t = time.perf_counter()
for k in (1, 10, 10**6, 10**12, 10**15):
    x = kth(k)
    print(f"k = {k:>16,}: {x:>20,}  (digit sum {sum(map(int, str(x)))})")
print(f"[{(time.perf_counter() - t) * 1000:.1f} ms for all five]")
