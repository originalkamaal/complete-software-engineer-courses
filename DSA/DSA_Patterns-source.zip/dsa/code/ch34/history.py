# file: history.py
from functools import cache
from check import stress

def count_distinct_digits(N):                         # numbers in [1, N] with all digits distinct
    digits = list(map(int, str(N)))
    @cache
    def go(pos, tight, started, mask):
        if pos == len(digits):
            return int(started)
        total = 0
        for d in range(digits[pos] + 1 if tight else 10):
            if started or d > 0:
                if mask >> d & 1:
                    continue                          # digit already used
                total += go(pos + 1, tight and d == digits[pos], True, mask | 1 << d)
            else:
                total += go(pos + 1, tight and d == digits[pos], False, mask)   # leading zero: not a digit
        return total
    return go(0, True, False, 0)

def count_no_equal_adjacent(N):                       # numbers in [1, N] with no two equal neighbouring digits
    digits = list(map(int, str(N)))
    @cache
    def go(pos, tight, prev):                         # prev = -1 while not started
        if pos == len(digits):
            return int(prev != -1)
        total = 0
        for d in range(digits[pos] + 1 if tight else 10):
            if prev == -1 and d == 0:
                total += go(pos + 1, tight and d == digits[pos], -1)
            elif d != prev:
                total += go(pos + 1, tight and d == digits[pos], d)
        return total
    return go(0, True, -1)

print(stress(count_distinct_digits, lambda N: sum(len(set(str(x))) == len(str(x)) for x in range(1, N + 1)), lambda rng: (rng.randint(1, 5000),)))
print(stress(count_no_equal_adjacent, lambda N: sum(all(a != b for a, b in zip(str(x), str(x)[1:])) for x in range(1, N + 1)), lambda rng: (rng.randint(1, 5000),)))
print(count_distinct_digits(10**10), "numbers below 10^10 have all distinct digits")
