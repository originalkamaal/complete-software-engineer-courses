# file: ranges.py
from functools import cache
from check import stress

def count_and_sum(N, k):
    """(count, sum) of x in [0, N] with digit sum divisible by k (0 counts)."""
    if N < 0:
        return 0, 0
    digits = list(map(int, str(N)))
    n = len(digits)
    @cache
    def go(pos, tight, s):
        if pos == n:
            return (1, 0) if s == 0 else (0, 0)
        cnt = tot = 0
        place = 10 ** (n - pos - 1)
        for d in range(digits[pos] + 1 if tight else 10):
            c, t = go(pos + 1, tight and d == digits[pos], (s + d) % k)
            cnt += c
            tot += t + d * place * c
        return cnt, tot
    return go(0, True, 0)

def in_range(L, R, k):
    cR, sR = count_and_sum(R, k)
    cL, sL = count_and_sum(L - 1, k)
    return cR - cL, sR - sL

def brute(L, R, k):
    xs = [x for x in range(L, R + 1) if sum(map(int, str(x))) % k == 0]
    return len(xs), sum(xs)

print(stress(in_range, brute, lambda rng: ((L := rng.randint(0, 2000)), L + rng.randint(0, 2000), rng.randint(1, 9))))
print(in_range(10**17, 10**18, 9))
