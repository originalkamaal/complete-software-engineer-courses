# file: phone_letters.py
from itertools import product
from check import stress

KEYS = {"2": "abc", "3": "def", "4": "ghi", "5": "jkl", "6": "mno", "7": "pqrs", "8": "tuv", "9": "wxyz"}

def letter_combinations(digits):
    if not digits:
        return []
    out, path = [], []
    def backtrack(i):
        if i == len(digits):
            out.append("".join(path))
            return
        for ch in KEYS[digits[i]]:
            path.append(ch)          # choose
            backtrack(i + 1)         # explore
            path.pop()               # undo
    backtrack(0)
    return out

def brute(digits):
    return ["".join(p) for p in product(*(KEYS[d] for d in digits))] if digits else []

print(letter_combinations("23"))
print(stress(letter_combinations, brute, lambda rng: ("".join(rng.choice("23456789") for _ in range(rng.randint(0, 4))),)))
