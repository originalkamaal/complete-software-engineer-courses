# file: constraints.py
import time
from check import examples

def n_queens(n):                                     # count solutions with bitmasks
    full = (1 << n) - 1
    def go(cols, d1, d2):
        if cols == full:
            return 1
        count, free = 0, full & ~(cols | d1 | d2)
        while free:
            bit = free & -free                       # lowest free column
            free ^= bit
            count += go(cols | bit, ((d1 | bit) << 1) & full, (d2 | bit) >> 1)
        return count
    return go(0, 0, 0)

def solve_sudoku(board):                             # board: list of 9 strings, '.' empty; returns solved list
    g = [list(r) for r in board]
    rows, cols, boxes = [set() for _ in range(9)], [set() for _ in range(9)], [set() for _ in range(9)]
    empty = []
    for r in range(9):
        for c in range(9):
            if g[r][c] == ".":
                empty.append((r, c))
            else:
                d = g[r][c]
                rows[r].add(d); cols[c].add(d); boxes[r // 3 * 3 + c // 3].add(d)
    def go():
        if not empty:
            return True
        # most constrained cell first
        best = min(range(len(empty)), key=lambda k: 9 - len(rows[empty[k][0]] | cols[empty[k][1]] | boxes[empty[k][0] // 3 * 3 + empty[k][1] // 3]))
        empty[best], empty[-1] = empty[-1], empty[best]
        r, c = empty.pop()
        b = r // 3 * 3 + c // 3
        for d in "123456789":
            if d not in rows[r] and d not in cols[c] and d not in boxes[b]:
                g[r][c] = d; rows[r].add(d); cols[c].add(d); boxes[b].add(d)
                if go():
                    return True
                g[r][c] = "."; rows[r].discard(d); cols[c].discard(d); boxes[b].discard(d)
        empty.append((r, c))
        return False
    return ["".join(r) for r in g] if go() else None

def valid_solution(sol, puzzle):
    ok_given = all(p == "." or p == s for pr, sr in zip(puzzle, sol) for p, s in zip(pr, sr))
    units = [sol[r] for r in range(9)] + ["".join(sol[r][c] for r in range(9)) for c in range(9)]
    units += ["".join(sol[r][c] for r in range(br, br + 3) for c in range(bc, bc + 3)) for br in (0, 3, 6) for bc in (0, 3, 6)]
    return ok_given and all(sorted(u) == list("123456789") for u in units)

def word_search(grid, word):
    R, C = len(grid), len(grid[0])
    def go(r, c, i):
        if i == len(word):
            return True
        if not (0 <= r < R and 0 <= c < C) or grid[r][c] != word[i]:
            return False
        saved, grid[r][c] = grid[r][c], "#"          # mark visited in place
        found = any(go(r + dr, c + dc, i + 1) for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        grid[r][c] = saved                           # un-choose
        return found
    return any(go(r, c, 0) for r in range(R) for c in range(C))

print("N-Queens solutions n=1..10:", [n_queens(n) for n in range(1, 11)])
hard = ["8........", "..36.....", ".7..9.2..", ".5...7...", "....457..", "...1...3.", "..1....68", "..85...1.", ".9....4.."]
t = time.perf_counter()
sol = solve_sudoku(hard)
print(f"hard sudoku solved: {valid_solution(sol, hard)} in {(time.perf_counter() - t) * 1000:.0f} ms")
grid = [list("ABCE"), list("SFCS"), list("ADEE")]
print(examples(lambda w: word_search(grid, w), [(("ABCCED",), True), (("SEE",), True), (("ABCB",), False)]))
