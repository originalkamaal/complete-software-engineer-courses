# file: partition/partition.py
import random
import time
from check import stress

def can_partition(nums, k):
    total = sum(nums)
    if total % k:
        return False
    target = total // k
    nums = sorted(nums, reverse=True)
    if nums and nums[0] > target:
        return False
    buckets = [0] * k
    def go(i):
        if i == len(nums):
            return True                          # all placed; sums must all be target
        tried = set()
        for b in range(k):
            if buckets[b] in tried or buckets[b] + nums[i] > target:
                continue                         # symmetry: same sum means same subtree
            tried.add(buckets[b])
            buckets[b] += nums[i]
            if go(i + 1):
                return True
            buckets[b] -= nums[i]
        return False
    return go(0)

def brute(nums, k):                              # assign each item a label 0..k-1
    total = sum(nums)
    if total % k:
        return False
    target = total // k
    def go(i, sums):
        if i == len(nums):
            return all(s == target for s in sums)
        for b in range(k):
            sums[b] += nums[i]
            if go(i + 1, sums):
                sums[b] -= nums[i]
                return True
            sums[b] -= nums[i]
        return False
    return go(0, [0] * k)

print(stress(can_partition, brute, lambda rng: ([rng.randint(1, 6) for _ in range(rng.randint(1, 7))], rng.randint(1, 4)), trials=800))
def yes_instance(rng, k, per, target):           # k groups of `per` items, each summing to target
    nums = []
    for _ in range(k):
        cuts = sorted(rng.sample(range(1, target), per - 1))
        nums += [b - a for a, b in zip([0] + cuts, cuts + [target])]
    rng.shuffle(nums)
    return nums

rng = random.Random(5)
for k in (2, 4, 8):
    for label, nums in (("planted  ", yes_instance(rng, k, 16 // k, 10_000)),
                        ("perturbed", (lambda v: v[:-1] + [v[-1] + k])(yes_instance(rng, k, 16 // k, 10_000)))):
        t = time.perf_counter()
        r = can_partition(nums, k)
        print(f"n=16, k={k}, {label}: {r} in {(time.perf_counter() - t) * 1000:.1f} ms")
