# file: pal_partition.py
from itertools import combinations
from check import stress

def partitions(s):
    n = len(s)
    is_pal = [[False] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):
        for j in range(i, n):
            is_pal[i][j] = s[i] == s[j] and (j - i < 2 or is_pal[i + 1][j - 1])
    out, path = [], []
    def go(i):
        if i == n:
            out.append(list(path))
            return
        for j in range(i, n):
            if is_pal[i][j]:                         # prune: only palindromic prefixes
                path.append(s[i:j + 1])
                go(j + 1)
                path.pop()
    go(0)
    return out

def brute(s):
    res = []
    for k in range(len(s)):
        for cuts in combinations(range(1, len(s)), k):
            bounds = (0,) + cuts + (len(s),)
            parts = [s[a:b] for a, b in zip(bounds, bounds[1:])]
            if all(p == p[::-1] for p in parts):
                res.append(parts)
    return res

print(partitions("aab"))
print(stress(lambda s: sorted(partitions(s)), lambda s: sorted(brute(s)),
             lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(1, 8))),)))
