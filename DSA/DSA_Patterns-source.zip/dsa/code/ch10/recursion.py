# file: recursion.py
import sys
from check import stress, rand_list, examples

def power(x, n):                                   # x**n in O(log n) multiplications
    if n == 0:
        return 1
    half = power(x, n // 2)                        # trust: correct for n // 2
    return half * half * (x if n % 2 else 1)

def flatten(nested):                               # contract: list of all integers, in order
    out = []
    for item in nested:
        if isinstance(item, list):
            out.extend(flatten(item))              # trust it for the smaller list
        else:
            out.append(item)
    return out

def hanoi(n, src="A", dst="C", via="B", moves=None):
    """Move n disks from src to dst. Contract: returns the list of moves."""
    moves = [] if moves is None else moves
    if n:
        hanoi(n - 1, src, via, dst, moves)         # clear the top n-1 out of the way
        moves.append((src, dst))                   # move the largest disk
        hanoi(n - 1, via, dst, src, moves)         # put the n-1 back on top
    return moves

def check_hanoi(n):
    pegs = {"A": list(range(n, 0, -1)), "B": [], "C": []}
    for s, d in hanoi(n):
        disk = pegs[s].pop()
        assert not pegs[d] or pegs[d][-1] > disk   # never a larger disk on a smaller one
        pegs[d].append(disk)
    return pegs["C"] == list(range(n, 0, -1)), len(hanoi(n))

print(stress(power, lambda x, n: x ** n, lambda rng: (rng.randint(-3, 3), rng.randint(0, 20))))
print(examples(flatten, [(([1, [2, [3, [4]], 5], [], [[6]]],), [1, 2, 3, 4, 5, 6])]))
print([check_hanoi(n) for n in range(1, 8)])
print("default recursion limit:", sys.getrecursionlimit())
