# file: enumerate_.py
from itertools import combinations, permutations
from check import stress, rand_list

def subsets(a):
    out, path = [], []
    def go(i):
        if i == len(a):
            out.append(path[:])                  # copy! path keeps changing
            return
        go(i + 1)                                # skip a[i]
        path.append(a[i]); go(i + 1); path.pop() # take a[i]
    go(0)
    return out

def combine(n, k):                               # all k-subsets of 1..n
    out, path = [], []
    def go(start):
        if len(path) == k:
            out.append(path[:])
            return
        for x in range(start, n - (k - len(path)) + 2):   # prune: leave room for the rest
            path.append(x); go(x + 1); path.pop()
    go(1)
    return out

def permute(a):
    out, path, used = [], [], [False] * len(a)
    def go():
        if len(path) == len(a):
            out.append(path[:])
            return
        for i, x in enumerate(a):
            if not used[i]:
                used[i] = True; path.append(x)
                go()
                path.pop(); used[i] = False
    go()
    return out

print(stress(lambda a: sorted(subsets(a)), lambda a: sorted(list(c) for r in range(len(a) + 1) for c in combinations(a, r)),
             lambda rng: (rand_list(rng, 0, 9, 6),), trials=500))
print(stress(combine, lambda n, k: [list(c) for c in combinations(range(1, n + 1), k)],
             lambda rng: ((n := rng.randint(0, 7)), rng.randint(0, n)), trials=500))
print(stress(lambda a: sorted(permute(a)), lambda a: sorted(list(p) for p in permutations(a)), lambda rng: (rand_list(rng, 0, 9, 5),), trials=500))
print(len(subsets(list(range(10)))), len(combine(10, 3)), len(permute(list(range(6)))))
