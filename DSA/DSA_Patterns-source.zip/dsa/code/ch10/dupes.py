# file: dupes.py
from itertools import combinations, permutations
from check import stress, rand_list

def subsets_with_dup(a):
    a, out, path = sorted(a), [], []
    def go(start):
        out.append(path[:])                       # every node is a subset
        for i in range(start, len(a)):
            if i > start and a[i] == a[i - 1]:    # same value already tried at this depth
                continue
            path.append(a[i]); go(i + 1); path.pop()
    go(0)
    return out

def permute_unique(a):
    a, out, path, used = sorted(a), [], [], [False] * len(a)
    def go():
        if len(path) == len(a):
            out.append(path[:])
            return
        for i in range(len(a)):
            if used[i] or (i and a[i] == a[i - 1] and not used[i - 1]):
                continue                          # use equal values only in left-to-right order
            used[i] = True; path.append(a[i]); go(); path.pop(); used[i] = False
    go()
    return out

def combination_sum(cands, target):               # each candidate unlimited times
    cands, out, path = sorted(set(cands)), [], []
    def go(start, remain):
        if remain == 0:
            out.append(path[:])
            return
        for i in range(start, len(cands)):
            if cands[i] > remain:
                break                             # sorted: every later candidate is bigger too
            path.append(cands[i]); go(i, remain - cands[i]); path.pop()   # i, not i+1: reuse allowed
    go(0, target)
    return out

def combination_sum_brute(cands, target):
    cands = sorted(set(cands))
    out = []
    def go(i, remain, path):
        if remain == 0:
            out.append(path); return
        if i == len(cands) or remain < 0:
            return
        go(i, remain - cands[i], path + [cands[i]])
        go(i + 1, remain, path)
    go(0, target, [])
    return sorted(out)

print(stress(lambda a: sorted(subsets_with_dup(a)), lambda a: sorted(list(c) for c in set(c for r in range(len(a) + 1) for c in combinations(sorted(a), r))),
             lambda rng: (rand_list(rng, 1, 3, 7),), trials=500))
print(stress(lambda a: sorted(permute_unique(a)), lambda a: sorted(list(p) for p in set(permutations(a))),
             lambda rng: (rand_list(rng, 1, 3, 6),), trials=500))
print(stress(lambda c, t: sorted(combination_sum(c, t)), combination_sum_brute,
             lambda rng: (rand_list(rng, 1, 8, 5, 1), rng.randint(1, 15)), trials=500))
