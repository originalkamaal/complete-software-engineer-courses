# file: count_nodes.py
import math

def count_nodes_subsets(n):                       # nodes visited by the include/skip recursion
    return 2 ** (n + 1) - 1

def count_nodes_perms(n):                         # sum over depth d of n!/(n-d)!
    return sum(math.perm(n, d) for d in range(n + 1))

for n in (10, 15, 20):
    print(f"subsets n={n}: {count_nodes_subsets(n):>12,} nodes")
for n in (8, 10, 12):
    print(f"perms   n={n}: {count_nodes_perms(n):>12,} nodes")
