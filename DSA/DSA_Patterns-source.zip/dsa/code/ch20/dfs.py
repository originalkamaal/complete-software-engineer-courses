# file: dfs.py
from check import stress
from represent import adjacency

def components(adj):
    comp, c = [-1] * len(adj), 0
    for s in range(len(adj)):
        if comp[s] == -1:
            comp[s] = c
            stack = [s]
            while stack:
                u = stack.pop()
                for v in adj[u]:
                    if comp[v] == -1:
                        comp[v] = c; stack.append(v)
            c += 1
    return c, comp

def num_islands(grid):
    g = [list(row) for row in grid]
    R, C, count = len(g), len(g[0]), 0
    for r in range(R):
        for c in range(C):
            if g[r][c] == "1":
                count += 1
                g[r][c] = "0"
                stack = [(r, c)]
                while stack:
                    x, y = stack.pop()
                    for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                        if 0 <= nx < R and 0 <= ny < C and g[nx][ny] == "1":
                            g[nx][ny] = "0"; stack.append((nx, ny))
    return count

def has_cycle_undirected(n, edges):
    adj = [[] for _ in range(n)]
    for i, (u, v) in enumerate(edges):                # edge ids: parallel edges and self-loops count
        adj[u].append((v, i)); adj[v].append((u, i))
    seen = [False] * n
    for s in range(n):
        if seen[s]:
            continue
        seen[s] = True
        stack = [(s, -1)]
        while stack:
            u, via = stack.pop()
            for v, eid in adj[u]:
                if eid == via:
                    continue                          # do not go back along the same edge
                if seen[v]:
                    return True
                seen[v] = True
                stack.append((v, eid))
    return False

def cycle_brute(n, edges):                            # a forest has exactly V - components edges
    c, _ = components(adjacency(n, edges))
    return len(edges) > n - c

def islands_brute(grid):
    from dsu import DSU
    R, C = len(grid), len(grid[0])
    d = DSU(R * C)
    for r in range(R):
        for c in range(C):
            if grid[r][c] == "1":
                if r + 1 < R and grid[r + 1][c] == "1": d.union(r * C + c, (r + 1) * C + c)
                if c + 1 < C and grid[r][c + 1] == "1": d.union(r * C + c, r * C + c + 1)
    return len({d.find(r * C + c) for r in range(R) for c in range(C) if grid[r][c] == "1"})

gen = lambda rng: ((n := rng.randint(1, 8)), [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 9))])
print(stress(has_cycle_undirected, cycle_brute, gen))
def gen_grid(rng):
    R, C = rng.randint(1, 6), rng.randint(1, 6)
    return (["".join(rng.choice("01") for _ in range(C)) for _ in range(R)],)
print(stress(num_islands, islands_brute, gen_grid))
