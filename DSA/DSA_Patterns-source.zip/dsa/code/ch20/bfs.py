# file: bfs.py
from collections import deque
from check import stress
from represent import adjacency

def bfs_dist(adj, s):
    dist = [-1] * len(adj)
    dist[s] = 0
    q = deque([s])
    while q:
        u = q.popleft()
        for v in adj[u]:
            if dist[v] == -1:                         # mark on enqueue
                dist[v] = dist[u] + 1
                q.append(v)
    return dist

def shortest_path(adj, s, t):                         # reconstruct with parent pointers
    parent = {s: None}
    q = deque([s])
    while q:
        u = q.popleft()
        if u == t:
            path = []
            while u is not None:
                path.append(u); u = parent[u]
            return path[::-1]
        for v in adj[u]:
            if v not in parent:
                parent[v] = u; q.append(v)
    return None

def rotting_oranges(grid):                            # 2 = rotten, 1 = fresh: minutes until all rot, or -1
    R, C = len(grid), len(grid[0])
    q = deque((r, c) for r in range(R) for c in range(C) if grid[r][c] == 2)   # all sources at once
    fresh = sum(row.count(1) for row in grid)
    minutes, g = 0, [row[:] for row in grid]
    while q and fresh:
        for _ in range(len(q)):
            r, c = q.popleft()
            for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if 0 <= nr < R and 0 <= nc < C and g[nr][nc] == 1:
                    g[nr][nc] = 2; fresh -= 1; q.append((nr, nc))
        minutes += 1
    return -1 if fresh else minutes

def bellman_unit(n, edges, s):                        # brute force: relax n times
    INF = float("inf")
    d = [INF] * n; d[s] = 0
    for _ in range(n):
        for u, v in edges:
            d[v] = min(d[v], d[u] + 1); d[u] = min(d[u], d[v] + 1)
    return [x if x < INF else -1 for x in d]

def rot_brute(grid):                                  # simulate minute by minute
    g, t = [row[:] for row in grid], 0
    while True:
        new = [(r, c) for r, row in enumerate(g) for c, x in enumerate(row) if x == 1 and
               any(0 <= r + a < len(g) and 0 <= c + b < len(row) and g[r + a][c + b] == 2 for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1)))]
        if not new:
            return t if not any(1 in row for row in g) else -1
        for r, c in new:
            g[r][c] = 2
        t += 1

def gen_graph(rng):
    n = rng.randint(1, 8)
    return (n, [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 10))], rng.randrange(n))

print(stress(lambda n, e, s: bfs_dist(adjacency(n, e), s), bellman_unit, gen_graph))
def path_ok(n, e, s):
    adj, d = adjacency(n, e), bfs_dist(adjacency(n, e), s)
    t = n - 1
    p = shortest_path(adj, s, t)
    if p is None:
        return d[t] == -1
    return p[0] == s and p[-1] == t and len(p) - 1 == d[t] and all(b in adj[a] for a, b in zip(p, p[1:]))
print(stress(path_ok, lambda n, e, s: True, gen_graph))
def gen_oranges(rng):
    R, C = rng.randint(1, 5), rng.randint(1, 5)
    return ([[rng.choice([0, 1, 1, 2]) for _ in range(C)] for _ in range(R)],)
print(stress(rotting_oranges, rot_brute, gen_oranges))
