# file: represent.py
from collections import defaultdict

def adjacency(n, edges, directed=False):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        if not directed:
            adj[v].append(u)
    return adj

def grid_neighbours(grid, r, c):
    R, C = len(grid), len(grid[0])
    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < R and 0 <= nc < C and grid[nr][nc] != "#":
            yield nr, nc

def word_neighbours(word, words):                    # implicit graph via wildcard buckets
    buckets = defaultdict(list)
    for w in words:
        for i in range(len(w)):
            buckets[w[:i] + "*" + w[i + 1:]].append(w)
    return sorted({x for i in range(len(word)) for x in buckets[word[:i] + "*" + word[i + 1:]] if x != word})

if __name__ == "__main__":
  print(adjacency(4, [(0, 1), (1, 2), (2, 0), (2, 3)]))
  print(list(grid_neighbours(["..#", "...", "#.."], 1, 1)))
  print(word_neighbours("hot", ["hot", "dot", "dog", "lot", "log", "cog", "hit"]))
