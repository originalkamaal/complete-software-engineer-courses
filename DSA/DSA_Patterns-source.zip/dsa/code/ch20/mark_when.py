# file: mark_when.py
from collections import deque

def pushes(n, mark_on_enqueue):                       # BFS on the complete graph K_n
    seen, q, count = {0} if mark_on_enqueue else set(), deque([0]), 1
    while q:
        u = q.popleft()
        if not mark_on_enqueue:
            if u in seen:
                continue
            seen.add(u)
        for v in range(n):
            if v != u and v not in seen:
                if mark_on_enqueue:
                    seen.add(v)
                q.append(v); count += 1
    return count

for n in (100, 1000):
    print(f"K_{n}: queue pushes, mark on enqueue = {pushes(n, True):,}; mark on dequeue = {pushes(n, False):,}")
