# file: bipartite.py
from collections import deque
from itertools import product
from check import stress

def is_bipartite(n, edges):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v); adj[v].append(u)
    color = [-1] * n
    for s in range(n):
        if color[s] != -1:
            continue
        color[s] = 0
        q = deque([s])
        while q:
            u = q.popleft()
            for v in adj[u]:
                if color[v] == -1:
                    color[v] = color[u] ^ 1; q.append(v)
                elif color[v] == color[u]:
                    return False
    return True

def brute(n, edges):
    return any(all(c[u] != c[v] for u, v in edges) for c in product((0, 1), repeat=n))

print(stress(is_bipartite, brute, lambda rng: ((n := rng.randint(1, 8)), [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 8))])))
