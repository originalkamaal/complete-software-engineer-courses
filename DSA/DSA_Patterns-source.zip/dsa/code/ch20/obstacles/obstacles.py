# file: obstacles/obstacles.py
import random
import time
from collections import deque
from check import stress

def shortest_with_removals(grid, k):
    R, C = len(grid), len(grid[0])
    if k >= R + C - 2:
        return R + C - 2
    best_left = [[-1] * C for _ in range(R)]            # most removals left on arrival so far
    best_left[0][0] = k
    q, steps = deque([(0, 0, k)]), 0
    while q:
        for _ in range(len(q)):
            r, c, left = q.popleft()
            if (r, c) == (R - 1, C - 1):
                return steps
            for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if 0 <= nr < R and 0 <= nc < C:
                    nl = left - grid[nr][nc]
                    if nl > best_left[nr][nc]:          # strictly better budget than any earlier visit
                        best_left[nr][nc] = nl
                        q.append((nr, nc, nl))
        steps += 1
    return -1

def brute(grid, k):                                     # plain BFS over full states, no pruning
    R, C = len(grid), len(grid[0])
    dist = {(0, 0, k): 0}
    q = deque([(0, 0, k)])
    while q:
        r, c, left = q.popleft()
        if (r, c) == (R - 1, C - 1):
            return dist[(r, c, left)]
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < R and 0 <= nc < C:
                s = (nr, nc, left - grid[nr][nc])
                if s[2] >= 0 and s not in dist:
                    dist[s] = dist[(r, c, left)] + 1; q.append(s)
    return -1

def gen(rng):
    R, C = rng.randint(1, 5), rng.randint(1, 5)
    g = [[int(rng.random() < 0.4) for _ in range(C)] for _ in range(R)]
    g[0][0] = 0
    return (g, rng.randint(0, 3))

print(stress(shortest_with_removals, brute, gen))
rng = random.Random(14)
R = C = 300
g = [[int(rng.random() < 0.3) for _ in range(C)] for _ in range(R)]
for r, c in ((0, 0), (0, 1), (1, 0), (R - 1, C - 2), (R - 2, C - 1)):
    g[r][c] = 0                                         # keep the corners open
for k in (0, 5, 40):
    t = time.perf_counter()
    a = shortest_with_removals(g, k)
    t1 = time.perf_counter() - t
    t = time.perf_counter()
    b = brute(g, k)
    t2 = time.perf_counter() - t
    print(f"300x300, k={k:>2}: {a} steps; dominance-pruned {t1 * 1000:5.0f} ms, full state BFS {t2 * 1000:6.0f} ms, agree: {a == b}")
