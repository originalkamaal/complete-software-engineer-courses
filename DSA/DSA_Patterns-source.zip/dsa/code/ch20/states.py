# file: states.py
from collections import deque
from check import stress, examples

def open_lock(deadends, target):                       # 4 wheels, each move turns one wheel ±1
    dead = set(deadends)
    if "0000" in dead:
        return -1
    dist = {"0000": 0}
    q = deque(["0000"])
    while q:
        s = q.popleft()
        if s == target:
            return dist[s]
        for i in range(4):
            d = int(s[i])
            for nd in ((d + 1) % 10, (d - 1) % 10):
                t = s[:i] + str(nd) + s[i + 1:]
                if t not in dist and t not in dead:
                    dist[t] = dist[s] + 1
                    q.append(t)
    return -1

def word_ladder(begin, end, words):                    # number of words in the shortest chain, or 0
    from represent import word_neighbours
    words = set(words) | {begin}
    if end not in words:
        return 0
    dist, q = {begin: 1}, deque([begin])
    while q:
        w = q.popleft()
        if w == end:
            return dist[w]
        for x in word_neighbours(w, words):
            if x not in dist:
                dist[x] = dist[w] + 1; q.append(x)
    return 0

print(examples(open_lock, [((["0201", "0101", "0102", "1212", "2002"], "0202"), 6), ((["8888"], "0009"), 1),
                           ((["8887", "8889", "8878", "8898", "8788", "8988", "7888", "9888"], "8888"), -1)]))
print(examples(word_ladder, [(("hit", "cog", ["hot", "dot", "dog", "lot", "log", "cog"]), 5), (("hit", "cog", ["hot", "dot", "dog", "lot", "log"]), 0)]))
