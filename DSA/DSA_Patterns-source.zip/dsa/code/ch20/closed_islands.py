# file: closed_islands.py
from check import stress

def closed_islands(grid):
    g = [row[:] for row in grid]
    R, C = len(g), len(g[0])
    def sink(r, c):
        stack = [(r, c)]
        g[r][c] = 1
        while stack:
            r, c = stack.pop()
            for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if 0 <= nr < R and 0 <= nc < C and g[nr][nc] == 0:
                    g[nr][nc] = 1                      # mark when pushed
                    stack.append((nr, nc))
    for r in range(R):
        for c in range(C):
            if (r in (0, R - 1) or c in (0, C - 1)) and g[r][c] == 0:
                sink(r, c)                             # land is 0 here; touches the border
    count = 0
    for r in range(R):
        for c in range(C):
            if g[r][c] == 0:
                count += 1
                sink(r, c)
    return count

def brute(grid):
    R, C = len(grid), len(grid[0])
    seen, count = set(), 0
    for r in range(R):
        for c in range(C):
            if grid[r][c] == 0 and (r, c) not in seen:
                comp, todo = [], [(r, c)]
                seen.add((r, c))
                while todo:
                    cell = todo.pop()
                    comp.append(cell)
                    for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        n = (cell[0] + d[0], cell[1] + d[1])
                        if 0 <= n[0] < R and 0 <= n[1] < C and grid[n[0]][n[1]] == 0 and n not in seen:
                            seen.add(n); todo.append(n)
                count += all(0 < a < R - 1 and 0 < b < C - 1 for a, b in comp)
    return count

def gen(rng):
    R, C = rng.randint(1, 6), rng.randint(1, 6)
    return ([[rng.randint(0, 1) for _ in range(C)] for _ in range(R)],)

print(closed_islands([[1, 1, 1, 1], [1, 0, 0, 1], [1, 1, 1, 1], [0, 1, 0, 1]]))
print(stress(closed_islands, brute, gen))
