# file: first_at_least.py
from check import stress, rand_list

class MaxTree:
    def __init__(self, a):
        self.n = 1
        while self.n < len(a):
            self.n *= 2
        self.t = [float("-inf")] * (2 * self.n)
        self.t[self.n:self.n + len(a)] = a
        for i in range(self.n - 1, 0, -1):
            self.t[i] = max(self.t[2 * i], self.t[2 * i + 1])

    def first_at_least(self, l, x, node=1, lo=0, hi=None):
        if hi is None:
            hi = self.n
        if hi <= l or self.t[node] < x:
            return -1                                   # entirely left of l, or nothing big enough
        if hi - lo == 1:
            return lo
        mid = (lo + hi) // 2
        r = self.first_at_least(l, x, 2 * node, lo, mid)
        return r if r != -1 else self.first_at_least(l, x, 2 * node + 1, mid, hi)

def run(a, l, x):
    return MaxTree(a).first_at_least(l, x)

def brute(a, l, x):
    return next((i for i in range(l, len(a)) if a[i] >= x), -1)

print(run([1, 5, 2, 8, 3], 2, 4), run([1, 5, 2, 8, 3], 4, 4))
print(stress(run, brute, lambda rng: ((a := rand_list(rng, 0, 9, min_len=1)), rng.randint(0, len(a) - 1), rng.randint(0, 10))))
