# file: max_subarray_range.py
from check import stress, rand_list
from segtree import SegTree

NEG = float("-inf")
IDENT = (0, NEG, NEG, NEG)                              # empty range

def leaf(x):
    return (x, x, x, x)

def combine(L, R):
    if L is IDENT: return R
    if R is IDENT: return L
    return (L[0] + R[0], max(L[1], L[0] + R[1]), max(R[2], R[0] + L[2]), max(L[3], R[3], L[2] + R[1]))

def run(a, ops):
    st, out = SegTree([leaf(x) for x in a], combine, IDENT), []
    for kind, x, y in ops:
        if kind == "set":
            st.update(x, leaf(y))
        else:
            out.append(st.query(x, y)[3])
    return out

def brute(a, ops):
    a, out = a[:], []
    for kind, x, y in ops:
        if kind == "set":
            a[x] = y
        else:
            out.append(max(sum(a[i:j]) for i in range(x, y) for j in range(i + 1, y + 1)))
    return out

def gen(rng):
    a = rand_list(rng, -6, 6, 12, 1)
    ops = []
    for _ in range(12):
        if rng.random() < 0.4:
            ops.append(("set", rng.randrange(len(a)), rng.randint(-6, 6)))
        else:
            l = rng.randrange(len(a)); ops.append(("q", l, rng.randint(l + 1, len(a))))
    return (a, ops)

print(stress(run, brute, gen))
