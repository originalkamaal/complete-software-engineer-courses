# file: lazy_test.py
from check import stress, rand_list
from lazy import LazySegTree

def run(a, ops):
    st, out = LazySegTree(a), []
    for kind, l, r, v in ops:
        if kind == "add":
            st.add(l, r, v)
        else:
            out.append(st.query(l, r))
    return out

def brute(a, ops):
    a, out = a[:], []
    for kind, l, r, v in ops:
        if kind == "add":
            for i in range(l, r):
                a[i] += v
        else:
            out.append((sum(a[l:r]), min(a[l:r])))
    return out

def gen(rng):
    a = rand_list(rng, -5, 5, 12, 1)
    ops = []
    for _ in range(15):
        l = rng.randrange(len(a)); r = rng.randint(l + 1, len(a))
        ops.append((rng.choice(["add", "q"]), l, r, rng.randint(-3, 3)))
    return (a, ops)

print(stress(run, brute, gen))
