# file: rect_union/rect_union.py
import random
import time
from check import stress

def union_area(rects):                                    # rects: (x1, y1, x2, y2), x1<x2, y1<y2
    if not rects:
        return 0
    ys = sorted({y for _, y1, _, y2 in rects for y in (y1, y2)})
    idx = {y: i for i, y in enumerate(ys)}
    m = len(ys) - 1                                       # elementary y-segments
    cnt, length = [0] * (4 * m), [0] * (4 * m)
    def update(l, r, v, node=1, lo=0, hi=m):
        if r <= lo or hi <= l:
            return
        if l <= lo and hi <= r:
            cnt[node] += v
        else:
            mid = (lo + hi) // 2
            update(l, r, v, 2 * node, lo, mid)
            update(l, r, v, 2 * node + 1, mid, hi)
        if cnt[node]:
            length[node] = ys[hi] - ys[lo]                # fully covered
        elif hi - lo == 1:
            length[node] = 0
        else:
            length[node] = length[2 * node] + length[2 * node + 1]
    events = sorted([(x1, 1, y1, y2) for x1, y1, x2, y2 in rects] + [(x2, -1, y1, y2) for x1, y1, x2, y2 in rects])
    area, prev_x = 0, events[0][0]
    for x, v, y1, y2 in events:
        area += length[1] * (x - prev_x)
        update(idx[y1], idx[y2], v)
        prev_x = x
    return area

def brute(rects):                                         # unit cells on a small grid
    cells = set()
    for x1, y1, x2, y2 in rects:
        cells.update((x, y) for x in range(x1, x2) for y in range(y1, y2))
    return len(cells)

def gen(rng):
    rs = []
    for _ in range(rng.randint(0, 6)):
        x1, y1 = rng.randint(0, 8), rng.randint(0, 8)
        rs.append((x1, y1, x1 + rng.randint(1, 5), y1 + rng.randint(1, 5)))
    return (rs,)

print(stress(union_area, brute, gen))
rng = random.Random(12)
rects = []
for _ in range(20_000):
    x, y = rng.randint(0, 10**9), rng.randint(0, 10**9)
    rects.append((x, y, x + rng.randint(1, 10**7), y + rng.randint(1, 10**7)))
t = time.perf_counter()
a = union_area(rects)
print(f"20,000 rectangles: union area {a:,} ({a / 1e18:.1%} of the 10^9 x 10^9 square) in {(time.perf_counter() - t):.1f} s")
