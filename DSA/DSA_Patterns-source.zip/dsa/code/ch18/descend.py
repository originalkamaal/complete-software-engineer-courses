# file: descend.py
from itertools import accumulate
from check import stress, rand_list

class SumTree:                                          # power-of-two size: a true binary tree
    def __init__(self, data):
        self.size = 1
        while self.size < len(data):
            self.size *= 2
        self.t = [0] * (2 * self.size)
        self.t[self.size:self.size + len(data)] = data
        for i in range(self.size - 1, 0, -1):
            self.t[i] = self.t[2 * i] + self.t[2 * i + 1]
    def update(self, i, v):
        i += self.size
        self.t[i] = v
        while i > 1:
            i //= 2
            self.t[i] = self.t[2 * i] + self.t[2 * i + 1]
    def first_prefix_at_least(self, k):                 # smallest i with sum(data[:i+1]) >= k, or -1
        if self.t[1] < k:
            return -1
        i = 1
        while i < self.size:
            if self.t[2 * i] >= k:
                i = 2 * i
            else:
                k -= self.t[2 * i]
                i = 2 * i + 1
        return i - self.size

def run(a, ops):
    st, out = SumTree(a), []
    for kind, x, y in ops:
        if kind == "set":
            st.update(x % len(a), y)
        else:
            out.append(st.first_prefix_at_least(x))
    return out

def brute(a, ops):
    a, out = a[:], []
    for kind, x, y in ops:
        if kind == "set":
            a[x % len(a)] = y
        else:
            out.append(next((i for i, p in enumerate(accumulate(a)) if p >= x), -1))
    return out

gen = lambda rng: (rand_list(rng, 0, 5, 12, 1), [(rng.choice(["set", "q"]), rng.randint(1, 30), rng.randint(0, 5)) for _ in range(15)])
print(stress(run, brute, gen))
