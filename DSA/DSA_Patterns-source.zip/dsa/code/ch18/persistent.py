# file: persistent.py
import bisect
from check import stress, rand_list

class PersistentCount:
    """Count-tree over m values; version v = counts of a[:v]. Nodes in flat lists."""
    def __init__(self, ranks, m):
        self.m = m
        self.left, self.right, self.cnt = [0], [0], [0]   # node 0 = shared empty tree
        self.roots = [0]
        for r in ranks:
            self.roots.append(self._insert(self.roots[-1], 0, m, r))
    def _new(self, l, r, c):
        self.left.append(l); self.right.append(r); self.cnt.append(c)
        return len(self.cnt) - 1
    def _insert(self, node, lo, hi, pos):              # returns a NEW node; old one untouched
        if hi - lo == 1:
            return self._new(0, 0, self.cnt[node] + 1)
        mid = (lo + hi) // 2
        if pos < mid:
            return self._new(self._insert(self.left[node], lo, mid, pos), self.right[node], self.cnt[node] + 1)
        return self._new(self.left[node], self._insert(self.right[node], mid, hi, pos), self.cnt[node] + 1)
    def kth(self, l, r, k):                            # k-th smallest rank (0-based k) in a[l:r]
        u, v, lo, hi = self.roots[l], self.roots[r], 0, self.m
        while hi - lo > 1:
            mid = (lo + hi) // 2
            left_count = self.cnt[self.left[v]] - self.cnt[self.left[u]]
            if k < left_count:
                u, v, hi = self.left[u], self.left[v], mid
            else:
                k -= left_count
                u, v, lo = self.right[u], self.right[v], mid
        return lo

def kth_in_ranges(a, queries):
    vals = sorted(set(a))
    pt = PersistentCount([bisect.bisect_left(vals, x) for x in a], len(vals))
    return [vals[pt.kth(l, r, k)] for l, r, k in queries]

def gen(rng):
    a = rand_list(rng, -9, 9, 14, 1)
    qs = []
    for _ in range(8):
        l = rng.randrange(len(a)); r = rng.randint(l + 1, len(a))
        qs.append((l, r, rng.randrange(r - l)))
    return (a, qs)

print(stress(kth_in_ranges, lambda a, qs: [sorted(a[l:r])[k] for l, r, k in qs], gen))
