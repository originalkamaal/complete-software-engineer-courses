# file: segtree_test.py
import math
import operator
from functools import reduce
from check import stress, rand_list
from segtree import SegTree

def run(data, ops, op, e):
    st, a, out = SegTree(data, op, e), data[:], []
    for kind, x, y in ops:
        if kind == "set":
            st.update(x % len(a), y)
        else:
            l, r = sorted((x % (len(a) + 1), y % (len(a) + 1)))
            out.append(st.query(l, r))
    return out

def brute(data, ops, op, e):
    a, out = data[:], []
    for kind, x, y in ops:
        if kind == "set":
            a[x % len(a)] = y
        else:
            l, r = sorted((x % (len(a) + 1), y % (len(a) + 1)))
            out.append(reduce(op, a[l:r], e))
    return out

def gen(rng):
    data = rand_list(rng, -9, 9, 12, 1)
    return (data, [(rng.choice(["set", "q", "q"]), rng.randint(0, 20), rng.randint(-9, 20)) for _ in range(15)])

for name, op, e in (("sum", operator.add, 0), ("min", min, math.inf), ("max", max, -math.inf), ("gcd", math.gcd, 0)):
    print(name, stress(lambda d, o: run(d, o, op, e), lambda d, o: brute(d, o, op, e), gen))
