# file: noncommutative.py
import operator
from check import stress
from segtree import SegTree

def concat_queries(chars, ranges):
    st = SegTree(chars, operator.add, "")
    return [st.query(l, r) for l, r in ranges]

def gen(rng):
    s = [rng.choice("abc") for _ in range(rng.randint(1, 13))]     # lengths that are not powers of two
    return (s, [tuple(sorted((rng.randint(0, len(s)), rng.randint(0, len(s))))) for _ in range(6)])

print(stress(concat_queries, lambda s, rs: ["".join(s[l:r]) for l, r in rs], gen))
