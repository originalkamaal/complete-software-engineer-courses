# file: tiling_dp.py
from functools import cache
from check import stress

def domino_tilings(R, C):
    """Count tilings of an R x C board with 1x2 dominoes; profile bit j = cell (r, j) already covered."""
    if C > R:
        R, C = C, R                                      # keep the profile narrow
    dp = {0: 1}
    for r in range(R):
        for c in range(C):
            ndp = {}
            for mask, ways in dp.items():
                bit = 1 << c
                if mask & bit:                           # already covered by a vertical domino from above
                    key = mask & ~bit
                    ndp[key] = ndp.get(key, 0) + ways
                    continue
                if r + 1 < R:                            # place a vertical domino: covers (r+1, c)
                    key = mask | bit
                    ndp[key] = ndp.get(key, 0) + ways
                if c + 1 < C and not mask & (bit << 1):  # place a horizontal domino: covers (r, c+1)
                    key = mask | (bit << 1)
                    ndp[key] = ndp.get(key, 0) + ways
            dp = ndp
    return dp.get(0, 0)

def brute(R, C):
    @cache
    def go(filled):                                       # filled: frozenset of covered cells
        free = next(((r, c) for r in range(R) for c in range(C) if (r, c) not in filled), None)
        if free is None:
            return 1
        r, c = free
        total = 0
        for dr, dc in ((0, 1), (1, 0)):
            o = (r + dr, c + dc)
            if o[0] < R and o[1] < C and o not in filled:
                total += go(filled | {free, o})
        return total
    return go(frozenset())

if __name__ == "__main__":
    print(stress(domino_tilings, brute, lambda rng: (rng.randint(1, 4), rng.randint(1, 4)), trials=300))
    print("2xn boards:", [domino_tilings(2, n) for n in range(1, 11)], "(Fibonacci)")
