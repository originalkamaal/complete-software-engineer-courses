# file: submask_dp.py
from functools import cache
from check import stress, rand_list

def min_partition_cost(vals, limit):
    """Split items into groups with sum <= limit; cost of a group = (max - min)^2; minimise total cost."""
    n = len(vals)
    INF = float("inf")
    cost = [INF] * (1 << n)
    for m in range(1, 1 << n):
        g = [vals[i] for i in range(n) if m >> i & 1]
        if sum(g) <= limit:
            cost[m] = (max(g) - min(g)) ** 2
    dp = [INF] * (1 << n)
    dp[0] = 0
    for mask in range(1, 1 << n):
        low = mask & -mask
        sub = mask
        while sub:
            if sub & low and cost[sub] + dp[mask ^ sub] < dp[mask]:
                dp[mask] = cost[sub] + dp[mask ^ sub]
            sub = (sub - 1) & mask
    return dp[-1]

def brute(vals, limit):                                   # all set partitions, recursively
    @cache
    def go(rest):
        if not rest:
            return 0
        first, others = rest[0], rest[1:]
        best = float("inf")
        n = len(others)
        for m in range(1 << n):                           # choose companions of `first`
            group = (first,) + tuple(others[i] for i in range(n) if m >> i & 1)
            if sum(group) <= limit:
                remaining = tuple(others[i] for i in range(n) if not m >> i & 1)
                best = min(best, (max(group) - min(group)) ** 2 + go(remaining))
        return best
    return go(tuple(vals))

print(stress(min_partition_cost, brute, lambda rng: (rand_list(rng, 1, 9, 7, 1), rng.randint(9, 20)), trials=500))
