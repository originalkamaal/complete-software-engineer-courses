# file: tilings/tilings.py
import math
import time
from decimal import Decimal, getcontext
from tiling_dp import domino_tilings

def kasteleyn(m, n):
    if (m * n) % 2:
        return 0
    getcontext().prec = 80                                     # enough digits to round exactly
    pi = Decimal("3.14159265358979323846264338327950288419716939937510582097494459230781640628620899")
    def cos(x):                                                # Taylor series in Decimal
        x = x % (2 * pi)
        term, total, k = Decimal(1), Decimal(1), 0
        while True:
            k += 2
            term *= -x * x / (k * (k - 1))
            if abs(term) < Decimal(10) ** -70:
                return total
            total += term
    prod = Decimal(1)
    for j in range(1, (m + 1) // 2 + 1):
        for k in range(1, (n + 1) // 2 + 1):
            prod *= 4 * cos(pi * j / (m + 1)) ** 2 + 4 * cos(pi * k / (n + 1)) ** 2
    return int(prod.to_integral_value())

t = time.perf_counter()
for m, n in ((2, 2), (4, 4), (6, 6), (8, 8), (10, 10), (12, 12), (7, 10), (9, 12)):
    dp = domino_tilings(m, n)
    print(f"{m:>2} x {n:<2}: {dp:>40,}   Kasteleyn agrees: {dp == kasteleyn(m, n)}")
print(f"[all eight boards, DP and formula: {(time.perf_counter() - t) * 1000:.0f} ms]")
