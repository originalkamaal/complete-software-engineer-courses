# file: bins.py
from check import stress, rand_list

def min_bins(items, cap):                                # minimum bins of capacity cap (each item <= cap)
    n = len(items)
    INF = (n + 1, 0)
    dp = [INF] * (1 << n)
    dp[0] = (1, 0)                                       # one open, empty bin
    for mask in range(1 << n):
        bins, fill = dp[mask]
        if (bins, fill) == INF:
            continue
        for i in range(n):
            if not mask >> i & 1:
                cand = (bins, fill + items[i]) if fill + items[i] <= cap else (bins + 1, items[i])
                nm = mask | 1 << i
                if cand < dp[nm]:
                    dp[nm] = cand
    return dp[-1][0] if n else 0

def brute(items, cap):                                   # try every assignment of items to bins 0..n-1
    from itertools import product
    n = len(items)
    best = n
    for assign in product(range(n), repeat=n):
        loads = [0] * n
        for x, b in zip(items, assign):
            loads[b] += x
        if max(loads, default=0) <= cap:
            best = min(best, len(set(assign)))
    return best if n else 0

gen = lambda rng: ((items := rand_list(rng, 1, 6, 6)), 6)
print(stress(min_bins, brute, gen, trials=500))
print(min_bins([1, 2, 3, 4, 5], 6), min_bins([3, 1, 3, 1, 1], 8))
