# file: sos.py
import random
import time
from check import stress, rand_list

def sos(f, n):
    F = f[:]
    for i in range(n):
        bit = 1 << i
        for mask in range(1 << n):
            if mask & bit:
                F[mask] += F[mask ^ bit]
    return F

def sos_brute(f, n):
    return [sum(f[s] for s in range(1 << n) if s & m == s) for m in range(1 << n)]

def count_pairs_and_zero(a, bits):                        # pairs (i, j), i < j, with a[i] & a[j] == 0
    n = bits
    f = [0] * (1 << n)
    for x in a:
        f[x] += 1
    F = sos(f, n)
    full = (1 << n) - 1
    total = sum(F[full ^ x] for x in a)                   # y & x == 0  <=>  y is a submask of ~x
    total -= sum(1 for x in a if x == 0)                  # x paired with itself (only possible for x == 0)
    return total // 2

print(stress(lambda f: sos(f, 4), lambda f: sos_brute(f, 4), lambda rng: ([rng.randint(0, 5) for _ in range(16)],)))
print(stress(count_pairs_and_zero, lambda a, b: sum(a[i] & a[j] == 0 for i in range(len(a)) for j in range(i + 1, len(a))),
             lambda rng: (rand_list(rng, 0, 15, 12), 4)))
rng = random.Random(27)
n = 18
f = [rng.randint(0, 9) for _ in range(1 << n)]
t = time.perf_counter()
F = sos(f, n)
print(f"n={n}: SOS over {1 << n:,} masks in {time.perf_counter() - t:.1f} s; naive submask enumeration would touch 3^{n} = {3 ** n:,} pairs")
