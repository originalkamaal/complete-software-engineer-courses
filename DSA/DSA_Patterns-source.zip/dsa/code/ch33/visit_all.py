# file: visit_all.py
from collections import deque
from itertools import permutations
from check import stress

def shortest_visit_all(n, edges):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v); adj[v].append(u)
    full = (1 << n) - 1
    dist = {(1 << v, v): 0 for v in range(n)}
    q = deque(dist)
    while q:
        mask, u = q.popleft()
        if mask == full:
            return dist[(mask, u)]
        for v in adj[u]:
            s = (mask | 1 << v, v)
            if s not in dist:
                dist[s] = dist[(mask, u)] + 1
                q.append(s)
    return -1

def brute(n, edges):                                     # all-pairs distances + best visiting order
    INF = float("inf")
    d = [[0 if i == j else INF for j in range(n)] for i in range(n)]
    for u, v in edges:
        d[u][v] = d[v][u] = 1
    for k in range(n):
        for i in range(n):
            for j in range(n):
                d[i][j] = min(d[i][j], d[i][k] + d[k][j])
    best = min(sum(d[a][b] for a, b in zip(p, p[1:])) for p in permutations(range(n)))
    return -1 if best == INF else best

def gen(rng):
    n = rng.randint(1, 6)
    return (n, [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 8))])

print(stress(shortest_visit_all, brute, gen, trials=800))
