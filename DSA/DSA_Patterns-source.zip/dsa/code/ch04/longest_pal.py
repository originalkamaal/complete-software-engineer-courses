# file: longest_pal.py
from check import stress

def longest_palindrome(s):
    best = (0, 0)                                    # [start, end) of the best so far
    for centre in range(2 * len(s) - 1):
        lo, hi = centre // 2, (centre + 1) // 2      # same index (odd) or neighbours (even)
        while lo >= 0 and hi < len(s) and s[lo] == s[hi]:
            lo, hi = lo - 1, hi + 1
        if hi - lo - 1 > best[1] - best[0]:
            best = (lo + 1, hi)
    return s[best[0]:best[1]]

def brute(s):
    subs = [s[i:j] for i in range(len(s)) for j in range(i, len(s) + 1)]
    return max((len(x) for x in subs if x == x[::-1]), default=0)

def gen(rng):
    return ("".join(rng.choice("ab") for _ in range(rng.randint(0, 10))),)

print(longest_palindrome("babad"), longest_palindrome("cbbd"), repr(longest_palindrome("")))
print(stress(lambda s: len(longest_palindrome(s)), brute, gen))
