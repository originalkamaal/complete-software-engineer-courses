# file: compress.py
from itertools import groupby
from check import stress

def compress(chars):
    """In place: "aaabcc" -> ['a','3','b','c','2']; returns the new length."""
    w = r = 0
    while r < len(chars):
        ch, start = chars[r], r
        while r < len(chars) and chars[r] == ch:
            r += 1                                   # reader skips the whole run
        chars[w] = ch
        w += 1
        if r - start > 1:
            for d in str(r - start):                 # the count never outruns the reader
                chars[w] = d
                w += 1
    return w

def brute(chars):
    return "".join(k + (str(len(list(g))) if (n := len(list(g2))) > 1 else "")
                   for (k, g), (_, g2) in zip(groupby(chars), groupby(chars)))

def run(chars):
    a = list(chars)
    n = compress(a)
    return "".join(a[:n])

def gen(rng):
    return ("".join(rng.choice("ab") * rng.randint(1, 12) for _ in range(rng.randint(0, 4))),)

print(run("aabbccc"), run("a"), run("abbbbbbbbbbbb"))
print(stress(run, brute, gen))
