# file: palindromes.py
from check import stress

def is_palindrome_alnum(s):
    i, j = 0, len(s) - 1
    while i < j:
        if not s[i].isalnum():
            i += 1
        elif not s[j].isalnum():
            j -= 1
        elif s[i].lower() != s[j].lower():
            return False
        else:
            i, j = i + 1, j - 1
    return True

def palindrome_after_one_deletion(s):
    def is_pal(i, j):
        while i < j:
            if s[i] != s[j]:
                return False
            i, j = i + 1, j - 1
        return True
    i, j = 0, len(s) - 1
    while i < j:
        if s[i] != s[j]:
            return is_pal(i + 1, j) or is_pal(i, j - 1)        # the one allowed deletion
        i, j = i + 1, j - 1
    return True

def brute_one_deletion(s):
    return s == s[::-1] or any((t := s[:k] + s[k + 1:]) == t[::-1] for k in range(len(s)))

def word(rng, alphabet):
    return "".join(rng.choice(alphabet) for _ in range(rng.randint(0, 8)))

print(stress(is_palindrome_alnum, lambda s: (t := [c.lower() for c in s if c.isalnum()]) == t[::-1], lambda rng: (word(rng, "aAb ,"),)))
print(stress(palindrome_after_one_deletion, brute_one_deletion, lambda rng: (word(rng, "abc"),)))
