# file: pairs.py
from check import stress, rand_list

def two_sum_sorted(a, target):                    # a sorted; indices of one pair, or None
    i, j = 0, len(a) - 1
    while i < j:
        s = a[i] + a[j]
        if s == target:
            return (i, j)
        if s < target:
            i += 1
        else:
            j -= 1
    return None

def count_pairs_less(a, target):                  # pairs i<j with a[i]+a[j] < target (a unsorted)
    a = sorted(a)
    i, j, count = 0, len(a) - 1, 0
    while i < j:
        if a[i] + a[j] < target:
            count += j - i                        # a[i] pairs with every element in (i, j]
            i += 1
        else:
            j -= 1
    return count

def count_pairs_less_brute(a, target):
    return sum(1 for i in range(len(a)) for j in range(i + 1, len(a)) if a[i] + a[j] < target)

def three_sum(a):
    """All distinct triples of values summing to 0, as sorted tuples."""
    a, out = sorted(a), []
    for k in range(len(a) - 2):
        if k and a[k] == a[k - 1]:
            continue                              # skip duplicate first elements
        i, j = k + 1, len(a) - 1
        while i < j:
            s = a[k] + a[i] + a[j]
            if s < 0:
                i += 1
            elif s > 0:
                j -= 1
            else:
                out.append((a[k], a[i], a[j]))
                i += 1
                while i < j and a[i] == a[i - 1]:
                    i += 1                        # skip duplicate second elements
                j -= 1
    return out

def three_sum_brute(a):
    from itertools import combinations
    return sorted({tuple(sorted(t)) for t in combinations(a, 3) if sum(t) == 0})

def max_area(h):
    """Container with most water: max over i<j of (j-i) * min(h[i], h[j])."""
    i, j, best = 0, len(h) - 1, 0
    while i < j:
        best = max(best, (j - i) * min(h[i], h[j]))
        if h[i] < h[j]:
            i += 1                                # the shorter side can never do better with a narrower partner
        else:
            j -= 1
    return best

def max_area_brute(h):
    return max([(j - i) * min(h[i], h[j]) for i in range(len(h)) for j in range(i + 1, len(h))], default=0)

def valid_two_sum(res, _brute, args):
    a, t = args
    if res is None:
        return all(a[i] + a[j] != t for i in range(len(a)) for j in range(i + 1, len(a)))
    i, j = res
    return i < j and a[i] + a[j] == t

print(stress(two_sum_sorted, lambda a, t: None, lambda rng: (sorted(rand_list(rng)), rng.randint(-8, 8)), same=valid_two_sum))
print(stress(count_pairs_less, count_pairs_less_brute, lambda rng: (rand_list(rng), rng.randint(-6, 6))))
print(stress(three_sum, three_sum_brute, lambda rng: (rand_list(rng, -4, 4, 10),)))
print(stress(max_area, max_area_brute, lambda rng: (rand_list(rng, 0, 9, 10),)))
