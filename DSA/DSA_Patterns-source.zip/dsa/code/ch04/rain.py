# file: rain.py
from check import stress, rand_list

def trap_prefix(h):
    n = len(h)
    if n == 0:
        return 0
    L, R = [0] * n, [0] * n
    L[0], R[-1] = h[0], h[-1]
    for i in range(1, n):
        L[i] = max(L[i - 1], h[i])
    for i in range(n - 2, -1, -1):
        R[i] = max(R[i + 1], h[i])
    return sum(min(L[i], R[i]) - h[i] for i in range(n))

def trap_two_pointers(h):
    i, j = 0, len(h) - 1
    left_max = right_max = water = 0
    while i <= j:
        if left_max <= right_max:
            left_max = max(left_max, h[i])
            water += left_max - h[i]
            i += 1
        else:
            right_max = max(right_max, h[j])
            water += right_max - h[j]
            j -= 1
    return water

def trap_brute(h):
    return sum(max(0, min(max(h[:i + 1]), max(h[i:])) - h[i]) for i in range(len(h)))

print(stress(trap_prefix, trap_brute, lambda rng: (rand_list(rng, 0, 5, 12),)))
print(stress(trap_two_pointers, trap_brute, lambda rng: (rand_list(rng, 0, 5, 12),)))
print(trap_two_pointers([0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]))
