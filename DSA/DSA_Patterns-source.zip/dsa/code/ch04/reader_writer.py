# file: reader_writer.py
from check import stress, rand_list

def dedupe_sorted_keep_k(a, k):                   # sorted input; keep at most k copies of each value
    a, w = list(a), 0
    for x in a:
        if w < k or a[w - k] != x:                # x is not already present k times in the output
            a[w] = x
            w += 1
    return a[:w]

def dedupe_brute(a, k):
    out = []
    for x in a:
        if out.count(x) < k:
            out.append(x)
    return out

def merge_into_first(a, m, b):
    """a has len m+len(b), with its first m elements sorted; merge b in, in place, filling from the end."""
    a = list(a)
    i, j, w = m - 1, len(b) - 1, len(a) - 1
    while j >= 0:                                 # when b is exhausted, the rest of a is already in place
        if i >= 0 and a[i] > b[j]:
            a[w], i = a[i], i - 1
        else:
            a[w], j = b[j], j - 1
        w -= 1
    return a

def gen_merge(rng):
    x, y = sorted(rand_list(rng)), sorted(rand_list(rng))
    return x + [0] * len(y), len(x), y

print(stress(dedupe_sorted_keep_k, dedupe_brute, lambda rng: (sorted(rand_list(rng, 0, 3, 10)), rng.randint(1, 3))))
print(stress(merge_into_first, lambda a, m, b: sorted(a[:m] + b), gen_merge))
