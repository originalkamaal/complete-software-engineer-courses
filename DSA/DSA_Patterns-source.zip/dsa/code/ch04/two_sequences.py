# file: two_sequences.py
from collections import Counter
from check import stress, rand_list

def is_subsequence(s, t):                         # is s a subsequence of t?
    i = 0
    for ch in t:
        if i < len(s) and s[i] == ch:
            i += 1
    return i == len(s)

def is_subsequence_brute(s, t):
    from itertools import combinations
    return any("".join(c) == s for k in [len(s)] for c in combinations(t, k)) if len(s) <= len(t) else False

def intersect_sorted(a, b):                       # multiset intersection of two sorted lists
    i = j = 0
    out = []
    while i < len(a) and j < len(b):
        if a[i] < b[j]:
            i += 1
        elif a[i] > b[j]:
            j += 1
        else:
            out.append(a[i])
            i, j = i + 1, j + 1
    return out

def word(rng):
    return "".join(rng.choice("ab") for _ in range(rng.randint(0, 6)))

print(stress(is_subsequence, is_subsequence_brute, lambda rng: (word(rng)[:3], word(rng))))
print(stress(intersect_sorted, lambda a, b: sorted((Counter(a) & Counter(b)).elements()),
             lambda rng: (sorted(rand_list(rng, 0, 4)), sorted(rand_list(rng, 0, 4)))))
