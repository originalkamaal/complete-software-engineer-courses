# file: unsorted_sub.py
from check import stress, rand_list

def shortest_unsorted(a):
    n = len(a)
    end, hi = -1, float("-inf")
    for i in range(n):
        hi = max(hi, a[i])
        if a[i] < hi:
            end = i                      # something bigger came before: i is out of place
    start, lo = 0, float("inf")
    for i in range(n - 1, -1, -1):
        lo = min(lo, a[i])
        if a[i] > lo:
            start = i
    return end - start + 1 if end >= 0 else 0

def brute(a):
    s = sorted(a)
    diff = [i for i in range(len(a)) if a[i] != s[i]]
    return diff[-1] - diff[0] + 1 if diff else 0

print(shortest_unsorted([2, 6, 4, 8, 10, 9, 15]), shortest_unsorted([1, 2, 3]), shortest_unsorted([1, 3, 2, 2, 2]))
print(stress(shortest_unsorted, brute, lambda rng: (rand_list(rng, 0, 5, max_len=10),)))
