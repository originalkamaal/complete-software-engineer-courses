# file: ksum/ksum.py
from itertools import combinations
import random
import time
from check import stress, rand_list

def k_sum(nums, k, target):
    a = sorted(nums)

    def solve(start, k, target):
        out = []
        if k == 2:
            i, j = start, len(a) - 1
            while i < j:
                s = a[i] + a[j]
                if s < target:
                    i += 1
                elif s > target:
                    j -= 1
                else:
                    out.append((a[i], a[j]))
                    i += 1
                    while i < j and a[i] == a[i - 1]:
                        i += 1
                    j -= 1
            return out
        for p in range(start, len(a) - k + 1):
            if p > start and a[p] == a[p - 1]:
                continue                                         # duplicate at this level
            if sum(a[p:p + k]) > target:
                break                                            # the k smallest from here already exceed
            if a[p] + sum(a[len(a) - k + 1:]) < target:
                continue                                         # even the largest partners are not enough
            for rest in solve(p + 1, k - 1, target - a[p]):
                out.append((a[p],) + rest)
        return out

    return solve(0, k, target) if 2 <= k <= len(a) else []

def k_sum_brute(nums, k, target):
    return sorted({tuple(sorted(c)) for c in combinations(nums, k) if sum(c) == target})

print(stress(k_sum, k_sum_brute, lambda rng: (rand_list(rng, -5, 5, 9), rng.randint(2, 4), rng.randint(-6, 6))))
print(k_sum([1, 0, -1, 0, -2, 2], 4, 0))
rng = random.Random(4)
nums = [rng.randint(-1000, 1000) for _ in range(300)]
for k in (3, 4):
    t = time.perf_counter()
    r = k_sum(nums, k, 17)
    print(f"n=300, k={k}: {len(r):,} distinct tuples in {(time.perf_counter() - t) * 1000:.0f} ms")
