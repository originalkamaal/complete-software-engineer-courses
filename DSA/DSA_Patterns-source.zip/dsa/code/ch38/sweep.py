# file: sweep.py
from check import stress

def sweep_stats(intervals):                            # half-open [s, e)
    events = sorted([(s, 1) for s, e in intervals] + [(e, -1) for s, e in intervals])   # -1 sorts before +1
    count = best = covered = 0
    prev = None
    free = []
    for x, d in events:
        if prev is not None and x > prev:
            if count > 0:
                covered += x - prev
            else:
                free.append((prev, x))                 # a gap between busy stretches
        count += d
        best = max(best, count)
        prev = x
    return best, covered, free

def brute(intervals):
    pts = {}
    for s, e in intervals:
        for x in range(s, e):
            pts[x] = pts.get(x, 0) + 1
    best = max(pts.values(), default=0)
    covered = len(pts)
    free = []
    if intervals:
        lo, hi = min(s for s, _ in intervals), max(e for _, e in intervals)
        for x in range(lo, hi):
            if x not in pts:
                if free and free[-1][1] == x:
                    free[-1] = (free[-1][0], x + 1)
                else:
                    free.append((x, x + 1))
    return best, covered, free

gen = lambda rng: ([(s := rng.randint(0, 20), s + rng.randint(1, 5)) for _ in range(rng.randint(0, 6))],)
print(stress(sweep_stats, brute, gen))
print(sweep_stats([(1, 3), (2, 6), (8, 10), (9, 12)]))
