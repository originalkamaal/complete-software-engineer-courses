# file: skyline.py
import heapq
from check import stress

def skyline(buildings):                                # (left, right, height), half-open [left, right)
    xs = sorted({x for l, r, _ in buildings for x in (l, r)})
    by_left = sorted(buildings)
    active, i, out = [], 0, []                         # active: (-height, right)
    for x in xs:
        while i < len(by_left) and by_left[i][0] <= x:
            l, r, h = by_left[i]
            heapq.heappush(active, (-h, r)); i += 1
        while active and active[0][1] <= x:            # lazy deletion: building ended
            heapq.heappop(active)
        h = -active[0][0] if active else 0
        if not out or out[-1][1] != h:
            out.append([x, h])
    return out

def brute(buildings):
    xs = sorted({x for l, r, _ in buildings for x in (l, r)})
    out = []
    for x in xs:
        h = max((hh for l, r, hh in buildings if l <= x < r), default=0)
        if not out or out[-1][1] != h:
            out.append([x, h])
    return out

gen = lambda rng: ([(l := rng.randint(0, 15), l + rng.randint(1, 6), rng.randint(1, 9)) for _ in range(rng.randint(0, 6))],)
print(stress(skyline, brute, gen))
print(skyline([(2, 9, 10), (3, 7, 15), (5, 12, 12), (15, 20, 10), (19, 24, 8)]))
