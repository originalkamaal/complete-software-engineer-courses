# file: calendar/calendar_k.py
import random
import time
from sortedcontainers import SortedDict
from check import stress

class SweepCalendar:
    def __init__(self):
        self.delta = SortedDict()
    def book(self, s, e):
        self.delta[s] = self.delta.get(s, 0) + 1
        self.delta[e] = self.delta.get(e, 0) - 1
        cur = best = 0
        for d in self.delta.values():                   # O(n) re-sweep
            cur += d
            best = max(best, cur)
        return best

class DynamicSegTree:
    """Range add on [l, r), global max, over [0, size). Nodes created lazily in dicts."""
    def __init__(self, size):
        self.size = size
        self.mx, self.tag = {}, {}
    def add(self, l, r, v, node=1, lo=0, hi=None):
        hi = self.size if hi is None else hi
        if r <= lo or hi <= l:
            return
        if l <= lo and hi <= r:
            self.mx[node] = self.mx.get(node, 0) + v
            self.tag[node] = self.tag.get(node, 0) + v
            return
        mid = (lo + hi) // 2
        self.add(l, r, v, 2 * node, lo, mid)
        self.add(l, r, v, 2 * node + 1, mid, hi)
        # tags are never pushed down: a node's max = its own tag + max of children
        self.mx[node] = self.tag.get(node, 0) + max(self.mx.get(2 * node, 0), self.mx.get(2 * node + 1, 0))
    def global_max(self):
        return self.mx.get(1, 0)

class TreeCalendar:
    def __init__(self, size=10**9):
        self.t = DynamicSegTree(size)
    def book(self, s, e):
        self.t.add(s, e, 1)
        return self.t.global_max()

def run(cls, bookings):
    c = cls()
    return [c.book(s, e) for s, e in bookings]

gen = lambda rng: ([(s := rng.randint(0, 30), s + rng.randint(1, 8)) for _ in range(rng.randint(1, 12))],)
print(stress(lambda b: run(TreeCalendar, b), lambda b: run(SweepCalendar, b), gen))

rng = random.Random(31)
for n in (2_000, 20_000, 100_000):
    bookings = [(s := rng.randint(0, 10**9 - 10**6), s + rng.randint(1, 10**6)) for _ in range(n)]
    for name, cls in (("dynamic segment tree", TreeCalendar), ("sorted map + sweep", SweepCalendar)):
        if cls is SweepCalendar and n > 20_000:
            print(f"n={n:>7,}: {name:>20}: skipped (quadratic)")
            continue
        t = time.perf_counter()
        res = run(cls, bookings)
        print(f"n={n:>7,}: {name:>20}: final max overlap {res[-1]} in {time.perf_counter() - t:.2f} s")
