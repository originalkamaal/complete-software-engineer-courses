# file: stabbing.py
from itertools import combinations, product
from check import stress

def min_arrows(balloons):                              # closed intervals: an arrow at x bursts [s, e] if s <= x <= e
    arrows, last = 0, float("-inf")
    for s, e in sorted(balloons, key=lambda b: b[1]):
        if s > last:                                   # not yet burst
            arrows, last = arrows + 1, e
    return arrows

def arrows_brute(balloons):
    if not balloons:
        return 0
    candidates = sorted({e for _, e in balloons})      # some optimal solution shoots only at right ends
    for k in range(1, len(balloons) + 1):
        for shots in combinations(candidates, k):
            if all(any(s <= x <= e for x in shots) for s, e in balloons):
                return k

gen = lambda rng: ([(s := rng.randint(0, 15), s + rng.randint(0, 5)) for _ in range(rng.randint(0, 6))],)
print(stress(min_arrows, arrows_brute, gen))
print(min_arrows([(10, 16), (2, 8), (1, 6), (7, 12)]))
