# file: interval_lists.py
from check import stress

def merge(intervals):                                 # closed intervals [s, e]; touching ones merge
    out = []
    for s, e in sorted(intervals):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out

def insert(intervals, new):                           # intervals sorted and disjoint
    s, e = new
    left = [iv for iv in intervals if iv[1] < s]
    right = [iv for iv in intervals if iv[0] > e]
    mid = [iv for iv in intervals if not (iv[1] < s or iv[0] > e)]
    if mid:
        s, e = min(s, mid[0][0]), max(e, mid[-1][1])
    return left + [[s, e]] + right

def intersect(A, B):
    i = j = 0
    out = []
    while i < len(A) and j < len(B):
        lo, hi = max(A[i][0], B[j][0]), min(A[i][1], B[j][1])
        if lo <= hi:
            out.append([lo, hi])
        if A[i][1] < B[j][1]:
            i += 1
        else:
            j += 1
    return out

def to_points(ivs):                                   # brute force on a small integer line (closed intervals)
    return {x for s, e in ivs for x in range(s, e + 1)}

def from_points(pts):
    out = []
    for x in sorted(pts):
        if out and x == out[-1][1] + 1:
            out[-1][1] = x
        else:
            out.append([x, x])
    return out

def rand_ivs(rng, k=5):
    return [[s, s + rng.randint(0, 4)] for s in (rng.randint(0, 20) for _ in range(rng.randint(0, k)))]

print(stress(lambda ivs: to_points(merge(ivs)), to_points, lambda rng: (rand_ivs(rng),)))
print(stress(lambda a, n: to_points(insert(merge(a), n)), lambda a, n: to_points(a) | to_points([n]),
             lambda rng: (rand_ivs(rng), [(s := rng.randint(0, 20)), s + rng.randint(0, 4)])))
print(stress(lambda a, b: to_points(intersect(merge(a), merge(b))), lambda a, b: to_points(a) & to_points(b), lambda rng: (rand_ivs(rng), rand_ivs(rng))))
print(merge([[1, 3], [2, 6], [8, 10], [15, 18]]), insert([[1, 2], [3, 5], [6, 7], [8, 10], [12, 16]], [4, 8]))
