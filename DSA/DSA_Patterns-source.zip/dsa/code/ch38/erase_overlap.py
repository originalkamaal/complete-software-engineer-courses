# file: erase_overlap.py
from itertools import combinations
from check import stress

def min_removals(intervals):                      # half-open [s, e)
    kept, last_end = 0, float("-inf")
    for s, e in sorted(intervals, key=lambda iv: iv[1]):
        if s >= last_end:
            kept += 1
            last_end = e
    return len(intervals) - kept

def brute(intervals):
    n = len(intervals)
    for keep in range(n, -1, -1):
        for subset in combinations(intervals, keep):
            ivs = sorted(subset)
            if all(a[1] <= b[0] for a, b in zip(ivs, ivs[1:])):
                return n - keep

def gen(rng):
    out = []
    for _ in range(rng.randint(0, 7)):
        s = rng.randint(0, 8)
        out.append((s, s + rng.randint(1, 4)))
    return (out,)

print(min_removals([(1, 2), (2, 3), (3, 4), (1, 3)]), min_removals([(1, 2), (1, 2), (1, 2)]))
print(stress(min_removals, brute, gen))
