# file: game.py
from functools import cache
from check import stress, rand_list

def best_difference(a):
    n = len(a)
    if n == 0:
        return 0
    dp = a[:]                                        # length-1 intervals: dp[i] = a[i]; dp[i] then means dp[i][i+len-1]
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            dp[i] = max(a[i] - dp[i + 1], a[j] - dp[i])  # dp[i+1] holds [i+1..j], dp[i] holds [i..j-1]
    return dp[0]

def minimax(a):                                       # explicit turns: returns (first player's total, second's)
    @cache
    def go(i, j):                                    # (score of player to move, score of other)
        if i > j:
            return 0, 0
        o1, m1 = go(i + 1, j)
        o2, m2 = go(i, j - 1)
        return max((a[i] + m1, o1), (a[j] + m2, o2))
    first, second = go(0, len(a) - 1)
    return first - second

print(stress(best_difference, minimax, lambda rng: (rand_list(rng, 0, 9, 10),)))
print(best_difference([1, 5, 233, 7]), best_difference([1, 5, 2]))
