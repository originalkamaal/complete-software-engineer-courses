# file: last_op.py
from functools import cache
from itertools import permutations
from check import stress, rand_list

def burst(nums):
    a = [1] + nums + [1]
    n = len(a)
    dp = [[0] * n for _ in range(n)]                 # dp[i][j]: best for balloons strictly between i and j
    for length in range(2, n):
        for i in range(n - length):
            j = i + length
            dp[i][j] = max(dp[i][k] + dp[k][j] + a[i] * a[k] * a[j] for k in range(i + 1, j))
    return dp[0][n - 1]

def burst_brute(nums):
    best = 0
    for order in permutations(range(len(nums))):
        alive, coins = list(range(len(nums))), 0
        for k in order:
            p = alive.index(k)
            left = nums[alive[p - 1]] if p > 0 else 1
            right = nums[alive[p + 1]] if p + 1 < len(alive) else 1
            coins += left * nums[k] * right
            alive.pop(p)
        best = max(best, coins)
    return best

def min_cut_cost(length, cuts):
    c = [0] + sorted(cuts) + [length]
    m = len(c)
    dp = [[0] * m for _ in range(m)]
    for gap in range(2, m):
        for i in range(m - gap):
            j = i + gap
            dp[i][j] = c[j] - c[i] + min(dp[i][k] + dp[k][j] for k in range(i + 1, j))
    return dp[0][m - 1]

def cut_brute(length, cuts):
    best = float("inf")
    for order in permutations(cuts):
        pieces, cost = [(0, length)], 0
        for x in order:
            idx = next(i for i, (a, b) in enumerate(pieces) if a < x < b)
            a, b = pieces.pop(idx)
            cost += b - a
            pieces += [(a, x), (x, b)]
        best = min(best, cost)
    return best if cuts else 0

print(stress(burst, burst_brute, lambda rng: (rand_list(rng, 0, 9, 6),)))
print(stress(min_cut_cost, cut_brute, lambda rng: ((L := rng.randint(2, 20)), rng.sample(range(1, L), min(L - 1, rng.randint(0, 5))))))
print(burst([3, 1, 5, 8]), min_cut_cost(7, [1, 3, 4, 5]))
