# file: obst/obst.py
import random
import time
from functools import cache
from check import stress

def optimal_bst(freq):
    n = len(freq)
    pre = [0]
    for f in freq:
        pre.append(pre[-1] + f)
    cost = [[0] * (n + 1) for _ in range(n + 2)]       # cost[i][j] for keys i..j-1 (half-open), 0 when empty
    root = [[0] * (n + 1) for _ in range(n + 1)]
    for length in range(1, n + 1):
        for i in range(n - length + 1):
            j = i + length
            best, arg = float("inf"), -1
            for r in range(i, j):
                c = cost[i][r] + cost[r + 1][j]
                if c < best:
                    best, arg = c, r
            cost[i][j], root[i][j] = best + pre[j] - pre[i], arg
    return cost[0][n], root

def build(root, i, j):                                 # nested tuples (key, left, right)
    if i >= j:
        return None
    r = root[i][j]
    return (r, build(root, i, r), build(root, r + 1, j))

def search_cost(tree, freq, depth=1):
    if tree is None:
        return 0
    k, l, r = tree
    return freq[k] * depth + search_cost(l, freq, depth + 1) + search_cost(r, freq, depth + 1)

def balanced(i, j):
    if i >= j:
        return None
    m = (i + j) // 2
    return (m, balanced(i, m), balanced(m + 1, j))

def brute(freq):
    @cache
    def go(i, j):
        if i >= j: return 0
        return sum(freq[i:j]) + min(go(i, r) + go(r + 1, j) for r in range(i, j))
    return go(0, len(freq))

def check(freq):
    c, root = optimal_bst(freq)
    return c, search_cost(build(root, 0, len(freq)), freq) == c

if __name__ == "__main__":
    print(stress(check, lambda f: (brute(f), True), lambda rng: ([rng.randint(0, 9) for _ in range(rng.randint(0, 9))],)))
    
    rng = random.Random(25)
    n = 400
    freq = [int(1000 / (rank + 1)) for rank in range(n)]  # Zipf-like popularity...
    rng.shuffle(freq)                                      # ...assigned to keys in random order
    t = time.perf_counter()
    c, root = optimal_bst(freq)
    el = time.perf_counter() - t
    total = sum(freq)
    print(f"n={n}: optimal expected depth {c / total:.3f}, balanced BST {search_cost(balanced(0, n), freq) / total:.3f}  [{el * 1000:,.0f} ms]")
