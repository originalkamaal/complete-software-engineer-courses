# file: count_pal.py
from check import stress

def count_palindromic(s):
    n, count = len(s), 0
    is_pal = [[False] * n for _ in range(n)]
    for length in range(1, n + 1):                 # by increasing length
        for i in range(n - length + 1):
            j = i + length - 1
            is_pal[i][j] = s[i] == s[j] and (length <= 2 or is_pal[i + 1][j - 1])
            count += is_pal[i][j]
    return count

def brute(s):
    return sum(s[i:j] == s[i:j][::-1] for i in range(len(s)) for j in range(i + 1, len(s) + 1))

print(count_palindromic("abc"), count_palindromic("aaa"))
print(stress(count_palindromic, brute, lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(0, 10))),)))
