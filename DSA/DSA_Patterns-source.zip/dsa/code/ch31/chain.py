# file: chain.py
from functools import cache
from check import stress

def matrix_chain(d):                                 # n = len(d) - 1 matrices
    n = len(d) - 1
    dp = [[0] * n for _ in range(n)]
    split = [[0] * n for _ in range(n)]
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            dp[i][j] = float("inf")
            for k in range(i, j):                    # last multiplication: (i..k) x (k+1..j)
                c = dp[i][k] + dp[k + 1][j] + d[i] * d[k + 1] * d[j + 1]
                if c < dp[i][j]:
                    dp[i][j], split[i][j] = c, k
    def paren(i, j):
        return f"A{i}" if i == j else f"({paren(i, split[i][j])}{paren(split[i][j] + 1, j)})"
    return dp[0][n - 1], paren(0, n - 1)

def brute(d):                                        # all parenthesisations, recursively
    @cache
    def go(i, j):
        if i == j:
            return 0
        return min(go(i, k) + go(k + 1, j) + d[i] * d[k + 1] * d[j + 1] for k in range(i, j))
    return go(0, len(d) - 2)

print(stress(lambda d: matrix_chain(d)[0], brute, lambda rng: ([rng.randint(1, 20) for _ in range(rng.randint(2, 8))],)))
print(matrix_chain([10, 30, 5, 60]), matrix_chain([40, 20, 30, 10, 30]))
