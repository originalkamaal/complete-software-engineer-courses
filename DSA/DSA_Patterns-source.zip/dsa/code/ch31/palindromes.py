# file: palindromes.py
from functools import cache
from check import stress

def lps(s):
    n = len(s)
    if n == 0:
        return 0
    dp = [[0] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):                   # i decreasing, j increasing: dp[i+1][*] ready
        dp[i][i] = 1
        for j in range(i + 1, n):
            dp[i][j] = dp[i + 1][j - 1] + 2 if s[i] == s[j] else max(dp[i + 1][j], dp[i][j - 1])
    return dp[0][n - 1]

def min_palindrome_cuts(s):
    n = len(s)
    pal = [[False] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):
        for j in range(i, n):
            pal[i][j] = s[i] == s[j] and (j - i < 2 or pal[i + 1][j - 1])
    cuts = [0] * n                                   # cuts[j]: min cuts for s[:j+1]
    for j in range(n):
        cuts[j] = 0 if pal[0][j] else min(cuts[i - 1] + 1 for i in range(1, j + 1) if pal[i][j])
    return cuts[-1] if n else 0

def lps_brute(s):
    from itertools import combinations
    return max((k for k in range(len(s) + 1) for c in combinations(s, k) if c == c[::-1]), default=0)

def cuts_brute(s):
    @cache
    def go(i):                                       # min pieces for s[i:]
        if i == len(s): return 0
        return min(1 + go(j) for j in range(i + 1, len(s) + 1) if s[i:j] == s[i:j][::-1])
    return max(0, go(0) - 1)

w = lambda rng: ("".join(rng.choice("abc") for _ in range(rng.randint(0, 10))),)
print(stress(lps, lps_brute, w))
print(stress(min_palindrome_cuts, cuts_brute, w))
print(lps("bbbab"), "insertions for 'mbadm':", 5 - lps("mbadm"), "cuts for 'aab':", min_palindrome_cuts("aab"))
