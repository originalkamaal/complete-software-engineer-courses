# file: twosat_test.py
from itertools import product
from check import stress
from twosat import TwoSat

def satisfied(clauses, assign):
    val = lambda l: assign[l // 2] ^ (l & 1)
    return all(val(a) or val(b) for a, b in clauses)

def run(n, clauses):
    ts = TwoSat(n)
    for a, b in clauses:
        ts.either(a, b)
    res = ts.solve()
    return res is not None and satisfied(clauses, res), res is not None

def brute(n, clauses):
    ok = any(satisfied(clauses, list(a)) for a in product((False, True), repeat=n))
    return ok, ok

gen = lambda rng: ((n := rng.randint(1, 5)), [(rng.randrange(2 * n), rng.randrange(2 * n)) for _ in range(rng.randint(0, 10))])
print(stress(run, brute, gen))
