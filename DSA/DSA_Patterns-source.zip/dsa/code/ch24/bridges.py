# file: bridges.py
from check import stress
from dsu import DSU

def bridges_and_cuts(n, edges):
    adj = [[] for _ in range(n)]
    for i, (u, v) in enumerate(edges):
        adj[u].append((v, i)); adj[v].append((u, i))
    tin, low, timer = [-1] * n, [0] * n, 0
    bridges, cuts = [], set()
    for root in range(n):
        if tin[root] != -1:
            continue
        tin[root] = low[root] = timer; timer += 1
        children = 0
        stack = [(root, -1, iter(adj[root]))]
        while stack:
            u, via, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                stack.pop()
                if stack:                                # finished child u of parent p: propagate low
                    p = stack[-1][0]
                    low[p] = min(low[p], low[u])
                    if low[u] > tin[p]:
                        bridges.append(via)
                    if low[u] >= tin[p] and p != root:
                        cuts.add(p)
                continue
            v, eid = nxt
            if eid == via:
                continue
            if tin[v] == -1:
                tin[v] = low[v] = timer; timer += 1
                if u == root:
                    children += 1
                stack.append((v, eid, iter(adj[v])))
            else:
                low[u] = min(low[u], tin[v])             # back edge
        if children >= 2:
            cuts.add(root)
    return sorted(bridges), sorted(cuts)

def components(n, edges, skip_vertex=None):
    d = DSU(n)
    for u, v in edges:
        if skip_vertex not in (u, v):
            d.union(u, v)
    return len({d.find(v) for v in range(n) if v != skip_vertex})

def cut_brute(n, edges):                                 # v is a cut vertex if removing it increases the
    base = components(n, edges)                          # number of components among the OTHER vertices
    isolated = lambda v: all(v not in e for e in edges)
    return [v for v in range(n) if components(n, edges, v) > base - (1 if isolated(v) else 0)]

def bridge_brute(n, edges):
    base = components(n, edges)
    return [i for i in range(len(edges)) if components(n, edges[:i] + edges[i + 1:]) > base]

gen = lambda rng: ((n := rng.randint(1, 8)), [(a, b) for a, b in ((rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 10)))])
print(stress(bridges_and_cuts, lambda n, e: (bridge_brute(n, e), cut_brute(n, e)), gen))
print(bridges_and_cuts(6, [(0, 1), (1, 2), (2, 0), (1, 3), (3, 4), (4, 5), (5, 3)]))
