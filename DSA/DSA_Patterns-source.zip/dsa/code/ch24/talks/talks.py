# file: talks/talks.py
import random
import time
from collections import deque
from check import stress
from twosat import TwoSat

MORNING = True

def build(n, same_speaker, fixed, same_slot, if_morning):
    ts, L = TwoSat(n), TwoSat.lit
    for a, b in same_speaker:                          # different slots: (a or b) and (not a or not b)
        ts.either(L(a), L(b)); ts.either(L(a, False), L(b, False))
    for a, slot in fixed:
        ts.either(L(a, slot), L(a, slot))              # unit clause (x or x)
    for a, b in same_slot:                             # a == b
        ts.implies(L(a), L(b)); ts.implies(L(b), L(a))
    for a, b in if_morning:                            # a morning -> b morning
        ts.implies(L(a), L(b))
    return ts

def explain(ts, var):
    """Find a path x -> ... -> not x and not x -> ... -> x for a contradictory variable."""
    adj = [[] for _ in range(2 * ts.n)]
    for u, v in ts.edges:
        adj[u].append(v)
    def path(s, t):
        par, q = {s: None}, deque([s])
        while q:
            u = q.popleft()
            if u == t:
                out = []
                while u is not None:
                    out.append(u); u = par[u]
                return out[::-1]
            for v in adj[u]:
                if v not in par:
                    par[v] = u; q.append(v)
    name = lambda l: f"{'AM' if l % 2 == 0 else 'PM'}({l // 2})"
    p1, p2 = path(2 * var, 2 * var + 1), path(2 * var + 1, 2 * var)
    return " -> ".join(map(name, p1)) + "  and  " + " -> ".join(map(name, p2))

def valid(n, sol, same_speaker, fixed, same_slot, if_morning):
    return (all(sol[a] != sol[b] for a, b in same_speaker) and all(sol[a] == s for a, s in fixed)
            and all(sol[a] == sol[b] for a, b in same_slot) and all(not sol[a] or sol[b] for a, b in if_morning))

def brute(n, *cons):
    from itertools import product
    return any(valid(n, list(s), *cons) for s in product((False, True), repeat=n))

def run(n, *cons):                                     # True iff a valid schedule was produced
    sol = build(n, *cons).solve()
    return sol is not None and valid(n, sol, *cons)

def gen(rng):
    n = rng.randint(1, 6)
    pair = lambda: tuple(rng.sample(range(n), 2)) if n > 1 else (0, 0)
    return (n, [pair() for _ in range(rng.randint(0, 3))], [(rng.randrange(n), rng.random() < 0.5) for _ in range(rng.randint(0, 2))],
            [pair() for _ in range(rng.randint(0, 2))], [pair() for _ in range(rng.randint(0, 2))])

print(stress(run, brute, gen))

ts = build(3, same_speaker=[(0, 1), (1, 2)], fixed=[], same_slot=[(0, 2)], if_morning=[]) # satisfiable
print("3 talks:", ["AM" if x else "PM" for x in ts.solve()])
ts = build(3, same_speaker=[(0, 1), (1, 2), (0, 2)], fixed=[], same_slot=[], if_morning=[])  # odd cycle: impossible
sol = ts.solve()
print("triangle of shared speakers:", sol, "->", explain(ts, 0))

rng = random.Random(18)
n = 50_000
hidden = [rng.random() < 0.5 for _ in range(n)]       # plant a schedule, then draw constraints it satisfies
def pairs(k, ok):
    out = []
    while len(out) < k:
        a, b = rng.randrange(n), rng.randrange(n)
        if a != b and ok(a, b):
            out.append((a, b))
    return out
cons = (pairs(30_000, lambda a, b: hidden[a] != hidden[b]), [(a, hidden[a]) for a in rng.sample(range(n), 500)],
        pairs(5_000, lambda a, b: hidden[a] == hidden[b]), pairs(20_000, lambda a, b: not hidden[a] or hidden[b]))
t = time.perf_counter()
sol = build(n, *cons).solve()
print(f"{n:,} talks, {sum(map(len, cons)):,} constraints -> {'schedule found' if sol else 'impossible'}"
      f"{' (verified)' if sol and valid(n, sol, *cons) else ''} in {(time.perf_counter() - t) * 1000:.0f} ms;"
      f" same as the planted schedule on {sum(x == y for x, y in zip(sol, hidden)):,} talks")
