# file: scc_test.py
from check import stress
from scc import scc

def reach(n, edges):
    R = [[i == j for j in range(n)] for i in range(n)]
    for u, v in edges:
        R[u][v] = True
    for k in range(n):                                  # transitive closure (Floyd–Warshall with booleans)
        for i in range(n):
            if R[i][k]:
                for j in range(n):
                    R[i][j] = R[i][j] or R[k][j]
    return R

def check(n, edges):
    comp, R = scc(n, edges), reach(n, edges)
    same_iff_mutual = all((comp[u] == comp[v]) == (R[u][v] and R[v][u]) for u in range(n) for v in range(n))
    topo = all(comp[u] <= comp[v] for u, v in edges)    # edges never go "backwards" between components
    return same_iff_mutual and topo

def min_edges_to_strongly_connect(n, edges):          # classic: max(#sources, #sinks) of the condensation
    comp = scc(n, edges)
    k = max(comp) + 1
    if k == 1:
        return 0
    has_in, has_out = [False] * k, [False] * k
    for u, v in edges:
        if comp[u] != comp[v]:
            has_out[comp[u]] = True; has_in[comp[v]] = True
    return max(k - sum(has_in), k - sum(has_out))

print(stress(check, lambda n, e: True, lambda rng: ((n := rng.randint(1, 8)), [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 12))])))
print(scc(8, [(0, 1), (1, 2), (2, 0), (2, 3), (3, 4), (4, 5), (5, 3), (6, 5), (6, 7), (7, 6)]))
print(min_edges_to_strongly_connect(5, [(0, 1), (1, 2), (3, 4)]))
