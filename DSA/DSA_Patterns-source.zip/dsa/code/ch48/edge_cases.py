# file: edge_cases.py
"""Generate the 'interview edge cases' for array problems, and show they catch typical bugs."""
def edge_cases(lo=-3, hi=3):
    yield []
    yield [lo]
    yield [0]
    yield [hi] * 4                                    # all equal
    yield list(range(lo, hi + 1))                     # sorted
    yield list(range(hi, lo - 1, -1))                 # reverse sorted
    yield [lo, hi, lo, hi]                            # duplicates, alternating
    yield [0, lo, 0, hi, 0]                           # zeros and signs

def max_subarray(a):                                  # correct Kadane (non-empty subarray)
    best = cur = a[0]
    for x in a[1:]:
        cur = max(x, cur + x)
        best = max(best, cur)
    return best

def buggy_reset_at_zero(a):                           # common bug: reset when cur < 0, init best = 0
    best = cur = 0
    for x in a:
        cur = max(0, cur + x)
        best = max(best, cur)
    return best

def brute(a):
    return max(sum(a[i:j]) for i in range(len(a)) for j in range(i + 1, len(a) + 1))

for case in edge_cases():
    if not case:
        continue                                       # this problem requires a non-empty array: say so!
    if buggy_reset_at_zero(case) != brute(case):
        print(f"edge case {case} exposes the bug: buggy={buggy_reset_at_zero(case)}, correct={brute(case)}")
print("correct version passes all edge cases:", all(max_subarray(c) == brute(c) for c in edge_cases() if c))
