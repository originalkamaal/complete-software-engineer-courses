# file: extsort/extsort.py
import heapq
import os
import random
import tempfile
import time

def write_numbers(path, nums):
    with open(path, "w") as f:
        f.write("\n".join(map(str, nums)) + ("\n" if nums else ""))

def read_numbers(path):
    with open(path) as f:
        for line in f:
            yield int(line)

def external_sort(in_path, out_path, memory_numbers, tmpdir):
    runs, chunk, io = [], [], {"read": 0, "written": 0}
    def flush():
        chunk.sort()
        path = os.path.join(tmpdir, f"run{len(runs)}.txt")
        write_numbers(path, chunk)
        io["written"] += len(chunk)
        runs.append(path)
        chunk.clear()
    for x in read_numbers(in_path):                    # pass 1: sorted runs of size <= M
        io["read"] += 1
        chunk.append(x)
        if len(chunk) == memory_numbers:
            flush()
    if chunk:
        flush()
    readers = [read_numbers(p) for p in runs]           # pass 2: one k-way merge (k = number of runs)
    with open(out_path, "w") as out:
        for x in heapq.merge(*readers):                 # heap of run heads (Unit 15.3)
            io["read"] += 1
            out.write(f"{x}\n")
            io["written"] += 1
    return len(runs), io

rng = random.Random(45)
N, M = 1_000_000, 50_000
nums = [rng.randint(-10**12, 10**12) for _ in range(N)]
with tempfile.TemporaryDirectory() as d:
    src, dst = os.path.join(d, "in.txt"), os.path.join(d, "out.txt")
    write_numbers(src, nums)
    t = time.perf_counter()
    nruns, io = external_sort(src, dst, M, d)
    el = time.perf_counter() - t
    ok = list(read_numbers(dst)) == sorted(nums)
print(f"N = {N:,} numbers, memory for {M:,}: {nruns} sorted runs, one {nruns}-way merge; "
      f"read {io['read']:,} and wrote {io['written']:,} numbers (2 passes); correct: {ok}  [{el:.1f} s]")
