# file: stream_followup.py
import heapq
import random

def top_k_stream(stream, k):                          # follow-up: "the numbers arrive as a stream" -> heap of size k
    h = []
    for x in stream:
        if len(h) < k:
            heapq.heappush(h, x)
        elif x > h[0]:
            heapq.heapreplace(h, x)
    return sorted(h, reverse=True)

def running_mean_and_variance(stream):                 # Welford: numerically stable, O(1) memory
    n, mean, m2 = 0, 0.0, 0.0
    for x in stream:
        n += 1
        d = x - mean
        mean += d / n
        m2 += d * (x - mean)
    return mean, m2 / (n - 1) if n > 1 else 0.0

rng = random.Random(44)
data = (rng.gauss(10**9, 1) for _ in range(1_000_000))  # a generator: never materialised
print("top 3 of a million streamed values:", top_k_stream((rng.randint(0, 10**9) for _ in range(10**6)), 3))
mean, var = running_mean_and_variance(data)
print(f"Welford over 10^6 values near 1e9: mean {mean:.4f}, variance {var:.4f} (true variance 1)")
naive = [rng.gauss(10**9, 1) for _ in range(100_000)]
s, s2 = sum(naive), sum(x * x for x in naive)
print(f"naive E[x^2] - E[x]^2 on 10^5 values near 1e9: variance {s2 / len(naive) - (s / len(naive)) ** 2:.1f}  (catastrophic cancellation)")
