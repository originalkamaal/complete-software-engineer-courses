# file: cluster/cluster.py
import math
import random
import time
from check import stress
from dsu import DSU

def prim_euclid(pts):
    n = len(pts)
    best, parent, used = [math.inf] * n, [-1] * n, [False] * n
    best[0] = 0.0
    edges = []
    for _ in range(n):
        u, bu = -1, math.inf
        for v in range(n):
            if not used[v] and best[v] < bu:
                u, bu = v, best[v]
        used[u] = True
        if parent[u] != -1:
            edges.append((bu, parent[u], u))
        ux, uy = pts[u]
        for v in range(n):
            if not used[v]:
                d = math.hypot(ux - pts[v][0], uy - pts[v][1])
                if d < best[v]:
                    best[v], parent[v] = d, u
    return edges

def kruskal_all_pairs(pts):
    n = len(pts)
    pairs = sorted((math.hypot(a[0] - b[0], a[1] - b[1]), i, j) for i, a in enumerate(pts) for j, b in enumerate(pts) if i < j)
    d, out = DSU(n), []
    for w, i, j in pairs:
        if d.union(i, j):
            out.append((w, i, j))
            if len(out) == n - 1:
                break
    return out

def clusters(pts, k):
    edges = sorted(prim_euclid(pts))
    d = DSU(len(pts))
    for w, u, v in edges[:len(pts) - k]:             # keep all but the k-1 heaviest edges
        d.union(u, v)
    spacing = edges[len(pts) - k][0] if k > 1 else math.inf
    return d, spacing

def spacing_brute(pts, d):                           # minimum distance between points in different clusters
    return min((math.hypot(a[0] - b[0], a[1] - b[1]) for i, a in enumerate(pts) for j, b in enumerate(pts)
                if i < j and not d.same(i, j)), default=math.inf)

gen = lambda rng: ([(rng.random(), rng.random()) for _ in range(rng.randint(1, 12))],)
print(stress(lambda p: round(sum(w for w, _, _ in prim_euclid(p)), 9), lambda p: round(sum(w for w, _, _ in kruskal_all_pairs(p)), 9), gen, trials=500))
print(stress(lambda p, k: round(clusters(p, k)[1], 9), lambda p, k: round(spacing_brute(p, clusters(p, k)[0]), 9),
             lambda rng: ((p := gen(rng)[0]), rng.randint(2, max(2, len(p)))), valid=lambda p, k: 2 <= k <= len(p), trials=500))

rng = random.Random(17)
pts = [(rng.random(), rng.random()) for _ in range(3000)]
for name, f in (("dense Prim O(V^2)", prim_euclid), ("Kruskal, all pairs", kruskal_all_pairs)):
    t = time.perf_counter()
    total = sum(w for w, _, _ in f(pts))
    print(f"{name:>20}: MST weight {total:.6f} in {time.perf_counter() - t:.1f} s")
print(f"weight / sqrt(n) = {total / math.sqrt(len(pts)):.3f}")
for k in (2, 5, 20):
    d, s = clusters(pts, k)
    sizes = sorted((sum(1 for i in range(len(pts)) if d.find(i) == r) for r in {d.find(i) for i in range(len(pts))}), reverse=True)
    print(f"k={k:>2}: spacing {s:.4f}, cluster sizes {sizes[:6]}{' ...' if len(sizes) > 6 else ''}")
