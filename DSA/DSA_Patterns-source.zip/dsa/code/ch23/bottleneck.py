# file: bottleneck.py
from check import stress
from dsu import DSU
from kruskal import kruskal

def minimax(n, edges, s, t):                         # minimise the maximum edge weight on an s-t path
    if s == t:
        return 0
    d = DSU(n)
    for w, u, v in sorted((w, u, v) for u, v, w in edges):
        d.union(u, v)
        if d.same(s, t):
            return w
    return None

def minimax_brute(n, edges, s, t):                   # try thresholds in increasing order
    if s == t:
        return 0
    for limit in sorted({w for _, _, w in edges}):
        d = DSU(n)
        for u, v, w in edges:
            if w <= limit:
                d.union(u, v)
        if d.same(s, t):
            return limit
    return 0 if s == t else None

def classify(n, edges):
    base, _ = kruskal(n, edges)
    critical, pseudo = [], []
    for i, (u, v, w) in enumerate(edges):
        without, _ = kruskal(n, edges[:i] + edges[i + 1:])
        if without is None or without > base:
            critical.append(i)
            continue
        d = DSU(n)                                   # force edge i first
        d.union(u, v)
        total = w
        for ww, a, b in sorted((ww, a, b) for a, b, ww in edges):
            if d.union(a, b):
                total += ww
        if total == base:
            pseudo.append(i)
    return critical, pseudo

gen = lambda rng: ((n := rng.randint(1, 6)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 9)) for _ in range(rng.randint(0, 9))], 0, n - 1)
print(stress(minimax, minimax_brute, gen))
print(classify(5, [(0, 1, 1), (1, 2, 1), (2, 3, 2), (0, 3, 2), (0, 4, 3), (3, 4, 3), (1, 4, 6)]))
