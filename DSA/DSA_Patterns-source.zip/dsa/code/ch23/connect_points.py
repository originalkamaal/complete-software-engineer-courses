# file: connect_points.py
from itertools import combinations
from check import stress

def min_cost(points):
    n = len(points)
    in_tree, best, total = [False] * n, [float("inf")] * n, 0
    best[0] = 0
    for _ in range(n):
        u = min((i for i in range(n) if not in_tree[i]), key=best.__getitem__)
        in_tree[u] = True
        total += best[u]
        for v in range(n):
            if not in_tree[v]:
                d = abs(points[u][0] - points[v][0]) + abs(points[u][1] - points[v][1])
                if d < best[v]:
                    best[v] = d
    return total

def kruskal(points):
    edges = sorted((abs(a[0] - b[0]) + abs(a[1] - b[1]), i, j)
                   for (i, a), (j, b) in combinations(enumerate(points), 2))
    parent = list(range(len(points)))
    def find(x):
        while parent[x] != x:
            x = parent[x]
        return x
    total = 0
    for w, i, j in edges:
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[ri] = rj
            total += w
    return total

def gen(rng):
    return ([(rng.randint(-10, 10), rng.randint(-10, 10)) for _ in range(rng.randint(1, 8))],)

print(min_cost([(0, 0), (2, 2), (3, 10), (5, 2), (7, 0)]))
print(stress(min_cost, kruskal, gen))
