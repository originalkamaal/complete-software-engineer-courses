# file: kruskal.py
from itertools import combinations
from check import stress
from dsu import DSU

def kruskal(n, edges):                            # returns (total weight, chosen edges) or (None, ...) if disconnected
    d, total, chosen = DSU(n), 0, []
    for w, u, v in sorted((w, u, v) for u, v, w in edges):
        if d.union(u, v):
            total += w
            chosen.append((u, v, w))
            if len(chosen) == n - 1:
                break
    return (total if len(chosen) == n - 1 else None), chosen

def brute(n, edges):                               # try every subset of n - 1 edges
    best = None
    for subset in combinations(edges, n - 1):
        d = DSU(n)
        if all(d.union(u, v) for u, v, _ in subset):
            w = sum(w for _, _, w in subset)
            best = w if best is None else min(best, w)
    return best if n > 1 else 0

gen = lambda rng: ((n := rng.randint(1, 6)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 9)) for _ in range(rng.randint(0, 9))])
if __name__ == "__main__":
    print(stress(lambda n, e: kruskal(n, e)[0], brute, gen))
    print(kruskal(4, [(0, 1, 1), (1, 2, 2), (0, 2, 3), (2, 3, 4), (1, 3, 5)]))
