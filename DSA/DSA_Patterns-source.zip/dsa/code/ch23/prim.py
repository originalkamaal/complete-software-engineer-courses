# file: prim.py
import heapq
from check import stress
from kruskal import kruskal

def prim_heap(n, edges):
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((w, v)); adj[v].append((w, u))
    in_tree, total, h, count = [False] * n, 0, [(0, 0)], 0
    while h and count < n:
        w, u = heapq.heappop(h)
        if in_tree[u]:
            continue
        in_tree[u], total, count = True, total + w, count + 1
        for e in adj[u]:
            if not in_tree[e[1]]:
                heapq.heappush(h, e)
    return total if count == n else None

def prim_dense(points):                             # complete graph, Manhattan distances
    n = len(points)
    INF = float("inf")
    best, in_tree, total = [INF] * n, [False] * n, 0
    best[0] = 0
    for _ in range(n):
        u = min((v for v in range(n) if not in_tree[v]), key=best.__getitem__)
        in_tree[u] = True
        total += best[u]
        ux, uy = points[u]
        for v in range(n):
            if not in_tree[v]:
                d = abs(ux - points[v][0]) + abs(uy - points[v][1])
                if d < best[v]:
                    best[v] = d
    return total

def all_pairs(points):
    return [(i, j, abs(a[0] - b[0]) + abs(a[1] - b[1])) for i, a in enumerate(points) for j, b in enumerate(points) if i < j]

gen = lambda rng: ((n := rng.randint(1, 7)), [(rng.randrange(n), rng.randrange(n), rng.randint(1, 9)) for _ in range(rng.randint(0, 12))])
if __name__ == "__main__":
    print(stress(prim_heap, lambda n, e: kruskal(n, e)[0], gen))
    print(stress(prim_dense, lambda p: kruskal(len(p), all_pairs(p))[0],
                 lambda rng: ([(rng.randint(-20, 20), rng.randint(-20, 20)) for _ in range(rng.randint(1, 9))],)))
