# file: matrix_kth.py
import heapq
from check import stress

def kth_smallest(m, k):
    heap = [(row[0], r, 0) for r, row in enumerate(m)]
    heapq.heapify(heap)
    for _ in range(k - 1):
        v, r, c = heapq.heappop(heap)
        if c + 1 < len(m[r]):
            heapq.heappush(heap, (m[r][c + 1], r, c + 1))
    return heap[0][0]

def gen(rng):
    n = rng.randint(1, 5)
    m = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            m[i][j] = max(m[i - 1][j] if i else 0, m[i][j - 1] if j else 0) + rng.randint(0, 3)
    return m, rng.randint(1, n * n)

print(kth_smallest([[1, 5, 9], [10, 11, 13], [12, 13, 15]], 8))
print(stress(kth_smallest, lambda m, k: sorted(x for row in m for x in row)[k - 1], gen))
