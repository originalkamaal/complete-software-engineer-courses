# file: median.py
import heapq
import statistics
from check import stress, rand_list

class RunningMedian:
    def __init__(self):
        self.lo, self.hi = [], []                   # lo: max-heap via negation
    def add(self, x):
        heapq.heappush(self.lo, -x)
        heapq.heappush(self.hi, -heapq.heappop(self.lo))     # largest of lo moves to hi
        if len(self.hi) > len(self.lo):
            heapq.heappush(self.lo, -heapq.heappop(self.hi))  # rebalance: lo keeps the extra
    def median(self):
        if len(self.lo) > len(self.hi):
            return -self.lo[0]
        return (-self.lo[0] + self.hi[0]) / 2

def medians(a):
    rm, out = RunningMedian(), []
    for x in a:
        rm.add(x)
        out.append(rm.median())
    return out

print(stress(medians, lambda a: [statistics.median(a[:i + 1]) for i in range(len(a))], lambda rng: (rand_list(rng, -9, 9, 20),)))
