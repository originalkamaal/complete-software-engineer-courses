# file: k_pairs.py
import heapq
from check import stress

def k_smallest_pairs(a, b, k):
    if not a or not b:
        return []
    heap = [(a[i] + b[0], i, 0) for i in range(min(k, len(a)))]
    heapq.heapify(heap)
    out = []
    while heap and len(out) < k:
        s, i, j = heapq.heappop(heap)
        out.append(s)
        if j + 1 < len(b):
            heapq.heappush(heap, (a[i] + b[j + 1], i, j + 1))
    return out

def brute(a, b, k):
    return sorted(x + y for x in a for y in b)[:k]

def gen(rng):
    return sorted(rng.choices(range(10), k=rng.randint(0, 5))), sorted(rng.choices(range(10), k=rng.randint(0, 5))), rng.randint(1, 12)

print(stress(k_smallest_pairs, brute, gen))
