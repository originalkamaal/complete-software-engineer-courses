# file: heap_basics.py
import heapq
from check import stress, rand_list

class MinHeap:                                      # what heapq does, written out
    def __init__(self):
        self.h = []
    def push(self, x):
        h = self.h
        h.append(x)
        i = len(h) - 1
        while i and h[(i - 1) // 2] > h[i]:         # sift up
            h[i], h[(i - 1) // 2] = h[(i - 1) // 2], h[i]
            i = (i - 1) // 2
    def pop(self):
        h = self.h
        top, last = h[0], h.pop()
        if h:
            h[0], i = last, 0
            while True:                             # sift down
                c = 2 * i + 1
                if c >= len(h):
                    break
                if c + 1 < len(h) and h[c + 1] < h[c]:
                    c += 1                          # smaller child
                if h[i] <= h[c]:
                    break
                h[i], h[c] = h[c], h[i]
                i = c
        return top

def heap_sort_with(ops_values):
    hp = MinHeap()
    for v in ops_values:
        hp.push(v)
    return [hp.pop() for _ in ops_values]

print(stress(heap_sort_with, sorted, lambda rng: (rand_list(rng, -9, 9, 20),)))

tasks = []
for prio, name in [(2, "write"), (1, "plan"), (2, "test"), (3, "ship")]:
    heapq.heappush(tasks, (prio, len(tasks), name))  # counter breaks ties: never compares names
print([heapq.heappop(tasks)[2] for _ in range(4)])
mx = []
for x in [5, 1, 9, 3]:
    heapq.heappush(mx, -x)                           # max-heap by negation
print("max:", -mx[0])
