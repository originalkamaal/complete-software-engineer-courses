# file: kway.py
import heapq
from check import stress, rand_list

def merge_k(lists):
    h = [(lst[0], i, 0) for i, lst in enumerate(lists) if lst]
    heapq.heapify(h)
    out = []
    while h:
        v, i, j = heapq.heappop(h)
        out.append(v)
        if j + 1 < len(lists[i]):
            heapq.heappush(h, (lists[i][j + 1], i, j + 1))
    return out

def smallest_range(lists):                          # [lo, hi] containing at least one element of each list
    h = [(lst[0], i, 0) for i, lst in enumerate(lists)]
    heapq.heapify(h)
    hi = max(lst[0] for lst in lists)
    best = (h[0][0], hi)
    while True:
        lo, i, j = heapq.heappop(h)
        if hi - lo < best[1] - best[0]:
            best = (lo, hi)
        if j + 1 == len(lists[i]):
            return best                             # this list is exhausted: lo cannot increase further
        nxt = lists[i][j + 1]
        hi = max(hi, nxt)
        heapq.heappush(h, (nxt, i, j + 1))

def smallest_range_brute(lists):
    vals = sorted({v for l in lists for v in l})
    best = None
    for lo in vals:
        for hi in vals:
            if hi >= lo and all(any(lo <= v <= hi for v in l) for l in lists):
                if best is None or (hi - lo, lo) < (best[1] - best[0], best[0]):
                    best = (lo, hi)
    return best

def gen(rng):
    return ([sorted(rand_list(rng, -9, 9, 5, 1)) for _ in range(rng.randint(1, 4))],)

print(stress(merge_k, lambda ls: sorted(v for l in ls for v in l), gen))
print(stress(lambda ls: smallest_range(ls)[1] - smallest_range(ls)[0], lambda ls: (lambda b: b[1] - b[0])(smallest_range_brute(ls)), gen))
print(merge_k([[1, 4, 7], [2, 5], [0, 9]]), smallest_range([[4, 10, 15, 24, 26], [0, 9, 12, 20], [5, 18, 22, 30]]))
