# file: winmedian/winmedian.py
import heapq
import random
import time
from collections import Counter
from check import stress, rand_list
from sortedcontainers import SortedList

def window_medians(a, k):
    lo, hi = [], []                                  # lo: max-heap (negated), hi: min-heap
    pending = Counter()
    def prune(h, sign):
        while h and pending[sign * h[0]]:
            pending[sign * h[0]] -= 1
            heapq.heappop(h)
    for x in a[:k]:
        heapq.heappush(lo, -x)
    for _ in range(k // 2):                          # move the larger half to hi
        heapq.heappush(hi, -heapq.heappop(lo))
    med = lambda: float(-lo[0]) if k % 2 else (-lo[0] + hi[0]) / 2
    out = [med()]
    for i in range(k, len(a)):
        x, gone = a[i], a[i - k]
        balance = 0                                  # (valid in lo) - (valid in hi) change
        pending[gone] += 1
        balance += -1 if gone <= -lo[0] else 1       # which side lost an element
        if lo and x <= -lo[0]:
            heapq.heappush(lo, -x); balance += 1
        else:
            heapq.heappush(hi, x); balance -= 1
        if balance < 0:                              # lo lost one more than it gained
            heapq.heappush(lo, -heapq.heappop(hi))
        elif balance > 0:
            heapq.heappush(hi, -heapq.heappop(lo))
        prune(lo, -1)
        prune(hi, 1)
        out.append(med())
    return out

def medians_sl(a, k):
    s, out = SortedList(a[:k]), []
    out.append((s[(k - 1) // 2] + s[k // 2]) / 2)
    for i in range(k, len(a)):
        s.remove(a[i - k]); s.add(a[i])
        out.append((s[(k - 1) // 2] + s[k // 2]) / 2)
    return out

def brute(a, k):
    return [(sorted(a[i:i + k])[(k - 1) // 2] + sorted(a[i:i + k])[k // 2]) / 2 for i in range(len(a) - k + 1)]

print(stress(window_medians, brute, lambda rng: ((a := rand_list(rng, -4, 4, 14, 1)), rng.randint(1, len(a)))))
rng = random.Random(9)
a = [rng.randint(-10**9, 10**9) for _ in range(200_000)]
for name, f in (("two heaps", window_medians), ("SortedList", medians_sl)):
    t = time.perf_counter()
    m = f(a, 1001)
    print(f"{name:>10}: n=200,000, k=1001 in {(time.perf_counter() - t) * 1000:.0f} ms (checksum {sum(m):.1f})")
