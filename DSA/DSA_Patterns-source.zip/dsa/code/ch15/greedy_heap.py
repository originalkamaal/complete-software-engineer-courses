# file: greedy_heap.py
import heapq
from collections import Counter
from itertools import permutations
from check import stress, rand_list

def min_rooms(intervals):
    ends = []
    for s, e in sorted(intervals):
        if ends and ends[0] <= s:
            heapq.heapreplace(ends, e)               # reuse the room that frees up first
        else:
            heapq.heappush(ends, e)
    return len(ends)

def max_capital(k, w, profits, capital):
    projects = sorted(zip(capital, profits))
    avail, i = [], 0
    for _ in range(k):
        while i < len(projects) and projects[i][0] <= w:
            heapq.heappush(avail, -projects[i][1])  # newly affordable
            i += 1
        if not avail:
            break
        w -= heapq.heappop(avail)
    return w

def reorganize(s):                                   # no two adjacent equal; "" if impossible
    h = [(-c, ch) for ch, c in Counter(s).items()]
    heapq.heapify(h)
    out, prev = [], None
    while h:
        c, ch = heapq.heappop(h)
        out.append(ch)
        if prev:
            heapq.heappush(h, prev)                  # previous char is allowed again
        prev = (c + 1, ch) if c + 1 < 0 else None
    return "".join(out) if not prev else ""

def rooms_brute(iv):
    return max((sum(s <= t < e for s, e in iv) for t in {s for s, _ in iv}), default=0)

def capital_brute(k, w, profits, capital):
    best = w
    def go(w, used, left):
        nonlocal best
        best = max(best, w)
        if left:
            for i in range(len(profits)):
                if i not in used and capital[i] <= w:
                    go(w + profits[i], used | {i}, left - 1)
    go(w, frozenset(), k)
    return best

def reorg_ok(s, r):
    if r == "" and s:                                # claimed impossible: check every arrangement
        return all(any(a == b for a, b in zip(p, p[1:])) for p in set(permutations(s)))
    return sorted(r) == sorted(s) and all(a != b for a, b in zip(r, r[1:]))

print(stress(min_rooms, rooms_brute, lambda rng: ([(s := rng.randint(0, 9), s + rng.randint(1, 5)) for _ in range(rng.randint(0, 8))],)))
print(stress(max_capital, capital_brute, lambda rng: (rng.randint(1, 3), rng.randint(0, 3), (p := rand_list(rng, 1, 5, 5, 1)), [rng.randint(0, 6) for _ in p]), trials=800))
print(stress(lambda s: reorg_ok(s, reorganize(s)), lambda s: True, lambda rng: ("".join(rng.choice("aab") for _ in range(rng.randint(0, 7))),), trials=800))
