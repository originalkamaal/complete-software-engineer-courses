# file: topk.py
import heapq
from collections import Counter
from check import stress, rand_list

def k_largest(stream, k):
    h = []
    for x in stream:
        if len(h) < k:
            heapq.heappush(h, x)
        elif x > h[0]:
            heapq.heapreplace(h, x)                 # pop root and push x in one sift
    return sorted(h, reverse=True)

def top_k_frequent(words, k):                       # ties: alphabetical
    cnt = Counter(words)
    return [w for _, w in heapq.nsmallest(k, ((-c, w) for w, c in cnt.items()))]

def k_closest(points, k):                           # to the origin
    return heapq.nsmallest(k, points, key=lambda p: p[0] ** 2 + p[1] ** 2)

print(stress(k_largest, lambda a, k: sorted(a, reverse=True)[:k], lambda rng: (rand_list(rng, -9, 9, 20), rng.randint(1, 5))))
print(stress(top_k_frequent, lambda ws, k: sorted(Counter(ws), key=lambda w: (-Counter(ws)[w], w))[:k],
             lambda rng: ([rng.choice("abcde") for _ in range(rng.randint(1, 15))], rng.randint(1, 3))))
print(k_closest([(1, 3), (-2, 2), (5, 8), (0, 1)], 2))
