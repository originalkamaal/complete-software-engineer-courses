# file: jugs.py
from collections import deque
from math import gcd
from check import stress

def can_measure(x, y, z):
    if z > x + y:
        return False
    if z == 0:
        return True
    return z % gcd(x, y) == 0

def bfs(x, y, z):
    seen, q = {(0, 0)}, deque([(0, 0)])
    while q:
        a, b = q.popleft()
        if a + b == z:
            return True
        pour_ab, pour_ba = min(a, y - b), min(b, x - a)
        for nxt in [(x, b), (a, y), (0, b), (a, 0), (a - pour_ab, b + pour_ab), (a + pour_ba, b - pour_ba)]:
            if nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return False

print(can_measure(3, 5, 4), can_measure(2, 6, 5), can_measure(1, 2, 3))
print(stress(can_measure, bfs, lambda rng: (rng.randint(1, 12), rng.randint(1, 12), rng.randint(0, 25))))
