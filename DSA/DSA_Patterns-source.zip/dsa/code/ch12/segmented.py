# file: segmented.py
import math
from check import stress

def primes_upto(n):
    s = bytearray([1]) * (n + 1)
    s[0:2] = b"\x00\x00"
    for p in range(2, int(n ** 0.5) + 1):
        if s[p]:
            s[p * p::p] = bytes(len(range(p * p, n + 1, p)))
    return [i for i, v in enumerate(s) if v]

def count_primes_range(L, R):
    if R < 2:
        return 0
    L = max(L, 2)
    mark = bytearray([1]) * (R - L + 1)
    for p in primes_upto(math.isqrt(R)):
        start = max(p * p, (L + p - 1) // p * p)       # first multiple of p in [L, R], not p itself
        mark[start - L::p] = bytes(len(range(start, R + 1, p)))
    return sum(mark)

def brute(L, R):
    return sum(1 for n in range(max(L, 2), R + 1) if all(n % d for d in range(2, math.isqrt(n) + 1)))

print(count_primes_range(1, 100), count_primes_range(10 ** 12, 10 ** 12 + 1000))
print(stress(count_primes_range, brute, lambda rng: ((L := rng.randint(0, 300)), L + rng.randint(0, 200))))
