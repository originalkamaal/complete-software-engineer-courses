# file: counting.py
import math
from itertools import product
from check import stress

def stars_and_bars(n, k):
    return math.comb(n + k - 1, k - 1)

def count_divisible(n, divisors):               # how many of 1..n are divisible by at least one divisor
    total = 0
    for mask in range(1, 1 << len(divisors)):
        l, bits = 1, 0
        for i, d in enumerate(divisors):
            if mask >> i & 1:
                l, bits = math.lcm(l, d), bits + 1
        total += (n // l) if bits % 2 else -(n // l)     # + for odd-sized intersections
    return total

def catalan(n):
    return math.comb(2 * n, n) // (n + 1)

def balanced(n):                                # brute force: count balanced strings of n pairs
    return sum(1 for s in product("()", repeat=2 * n)
               if all(s[:i].count("(") >= s[:i].count(")") for i in range(2 * n + 1)) and s.count("(") == n)

print(stress(stars_and_bars, lambda n, k: sum(1 for t in product(range(n + 1), repeat=k) if sum(t) == n),
             lambda rng: (rng.randint(0, 6), rng.randint(1, 4)), trials=300))
print(stress(count_divisible, lambda n, ds: sum(any(x % d == 0 for d in ds) for x in range(1, n + 1)),
             lambda rng: (rng.randint(1, 500), rng.sample(range(2, 15), rng.randint(1, 4))), trials=500))
print([catalan(n) for n in range(10)], [balanced(n) for n in range(7)])
