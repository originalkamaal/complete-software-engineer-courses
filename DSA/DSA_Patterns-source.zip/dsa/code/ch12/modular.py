# file: modular.py
import math
from check import stress

MOD = 10**9 + 7

def power(a, b, m):                             # binary exponentiation, O(log b)
    result, a = 1, a % m
    while b:
        if b & 1:
            result = result * a % m
        a = a * a % m
        b >>= 1
    return result

class Binomial:
    def __init__(self, n, p=MOD):
        self.p = p
        self.fact = [1] * (n + 1)
        for i in range(1, n + 1):
            self.fact[i] = self.fact[i - 1] * i % p
        self.inv = [1] * (n + 1)
        self.inv[n] = pow(self.fact[n], p - 2, p)       # one inverse via Fermat
        for i in range(n, 0, -1):
            self.inv[i - 1] = self.inv[i] * i % p        # then walk down: 1/(i-1)! = i/i!
    def C(self, n, r):
        if r < 0 or r > n:
            return 0
        return self.fact[n] * self.inv[r] % self.p * self.inv[n - r] % self.p

if __name__ == "__main__":
    print(stress(power, lambda a, b, m: pow(a, b, m), lambda rng: (rng.randint(0, 10**12), rng.randint(0, 10**12), rng.randint(1, 10**9))))
    print(stress(lambda a: a * pow(a, -1, MOD) % MOD, lambda a: 1, lambda rng: (rng.randint(1, MOD - 1),)))
    B = Binomial(10**5)
    print(stress(B.C, lambda n, r: math.comb(n, r) % MOD if 0 <= r <= n else 0, lambda rng: ((n := rng.randint(0, 2000)), rng.randint(-2, n + 2))))
    print("C(100000, 50000) mod p =", B.C(10**5, 5 * 10**4))
    print("6/4 == 3/2 mod p:", (6 * pow(4, -1, MOD)) % MOD == (3 * pow(2, -1, MOD)) % MOD, "  int(6/4) =", int(6 / 4))
