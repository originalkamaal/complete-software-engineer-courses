# file: gcd.py
import math
from check import stress

def gcd(a, b):
    while b:
        a, b = b, a % b
    return abs(a)

def ext_gcd(a, b):
    """Return (g, x, y) with a*x + b*y == g == gcd(a, b)."""
    if b == 0:
        return (a, 1, 0)
    g, x, y = ext_gcd(b, a % b)                 # b*x + (a % b)*y == g
    return (g, y, x - (a // b) * y)             # since a % b == a - (a//b)*b

def solve_diophantine(a, b, c):                 # one integer solution of a*x + b*y == c, or None
    g, x, y = ext_gcd(a, b)
    if c % g:
        return None
    return (x * (c // g), y * (c // g))

print(stress(gcd, math.gcd, lambda rng: (rng.randint(0, 10**9), rng.randint(0, 10**9))))
def check_ext(a, b):
    g, x, y = ext_gcd(a, b)
    return g == math.gcd(a, b) and a * x + b * y == g
print(stress(check_ext, lambda a, b: True, lambda rng: (rng.randint(0, 10**6), rng.randint(0, 10**6))))
def check_dio(a, b, c):
    s = solve_diophantine(a, b, c)
    return (s is not None and a * s[0] + b * s[1] == c) or (s is None and c % math.gcd(a, b) != 0)
print(stress(check_dio, lambda a, b, c: True, lambda rng: (rng.randint(1, 50), rng.randint(1, 50), rng.randint(0, 200))))
print("lcm(4, 6) =", 4 // gcd(4, 6) * 6, "  math.lcm(4, 6, 10) =", math.lcm(4, 6, 10))
