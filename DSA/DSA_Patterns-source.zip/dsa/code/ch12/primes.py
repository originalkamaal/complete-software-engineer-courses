# file: primes.py
import time
from check import stress

def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

def sieve(n):                                   # bytearray: compact and fast
    is_p = bytearray([1]) * (n + 1)
    is_p[0:2] = b"\x00\x00"[: min(2, n + 1)]
    for p in range(2, int(n ** 0.5) + 1):
        if is_p[p]:
            is_p[p * p :: p] = bytes(len(range(p * p, n + 1, p)))   # slice assignment: C speed
    return [i for i in range(n + 1) if is_p[i]]

def spf_table(n):
    spf = list(range(n + 1))
    for p in range(2, int(n ** 0.5) + 1):
        if spf[p] == p:
            for m in range(p * p, n + 1, p):
                if spf[m] == m:
                    spf[m] = p
    return spf

def factorise(x, spf):
    out = {}
    while x > 1:
        p = spf[x]
        out[p] = out.get(p, 0) + 1
        x //= p
    return out

def divisor_count(factors):
    c = 1
    for e in factors.values():
        c *= e + 1                              # each exponent 0..e
    return c

print(stress(sieve, lambda n: [i for i in range(n + 1) if is_prime(i)], lambda rng: (rng.randint(0, 300),), trials=300))
spf = spf_table(10**5)
def factor_ok(x):
    f = factorise(x, spf)
    prod = 1
    for p, e in f.items():
        prod *= p ** e
    return prod == x and all(is_prime(p) for p in f)
print(stress(factor_ok, lambda x: True, lambda rng: (rng.randint(2, 10**5),)))
print(stress(lambda x: divisor_count(factorise(x, spf)), lambda x: sum(x % d == 0 for d in range(1, x + 1)), lambda rng: (rng.randint(2, 3000),), trials=300))
t = time.perf_counter()
ps = sieve(10**7)
print(f"primes below 10^7: {len(ps):,} in {(time.perf_counter() - t) * 1000:.0f} ms")
