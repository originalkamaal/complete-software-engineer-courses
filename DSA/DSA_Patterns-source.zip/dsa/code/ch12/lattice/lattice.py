# file: lattice/lattice.py
import random
import time
from check import stress
from modular import Binomial, MOD

def count_paths(H, W, blocked, B):
    pts = sorted(set(blocked)) + [(H - 1, W - 1)]
    def ways(r1, c1, r2, c2):
        if r2 < r1 or c2 < c1:
            return 0
        return B.C((r2 - r1) + (c2 - c1), r2 - r1)
    f = []
    for i, (r, c) in enumerate(pts):
        total = ways(0, 0, r, c)
        for j in range(i):
            rj, cj = pts[j]
            total -= f[j] * ways(rj, cj, r, c)           # first blocked cell on the path is j
        f.append(total % MOD)
    return f[-1] if (H - 1, W - 1) not in set(blocked) and (0, 0) not in set(blocked) else 0

def grid_dp(H, W, blocked):
    bl = set(blocked)
    dp = [[0] * W for _ in range(H)]
    for r in range(H):
        for c in range(W):
            if (r, c) in bl:
                continue
            dp[r][c] = 1 if r == c == 0 else ((dp[r - 1][c] if r else 0) + (dp[r][c - 1] if c else 0)) % MOD
    return dp[H - 1][W - 1]

B = Binomial(2 * 10**5 + 10)
def gen(rng):
    H, W = rng.randint(1, 7), rng.randint(1, 7)
    cells = [(r, c) for r in range(H) for c in range(W)]
    return (H, W, rng.sample(cells, rng.randint(0, min(6, len(cells)))))
print(stress(lambda H, W, bl: count_paths(H, W, bl, B), grid_dp, gen))
rng = random.Random(7)
H = W = 10**5
blocked = [(rng.randint(1, H - 2), rng.randint(1, W - 2)) for _ in range(2000)]
t = time.perf_counter()
r = count_paths(H, W, blocked, B)
print(f"H=W=10^5 with 2,000 obstacles: {r} paths (mod p) in {(time.perf_counter() - t) * 1000:.0f} ms")
