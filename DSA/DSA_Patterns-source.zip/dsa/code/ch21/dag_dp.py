# file: dag_dp.py
from itertools import permutations
from check import stress
from kahn import topo_kahn

def longest_path(n, edges):                         # weighted edges (u, v, w); length of the longest path
    order = topo_kahn(n, [(u, v) for u, v, _ in edges])
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((v, w))
    best = [0] * n                                   # longest path ending at each vertex
    for u in order:
        for v, w in adj[u]:
            best[v] = max(best[v], best[u] + w)
    return max(best, default=0)

def count_paths(n, edges, s, t, mod=10**9 + 7):
    order = topo_kahn(n, edges)
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
    ways = [0] * n
    ways[s] = 1
    for u in order:
        for v in adj[u]:
            ways[v] = (ways[v] + ways[u]) % mod
    return ways[t]

def random_dag(rng, weighted):
    n = rng.randint(1, 7)
    perm = list(range(n)); rng.shuffle(perm)        # hidden order: edges go forward in it
    edges = []
    for _ in range(rng.randint(0, 10)):
        i, j = sorted(rng.sample(range(n), 2)) if n > 1 else (0, 0)
        if i != j:
            edges.append((perm[i], perm[j], rng.randint(1, 9)) if weighted else (perm[i], perm[j]))
    return n, edges

def all_paths(n, edges, s, t):
    adj = [[] for _ in range(n)]
    for e in edges:
        adj[e[0]].append(e)
    out = []
    def go(u, acc):
        if u == t: out.append(acc)
        for e in adj[u]:
            go(e[1], acc + (e[2] if len(e) == 3 else 1))
    go(s, 0)
    return out

if __name__ == "__main__":
    print(stress(longest_path, lambda n, e: max((max(all_paths(n, e, s, t), default=0) for s in range(n) for t in range(n)), default=0),
                 lambda rng: random_dag(rng, True)))
    print(stress(count_paths, lambda n, e, s, t: len(all_paths(n, e, s, t)),
                 lambda rng: (*(g := random_dag(rng, False)), rng.randrange(g[0]), rng.randrange(g[0]))))
