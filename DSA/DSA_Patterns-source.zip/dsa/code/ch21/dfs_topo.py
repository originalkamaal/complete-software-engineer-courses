# file: dfs_topo.py
from check import stress
from kahn import topo_kahn, valid_order

WHITE, GRAY, BLACK = 0, 1, 2

def topo_or_cycle(n, edges):
    """Return ("order", order) or ("cycle", [v0, v1, ..., v0])."""
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
    color, parent, post = [WHITE] * n, [-1] * n, []
    for s in range(n):
        if color[s] != WHITE:
            continue
        stack = [(s, iter(adj[s]))]
        color[s] = GRAY
        while stack:
            u, it = stack[-1]
            v = next(it, None)
            if v is None:                            # all neighbours done: finish u
                color[u] = BLACK
                post.append(u)
                stack.pop()
            elif color[v] == WHITE:
                parent[v] = u
                color[v] = GRAY
                stack.append((v, iter(adj[v])))
            elif color[v] == GRAY:                    # back edge u -> v: walk parents from u back to v
                cycle = [v, u]
                while cycle[-1] != v:
                    cycle.append(parent[cycle[-1]])
                return "cycle", cycle[::-1]          # v -> ... -> u -> v
    return "order", post[::-1]

def check(n, edges):
    kind, res = topo_or_cycle(n, edges)
    eset = set(edges)
    if kind == "order":
        return valid_order(n, edges, res)
    return res[0] == res[-1] and all((a, b) in eset for a, b in zip(res, res[1:]))

if __name__ == "__main__":
    print(stress(lambda n, e: (topo_or_cycle(n, e)[0], check(n, e)), lambda n, e: ("order" if topo_kahn(n, e) is not None else "cycle", True),
                 lambda rng: ((n := rng.randint(1, 7)), [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 8))])))
    print(topo_or_cycle(5, [(0, 1), (1, 2), (2, 3), (3, 1), (3, 4)]))
