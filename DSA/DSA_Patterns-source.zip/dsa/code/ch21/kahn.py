# file: kahn.py
import heapq
from collections import deque
from itertools import permutations
from check import stress

def topo_kahn(n, edges):                         # edge (u, v): u must come before v; None if cyclic
    adj, indeg = [[] for _ in range(n)], [0] * n
    for u, v in edges:
        adj[u].append(v); indeg[v] += 1
    q = deque(i for i in range(n) if indeg[i] == 0)
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    return order if len(order) == n else None

def topo_smallest(n, edges):                     # lexicographically smallest order: heap instead of queue
    adj, indeg = [[] for _ in range(n)], [0] * n
    for u, v in edges:
        adj[u].append(v); indeg[v] += 1
    h = [i for i in range(n) if indeg[i] == 0]
    heapq.heapify(h)
    order = []
    while h:
        u = heapq.heappop(h)
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                heapq.heappush(h, v)
    return order if len(order) == n else None

def valid_order(n, edges, order):
    pos = {v: i for i, v in enumerate(order)}
    return sorted(order) == list(range(n)) and all(pos[u] < pos[v] for u, v in edges)

def brute_smallest(n, edges):
    return next((list(p) for p in permutations(range(n)) if valid_order(n, edges, p)), None)

def gen(rng):
    n = rng.randint(1, 6)
    return (n, [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 7))])

if __name__ == "__main__":
    print(stress(lambda n, e: (o := topo_kahn(n, e)) is not None and valid_order(n, e, o), lambda n, e: brute_smallest(n, e) is not None, gen))
    print(stress(topo_smallest, brute_smallest, gen))
    print(topo_kahn(4, [(0, 1), (0, 2), (1, 3), (2, 3)]), topo_kahn(3, [(0, 1), (1, 2), (2, 0)]))
