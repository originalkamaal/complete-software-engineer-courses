# file: scheduler/scheduler.py
import heapq
import random
import time
from check import stress
from kahn import topo_kahn
from dfs_topo import topo_or_cycle

def critical_path(dur, deps):                       # deps[v] = list of prerequisites of v
    n = len(dur)
    edges = [(u, v) for v in range(n) for u in deps[v]]
    kind, res = topo_or_cycle(n, edges)
    if kind == "cycle":
        return None, res
    finish, via = [0] * n, [-1] * n
    for v in res:                                    # topological order
        start = 0
        for u in deps[v]:
            if finish[u] > start:
                start, via[v] = finish[u], u
        finish[v] = start + dur[v]
    end = max(range(n), key=lambda v: finish[v])
    path = []
    while end != -1:
        path.append(end); end = via[end]
    return max(finish), path[::-1]

def tail_lengths(dur, deps):                         # longest path from v to the end, including v
    n = len(dur)
    succ = [[] for _ in range(n)]
    for v in range(n):
        for u in deps[v]:
            succ[u].append(v)
    order = topo_kahn(n, [(u, v) for v in range(n) for u in deps[v]])
    tail = [0] * n
    for u in reversed(order):
        tail[u] = dur[u] + max((tail[v] for v in succ[u]), default=0)
    return tail

def list_schedule(dur, deps, p):
    n = len(dur)
    tail = tail_lengths(dur, deps)
    succ, waiting = [[] for _ in range(n)], [len(deps[v]) for v in range(n)]
    for v in range(n):
        for u in deps[v]:
            succ[u].append(v)
    ready = [(-tail[v], v) for v in range(n) if waiting[v] == 0]
    heapq.heapify(ready)
    running, t, free, done = [], 0, p, 0             # running: (finish time, task)
    while done < n:
        while ready and free:
            _, v = heapq.heappop(ready)
            heapq.heappush(running, (t + dur[v], v)); free -= 1
        t, v = heapq.heappop(running)
        free += 1; done += 1
        for w in succ[v]:
            waiting[w] -= 1
            if waiting[w] == 0:
                heapq.heappush(ready, (-tail[w], w))
    return t

def simulate_unlimited(dur, deps):                   # brute: repeatedly start everything that is ready
    n, finish = len(dur), {}
    while len(finish) < n:
        progress = False
        for v in range(n):
            if v not in finish and all(u in finish for u in deps[v]):
                finish[v] = max((finish[u] for u in deps[v]), default=0) + dur[v]; progress = True
        if not progress:
            return None
    return max(finish.values(), default=0)

def gen(rng):
    n = rng.randint(1, 8)
    dur = [rng.randint(1, 9) for _ in range(n)]
    deps = [sorted(set(rng.sample(range(v), rng.randint(0, min(v, 3))))) if v else [] for v in range(n)]
    perm = list(range(n)); rng.shuffle(perm)
    inv = {old: new for new, old in enumerate(perm)}
    dur2, deps2 = [0] * n, [[] for _ in range(n)]
    for v in range(n):
        dur2[inv[v]] = dur[v]; deps2[inv[v]] = [inv[u] for u in deps[v]]
    return (dur2, deps2)

print(stress(lambda d, dp: critical_path(d, dp)[0], simulate_unlimited, gen))
print(stress(lambda d, dp: list_schedule(d, dp, 10**6), lambda d, dp: critical_path(d, dp)[0], gen))   # p = infinity
print(critical_path([3, 2, 4], [[2], [0], [1]]))    # a cycle 0 -> 1 -> 2 -> 0

rng = random.Random(15)
n = 20_000
dur = [rng.randint(1, 100) for _ in range(n)]
deps = [sorted(set(rng.sample(range(max(0, v - 200), v), min(v, rng.randint(0, 4))))) for v in range(n)]
t = time.perf_counter()
length, path = critical_path(dur, deps)
print(f"{n:,} tasks: critical path {length:,} through {len(path)} tasks; total work {sum(dur):,}  [{(time.perf_counter() - t) * 1000:.0f} ms]")
for p in (4, 16, 64, 256):
    t = time.perf_counter()
    mk = list_schedule(dur, deps, p)
    lower = max(length, -(-sum(dur) // p))
    print(f"  p={p:>3} workers: makespan {mk:,}  (lower bound {lower:,}, ratio {mk / lower:.3f})  [{(time.perf_counter() - t) * 1000:.0f} ms]")
