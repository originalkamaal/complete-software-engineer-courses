# file: alien.py
from itertools import permutations
from check import stress
from kahn import topo_smallest

def alien_order(words):
    letters = sorted(set("".join(words)))
    idx = {ch: i for i, ch in enumerate(letters)}
    edges = set()
    for a, b in zip(words, words[1:]):
        for x, y in zip(a, b):
            if x != y:
                edges.add((idx[x], idx[y]))
                break
        else:
            if len(a) > len(b):
                return None                          # "abc" before "ab": impossible
    order = topo_smallest(len(letters), sorted(edges))
    return None if order is None else "".join(letters[i] for i in order)

def consistent(words, alphabet):
    rank = {ch: i for i, ch in enumerate(alphabet)}
    key = lambda w: [rank[c] for c in w]
    return all(key(a) <= key(b) for a, b in zip(words, words[1:]))

def brute(words):
    letters = sorted(set("".join(words)))
    return next(("".join(p) for p in permutations(letters) if consistent(words, p)), None)

def gen(rng):
    letters = "abcd"
    hidden = list(letters); rng.shuffle(hidden)
    rank = {c: i for i, c in enumerate(hidden)}
    words = ["".join(rng.choice(letters) for _ in range(rng.randint(1, 3))) for _ in range(rng.randint(1, 5))]
    words.sort(key=lambda w: [rank[c] for c in w])
    if rng.random() < 0.2 and len(words) > 1:
        rng.shuffle(words)                           # sometimes inconsistent
    return (words,)

print(stress(alien_order, brute, gen))
print(alien_order(["wrt", "wrf", "er", "ett", "rftt"]), alien_order(["abc", "ab"]))
