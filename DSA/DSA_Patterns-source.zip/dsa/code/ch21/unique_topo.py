# file: unique_topo.py
from collections import deque
from itertools import permutations
from check import stress

def unique_order(n, edges):
    indeg, adj = [0] * n, [[] for _ in range(n)]
    for a, b in edges:
        adj[a].append(b)
        indeg[b] += 1
    q = deque(v for v in range(n) if indeg[v] == 0)
    seen = 0
    while q:
        if len(q) > 1:
            return False                     # two choices at this step: more than one order
        v = q.popleft()
        seen += 1
        for w in adj[v]:
            indeg[w] -= 1
            if indeg[w] == 0:
                q.append(w)
    return seen == n                         # a cycle means no order at all

def brute(n, edges):
    valid = [p for p in permutations(range(n)) if all(p.index(a) < p.index(b) for a, b in edges)]
    return len(valid) == 1

def gen(rng):
    n = rng.randint(1, 5)
    edges = {(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 7))}
    return n, [(a, b) for a, b in edges if a != b]

print(unique_order(3, [(0, 1), (1, 2)]), unique_order(3, [(0, 1), (0, 2)]))
print(stress(unique_order, brute, gen))
