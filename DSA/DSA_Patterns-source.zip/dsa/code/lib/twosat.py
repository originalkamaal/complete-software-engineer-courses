# file: ../lib/twosat.py
"""2-SAT: variables 0..n-1; literal 2*i = x_i, 2*i+1 = not x_i."""
from scc import scc

class TwoSat:
    def __init__(self, n):
        self.n, self.edges = n, []
    @staticmethod
    def lit(i, value=True):
        return 2 * i + (0 if value else 1)
    def either(self, a, b):                            # clause (a or b), literals as from lit()
        self.edges.append((a ^ 1, b))                   # not a -> b
        self.edges.append((b ^ 1, a))                   # not b -> a
    def implies(self, a, b):
        self.either(a ^ 1, b)
    def solve(self):
        comp = scc(2 * self.n, self.edges)
        res = []
        for i in range(self.n):
            if comp[2 * i] == comp[2 * i + 1]:
                return None
            res.append(comp[2 * i] > comp[2 * i + 1])
        return res
