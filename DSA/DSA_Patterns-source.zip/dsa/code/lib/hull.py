# file: ../lib/hull.py
from geom import cross

def convex_hull(points):
    """Counter-clockwise hull without collinear points; first point not repeated."""
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts
    def half(seq):
        h = []
        for p in seq:
            while len(h) >= 2 and cross(h[-2], h[-1], p) <= 0:
                h.pop()
            h.append(p)
        return h
    lower, upper = half(pts), half(reversed(pts))
    return lower[:-1] + upper[:-1]
