# file: ../lib/segtree.py
"""Iterative segment tree over a monoid (op, identity). Half-open ranges [l, r)."""

class SegTree:
    def __init__(self, data, op, identity):
        self.n = n = len(data)
        self.op, self.e = op, identity
        self.t = [identity] * n + list(data)
        for i in range(n - 1, 0, -1):
            self.t[i] = op(self.t[2 * i], self.t[2 * i + 1])

    def update(self, i, value):
        i += self.n
        self.t[i] = value
        while i > 1:
            i //= 2
            self.t[i] = self.op(self.t[2 * i], self.t[2 * i + 1])

    def query(self, l, r):
        """Combine data[l:r] in order (works for non-commutative ops too)."""
        resl, resr = self.e, self.e
        l += self.n; r += self.n
        while l < r:
            if l & 1:
                resl = self.op(resl, self.t[l]); l += 1
            if r & 1:
                r -= 1; resr = self.op(self.t[r], resr)
            l //= 2; r //= 2
        return self.op(resl, resr)

    def get(self, i):
        return self.t[i + self.n]
