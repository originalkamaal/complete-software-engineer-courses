# file: ../lib/aho.py
"""Aho–Corasick automaton: all occurrences of many patterns in one pass."""
from collections import deque

class AhoCorasick:
    def __init__(self, patterns):
        self.goto = [{}]          # trie edges
        self.fail = [0]
        self.out = [[]]           # pattern ids ending exactly at this node
        self.dict_link = [-1]     # nearest node on the fail chain with non-empty out
        self.patterns = patterns
        for pid, p in enumerate(patterns):
            node = 0
            for ch in p:
                if ch not in self.goto[node]:
                    self.goto[node][ch] = len(self.goto)
                    self.goto.append({}); self.fail.append(0); self.out.append([]); self.dict_link.append(-1)
                node = self.goto[node][ch]
            self.out[node].append(pid)
        q = deque(self.goto[0].values())                 # depth-1 nodes fail to the root
        while q:
            u = q.popleft()
            for ch, v in self.goto[u].items():
                f = self.fail[u]
                while f and ch not in self.goto[f]:
                    f = self.fail[f]
                self.fail[v] = self.goto[f].get(ch, 0) if self.goto[f].get(ch, 0) != v else 0
                fv = self.fail[v]
                self.dict_link[v] = fv if self.out[fv] else self.dict_link[fv]
                q.append(v)

    def find_all(self, text):
        """Yield (end_index_exclusive, pattern_id) for every occurrence."""
        node = 0
        for i, ch in enumerate(text):
            while node and ch not in self.goto[node]:
                node = self.fail[node]
            node = self.goto[node].get(ch, 0)
            m = node if self.out[node] else self.dict_link[node]
            while m > 0:
                for pid in self.out[m]:
                    yield i + 1, pid
                m = self.dict_link[m]
