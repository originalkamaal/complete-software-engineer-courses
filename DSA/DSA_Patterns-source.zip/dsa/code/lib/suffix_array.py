# file: ../lib/suffix_array.py
"""Suffix array by prefix doubling (O(n log^2 n) with Python's sort; simple and fast enough) and Kasai LCP."""

def suffix_array(s):
    n = len(s)
    if n == 0:
        return []
    rank = [ord(c) for c in s]
    sa = list(range(n))
    k = 1
    while True:
        key = lambda i: (rank[i], rank[i + k] if i + k < n else -1)
        sa.sort(key=key)
        new = [0] * n
        for j in range(1, n):
            new[sa[j]] = new[sa[j - 1]] + (key(sa[j]) != key(sa[j - 1]))
        rank = new
        if rank[sa[-1]] == n - 1:                      # all ranks distinct: done
            return sa
        k *= 2

def lcp_array(s, sa):                                  # lcp[i] = LCP(suffix sa[i], suffix sa[i+1])
    n = len(s)
    rank = [0] * n
    for i, p in enumerate(sa):
        rank[p] = i
    lcp, h = [0] * max(0, n - 1), 0
    for p in range(n):                                 # in text order: h drops by at most 1 each step
        if rank[p] + 1 < n:
            q = sa[rank[p] + 1]
            while p + h < n and q + h < n and s[p + h] == s[q + h]:
                h += 1
            lcp[rank[p]] = h
            if h:
                h -= 1
        else:
            h = 0
    return lcp
