# file: ../lib/lichao.py
"""Li Chao tree for minimum of lines over integer x in [lo, hi)."""

class LiChao:
    def __init__(self, lo, hi):
        self.lo, self.hi = lo, hi
        self.line = {}                                  # node id -> (m, c); implicit tree, created lazily

    @staticmethod
    def _f(l, x):
        return l[0] * x + l[1]

    def add(self, m, c):
        new, node, lo, hi = (m, c), 1, self.lo, self.hi
        while True:
            cur = self.line.get(node)
            if cur is None:
                self.line[node] = new
                return
            mid = (lo + hi) // 2
            if self._f(new, mid) < self._f(cur, mid):
                self.line[node], new = new, cur          # keep the better line at mid here
            if hi - lo == 1:
                return
            if self._f(new, lo) < self._f(self.line[node], lo):
                node, hi = 2 * node, mid                 # the loser can still win on the left
            elif self._f(new, hi - 1) < self._f(self.line[node], hi - 1):
                node, lo = 2 * node + 1, mid             # ... or on the right
            else:
                return                                   # dominated everywhere in this range

    def query(self, x):
        node, lo, hi, best = 1, self.lo, self.hi, float("inf")
        while node in self.line:
            best = min(best, self._f(self.line[node], x))
            mid = (lo + hi) // 2
            if x < mid:
                node, hi = 2 * node, mid
            else:
                node, lo = 2 * node + 1, mid
        return best
