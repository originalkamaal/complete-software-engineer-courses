# file: ../lib/mincost.py
"""Min-cost flow by successive shortest paths (Bellman-Ford / SPFA), small and robust."""
from collections import deque

class MinCostFlow:
    def __init__(self, n):
        self.n, self.head, self.to, self.cap, self.cost = n, [[] for _ in range(n)], [], [], []
    def add_edge(self, u, v, cap, cost):
        for a, b, c, w in ((u, v, cap, cost), (v, u, 0, -cost)):
            self.head[a].append(len(self.to)); self.to.append(b); self.cap.append(c); self.cost.append(w)
    def flow(self, s, t, limit=float("inf")):
        total_flow = total_cost = 0
        while total_flow < limit:
            dist, inq, prev = [float("inf")] * self.n, [False] * self.n, [-1] * self.n
            dist[s] = 0
            q = deque([s])
            while q:                                     # SPFA: Bellman-Ford with a queue
                u = q.popleft(); inq[u] = False
                for e in self.head[u]:
                    v = self.to[e]
                    if self.cap[e] > 0 and dist[u] + self.cost[e] < dist[v]:
                        dist[v], prev[v] = dist[u] + self.cost[e], e
                        if not inq[v]:
                            inq[v] = True; q.append(v)
            if dist[t] == float("inf"):
                break
            f, v = limit - total_flow, t
            while v != s:
                f = min(f, self.cap[prev[v]]); v = self.to[prev[v] ^ 1]
            v = t
            while v != s:
                self.cap[prev[v]] -= f; self.cap[prev[v] ^ 1] += f; v = self.to[prev[v] ^ 1]
            total_flow += f
            total_cost += f * dist[t]
        return total_flow, total_cost
