# file: ../lib/check.py
"""Test helper used throughout the book: examples, stress tests with shrinking."""
import random

def examples(f, cases):
    for args, expected in cases:
        got = f(*args)
        assert got == expected, f"{f.__name__}{args}: expected {expected!r}, got {got!r}"
    return f"{len(cases)} examples ok"

def _shrink(args, fails, valid):
    args, changed = list(args), True
    while changed:
        changed = False
        for k, a in enumerate(args):
            if isinstance(a, (list, str)) and len(a) > 0:
                for i in range(len(a)):
                    trial = args[:k] + [a[:i] + a[i + 1:]] + args[k + 1:]
                    if valid(*trial) and fails(trial):
                        args, changed = trial, True
                        break
            if changed:
                break
    return args

def stress(fast, brute, gen, trials=2000, seed=0, same=None, valid=None):
    """gen(rng) -> tuple of arguments. same(fast_result, brute_result, args) -> bool (default ==).
    valid(*args) -> bool: the problem's input guarantees, respected while shrinking a counterexample."""
    valid = valid or (lambda *args: True)
    rng = random.Random(seed)
    same = same or (lambda x, y, args: x == y)
    def fails(args):
        try:
            return not same(fast(*args), brute(*args), args)
        except Exception:
            return True
    for t in range(trials):
        args = list(gen(rng))
        if not valid(*args):
            continue                          # the generator may overshoot the guarantees: skip such inputs
        if fails(args):
            small = _shrink(args, fails, valid)
            try:
                got = fast(*small)
            except Exception as e:
                got = f"{type(e).__name__}: {e}"
            raise AssertionError(f"{fast.__name__}: counterexample {small} -> got {got!r}, expected {brute(*small)!r}")
    return f"{trials} stress tests ok"

def rand_list(rng, lo=-5, hi=5, max_len=8, min_len=0):
    return [rng.randint(lo, hi) for _ in range(rng.randint(min_len, max_len))]
