# file: ../lib/sam.py
"""Suffix automaton (online construction)."""

class SuffixAutomaton:
    def __init__(self, s=""):
        self.next, self.link, self.len = [{}], [-1], [0]
        self.last = 0
        for ch in s:
            self.extend(ch)

    def extend(self, ch):
        cur = len(self.len)
        self.next.append({}); self.link.append(0); self.len.append(self.len[self.last] + 1)
        p = self.last
        while p != -1 and ch not in self.next[p]:
            self.next[p][ch] = cur
            p = self.link[p]
        if p != -1:
            q = self.next[p][ch]
            if self.len[p] + 1 == self.len[q]:
                self.link[cur] = q
            else:                                       # split q: clone with the shorter length
                clone = len(self.len)
                self.next.append(dict(self.next[q])); self.link.append(self.link[q]); self.len.append(self.len[p] + 1)
                while p != -1 and self.next[p].get(ch) == q:
                    self.next[p][ch] = clone
                    p = self.link[p]
                self.link[q] = self.link[cur] = clone
        self.last = cur

    def distinct_substrings(self):
        return sum(self.len[v] - self.len[self.link[v]] for v in range(1, len(self.len)))

    def longest_common_substring(self, t):
        v, l, best, end = 0, 0, 0, 0
        for i, ch in enumerate(t):
            while v and ch not in self.next[v]:
                v = self.link[v]; l = self.len[v]
            if ch in self.next[v]:
                v = self.next[v][ch]; l += 1
            if l > best:
                best, end = l, i + 1
        return t[end - best:end]
