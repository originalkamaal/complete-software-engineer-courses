# file: ../lib/scc.py
"""Strongly connected components (Kosaraju), iterative."""

def scc(n, edges):
    """Return comp[v] for each vertex; components are numbered in topological order of the condensation."""
    adj, radj = [[] for _ in range(n)], [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v); radj[v].append(u)
    seen, order = [False] * n, []
    for s in range(n):                                  # pass 1: finishing order
        if seen[s]:
            continue
        seen[s] = True
        stack = [(s, iter(adj[s]))]
        while stack:
            u, it = stack[-1]
            v = next(it, None)
            if v is None:
                order.append(u); stack.pop()
            elif not seen[v]:
                seen[v] = True; stack.append((v, iter(adj[v])))
    comp, c = [-1] * n, 0
    for s in reversed(order):                           # pass 2: reversed graph
        if comp[s] != -1:
            continue
        comp[s] = c
        stack = [s]
        while stack:
            u = stack.pop()
            for v in radj[u]:
                if comp[v] == -1:
                    comp[v] = c; stack.append(v)
        c += 1
    return comp
