# file: ../lib/rooted.py
"""Rooting a tree given as an edge list (vertices 0..n-1), iteratively."""
from collections import deque

def root_tree(n, edges, root=0):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v); adj[v].append(u)
    parent, depth, order = [-1] * n, [0] * n, []
    seen = [False] * n
    seen[root] = True
    q = deque([root])
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            if not seen[v]:
                seen[v] = True
                parent[v], depth[v] = u, depth[u] + 1
                q.append(v)
    return adj, parent, depth, order

def subtree_sizes(parent, order):
    size = [1] * len(parent)
    for u in reversed(order):                       # children before parents
        if parent[u] != -1:
            size[parent[u]] += size[u]
    return size

def random_tree(rng, n):
    """Random labelled tree: attach each vertex to a random earlier one, then shuffle labels."""
    perm = list(range(n)); rng.shuffle(perm)
    return [(perm[i], perm[rng.randrange(i)]) for i in range(1, n)]
