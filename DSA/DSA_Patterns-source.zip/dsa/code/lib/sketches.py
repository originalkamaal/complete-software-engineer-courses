# file: ../lib/sketches.py
"""Bloom filter, Count-Min sketch, HyperLogLog — with seeded 64-bit hashing via blake2b."""
import hashlib
import math

def h64(x, seed):
    return int.from_bytes(hashlib.blake2b(repr(x).encode(), digest_size=8, salt=seed.to_bytes(16, "little")).digest(), "little")

class Bloom:
    def __init__(self, m_bits, k):
        self.m, self.k, self.bits = m_bits, k, bytearray((m_bits + 7) // 8)
    def _positions(self, x):
        a, b = h64(x, 1), h64(x, 2)                       # double hashing: g_i = a + i*b
        return [(a + i * b) % self.m for i in range(self.k)]
    def add(self, x):
        for p in self._positions(x):
            self.bits[p >> 3] |= 1 << (p & 7)
    def might_contain(self, x):
        return all(self.bits[p >> 3] >> (p & 7) & 1 for p in self._positions(x))

class CountMin:
    def __init__(self, eps, delta):
        self.w, self.d = math.ceil(math.e / eps), math.ceil(math.log(1 / delta))
        self.t = [[0] * self.w for _ in range(self.d)]
    def add(self, x, c=1):
        for r in range(self.d):
            self.t[r][h64(x, 10 + r) % self.w] += c
    def count(self, x):
        return min(self.t[r][h64(x, 10 + r) % self.w] for r in range(self.d))

class HyperLogLog:
    def __init__(self, b=12):                              # m = 2^b registers
        self.b, self.m = b, 1 << b
        self.reg = [0] * self.m
    def add(self, x):
        h = h64(x, 99)
        j = h & (self.m - 1)
        w = h >> self.b
        rank = (64 - self.b) - w.bit_length() + 1          # position of the first 1-bit
        self.reg[j] = max(self.reg[j], rank)
    def estimate(self):
        alpha = 0.7213 / (1 + 1.079 / self.m)
        e = alpha * self.m * self.m / sum(2.0 ** -r for r in self.reg)
        zeros = self.reg.count(0)
        if e <= 2.5 * self.m and zeros:                    # small-range correction: linear counting
            e = self.m * math.log(self.m / zeros)
        return e
