# file: ../lib/lazy.py
"""Recursive segment tree with lazy propagation: range add, range sum and range min."""

class LazySegTree:
    def __init__(self, data):
        self.n = len(data)
        size = 4 * max(1, self.n)
        self.sum, self.mn, self.tag = [0] * size, [0] * size, [0] * size
        self._build(1, 0, self.n, data)

    def _build(self, node, lo, hi, data):
        if hi - lo == 1:
            self.sum[node] = self.mn[node] = data[lo]
            return
        mid = (lo + hi) // 2
        self._build(2 * node, lo, mid, data)
        self._build(2 * node + 1, mid, hi, data)
        self._pull(node)

    def _pull(self, node):
        self.sum[node] = self.sum[2 * node] + self.sum[2 * node + 1]
        self.mn[node] = min(self.mn[2 * node], self.mn[2 * node + 1])

    def _apply(self, node, lo, hi, v):                  # add v to every element under node
        self.sum[node] += v * (hi - lo)
        self.mn[node] += v
        self.tag[node] += v                             # add-tags compose by addition

    def _push(self, node, lo, hi):
        if self.tag[node]:
            mid = (lo + hi) // 2
            self._apply(2 * node, lo, mid, self.tag[node])
            self._apply(2 * node + 1, mid, hi, self.tag[node])
            self.tag[node] = 0

    def add(self, l, r, v, node=1, lo=0, hi=None):
        hi = self.n if hi is None else hi
        if r <= lo or hi <= l:
            return
        if l <= lo and hi <= r:
            self._apply(node, lo, hi, v)
            return
        self._push(node, lo, hi)
        mid = (lo + hi) // 2
        self.add(l, r, v, 2 * node, lo, mid)
        self.add(l, r, v, 2 * node + 1, mid, hi)
        self._pull(node)

    def query(self, l, r, node=1, lo=0, hi=None):       # returns (sum, min) of data[l:r]
        hi = self.n if hi is None else hi
        if r <= lo or hi <= l:
            return 0, float("inf")
        if l <= lo and hi <= r:
            return self.sum[node], self.mn[node]
        self._push(node, lo, hi)
        mid = (lo + hi) // 2
        s1, m1 = self.query(l, r, 2 * node, lo, mid)
        s2, m2 = self.query(l, r, 2 * node + 1, mid, hi)
        return s1 + s2, min(m1, m2)
