# file: ../lib/geom.py
"""Exact integer geometry primitives."""

def cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

def dot(o, a, b):
    return (a[0] - o[0]) * (b[0] - o[0]) + (a[1] - o[1]) * (b[1] - o[1])

def sign(x):
    return (x > 0) - (x < 0)

def on_segment(p, a, b):                               # p collinear with a-b assumed
    return min(a[0], b[0]) <= p[0] <= max(a[0], b[0]) and min(a[1], b[1]) <= p[1] <= max(a[1], b[1])

def segments_intersect(a, b, c, d):                     # closed segments ab and cd
    d1, d2 = sign(cross(a, b, c)), sign(cross(a, b, d))
    d3, d4 = sign(cross(c, d, a)), sign(cross(c, d, b))
    if d1 * d2 < 0 and d3 * d4 < 0:
        return True                                     # proper crossing
    return ((d1 == 0 and on_segment(c, a, b)) or (d2 == 0 and on_segment(d, a, b)) or
            (d3 == 0 and on_segment(a, c, d)) or (d4 == 0 and on_segment(b, c, d)))

def area2(poly):                                        # twice the signed area (shoelace); > 0 if counter-clockwise
    return sum(poly[i - 1][0] * poly[i][1] - poly[i][0] * poly[i - 1][1] for i in range(len(poly)))
