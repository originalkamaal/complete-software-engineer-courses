# file: ../lib/centroid.py
"""Centroid decomposition: cpar[v] = parent of v in the centroid tree (-1 for the top)."""

def centroid_decomposition(n, adj):
    removed, size = [False] * n, [0] * n
    cpar = [-1] * n
    stack = [(0, -1)]                                  # (any vertex of a component, centroid parent)
    while stack:
        start, cp = stack.pop()
        order, par = [start], {start: -1}               # collect the component
        i = 0
        while i < len(order):
            u = order[i]; i += 1
            for v in adj[u]:
                if not removed[v] and v != par[u]:
                    par[v] = u; order.append(v)
        for u in reversed(order):                      # subtree sizes within the component
            size[u] = 1 + sum(size[v] for v in adj[u] if not removed[v] and par.get(v) == u)
        total, c = len(order), start
        while True:                                    # walk towards the heavy side
            nxt = next((v for v in adj[c] if not removed[v] and par.get(v) == c and size[v] > total // 2), None)
            if nxt is None:
                break
            c = nxt
        removed[c], cpar[c] = True, cp
        for v in adj[c]:
            if not removed[v]:
                stack.append((v, c))
    return cpar
