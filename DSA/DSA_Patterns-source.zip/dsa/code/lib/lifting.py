# file: ../lib/lifting.py
"""Binary lifting over a rooted tree (parent[root] == -1)."""

class Lifting:
    def __init__(self, parent, depth):
        n = len(parent)
        self.depth = depth
        self.LOG = max(1, (n - 1).bit_length())
        root_fix = [p if p != -1 else v for v, p in enumerate(parent)]     # root points to itself
        self.up = [root_fix]
        for j in range(1, self.LOG):
            prev = self.up[-1]
            self.up.append([prev[prev[v]] for v in range(n)])

    def kth_ancestor(self, v, k):
        if k > self.depth[v]:
            return -1
        j = 0
        while k:
            if k & 1:
                v = self.up[j][v]
            k >>= 1; j += 1
        return v

    def lca(self, u, v):
        if self.depth[u] < self.depth[v]:
            u, v = v, u
        u = self.kth_ancestor(u, self.depth[u] - self.depth[v])
        if u == v:
            return u
        for j in range(self.LOG - 1, -1, -1):
            if self.up[j][u] != self.up[j][v]:
                u, v = self.up[j][u], self.up[j][v]
        return self.up[0][u]

    def dist(self, u, v):
        return self.depth[u] + self.depth[v] - 2 * self.depth[self.lca(u, v)]
