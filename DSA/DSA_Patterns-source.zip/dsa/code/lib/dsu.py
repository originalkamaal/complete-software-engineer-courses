# file: ../lib/dsu.py
"""Disjoint set union with path compression and union by size."""

class DSU:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n
        self.groups = n

    def find(self, x):
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:                 # path compression, iteratively
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False                              # already together
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra                          # smaller under larger
        self.size[ra] += self.size[rb]
        self.groups -= 1
        return True

    def same(self, a, b):
        return self.find(a) == self.find(b)
