# file: ../lib/flow.py
"""Dinic's maximum flow. Edges stored in flat lists; edge i and i^1 are a forward/backward pair."""
from collections import deque

class MaxFlow:
    def __init__(self, n):
        self.n = n
        self.head = [[] for _ in range(n)]            # vertex -> edge ids
        self.to, self.cap = [], []

    def add_edge(self, u, v, c):
        self.head[u].append(len(self.to)); self.to.append(v); self.cap.append(c)
        self.head[v].append(len(self.to)); self.to.append(u); self.cap.append(0)
        return len(self.to) - 2                       # id of the forward edge

    def _bfs(self, s, t):
        self.level = [-1] * self.n
        self.level[s] = 0
        q = deque([s])
        while q:
            u = q.popleft()
            for e in self.head[u]:
                if self.cap[e] > 0 and self.level[self.to[e]] < 0:
                    self.level[self.to[e]] = self.level[u] + 1
                    q.append(self.to[e])
        return self.level[t] >= 0

    def _dfs(self, s, t):                             # one augmenting path in the level graph, iteratively
        stack, path = [s], []
        while stack:
            u = stack[-1]
            if u == t:
                f = min(self.cap[e] for e in path)
                for e in path:
                    self.cap[e] -= f; self.cap[e ^ 1] += f
                return f
            advanced = False
            while self.it[u] < len(self.head[u]):
                e = self.head[u][self.it[u]]
                v = self.to[e]
                if self.cap[e] > 0 and self.level[v] == self.level[u] + 1:
                    stack.append(v); path.append(e); advanced = True
                    break
                self.it[u] += 1                       # dead edge: never try it again this phase
            if not advanced:
                stack.pop()
                if path:
                    path.pop()
                    self.it[stack[-1]] += 1           # the edge into u led to a dead end
        return 0

    def max_flow(self, s, t):
        flow = 0
        while self._bfs(s, t):
            self.it = [0] * self.n
            while True:
                f = self._dfs(s, t)
                if not f:
                    break
                flow += f
        return flow

    def min_cut_side(self, s):
        """Vertices reachable from s in the residual graph (call after max_flow)."""
        seen, stack = {s}, [s]
        while stack:
            u = stack.pop()
            for e in self.head[u]:
                if self.cap[e] > 0 and self.to[e] not in seen:
                    seen.add(self.to[e]); stack.append(self.to[e])
        return seen
