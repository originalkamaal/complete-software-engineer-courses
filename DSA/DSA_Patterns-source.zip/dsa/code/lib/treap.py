# file: ../lib/treap.py
"""Order-statistic multiset: treap with split/merge (expected O(log n) per operation)."""
import random

class _Node:
    __slots__ = ("key", "pri", "left", "right", "size")
    def __init__(self, key, pri):
        self.key, self.pri, self.left, self.right, self.size = key, pri, None, None, 1

def _sz(t):
    return t.size if t else 0

def _pull(t):
    t.size = 1 + _sz(t.left) + _sz(t.right)
    return t

def _split(t, key):                    # -> (keys < key, keys >= key)
    if not t:
        return None, None
    if t.key < key:
        l, r = _split(t.right, key)
        t.right = l
        return _pull(t), r
    l, r = _split(t.left, key)
    t.left = r
    return l, _pull(t)

def _merge(a, b):                      # every key in a <= every key in b
    if not a or not b:
        return a or b
    if a.pri > b.pri:
        a.right = _merge(a.right, b)
        return _pull(a)
    b.left = _merge(a, b.left)
    return _pull(b)

class Treap:
    def __init__(self, seed=0):
        self.root, self.rng = None, random.Random(seed)
    def __len__(self):
        return _sz(self.root)
    def add(self, key):
        l, r = _split(self.root, key)
        self.root = _merge(_merge(l, _Node(key, self.rng.random())), r)
    def remove(self, key):             # remove one copy; return whether it existed
        l, r = _split(self.root, key)
        mid, r = _split(r, _succ(key))
        found = mid is not None
        if mid:
            mid = _merge(mid.left, mid.right)          # drop the root of the equal-keys part
        self.root = _merge(_merge(l, mid), r)
        return found
    def rank(self, key):               # number of keys < key
        t, r = self.root, 0
        while t:
            if t.key < key:
                r += _sz(t.left) + 1
                t = t.right
            else:
                t = t.left
        return r
    def select(self, k):               # k-th smallest, 0-based
        t = self.root
        while t:
            ls = _sz(t.left)
            if k < ls:
                t = t.left
            elif k == ls:
                return t.key
            else:
                k -= ls + 1
                t = t.right
        raise IndexError(k)

def _succ(key):                        # smallest value greater than key, for split by "<= key"
    if isinstance(key, int):
        return key + 1
    if isinstance(key, tuple):
        return key + ((),)             # tuples: any extension is greater
    raise TypeError("Treap.remove supports int and tuple keys")
