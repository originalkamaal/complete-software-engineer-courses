# file: ../lib/fenwick.py
"""Fenwick (binary indexed) tree over 0-based positions."""

class Fenwick:
    def __init__(self, n):
        self.n = n
        self.t = [0] * (n + 1)

    @classmethod
    def from_list(cls, data):                      # O(n) build
        f = cls(len(data))
        for i, v in enumerate(data, 1):
            f.t[i] += v
            j = i + (i & -i)
            if j <= f.n:
                f.t[j] += f.t[i]
        return f

    def add(self, i, delta):
        i += 1
        while i <= self.n:
            self.t[i] += delta
            i += i & -i

    def prefix(self, i):                           # sum of data[0:i]
        s = 0
        while i > 0:
            s += self.t[i]
            i -= i & -i
        return s

    def range_sum(self, l, r):                     # data[l:r]
        return self.prefix(r) - self.prefix(l)

    def lower_bound(self, k):
        """Smallest i such that prefix(i + 1) >= k (all values non-negative); n if none."""
        pos, step = 0, 1 << self.n.bit_length()
        while step:
            nxt = pos + step
            if nxt <= self.n and self.t[nxt] < k:
                pos, k = nxt, k - self.t[nxt]
            step >>= 1
        return pos
