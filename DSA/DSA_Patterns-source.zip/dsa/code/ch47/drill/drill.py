# file: drill/drill.py
import random
import sys

CARDS = {
    13: ("Median of two sorted arrays", "binary-search the partition of the shorter array; O(log min(m, n))"),
    18: ("Largest rectangle in histogram", "monotonic stack; width between previous and next smaller; O(n)"),
    23: ("Shortest subarray with sum >= K (negatives)", "prefix sums + increasing deque; O(n)"),
    35: ("Create maximum number", "best subsequence per split via monotonic stack + suffix-comparing merge"),
    40: ("LFU cache", "frequency buckets of ordered dicts + min frequency; O(1)"),
    57: ("Word ladder II", "BFS layers with parent lists, then backtrack paths"),
    61: ("Parallel courses with k per semester", "bitmask DP over taken set, submasks of available of size <= k"),
    67: ("Shortest path to get all keys", "BFS over (cell, key mask)"),
    75: ("Number of ways to wear different hats", "DP over hats with a mask of people (the smaller set)"),
    79: ("Burst balloons", "interval DP on the LAST balloon burst in (i, j)"),
    80: ("Minimum cost to merge stones", "interval DP with pile counts; feasibility (n-1) % (k-1) == 0"),
    88: ("Profitable schemes", "2-D knapsack, profit capped at P"),
    90: ("Can I win", "win/lose memo over bitmask of used numbers"),
    96: ("Queue reconstruction by height", "sort by height desc, k asc; insert at index k"),
    99: ("Self crossing", "three local cases: segments i-3, i-4, i-5"),
    100: ("Split array largest sum", "binary search on answer + greedy count"),
}
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 2026
picked = random.Random(seed).sample(sorted(CARDS), 10)
print(f"Drill (seed {seed}) - for each: signals, insight, complexity, trap\n")
for k in picked:
    print(f"  #{k:>3}  {CARDS[k][0]}")
print("\n--- key ---")
for k in picked:
    print(f"  #{k:>3}  {CARDS[k][1]}")
