# file: misc_hard.py
import math
from collections import Counter
from functools import cache
from itertools import product
from sortedcontainers import SortedList
from check import stress

def strange_printer(s):
    n = len(s)
    if n == 0:
        return 0
    dp = [[0] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):
        dp[i][i] = 1
        for j in range(i + 1, n):
            dp[i][j] = dp[i + 1][j] + 1                 # print s[i] alone, then the rest
            for k in range(i + 1, j + 1):
                if s[k] == s[i]:                         # extend s[i]'s print to cover position k too
                    dp[i][j] = min(dp[i][j], (dp[i + 1][k - 1] if k > i + 1 else 0) + dp[k][j])
    return dp[0][n - 1]

def printer_brute(s):                                    # BFS over board states (small alphabet and length)
    from collections import deque
    n = len(s)
    start = "_" * n
    dist, q = {start: 0}, deque([start])
    while q:
        b = q.popleft()
        if b == s:
            return dist[b]
        for ch in set(s):
            for i in range(n):
                for j in range(i + 1, n + 1):
                    nb = b[:i] + ch * (j - i) + b[j:]
                    if nb not in dist:
                        dist[nb] = dist[b] + 1; q.append(nb)

def max_points(points):
    best = 0
    for i, (x1, y1) in enumerate(points):
        dirs, same = Counter(), 0
        for x2, y2 in points[i + 1:]:
            dx, dy = x2 - x1, y2 - y1
            if dx == 0 and dy == 0:
                same += 1; continue
            g = math.gcd(dx, dy)
            dx, dy = dx // g, dy // g
            if dx < 0 or (dx == 0 and dy < 0):
                dx, dy = -dx, -dy                        # canonical sign
            dirs[(dx, dy)] += 1
        best = max(best, max(dirs.values(), default=0) + same + 1)
    return best

def points_brute(points):
    best = min(len(points), 2) if points else 0
    for a in points:
        for b in points:
            if a != b:
                best = max(best, sum((b[0] - a[0]) * (p[1] - a[1]) == (b[1] - a[1]) * (p[0] - a[0]) for p in points))
    return max(best, max(Counter(points).values(), default=0))

def reaching_points(sx, sy, tx, ty):
    while tx >= sx and ty >= sy:
        if tx == sx and ty == sy:
            return True
        if tx > ty:
            if ty == sy:
                return (tx - sx) % ty == 0
            tx %= ty
        else:
            if tx == sx:
                return (ty - sy) % tx == 0
            ty %= tx
    return False

def reaching_brute(sx, sy, tx, ty):
    @cache
    def go(x, y):
        if (x, y) == (tx, ty): return True
        if x > tx or y > ty: return False
        return go(x + y, y) or go(x, x + y)
    return go(sx, sy)

def max_rect_at_most_k(m, k):
    R, C = len(m), len(m[0])
    best = float("-inf")
    for top in range(R):
        col = [0] * C
        for bottom in range(top, R):
            for c in range(C):
                col[c] += m[bottom][c]
            prefixes, P = SortedList([0]), 0
            for v in col:
                P += v
                i = prefixes.bisect_left(P - k)          # smallest earlier prefix >= P - k
                if i < len(prefixes):
                    best = max(best, P - prefixes[i])
                prefixes.add(P)
    return best

def rect_brute(m, k):
    R, C = len(m), len(m[0])
    sums = [sum(m[r][c] for r in range(r1, r2 + 1) for c in range(c1, c2 + 1))
            for r1 in range(R) for r2 in range(r1, R) for c1 in range(C) for c2 in range(c1, C)]
    return max((s for s in sums if s <= k), default=float("-inf"))

if __name__ == "__main__":
    print("H9 ", stress(strange_printer, printer_brute, lambda rng: ("".join(rng.choice("ab") for _ in range(rng.randint(0, 6))),), trials=300))
    print("H10", stress(max_points, points_brute, lambda rng: ([(rng.randint(-3, 3), rng.randint(-3, 3)) for _ in range(rng.randint(0, 8))],)))
    print("H11", stress(reaching_points, reaching_brute, lambda rng: (rng.randint(1, 5), rng.randint(1, 5), rng.randint(1, 40), rng.randint(1, 40))))
    def gen_rect(rng):
        R, C = rng.randint(1, 4), rng.randint(1, 4)
        return ([[rng.randint(-5, 5) for _ in range(C)] for _ in range(R)], rng.randint(-5, 10))
    print("H12", stress(max_rect_at_most_k, rect_brute, gen_rect))
