# file: heaps_bfs.py
import heapq
from collections import deque, defaultdict
from itertools import combinations
from check import stress

def trap_rain_2d(h):
    R, C = len(h), len(h[0])
    seen = [[False] * C for _ in range(R)]
    pq = []
    for r in range(R):
        for c in range(C):
            if r in (0, R - 1) or c in (0, C - 1):
                heapq.heappush(pq, (h[r][c], r, c)); seen[r][c] = True
    water = 0
    while pq:
        level, r, c = heapq.heappop(pq)
        for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if 0 <= nr < R and 0 <= nc < C and not seen[nr][nc]:
                seen[nr][nc] = True
                water += max(0, level - h[nr][nc])
                heapq.heappush(pq, (max(level, h[nr][nc]), nr, nc))
    return water

def trap_brute(h):                                      # level[c] = min over paths to border of max height (iterate to fixpoint)
    R, C = len(h), len(h[0])
    INF = float("inf")
    lvl = [[h[r][c] if r in (0, R - 1) or c in (0, C - 1) else INF for c in range(C)] for r in range(R)]
    changed = True
    while changed:
        changed = False
        for r in range(R):
            for c in range(C):
                for nr, nc in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                    if 0 <= nr < R and 0 <= nc < C:
                        v = max(h[r][c], lvl[nr][nc])
                        if v < lvl[r][c]:
                            lvl[r][c] = v; changed = True
    return sum(lvl[r][c] - h[r][c] for r in range(R) for c in range(C))

def min_refuel(target, fuel, stations):
    pq, stops, i, reach = [], 0, 0, fuel
    while reach < target:
        while i < len(stations) and stations[i][0] <= reach:
            heapq.heappush(pq, -stations[i][1]); i += 1
        if not pq:
            return -1
        reach -= heapq.heappop(pq); stops += 1        # refuel at the biggest station passed
    return stops

def refuel_brute(target, fuel, stations):
    for k in range(len(stations) + 1):
        for sub in combinations(stations, k):
            reach, ok = fuel, True
            for pos, f in sub:
                if pos > reach: ok = False; break
                reach += f
            if ok and reach >= target:
                return k
    return -1

def bus_routes(routes, S, T):
    if S == T:
        return 0
    at = defaultdict(list)
    for i, r in enumerate(routes):
        for s in r:
            at[s].append(i)
    used_route, used_stop = set(at[S]), {S}
    q, buses = deque(at[S]), 1
    while q:
        for _ in range(len(q)):
            i = q.popleft()
            if T in routes[i]:
                return buses
            for s in routes[i]:
                if s not in used_stop:
                    used_stop.add(s)
                    for j in at[s]:
                        if j not in used_route:
                            used_route.add(j); q.append(j)
        buses += 1
    return -1

def bus_brute(routes, S, T):                            # BFS over (stop) with edge weight 1 per route boarded
    if S == T: return 0
    best = {S: 0}; frontier = {S}; k = 0
    while frontier:
        k += 1
        nxt = set()
        for r in routes:
            if frontier & set(r):
                for s in r:
                    if s not in best:
                        best[s] = k; nxt.add(s)
        frontier = nxt
    return best.get(T, -1)

def min_clips(clips, T):
    clips = sorted(clips)
    count, covered, i = 0, 0, 0
    while covered < T:
        far = covered
        while i < len(clips) and clips[i][0] <= covered:
            far = max(far, clips[i][1]); i += 1
        if far == covered:
            return -1
        count, covered = count + 1, far
    return count

def clips_brute(clips, T):
    for k in range(len(clips) + 1):
        for sub in combinations(clips, k):
            pts = set()
            for a, b in sub:
                pts |= set(range(a, b))
            if all(x in pts for x in range(T)):
                return k
    return -1

if __name__ == "__main__":
    print("H1", stress(trap_rain_2d, trap_brute, lambda rng: ([[rng.randint(0, 6) for _ in range(C)] for C in [rng.randint(1, 5)] for _ in range(rng.randint(1, 5))],)))
    print("H2", stress(min_refuel, refuel_brute, lambda rng: (rng.randint(1, 30), rng.randint(1, 10),
                       sorted((p, rng.randint(1, 10)) for p in rng.sample(range(1, 30), rng.randint(0, 5))))))
    print("H3", stress(bus_routes, bus_brute, lambda rng: ([rng.sample(range(8), rng.randint(1, 4)) for _ in range(rng.randint(1, 4))], rng.randrange(8), rng.randrange(8))))
    print("H4", stress(min_clips, clips_brute, lambda rng: ([(a := rng.randint(0, 9), a + rng.randint(0, 5)) for _ in range(rng.randint(0, 6))], rng.randint(1, 10))))
