# file: hard_dp.py
import re
from functools import cache
from check import stress

def regex_match(s, p):
    @cache
    def dp(i, j):
        if j == len(p):
            return i == len(s)
        first = i < len(s) and p[j] in (s[i], ".")
        if j + 1 < len(p) and p[j + 1] == "*":
            return dp(i, j + 2) or (first and dp(i + 1, j))
        return first and dp(i + 1, j + 1)
    return dp(0, 0)

def longest_valid_parens(s):
    stack, best = [-1], 0
    for i, ch in enumerate(s):
        if ch == "(":
            stack.append(i)
        else:
            stack.pop()
            if not stack:
                stack.append(i)                          # new sentinel: nothing valid crosses here
            else:
                best = max(best, i - stack[-1])
    return best

def cherry_pickup(g):                                    # -1 = thorn; 0/1 cherries; both trips = two forward walkers
    n = len(g)
    NEG = float("-inf")
    @cache
    def dp(t, r1, r2):
        c1, c2 = t - r1, t - r2
        if not (0 <= r1 < n and 0 <= c1 < n and 0 <= r2 < n and 0 <= c2 < n) or g[r1][c1] < 0 or g[r2][c2] < 0:
            return NEG
        here = g[r1][c1] + (g[r2][c2] if r1 != r2 else 0)
        if t == 2 * n - 2:
            return here
        return here + max(dp(t + 1, r1 + a, r2 + b) for a in (0, 1) for b in (0, 1))
    return max(0, dp(0, 0, 0))

def cherry_brute(g):                                     # enumerate both paths explicitly
    n = len(g)
    from itertools import product
    paths = []
    for moves in product("DR", repeat=2 * n - 2):
        if moves.count("D") == n - 1:
            r = c = 0; cells = [(0, 0)]
            for m in moves:
                r, c = (r + 1, c) if m == "D" else (r, c + 1); cells.append((r, c))
            if all(g[x][y] >= 0 for x, y in cells):
                paths.append(cells)
    best = 0
    for p1 in paths:
        for p2 in paths:
            best = max(best, sum(g[x][y] for x, y in set(p1) | set(p2)))
    return best

def egg_drop(k, n):
    f = [0] * (k + 1)                                    # f[e] = floors coverable with current moves and e eggs
    m = 0
    while f[k] < n:
        m += 1
        for e in range(k, 0, -1):                        # backwards: f[e-1] is still the previous move's value
            f[e] = f[e] + f[e - 1] + 1
    return m

def egg_brute(k, n):
    @cache
    def go(e, floors):
        if floors == 0: return 0
        if e == 1: return floors
        return 1 + min(max(go(e - 1, x - 1), go(e, floors - x)) for x in range(1, floors + 1))
    return go(k, n)

if __name__ == "__main__":
    w = lambda rng, a, k: "".join(rng.choice(a) for _ in range(rng.randint(0, k)))
    print("H5", stress(regex_match, lambda s, p: re.fullmatch(p, s) is not None,
                       lambda rng: (w(rng, "ab", 6), "".join(rng.choice(["a", "b", ".", "a*", "b*", ".*"]) for _ in range(rng.randint(0, 4))))))
    print("H6", stress(longest_valid_parens, lambda s: max((j - i for i in range(len(s)) for j in range(i, len(s) + 1)
                       if (lambda t: all(t[:q].count("(") >= t[:q].count(")") for q in range(len(t) + 1)) and t.count("(") == t.count(")"))(s[i:j])), default=0),
                       lambda rng: (w(rng, "()", 10),)))
    print("H7", stress(cherry_pickup, cherry_brute, lambda rng: ([[rng.choice([0, 1, 1, -1]) for _ in range(n)] for n in [rng.randint(1, 4)] for _ in range(n)],), trials=500))
    print("H8", stress(egg_drop, egg_brute, lambda rng: (rng.randint(1, 4), rng.randint(1, 40)), trials=300))
    print("egg drop, 2 eggs, 100 floors:", egg_drop(2, 100), "moves; 3 eggs, 10^9 floors:", egg_drop(3, 10**9))
