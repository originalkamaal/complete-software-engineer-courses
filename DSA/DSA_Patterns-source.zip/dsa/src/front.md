---
title: "Data Structures and Algorithms: Patterns for Hard Problems"
subtitle: "From first principles to FAANG-level interviews — every pattern with its invariant, template, traps, and stress-tested code"
lang: en
---

# Preface

Most people who struggle with algorithm interviews do not lack knowledge. They have seen binary search, heaps, and dynamic programming. What they lack is **recognition**: looking at an unfamiliar problem and seeing which idea it needs — and **reliability**: writing that idea correctly, under pressure, the first time.

This book is built to train both.

**Recognition** comes from patterns. Every technique in this book is presented as a *pattern card*: a one-line summary, the signals in a problem statement that point to it ("Recognise it when"), the **invariant** that makes it correct, a template, worked problems from easy to hard, and the traps that catch experienced programmers. Part VI then turns the patterns into a decision guide and drills it on problems that combine several patterns at once.

**Reliability** comes from a habit this book uses on every page: **stress testing**. Each fast solution is run against a slow, obviously correct brute force on thousands of random small inputs, and any disagreement is automatically shrunk to a minimal counterexample. When a first version of an example was wrong while this book was being written — a generator that broke a problem's guarantees, a tie-breaking rule that double-counted, an "idempotent" operation that was not idempotent on negative numbers — the book shows what happened, because those are exactly the bugs you will write.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: a paper or textbook, the Python documentation, CPython's implementation, or a mathematical argument given in the text.
2. **Evidence.** Every program shown with output was run with Python 3.13, and the output is real — including timings, which show where constant factors beat asymptotics and where they do not.
3. **Order.** Nothing is used before it is taught; later chapters refer back by unit number.

# How to use this book

## Who it is for

- **Beginners in algorithms** who can program in Python: start at Chapter 0 and read in order.
- **Interview candidates:** Chapters 0–7 are the core; then Chapters 13, 15, 20–22, 28–30, and 37. Use Chapter 45 (the decision guide) and Chapter 47 (hard problems) as your final preparation.
- **Competitive programmers:** Chapters 17–19, 24–26, 33–36, 39–41 go beyond typical interviews.
- **Engineers using another language:** the ideas are language-independent; the Python-specific notes (recursion limits, integer behaviour, constant factors) are marked as such.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Recognise it when** | The signals in a problem statement that point to this pattern. |
| **Lesson and code** | Templates and worked problems, each stress-tested against a brute force. |
| **Deep & Tricky (DT-n)** | Precise facts and traps, labelled with their source of truth. |
| **Patterns (P-n)** | The engineering judgment: when to use the technique, and its trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a harder problem that combines the chapter's ideas, a complete solution with real output (usually including a timing at full scale), and a review checklist.

## How to study

1. **Solve before reading.** For each worked problem, stop after the statement and try for 10–20 minutes.
2. **Write the brute force first.** It takes two minutes and turns every later bug into a counterexample.
3. **Stress-test your own solutions** with the `check.py` harness from Chapters 0 and 2 — not just the examples.
4. **Say the invariant aloud.** If you cannot state why the loop is correct, you do not yet own the pattern.
5. **Revisit with spacing.** Appendix A lists every DT and P entry; quiz yourself on them a week later.

## Running the code

All code is in the accompanying source archive, one directory per chapter, plus a shared `lib/` directory (`check.py`, and the reusable structures: linked lists, trees, treap, DSU, segment trees, Fenwick tree, Aho–Corasick). Run any example from its chapter directory:

```text
cd code/ch06
PYTHONPATH=../lib python3 rotated.py
```

Python 3.10 or later is required (3.13 was used); the only third-party package is `sortedcontainers` (Chapters 14–15), used to compare against hand-written structures.
