# Appendix B — The Python Toolkit for Algorithms

This appendix collects the standard-library tools used throughout the book, with their costs and traps. All complexities are for CPython.

## Built-in containers

| Operation | list | dict / set | deque | str |
| --- | --- | --- | --- | --- |
| index / lookup | `a[i]` O(1) | `d[k]`, `x in s` O(1) average | `q[i]` O(n) | `s[i]` O(1) |
| append / add | `append` O(1) amortised | O(1) average | `append`, `appendleft` O(1) | `+` creates a new string: O(n) |
| pop end | `pop()` O(1) | `popitem()` O(1) | `pop()`, `popleft()` O(1) | — |
| insert / delete in the middle | O(n) (`memmove`, fast) | O(1) | O(n) | O(n) |
| slice | O(k) copy | — | — | O(k) copy |
| sort | `sort()` O(n log n), stable (Timsort) | — | — | — |

- Build strings with `"".join(parts)`, never `s += piece` in a loop.
- `x in list` is O(n); convert to a set when testing membership repeatedly.
- `[[0] * C] * R` creates R references to **one** row; use `[[0] * C for _ in range(R)]`.

## `collections`

- `deque` — queues and sliding windows (Ch. 5, 20). `deque(maxlen=k)` keeps the last k items.
- `Counter` — counting (Ch. 3); `most_common(k)` uses a heap; `c1 - c2` drops non-positive counts.
- `defaultdict(list)` — adjacency lists and grouping.
- `OrderedDict` — `move_to_end`, `popitem(last=False)`: LRU caches (Unit 43.1).

## `heapq` (Chapter 15)

- Min-heap on a plain list: `heappush`, `heappop`, `heapify` (O(n)), `heapreplace`, `heappushpop`, `nsmallest`, `nlargest`, `merge`.
- Max-heap: push negated keys. Custom priority: push `(priority, counter, item)` so items are never compared.
- No decrease-key and no arbitrary delete: push duplicates and skip stale entries (Dijkstra, Unit 22.1), or use lazy deletion (Ch. 15 project).

## `bisect` (Chapters 6, 14)

- `bisect_left(a, x)` — first index with `a[i] >= x`; `bisect_right(a, x)` — first index with `a[i] > x`.
- `insort(a, x)` — O(n) insertion, fast in practice for n up to ~10⁵ (DT-22).
- Python 3.10+: `key=` parameter for searching by a derived key.

## `functools` and `itertools`

- `@cache` / `@lru_cache(maxsize=None)` — memoisation (Ch. 28). Arguments must be hashable (tuples, not lists). `f.cache_clear()` between test cases.
- `cmp_to_key` — sort with a comparison function (Unit 7.4).
- `reduce`, `accumulate` (prefix sums: `list(accumulate(a, initial=0))`), `pairwise` (3.10+), `product`, `permutations`, `combinations`, `combinations_with_replacement`, `islice`, `chain.from_iterable`.

## `math` and integers

- `math.gcd`, `math.lcm` (3.9+), `math.isqrt` (exact integer square root), `math.comb`, `math.perm`, `math.inf`.
- `pow(a, b, m)` — fast modular power; `pow(a, -1, m)` — modular inverse (3.8+) (Unit 12.3).
- `int.bit_length()`, `int.bit_count()` (3.10+) (Ch. 11). Integers are unbounded; bitwise operations on negatives behave as infinite two's complement (DT-19).
- `fractions.Fraction` for exact ratios (P-13); `decimal.Decimal` for controlled precision (Ch. 33 project).

## Recursion and speed

- Default recursion limit 1000 (DT-17): convert deep recursions to explicit stacks, or process trees in reversed BFS order (Unit 25.1).
- Fast input for large data: `data = sys.stdin.buffer.read().split()`.
- Local variable lookups are faster than global or attribute lookups; in hot loops, bind `append = out.append`.
- About 10⁷ simple operations per second (Unit 0.2): check the budget before coding (Unit 45.1).

## Third-party: `sortedcontainers`

- `SortedList` — `add`, `remove`, `bisect_left`, `bisect_right`, indexing `s[k]` (k-th smallest), `irange`, `islice`; all about O(log n), fast in practice (Ch. 14).
- `SortedDict`, `SortedSet` — ordered maps and sets (Ch. 38 project).
- Not in the standard library: in interviews, say you would use it, and be ready to explain the balanced-BST alternative.
