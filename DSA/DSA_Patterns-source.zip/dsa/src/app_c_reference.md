# Appendix C — Complexity Reference

## Data structures

| Structure | Access / query | Insert | Delete | Notes | Chapter |
| --- | --- | --- | --- | --- | --- |
| Dynamic array | O(1) index | O(1) amortised at end | O(n) middle | cache-friendly | 1, 2 |
| Hash map / set | O(1) average | O(1) average | O(1) average | O(n) worst case; adversarial keys (DT-50) | 3 |
| Linked list | O(n) | O(1) at a known node | O(1) at a known node | | 8 |
| Stack / queue / deque | O(1) ends | O(1) | O(1) | | 9 |
| Monotonic stack / deque | — | O(1) amortised | O(1) amortised | nearest greater/smaller; window max | 5, 9 |
| Binary heap | O(1) min | O(log n) | O(log n) pop | `heapify` O(n) | 15 |
| Balanced BST / treap | O(log n) search, rank, select | O(log n) | O(log n) | order statistics | 14 |
| Trie | O(L) | O(L) | O(L) | L = key length | 16 |
| Union–find | O(α(n)) find | — | — | union O(α(n)); no split | 17 |
| Segment tree | O(log n) range query | O(log n) point/range update | — | any monoid; lazy for ranges | 18 |
| Fenwick tree | O(log n) prefix | O(log n) point update | — | invertible operations | 19 |
| Sparse table | O(1) idempotent range query | — | — | static; O(n log n) build | 19 |
| Suffix array + LCP | O(m log n) pattern search | — | — | O(n log n) build here | 39 |
| Suffix automaton | O(m) substring test | O(1) amortised per char | — | ≤ 2n − 1 states | 39 |
| Bloom filter | O(k) query | O(k) | — | false positives only | 42 |
| Count-Min sketch | O(d) | O(d) | — | overestimates only | 42 |

## Algorithms

| Problem | Algorithm | Time | Space | Chapter |
| --- | --- | --- | --- | --- |
| Sorting (comparison) | merge sort / Timsort / heap sort | O(n log n) | O(n) / O(n) / O(1) | 7 |
| Sorting (small integer keys) | counting / radix sort | O(n + k) / O(d(n + b)) | O(n + k) | 7 |
| Selection (k-th) | quickselect | O(n) expected | O(1) | 7 |
| Binary search | on index / on answer | O(log n) × check | O(1) | 6 |
| Pattern matching | KMP / Z / rolling hash | O(n + m) | O(m) | 3, 39 |
| Many patterns | Aho–Corasick | O(n + Σm + matches) | O(Σm) | 16 |
| Palindromes | Manacher | O(n) | O(n) | 39 |
| BFS / DFS | — | O(V + E) | O(V) | 20 |
| Topological sort | Kahn / DFS | O(V + E) | O(V) | 21 |
| Shortest paths, unit / 0-1 weights | BFS / 0-1 BFS | O(V + E) | O(V) | 20, 22 |
| Shortest paths, w ≥ 0 | Dijkstra (binary heap) | O((V + E) log V) | O(V) | 22 |
| Shortest paths, negative w | Bellman–Ford | O(VE) | O(V) | 22 |
| All-pairs shortest paths | Floyd–Warshall | O(V³) | O(V²) | 22 |
| MST | Kruskal / Prim (heap) / Prim (dense) | O(E log E) / O(E log V) / O(V²) | O(V + E) | 23 |
| SCC, bridges, articulation points | Kosaraju / low-link | O(V + E) | O(V) | 24 |
| 2-SAT | implication graph + SCC | O(n + m) | O(n + m) | 24 |
| LCA | binary lifting | O(n log n) build, O(log n) query | O(n log n) | 25 |
| Path queries on trees | heavy–light decomposition | O(log² n) per query | O(n) | 25 |
| Max flow | Dinic | O(V²E); O(E√V) unit bipartite | O(V + E) | 26 |
| Assignment | Hungarian | O(n³) | O(n²) | 26 |
| Euler path | Hierholzer | O(E) | O(E) | 27 |
| TSP / Hamiltonian path | Held–Karp | O(2ⁿ n²) | O(2ⁿ n) | 27 |
| LIS | patience sorting | O(n log n) | O(n) | 29 |
| LCS / edit distance | 2-D DP | O(nm) | O(min(n, m)) for the value | 29 |
| 0/1 knapsack | 1-D DP | O(nW) | O(W) | 30 |
| Interval DP | split points | O(n³); O(n²) with Knuth | O(n²) | 31, 36 |
| Subset DP | over masks / submasks / SOS | O(2ⁿ n) / O(3ⁿ) / O(2ⁿ n) | O(2ⁿ) | 33 |
| Digit DP | positions × states | O(digits · states · 10) | O(digits · states) | 34 |
| Linear recurrence, huge n | matrix power | O(d³ log n) | O(d²) | 36 |
| Convex hull | monotone chain | O(n log n) | O(n) | 40 |
| Closest pair | sweep | O(n log n) | O(n) | 40 |
| Integer multiplication | Karatsuba | O(n^1.585) | O(n) | 41 |
| Subset sums, n ≤ 40 | meet in the middle | O(2^(n/2) n) | O(2^(n/2)) | 41 |
| Primality (64-bit) | Miller–Rabin, fixed bases | O(k log³ n) | O(1) | 42 |

## Input size → target complexity

See Unit 45.1. In Python, divide the operation budget by about ten compared with C++.
