"""Build the book: assemble chapter files, generate appendices, combine."""
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).parent
SRC = ROOT / "src"
PARTS = ROOT / "parts"

subprocess.run(["python3", str(ROOT / "assemble01.py")], check=True)

# Chapter 2: lesson text written in two halves, with Unit 2.1 from the notes.
ch2 = (PARTS / "ch02_a.md").read_text().replace(
    "@@UNIT21@@", (PARTS / "unit2_1.md").read_text().strip())
ch2 += "\n" + (PARTS / "ch02_b.md").read_text()
(SRC / "ch02.md").write_text(ch2)

# Chapters written as several part files: chNN_a.md, chNN_b.md, ...
for n in range(3, 15):
    pieces = sorted(PARTS.glob(f"ch{n:02d}_*.md"))
    if pieces:
        (SRC / f"ch{n:02d}.md").write_text("\n".join(p.read_text() for p in pieces))

chapters = sorted(SRC.glob("ch*.md"))
order = [SRC / "front.md"] + chapters + sorted(SRC.glob("app*.md"))
order = [p for p in order if p.exists()]


def entries(prefix):
    """Collect '**DT-n. title**' style entries with the unit they appear in."""
    found = []
    for path in chapters:
        unit = None
        for line in path.read_text().split("\n"):
            m = re.match(r"^## (Unit \d+\.\d+|Chapter \d+ Project)", line)
            if m:
                unit = m.group(1)
            m = re.match(rf"^\*\*{prefix}-(\d+)\. (.+?)\*\*", line)
            if m:
                found.append((int(m.group(1)), m.group(2), unit))
    return found


def index_md():
    out = ["# Appendix A — Index of Deep & Tricky entries and Patterns", "",
           "Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, "
           "with the unit where it is explained. Use it for revision: read each title and try to "
           "explain the entry before looking it up.", "", "## Deep & Tricky Go Knowledge", "",
           "| # | Entry | Where |", "| --- | --- | --- |"]
    for n, title, unit in sorted(entries("DT")):
        out.append(f"| DT-{n} | {title.replace('|', '¦')} | {unit} |")
    out += ["", "## Go Patterns & Engineering Practices", "", "| # | Pattern | Where |", "| --- | --- | --- |"]
    for n, title, unit in sorted(entries("P")):
        out.append(f"| P-{n} | {title.replace('|', '¦')} | {unit} |")
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    (SRC / "app_a_index.md").write_text(index_md())
    order = [SRC / "front.md"] + chapters + sorted(SRC.glob("app*.md"))
    order = [p for p in order if p.exists()]
    book = "\n\n".join(p.read_text().strip() for p in order) + "\n"
    (ROOT / "build" / "GoApprenticeship.md").write_text(book)
    dts = sorted(entries("DT"))
    ps = sorted(entries("P"))
    print(f"chapters={len(chapters)} DT={len(dts)} P={len(ps)} bytes={len(book)}")
