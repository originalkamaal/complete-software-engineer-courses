# Chapter 4 — Testing, Tooling & Debugging

*Goal: make verifying code a habit, not an afterthought.*

Every chapter so far has said "run it, don't guess". This chapter turns that into engineering: automated tests that run in seconds, benchmarks that measure instead of guessing, fuzzers that find inputs you never imagined, static analysis that catches whole classes of bugs before the code runs, and a systematic way to debug when something still goes wrong.

Go's testing tools are built into the `go` command and the standard library — no framework to choose, no runner to configure. That is a big reason Go codebases tend to be well tested: the path of least resistance is the right one.

**What you will be able to do after this chapter**

- Write table-driven tests with subtests, helpers, cleanup, temporary directories, and golden files.
- Read coverage reports critically and use example functions as executable documentation.
- Design code with seams (small interfaces, injected clocks) so it can be tested without real databases or networks.
- Write honest benchmarks, compare them with `benchstat`, and fuzz parsers.
- Run `go vet`, `staticcheck`, `govulncheck`, and debug with Delve and a disciplined method.

## Topic 4A — Writing tests

## Unit 4.1 — Testing basics

**One-line summary:** Tests live in files ending in `_test.go`, in functions named `TestXxx(t *testing.T)`. `go test` compiles them with the package and runs them. Table-driven tests with subtests are the standard Go style.

**Mental model — the quality-control bench.** A factory has a bench next to the line where every batch is checked against a list: input, expected output, actual output. The list (the table) grows every time a defect is found, so the same defect is never shipped twice.

### A first test

```go
// file: mathx/mathx.go
package mathx

func Abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}
```

```go
// file: mathx/mathx_test.go
package mathx

import "testing"

func TestAbs(t *testing.T) {
	if got := Abs(-3); got != 3 {
		t.Errorf("Abs(-3) = %d, want 3", got)
	}
}
```

```
$ go test ./mathx
ok      example.com/mathx    0.002s
```

- `t.Errorf` records a failure and **continues** the test; `t.Fatalf` records a failure and **stops** this test immediately (use it when continuing makes no sense, for example after a setup error).
- The failure message convention is `Func(input) = got, want expected`. A reader of CI output should understand the failure without opening the code.
- Test files are excluded from normal builds; they can use the same package (white-box) or `package mathx_test` (black-box, DT-166).

### Table-driven tests and subtests

```go
func TestAbs(t *testing.T) {
	tests := []struct {
		name string
		in   int
		want int
	}{
		{"positive", 3, 3},
		{"negative", -3, 3},
		{"zero", 0, 0},
		{"min int", math.MinInt, math.MinInt}, // DT-24: documents a real edge case
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Abs(tt.in); got != tt.want {
				t.Errorf("Abs(%d) = %d, want %d", tt.in, got, tt.want)
			}
		})
	}
}
```

- Adding a case is one line, so people actually add them.
- `t.Run` creates a **subtest** with its own name, its own pass/fail, and its own `t`. `t.Fatal` inside a subtest stops only that subtest.
- Run one case: `go test -run 'TestAbs/negative' ./mathx` (the `-run` pattern is a regular expression, split on `/` for subtests; spaces in names become underscores).

### Useful `go test` flags

| Flag | Effect |
| --- | --- |
| `-v` | print every test name and its logs, not only failures |
| `-run REGEX` | run only matching tests (and subtests) |
| `-count=1` | ignore the test cache (results of unchanged packages are cached) |
| `-race` | enable the race detector (Chapter 7) — run it in CI |
| `-shuffle=on` | run tests in random order to expose hidden dependencies between them |
| `-failfast` | stop after the first failure |
| `-short` | tests may call `testing.Short()` and skip slow work |
| `-timeout 30s` | fail (with all goroutine stacks) if tests take longer (default 10 minutes) |
| `-cover` | report coverage (Unit 4.3) |
| `-json` | machine-readable output for CI tools |

`t.Log` / `t.Logf` print only for failing tests (or with `-v`). `t.Skip("reason")` skips a test (for example when an external tool is missing).

### What makes a good test

- **Tests behaviour, not implementation.** Assert on outputs and observable effects, not on private fields or the order of internal calls. Such tests survive refactoring.
- **Deterministic.** No dependence on the current time, random numbers without a seed, map iteration order, network, or test order.
- **Fast.** Unit tests in milliseconds, so people run them on every save.
- **Readable failures.** The message says what was called, with what, what came back, and what was expected.
- **One reason to fail.** A test named `TestBorrowWhenNoCopies` should fail only if that behaviour breaks.

### Deep & Tricky

**DT-179. `t.Fatal` must be called from the test's own goroutine.** *(Guarantee)* It calls `runtime.Goexit` (DT-165), which stops only the *current* goroutine. Called from a goroutine the test started, it stops that goroutine but not the test, which may then hang or pass wrongly. `go vet`'s `testinggoroutine` check reports it. From other goroutines, use `t.Error` and return.

**DT-180. Test results are cached.** *(Toolchain behaviour)* `go test ./...` reuses a cached `ok` for packages whose code, dependencies, flags, and *read files and environment variables* have not changed (it tracks which ones the test used). `(cached)` in the output means it did not run. Use `-count=1` when the test depends on something Go cannot see (a database, the network).

**DT-181. Since Go 1.27, `go test` runs the `stdversion` vet check by default.** *(Toolchain behaviour, version-dependent)* It reports uses of standard-library symbols newer than the module's `go` line — for example calling `errors.AsType` in a module that says `go 1.25`. `go test` already ran a small, high-confidence subset of vet checks (atomic, bool, buildtags, directive, errorsas, ifaceassert, nilfunc, printf, stringintconv, tests); this adds one more.

### Mastery check

1. **Explain.** When do you use `t.Errorf` and when `t.Fatalf`? Give an example of each.
2. **Predict.** A table test uses `t.Fatalf` inside `t.Run` and the second of five cases fails. How many cases run? What if `t.Fatalf` is used *without* `t.Run`?
3. **Write.** A table-driven test for `classify(n int) string` from Unit 1.6, with names, boundary cases, and one deliberately wrong expected value; read the failure message, then fix the table.

## Unit 4.2 — Test helpers and fixtures

**One-line summary:** `t.Helper()` makes failures point at the caller; `t.Cleanup` registers teardown; `t.TempDir` and `t.Setenv` give isolated files and environment; `t.Parallel` runs tests concurrently; the `testdata` directory and **golden files** hold expected outputs.

### Helpers

```go
func mustAddBook(t *testing.T, lib *catalog.Library, b catalog.Book) {
	t.Helper() // without this, failures report THIS line, not the test's line
	if err := lib.AddBook(b); err != nil {
		t.Fatalf("AddBook(%q): %v", b.ID, err)
	}
}
```

Helpers take `t` as the first parameter and call `t.Helper()` first. They keep tests short without hiding *what* is being tested — setup goes in helpers, the assertion that matters stays visible in the test.

### Cleanup, temporary directories, environment

```go
func TestExport(t *testing.T) {
	dir := t.TempDir()                 // unique directory, deleted after the test
	t.Setenv("APP_MODE", "test")       // restored after the test (not allowed in parallel tests)
	srv := startFakeServer()
	t.Cleanup(func() { srv.Close() })  // runs after the test and its subtests, LIFO like defer
	ctx := t.Context()                 // Go 1.24: canceled just before Cleanup functions run
	...
}
```

`t.Cleanup` beats `defer` in helpers: a helper's `defer` would run when the *helper* returns, but `t.Cleanup` runs when the *test* ends.

### Parallel tests

```go
func TestSlowThings(t *testing.T) {
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel() // pauses here; resumes in parallel after the loop finishes
			...
		})
	}
}
```

Parallel subtests share nothing unless you share it. They cannot use `t.Setenv` or `t.Chdir` (process-wide state). Since Go 1.22's per-iteration loop variables (DT-72), capturing `tt` in a parallel subtest is safe; in older code you will see `tt := tt` before `t.Run`.

### `testdata` and golden files

The `go` tool ignores directories named `testdata`, so they are the place for input files and expected outputs. Tests run with the **package directory** as the working directory, so `os.ReadFile("testdata/input.txt")` works.

A **golden file** stores the expected output of a complex operation (a report, generated code, a rendered page). The test compares actual output with the file; a flag rewrites the file when the change is intended:

```go
var update = flag.Bool("update", false, "rewrite golden files")

func TestListGolden(t *testing.T) {
	got := renderReport(...)
	golden := filepath.Join("testdata", "report.golden")
	if *update {
		os.WriteFile(golden, []byte(got), 0o644)
	}
	want, err := os.ReadFile(golden)
	if err != nil {
		t.Fatal(err)
	}
	if got != string(want) {
		t.Errorf("output differs from %s:\n got: %q\nwant: %q", golden, got, want)
	}
}
```

`go test -run TestListGolden -update` regenerates it; the diff in code review shows exactly what changed. Golden files are only as good as the review of their diffs.

### Comparing complex values

`==` works for comparable values; `slices.Equal` and `maps.Equal` for slices and maps; `reflect.DeepEqual` for arbitrary nesting (but with poor failure messages). Many teams use `github.com/google/go-cmp/cmp`, whose `cmp.Diff(want, got)` prints a readable diff.

### Deep & Tricky

**DT-182. `TestMain` controls the whole package's test run.** *(Guarantee)* `func TestMain(m *testing.M) { setup(); code := m.Run(); teardown(); os.Exit(code) }` runs once per package. Use it for expensive shared fixtures (a database container, Unit 9.8). Since Go 1.15 you may simply return instead of calling `os.Exit`; the testing framework exits with the right code.

**DT-183. Parallel subtests run after the parent function returns.** *(Guarantee)* A parent test's deferred calls run *before* its parallel subtests execute, so a `defer db.Close()` in the parent closes the database the subtests still need. Use `t.Cleanup` in the parent, which waits for subtests.

### Mastery check

1. **Explain.** Why is `t.Cleanup` better than `defer` inside a helper function?
2. **Explain.** What is a golden file, and what discipline makes golden tests trustworthy?
3. **Write.** A helper `writeFile(t, dir, name, content string) string` that creates a file in `t.TempDir()` and returns its path; use it in a table test of a function that counts lines in a file.

## Unit 4.3 — Coverage and examples

**One-line summary:** Coverage shows which statements tests executed — a map of what is *untested*, not a proof of correctness. Example functions are tests that double as documentation: their output is checked, and they appear in `go doc` and on pkg.go.dev.

### Coverage

```
$ go test -cover ./...
ok   example.com/library/internal/catalog   coverage: 84.2% of statements
$ go test -coverprofile=cover.out ./...
$ go tool cover -func=cover.out      # per function
$ go tool cover -html=cover.out      # open a colour-coded view in the browser
```

How to use it well:

- Look at the **red lines** in the HTML view. Are they error paths? Boundary conditions? Those are where bugs hide (the Chapter 1 lesson: the path you never ran is the one that breaks).
- Do not chase 100%. Some code (a `main` that only wires things, a "should never happen" panic) is not worth testing. 70–90% is typical for well-tested Go packages; the *right* number depends on risk.
- 100% coverage does not mean correct: every line can run while the assertions check nothing. The Chapter 4 project shows a bug that a high-coverage suite misses.
- `-coverpkg=./...` counts coverage of *all* packages exercised, not just the package under test (useful for integration tests). `go build -cover` builds a binary that writes coverage when run, for coverage from end-to-end tests.

### Example functions

```go
func ExampleAbs() {
	fmt.Println(Abs(-5))
	fmt.Println(Abs(7))
	// Output:
	// 5
	// 7
}
```

- Named `Example`, `ExampleFunc`, `ExampleType`, `ExampleType_Method`, optionally with a `_suffix` (`ExampleAbs_negative`).
- `go test` runs it and compares stdout with the `// Output:` comment. `// Unordered output:` ignores line order (handy for map output). Without an output comment, the example is compiled but not run.
- `go doc` and pkg.go.dev show it next to the function. Users copy examples; making them compiled and checked guarantees they work.

### Deep & Tricky

**DT-184. Coverage counts statements, not branches or conditions.** *(Tool behaviour)* `if a && b {` is one statement; a test where `a` is false covers the line but never evaluates `b`. Coverage of 100% says nothing about whether each condition was tried both ways. Think in terms of cases, not lines.

### Mastery check

1. **Explain.** Give an example of a function with 100% coverage and a serious bug the tests did not catch.
2. **Write.** Two example functions for a package of your own, one with `// Output:` and one for a map-based function with `// Unordered output:`. Break one deliberately and read the failure.

## Unit 4.4 — Designing for testability

**One-line summary:** Code is easy to test when its dependencies (time, randomness, storage, network, the file system, stdin/stdout) come in through parameters or small interfaces. Then tests can substitute **fakes**, **stubs**, or **recorders** — no mocking framework needed.

### The seams

A **seam** is a place where a test can swap in a different implementation without changing the code under test.

| Dependency | Seam | Test substitute |
| --- | --- | --- |
| Current time | `now func() time.Time` field or parameter | fixed or advancing fake clock |
| Randomness | `*rand.Rand` parameter | `rand.New(rand.NewPCG(1, 2))` (Unit 1.13) |
| Storage | small interface (`catalog.Store`) | in-memory implementation |
| HTTP services | interface, or an `*http.Client` / base URL | `httptest.Server` (Unit 8.7) |
| Output | `io.Writer` parameter | `*strings.Builder` / `bytes.Buffer` |
| Input | `io.Reader` parameter | `strings.NewReader("...")` |
| Environment, args | `run(args []string, env func(string) string)` | literal values |

The `run(args, stdin, stdout)` pattern (P-14) is the same idea at program level: `main` passes the real `os.Stdin`/`os.Stdout`; tests pass buffers.

### Kinds of test doubles

- **Fake:** a working, simplified implementation (an in-memory store). The most useful kind: tests read naturally and check *behaviour*.
- **Stub:** returns canned answers ("always return `ErrNotFound`") — good for forcing error paths.
- **Recorder (spy):** remembers the calls it received so the test can check them (the `RecordingNotifier` in Unit 3.4).
- **Mock:** a stub plus expectations about exactly which calls happen in which order. Mocks generated by tools couple tests to implementation details; prefer fakes and assert on outcomes. Use strict mocks only when the *interaction itself* is the behaviour (for example "charge the card exactly once").

### A stub that forces an error path

Embed a real fake and override one method (the outer method shadows the promoted one, Unit 3.7):

```go
// failingLoans is a stub: a real in-memory store whose Loans method fails.
type failingLoans struct {
	*store.Memory
}

func (failingLoans) Loans() ([]catalog.Loan, error) {
	return nil, errors.New("disk on fire")
}

func TestBorrowStorageError(t *testing.T) {
	mem := store.NewMemory()
	if err := mem.PutBook(catalog.Book{ID: "b1", Title: "T", Copies: 1}); err != nil {
		t.Fatal(err)
	}
	if err := mem.PutMember(catalog.Member{ID: "m1"}); err != nil {
		t.Fatal(err)
	}
	lib := catalog.New(failingLoans{mem})
	_, err := lib.Borrow("b1", "m1")
	if err == nil || !strings.Contains(err.Error(), "disk on fire") {
		t.Fatalf("Borrow error = %v, want the storage error", err)
	}
}
```

This is the decorator pattern of P-24 used for testing. Note what the test checks: that the storage error *reaches the caller* (with context added), not which internal calls happened.

### Don't over-abstract

Not every dependency needs an interface. Pure functions need no seams at all. A package that only formats strings needs none. Add a seam when a test needs it, at the boundary to something slow, nondeterministic, or external.

### Pattern

**P-28. Inject time, randomness, and I/O; keep the core pure.** *(Testability practice)*

- *Problem it solves:* tests that are slow, flaky (depend on the clock or the network), or impossible (how do you test "after 14 days"?).
- *How:* pass `now func() time.Time`, `*rand.Rand`, `io.Reader`/`io.Writer`, and consumer-defined interfaces (P-23). Production wiring happens in `main`. Keep business rules in functions that take values and return values.
- *When not to:* trivial code, or when the real dependency is fast and deterministic (an in-process `map` does not need a seam).
- *Trade-off:* a few extra parameters or fields in exchange for fast, deterministic tests.

### Mastery check

1. **Explain.** Fake vs stub vs mock: which would you use to test "a member cannot borrow when the store fails", and why?
2. **Write.** A function `greeting(now func() time.Time) string` that says "Good morning/afternoon/evening"; test all three plus the boundaries (11:59:59, 12:00:00) without waiting for the clock.

## Topic 4B — Measuring and fuzzing

## Unit 4.5 — Benchmarks

**One-line summary:** Benchmarks are functions `BenchmarkXxx(b *testing.B)` that run code many times and report time and allocations per operation. Measure before optimising, compare runs statistically with `benchstat`, and beware of benchmarks that measure the wrong thing.

### Writing a benchmark

```go
func BenchmarkJoin(b *testing.B) {
	parts := strings.Fields(strings.Repeat("go ", 1000)) // setup: not timed (Go 1.24 b.Loop)
	b.ReportAllocs()
	for b.Loop() { // Go 1.24+: runs the body as many times as needed
		_ = strings.Join(parts, ",")
	}
}
```

```
$ go test -run XXX -bench Join -benchmem
BenchmarkJoin-8   	  200000	      5321 ns/op	    3072 B/op	       1 allocs/op
```

- `-run XXX` (any pattern that matches no test) skips the normal tests. `-bench .` runs all benchmarks.
- Columns: iterations, time per operation, bytes allocated per operation, allocations per operation. The `-8` suffix is GOMAXPROCS.
- `b.Loop()` (Go 1.24) is the modern form. It times only the loop, keeps the body's results alive so the compiler cannot delete the work, and runs setup code before the loop exactly once. Older code uses `for i := 0; i < b.N; i++ { ... }` with `b.ResetTimer()` after setup; both are still valid.

### Comparing with `benchstat`

A single benchmark run is noisy (CPU frequency, other processes, thermal state). Run each version several times and compare statistically:

```
$ go test -run XXX -bench List -count 10 > old.txt
  ... change the code ...
$ go test -run XXX -bench List -count 10 > new.txt
$ go run golang.org/x/perf/cmd/benchstat@latest old.txt new.txt
name    old time/op    new time/op    delta
List-8    982µs ± 2%     41µs ± 3%   -95.83%  (p=0.000 n=10+10)
```

`benchstat` reports the median, the variation, and whether the difference is statistically significant (`p` < 0.05). "± 15%" variation means your machine is too noisy to detect small changes; quiet it down (close other programs, plug in a laptop) before trusting results.

### Misleading benchmarks

- **Dead-code elimination:** with the old `b.N` loop, `for i := 0; i < b.N; i++ { square(5) }` may be compiled away when the result is unused — a "0.3 ns/op" miracle. `b.Loop` prevents this; with `b.N`, assign results to a package-level sink variable.
- **Unrealistic inputs:** benchmarking with 10 elements says little about 10 million (caches, Unit 0.5). Benchmark with realistic sizes, often several (`b.Run("n=1000", ...)` sub-benchmarks).
- **Measuring setup:** setup inside the timed loop dominates the result.
- **Warm caches:** repeating the same input keeps everything in L1 cache; real workloads may not.
- **Comparing across machines:** only compare runs from the same machine and conditions.

### Allocations

`testing.AllocsPerRun(100, func() {...})` returns the average allocation count; tests can assert "this hot function does not allocate" to stop regressions.

### Deep & Tricky

**DT-185. A benchmark is a hypothesis test, not a speed reading.** *(Practice)* The question is "is B faster than A on this workload, beyond the noise?" — which needs multiple runs and a statistical comparison. A single run that shows a 3% improvement is usually noise.

**DT-186. The library project's `List` benchmark reveals an O(books × loans) loop.** *(Seen in this book's own benchmark)* `countLoans` scans every loan for every book: about 1 ms for 1,000 books with 334 loans. Counting loans per book once into a map makes it O(books + loans). Chapter 6 gives the vocabulary (Big-O) and Chapter 10 the tooling (profiles) to find such loops systematically.

### Mastery check

1. **Explain.** Why can a benchmark report 0.3 ns/op for a function that computes something, and how does `b.Loop` prevent it?
2. **Write.** Benchmarks for three ways of building a 10,000-element comma-separated string (`+=`, `strings.Builder`, `strings.Join`), with `-benchmem`; run them 10 times each and compare with `benchstat`. Explain the allocation counts.

## Unit 4.6 — Fuzzing

**One-line summary:** A fuzz test (`FuzzXxx(f *testing.F)`) feeds automatically mutated inputs to your code, looking for crashes and violated properties. It is especially powerful for parsers and anything that handles untrusted input. Failing inputs are saved and become permanent regression tests.

### Writing a fuzz test

```go
func FuzzParseGenre(f *testing.F) {
	for _, s := range []string{"fiction", "SCIENCE", "", "unknown", "hist ory"} {
		f.Add(s) // the seed corpus
	}
	f.Fuzz(func(t *testing.T, s string) {
		g, err := catalog.ParseGenre(s)
		if err != nil {
			if g != catalog.GenreUnknown {
				t.Errorf("error with non-zero genre %v", g)
			}
			return
		}
		// Property: the name of a parsed genre parses back to the same genre.
		g2, err := catalog.ParseGenre(g.String())
		if err != nil || g2 != g {
			t.Errorf("round trip %q -> %v -> %v, %v", s, g, g2, err)
		}
	})
}
```

- `go test` (without `-fuzz`) runs the fuzz function on the seed corpus only — a normal, fast test.
- `go test -fuzz FuzzParseGenre -fuzztime 30s` mutates inputs (coverage-guided: inputs that reach new code are kept and mutated further).
- A failing input is written to `testdata/fuzz/FuzzParseGenre/<hash>`. Commit it: from then on, plain `go test` re-runs it.
- Arguments may be strings, `[]byte`, integers, floats, bools, and runes.

### What to assert: properties

You cannot write the expected output for random input, so fuzz tests check **properties** that must always hold:

- **No panic** (the minimum — any panic fails the test).
- **Round trip:** `Parse(Format(x)) == x`, `Decode(Encode(b)) == b`.
- **Equivalence:** a fast implementation gives the same answer as a slow, obviously-correct one.
- **Invariants:** output is valid UTF-8; length never exceeds input length; a sorted result is sorted.

### Deep & Tricky

**DT-187. Fuzzing uses all CPU cores and grows the cache.** *(Toolchain behaviour)* `-fuzz` runs workers on every core (`-parallel` limits it) and stores generated corpus entries in the build cache (`$GOCACHE/fuzz`), which can grow large; `go clean -fuzzcache` empties it. In CI, fuzz for a fixed `-fuzztime` on a schedule, not on every commit.

### Mastery check

1. **Explain.** Why does a fuzz test check properties rather than exact outputs? Give three properties for a URL parser.
2. **Write.** A fuzz test for `splitWords` from the Chapter 2 project with the properties: never panics, every word is non-empty, contains no spaces, and is lower case (`strings.ToLower(w) == w`). Run it for a minute. Did it find anything? (Think about DT-116 before you answer.)

## Topic 4C — Tools and debugging

## Unit 4.7 — Static analysis

**One-line summary:** Static analysers read your code without running it and report likely bugs. Run `gofmt`, `go vet`, and `staticcheck` on every change, `govulncheck` regularly, and consider `golangci-lint` to run many linters together.

### The toolbox

| Tool | What it catches | How |
| --- | --- | --- |
| `gofmt` / `goimports` | formatting; `goimports` also adds and removes imports | `gofmt -l .` lists unformatted files (CI fails if non-empty) |
| `go vet` | suspicious constructs: printf mismatches, copied locks (DT-136), unreachable code, bad struct tags, `errors.As` misuse, self-assignment, loop-closure capture in old code, recursive `String` (DT-139) | `go vet ./...` |
| `staticcheck` | hundreds of checks: deprecated APIs, impossible conditions (`uint >= 0`, DT-22), unused code, simplifications, common bugs | `go run honnef.co/go/tools/cmd/staticcheck@latest ./...` |
| `govulncheck` | known vulnerabilities in dependencies **that your code actually calls** | `go run golang.org/x/vuln/cmd/govulncheck@latest ./...` |
| `golangci-lint` | runs many linters (including the above, `errcheck`, `gosec`, `revive`, `exhaustive`, shadow checks) with one config | `golangci-lint run` |
| `go fix` | (Go 1.26 rewrite) applies "modernizers": replaces old idioms with new ones (`interface{}` → `any`, loops → `slices.Contains`, `errors.As` → `errors.AsType`, …) | `go fix ./...` |

`govulncheck` is notable: it does not just list vulnerable *modules* in `go.mod`; it analyses the call graph and reports only vulnerabilities in functions your program can reach, so the results are actionable.

### Making it automatic

- Editor: gopls runs vet-like checks and staticcheck on save.
- Pre-commit or CI: `gofmt -l`, `go vet ./...`, `staticcheck ./...`, `go test -race ./...`, `govulncheck ./...` (Unit 11.7 builds the full pipeline).
- Treat warnings as errors in CI; a linter whose output everyone ignores is worse than none.

### Deep & Tricky

**DT-188. Linters can be silenced line by line, and that should be rare and explained.** *(Tool behaviour)* `//lint:ignore SA1019 reason` (staticcheck) or `//nolint:errcheck // reason` (golangci-lint) suppress a finding. Require a reason in the comment so reviewers can judge it.

### Mastery check

1. **Explain.** Why is `govulncheck`'s call-graph analysis more useful than a list of vulnerable module versions?
2. **Write.** Take any program from Chapters 1–3, deliberately add: a printf with the wrong number of arguments, a copied `sync.Mutex`, an unsigned `>= 0` loop, and an ignored error. Run `go vet` and `staticcheck`; which tool finds which?

## Unit 4.8 — Debugging

**One-line summary:** Debugging is a method, not luck: reproduce, read the evidence (the panic message and stack trace), form a hypothesis, test it with the smallest experiment, fix, and add a test so it never returns. Delve is the Go debugger for stepping through code and inspecting goroutines.

### Reading a panic

```
panic: runtime error: index out of range [5] with length 3

goroutine 1 [running]:
main.lastScore(...)
        /home/asha/proj/main.go:12
main.report({0xc000012345, 0x3, 0x3})
        /home/asha/proj/main.go:20 +0x1d
main.main()
        /home/asha/proj/main.go:27 +0x45
exit status 2
```

Read it top down: the **message** says what (index 5, length 3); the **first frame** in your code says where (`main.go:12`); the frames below say how you got there. `(...)` marks an inlined frame (DT-40). The hex values in `report({0xc000012345, 0x3, 0x3})` are the raw words of the arguments: a slice is shown as its three-word header (pointer, len 3, cap 3, Unit 2.2). `GOTRACEBACK=all` prints every goroutine; `GOTRACEBACK=crash` also produces a core dump on supported systems. Since Go 1.27, goroutine headers also show `runtime/pprof` labels, if the program sets them (Unit 10.2).

### A systematic method

1. **Reproduce** reliably — ideally as a failing test. A bug you cannot reproduce you cannot verify as fixed.
2. **Read the evidence:** the full error message, the stack, the logs around the failure, recent changes (`git log`, `git bisect` to find the commit that introduced it).
3. **Hypothesise:** "the slice is empty when the input file has a trailing blank line".
4. **Test the hypothesis** with the smallest experiment: a print, an assertion, a debugger breakpoint, a narrowed test case. Change one thing at a time.
5. **Fix the cause, not the symptom.** A `recover` that hides a panic is not a fix.
6. **Add the regression test** (the failing test from step 1 now passes) and look for the same bug elsewhere.

### Delve

```
$ go install github.com/go-delve/delve/cmd/dlv@latest
$ dlv debug ./cmd/library -- borrow b1 m1     # build with debug info and start
(dlv) break catalog.(*Library).Borrow         # or: break catalog.go:97
(dlv) continue
(dlv) next          # next line (step over calls)
(dlv) step          # step into a call
(dlv) print book    # inspect a variable; also: locals, args
(dlv) stack         # current goroutine's stack
(dlv) goroutines    # all goroutines (essential for Chapter 7)
(dlv) quit
$ dlv test ./internal/catalog -- -test.run TestBorrowAndReturn   # debug a test
```

Delve understands Go: it prints slices, maps, strings, and interfaces properly and knows about goroutines. Editors (VS Code, GoLand) use it underneath. For optimised builds, variables may be "optimized away"; `dlv debug` builds with `-gcflags='all=-N -l'` (no optimisation, no inlining) for you.

### Print debugging is fine — with care

A quick `fmt.Fprintf(os.Stderr, "DEBUG n=%d s=%q\n", n, s)` is often the fastest experiment. Use `%q` and `%#v` to see exact values (hidden spaces, nil vs empty). Remove them before committing; for permanent diagnostics use structured logging (Unit 5.8).

### Deep & Tricky

**DT-189. Stack traces show argument words, not argument values.** *(Runtime behaviour)* The hex numbers after a function name are the raw machine words of its arguments (strings as pointer + length, slices as pointer + len + cap, interfaces as two words), truncated after a few words and possibly inaccurate for register-passed arguments (marked `?` in newer versions). Use them for hints (a length of 0, a nil pointer `0x0`), not as reliable values.

### Mastery check

1. **Explain.** Walk through the six steps of the debugging method with a real bug from your own work in this book.
2. **Write.** Introduce an off-by-one into `wordfreq`'s top-N cut, reproduce it with a test, then use Delve to break in `run`, inspect `entries`, and confirm your hypothesis before fixing it.

## Chapter 4 Project — A real test suite, and a bug hunt

**Goal:** turn the Chapter 3 `library` into a properly tested codebase, measure it, and then prove your tests work by hunting planted bugs.

### Part 1 — Build the test suite

Add, to the Chapter 3 project:

1. **Table-driven validation tests** for `AddBook`: empty ID, blank ID, empty title, zero copies, negative copies — each asserting the *field* of the `*ValidationError`.
2. **`List` ordering test** with two books of the same title (ordering must fall back to ID) and availability counts after a loan.
3. **`Overdue` boundary tests** with a controllable fake clock: before the due date, *exactly at* the due date (not overdue), one second after, and after two loans.
4. **Store tests** (`internal/store/store_test.go`, white-box): a `File` round trip through `t.TempDir()`, a corrupt-file error, no `.tmp` file left behind, and a test proving callers cannot modify store data through returned or passed slices.
5. **Golden test** for the `list` command output via `run`, with an `-update` flag.
6. **Usage-error tests** for `run`.
7. **A fuzz test** for `ParseGenre` (round-trip property).
8. **A benchmark** for `List` with 1,000 books.

Target: `go test -cover ./...` above 80% for `catalog` and `store`, and the whole suite under one second (excluding fuzzing).

### Reference test suite

`internal/catalog/list_test.go`:

```go
package catalog_test

import (
	"errors"
	"testing"
	"time"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

// fakeClock is a controllable clock for tests.
type fakeClock struct{ t time.Time }

func (c *fakeClock) Now() time.Time          { return c.t }
func (c *fakeClock) Advance(d time.Duration) { c.t = c.t.Add(d) }

func TestList(t *testing.T) {
	lib := catalog.New(store.NewMemory())
	books := []catalog.Book{
		{ID: "b2", Title: "Zebra", Copies: 2},
		{ID: "b1", Title: "Apple", Copies: 1},
		{ID: "b3", Title: "Apple", Copies: 3},
	}
	for _, b := range books {
		if err := lib.AddBook(b); err != nil {
			t.Fatal(err)
		}
	}
	if err := lib.AddMember(catalog.Member{ID: "m1"}); err != nil {
		t.Fatal(err)
	}
	if _, err := lib.Borrow("b3", "m1"); err != nil {
		t.Fatal(err)
	}

	got, err := lib.List()
	if err != nil {
		t.Fatal(err)
	}
	want := []struct {
		id    string
		avail int
	}{{"b1", 1}, {"b3", 2}, {"b2", 2}} // by title, then ID
	if len(got) != len(want) {
		t.Fatalf("len = %d, want %d", len(got), len(want))
	}
	for i, w := range want {
		if got[i].Book.ID != w.id || got[i].Available != w.avail {
			t.Errorf("row %d = %s/%d, want %s/%d", i, got[i].Book.ID, got[i].Available, w.id, w.avail)
		}
	}
}

func TestOverdue(t *testing.T) {
	clock := &fakeClock{t: time.Date(2026, 3, 1, 9, 0, 0, 0, time.UTC)}
	lib := catalog.New(store.NewMemory()).WithClock(clock.Now)
	for _, err := range []error{
		lib.AddBook(catalog.Book{ID: "b1", Title: "T", Copies: 2}),
		lib.AddMember(catalog.Member{ID: "m1"}),
		lib.AddMember(catalog.Member{ID: "m2"}),
	} {
		if err != nil {
			t.Fatal(err)
		}
	}
	if _, err := lib.Borrow("b1", "m1"); err != nil {
		t.Fatal(err)
	}
	clock.Advance(24 * time.Hour)
	if _, err := lib.Borrow("b1", "m2"); err != nil {
		t.Fatal(err)
	}

	tests := []struct {
		name  string
		after time.Duration // from the first loan
		want  int
	}{
		{"before any due date", 13 * 24 * time.Hour, 0},
		{"exactly at first due date", 14 * 24 * time.Hour, 0}, // due, not yet overdue
		{"just after first due date", 14*24*time.Hour + time.Second, 1},
		{"after both", 16 * 24 * time.Hour, 2},
	}
	start := time.Date(2026, 3, 1, 9, 0, 0, 0, time.UTC)
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			clock.t = start.Add(tt.after)
			got, err := lib.Overdue()
			if err != nil {
				t.Fatal(err)
			}
			if len(got) != tt.want {
				t.Errorf("Overdue() returned %d loans, want %d", len(got), tt.want)
			}
		})
	}
}

func TestAddBookValidation(t *testing.T) {
	tests := []struct {
		name      string
		book      catalog.Book
		wantField string
	}{
		{"empty id", catalog.Book{Title: "T", Copies: 1}, "id"},
		{"blank id", catalog.Book{ID: "  ", Title: "T", Copies: 1}, "id"},
		{"empty title", catalog.Book{ID: "x", Copies: 1}, "title"},
		{"zero copies", catalog.Book{ID: "x", Title: "T"}, "copies"},
		{"negative copies", catalog.Book{ID: "x", Title: "T", Copies: -2}, "copies"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			lib := catalog.New(store.NewMemory())
			err := lib.AddBook(tt.book)
			var ve *catalog.ValidationError
			if !errors.As(err, &ve) {
				t.Fatalf("got %v, want a *ValidationError", err)
			}
			if ve.Field != tt.wantField {
				t.Errorf("field = %q, want %q", ve.Field, tt.wantField)
			}
		})
	}
}

func FuzzParseGenre(f *testing.F) {
	for _, s := range []string{"fiction", "SCIENCE", "", "unknown", "hist ory"} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) {
		g, err := catalog.ParseGenre(s)
		if err != nil {
			if g != catalog.GenreUnknown {
				t.Errorf("error with non-zero genre %v", g)
			}
			return
		}
		// Round trip: the name of a parsed genre parses to the same genre.
		g2, err := catalog.ParseGenre(g.String())
		if err != nil || g2 != g {
			t.Errorf("round trip %q -> %v -> %v, %v", s, g, g2, err)
		}
	})
}

func BenchmarkList(b *testing.B) {
	lib := catalog.New(store.NewMemory())
	_ = lib.AddMember(catalog.Member{ID: "m"})
	for i := range 1000 {
		id := "b" + string(rune('a'+i%26)) + time.Duration(i).String()
		_ = lib.AddBook(catalog.Book{ID: id, Title: id, Copies: 2})
		if i%3 == 0 {
			_, _ = lib.Borrow(id, "m")
		}
	}
	b.ReportAllocs()
	for b.Loop() {
		if _, err := lib.List(); err != nil {
			b.Fatal(err)
		}
	}
}
```

`internal/store/store_test.go`:

```go
package store

import (
	"os"
	"path/filepath"
	"testing"
	"time"

	"example.com/library/internal/catalog"
)

func TestFileRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "lib.json") // removed automatically after the test
	f, err := OpenFile(path)
	if err != nil {
		t.Fatal(err)
	}
	due := time.Date(2026, 5, 1, 0, 0, 0, 0, time.UTC)
	must(t, f.PutBook(catalog.Book{ID: "b1", Title: "Go", Genre: catalog.Science, Copies: 2}))
	must(t, f.PutMember(catalog.Member{ID: "m1", Name: "Asha"}))
	must(t, f.PutLoans([]catalog.Loan{{BookID: "b1", MemberID: "m1", Due: due}}))

	g, err := OpenFile(path) // a fresh load from disk
	if err != nil {
		t.Fatal(err)
	}
	b, err := g.Book("b1")
	if err != nil || b.Title != "Go" || b.Genre != catalog.Science || b.Copies != 2 {
		t.Errorf("book after reload = %+v, %v", b, err)
	}
	loans, _ := g.Loans()
	if len(loans) != 1 || !loans[0].Due.Equal(due) {
		t.Errorf("loans after reload = %+v", loans)
	}
	if _, err := os.Stat(path + ".tmp"); !os.IsNotExist(err) {
		t.Errorf("temporary file left behind: %v", err)
	}
}

func TestOpenFileCorrupt(t *testing.T) {
	path := filepath.Join(t.TempDir(), "bad.json")
	if err := os.WriteFile(path, []byte("{not json"), 0o644); err != nil {
		t.Fatal(err)
	}
	if _, err := OpenFile(path); err == nil {
		t.Fatal("expected an error for a corrupt file")
	}
}

func TestLoansAreCopies(t *testing.T) {
	m := NewMemory()
	in := []catalog.Loan{{BookID: "b1"}}
	must(t, m.PutLoans(in))
	in[0].BookID = "changed-by-caller"
	out, _ := m.Loans()
	out[0].MemberID = "changed-by-reader"
	again, _ := m.Loans()
	if again[0].BookID != "b1" || again[0].MemberID != "" {
		t.Errorf("store data was modified through a slice: %+v", again[0])
	}
}

func must(t *testing.T, err error) {
	t.Helper() // failures are reported at the caller's line
	if err != nil {
		t.Fatal(err)
	}
}
```

`cmd/library/main_test.go`:

```go
package main

import (
	"flag"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

var update = flag.Bool("update", false, "rewrite golden files")

func TestListGolden(t *testing.T) {
	t.Setenv("LIBRARY_DATA", filepath.Join(t.TempDir(), "lib.json"))
	steps := [][]string{
		{"add-book", "b1", "2", "science", "The Go Programming Language"},
		{"add-book", "b2", "1", "fiction", "Malgudi Days"},
		{"add-member", "m1", "Asha"},
		{"borrow", "b2", "m1"},
	}
	for _, args := range steps {
		if err := run(args, new(strings.Builder)); err != nil {
			t.Fatalf("%v: %v", args, err)
		}
	}
	var out strings.Builder
	if err := run([]string{"list"}, &out); err != nil {
		t.Fatal(err)
	}

	golden := filepath.Join("testdata", "list.golden")
	if *update {
		if err := os.WriteFile(golden, []byte(out.String()), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	want, err := os.ReadFile(golden)
	if err != nil {
		t.Fatal(err)
	}
	if out.String() != string(want) {
		t.Errorf("list output differs from %s:\n got: %q\nwant: %q", golden, out.String(), want)
	}
}

func TestUsageErrors(t *testing.T) {
	t.Setenv("LIBRARY_DATA", filepath.Join(t.TempDir(), "lib.json"))
	for _, args := range [][]string{nil, {"fly"}, {"borrow", "only-one"}} {
		err := run(args, new(strings.Builder))
		if err == nil || !strings.Contains(err.Error(), "bad usage") {
			t.Errorf("run(%q) = %v, want a usage error", args, err)
		}
	}
}
```

Real results with this suite:

```
$ go test -cover ./...
ok   example.com/library/cmd/library        coverage: 52.5% of statements
ok   example.com/library/internal/catalog   coverage: 84.2% of statements
ok   example.com/library/internal/store     coverage: 82.0% of statements
$ go test -run XXX -bench List ./internal/catalog
BenchmarkList-2   	     200	    982272 ns/op	  238784 B/op	      13 allocs/op
```

### Part 2 — The bug hunt

Copy the project and apply each of the following **planted bugs** one at a time. Before running the tests, *predict* which test (if any) will fail. Then run `go test ./...` and compare. Record prediction and result in a table.

| # | File | Change |
| --- | --- | --- |
| 1 | `catalog.go`, `Borrow` | `out >= book.Copies` → `out > book.Copies` |
| 2 | `catalog.go`, `Overdue` | `return !ln.Due.Before(now)` → `return ln.Due.After(now)` |
| 3 | `catalog.go`, `List` | tie-break `strings.Compare(a.Book.ID, b.Book.ID)` → `strings.Compare(b.Book.ID, a.Book.ID)` |
| 4 | `store.go`, `Memory.Loans` | `return slices.Clone(m.loans), nil` → `return m.loans, nil` |
| 5 | `catalog.go`, `AddBook` | delete the line `b.ID = strings.TrimSpace(b.ID)` |
| 6 | `store.go`, `save` | `return os.Rename(tmp, f.path)` → `return nil` |
| 7 | `catalog.go`, `Return` | `slices.Delete(loans, i, i+1)` → `slices.Delete(loans, 0, 1)` |

### Part 3 — Optimise with evidence

Rewrite `List` so it counts loans per book once (a `map[string]int`), keep the behaviour identical (the tests prove it), and compare old and new with `-count 10` and `benchstat`.

### Answer key for the bug hunt (verified by running each bug)

| # | Tests that fail | Why |
| --- | --- | --- |
| 1 | `TestBorrowAndReturn` | The second borrow of a 1-copy book succeeds instead of `ErrNoCopies`. |
| 2 | `TestOverdue/exactly_at_first_due_date` | A loan *due* right now is wrongly reported as overdue: a boundary bug, caught only because the table has the boundary row. |
| 3 | `TestList` | Same-title books come out in reverse ID order. |
| 4 | `TestLoansAreCopies` **and** `TestOverdue` (two subtests) | Surprise: `Overdue` calls `slices.DeleteFunc` on the slice returned by `Loans`. Without the clone, that *modifies the store's own loans* (Unit 2.4 aliasing), so later subtests see loans that have vanished. One missing `Clone` broke an unrelated feature. |
| 5 | `TestAddBookValidation/blank_id` | `"  "` is no longer rejected. |
| 6 | `TestFileRoundTrip` and `TestListGolden` | Data is written to `.tmp` and never renamed, so a reload sees nothing. |
| 7 | **None.** | Every test returns the *only* loan, so removing index 0 happens to be correct. The suite has high coverage and still misses it. |

Bug 7 is the most important lesson of the chapter: **coverage showed the line ran, but no test checked the case that distinguishes right from wrong.** The fix is a new test where the loan to return is not the first one:

```go
func TestReturnRemovesTheRightLoan(t *testing.T) {
	lib := catalog.New(store.NewMemory())
	for _, err := range []error{
		lib.AddBook(catalog.Book{ID: "b1", Title: "A", Copies: 1}),
		lib.AddBook(catalog.Book{ID: "b2", Title: "B", Copies: 1}),
		lib.AddMember(catalog.Member{ID: "m1"}),
	} {
		if err != nil {
			t.Fatal(err)
		}
	}
	for _, id := range []string{"b1", "b2"} {
		if _, err := lib.Borrow(id, "m1"); err != nil {
			t.Fatal(err)
		}
	}
	if err := lib.Return("b2", "m1"); err != nil { // return the SECOND loan
		t.Fatal(err)
	}
	items, err := lib.List()
	if err != nil {
		t.Fatal(err)
	}
	for _, it := range items {
		want := map[string]int{"b1": 0, "b2": 1}[it.Book.ID]
		if it.Available != want {
			t.Errorf("%s available = %d, want %d", it.Book.ID, it.Available, want)
		}
	}
}
```

With bug 7 applied it fails with `b1 available = 1, want 0` and `b2 available = 0, want 1`. This technique — deliberately breaking code to check that tests notice — is called **mutation testing**, and tools exist to automate it.

### Review checklist

- Does every test name say what behaviour it checks?
- Would each assertion's failure message be understandable in CI without opening the code?
- Is any test dependent on time, map order, or another test (run with `-shuffle=on -count=3`)?
- For each `if` in the domain code, is there a test for both outcomes — and for the boundary?
- Is the benchmark comparison backed by `benchstat` output, not one run?

## Answers to the Chapter 4 prediction questions

**4.1 Q2.** With `t.Run`, all five cases run: `t.Fatalf` stops only the failing subtest. Without `t.Run`, `t.Fatalf` stops the whole test function at the second case, so cases 3–5 never run (and you do not learn whether they pass).

**4.6 Q2.** Most likely nothing. When this exercise was run for 40 seconds (2.2 million inputs), the fuzzer found no violation: lower-casing each rune with `unicode.ToLower` and lower-casing the whole word with `strings.ToLower` agree, and the word rules never admit spaces. Two lessons. First, a passing fuzz run is *evidence*, not proof: random byte mutations rarely produce specific multi-byte characters, so add seeds from every script and edge case you care about (Turkish `İ`, German `ß`, combining marks, emoji). Second, the act of writing the properties forced you to decide what a "word" must satisfy — often the most valuable part of fuzzing.
