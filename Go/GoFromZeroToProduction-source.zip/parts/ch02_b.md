## Topic 2C — Maps

## Unit 2.7 — Maps I

**One-line summary:** A map stores key → value pairs and finds a value by its key in constant time on average, using a hash table. Reading a missing key gives the zero value; the comma-ok form tells you whether the key was really there. Writing to a nil map panics, and iteration order is deliberately random.

**Mental model — the post office sorting rack.** A post office has a rack of pigeonholes. To store a letter, the clerk computes a pigeonhole number from the address (the **hash**) and puts the letter there. To find it later, the same computation sends him straight to the right pigeonhole — no need to search all letters. Sometimes two addresses land in the same pigeonhole (a **collision**); he then checks the few letters in that hole one by one. When the rack gets too full, he builds a bigger rack and re-sorts everything.

### Creating and using maps

```go
ages := map[string]int{       // map literal
	"Asha": 31,
	"Ravi": 28,               // trailing comma required on multi-line literals (DT-17)
}
scores := make(map[string]int)      // empty, ready to use
big := make(map[int]string, 10_000) // size hint: room for ~10,000 entries without growing
var m map[string]int                // nil map: reading works, WRITING PANICS

ages["Meera"] = 35            // insert or overwrite
fmt.Println(ages["Asha"])     // 31
fmt.Println(ages["Nobody"])   // 0 — missing key gives the zero value, no error
delete(ages, "Ravi")          // remove; deleting a missing key is a no-op
fmt.Println(len(ages))        // 2
```

### The comma-ok idiom

Because a missing key returns the zero value, `ages["Nobody"] == 0` cannot tell "missing" from "present with value 0". The two-result form can:

```go
age, ok := ages["Nobody"] // ok == false: the key is not in the map
if v, ok := ages["Asha"]; ok {
	fmt.Println("found", v)
}
```

This `(value, ok)` shape appears throughout Go: maps, type assertions (Unit 3.6), channel receives (Unit 7.3). Use it whenever the zero value is a meaningful value.

**Counting with the zero value.** The missing-key rule makes counting elegant:

```go
counts := make(map[string]int)
for _, w := range words {
	counts[w]++ // missing key reads as 0, then 1 is stored
}
```

The same trick works for grouping: `groups[k] = append(groups[k], v)` — a missing key gives a nil slice, and appending to nil works (DT-106).

### Nil maps

```go
var m map[string]int
fmt.Println(m["x"], len(m)) // 0 0 — reading is fine
for k, v := range m {}      // zero iterations — fine
delete(m, "x")              // fine (no-op)
m["x"] = 1                  // panic: assignment to entry in nil map
```

A nil map has no hash table to write into. Always `make` (or use a literal) before writing. This is the most common map panic in real code, typically from a struct field `map[...]...` that was never initialised (Unit 3.8 shows constructors that prevent it).

### Iteration order is random

```go
for name, age := range ages {
	fmt.Println(name, age) // order differs from run to run
}
```

The Go runtime deliberately randomises the starting point of every map iteration. Code that accidentally depended on insertion order would break mysteriously on another Go version; making the order random from day one makes such bugs show up immediately in tests. When you need a stable order — reports, tests, anything a human reads — collect the keys and sort them (Unit 2.8).

### Which types can be keys?

Keys must be **comparable** with `==`: booleans, numbers, strings, pointers, channels, interfaces, arrays of comparable types, and structs whose fields are all comparable. Slices, maps, and functions cannot be keys (compile error: `invalid map key type`). Values can be any type, including slices and other maps.

Composite keys with arrays or structs are often cleaner than building a string:

```go
visited := map[[2]int]bool{}        // grid cell (row, col) — DT-100
type edge struct{ from, to int }
weight := map[edge]float64{{1, 2}: 3.5}
```

### Hash tables, briefly

A Go map hashes the key with a fast hash function seeded randomly per map (so attackers cannot predict collisions), uses part of the hash to pick a group of slots, and compares keys within the group. Average cost of lookup, insert, and delete: O(1). When the table gets too full it grows and moves entries into a larger table (incrementally, so no single insert stalls for long). Unit 6.4 builds a hash table from scratch; Unit 10.8 looks at Go's own implementation.

### Deep & Tricky

**DT-119. Go 1.24 rewrote maps as "Swiss tables".** *(Implementation detail)* Since Go 1.24 the built-in map uses a Swiss-table design: slots in groups of 8 with a control word of one-byte hash fragments, checked several at a time. Lookups and inserts got noticeably faster for large maps. Nothing about map *semantics* changed — which is the point of keeping the representation an implementation detail.

**DT-120. A map with NaN keys can hold "the same" key many times.** *(Guarantee, consequence of DT-7)* `m[math.NaN()] = 1; m[math.NaN()] = 2` gives `len(m) == 2`, and `m[math.NaN()]` always reads 0, because NaN is not equal to itself, so a lookup never matches. You can only get such entries back by ranging over the map or remove them with `clear(m)`. Avoid float keys; if you must use them, reject NaN at the edge.

**DT-121. Iteration order is randomised per iteration, not just per run.** *(Implementation behaviour)* Two `range` loops over the same unchanged map in the same run usually visit keys in different orders. Never assume "the same order as last time".

**DT-122. Adding to a map during `range` may or may not show up in the same loop.** *(Guarantee)* The spec says an entry added during iteration may be produced or skipped; an entry deleted before it is reached will not be produced. Deleting the *current* key during range is safe and common.

### Common mistakes

- Writing to a nil map (often a struct field never initialised).
- Using `m[k] == 0` to test presence when 0 is a valid value.
- Printing or testing output that depends on map iteration order.
- Using slices as keys (compile error) — use an array or a string.

### Mastery check

1. **Explain.** Why does the runtime randomise iteration order? What kind of bug does that prevent?
2. **Predict.** (a) `var m map[string]int; fmt.Println(m["a"])` (b) `m["a"] = 1` on that map (c) `m := map[string]int{"a": 0}; v, ok := m["a"]` (d) `delete(m, "zzz")` (e) `len(map[float64]int{math.NaN(): 1})` — careful: is that a constant? Can it compile?
3. **Write.** `groupByLength(words []string) map[int][]string`, then print the groups in increasing length order (so the output is the same on every run).

## Unit 2.8 — Maps II

**One-line summary:** Use `map[K]struct{}` for sets, the `maps` and `slices` packages for keys and sorting, and remember three hard rules: map elements are not addressable, maps are shared when copied, and maps are not safe for concurrent writes.

### Sets

Go has no set type; a map with an empty value is the idiom:

```go
seen := make(map[string]struct{})
seen["go"] = struct{}{}
if _, ok := seen["go"]; ok { /* member */ }
```

`struct{}` takes zero bytes (DT-125). `map[string]bool` is also common and reads more naturally (`if seen[x]`); the memory difference is small, so choose for clarity unless the set is huge.

### Map elements are not addressable

```go
type point struct{ X, Y int }
pts := map[string]point{"a": {1, 2}}
pts["a"].X = 10       // compile error: cannot assign to struct field pts["a"].X in map
```

The map may move its entries when it grows, so Go does not let you hold the address of an entry (`&pts["a"]` is also an error). Two ways to update:

```go
p := pts["a"] // copy out
p.X = 10
pts["a"] = p  // write back

ptrs := map[string]*point{"a": {1, 2}} // or store pointers
ptrs["a"].X = 10                         // fine: modifies the pointed-to struct
```

`m[k]++`, `m[k] += 5`, and `m[k] = append(m[k], v)` are fine: they read the value, compute, and store it back as a whole.

### Maps are shared when copied

A map value is a pointer to the runtime's table. Assigning or passing a map copies that pointer:

```go
a := map[string]int{"x": 1}
b := a
b["x"] = 99
fmt.Println(a["x"]) // 99
```

A function that receives a map can modify the caller's map. To get an independent copy: `c := maps.Clone(a)` (a *shallow* copy: values that are slices or pointers are still shared).

### The `maps` package and sorted output

| Task | Code |
| --- | --- |
| Keys / values (iterators, Go 1.23+) | `maps.Keys(m)`, `maps.Values(m)` |
| Sorted keys | `slices.Sorted(maps.Keys(m))` |
| Copy | `maps.Clone(m)`, `maps.Copy(dst, src)` |
| Compare | `maps.Equal(a, b)` |
| Delete matching | `maps.DeleteFunc(m, func(k K, v V) bool {...})` |
| Remove everything | `clear(m)` |

Deterministic output, the idiom you will write most often:

```go
for _, name := range slices.Sorted(maps.Keys(ages)) {
	fmt.Printf("%-6s %d\n", name, ages[name])
}
```

`maps.Keys` returns an *iterator* (Unit 3.16), not a slice; `slices.Sorted` collects it into a sorted slice.

### Not safe for concurrent writes

If one goroutine writes to a map while another reads or writes it, the runtime may detect it and **kill the program**:

```
fatal error: concurrent map writes
```

This is a *fatal error*, not a panic: `recover` cannot catch it (DT-39 explains the difference). Protect shared maps with a `sync.Mutex` or `sync.RWMutex`, or use `sync.Map` for a few special cases (Chapter 7). Concurrent *reads* with no writer are safe.

### Memory: maps do not shrink

Deleting entries frees the *values'* references but the table itself keeps its size: a map that once held 10 million entries keeps the memory for 10 million slots even after you delete all but ten. If a long-lived map shrinks a lot, copy the survivors into a new map and drop the old one.

### Deep & Tricky

**DT-123. `clear(m)` is not the same as `m = make(...)`.** *(Guarantee)* `clear(m)` empties the map that *every holder* of `m` sees (they share it). `m = make(map[K]V)` gives only *this variable* a new empty map; other holders still see the old contents. Choose deliberately.

**DT-124. `fatal error: concurrent map writes` is best-effort detection.** *(Implementation behaviour)* The runtime checks a flag on each map operation and catches many races, but not all. A program can corrupt a map silently before it is detected. The race detector (`go test -race`, Chapter 7) is the reliable tool.

**DT-125. Zero-size types share an address.** *(Implementation detail; the spec allows it)* `struct{}{}` and `[0]int{}` occupy no memory, and pointers to different zero-size variables may compare equal. Never use the address of a zero-size value as an identity.

### Pattern

**P-21. Sort keys for any output a human or a test reads.** *(Go practice)* Map order is random by design; reports, logs compared in tests, and golden files (Unit 4.2) must not depend on it. `slices.Sorted(maps.Keys(m))` costs O(n log n), which is negligible for output-sized maps.

### Common mistakes

- Trying `m[k].field = v` on a map of structs.
- Assuming a function cannot modify a map it received (it can).
- Using a plain map from several goroutines.
- Thinking `maps.Clone` is a deep copy.

### Mastery check

1. **Explain.** Why are map elements not addressable? Give two ways to update a struct stored in a map.
2. **Predict.** `func add(m map[string]int) { m["x"] = 1; m = nil }` — after `m := map[string]int{}; add(m)`, what is `len(m)`? Why did `m = nil` inside `add` not matter?
3. **Write.** Set operations on `map[string]struct{}`: `union`, `intersection`, `difference`, each returning a new set, and a `sortedMembers` helper. Test with small examples.

## Topic 2D — Structs and pointers

## Unit 2.9 — Structs

**One-line summary:** A struct groups named fields of different types into one value. Structs are values: assigning one copies all its fields. A struct can be compared with `==` when all its fields are comparable.

**Mental model — a form with labelled boxes.** A struct type is a printed form: "Name: ___, Age: ___, City: ___". A struct value is one filled-in copy of that form. Photocopying the form (assignment) gives an independent copy, except where a box says "see attached file" (a pointer, slice, or map field) — both copies point to the same attachment.

### Declaring and creating

```go
type Employee struct {
	Name   string
	Age    int
	Skills []string
	active bool // lower-case: unexported (visible only inside this package, Unit 3.12)
}

var e1 Employee                        // zero value: {"" 0 nil false}
e2 := Employee{Name: "Asha", Age: 31}  // keyed literal: missing fields get zero values
e3 := Employee{"Ravi", 28, nil, true}  // positional: ALL fields, in order — avoid
e2.Age++                               // field access with .
```

Prefer keyed literals: they keep working when fields are added or reordered, and they say what each value means. `go vet` warns about unkeyed literals of struct types from *other* packages. Since Go 1.27, keys in a struct literal may also name **promoted** fields of embedded structs (Unit 3.7).

### Zero values compose

A struct's zero value is every field at its own zero value. A well-designed struct is useful at zero (DT-48): `var b bytes.Buffer` or `var mu sync.Mutex` work immediately. Note what that means for fields of map type: their zero value is nil, so writing to them panics — a struct with a map field usually needs a constructor (Unit 3.8).

### Structs are values

```go
a := Employee{Name: "Asha", Skills: []string{"Go"}}
b := a                       // copies every field
b.Name = "Meera"             // a.Name is still "Asha"
b.Skills[0] = "Rust"         // a.Skills[0] is now "Rust" too: the slice header was copied, the array is shared
```

The copy is **shallow**: fields that are slices, maps, or pointers copy only their headers or addresses. Passing a struct to a function copies it the same way.

### Comparison

Two struct values are equal with `==` if all corresponding fields are equal. That requires every field type to be comparable; a struct with a slice, map, or function field cannot be compared (compile error) and cannot be a map key. Comparable structs make excellent map keys (Unit 2.7).

### Anonymous structs

A struct type can be written inline without a name, which is handy for one-off groupings, especially table-driven tests (Unit 4.1):

```go
tests := []struct {
	in   string
	want int
}{
	{"a", 1},
	{"bb", 2},
}
point := struct{ X, Y int }{1, 2}
```

### Struct tags (preview)

A field may carry a string **tag**, metadata that packages read through reflection:

```go
type User struct {
	ID    int    `json:"id"`
	Email string `json:"email,omitempty"`
	Pass  string `json:"-"` // never encoded
}
```

The compiler ignores tags; `encoding/json` (Chapter 5), database libraries (Chapter 9), and validators read them. Format: space-separated `key:"value"` pairs; `go vet` checks the syntax.

### The empty struct

`struct{}` has no fields and takes zero bytes. It is used for set values (Unit 2.8) and for channel signals where only the event matters (Chapter 7).

### Deep & Tricky

**DT-126. Struct literals of pointer type: `&T{...}` is fine, and Go allows `{...}` shorthand inside composite literals.** *(Guarantee)* `ps := []*Point{{1, 2}, {3, 4}}` means `[]*Point{&Point{1, 2}, &Point{3, 4}}`. The elided `&T` in nested literals is legal and idiomatic.

**DT-127. Field order and names are part of the type.** *(Guarantee)* `struct{ X, Y int }` and `struct{ Y, X int }` are different types, and so are structs with the same fields but different tags... except that *conversion* between struct types ignores tags (since Go 1.8). Two named struct types with identical underlying fields can be converted to each other with `T2(v)` (Unit 3.1).

**DT-128. Comparing structs with `==` compares padding-free field values, not memory.** *(Guarantee)* Equality is defined field by field; padding bytes (Unit 2.10) never affect it. A float field holding NaN makes the struct unequal to itself (DT-7).

### Common mistakes

- Positional literals that silently break when a field is added.
- Expecting a struct copy to deep-copy its slices and maps.
- A struct with a nil map field written to without initialisation.
- Exporting every field by habit; start unexported and export what callers need (Unit 3.12).

### Mastery check

1. **Explain.** What does "shallow copy" mean for a struct containing a slice? Draw it.
2. **Predict.** (a) `type P struct{ X, Y int }; P{1, 2} == P{1, 2}` (b) a struct with a `[]int` field compared with `==` (c) `type T struct{ M map[string]int }; var t T; t.M["a"] = 1`
3. **Write.** An `Order` struct (ID, customer, lines of {product, quantity, price in paise}), a function `total(o Order) int64`, and a table-driven check using an anonymous struct slice.

## Unit 2.10 — Struct memory layout

**One-line summary:** Each type has an *alignment*: its address must be a multiple of some power of two. To satisfy alignment the compiler inserts invisible **padding** between fields, so field order can change a struct's size. Go does not reorder fields for you.

**Mental model — packing a tiffin bag with fixed slots.** Some containers only fit in slots that start at a multiple of 8 cm; small ones fit anywhere. Put a tiny container first, then a big one, and the big one must skip to the next 8 cm mark, leaving a gap. Put the big ones first and the small ones together at the end, and the gaps disappear.

### Size and alignment of basic types (64-bit platforms)

| Type | Size | Alignment |
| --- | --- | --- |
| `bool`, `int8`, `uint8` | 1 | 1 |
| `int16`, `uint16` | 2 | 2 |
| `int32`, `uint32`, `float32`, `rune` | 4 | 4 |
| `int64`, `uint64`, `float64`, `int`, `uint`, pointers, `uintptr` | 8 | 8 |
| `string` | 16 (ptr + len) | 8 |
| slice | 24 (ptr + len + cap) | 8 |
| map, channel, function | 8 (one pointer) | 8 |
| interface | 16 (two words, Unit 3.5) | 8 |
| `[N]T` | N × size of T | alignment of T |
| struct | sum of fields + padding | largest field alignment |

Rules: each field starts at an offset that is a multiple of its alignment; the whole struct's size is rounded up to a multiple of its own alignment (so that arrays of the struct keep every element aligned).

### Padding in action

```go
type Bad struct {
	a bool  // offset 0, size 1
	        // 7 bytes padding so b starts at 8
	b int64 // offset 8, size 8
	c bool  // offset 16, size 1
	        // 7 bytes padding to round the size to a multiple of 8
}           // unsafe.Sizeof(Bad{}) == 24

type Good struct {
	b int64 // offset 0
	a bool  // offset 8
	c bool  // offset 9
	        // 6 bytes padding
}           // unsafe.Sizeof(Good{}) == 16
```

Same data, a third less memory. For one value it does not matter; for a slice of 10 million it is 80 MB, and more values per cache line (Unit 0.5) also means faster scans.

### Measuring

```go
import "unsafe"

unsafe.Sizeof(Bad{})     // 24
unsafe.Alignof(Bad{}.b)  // 8
unsafe.Offsetof(Bad{}.c) // 16
```

`unsafe.Sizeof` is computed at compile time and is safe to call; the danger in package `unsafe` lies elsewhere (Unit 10.10). The `fieldalignment` analyzer (in `golang.org/x/tools`) reports structs that could be smaller and suggests an order.

### When to care

- Large slices or arrays of a struct; caches holding millions of entries; data structures in the routing chapters (Unit 13.8).
- **Not** for ordinary structs that exist a few at a time: there, order fields for *readability* (related fields together).

### Deep & Tricky

**DT-129. A zero-size field at the end of a struct adds padding.** *(Implementation detail)* `struct{ x int32; y struct{} }` is 8 bytes, not 4: if a zero-size final field had the struct's end address, `&s.y` would point past the struct, possibly into the next object, which would confuse the garbage collector. The compiler pads it. Put zero-size fields first if it matters.

**DT-130. 64-bit atomic operations need 8-byte alignment, which 32-bit platforms do not give automatically.** *(Platform rule)* On 32-bit ARM and x86, an `int64` field may be only 4-byte aligned, and `sync/atomic` 64-bit functions on it crash. The old rule was "put 64-bit atomic fields first". The typed `atomic.Int64` (Unit 7.6) guarantees alignment and is the modern answer.

**DT-131. Go does not reorder struct fields.** *(Current compiler behaviour; the spec does not promise layout)* The gc compiler lays fields out in declaration order. Code that talks to C, to hardware, or to binary formats relies on this, so it is unlikely to change, but the language spec itself does not guarantee a memory layout.

### Mastery check

1. **Explain.** Why must a struct's size be a multiple of its alignment?
2. **Predict.** `unsafe.Sizeof` of (a) `struct{ a int8; b int32; c int8 }` (b) `struct{ b int32; a, c int8 }` (c) `struct{ s string; b bool }` (d) `struct{}`
3. **Write.** Define a struct with at least six fields of mixed sizes, measure it, reorder for minimum size, and verify with `unsafe.Offsetof` for every field.

## Unit 2.11 — Pointers

**One-line summary:** A pointer holds the address of a variable. `&x` takes the address; `*p` reads or writes the variable it points to. Pointers let functions modify the caller's data and let many parts of a program share one value. Go pointers are safe: no arithmetic, garbage-collected targets, and a nil dereference panics instead of corrupting memory.

**Mental model — a house address on a slip of paper.** A variable is a house. A pointer is a slip with the house's address written on it. Copying the slip gives two slips with the same address: whoever follows either slip reaches the same house. A nil pointer is a blank slip: following it is an error.

### `&`, `*`, and pointer types

```go
x := 10
p := &x          // p has type *int: "pointer to int"
fmt.Println(*p)  // 10: dereference — read through the pointer
*p = 20          // write through the pointer
fmt.Println(x)   // 20
```

- `*int` (in a type) means "pointer to int". `*p` (in an expression) means "the variable p points to". Same symbol, two roles.
- The zero value of any pointer type is `nil`.

### Pointers let functions modify the caller's variables

Go copies arguments (DT-75); copying a pointer gives the function the caller's address:

```go
func double(n *int) { *n *= 2 }

v := 5
double(&v)
fmt.Println(v) // 10
```

This is also how `fmt.Scan(&n)` (Unit 1.12) stores into your variable.

### Pointers to structs

```go
type Account struct{ Balance int64 }

func deposit(a *Account, amt int64) { a.Balance += amt } // a.Balance means (*a).Balance

acc := &Account{Balance: 100}  // & on a composite literal: allocate and take the address
deposit(acc, 50)
fmt.Println(acc.Balance)       // 150
```

Go automatically dereferences pointers to structs for field access, so you write `a.Balance`, never `(*a).Balance`. The same applies to pointers to arrays: `pa[2]` works for `pa *[5]int`.

### `new`

`new(T)` allocates a zero `T` and returns its address: `p := new(int)` gives a `*int` pointing to 0. It is rarely needed (`&T{}` is more common for structs). Since Go 1.26, `new` also accepts an expression, giving the new variable an initial value: `p := new(42)` or `age := new(yearsSince(born))`. This is especially handy for optional fields represented as pointers (`Name: new("Asha")` in a struct literal where `Name *string`).

### nil pointers

```go
var p *Account
fmt.Println(p == nil) // true
fmt.Println(p.Balance) // panic: runtime error: invalid memory address or nil pointer dereference
```

The panic comes from the same mechanism as calling a nil function (DT-84): address 0 is never mapped, the CPU faults, the runtime turns it into a panic. Check for nil where a pointer may legitimately be absent, and design APIs so that it usually cannot be.

### What Go pointers cannot do

- **No pointer arithmetic.** `p + 1` is a compile error. You cannot walk memory; you use slices instead. (Package `unsafe` can, at your own risk, Unit 10.10.)
- **No dangling pointers.** A pointer keeps its target alive; the GC never frees memory something still points to.
- **No pointers to map entries or to string bytes** (they could move or must stay immutable).

### Pointers and loops (Go 1.22+)

Since Go 1.22, each iteration has its own loop variable (DT-72), so this collects three distinct addresses:

```go
var ptrs []*int
for i := range 3 {
	ptrs = append(ptrs, &i)
}
fmt.Println(*ptrs[0], *ptrs[1], *ptrs[2]) // 0 1 2   (before 1.22: 3 3 3)
```

But `for _, v := range items { ptrs = append(ptrs, &v) }` gives pointers to *copies*, not to the elements of `items`. To point into the slice, use the index: `&items[i]`.

### Deep & Tricky

**DT-132. A pointer into a slice's backing array goes stale after a growing append.** *(Guarantee + classic bug)* `p := &s[0]; s = append(s, x)` — if the append reallocated, `p` still points into the *old* array. Writes through `p` are no longer visible in `s`. No crash, just silently diverging data. Take element pointers after you finish growing, or store indexes instead.

**DT-133. Pointers are comparable; equal pointers point to the same variable.** *(Guarantee, with the zero-size exception of DT-125)* `p == q` is true if they point to the same variable or are both nil. Pointers can be map keys, which is useful for identity-based sets (for example "nodes already visited").

**DT-134. Taking the address of a local is always safe in Go.** *(Guarantee)* `func newCounter() *int { n := 0; return &n }` is correct: escape analysis moves `n` to the heap (DT-34). The same code in C returns a pointer into a dead stack frame.

### Common mistakes

- Dereferencing a pointer that may be nil.
- Taking `&v` of a range copy and expecting it to point into the collection.
- Holding element pointers across `append`.
- Using a pointer just to "avoid copying" a small struct (Unit 2.12 explains why that is often slower).

### Mastery check

1. **Explain.** What exactly is copied when you pass a `*Account` to a function, and why does the function's change become visible to the caller?
2. **Predict.** (a) `a := 1; p := &a; q := p; *q = 5; fmt.Println(a)` (b) `var p *int; fmt.Println(p == nil, *p)` (c) `s := []int{1}; p := &s[0]; s = append(s, 2); *p = 9; fmt.Println(s)`
3. **Write.** `swap(a, b *int)`; a function `maxPtr(nums []int) *int` that returns a pointer to the largest element (nil for an empty slice) and lets the caller modify it in place.

## Unit 2.12 — Value vs pointer semantics

**One-line summary:** Choosing between passing `T` and `*T` is choosing between *copying* and *sharing*. Decide by meaning first (should the callee change it? does identity matter?), and by cost second (size, allocations, cache locality). Returning a pointer to a local is safe; whether it costs a heap allocation is decided by escape analysis.

### Two kinds of types

Most types naturally have one kind of semantics:

| Value semantics: copies are independent and fine | Pointer semantics: there is one "real" thing, shared |
| --- | --- |
| `time.Time`, a `Point`, a `Money` amount, a small config | a database connection pool, a bank account being updated, a `bytes.Buffer` being written, anything containing a mutex |
| Pass `T`, return `T` | Pass `*T`, return `*T` |

Rule of thumb from experienced Go teams: **decide once per type, then be consistent.** If any method needs to modify the value or the type contains a `sync.Mutex`, use pointers everywhere for that type (Unit 3.3 makes this precise with method sets).

### Questions to decide

1. **Must the callee modify the caller's value?** Yes → pointer (or return the new value).
2. **Does identity matter** — is there exactly one of this thing (a connection, a cache)? Yes → pointer.
3. **Must copies never happen** — contains a `sync.Mutex`, `sync.WaitGroup`, or `strings.Builder`? Yes → pointer (`go vet`'s copylocks check catches copies).
4. **Is it big?** A struct of many hundreds of bytes copied in a hot loop costs time. Pointer may help — but measure.
5. **Is "absent" a meaningful state?** `*T` can be nil; `T` cannot. Sometimes this is useful (optional fields), sometimes it is a source of nil panics.

### Why pointers are not automatically faster

Passing a 24-byte struct by value copies 24 bytes, usually in registers (DT-38): extremely cheap. Passing a pointer is 8 bytes, but:

- if the pointed-to value **escapes** to the heap, it costs an allocation plus GC work (Unit 0.6);
- every access goes through an extra indirection, possibly a cache miss;
- the compiler is more conservative about optimising code with pointers (it must consider aliasing).

So `[]Point` (values side by side in memory) is usually much faster to scan than `[]*Point` (pointers to objects scattered across the heap).

### Seeing escape analysis

```go
package main

import "fmt"

type Point struct{ X, Y int }

//go:noinline
func byValue() Point { p := Point{1, 2}; return p }

//go:noinline
func byPointer() *Point { p := Point{1, 2}; return &p }

func main() {
	a := byValue()
	b := byPointer()
	fmt.Println(a, *b)
}
```

```
$ go build -gcflags=-m .
./main.go:14:27: moved to heap: p
./main.go:19:13: ... argument does not escape
./main.go:19:14: a escapes to heap
./main.go:19:17: *b escapes to heap
```

(Some lines about inlining are omitted.) The `//go:noinline` directives stop the compiler from inlining the two functions into `main`, which would let it prove that `p` does not really escape. Three things to read here:

- `moved to heap: p` on line 14: `byPointer` returns `&p`, so `p` must outlive the call — a heap allocation on every call. `byValue` has no such line: its `p` is copied out (Unit 0.6).
- `a escapes to heap` and `*b escapes to heap`: passing values to `fmt.Println` converts them to interfaces (Unit 3.5), which, for values that are not tiny, means a copy on the heap. Printing is not free.
- The messages depend on the Go version and on inlining decisions. Treat `-gcflags=-m` as a microscope, not as a specification.

### Constructors return pointers or values?

Look at the standard library: `bytes.NewBuffer` returns `*Buffer` (shared, mutable), `time.Now` returns `Time` (a value), `errors.New` returns `error` (an interface holding a pointer). Follow the semantics of the type, not a blanket rule.

### Deep & Tricky

**DT-135. "Pass a pointer to avoid copying" can make code slower.** *(Performance fact; measure)* The copy saved is often a few words in registers; the cost added can be a heap allocation per call and GC pressure. Profiles of real Go services frequently show allocations from needless pointers as a top cost. Default to values for small types (rule of thumb: a few words), and change only with benchmark evidence (Chapter 10).

**DT-136. `go vet` reports copied locks.** *(Tool behaviour)* Passing or assigning a struct containing a `sync.Mutex` by value creates a second, independent lock — the protection silently disappears. `go vet`'s `copylocks` analyzer flags `passes lock by value` and `assignment copies lock value`. Types with locks must use pointer semantics.

### Pattern

**P-22. Pick value or pointer semantics per type, and stay consistent.** *(Go design practice)*

- *Problem it solves:* mixing `T` and `*T` for the same type causes lost updates (a method modified a copy) and confusing APIs.
- *How:* small, immutable-feeling data (coordinates, money, timestamps, IDs) → values. Things with identity, internal state, or locks → pointers. All methods and functions for that type follow the choice.
- *When not to:* the occasional function that legitimately needs a private copy of a pointer-semantics type should make the copy explicit (a `Clone` method).
- *Trade-off:* values give safety (no unexpected sharing) and locality; pointers give shared mutation and avoid copying big objects, at the cost of possible nil, aliasing, and heap allocations.

### Mastery check

1. **Explain.** Give two reasons why `[]Point` is usually faster to iterate than `[]*Point`.
2. **Explain.** Why is it safe in Go to return `&local`, and what does it cost?
3. **Write.** Two versions of `func (move) ...` for a `Point` — one taking and returning `Point`, one taking `*Point` — and a benchmark plan (written now, run in Chapter 4) comparing them in a loop of 10 million calls. Predict which wins and why.

## Chapter 2 Project — `wordfreq`, a Unicode-correct word counter

**Goal:** read text from files or standard input, count words correctly in any language, and print the most frequent words in a stable order. This project exercises slices, strings and runes, maps, structs, sorting, and careful input handling.

**Specification**

```
wordfreq [N] [file ...]
```

- N (optional, default 10) is how many words to print; it must be positive.
- With no files, read standard input; otherwise read each file in turn.
- A **word** is a run of letters, digits, and combining marks, optionally joined by an apostrophe (`'` or `’`) or hyphen *between* two word characters: `don't`, `well-known`. Leading or trailing apostrophes and hyphens are not part of words.
- Counting is case-insensitive (output in lower case).
- Output: a header line `T words, D distinct`, then the top N words with counts, highest count first; ties in alphabetical (byte) order, so output is identical on every run (P-21). Counts aligned in a column.
- Errors (unreadable file, bad N, read error, extremely long line) go to stderr with exit code 1, and keep the original error text (it already names the file).

**Requirements checklist**

1. `run(args []string, stdin io.Reader, stdout io.Writer) error` holds all logic, so tests can call it with fake input (P-14).
2. Splitting is done by a separate, tested function `splitWords(line string) []string`.
3. Handles Hindi (`नमस्ते दुनिया` is two words), accented Latin, and digits.
4. The `bufio.Scanner` buffer is raised so lines up to 16 MiB work (DT-92), and `sc.Err()` is checked.
5. Sorting uses `slices.SortFunc` with a tie-breaker; the map is never ranged for output directly.
6. Includes a table-driven test of `splitWords` with at least six cases (empty input, punctuation, apostrophes, hyphens, Hindi, mixed case).

**Hints**

- `unicode.IsLetter` returns false for Devanagari vowel signs such as `े` and the virama `्`: they are *marks*. Without `unicode.IsMark` your Hindi words fall apart into pieces. Find this out by testing first, then read about Unicode categories.
- To check "the next character is a word character", you need to look one rune ahead; converting the line to `[]rune` makes that simple.
- The `io.Reader` and `io.Writer` types are explained fully in Chapter 5; for now: `os.Stdin`, files, and `strings.NewReader` are readers; `os.Stdout` and `*strings.Builder` are writers.

**Reference solution**

```go
// Command wordfreq counts words in its input and prints the most frequent.
//
//	wordfreq [N] [file ...]
//
// With no files it reads standard input. N (default 10) is how many
// words to print. Words are runs of letters, digits, and combining marks,
// optionally joined by an apostrophe or hyphen ("don't", "well-known").
// Counting is case-insensitive.
package main

import (
	"bufio"
	"cmp"
	"errors"
	"fmt"
	"io"
	"os"
	"slices"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

func main() {
	if err := run(os.Args[1:], os.Stdin, os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "wordfreq:", err)
		os.Exit(1)
	}
}

type entry struct {
	word  string
	count int
}

func run(args []string, stdin io.Reader, stdout io.Writer) error {
	top := 10
	if len(args) > 0 {
		if n, err := strconv.Atoi(args[0]); err == nil {
			if n <= 0 {
				return fmt.Errorf("N must be positive, got %d", n)
			}
			top = n
			args = args[1:]
		}
	}

	counts := make(map[string]int)
	total := 0
	if len(args) == 0 {
		n, err := countWords(stdin, counts)
		if err != nil {
			return fmt.Errorf("stdin: %w", err)
		}
		total += n
	}
	for _, name := range args {
		n, err := countFile(name, counts)
		if err != nil {
			return err
		}
		total += n
	}

	entries := make([]entry, 0, len(counts))
	for w, c := range counts {
		entries = append(entries, entry{w, c})
	}
	// Highest count first; ties in alphabetical order, so output is stable.
	slices.SortFunc(entries, func(a, b entry) int {
		if c := cmp.Compare(b.count, a.count); c != 0 {
			return c
		}
		return strings.Compare(a.word, b.word)
	})
	if len(entries) > top {
		entries = entries[:top]
	}

	width := 0
	for _, e := range entries {
		width = max(width, utf8.RuneCountInString(e.word))
	}
	fmt.Fprintf(stdout, "%d words, %d distinct\n", total, len(counts))
	for _, e := range entries {
		pad := strings.Repeat(" ", width-utf8.RuneCountInString(e.word))
		fmt.Fprintf(stdout, "%s%s  %d\n", e.word, pad, e.count)
	}
	return nil
}

func countFile(name string, counts map[string]int) (int, error) {
	f, err := os.Open(name)
	if err != nil {
		return 0, err // the error already contains the file name
	}
	defer f.Close()
	n, err := countWords(f, counts)
	if err != nil {
		return n, fmt.Errorf("%s: %w", name, err)
	}
	return n, nil
}

// countWords adds every word read from r to counts and returns how many
// words it saw.
func countWords(r io.Reader, counts map[string]int) (int, error) {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 0, 64*1024), 16*1024*1024)
	total := 0
	for sc.Scan() {
		for _, w := range splitWords(sc.Text()) {
			counts[w]++
			total++
		}
	}
	if err := sc.Err(); err != nil {
		if errors.Is(err, bufio.ErrTooLong) {
			return total, fmt.Errorf("a line is longer than 16 MiB: %w", err)
		}
		return total, err
	}
	return total, nil
}

func isWordRune(r rune) bool {
	// unicode.IsMark matters: Devanagari vowel signs (like the "े" in "नमस्ते")
	// are marks, not letters. Without it, Hindi words fall apart.
	return unicode.IsLetter(r) || unicode.IsDigit(r) || unicode.IsMark(r)
}

func isJoiner(r rune) bool {
	return r == '\'' || r == '’' || r == '-'
}

// splitWords returns the lower-cased words in line.
func splitWords(line string) []string {
	var words []string
	runes := []rune(line)
	var b strings.Builder
	flush := func() {
		if b.Len() > 0 {
			words = append(words, b.String())
			b.Reset()
		}
	}
	for i, r := range runes {
		switch {
		case isWordRune(r):
			b.WriteRune(unicode.ToLower(r))
		case isJoiner(r) && b.Len() > 0 && i+1 < len(runes) && isWordRune(runes[i+1]):
			// keep an apostrophe or hyphen only between two word characters
			if r == '’' {
				r = '\''
			}
			b.WriteRune(r)
		default:
			flush()
		}
	}
	flush()
	return words
}
```

**Tests (`main_test.go`)**

```go
package main

import (
	"slices"
	"strings"
	"testing"
)

func TestSplitWords(t *testing.T) {
	tests := []struct {
		in   string
		want []string
	}{
		{"Hello, hello WORLD!", []string{"hello", "hello", "world"}},
		{"don't stop - well-known", []string{"don't", "stop", "well-known"}},
		{"नमस्ते दुनिया", []string{"नमस्ते", "दुनिया"}},
		{"Ünïcödé café", []string{"ünïcödé", "café"}},
		{"'quoted' -dash-", []string{"quoted", "dash"}},
		{"", nil},
	}
	for _, tt := range tests {
		if got := splitWords(tt.in); !slices.Equal(got, tt.want) {
			t.Errorf("splitWords(%q) = %q, want %q", tt.in, got, tt.want)
		}
	}
}

func TestRun(t *testing.T) {
	in := strings.NewReader("b a b c b a\n")
	var out strings.Builder
	if err := run([]string{"2"}, in, &out); err != nil {
		t.Fatal(err)
	}
	want := "6 words, 3 distinct\nb  3\na  2\n"
	if out.String() != want {
		t.Errorf("got %q, want %q", out.String(), want)
	}
}
```

A real run:

```
$ printf "The cat and the hat.\nThe CAT sat; the hat didn't.\nनमस्ते नमस्ते दुनिया\n" | ./wordfreq 4
14 words, 8 distinct
the     4
cat     2
hat     2
नमस्ते  2
```

**Review checklist**

- Is output stable across runs (no direct map iteration for output)? Run the program five times and `diff` the outputs.
- Do Hindi and accented words survive intact? Does `'quoted'` lose its outer apostrophes?
- Is the error from `os.Open` returned as-is (it already contains the path), rather than wrapped with the path a second time?
- Is `sc.Err()` checked, and does a 1 MB single-line file work?
- **Known limitation, worth discussing:** the column alignment counts runes, but the *display width* of text is not its rune count: Devanagari combining marks take no column, and Chinese characters and many emoji take two. Correct terminal alignment needs a width library (for example `golang.org/x/text/width` plus grapheme segmentation). Knowing where your solution is approximate is part of engineering.

**Extensions (optional)**

1. Add a `-stop` file of stop words to ignore (a set, Unit 2.8).
2. Print bigrams (pairs of consecutive words) as well; what key type will you use?
3. Process a 1 GB file and measure memory with `/usr/bin/time -v` (Linux) or `/usr/bin/time -l` (macOS). Where does the memory go?

## Answers to the Chapter 2 prediction questions

**2.2 Q2.** (a) `2 4` (b) `[2 3 4 5]` (c) panic: index out of range [2] with length 2 (d) panic: slice bounds out of range [:5] with capacity 4 (e) `[0 1 9 3 4 5]`.

**2.3 Q2.** `[0 0 0] [0 0 0 2] [0 0 0 2]` — both appends had room (cap 4), so both wrote into the *same* slot `a[3]`; the second write (2) overwrote the first (1), and `b` and `c` share it. **Q3.** First version: `[1 9 3]` (the append wrote into `s[1]`). With `s[:1:1]`: `[1 2 3]` (the append had to allocate).

**2.4 Q2.** Prints `1 2 3 4`. The `append` had no capacity left (cap 4), so it allocated a new array; `s[3] = 40` wrote into the new array, but `range` keeps using the original header and array. After the loop `s` is `[1 2 3 40 5]`.

**2.5 Q2.** (a) 6 (b) 3 (c) 240 (the first byte of the emoji, 0xF0) (d) `"Go\xf0"` (e) `"🙂"`.

**2.6 Q2.** (a) `["a" "b" "" "c"]` (b) 1 (c) `"hixx"` (d) `[a b]` (e) error: value out of range (f) `false` — simple case folding does not map `ß` to `ss` (DT-117).

**2.7 Q2.** (a) 0 (b) panic: assignment to entry in nil map (c) `0 true` (d) no-op (e) `math.NaN()` is a function call, not a constant, so the literal compiles; the result is 1.

**2.8 Q2.** 1. `add` received a copy of the map *pointer*; it wrote through it (visible), then set *its own copy* to nil (invisible to the caller).

**2.9 Q2.** (a) `true` (b) compile error: struct containing `[]int` cannot be compared (c) panic: assignment to entry in nil map.

**2.10 Q2.** (a) 12 (b) 8 (c) 24 (d) 0.

**2.11 Q2.** (a) 5 (b) `true`, then panic: nil pointer dereference (c) `[1 2]` — the append reallocated, so `p` points into the old array (DT-132).
