# Chapter 11 — Production Engineering

*Goal: turn working code into operable software.*

A service that works on your laptop is perhaps a third of the job. Production software must be configured without code changes, keep secrets secret, resist attackers, know who is calling and what they may do, tell its operators what it is doing (logs, metrics, traces, health), ship as a small and safe artifact, be tested and checked automatically on every change, and start, scale, and stop cleanly under an orchestrator. This chapter takes the Chapter 9 shortener through all of it.

Everything Go-related in this chapter's project was built and run end to end; the container, CI, and Kubernetes files are standard configurations that could not be executed in the environment used to write this book, and are marked as such.

**What you will be able to do after this chapter**

- Load and validate configuration, and handle secrets safely.
- Apply the most important security practices for Go services: validation, injection, XSS/CSRF, TLS, password hashing, cryptography, dependency scanning.
- Implement authentication (sessions, JWTs, OAuth2/OIDC concepts, API keys) and authorisation.
- Make a service observable with structured logs, Prometheus metrics, OpenTelemetry traces, and health checks.
- Build minimal, secure container images; write a CI pipeline; deploy to Kubernetes with correct probes, resources, and graceful shutdown.

## Topic 11A — Configuration and security

## Unit 11.1 — Configuration and secrets

**One-line summary:** Configuration comes from the environment (and optionally flags or a file), is validated completely at startup, and fails fast with every problem listed at once. Secrets never live in code, images, or logs; read them from files mounted by the platform or from a secret manager.

### The twelve-factor rule

Store configuration that varies between deployments (database URLs, feature flags, limits) in the **environment**, not in code. The same binary and image then run in development, staging, and production. Flags are fine for CLIs; long-running services usually read environment variables because every platform (Docker, Kubernetes, systemd, CI) can set them.

### Load everything, validate everything, report everything

```go
// Load reads configuration using getenv (os.Getenv in production, a map in
// tests). Every problem is reported at once, not one per restart.
func Load(getenv func(string) string) (Config, error) {
	c := Config{
		Addr:          or(getenv("ADDR"), ":8080"),
		AdminAddr:     or(getenv("ADMIN_ADDR"), "127.0.0.1:9090"),
		...
	}
	var errs []error
	...
	if v := getenv("RATE_PER_SECOND"); v != "" {
		if c.RatePerSecond, err = strconv.ParseFloat(v, 64); err != nil || c.RatePerSecond <= 0 {
			errs = append(errs, fmt.Errorf("RATE_PER_SECOND: must be a positive number, got %q", v))
		}
	}
	...
	return c, errors.Join(errs...)
}
```

(The full package is in the project.) Design points:

- `getenv` is a **parameter**, so tests pass a map (P-28) — no global environment mutation, tests can run in parallel.
- Defaults are explicit and safe (the admin listener defaults to `127.0.0.1`).
- `errors.Join` reports **all** problems in one startup. Nothing is more frustrating than fixing one variable, redeploying, and learning about the next.
- A `String()` method prints the configuration for the startup log **without secrets** — and a test checks that it does not leak them.

### Secrets

- **Never** in source code, Git history, container images, or command-line arguments (visible in `ps`).
- Read from **files** mounted by the platform: the project supports `DATABASE_URL_FILE` and `API_KEY_HASHES_FILE` as alternatives to the plain variables, the convention used by Docker secrets and Kubernetes `Secret` volumes.
- Or fetch from a secret manager (Vault, AWS Secrets Manager, GCP Secret Manager) at startup, with the service's own identity — no secret needed to get secrets.
- Never log them; redact with `slog.LogValuer` (Unit 5.8); never return them in errors (Unit 3.9).
- Store hashes instead of secrets where possible: the project stores **SHA-256 hashes** of API keys, so a leaked configuration does not leak usable keys.
- Plan for **rotation**: accept several valid keys at once so a new key can be rolled out before the old one is removed.

### Mastery check

1. **Explain.** Why read secrets from files rather than environment variables, given both are set by the platform?
2. **Write.** Add a `FEATURE_CUSTOM_CODES` boolean (default true) to the config, validated with `strconv.ParseBool`, and make the API reject custom codes when it is false. Test both settings.

## Unit 11.2 — Security

**One-line summary:** Most security failures in services are ordinary bugs with serious consequences: trusting input, building queries or HTML from strings, weak password storage, misused cryptography, outdated dependencies, and leaking internal details. Go's standard library makes the safe path easy; know where it ends.

### Input validation

Validate at the edge (P-4): types, ranges, lengths, formats, allow-lists. Bound sizes everywhere (bodies, headers, lines, uploads — DT-191). Treat every byte from outside as hostile until checked: request bodies, headers, query strings, cookies, file names, data from other services and from your own database (it may contain old or injected data).

### Injection

- **SQL:** placeholders always (Unit 9.5).
- **Shell commands:** `exec.Command` with separate arguments, never `sh -c` with user data (Unit 5.7).
- **Paths:** never join user input into file paths without `filepath.IsLocal` or, better, `os.Root` (Go 1.24), which confines all access to one directory tree (Unit 5.3).
- **Templates:** `html/template` for HTML, which escapes by context (Unit 5.9).
- **Headers and logs:** reject or escape newline characters in values you put into headers or log lines; structured logging (slog JSON) escapes them for you.

### XSS and CSRF (for services that serve browsers)

- **Cross-site scripting (XSS):** attacker-controlled text runs as script in a victim's browser. Defences: `html/template` escaping; a `Content-Security-Policy` header that forbids inline scripts; `HttpOnly` cookies so scripts cannot read session tokens.
- **Cross-site request forgery (CSRF):** a malicious page makes the victim's browser send a state-changing request to your site with the victim's cookies. Defences: `SameSite=Lax` or `Strict` cookies; CSRF tokens; checking the `Origin`/`Sec-Fetch-Site` headers. Go 1.25 added `http.CrossOriginProtection`, a middleware that rejects cross-origin non-safe requests using those headers. APIs authenticated with bearer tokens in headers (like the project's API keys) are not exposed to CSRF, because browsers do not attach such headers automatically.

### TLS

Serve HTTPS (`srv.ListenAndServeTLS(certFile, keyFile)`, or `golang.org/x/crypto/acme/autocert` for automatic Let's Encrypt certificates), or terminate TLS at a load balancer and keep internal traffic on a private network (or mutual TLS between services). Go's defaults (TLS 1.2 minimum, modern cipher suites, post-quantum hybrid key exchange since Go 1.24) are good; do not lower them. Set `Strict-Transport-Security` so browsers refuse plain HTTP afterwards.

### Passwords

Never store passwords, and never store a plain fast hash (SHA-256) of them: GPUs try billions of guesses per second. Use a slow, salted password hash: **bcrypt** (`golang.org/x/crypto/bcrypt`) or **argon2id** (`golang.org/x/crypto/argon2`).

```go
hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
err = bcrypt.CompareHashAndPassword(hash, []byte(attempt)) // nil = match
```

Why may the project use plain SHA-256 for **API keys**? Because they are 128+ bits of `crypto/rand` randomness (P-15) — not guessable, so slowing guesses down adds nothing. Human-chosen passwords are short and predictable; that is what slow hashes are for.

### Cryptography: use the high-level packages

- Randomness for secrets: `crypto/rand` (P-15).
- Comparing secrets: `crypto/subtle.ConstantTimeCompare`, so response time does not reveal how many bytes matched (the project uses it).
- Encryption: an AEAD such as AES-GCM (`crypto/cipher`) or `golang.org/x/crypto/chacha20poly1305`, with unique nonces; or `crypto/hpke` (Go 1.26) for public-key encryption.
- Signatures: Ed25519 (`crypto/ed25519`); post-quantum ML-DSA arrived in Go 1.27 (`crypto/mldsa`).
- Message authentication: HMAC-SHA-256 (`crypto/hmac`).
- Never design your own scheme, reuse nonces, use ECB mode, or "encrypt" with base64.

Go's crypto is implemented in Go, audited, constant-time where it matters, and offers a FIPS 140-3 mode (Go 1.24+) for regulated environments.

### The supply chain

- `govulncheck` in CI reports known vulnerabilities in code paths you actually call (Unit 4.7).
- `go.sum` and the checksum database make dependency tampering detectable (Unit 3.13).
- Fewer dependencies = smaller attack surface (one reason for Chapter 5's "standard library first").
- Pin versions, review upgrades, read changelogs of security-relevant dependencies; build images from pinned base images and rebuild them regularly for OS patches.

### Behind a proxy: whose IP is it?

`r.RemoteAddr` is the address of whoever connected — behind a load balancer, that is the load balancer. The client's address is then in `X-Forwarded-For`, but **a client can send that header itself**. Trust it only when your own proxy overwrites it, and then take the address that your proxy appended (the right-most untrusted entry), not the left-most one the client may have forged. The project's rate limiter uses `RemoteAddr`, and its comment says why.

### Deep & Tricky

**DT-274. Error messages are an information leak.** *(Security practice)* `pq: duplicate key value violates unique constraint "users_email_key"` tells an attacker your database, schema, and that an email is registered. Return generic messages for 5xx and carefully chosen ones for 4xx (P-34); log the details server-side with the request ID.

**DT-275. Timing can leak secrets.** *(Security fact)* Comparing a token with `==` stops at the first different byte; measuring response times over many requests can reveal the token byte by byte. Use `subtle.ConstantTimeCompare` for secrets — and note it still leaks the *length*, which is why the project compares fixed-length SHA-256 digests.

### Mastery check

1. **Explain.** Why is bcrypt right for passwords but unnecessary for 128-bit random API keys?
2. **Explain.** Why are bearer-token APIs not vulnerable to CSRF, while cookie-based sessions are?
3. **Write.** A file download handler that serves files from `./public` by name, using `os.Root` so `../` and symlink escapes are rejected; tests with `../../etc/passwd`.

## Unit 11.3 — Authentication

**One-line summary:** Authentication proves *who* is calling. Browser applications usually use **server-side sessions** in secure cookies; APIs use **tokens** — opaque API keys, or signed **JWTs**; "Log in with Google" and enterprise single sign-on use **OAuth 2.0 / OpenID Connect**. Each has trade-offs in revocation, scalability, and complexity.

### Sessions

The server creates a random session ID (`crypto/rand.Text()`), stores session data (user ID, expiry) in a database or Redis, and sends the ID in a cookie:

```go
http.SetCookie(w, &http.Cookie{
	Name: "session", Value: id, Path: "/",
	HttpOnly: true,                 // scripts cannot read it (XSS)
	Secure:   true,                 // HTTPS only
	SameSite: http.SameSiteLaxMode, // CSRF protection
	MaxAge:   int((12 * time.Hour).Seconds()),
})
```

Logout or revocation is trivial (delete the session row). Each request costs a session lookup — cache it. Rotate the session ID on login (prevents session fixation).

### API keys

Long random tokens issued to a client (another service, a customer's script), sent as `Authorization: Bearer <key>`. Store only hashes (the project), allow several per client for rotation, record a key ID and last-used time, scope them (read-only vs read-write), and support revocation.

```go
// From the project: compare against every configured hash in constant time.
key, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
sum := sha256.Sum256([]byte(key))
valid := false
for _, h := range want {
	if subtle.ConstantTimeCompare(sum[:], h) == 1 {
		valid = true
	}
}
```

### JWT

A JSON Web Token is three base64url parts — header, claims (`sub`, `exp`, `iat`, `aud`, custom data), signature — so any service with the key can verify it **without a database lookup**. Rules if you use them:

- Verify the signature with an algorithm **you** choose (reject `alg: none` and unexpected algorithms), and verify `exp`, `nbf`, `iss`, `aud`.
- Keep them short-lived (minutes), because a signed token cannot be revoked before it expires without extra machinery (a deny-list, which brings back the database lookup); pair with refresh tokens.
- Never put secrets in claims — they are only encoded, not encrypted.
- Use a maintained library (`github.com/golang-jwt/jwt/v5`, or a JOSE library) rather than writing verification yourself.

JWTs shine between services (stateless verification at scale) and are often overused for browser sessions, where a plain session cookie is simpler and revocable.

### OAuth 2.0 and OpenID Connect

OAuth 2.0 lets a user grant an application limited access to their account at another service without sharing their password; **OpenID Connect** (OIDC) adds a standard *identity* layer on top ("who is this user?") with an ID token (a JWT). The browser flow for web apps is the **authorization code flow with PKCE**: redirect the user to the identity provider, receive a one-time code at your callback, exchange it server-side for tokens, verify the ID token. `golang.org/x/oauth2` handles the protocol; `github.com/coreos/go-oidc` verifies ID tokens. For service-to-service calls, the **client credentials** flow gives a service its own token.

### Deep & Tricky

**DT-276. "Logged in" must be re-checked on every request.** *(Design rule)* Authentication state lives in the token or session, not in the connection or the client's claims. Every request is authenticated independently; HTTP/2 multiplexes many users' requests over one connection through proxies, so nothing about the connection identifies the user.

### Mastery check

1. **Explain.** Compare sessions and JWTs for (a) revocation (b) scaling across services (c) complexity.
2. **Write.** Add API key IDs to the project: keys of the form `<id>.<secret>`, stored as `id → hash`, so lookups are O(1) and logs can record which key made each request without logging the secret.

## Unit 11.4 — Authorisation

**One-line summary:** Authorisation decides *what* an authenticated caller may do. Model it explicitly — roles, permissions, and ownership checks — enforce it in one place per resource, deny by default, and test it as thoroughly as any feature.

### Models

- **Role-based (RBAC):** users have roles (`viewer`, `editor`, `admin`), roles have permissions (`links:read`, `links:create`, `links:delete`). Simple and common.
- **Ownership / attribute-based:** "a user may delete *their own* links; an admin may delete any". Decisions depend on attributes of the user and the resource.
- **Relationship-based (ReBAC):** permissions follow relationships ("members of the team that owns the folder"), as in Google's Zanzibar; tools like OpenFGA implement it.

### Enforcement

```go
type Principal struct {
	ID    string
	Roles []string
}

var permissions = map[string][]string{
	"viewer": {"links:read"},
	"editor": {"links:read", "links:create"},
	"admin":  {"links:read", "links:create", "links:delete"},
}

func (p Principal) Can(perm string) bool {
	for _, r := range p.Roles {
		if slices.Contains(permissions[r], perm) {
			return true
		}
	}
	return false // deny by default
}

// in the service layer, not only in HTTP middleware:
func (s *Service) Delete(ctx context.Context, p Principal, code string) error {
	l, err := s.store.Get(ctx, code)
	if err != nil {
		return err
	}
	if !p.Can("links:delete") && l.Owner != p.ID {
		return ErrForbidden // the HTTP layer maps it to 403 (or 404, to hide existence)
	}
	return s.store.Delete(ctx, code)
}
```

Rules: **deny by default**; check in the **service layer** where the resource is known (middleware cannot know who owns link `abc` — a missing ownership check is the "insecure direct object reference", one of the most common real vulnerabilities); return 404 instead of 403 when even the existence of a resource is secret; log authorisation failures; and write table-driven tests of the permission matrix (every role × every action).

### Mastery check

1. **Explain.** Why can authorisation for "delete *my* link" not be done entirely in HTTP middleware?
2. **Write.** Add an `owner` column to links, record the API key ID as owner, and implement `DELETE /api/links/{code}` allowed for the owner or an admin key; a table test of the matrix.

## Topic 11B — Observability

## Unit 11.5 — Logs, metrics, and traces

**One-line summary:** Observability is being able to answer new questions about a running system from the outside. **Logs** record events with context; **metrics** are numbers aggregated over time, cheap to keep and alert on; **traces** follow one request across services. Health and readiness checks tell the platform whether to send traffic and whether to restart.

### Logs

Structured JSON logs with `log/slog` (Unit 5.8): one line per request (the project's access log), one per significant event, errors once with context and request ID, never secrets. Logs are for *investigating*; do not alert on log patterns when a metric would do.

### Metrics: the RED and USE methods

For every service, measure **RED**: **R**ate (requests per second), **E**rrors (failed requests per second), **D**uration (latency distribution). For every resource (CPU, memory, pool, queue), measure **USE**: **U**tilisation, **S**aturation (queueing), **E**rrors.

Prometheus metric types:

- **Counter:** only goes up (`http_requests_total`); rates come from `rate(...)` in queries.
- **Gauge:** goes up and down (`go_goroutines`, queue length).
- **Histogram:** counts observations into buckets (`http_request_duration_seconds_bucket{le="0.1"}`); percentiles are computed at query time across all instances (`histogram_quantile(0.99, ...)`).

The project exposes these in the Prometheus **text format** with a small hand-written package, to show exactly what they are. Real output after a few requests:

```
# HELP http_requests_total HTTP requests by method, route, and status code.
# TYPE http_requests_total counter
http_requests_total{method="GET",route="GET /{code}",code="302"} 2
http_requests_total{method="GET",route="unmatched",code="429"} 4
http_requests_total{method="POST",route="POST /api/links",code="201"} 1
http_requests_total{method="POST",route="unmatched",code="401"} 1
http_request_duration_seconds_count{method="GET",route="GET /{code}"} 2
...
# TYPE go_goroutines gauge
go_goroutines 10
```

In a real service, use `github.com/prometheus/client_golang` (which also exports `runtime/metrics` and process metrics) or OpenTelemetry metrics.

**Label cardinality:** every distinct combination of label values is a separate time series. Label by **route pattern** (`GET /{code}`, bounded), never by raw path (`/abc123`, unbounded — millions of series will take down your metrics system). The project uses `r.Pattern` (Go 1.23), which the `ServeMux` sets after routing.

### Traces

A **trace** is a tree of **spans** (an operation with start, end, attributes) for one request across services; context propagation passes the trace ID in headers (`traceparent`, W3C Trace Context). With OpenTelemetry (`go.opentelemetry.io/otel`), you instrument HTTP servers and clients (`otelhttp`), database drivers, and your own code:

```go
ctx, span := tracer.Start(ctx, "links.Shorten")
defer span.End()
span.SetAttributes(attribute.String("code", code))
if err != nil {
	span.RecordError(err)
	span.SetStatus(codes.Error, "shorten failed")
}
```

Traces answer "where did these 2 seconds go across five services?" — the question CPU profiles cannot (DT-263). Put the trace ID in your logs so you can jump from a log line to its trace.

### Health checks

- **Liveness** (`/livez`): "is the process healthy enough to keep running?" If it fails, the platform **restarts** the container. It must check only the process itself — **never dependencies**: if liveness checked the database, a database outage would make the platform restart every instance in a loop, turning a partial outage into a total one.
- **Readiness** (`/readyz`): "should this instance receive traffic right now?" It may check critical dependencies (the project pings the database) and is deliberately failed during startup and shutdown.

Serve them, metrics, and pprof on a separate **admin listener** that is not exposed publicly (the project uses `ADMIN_ADDR`, defaulting to `127.0.0.1:9090`).

### Deep & Tricky

**DT-277. Requests rejected by outer middleware have no route.** *(Seen in this chapter's project)* `r.Pattern` is set by the `ServeMux` when it routes. The project's 401s (auth) and 429s (rate limit) are produced by middleware *before* the mux runs, so they appear as `route="unmatched"`. That is acceptable (and bounded), but dashboards must know it: "429s on `GET /{code}`" will show zero while clients are being throttled. Either place such middleware after routing (per route) or label rejections by a coarse path group.

**DT-278. Averages hide the users who suffer.** *(Measurement fact)* A mean latency of 50 ms is compatible with 1% of requests taking 5 seconds. Alert on high percentiles (p99, p99.9) from histograms, and on error *rates* — never on averages alone.

### Pattern

**P-37. Instrument RED for every endpoint and USE for every resource, from day one.** *(Operations practice)* Rate, errors, and duration per route (bounded labels), plus pool, queue, and runtime saturation, give you the first answer to almost every incident question. *Trade-off:* a little code and some metrics storage; without them, incidents are investigated by guessing.

### Mastery check

1. **Explain.** Why must a liveness probe not check the database?
2. **Explain.** Why is labelling metrics by raw URL path dangerous?
3. **Write.** Add a gauge for the cache's pending-hits count and a counter for flush failures to the project's metrics, and a test that reads them from the text output.

## Topic 11C — Delivery and operations

## Unit 11.6 — Containers

**One-line summary:** Build Go services as static binaries (`CGO_ENABLED=0`) in a multi-stage Docker build and copy them into a minimal, non-root runtime image (distroless or scratch). Stamp version information with `-ldflags -X`. The result is a small image with almost nothing for an attacker to use.

### The project's Dockerfile

*(Standard configuration; Docker image builds could not be run in the environment used to write this book.)*

```dockerfile
# syntax=docker/dockerfile:1

# ---- build stage: full Go toolchain ----
FROM golang:1.27 AS build
WORKDIR /src
# Download dependencies first: this layer is cached until go.mod/go.sum change.
COPY go.mod go.sum ./
RUN go mod download
COPY . .
ARG VERSION=dev
ARG COMMIT=unknown
# CGO_ENABLED=0: a static binary that needs no C libraries (DT-4).
# -trimpath: no local paths in the binary. -s -w: no symbol table/DWARF (DT-12).
RUN CGO_ENABLED=0 go build -trimpath \
    -ldflags="-s -w -X main.version=${VERSION} -X main.commit=${COMMIT}" \
    -o /out/shortener ./cmd/shortener

# ---- runtime stage: no shell, no package manager, non-root ----
FROM gcr.io/distroless/static-debian12:nonroot
COPY --from=build /out/shortener /shortener
USER nonroot:nonroot
EXPOSE 8080 9090
ENTRYPOINT ["/shortener"]
```

Why each choice:

- **Multi-stage:** the final image contains only the binary — not the compiler, source code, or module cache. Hundreds of MB → a few MB plus the base.
- **`CGO_ENABLED=0`:** a fully static binary (DT-4) that runs on `distroless/static` or even `scratch`. With cgo you need a base with the right C libraries.
- **`distroless/static:nonroot`:** CA certificates (for outgoing TLS), time-zone data, `/etc/passwd` with a non-root user — and no shell or package manager for an attacker to use. (`scratch` is emptier still; then embed `time/tzdata` and copy CA certificates yourself.)
- **Layer order:** `go.mod`/`go.sum` and `go mod download` before `COPY . .`, so code changes do not re-download dependencies.
- **`.dockerignore`:** keeps `.git`, build outputs, and local secrets out of the build context.

### Version information

`-ldflags "-X main.version=1.4.2 -X main.commit=abc1234"` sets string variables at link time. The project prints them at startup and serves them at `/version`. Real output:

```
$ curl -s localhost:19092/version
1.4.2 abc1234
```

Since Go 1.18, `runtime/debug.ReadBuildInfo()` also reports the module version and VCS revision automatically (`go version -m ./shortener` shows them for any binary) — useful even without `-X`.

### Deep & Tricky

**DT-279. A static Go binary in `scratch` has no CA certificates or time zones.** *(Container fact)* Outgoing HTTPS fails with `x509: certificate signed by unknown authority`, and `time.LoadLocation("Asia/Kolkata")` fails. Use `distroless/static` (which has both), or copy `/etc/ssl/certs/ca-certificates.crt` into the image and `import _ "time/tzdata"` to embed the time-zone database (about 450 KB).

### Mastery check

1. **Explain.** What does each of `-trimpath`, `-s`, `-w`, and `CGO_ENABLED=0` change about the binary?
2. **Write.** (If you have Docker.) Build the image, compare its size with a single-stage `golang:1.27` image, and run it with the database URL passed as a mounted secret file.

## Unit 11.7 — CI/CD pipelines

**One-line summary:** Every change runs the same automated gate: formatting, `go mod tidy` check, vet, static analysis, tests with the race detector against real dependencies, and vulnerability scanning; then an immutable, versioned artifact is built once and promoted through environments.

### The project's pipeline (GitHub Actions)

*(Standard configuration, not executed here.)*

```yaml
name: ci
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_HOST_AUTH_METHOD: trust
        ports: ["5432:5432"]
        options: >-
          --health-cmd pg_isready --health-interval 5s --health-timeout 5s --health-retries 10
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version-file: go.mod
      - name: Formatting
        run: test -z "$(gofmt -l .)"
      - name: go mod tidy is clean
        run: go mod tidy -diff
      - name: Vet
        run: go vet ./...
      - name: Staticcheck
        run: go run honnef.co/go/tools/cmd/staticcheck@latest ./...
      - name: Tests with the race detector, including PostgreSQL integration tests
        env:
          TEST_DATABASE_URL: postgres://postgres@localhost:5432/postgres
        run: go test -race -count=1 -shuffle=on ./...
      - name: Known vulnerabilities in reachable code
        run: go run golang.org/x/vuln/cmd/govulncheck@latest ./...

  image:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build image
        run: |
          docker build \
            --build-arg VERSION=${GITHUB_SHA::7} --build-arg COMMIT=${GITHUB_SHA::7} \
            -t ghcr.io/${{ github.repository }}:${GITHUB_SHA::7} .
      # then: scan the image, push it, and deploy (environment-specific)
```

Principles:

- **Fast feedback:** formatting and vet fail in seconds; slow integration tests run after.
- **Real dependencies:** the PostgreSQL service container makes the integration tests of Unit 9.8 run on every change, not just on the developer's machine.
- **`-race -shuffle=on -count=1`:** races, order dependence, and cached results are all excluded.
- **Build once, deploy many:** the image is built once from the tested commit, tagged immutably (commit SHA), and the *same* image goes to staging and production. Never rebuild for production.
- **Deploy progressively:** canary (a small share of traffic first) or blue-green, with automatic rollback on error-rate or latency regressions (the RED metrics of Unit 11.5).
- Pin third-party actions to commit SHAs in high-security settings (they run with your repository's permissions).

### Mastery check

1. **Explain.** Why should the production image be the same artifact that was tested in staging rather than a fresh build?
2. **Write.** Add a CI step that fails if test coverage of `internal/` drops below 80%.

## Unit 11.8 — Kubernetes basics

**One-line summary:** Kubernetes runs containers as **Pods** managed by a **Deployment** (desired replica count, rolling updates), exposed through a **Service**, configured with environment variables, ConfigMaps, and Secrets, and kept healthy with **probes**. A Go service must cooperate: correct probes, resource limits that match the runtime (GOMAXPROCS, GOMEMLIMIT), and graceful shutdown on SIGTERM.

### The project's manifest

*(Standard configuration, not executed here.)*

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: shortener
spec:
  replicas: 3
  selector:
    matchLabels: {app: shortener}
  strategy:
    rollingUpdate: {maxUnavailable: 0, maxSurge: 1}   # never drop below 3 ready pods
  template:
    metadata:
      labels: {app: shortener}
    spec:
      terminationGracePeriodSeconds: 30               # > drain wait (5s) + shutdown grace (15s)
      securityContext: {runAsNonRoot: true}
      containers:
        - name: shortener
          image: ghcr.io/example/shortener:1.4.2      # an immutable tag, never :latest
          ports:
            - {name: http, containerPort: 8080}
            - {name: admin, containerPort: 9090}
          env:
            - {name: ADDR, value: ":8080"}
            - {name: ADMIN_ADDR, value: ":9090"}      # reachable inside the cluster only
            - {name: REDIS_ADDR, value: "redis:6379"}
            - {name: DATABASE_URL_FILE, value: /secrets/db/url}
            - {name: API_KEY_HASHES_FILE, value: /secrets/api/hashes}
            - {name: GOMEMLIMIT, value: "230MiB"}      # ~90% of the memory limit (Unit 10.6)
          volumeMounts:
            - {name: db, mountPath: /secrets/db, readOnly: true}
            - {name: api, mountPath: /secrets/api, readOnly: true}
          resources:
            requests: {cpu: 250m, memory: 128Mi}
            limits: {cpu: "1", memory: 256Mi}          # Go 1.25+ sets GOMAXPROCS from the CPU limit
          readinessProbe:
            httpGet: {path: /readyz, port: admin}
            periodSeconds: 2
            failureThreshold: 1
          livenessProbe:
            httpGet: {path: /livez, port: admin}       # liveness must NOT check the database
            periodSeconds: 10
            failureThreshold: 3
          securityContext:
            readOnlyRootFilesystem: true
            allowPrivilegeEscalation: false
            capabilities: {drop: [ALL]}
      volumes:
        - name: db
          secret: {secretName: shortener-db}
        - name: api
          secret: {secretName: shortener-api-keys}
---
apiVersion: v1
kind: Service
metadata:
  name: shortener
spec:
  selector: {app: shortener}
  ports:
    - {name: http, port: 80, targetPort: http}
```

### Graceful shutdown, end to end

When a pod is deleted (rolling update, scale-down, node drain), Kubernetes sends SIGTERM and, at the same time, starts removing the pod from Service endpoints — but endpoint removal propagates to load balancers and other nodes over a few seconds. If the service stops accepting connections immediately, those seconds produce errors (DT-248). The project's sequence:

1. SIGTERM arrives; `ctx` is cancelled.
2. **Readiness fails immediately** (`ready.Store(false)`), so the endpoint is removed even faster.
3. **Wait** (`drainWait`, 5 s) while traffic stops arriving — requests that still arrive are served normally.
4. `public.Shutdown(ctx)` stops accepting and waits for in-flight requests, up to the grace (15 s).
5. Deferred cleanup: stop the hit flusher (which writes the remaining hits), close Redis and the database pool.
6. Exit before `terminationGracePeriodSeconds` (30 s), after which Kubernetes would SIGKILL.

The real log of that sequence from the project:

```
"msg":"shutdown: readiness failing, draining"
readyz during drain: 503
"msg":"http servers stopped; flushing hits"
```

### Resources and the Go runtime

- **CPU limit → GOMAXPROCS:** Go 1.25+ reads the container's CPU limit (Unit 10.7). With older Go, set `GOMAXPROCS` explicitly or use `automaxprocs`, or the service is throttled.
- **Memory limit → GOMEMLIMIT:** set it to ~90% of the container limit so the GC works harder before the kernel's OOM killer acts (Unit 10.6).
- **Requests** decide scheduling and guaranteed capacity; **limits** cap usage. Measure real usage under load (Unit 14.6) before choosing them.

### Other essentials

- **ConfigMaps** for non-secret configuration, **Secrets** mounted as files (Unit 11.1).
- **Horizontal Pod Autoscaler** scales replicas on CPU or custom metrics (requests per second).
- **PodDisruptionBudget** keeps a minimum number of replicas during voluntary disruptions.
- `readOnlyRootFilesystem`, non-root, dropped capabilities: defence in depth that costs a Go binary nothing.

### Deep & Tricky

**DT-280. A failing liveness probe during load turns slowness into an outage.** *(Operations)* If `/livez` shares the request path's resources (same goroutines, same locks, a database check), it times out under heavy load, Kubernetes restarts the pod, the remaining pods get more load, their probes fail too — a cascading restart loop. Keep liveness trivially cheap and on the admin listener.

### Mastery check

1. **Explain.** Walk through what happens to an in-flight request and to a new request during each step of the shutdown sequence.
2. **Explain.** Why `maxUnavailable: 0`? What does it require from readiness?
3. **Write.** A PodDisruptionBudget and a HorizontalPodAutoscaler for the shortener, with your reasoning for each number.

## Chapter 11 Project — Productionise the URL shortener

**Goal:** take the Chapter 9 shortener to production quality: validated configuration with file-based secrets, API-key authentication for writes, per-client rate limiting, security headers, Prometheus metrics, liveness and readiness on an admin listener, pprof, version stamping, graceful drain, a minimal container image, a CI pipeline, and Kubernetes manifests.

### Requirements

1. `internal/config`: environment-based, every error reported at once (`errors.Join`), `*_FILE` secrets, a secret-free `String()`, unit tests.
2. `internal/guard`: `RequireAPIKey` (Bearer keys, SHA-256 hashes, constant-time comparison, writes only), a token-bucket `Limiter` per client IP with `Retry-After`, a `Sweep` to bound memory, `SecurityHeaders`; tests with an injected clock.
3. `internal/metrics`: request counter and latency histogram labelled by method, route pattern, and status; runtime gauges; Prometheus text format; a test.
4. `httpapi.New` accepts extra middleware applied around the router (so `r.Pattern` is visible).
5. `main`: two listeners (public, admin), `/livez`, `/readyz` (fails during startup and shutdown, pings the database), `/metrics`, `/version`, `/debug/pprof/*` on admin only; readiness-drain-shutdown sequence; version via `-ldflags -X`.
6. `Dockerfile` (multi-stage, static, distroless, non-root), `.github/workflows/ci.yml`, `deploy/kubernetes.yaml`.

### What changed in `httpapi`

```go
// New returns the complete handler, with middleware applied. Extra
// middleware in wrap is applied directly around the router, inside request
// IDs, logging, and panic recovery, so it can see r.Pattern (Go 1.23) and
// the request ID.
func New(svc *links.Service, log *slog.Logger, wrap ...func(http.Handler) http.Handler) http.Handler {
	a := &API{svc: svc, log: log}
	mux := http.NewServeMux()
	...
	var h http.Handler = mux
	for i := len(wrap) - 1; i >= 0; i-- { // wrap[0] ends up outermost
		h = wrap[i](h)
	}
	// Middleware is applied outside-in: requestID runs first.
	return requestID(logRequests(log, recoverPanics(log, h)))
}
```

Existing callers (`New(svc, log)`) keep compiling: a variadic parameter is a compatible API change.

### `internal/config/config.go`

```go
// Package config loads the service configuration from the environment,
// validates all of it at startup, and reads secrets from files.
package config

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Addr          string        // public listener
	AdminAddr     string        // metrics, pprof, health: never exposed publicly
	DatabaseURL   string        // secret
	RedisAddr     string        // optional
	APIKeyHashes  []string      // hex SHA-256 of valid API keys (secret)
	RatePerSecond float64       // per client IP
	RateBurst     int
	CacheTTL      time.Duration
	ShutdownGrace time.Duration
}

// Load reads configuration using getenv (os.Getenv in production, a map in
// tests). Every problem is reported at once, not one per restart.
func Load(getenv func(string) string) (Config, error) {
	c := Config{
		Addr:          or(getenv("ADDR"), ":8080"),
		AdminAddr:     or(getenv("ADMIN_ADDR"), "127.0.0.1:9090"),
		RedisAddr:     getenv("REDIS_ADDR"),
		RatePerSecond: 20,
		RateBurst:     40,
		CacheTTL:      10 * time.Minute,
		ShutdownGrace: 15 * time.Second,
	}
	var errs []error
	var err error
	if c.DatabaseURL, err = secret(getenv, "DATABASE_URL"); err != nil {
		errs = append(errs, err)
	} else if c.DatabaseURL == "" {
		errs = append(errs, errors.New("DATABASE_URL (or DATABASE_URL_FILE) is required"))
	}
	keys, err := secret(getenv, "API_KEY_HASHES")
	if err != nil {
		errs = append(errs, err)
	}
	for _, h := range strings.Split(keys, ",") {
		if h = strings.TrimSpace(h); h == "" {
			continue
		}
		if len(h) != 64 || strings.Trim(h, "0123456789abcdef") != "" {
			errs = append(errs, fmt.Errorf("API_KEY_HASHES: %q is not a hex SHA-256", h))
			continue
		}
		c.APIKeyHashes = append(c.APIKeyHashes, h)
	}
	if v := getenv("RATE_PER_SECOND"); v != "" {
		if c.RatePerSecond, err = strconv.ParseFloat(v, 64); err != nil || c.RatePerSecond <= 0 {
			errs = append(errs, fmt.Errorf("RATE_PER_SECOND: must be a positive number, got %q", v))
		}
	}
	if v := getenv("RATE_BURST"); v != "" {
		if c.RateBurst, err = strconv.Atoi(v); err != nil || c.RateBurst < 1 {
			errs = append(errs, fmt.Errorf("RATE_BURST: must be a positive integer, got %q", v))
		}
	}
	if v := getenv("CACHE_TTL"); v != "" {
		if c.CacheTTL, err = time.ParseDuration(v); err != nil || c.CacheTTL <= 0 {
			errs = append(errs, fmt.Errorf("CACHE_TTL: must be a positive duration, got %q", v))
		}
	}
	return c, errors.Join(errs...)
}

// secret returns NAME, or the trimmed contents of the file named by
// NAME_FILE. Files work with Docker and Kubernetes secrets and keep
// secrets out of `ps` output and crash dumps of the environment.
func secret(getenv func(string) string, name string) (string, error) {
	v, file := getenv(name), getenv(name+"_FILE")
	if v != "" && file != "" {
		return "", fmt.Errorf("set only one of %s and %s_FILE", name, name)
	}
	if file == "" {
		return v, nil
	}
	b, err := os.ReadFile(file)
	if err != nil {
		return "", fmt.Errorf("%s_FILE: %w", name, err)
	}
	return strings.TrimSpace(string(b)), nil
}

func or(v, def string) string {
	if v == "" {
		return def
	}
	return v
}

// String describes the configuration without secrets, for startup logs.
func (c Config) String() string {
	return fmt.Sprintf("addr=%s admin=%s redis=%t api_keys=%d rate=%.1f/s burst=%d cache_ttl=%s",
		c.Addr, c.AdminAddr, c.RedisAddr != "", len(c.APIKeyHashes), c.RatePerSecond, c.RateBurst, c.CacheTTL)
}
```

### `internal/guard/guard.go`

```go
// Package guard holds HTTP middleware that protects the service:
// API-key authentication, per-client rate limiting, and security headers.
package guard

import (
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"math"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// RequireAPIKey rejects state-changing API requests (POST, PUT, PATCH,
// DELETE under /api/) unless they carry "Authorization: Bearer <key>"
// whose SHA-256 is in hashes. Only hashes are stored, so a leaked config
// does not leak usable keys; comparisons take constant time.
func RequireAPIKey(hashes []string) func(http.Handler) http.Handler {
	want := make([][]byte, 0, len(hashes))
	for _, h := range hashes {
		b, err := hex.DecodeString(h)
		if err == nil && len(b) == sha256.Size {
			want = append(want, b)
		}
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Method == http.MethodGet || r.Method == http.MethodHead || !strings.HasPrefix(r.URL.Path, "/api/") {
				next.ServeHTTP(w, r)
				return
			}
			key, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
			sum := sha256.Sum256([]byte(key))
			valid := false
			for _, h := range want {
				// ConstantTimeCompare: no timing difference reveals how many bytes matched.
				if subtle.ConstantTimeCompare(sum[:], h) == 1 {
					valid = true
				}
			}
			if !ok || !valid {
				w.Header().Set("WWW-Authenticate", `Bearer realm="shortener"`)
				http.Error(w, `{"error":"missing or invalid API key"}`, http.StatusUnauthorized)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

// HashKey returns the hex SHA-256 of an API key, for the config.
func HashKey(key string) string {
	s := sha256.Sum256([]byte(key))
	return hex.EncodeToString(s[:])
}

// Limiter is a token bucket per client: each client may make burst
// requests at once and rate requests per second on average.
type Limiter struct {
	rate    float64
	burst   float64
	now     func() time.Time
	mu      sync.Mutex
	buckets map[string]*bucket
}

type bucket struct {
	tokens float64
	last   time.Time
}

func NewLimiter(rate float64, burst int) *Limiter {
	return &Limiter{rate: rate, burst: float64(burst), now: time.Now, buckets: map[string]*bucket{}}
}

// Allow reports whether the client may make a request now, and if not,
// how long until it may.
func (l *Limiter) Allow(client string) (bool, time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := l.now()
	b, ok := l.buckets[client]
	if !ok {
		b = &bucket{tokens: l.burst, last: now}
		l.buckets[client] = b
	}
	b.tokens = math.Min(l.burst, b.tokens+now.Sub(b.last).Seconds()*l.rate) // refill
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true, 0
	}
	wait := time.Duration((1 - b.tokens) / l.rate * float64(time.Second))
	return false, wait
}

// Sweep removes buckets that are full again (idle clients), bounding memory.
func (l *Limiter) Sweep() {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := l.now()
	for k, b := range l.buckets {
		if b.tokens+now.Sub(b.last).Seconds()*l.rate >= l.burst {
			delete(l.buckets, k)
		}
	}
}

// Middleware rate-limits by client IP. It uses the connection's address:
// trusting X-Forwarded-For is only safe behind a proxy you control that
// overwrites it (see Unit 11.2).
func (l *Limiter) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil {
			ip = r.RemoteAddr
		}
		if ok, wait := l.Allow(ip); !ok {
			w.Header().Set("Retry-After", strconv.Itoa(int(math.Ceil(wait.Seconds()))))
			http.Error(w, `{"error":"too many requests"}`, http.StatusTooManyRequests)
			return
		}
		next.ServeHTTP(w, r)
	})
}

// SecurityHeaders sets conservative headers for an API.
func SecurityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
		h.Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		next.ServeHTTP(w, r)
	})
}
```

The token bucket in one sentence: each client has a bucket of up to `burst` tokens that refills at `rate` per second; a request spends one token or is rejected with how long until the next token. Note the loop that compares against **every** hash without stopping early, so the number of configured keys — not which one matched — determines the time taken.

### `internal/metrics/metrics.go`

```go
// Package metrics records HTTP request metrics and writes them in the
// Prometheus text exposition format. A real service would usually use
// github.com/prometheus/client_golang; this small version shows exactly
// what a counter, a histogram, and the format are.
package metrics

import (
	"fmt"
	"io"
	"net/http"
	"runtime/metrics"
	"slices"
	"strconv"
	"sync"
	"time"
)

// Buckets are upper bounds in seconds for request durations.
var Buckets = []float64{0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5}

type key struct{ method, route, code string }

type hist struct {
	counts []uint64 // one per bucket, cumulative at write time
	sum    float64
	count  uint64
}

type HTTP struct {
	mu        sync.Mutex
	requests  map[key]uint64
	durations map[[2]string]*hist // method, route
}

func NewHTTP() *HTTP {
	return &HTTP{requests: map[key]uint64{}, durations: map[[2]string]*hist{}}
}

type recorder struct {
	http.ResponseWriter
	code int
}

func (r *recorder) WriteHeader(c int)            { r.code = c; r.ResponseWriter.WriteHeader(c) }
func (r *recorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }

// Middleware must wrap the router directly so r.Pattern is set; it uses the
// route pattern (bounded set) rather than the raw path (unbounded) as a label.
func (m *HTTP) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &recorder{ResponseWriter: w, code: http.StatusOK}
		next.ServeHTTP(rec, r)
		route := r.Pattern // e.g. "GET /{code}"; set by ServeMux (Go 1.23+)
		if route == "" {
			route = "unmatched"
		}
		m.observe(r.Method, route, rec.code, time.Since(start))
	})
}

func (m *HTTP) observe(method, route string, code int, d time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.requests[key{method, route, strconv.Itoa(code)}]++
	h := m.durations[[2]string{method, route}]
	if h == nil {
		h = &hist{counts: make([]uint64, len(Buckets))}
		m.durations[[2]string{method, route}] = h
	}
	s := d.Seconds()
	for i, b := range Buckets {
		if s <= b {
			h.counts[i]++
		}
	}
	h.sum += s
	h.count++
}

// Write writes all metrics in Prometheus text format, sorted for stable output.
func (m *HTTP) Write(w io.Writer) {
	m.mu.Lock()
	defer m.mu.Unlock()
	fmt.Fprintln(w, "# HELP http_requests_total HTTP requests by method, route, and status code.")
	fmt.Fprintln(w, "# TYPE http_requests_total counter")
	keys := make([]key, 0, len(m.requests))
	for k := range m.requests {
		keys = append(keys, k)
	}
	slices.SortFunc(keys, func(a, b key) int {
		return cmpStr(a.method+a.route+a.code, b.method+b.route+b.code)
	})
	for _, k := range keys {
		fmt.Fprintf(w, "http_requests_total{method=%q,route=%q,code=%q} %d\n", k.method, k.route, k.code, m.requests[k])
	}
	fmt.Fprintln(w, "# HELP http_request_duration_seconds HTTP request latency.")
	fmt.Fprintln(w, "# TYPE http_request_duration_seconds histogram")
	hk := make([][2]string, 0, len(m.durations))
	for k := range m.durations {
		hk = append(hk, k)
	}
	slices.SortFunc(hk, func(a, b [2]string) int { return cmpStr(a[0]+a[1], b[0]+b[1]) })
	for _, k := range hk {
		h := m.durations[k]
		for i, b := range Buckets {
			fmt.Fprintf(w, "http_request_duration_seconds_bucket{method=%q,route=%q,le=%q} %d\n",
				k[0], k[1], strconv.FormatFloat(b, 'g', -1, 64), h.counts[i])
		}
		fmt.Fprintf(w, "http_request_duration_seconds_bucket{method=%q,route=%q,le=\"+Inf\"} %d\n", k[0], k[1], h.count)
		fmt.Fprintf(w, "http_request_duration_seconds_sum{method=%q,route=%q} %g\n", k[0], k[1], h.sum)
		fmt.Fprintf(w, "http_request_duration_seconds_count{method=%q,route=%q} %d\n", k[0], k[1], h.count)
	}
	writeRuntime(w)
}

func cmpStr(a, b string) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func writeRuntime(w io.Writer) {
	s := []metrics.Sample{
		{Name: "/sched/goroutines:goroutines"},
		{Name: "/gc/heap/live:bytes"},
		{Name: "/gc/cycles/total:gc-cycles"},
	}
	metrics.Read(s)
	fmt.Fprintf(w, "# TYPE go_goroutines gauge\ngo_goroutines %d\n", s[0].Value.Uint64())
	fmt.Fprintf(w, "# TYPE go_heap_live_bytes gauge\ngo_heap_live_bytes %d\n", s[1].Value.Uint64())
	fmt.Fprintf(w, "# TYPE go_gc_cycles_total counter\ngo_gc_cycles_total %d\n", s[2].Value.Uint64())
}

// Handler serves the metrics for a Prometheus scraper.
func (m *HTTP) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		m.Write(w)
	})
}
```

A note from development: this method was first called `WriteTo(w io.Writer)`, and `go vet` reported `method WriteTo(w io.Writer) should have signature WriteTo(io.Writer) (int64, error)`. Methods named like the standard interfaces (`WriteTo`, `ReadFrom`, `String`, `Error`, `Format`) must match their signatures, or code that checks for those interfaces (Unit 3.6, `io.Copy`'s fast paths) will misbehave. Renaming to `Write` fixed it.

### `cmd/shortener/main.go`

```go
// Command shortener runs the URL shortener service.
//
// Configuration: see package config. Two listeners: the public API on
// ADDR, and an admin listener on ADMIN_ADDR (metrics, health, pprof) that
// must never be exposed to the internet.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"net/http/pprof"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"

	"example.com/shortener/internal/cache"
	"example.com/shortener/internal/config"
	"example.com/shortener/internal/guard"
	"example.com/shortener/internal/httpapi"
	"example.com/shortener/internal/links"
	"example.com/shortener/internal/metrics"
	"example.com/shortener/internal/pgstore"
)

// Set at build time: go build -ldflags "-X main.version=1.4.2 -X main.commit=$(git rev-parse --short HEAD)"
var (
	version = "dev"
	commit  = "unknown"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil)).With("version", version)
	if err := run(log); err != nil {
		log.Error("shortener stopped", "err", err)
		os.Exit(1)
	}
}

func run(log *slog.Logger) error {
	cfg, err := config.Load(os.Getenv)
	if err != nil {
		return err // every configuration problem, at once
	}
	log.Info("starting", "commit", commit, "config", cfg.String())

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	startCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	db, err := pgstore.Open(startCtx, cfg.DatabaseURL)
	cancel()
	if err != nil {
		return err
	}
	defer db.Close()

	var kv cache.KV = cache.NewMemoryKV()
	if cfg.RedisAddr != "" {
		rdb := redis.NewClient(&redis.Options{Addr: cfg.RedisAddr, DialTimeout: 2 * time.Second,
			ReadTimeout: 200 * time.Millisecond, WriteTimeout: 200 * time.Millisecond})
		defer rdb.Close()
		kv = cache.RedisKV{C: rdb}
	}
	cached := cache.New(pgstore.New(db), kv, cfg.CacheTTL, log)
	bg, stopBG := context.WithCancel(context.Background())
	flushed := make(chan struct{})
	go func() {
		defer close(flushed)
		cached.Run(bg, time.Second)
	}()
	defer func() { stopBG(); <-flushed }()

	limiter := guard.NewLimiter(cfg.RatePerSecond, cfg.RateBurst)
	go func() {
		t := time.NewTicker(time.Minute)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				limiter.Sweep()
			case <-bg.Done():
				return
			}
		}
	}()

	m := metrics.NewHTTP()
	api := httpapi.New(links.NewService(cached), log,
		m.Middleware, // outermost of the extras: counts 401s and 429s too
		guard.SecurityHeaders,
		limiter.Middleware,
		guard.RequireAPIKey(cfg.APIKeyHashes),
	)
	public := &http.Server{Addr: cfg.Addr, Handler: api,
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second,
		WriteTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}

	// Readiness: false until started, and false again as soon as shutdown
	// begins, so the load balancer stops sending traffic before we stop.
	var ready atomic.Bool
	admin := http.NewServeMux()
	admin.Handle("GET /metrics", m.Handler())
	admin.HandleFunc("GET /livez", func(w http.ResponseWriter, _ *http.Request) { w.Write([]byte("ok\n")) })
	admin.HandleFunc("GET /readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), time.Second)
		defer cancel()
		if !ready.Load() {
			http.Error(w, "shutting down or starting", http.StatusServiceUnavailable)
			return
		}
		if err := db.Ping(ctx); err != nil {
			http.Error(w, "database unavailable", http.StatusServiceUnavailable)
			return
		}
		w.Write([]byte("ok\n"))
	})
	admin.HandleFunc("GET /version", func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte(version + " " + commit + "\n"))
	})
	admin.HandleFunc("/debug/pprof/", pprof.Index)
	admin.HandleFunc("/debug/pprof/profile", pprof.Profile)
	admin.HandleFunc("/debug/pprof/trace", pprof.Trace)
	adminSrv := &http.Server{Addr: cfg.AdminAddr, Handler: admin, ReadHeaderTimeout: 5 * time.Second}

	errCh := make(chan error, 2)
	go func() { errCh <- public.ListenAndServe() }()
	go func() { errCh <- adminSrv.ListenAndServe() }()
	ready.Store(true)
	log.Info("listening", "public", cfg.Addr, "admin", cfg.AdminAddr)

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}

	// Graceful shutdown (Unit 11.8): fail readiness, wait for the load
	// balancer to notice, then stop accepting and drain in-flight requests.
	ready.Store(false)
	log.Info("shutdown: readiness failing, draining", "wait", drainWait)
	time.Sleep(drainWait)
	shutCtx, cancel := context.WithTimeout(context.Background(), cfg.ShutdownGrace)
	defer cancel()
	if err := public.Shutdown(shutCtx); err != nil {
		return err
	}
	adminSrv.Shutdown(shutCtx)
	for range 2 {
		if err := <-errCh; !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	}
	log.Info("http servers stopped; flushing hits")
	return nil
}

// drainWait should exceed the load balancer's readiness probe period.
var drainWait = 5 * time.Second
```

The pprof handlers are registered explicitly on the admin mux instead of importing `net/http/pprof` for its side effect on `http.DefaultServeMux` — so nothing can accidentally expose them on the public listener.

### A real end-to-end run

With `API_KEY_HASHES` set to the SHA-256 of `demo-key-123`, `RATE_PER_SECOND=2`, `RATE_BURST=4`:

```
$ curl -s localhost:19092/version
1.4.2 abc1234
$ curl -s localhost:19092/readyz
ok
POST without a key:      401
POST with the key:       201
5 redirects in a burst:  302 302 429 429 429
$ curl -sD - -o /dev/null localhost:18082/godev
HTTP/1.1 429 Too Many Requests
Retry-After: 1
X-Content-Type-Options: nosniff
$ kill -TERM <pid>
readyz during drain: 503
"msg":"shutdown: readiness failing, draining"
"msg":"http servers stopped; flushing hits"
```

Why only two redirects succeeded: the burst of 4 tokens is per client IP, and the two POSTs from the same IP already spent two. The metrics output from this run is shown in Unit 11.5, including the `route="unmatched"` labels of DT-277.

### Review checklist

- Start with a bad configuration: are *all* errors reported in one go? Does any log line contain a secret?
- Is pprof reachable on the public port? (It must not be.)
- Does `readyz` fail before the server stops accepting connections during shutdown?
- Are metrics labels bounded? Try 10,000 random paths and count the series.
- Does the image run as non-root with a read-only root filesystem?
- **Known limitations to discuss:** the rate limiter is per instance (with 3 replicas a client gets 3× the rate — a Redis-based limiter shares state, Unit 12.8); API keys have no IDs or scopes yet (Unit 11.3's exercise); the configuration test checks that `String()` leaks no secret, but not that every field it prints is the right one — extend it.

## Answers to the Chapter 11 prediction questions

**11.8 Q2.** With `maxUnavailable: 0`, Kubernetes starts a new pod and waits until it is **ready** before stopping an old one, so capacity never drops below the desired replica count during a rollout. It depends entirely on an honest readiness probe: if `/readyz` reported ready before the database pool and migrations were done, traffic would reach a pod that cannot serve it.
