# Chapter 7 — Concurrency

*Goal: write correct, leak-free concurrent programs.*

Concurrency is why many teams choose Go. Goroutines are cheap enough to start one per request or per task, channels make communication between them a first-class language feature, and the runtime spreads the work across all CPU cores. But concurrency is also where the hardest bugs live: races that appear once a week in production, deadlocks, goroutines that leak until the server runs out of memory. This chapter teaches both the power and the discipline.

The guiding proverb: **"Do not communicate by sharing memory; instead, share memory by communicating."** Prefer passing ownership of data through channels; when you must share, protect it with a mutex — and always know which goroutine owns what.

**What you will be able to do after this chapter**

- Explain processes, threads, goroutines, scheduling, concurrency vs parallelism, and what a data race is.
- Use channels, `select`, timeouts, `sync` primitives, and atomics correctly.
- Explain the Go memory model's happens-before rule well enough to judge whether code is race-free.
- Find races with the race detector, and avoid deadlocks and goroutine leaks.
- Propagate cancellation and deadlines with `context`.
- Build worker pools, pipelines, fan-out/fan-in, semaphores, rate limiters, and error groups — and test them.

## Topic 7A — Foundations

## Unit 7.1 — The operating-system view

**One-line summary:** A process is a running program with its own memory; a thread is a sequence of execution inside a process, sharing that memory. The OS scheduler switches threads on and off CPU cores. Concurrency is *dealing with* many things at once; parallelism is *doing* many things at once. When two threads access the same memory and at least one writes, without synchronisation, the result is a **data race**.

**Mental model — a restaurant kitchen.** The restaurant is a process: one building, one store room (memory). Cooks are threads: they work independently but share the store room. The head chef (OS scheduler) decides who works at which stove (CPU core); with four stoves, at most four cooks cook at the same instant (parallelism), but a dozen orders can be "in progress" (concurrency). If two cooks reach for the same jar of salt without coordinating, one adds salt the other did not expect — a race.

### Processes and threads

| | Process | OS thread |
| --- | --- | --- |
| Memory | own private address space (Unit 0.6) | shares its process's memory |
| Creation cost | high (milliseconds) | moderate (tens of µs, ~1–8 MB of stack reserved) |
| Switching cost | high | about a microsecond (save registers, enter kernel) |
| Communication | pipes, sockets, files (copying) | shared memory (fast, dangerous) |

### Scheduling

The OS gives each runnable thread a time slice on a core, then **preempts** it (interrupts it) and runs another. A thread also leaves the CPU when it blocks — waiting for disk, network, a lock, or a sleep. From your program's point of view, a thread can be paused **between any two instructions**, for an unpredictable time. All concurrency reasoning follows from that.

### Concurrency vs parallelism

- **Concurrency:** structuring a program as independently executing tasks (a web server handling 10,000 connections, most of them waiting for the network).
- **Parallelism:** executing several computations at the same instant on several cores (resizing 1,000 images on 8 cores).

A concurrent program runs correctly on one core; on many cores it may also run in parallel. Go lets you write concurrent code and the runtime provides parallelism up to `GOMAXPROCS` (by default the number of usable cores — and since Go 1.25, the container's CPU limit, Unit 11.8).

### What a race is

```go
counter := 0
var wg sync.WaitGroup
for range 1000 {
	wg.Add(1)
	go func() {
		defer wg.Done()
		counter++ // read, add, write — three steps, not one
	}()
}
wg.Wait()
fmt.Println("counter:", counter)
```

Three real runs of this program printed **983, 979, and 982**. `counter++` is a read, an addition, and a write. Two goroutines both read 41, both add 1, both write 42: one increment is lost. This is a **data race**: concurrent access to the same memory, at least one a write, with no synchronisation. In Go, a program with a data race has **no guaranteed behaviour** beyond "something reasonable for that word of memory" — and with multi-word values (strings, slices, interfaces) a race can even produce a torn value that crashes the program (DT-225).

### Mastery check

1. **Explain.** Use the kitchen analogy to explain the difference between concurrency and parallelism.
2. **Explain.** Why is `counter++` not safe from multiple goroutines? Describe the interleaving that loses an update.

## Unit 7.2 — Goroutines

**One-line summary:** `go f(x)` starts `f` running concurrently in a new goroutine — a function execution managed by the Go runtime, not by the OS. Goroutines start with tiny stacks and are multiplexed onto a few OS threads, so a program can run hundreds of thousands of them. The program exits when `main` returns, without waiting for other goroutines.

### Starting goroutines

```go
go sendEmail(user)                 // runs concurrently; the call returns immediately
go func(id int) { process(id) }(7) // arguments are evaluated NOW, in the caller (like defer, DT-88)
```

There is no handle, no return value, and no way to kill a goroutine from outside. A goroutine ends when its function returns. To get results back, to wait for it, or to stop it, you build that in: channels (Unit 7.3), `sync.WaitGroup` (Unit 7.5), `context` (Unit 7.9).

### `main` does not wait

```go
func main() {
	go fmt.Println("hello from a goroutine")
} // main returns: the program exits, probably before the goroutine runs
```

When `main` returns, the process exits and all goroutines vanish mid-flight — deferred calls in them do not run. Every goroutine you start needs an answer to: **who waits for it, and how does it end?**

### A first look at the scheduler

The runtime runs goroutines on OS threads using the **G-M-P model** (details in Unit 10.7):

- **G** — a goroutine: its stack, its program counter, its state.
- **M** — an OS thread ("machine").
- **P** — a processor context, `GOMAXPROCS` of them; an M must hold a P to run Go code. Each P has a queue of runnable Gs.

When a goroutine blocks on a channel, a mutex, a sleep, or network I/O, the runtime parks it and runs another G on the same thread — a switch costing tens of nanoseconds, with no kernel involvement. Network I/O uses the OS's event notification (epoll, kqueue), so 10,000 goroutines waiting on sockets need only a handful of threads. Blocking *system calls* (disk I/O, cgo) do occupy a thread; the runtime hands the P to another thread meanwhile. Since Go 1.14, long-running goroutines are **preempted asynchronously**, so a tight loop cannot starve the others.

### Goroutine stacks

A goroutine starts with a small stack (a few KB; since Go 1.19 sized from observed averages) and grows by copying (DT-35) up to 1 GB. Thousands of mostly-idle goroutines cost only megabytes. This is what makes "one goroutine per connection" a sound design in Go, where it would be wasteful with OS threads.

### Deep & Tricky

**DT-222. An unrecovered panic in any goroutine kills the whole program.** *(Guarantee)* `recover` only works in the panicking goroutine's own deferred functions (Unit 3.11). A library that starts goroutines must recover inside them (and report the error) if a panic there should not crash its host. `net/http` does this for handler goroutines.

**DT-223. Goroutines have no identity you can use.** *(Language design)* There is no public goroutine ID, no thread-local storage, no `goroutine.current()`. This is deliberate: code that depends on "which goroutine am I" breaks when work moves between goroutines. Pass what you need (a `context`, a logger, a request ID) explicitly.

### Mastery check

1. **Explain.** Why can Go run 100,000 goroutines when 100,000 OS threads would be a problem?
2. **Predict.** `for i := range 3 { go fmt.Print(i) }` followed by `time.Sleep(10 * time.Millisecond)` — what can be printed? What if the sleep is removed?
3. **Write.** Start 10,000 goroutines that each sleep 1 second, wait for all with a `WaitGroup`, and measure total time and memory (`runtime.ReadMemStats` before and after). Explain the numbers.

## Topic 7B — Channels

## Unit 7.3 — Channels

**One-line summary:** A channel is a typed, synchronised pipe between goroutines. Sending and receiving on an **unbuffered** channel happen together (a handshake); a **buffered** channel holds up to N values. Closing a channel says "no more values"; receivers see the remaining values, then zero values with `ok == false`. Nil channels block forever.

**Mental model — handing over a parcel.** An unbuffered channel is a hand-to-hand handover: the sender waits until a receiver takes the parcel, so both know the handover happened. A buffered channel is a pigeonhole rack with N slots: the sender drops the parcel and leaves, unless the rack is full. Closing the channel is putting up a sign: "no more parcels".

### Basics

```go
ch := make(chan int)      // unbuffered
buf := make(chan int, 10) // buffered, capacity 10

go func() { ch <- 42 }()  // send: blocks until someone receives
v := <-ch                 // receive: blocks until someone sends
```

| Operation | Unbuffered | Buffered (capacity N) |
| --- | --- | --- |
| send | blocks until a receiver takes it | blocks only if N values are already waiting |
| receive | blocks until a sender sends | blocks only if empty |
| `len(ch)`, `cap(ch)` | 0, 0 | values waiting, N |

The unbuffered handshake is also a **synchronisation**: everything the sender did before the send is visible to the receiver after the receive (Unit 7.7).

### Directional channel types

```go
func produce(out chan<- int) { out <- 1 } // can only send
func consume(in <-chan int)  { <-in }     // can only receive
```

A `chan int` converts implicitly to either direction. Use directions in function signatures: they document ownership and the compiler enforces them.

### Close and range

```go
func numbers(n int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out) // the SENDER closes, when done
		for i := range n {
			out <- i
		}
	}()
	return out
}

for v := range numbers(3) { // receives until the channel is closed and drained
	fmt.Println(v)            // 0 1 2
}
```

- After `close(ch)`, receivers get the buffered values, then the zero value immediately, forever: `v, ok := <-ch` gives `ok == false`.
- **Sending on a closed channel panics** (`send on closed channel`). **Closing a closed channel panics** (`close of closed channel`).
- Rule: **only the sender closes, and only when no more sends can happen.** With several senders, a separate coordinator closes after all senders finish (a `WaitGroup`, Unit 7.10).
- Closing is not required for garbage collection; close only to *signal* "done" to receivers.

### Nil channels

Sending to or receiving from a nil channel blocks **forever**. This sounds useless, but in `select` it is a tool: setting a channel variable to nil disables its case (Unit 7.4).

### Deep & Tricky

**DT-224. A buffered channel is not a queue you should inspect.** *(Practice)* `len(ch)` is outdated the moment you read it — another goroutine may send or receive right after. Never write `if len(ch) > 0 { v := <-ch }`; use `select` with `default` for non-blocking operations.

**DT-225. Races on multi-word values can crash, not just give wrong numbers.** *(Implementation consequence)* A string or slice header is written as two or three words. A reader racing with a writer can see the new pointer with the old length, then read past the end of memory. Interfaces (type + data words) can be torn so that a method is called on data of the wrong type. "It is only a counter, a small race is fine" is never true in Go.

### Mastery check

1. **Explain.** Why must only the sender close a channel? What goes wrong with several senders?
2. **Predict.** (a) `ch := make(chan int, 1); ch <- 1; ch <- 2` (in `main`, nothing else running) (b) `ch := make(chan int); close(ch); v, ok := <-ch` (c) `var ch chan int; <-ch` (d) `close(ch)` twice.
3. **Write.** A generator `primes(ctx)` returning `<-chan int` that produces primes until the context is cancelled, closing the channel when it stops.

## Unit 7.4 — select

**One-line summary:** `select` waits on several channel operations at once and runs the first one that can proceed (choosing randomly among several ready ones). With `default` it never blocks. Combined with timers and `ctx.Done()`, it expresses timeouts, cancellation, and multiplexing.

### Basics

```go
select {
case msg := <-messages:
	handle(msg)
case results <- next: // a send can be a case too
	next = compute()
case <-time.After(2 * time.Second):
	fmt.Println("timed out")
case <-ctx.Done():
	return ctx.Err()
}
```

- If several cases are ready, one is chosen **uniformly at random** (so no case starves).
- If none is ready, `select` blocks until one is.
- With a `default` case, `select` does not block: `default` runs if nothing is ready.

### Non-blocking send and receive

```go
select {
case events <- e:
default:
	dropped++ // buffer full: drop rather than block the caller (e.g. telemetry)
}
```

### Timeouts

```go
select {
case r := <-resultCh:
	return r, nil
case <-time.After(500 * time.Millisecond):
	return Result{}, errors.New("timeout")
}
```

Since Go 1.23, the timer behind an abandoned `time.After` is garbage-collected promptly, so this idiom no longer leaks timers in loops (DT-226 covers the old caveat). For a deadline that applies to a whole operation and everything it calls, use `context.WithTimeout` (Unit 7.9).

### Disabling cases with nil channels

Merging two channels until both are closed:

```go
func merge(a, b <-chan int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out)
		for a != nil || b != nil {
			select {
			case v, ok := <-a:
				if !ok {
					a = nil // closed: disable this case
					continue
				}
				out <- v
			case v, ok := <-b:
				if !ok {
					b = nil
					continue
				}
				out <- v
			}
		}
	}()
	return out
}
```

### Deep & Tricky

**DT-226. Before Go 1.23, `time.After` in a loop leaked timers until they fired.** *(Version-dependent)* A `select` with `case <-time.After(time.Minute)` inside a busy loop created a new timer each iteration that stayed alive for a minute. Older code uses `time.NewTimer` with `Stop`/`Reset` for this reason. Modules with `go 1.23`+ do not need to.

**DT-227. An empty `select {}` blocks forever.** *(Guarantee)* It is occasionally used at the end of `main` in programs whose work happens in other goroutines. If those goroutines all exit, the runtime reports `fatal error: all goroutines are asleep - deadlock!`.

### Mastery check

1. **Explain.** Why does `select` choose randomly among ready cases?
2. **Write.** `firstOf(ctx, fetchers ...func(context.Context) (string, error)) (string, error)` that runs all fetchers concurrently and returns the first success, cancelling the rest — with no goroutine leaks (check with `runtime.NumGoroutine` in a test).

## Topic 7C — Shared-memory synchronization

## Unit 7.5 — The sync package

**One-line summary:** `sync.WaitGroup` waits for a group of goroutines; `sync.Mutex` and `sync.RWMutex` protect shared data so only one goroutine (or many readers) touches it at a time; `sync.Once`, `OnceFunc`, and `OnceValue` run initialisation exactly once; `sync.Cond` is a rarely needed wait/signal primitive.

### WaitGroup

```go
var wg sync.WaitGroup
for _, u := range urls {
	wg.Add(1) // BEFORE starting the goroutine
	go func() {
		defer wg.Done()
		fetch(u) // Go 1.22+: u is per-iteration (DT-72)
	}()
}
wg.Wait()
```

Since Go 1.25 you can write `wg.Go(func() { fetch(u) })`, which does the `Add(1)` and `defer Done()` for you and removes the most common WaitGroup bug (calling `Add` inside the goroutine, after `Wait` may already have returned). Go 1.27's `go fix` includes a modernizer (`waitgroupgo`) that rewrites the old pattern.

### Mutex

```go
type Counter struct {
	mu sync.Mutex     // protects the fields below it
	m  map[string]int
}

func (c *Counter) Inc(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.m[key]++
}

func (c *Counter) Value(key string) int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.m[key]
}
```

Rules:

- Keep the critical section (the code between `Lock` and `Unlock`) **short**. Never do network or disk I/O while holding a lock.
- Every access — reads too — must hold the lock. A read without the lock while another goroutine writes is still a race.
- `defer mu.Unlock()` right after `Lock` (P-13) keeps unlock correct on every path, including panics.
- A mutex must not be copied after first use (DT-136): use pointer receivers, and never embed it publicly (DT-152).
- Go's mutexes are **not reentrant**: a goroutine that calls `Lock` twice deadlocks itself. Structure code so that exported methods lock and unexported helpers assume the lock is held (and say so in a comment).

### RWMutex

`sync.RWMutex` allows many simultaneous readers (`RLock`/`RUnlock`) or one writer (`Lock`/`Unlock`). Use it when reads vastly outnumber writes *and* critical sections are not tiny; otherwise a plain `Mutex` is often faster (RWMutex has more overhead). Measure.

### Once, OnceFunc, OnceValue

```go
var loadConfig = sync.OnceValues(func() (*Config, error) { // Go 1.21
	return readConfig("app.yaml")
})

cfg, err := loadConfig() // the first caller runs readConfig; everyone else waits and gets the same result
```

`sync.Once{}.Do(f)` is the older form. `OnceFunc`, `OnceValue`, and `OnceValues` (Go 1.21) are simpler and also re-panic consistently if `f` panicked. Use for lazy initialisation of expensive shared resources.

### Cond

`sync.Cond` lets goroutines wait until a condition on shared state becomes true. It is easy to misuse, and channels usually express the same thing more clearly. You will rarely need it; when you see it in libraries (bounded queues), recognise the pattern: `for !condition { c.Wait() }` while holding the lock.

### Deep & Tricky

**DT-228. `wg.Add` inside the goroutine is a race with `Wait`.** *(Classic bug)* If the goroutine has not run yet when `Wait` is called, the counter may be 0, and `Wait` returns immediately. Always `Add` before `go`, or use `wg.Go` (Go 1.25+).

**DT-229. A mutex protects data, not code.** *(Design principle)* Document which fields a mutex guards (put them right below it with a comment). Two methods that lock the same mutex but touch different data, or one mutex for unrelated data, are design smells: contention without protection or protection without clarity.

**DT-230. Go's `Mutex` can be unlocked by a different goroutine than the one that locked it.** *(Guarantee, unlike many languages)* It is legal but almost always a sign of confused ownership. Keep Lock and Unlock in the same function.

### Pattern

**P-32. Confine state to one goroutine, or guard it with a documented mutex.** *(Concurrency practice)*

- *Problem it solves:* data races and unclear ownership.
- *How:* either (a) **confinement** — one goroutine owns the data and others send it requests through channels — or (b) a struct that holds the data and a `sync.Mutex`, with every method locking. Document which fields the mutex protects.
- *When not to use channels:* for simple shared counters, caches, and registries a mutex is clearer and faster. Channels shine for passing ownership, signalling, and pipelines.
- *Trade-off:* confinement makes races impossible by construction but adds message passing; mutexes are direct but rely on discipline.

### Mastery check

1. **Explain.** Why is a read without a lock still a race if another goroutine writes under the lock?
2. **Predict.** A method `func (c *Cache) Get(k string) string { c.mu.Lock(); defer c.mu.Unlock(); return c.load(k) }` where `load` also calls `c.mu.Lock()`. What happens?
3. **Write.** Make the `ds.LRU` from Chapter 6 safe for concurrent use with a `sync.Mutex`, and a test that hammers it from 50 goroutines under `-race`. Why can `Get` not use `RLock`?

## Unit 7.6 — sync/atomic and typed atomics

**One-line summary:** Atomic operations read, write, add, swap, or compare-and-swap a single variable indivisibly, without a lock. Use the typed atomics (`atomic.Int64`, `atomic.Bool`, `atomic.Pointer[T]`) for counters, flags, and lock-free publication of immutable snapshots.

```go
type Stats struct {
	requests atomic.Int64
	healthy  atomic.Bool
	config   atomic.Pointer[Config] // swap in a whole new immutable config
}

s.requests.Add(1)
n := s.requests.Load()
s.healthy.Store(true)
s.config.Store(&Config{...})
cfg := s.config.Load() // readers get a consistent snapshot, never a half-updated one
```

- **Compare-and-swap** (`CompareAndSwap(old, new)`) succeeds only if the value is still `old` — the building block of lock-free algorithms. The Chapter 7 project's test uses a CAS loop to track a maximum.
- The fixed counter from Unit 7.1: `var counter atomic.Int64` with `counter.Add(1)` prints 1000 every time.
- Atomics make **one variable** safe. Two related variables updated with two atomic operations are *not* updated together; use a mutex, or put both in one immutable struct behind an `atomic.Pointer`.
- Typed atomics (Go 1.19) are preferred over the older functions (`atomic.AddInt64(&x, 1)`), because a typed atomic cannot be accidentally read non-atomically and is correctly aligned on 32-bit platforms (DT-130). Go 1.27's `go fix` has an `atomictypes` modernizer for this.

### Deep & Tricky

**DT-231. Atomics are not free under contention.** *(Hardware fact)* An atomic add is a few nanoseconds uncontended, but when many cores update the same variable, its cache line bounces between cores (Unit 7.11), and each operation can cost a hundred nanoseconds. High-traffic counters are often **sharded** (one counter per P or per CPU, summed when read).

### Mastery check

1. **Explain.** Why is "check then act" with two atomic calls (`if x.Load() == 0 { x.Store(1) }`) racy, and how does `CompareAndSwap` fix it?
2. **Write.** A config hot-reload: a goroutine that every second reads a file and, if changed and valid, `Store`s a new `*Config`; handlers `Load` it. Test with `-race`.

## Unit 7.7 — The Go memory model

**One-line summary:** Without synchronisation, one goroutine is **not guaranteed** to see another's writes — or to see them in order — because compilers and CPUs reorder memory operations. The memory model defines **happens-before**: if a write happens before a read through a chain of synchronisation (channel operations, mutex unlock/lock, `WaitGroup`, `Once`, atomics), the read sees the write. A program without data races behaves as if executed sequentially.

### Why intuition fails

```go
var data int
var ready bool

go func() {
	data = 42
	ready = true
}()

for !ready { } // RACE: may spin forever (the compiler can hoist the read out of the loop)
fmt.Println(data) // and even if ready is seen, data may still read 0
```

Both the compiler (keeping `ready` in a register) and the CPU (store buffers, out-of-order execution) may make this fail. Nothing in this code establishes that `data = 42` *happens before* the print.

### Happens-before edges you can rely on

- Within one goroutine, statements happen in program order.
- `go f()` happens before `f` starts.
- A **send** on a channel happens before the corresponding **receive** completes. (For an unbuffered channel, the receive also happens before the send completes.)
- **Closing** a channel happens before a receive that returns because the channel is closed.
- The k-th receive on a channel with capacity C happens before the (k+C)-th send completes — which is why a buffered channel works as a semaphore.
- `mu.Unlock()` happens before any later `mu.Lock()` returns.
- `wg.Done()` happens before the `wg.Wait()` it unblocks.
- `once.Do(f)`: the completion of `f` happens before any `Do` returns.
- Atomic operations: if an atomic read observes an atomic write, the write happens before the read (Go's atomics are sequentially consistent).

Happens-before is **transitive**. The fixed version of the example:

```go
done := make(chan struct{})
go func() {
	data = 42
	close(done) // data = 42 happens before close
}()
<-done           // close happens before this receive returns
fmt.Println(data) // so this is guaranteed to print 42
```

### The practical rule

**If two goroutines access the same variable and at least one writes, there must be a happens-before chain between the accesses — through a channel, a lock, a WaitGroup, a Once, or an atomic.** If you cannot point to that chain, there is a race, and the race detector (Unit 7.8) will usually find it.

### Deep & Tricky

**DT-232. "Benign" races do not exist in Go.** *(Memory model)* The 2022 revision of the Go memory model gives racy programs limited, but not zero, guarantees: a racy read of a single machine word returns some value actually written, but multi-word values can be torn (DT-225), and the compiler may assume no races when optimising. Treat every reported race as a bug.

**DT-233. Double-checked locking without atomics is broken.** *(Classic bug)* `if instance == nil { mu.Lock(); if instance == nil { instance = new(T) }; mu.Unlock() }` — the first unlocked read races with the write, and a reader may see a non-nil pointer to a not-yet-initialised object. Use `sync.Once` / `OnceValue`.

### Mastery check

1. **Explain.** Name the happens-before chain that makes `fmt.Println(data)` correct in the fixed example.
2. **Explain.** Why can `for !ready {}` loop forever even after another goroutine sets `ready = true`?

## Topic 7D — Correctness

## Unit 7.8 — Races, deadlocks, and leaks

**One-line summary:** Three ways concurrent programs fail: **races** (unsynchronised access — find them with `-race`), **deadlocks** (goroutines waiting on each other forever — the runtime detects only the total kind), and **leaks** (goroutines blocked forever, silently consuming memory — prevent with ownership and cancellation, detect with goroutine counts and profiles).

### The race detector

```
$ go test -race ./...
$ go build -race -o app && ./app
```

The detector instruments every memory access and reports conflicting accesses not ordered by happens-before. Real output from the counter of Unit 7.1:

```
==================
WARNING: DATA RACE
Read at 0x00c000114078 by goroutine 12:
  main.main.func1()
      /tmp/s/main.go:27 +0x84

Previous write at 0x00c000114078 by goroutine 7:
  main.main.func1()
      /tmp/s/main.go:27 +0x96

Goroutine 12 (running) created at:
  main.main()
      /tmp/s/main.go:25 +0x7cd
...
==================
```

It shows both accesses with stacks and where each goroutine was created. Important limits: it finds races **that actually happen during the run** (so tests must exercise concurrent paths), it slows programs 2–20× and uses 5–10× memory, and a program with detected races exits with status 66 by default. Run all tests with `-race` in CI (Unit 11.7), and consider a canary deployment of a race-enabled build.

### Deadlocks

A deadlock is a cycle of waiting: A holds lock 1 and waits for lock 2; B holds lock 2 and waits for lock 1. Or a goroutine sends on an unbuffered channel no one will ever receive from.

If **every** goroutine is blocked, the runtime notices:

```
fatal error: all goroutines are asleep - deadlock!

goroutine 1 [chan send]:
main.main()
```

But if any goroutine is still running (a timer, an HTTP server's listener), a partial deadlock is **not** detected: the stuck goroutines simply wait forever. Prevention:

- Acquire multiple locks in a **consistent global order**.
- Do not hold a lock while sending on a channel or calling unknown code (callbacks).
- Every blocking operation should be able to give up: `select` with `ctx.Done()`.

### Goroutine leaks

A leaked goroutine is blocked forever: waiting to send to a channel nobody reads, or to receive from a channel nobody closes. It holds its stack and everything it references. Classic example:

```go
func firstResult(urls []string) string {
	ch := make(chan string) // unbuffered
	for _, u := range urls {
		go func() { ch <- fetch(u) }()
	}
	return <-ch // the other len(urls)-1 goroutines block forever on send: LEAK
}
```

Fixes: a buffered channel with room for every sender (`make(chan string, len(urls))`), or a `select` on `ctx.Done()` in the senders with cancellation when the first result arrives.

Detecting leaks:

- In tests, compare `runtime.NumGoroutine()` before and after (allowing a moment for goroutines to exit), or use `go.uber.org/goleak`.
- In production, the goroutine profile (`/debug/pprof/goroutine`, Unit 10.2) shows thousands of goroutines stuck at the same line.
- Go 1.27 made the **goroutine leak profile** generally available (`goroutineleak` in `runtime/pprof` and `/debug/pprof/goroutineleak`): it uses the garbage collector's reachability to find goroutines blocked on channels or locks that no running code can ever reach again.

### Deep & Tricky

**DT-234. The race detector cannot prove absence of races.** *(Tool limitation)* It reports races in executions it observes. A race in a code path your tests never run concurrently stays hidden. Combine `-race` with tests that deliberately run things in parallel (`t.Parallel`, many goroutines, `-count=50`).

**DT-235. Every goroutine needs an owner and an exit path.** *(Design rule)* Before writing `go`, answer: what makes this goroutine return? Who waits for it? What happens to it on error, on timeout, on shutdown? Most leaks come from an exit path that only exists for the happy case.

### Mastery check

1. **Explain.** Why did the runtime detect the deadlock in a program with one goroutine, but would not detect it in an HTTP server?
2. **Predict.** Does the `firstResult` example leak if `urls` has one element? Five? What is the cheapest fix?
3. **Write.** Deliberately create a lock-order deadlock between two goroutines, observe it (with a timeout in a test and a goroutine dump via `SIGQUIT` / `Ctrl+\`), then fix it with a consistent order.

## Topic 7E — Cancellation and patterns

## Unit 7.9 — context

**One-line summary:** A `context.Context` carries a **cancellation signal**, a **deadline**, and a few **request-scoped values** across API boundaries and goroutines. Every function that does I/O or may take long should accept `ctx context.Context` as its first parameter, pass it down, and stop when `ctx.Done()` is closed.

**Mental model — the order slip with a "cancel" checkbox.** When a customer cancels an order at the counter, the slip carrying the order number is marked cancelled, and everyone working on that order — kitchen, packing, delivery — checks the slip and stops. A context is that slip, passed to everyone working on one request.

### Creating contexts

```go
ctx := context.Background()                          // the root: in main, tests, top of a request
ctx, cancel := context.WithCancel(parent)            // cancel manually
ctx, cancel := context.WithTimeout(parent, 2*time.Second)
ctx, cancel := context.WithDeadline(parent, t)
ctx, cancel := context.WithCancelCause(parent)       // cancel(err) records why (Go 1.20)
defer cancel()                                        // ALWAYS: releases resources (go vet checks this)
```

Contexts form a tree: cancelling a parent cancels all its children; a child's deadline can only be *earlier* than its parent's. HTTP servers give each request a context that is cancelled when the client disconnects (Chapter 8); `signal.NotifyContext` gives one cancelled on Ctrl+C (Unit 5.7).

### Respecting cancellation

```go
func process(ctx context.Context, jobs <-chan Job) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err() // context.Canceled or context.DeadlineExceeded
		case j, ok := <-jobs:
			if !ok {
				return nil
			}
			if err := handle(ctx, j); err != nil { // pass ctx down
				return err
			}
		}
	}
}
```

Standard-library I/O takes contexts: `http.NewRequestWithContext`, `db.QueryContext` (Chapter 9), `exec.CommandContext`, `net.Dialer.DialContext`. A CPU-bound loop should check `ctx.Err()` every so often (the `logscan` project checked every 4096 lines).

### Conventions

- `ctx` is the **first parameter**, named `ctx`. Do not store it in structs (a struct outlives the request); pass it on every call.
- Never pass a nil context; use `context.TODO()` while refactoring.
- Check errors with `errors.Is(err, context.Canceled)` / `context.DeadlineExceeded` — they are usually wrapped.
- `context.WithoutCancel(ctx)` (Go 1.21) keeps values but drops cancellation — for work that must finish even if the request ends (writing an audit log). `context.AfterFunc(ctx, f)` (Go 1.21) runs `f` when ctx is done.

### Values — and when not to use them

```go
type ctxKey struct{} // unexported key type: no collisions with other packages

func WithRequestID(ctx context.Context, id string) context.Context {
	return context.WithValue(ctx, ctxKey{}, id)
}

func RequestID(ctx context.Context) string {
	id, _ := ctx.Value(ctxKey{}).(string)
	return id
}
```

Use values only for **request-scoped data that crosses API boundaries and is not a function parameter**: request IDs, trace spans, authenticated user identity. Never for optional parameters, database handles, or configuration — that hides dependencies and defeats the type system.

### Deep & Tricky

**DT-236. Forgetting `cancel()` leaks until the parent is cancelled.** *(Library behaviour)* Each `WithCancel`/`WithTimeout` registers the child with its parent. Without `cancel()`, the child (and a timer, for timeouts) stays alive until the parent is done — with `context.Background()` as parent, forever. `go vet`'s `lostcancel` check reports it.

**DT-237. Cancellation is cooperative.** *(Design)* Cancelling a context does not stop any goroutine by force; it only closes a channel. Code that never checks `ctx.Done()` (or calls functions that do) keeps running. A goroutine stuck in a non-context-aware call (a blocking read on a raw file, a C library) cannot be cancelled at all.

### Pattern

**P-33. Context first, everywhere work can block.** *(Universal Go convention)* Every exported function that performs I/O, waits, or loops for a long time takes `ctx context.Context` first and honours it. *Trade-off:* a parameter on many functions, in exchange for timeouts and cancellation that work end to end — the basis of robust services (Unit 8.7, Unit 12.7).

### Mastery check

1. **Explain.** What happens to a child context when its parent is cancelled? When the child's own timeout is longer than the parent's?
2. **Explain.** Why should a database handle not be stored in a context value?
3. **Write.** `retry(ctx, attempts int, f func(context.Context) error) error` with exponential backoff (100 ms, 200 ms, 400 ms…) that stops immediately when the context is cancelled, returning a wrapped error that still satisfies `errors.Is(err, context.Canceled)`.

## Unit 7.10 — Concurrency patterns

**One-line summary:** A handful of patterns cover most real concurrent code: **worker pools** (bounded parallel processing), **pipelines** (stages connected by channels), **fan-out/fan-in**, **semaphores** (bounding concurrency), **error groups** (first error cancels the rest), **backpressure**, and **rate limiting**.

### Worker pool

```go
func processAll(ctx context.Context, jobs []Job, workers int) []Result {
	in := make(chan Job)
	out := make(chan Result)

	var wg sync.WaitGroup
	for range workers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range in {
				select {
				case out <- process(ctx, j):
				case <-ctx.Done():
					return
				}
			}
		}()
	}

	go func() { // feeder: owns `in`, closes it
		defer close(in)
		for _, j := range jobs {
			select {
			case in <- j:
			case <-ctx.Done():
				return
			}
		}
	}()

	go func() { // closer: closes `out` after all workers have finished
		wg.Wait()
		close(out)
	}()

	var results []Result
	for r := range out {
		results = append(results, r)
	}
	return results
}
```

Note the ownership: the feeder owns `in` and closes it; a separate goroutine closes `out` after the `WaitGroup` says every sender is done. Results arrive in completion order; carry an index in `Result` if order matters.

### Pipelines and fan-out / fan-in

A pipeline is stages connected by channels: `generate → parse → enrich → store`, each stage a goroutine (or a pool) reading from one channel and writing to the next. **Fan-out** runs several goroutines reading the same input channel; **fan-in** merges several channels into one (the `merge` of Unit 7.4). Each stage must stop on `ctx.Done()` and close its output when its input is exhausted, so shutdown propagates cleanly down the pipeline.

### Semaphores: bounding concurrency

A buffered channel of capacity N is a counting semaphore:

```go
sem := make(chan struct{}, 10) // at most 10 at once
for _, f := range files {
	sem <- struct{}{} // acquire (blocks when 10 are running)
	wg.Add(1)
	go func() {
		defer wg.Done()
		defer func() { <-sem }() // release
		upload(f)
	}()
}
wg.Wait()
```

The crawler in this chapter's project uses exactly this to cap in-flight requests. `golang.org/x/sync/semaphore` offers a weighted version with context support.

### errgroup: the first error cancels the rest

```go
import "golang.org/x/sync/errgroup"

g, ctx := errgroup.WithContext(ctx)
g.SetLimit(8) // at most 8 goroutines at once
for _, id := range ids {
	g.Go(func() error {
		return syncUser(ctx, id) // ctx is cancelled as soon as any call returns an error
	})
}
if err := g.Wait(); err != nil { // the first error
	return err
}
```

`errgroup` (in the `golang.org/x/sync` module maintained by the Go team) is the standard tool for "run these in parallel, fail fast". Prefer it over hand-rolled WaitGroup-plus-error-channel code.

### Backpressure

When producers are faster than consumers, something must give. A bounded channel makes the producer wait (backpressure propagates upstream — good for pipelines); a `select` with `default` drops work (good for telemetry); an unbounded queue just converts the problem into an out-of-memory crash later. Choose deliberately.

### Rate limiting

Bounding concurrency ("at most 10 at a time") is different from bounding rate ("at most 5 per second"). The simplest rate limiter is a ticker:

```go
tick := time.NewTicker(200 * time.Millisecond) // 5 per second
defer tick.Stop()
for _, req := range requests {
	<-tick.C
	go send(req)
}
```

For bursts and per-client limits, a **token bucket** (`golang.org/x/time/rate`): a bucket refills at r tokens per second up to b tokens; each request takes one token or waits (`limiter.Wait(ctx)`). Unit 12.8 compares rate-limiting algorithms.

### Deep & Tricky

**DT-238. Unbounded goroutine creation is a bug waiting for a big input.** *(Practice)* `for _, x := range items { go work(x) }` with a million items starts a million goroutines — memory, file descriptors, and downstream services all suffer. Bound with a pool, a semaphore, or `errgroup.SetLimit`.

**DT-239. Results from a worker pool arrive in completion order.** *(Consequence of concurrency)* Tests that expect input order will pass sometimes and fail sometimes. Sort, index, or design the output to be order-independent.

### Mastery check

1. **Explain.** Who closes each channel in the worker pool, and why could a worker not close `out`?
2. **Explain.** Bounding concurrency vs bounding rate: give an example where you need each.
3. **Write.** A three-stage pipeline (read lines from a file → parse to numbers → sum) with cancellation; test that cancelling midway stops all stages with no leaked goroutines.

## Topic 7F — Advanced tools and testing

## Unit 7.11 — Advanced tools

**One-line summary:** `sync.Pool` reuses temporary objects to reduce allocations in hot paths; `sync.Map` is a concurrent map optimised for two specific access patterns; **false sharing** makes independent variables slow each other down when they share a cache line.

### sync.Pool

```go
var bufPool = sync.Pool{
	New: func() any { return new(bytes.Buffer) },
}

func render(w io.Writer, data Page) error {
	buf := bufPool.Get().(*bytes.Buffer)
	buf.Reset()
	defer bufPool.Put(buf)
	if err := tmpl.Execute(buf, data); err != nil {
		return err
	}
	_, err := w.Write(buf.Bytes())
	return err
}
```

A pool is a cache of reusable objects that the garbage collector may empty at any time. Use it for **temporary** objects allocated at high rates (buffers in encoders, formatters, HTTP servers). Rules: always reset objects before reuse; never put objects that are still referenced elsewhere; avoid pooling huge buffers (they pin memory — drop buffers above a size limit instead of putting them back). Measure the gain (Chapter 10); `fmt` and `encoding/json` use pools internally.

### sync.Map

`sync.Map` is safe for concurrent use without extra locking and is optimised for (1) keys written once and read many times (caches that only grow), and (2) goroutines working on disjoint sets of keys. For everything else, a plain `map` with a `sync.Mutex` or `RWMutex` is typically faster and clearer, and type-safe. Since Go 1.24 its implementation is a concurrent hash-trie with better performance, but the advice stands.

### False sharing

Two goroutines on two cores each update their *own* counter — no data race — but the counters sit in the same cache line (DT-32, DT-33). Every write invalidates the line in the other core's cache, so they bounce it back and forth, and the "independent" updates run many times slower. Fix by padding hot per-goroutine data to separate cache lines:

```go
type paddedCounter struct {
	n atomic.Int64
	_ [120]byte // 8 + 120 = 128: one line on Apple Silicon, two on x86
}

counters := make([]paddedCounter, runtime.GOMAXPROCS(0))
```

`golang.org/x/sys/cpu.CacheLinePad` provides the right size per architecture. Only pad after a benchmark shows contention: padding wastes memory.

### Mastery check

1. **Explain.** Why may `sync.Pool` drop objects, and why is that acceptable?
2. **Write.** A benchmark with 8 goroutines each incrementing its own `atomic.Int64` 10 million times, first in a plain `[8]atomic.Int64`, then padded. Report the ratio on your machine.

## Unit 7.12 — Testing concurrent code

**One-line summary:** Concurrent tests must be deterministic: no sleeps that "usually" suffice, no dependence on scheduling order. Use synchronisation instead of time, run with `-race` and high `-count`, inject clocks, and use `testing/synctest` (Go 1.25+) to test time-dependent concurrent code in a fake-time "bubble".

### Rules

- **Never use `time.Sleep` to wait for a goroutine.** Wait for an event: a channel receive, `wg.Wait()`, a result. Sleeps make tests slow on fast machines and flaky on slow CI machines.
- When you must wait for a condition, poll with a deadline and a short interval, failing with a clear message — and prefer making the code expose an event to wait on.
- Run concurrency tests with `-race -count=50` (or more) locally to shake out rare interleavings.
- Check for leaks: goroutine count before and after, or `goleak`.
- Inject time (P-28): code that uses `time.Now` and `time.After` directly is hard to test.

### `testing/synctest`

Go 1.25 made `testing/synctest` stable (it was an experiment in 1.24). Inside `synctest.Test`, goroutines run in a **bubble** with a fake clock: time advances only when every goroutine in the bubble is blocked, instantly jumping to the next timer. A test of a 30-second timeout runs in microseconds, deterministically:

```go
func TestTimeout(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		ctx, cancel := context.WithTimeout(t.Context(), 30*time.Second)
		defer cancel()
		start := time.Now()     // fake time inside the bubble
		<-ctx.Done()            // all goroutines blocked: the clock jumps 30s
		if d := time.Since(start); d != 30*time.Second {
			t.Errorf("waited %v", d)
		}
	})
}
```

`synctest.Wait()` blocks until every other goroutine in the bubble is durably blocked — a precise "let everything settle" without sleeps. Go 1.27 added `synctest.Sleep` (a sleep followed by `Wait`) and `httptest.NewTestServer`, an HTTP test server on an in-memory network that works inside bubbles.

### Deep & Tricky

**DT-240. A test that passes with `-count=1` can fail with `-count=1000`.** *(Probability)* A race window hit once in 500 runs passes casually and fails in production at scale. Repetition, `-race`, and `GOMAXPROCS` variation (`-cpu=1,2,8`) are how concurrency bugs are flushed out before users find them.

### Mastery check

1. **Explain.** Why is `time.Sleep(100 * time.Millisecond)` in a test both too long and too short?
2. **Write.** Using `synctest` (Go 1.25+) or an injected clock, test a "debouncer" that calls a function only after 500 ms without new events.

## Chapter 7 Project — `crawl`, a concurrent web crawler

**Goal:** a crawler that visits every page of one web site reachable from a start URL, with bounded parallel requests, a request-rate limit, a depth limit, cancellation (timeout and Ctrl+C), and no races or leaks — and a test suite that proves each property using a local test server.

### Specification

```
crawl [-depth 2] [-workers 4] [-rps 5] [-timeout 30s] URL
```

- Visit each URL at most once; follow only `http`/`https` links on the start URL's host.
- At most `-workers` requests in flight; at most `-rps` request starts per second.
- Report each page (depth, URL, number of links, or the error) as soon as it is fetched.
- Stop when everything reachable within `-depth` is visited, the timeout expires, or Ctrl+C is pressed; exit 1 if stopped early.
- Read at most 2 MB per page; time out each request after 10 s.

### Design

- `crawl.Crawl(ctx, fetcher, start, opts, report)` is a library function; the command is a thin wrapper.
- `Fetcher` is a consumer-defined interface (P-23) with an HTTP implementation.
- A **mutex-protected `seen` map** deduplicates URLs; a **buffered-channel semaphore** bounds in-flight requests; a **ticker** limits the rate; a **WaitGroup** knows when all work is done; the **context** stops everything.
- Each discovered page gets its own goroutine, which waits for a rate tick and a semaphore slot. Goroutines are cheap; requests are bounded.
- Tests use `httptest.NewServer` with a fake site: no network needed, fully deterministic.

### Reference solution — `crawl/crawl.go`

```go
// Package crawl visits the pages of one web site concurrently, with a
// bound on parallel requests, a request-rate limit, a depth limit, and
// cancellation through a context.
package crawl

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"sync"
	"time"
)

// Fetcher downloads a page. It is an interface so tests can use a fake.
type Fetcher interface {
	Fetch(ctx context.Context, url string) (body string, err error)
}

// Result describes one visited page.
type Result struct {
	URL   string
	Depth int
	Links int
	Err   error
}

type Options struct {
	Workers  int           // maximum requests in flight (default 4)
	MaxDepth int           // 0 = only the start page
	Interval time.Duration // minimum time between request starts (0 = no limit)
}

// Crawl visits start and pages linked from it on the same host, up to
// MaxDepth links away. It calls report for every page from several
// goroutines at once, so report must be safe for concurrent use.
// It returns when every reachable page was visited or ctx is done.
func Crawl(ctx context.Context, f Fetcher, start string, opt Options, report func(Result)) error {
	base, err := url.Parse(start)
	if err != nil {
		return fmt.Errorf("start URL: %w", err)
	}
	if opt.Workers < 1 {
		opt.Workers = 4
	}

	var (
		mu   sync.Mutex
		seen = map[string]bool{start: true}
		wg   sync.WaitGroup
		sem  = make(chan struct{}, opt.Workers) // counting semaphore
	)
	var tick <-chan time.Time
	if opt.Interval > 0 {
		t := time.NewTicker(opt.Interval)
		defer t.Stop()
		tick = t.C
	}

	var visit func(u string, depth int)
	visit = func(u string, depth int) {
		defer wg.Done()

		// Wait for a rate-limit slot and a worker slot, or give up on cancel.
		if tick != nil {
			select {
			case <-tick:
			case <-ctx.Done():
				return
			}
		}
		select {
		case sem <- struct{}{}:
		case <-ctx.Done():
			return
		}
		body, err := f.Fetch(ctx, u)
		<-sem // release the worker slot before spawning children

		if err != nil {
			report(Result{URL: u, Depth: depth, Err: err})
			return
		}
		links := sameHostLinks(base, u, body)
		report(Result{URL: u, Depth: depth, Links: len(links)})
		if depth == opt.MaxDepth {
			return
		}
		for _, l := range links {
			mu.Lock()
			isNew := !seen[l]
			seen[l] = true
			mu.Unlock()
			if isNew {
				wg.Add(1)
				go visit(l, depth+1)
			}
		}
	}

	wg.Add(1)
	go visit(start, 0)
	wg.Wait()
	return ctx.Err()
}

// hrefRE is a deliberately simple link finder. A real crawler should use
// an HTML parser (golang.org/x/net/html); regular expressions cannot
// parse HTML in general.
var hrefRE = regexp.MustCompile(`href="([^"#]+)`)

func sameHostLinks(base *url.URL, page, body string) []string {
	pu, err := url.Parse(page)
	if err != nil {
		return nil
	}
	var out []string
	for _, m := range hrefRE.FindAllStringSubmatch(body, -1) {
		ref, err := url.Parse(m[1])
		if err != nil {
			continue
		}
		abs := pu.ResolveReference(ref)
		if abs.Host == base.Host && (abs.Scheme == "http" || abs.Scheme == "https") {
			abs.Fragment = ""
			out = append(out, abs.String())
		}
	}
	return out
}

// HTTPFetcher fetches pages over HTTP with a size limit.
type HTTPFetcher struct {
	Client   *http.Client
	MaxBytes int64
}

var ErrStatus = errors.New("unexpected HTTP status")

func (h HTTPFetcher) Fetch(ctx context.Context, u string) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return "", err
	}
	resp, err := h.Client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("%w: %s", ErrStatus, resp.Status)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, h.MaxBytes))
	return string(b), err
}
```

Why release the semaphore **before** spawning children? If a goroutine held its slot while waiting for its children to get slots, a deep enough site would deadlock with every slot held by a parent waiting for children. Holding resources only for the operation that needs them is the general lesson.

### Reference solution — `crawl/crawl_test.go`

```go
package crawl

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// A small site with a cycle, a broken link, and an external link.
var site = map[string]string{
	"/":         `<a href="/a">a</a> <a href="/b">b</a> <a href="https://other.example/x">ext</a>`,
	"/a":        `<a href="/">home</a> <a href="/a/deep">deep</a>`,
	"/b":        `<a href="/missing">broken</a> <a href="/a">a</a>`,
	"/a/deep":   `<a href="/a/deeper">deeper</a>`,
	"/a/deeper": `the end`,
}

func newSite(t *testing.T, delay time.Duration, inFlight, maxInFlight *atomic.Int64) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n := inFlight.Add(1)
		defer inFlight.Add(-1)
		for {
			m := maxInFlight.Load()
			if n <= m || maxInFlight.CompareAndSwap(m, n) {
				break
			}
		}
		select {
		case <-time.After(delay):
		case <-r.Context().Done():
			return
		}
		body, ok := site[r.URL.Path]
		if !ok {
			http.NotFound(w, r)
			return
		}
		fmt.Fprint(w, body)
	}))
	t.Cleanup(srv.Close)
	return srv
}

func collect() (func(Result), func() []Result) {
	var mu sync.Mutex
	var rs []Result
	return func(r Result) {
			mu.Lock()
			rs = append(rs, r)
			mu.Unlock()
		}, func() []Result {
			mu.Lock()
			defer mu.Unlock()
			slices.SortFunc(rs, func(a, b Result) int {
				if a.URL < b.URL {
					return -1
				}
				if a.URL > b.URL {
					return 1
				}
				return 0
			})
			return rs
		}
}

func TestCrawlVisitsEachPageOnce(t *testing.T) {
	var inFlight, maxInFlight atomic.Int64
	srv := newSite(t, 20*time.Millisecond, &inFlight, &maxInFlight)
	report, results := collect()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	err := Crawl(context.Background(), f, srv.URL+"/", Options{Workers: 2, MaxDepth: 5}, report)
	if err != nil {
		t.Fatal(err)
	}
	rs := results()
	var got []string
	errCount := 0
	for _, r := range rs {
		got = append(got, r.URL[len(srv.URL):])
		if r.Err != nil {
			errCount++
			if !errors.Is(r.Err, ErrStatus) {
				t.Errorf("%s: unexpected error %v", r.URL, r.Err)
			}
		}
	}
	want := []string{"/", "/a", "/a/deep", "/a/deeper", "/b", "/missing"}
	if !slices.Equal(got, want) {
		t.Errorf("visited %v, want %v", got, want)
	}
	if errCount != 1 {
		t.Errorf("%d errors, want 1 (the 404)", errCount)
	}
	if m := maxInFlight.Load(); m > 2 {
		t.Errorf("%d requests in flight, limit was 2", m)
	}
}

func TestCrawlDepthLimit(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 0, &a, &b)
	report, results := collect()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	if err := Crawl(context.Background(), f, srv.URL+"/", Options{MaxDepth: 1}, report); err != nil {
		t.Fatal(err)
	}
	for _, r := range results() {
		if r.Depth > 1 {
			t.Errorf("%s visited at depth %d", r.URL, r.Depth)
		}
	}
	if n := len(results()); n != 3 { // /, /a, /b
		t.Errorf("visited %d pages, want 3", n)
	}
}

func TestCrawlCancel(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 2*time.Second, &a, &b) // every page is very slow
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	start := time.Now()
	err := Crawl(ctx, f, srv.URL+"/", Options{MaxDepth: 5}, func(Result) {})
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("err = %v, want DeadlineExceeded", err)
	}
	if d := time.Since(start); d > time.Second {
		t.Errorf("Crawl took %v after cancellation", d)
	}
}

func TestRateLimit(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 0, &a, &b)
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	start := time.Now()
	err := Crawl(context.Background(), f, srv.URL+"/", Options{Workers: 8, MaxDepth: 5, Interval: 50 * time.Millisecond}, func(Result) {})
	if err != nil {
		t.Fatal(err)
	}
	// 6 requests, at most one every 50ms: the first waits one tick too.
	if d := time.Since(start); d < 250*time.Millisecond {
		t.Errorf("6 requests finished in %v; rate limit not applied", d)
	}
}
```

The test server records the **maximum number of concurrent requests** with an atomic compare-and-swap loop: the bound is *proved*, not assumed. The whole suite passes under `go test -race -count=1`.

### Reference solution — `cmd/crawl/main.go`

```go
// Command crawl prints the pages of a web site reachable from a start URL.
//
//	crawl [-depth 2] [-workers 4] [-rps 5] [-timeout 30s] URL
package main

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"time"

	"example.com/crawler/crawl"
)

func main() {
	depth := flag.Int("depth", 2, "maximum link depth")
	workers := flag.Int("workers", 4, "maximum parallel requests")
	rps := flag.Float64("rps", 5, "maximum requests per second (0 = unlimited)")
	timeout := flag.Duration("timeout", 30*time.Second, "overall time limit")
	flag.Parse()
	if flag.NArg() != 1 {
		fmt.Fprintln(os.Stderr, "usage: crawl [flags] URL")
		os.Exit(2)
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	ctx, cancel := context.WithTimeout(ctx, *timeout)
	defer cancel()

	var interval time.Duration
	if *rps > 0 {
		interval = time.Duration(float64(time.Second) / *rps)
	}
	f := crawl.HTTPFetcher{
		Client:   &http.Client{Timeout: 10 * time.Second},
		MaxBytes: 2 << 20,
	}
	var mu sync.Mutex // report is called concurrently
	n := 0
	err := crawl.Crawl(ctx, f, flag.Arg(0), crawl.Options{Workers: *workers, MaxDepth: *depth, Interval: interval},
		func(r crawl.Result) {
			mu.Lock()
			defer mu.Unlock()
			n++
			if r.Err != nil {
				fmt.Printf("%d\t%s\tERROR %v\n", r.Depth, r.URL, r.Err)
				return
			}
			fmt.Printf("%d\t%s\t%d links\n", r.Depth, r.URL, r.Links)
		})
	fmt.Fprintf(os.Stderr, "%d pages\n", n)
	if err != nil {
		fmt.Fprintln(os.Stderr, "crawl stopped:", err)
		os.Exit(1)
	}
}
```

Note `time.Duration(float64(time.Second) / *rps)` for a fractional rate (DT-201).

### Review checklist

- Run `go test -race -count=100 ./...`. Any failure, even once, is a bug.
- For every goroutine: what makes it return on success, on error, on cancel?
- Is `report` documented as called concurrently? Does the command's callback lock?
- Does cancellation stop *waiting* goroutines (rate tick, semaphore) as well as in-flight requests?
- **Known limitation to discuss:** goroutines are bounded per *request*, not per *discovered URL*: a site with a million links spawns a million waiting goroutines (DT-238). For huge sites, replace "goroutine per URL" with a fixed pool of workers reading from a queue — and then think hard about how the pool knows when the crawl is finished (the queue can be empty while workers are still about to discover more URLs).
- **Politeness:** real crawlers honour `robots.txt` and identify themselves with a `User-Agent`.

### Extensions

1. Replace the goroutine-per-URL design with a fixed worker pool and a "pending work" counter; keep all tests passing.
2. Use `golang.org/x/net/html` to extract links properly (anchors, `<base href>`, relative URLs).
3. Add per-host rate limits for crawling several hosts, with a `map[string]*rate.Limiter` guarded by a mutex.

## Answers to the Chapter 7 prediction questions

**7.2 Q2.** Any order of 0, 1, 2 (or fewer, if a goroutine has not run before the sleep ends — unlikely but possible). Without the sleep, usually nothing: `main` returns and the program exits before the goroutines run.

**7.3 Q2.** (a) `fatal error: all goroutines are asleep - deadlock!` on the second send (buffer full, no receiver) (b) `0 false` (c) blocks forever; as the only goroutine, the runtime reports a deadlock (d) `panic: close of closed channel`.

**7.5 Q2.** Deadlock: Go mutexes are not reentrant, so `load` waits forever for the lock `Get` already holds. (In a server the runtime will not notice: only a total deadlock is detected, Unit 7.8.)

**7.8 Q2.** With one URL, no leak (the only sender is received from). With five, four goroutines leak. Cheapest fix: `make(chan string, len(urls))`, so every sender can complete.
