## Topic 3D — Errors and panics

## Unit 3.9 — Errors I

**One-line summary:** In Go, an error is an ordinary value of the interface type `error`. Functions that can fail return it as their last result; callers check it immediately with `if err != nil`. Good errors carry context so that the final message tells a human exactly what failed.

**Mental model — a delivery slip with a remarks column.** Every delivery comes back with a slip. Usually the remarks column is empty (`nil`). When something went wrong, the courier writes a remark: "address not found". Each depot that passes the slip back adds its own short note in front: "Pune hub: van 7: address not found". By the time it reaches you, the slip tells the whole story.

### The `error` interface

```go
type error interface {
	Error() string
}
```

Any type with an `Error() string` method is an error. The simplest ones:

```go
err := errors.New("disk full")
err := fmt.Errorf("user %d not found", id)
```

### Errors are values: check them right away

```go
f, err := os.Open(path)
if err != nil {
	return fmt.Errorf("open config: %w", err) // add context, return (Unit 3.10 explains %w)
}
defer f.Close()
```

This is P-9 (guard clauses) and P-10 (`(result, error)`) together. The happy path runs down the left margin; each failure is handled next to the line that caused it.

Why values instead of exceptions? Every place an operation can fail is *visible* in the code. Nothing can jump out of the middle of a function invisibly. The cost is verbosity, which Go accepts in exchange for clarity.

### Handle each error exactly once

For each error, do **one** of:

1. **Return it** (usually with added context) — the most common choice.
2. **Handle it** — retry, use a default, show it to the user, choose another path — and then do *not* also return it.
3. **Log it and continue** — only at the top level or for genuinely non-fatal problems.

The anti-pattern is *log and return*: the same failure appears in the logs five times, once per layer, with no added information. (Same lesson as "one problem, one report" in the Chapter 1 project.)

### Writing good error messages

- Lower-case, no trailing punctuation: they get embedded in longer messages (`load config: open /etc/app.yaml: permission denied`).
- Add *what you were doing* and the key identifiers: `fmt.Errorf("charge order %s: %w", orderID, err)`.
- Do not repeat what the wrapped error already says (`os.Open` errors already include the path).
- Never put secrets (passwords, tokens) in errors; they end up in logs.

### Errors from deferred calls

`defer f.Close()` ignores `Close`'s error. For files opened for *reading* that is acceptable. For *writing*, a failed `Close` can mean data was not saved (P-13's caveat). Use a named result and a deferred closure (the Unit 1.11 Rule 3 mechanism):

```go
func writeReport(path string, data []byte) (err error) {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer func() {
		if cerr := f.Close(); cerr != nil && err == nil {
			err = cerr // report Close's error only if nothing else failed
		}
	}()
	_, err = f.Write(data)
	return err
}
```

### Deep & Tricky

**DT-157. A function returning `(T, error)` usually leaves T unspecified on error.** *(Convention, not a guarantee)* Callers must not use the value when `err != nil`. A few functions document a useful partial result (`io.Reader.Read` returns `n > 0` bytes *and* an error; `strconv.ParseInt` returns the clamped maximum on range errors). Read the documentation; when in doubt, ignore the value on error.

**DT-158. `errors.New` creates a distinct value each call.** *(Guarantee)* `errors.New("x") == errors.New("x")` is false: each call allocates a new error, and errors compare by identity. That is why sentinel errors (Unit 3.10) are created once in a package-level `var`.

### Mastery check

1. **Explain.** What are the three things you can do with an error, and why is "log and return" an anti-pattern?
2. **Predict.** `errors.New("a") == errors.New("a")`; `err := fmt.Errorf("read %s: %v", "x.txt", io.EOF); err == io.EOF`.
3. **Write.** `loadPort(env map[string]string) (int, error)`: missing key, non-number, and out-of-range port (1–65535) each produce a distinct, well-worded error. Print the three messages.

## Unit 3.10 — Errors II: wrapping and inspecting

**One-line summary:** `fmt.Errorf("...: %w", err)` wraps an error, adding context while keeping the original inside. `errors.Is` checks whether any error in the chain equals a known value; `errors.As` (or `errors.AsType`, Go 1.26) finds an error of a specific type in the chain. Choose sentinel errors or typed errors depending on what callers need to know.

### Wrapping with `%w`

```go
func loadConfig(path string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return fmt.Errorf("load config: %w", err) // %w: wrap
	}
	...
}
```

The resulting error's message is `load config: open app.yaml: no such file or directory`, and it *contains* the original. With `%v` instead of `%w`, you get the same text but the chain is cut: callers can no longer inspect the cause.

**When to use `%w` vs `%v`:** `%w` makes the wrapped error part of your API (callers may start depending on it). Wrap when callers should be able to react to the cause; use `%v` when the cause is an implementation detail you may change (for example, an error from a database driver you might replace).

### `errors.Is`: "is it this specific error?"

```go
if errors.Is(err, fs.ErrNotExist) {
	// create a default config
}
```

`errors.Is` compares `err` and then each wrapped error (following `Unwrap`) with the target. Compare with `==` only when you know nothing wraps — in practice, always use `errors.Is`.

### `errors.As` and `errors.AsType`: "is there an error of this type?"

```go
var pe *fs.PathError
if errors.As(err, &pe) {
	fmt.Println("failed path:", pe.Path)
}

// Go 1.26+: generic, type-safe, no pointer-to-pointer
if pe, ok := errors.AsType[*fs.PathError](err); ok {
	fmt.Println("failed path:", pe.Path)
}
```

`As` gives you the typed error with all its fields. `AsType` is the recommended form in new code targeting Go 1.26+: it cannot be called with a wrong target type (a common `As` mistake, caught at run time by a panic or by `go vet`'s `errorsas` check).

### Sentinel errors vs typed errors

| | Sentinel error | Typed error |
| --- | --- | --- |
| What | A package-level variable: `var ErrNotFound = errors.New("not found")` | A type implementing `error`: `type ValidationError struct{ Field, Problem string }` |
| Caller checks with | `errors.Is(err, pkg.ErrNotFound)` | `errors.As` / `errors.AsType` |
| Carries data? | No (only identity) | Yes (fields) |
| Examples | `io.EOF`, `sql.ErrNoRows`, `fs.ErrNotExist`, `context.Canceled` | `*fs.PathError`, `*strconv.NumError`, `*net.OpError`, `*json.SyntaxError` |

Rules of thumb: use a sentinel when the caller only needs to know *which* condition happened; a typed error when they need *details*; and plain `fmt.Errorf` text when callers should not branch on the error at all (most errors!). Every exported sentinel or error type is API you must maintain.

### Writing a custom error type that wraps

```go
type QueryError struct {
	Query string
	Err   error
}

func (e *QueryError) Error() string { return "query " + e.Query + ": " + e.Err.Error() }
func (e *QueryError) Unwrap() error { return e.Err } // makes Is/As look inside
```

Use a pointer receiver and return `&QueryError{...}` (and see DT-147: never return a nil `*QueryError` as `error`).

### Several errors at once

```go
err := errors.Join(err1, err2, err3) // nil if all are nil; message is the messages joined by newlines
errors.Is(err, err2)                  // true

err = fmt.Errorf("sync: %w; cleanup: %w", errSync, errCleanup) // several %w (Go 1.20+)
```

Useful when validating many fields, or when a cleanup step fails after the main step already failed. Types can report several wrapped errors with `Unwrap() []error`.

### Deep & Tricky

**DT-159. `errors.As` panics if the target is not a non-nil pointer to an error type or interface.** *(Guarantee)* `errors.As(err, pe)` (missing `&`) or `errors.As(err, &notAnError)` panics at run time. `go vet` reports many of these; `errors.AsType` makes the mistake impossible.

**DT-160. A type can customise matching with `Is(target error) bool` and `As(target any) bool` methods.** *(Guarantee)* For example, a `*TimeoutError` can say it `Is` `context.DeadlineExceeded`. Use sparingly: it makes `errors.Is` results non-obvious to readers.

**DT-161. `go vet` (Go 1.27) flags `%w` with a pointer to a value-receiver error type.** *(Tool behaviour, version-dependent)* If `E` implements `error` with a value receiver and you write `fmt.Errorf("...: %w", p)` where `p` is `*E`, vet now reports it: `errors.As(err, &e)` with a value `e` would not match the `*E` in the chain. Be consistent about whether an error type is used as a value or a pointer.

**DT-162. Wrapping `io.EOF` breaks callers that check `err == io.EOF`.** *(Practice)* Some code — including older standard-library-style loops — compares `err == io.EOF` directly. If your `Read` method returns `fmt.Errorf("x: %w", io.EOF)`, those callers treat the normal end of data as a failure. Return `io.EOF` itself, unwrapped, from readers; the `io.Reader` contract expects exactly that.

### Pattern

**P-26. Wrap with context at every layer boundary; inspect only with `errors.Is`/`As`.** *(Universal Go practice)*

- *Problem it solves:* bare errors like `connection refused` with no clue *which* operation or ID failed; brittle string matching on messages.
- *How:* `return fmt.Errorf("verb object %s: %w", id, err)` when an error crosses a function or package boundary; check causes with `errors.Is` / `errors.As` / `errors.AsType`; never parse `err.Error()` text.
- *When not to:* do not wrap when the message already says everything (repeating "open file: open file.txt: ..."), and do not wrap with `%w` internals you do not want to expose — use `%v`.
- *Trade-off:* a little more typing; massively better debugging.

### Mastery check

1. **Explain.** What changes for callers between `fmt.Errorf("x: %w", err)` and `fmt.Errorf("x: %v", err)`?
2. **Predict.** (a) `errors.Is(fmt.Errorf("a: %w", fs.ErrNotExist), fs.ErrNotExist)` (b) the same with `%v` (c) `errors.Join(nil, nil) == nil` (d) `errors.Is(fmt.Errorf("x: %w, y: %w", fs.ErrNotExist, fs.ErrPermission), fs.ErrPermission)`
3. **Write.** A `ValidationErrors` type that collects several `*FieldError` values, implements `Error()` and `Unwrap() []error`, and lets callers find one field's error with `errors.As`.

## Unit 3.11 — panic and recover

**One-line summary:** `panic` stops normal execution and unwinds the stack, running deferred calls. `recover`, called directly inside a deferred function, stops the unwinding and returns the panic value. Panics are for programmer errors and impossible states, not for expected failures — those are errors.

### What panics are for

Panics signal bugs: an index out of range, a nil map write, a nil pointer dereference, a broken invariant ("this switch has a case for every enum value; reaching default is a bug"). Expected failures — file not found, invalid input, network down, insufficient balance — are **errors** and are returned.

```go
func mustPositive(n int) int {
	if n <= 0 {
		panic(fmt.Sprintf("mustPositive: got %d", n)) // a caller bug
	}
	return n
}
```

**`Must` functions** convert an error into a panic for values that are fixed at program start, where failure means the program itself is wrong:

```go
var validID = regexp.MustCompile(`^[a-z]+\[[0-9]+\]$`) // a bad pattern is a bug, found at startup
var tmpl = template.Must(template.New("x").Parse(text))
```

### What happens during a panic

1. Normal execution of the current function stops.
2. Its deferred calls run (LIFO), then the caller's deferred calls, and so on up the goroutine's stack.
3. If nothing recovers, the program prints `panic: <value>` and the stack trace of the goroutine and exits with code 2 (DT-6). Deferred output appears *before* the panic message (DT-90).

### `recover`

```go
func safeDivide(a, b int) (q int, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("safeDivide: %v", r) // turn the panic into an error
		}
	}()
	return a / b, nil
}

safeDivide(1, 0) // 0, "safeDivide: runtime error: integer divide by zero"
```

Rules:

- `recover` only works when called **directly** by a deferred function. Called anywhere else (or in a helper called *by* the deferred function), it returns nil and does nothing.
- After a successful recover, the function returns normally to its caller, with whatever its named results hold.
- A panic in one goroutine cannot be recovered in another. An unrecovered panic in **any** goroutine kills the **whole program** (Chapter 7).

### Where recovering is right

- At the boundary of an independent unit of work, so one bad request does not kill a server: `net/http` recovers panics in each handler and logs them (Chapter 8).
- In libraries that use panics internally as a control-flow shortcut (deep recursive parsers), recovering at the public API and returning an error — never letting the panic escape.

Recovering is **wrong** as a general error-handling mechanism ("try/catch"). After a panic the program's state may be inconsistent: a mutex may be locked, a half-updated structure left behind.

### Panics vs fatal errors

Some failures are not panics and cannot be recovered: `fatal error: stack overflow` (DT-39), `fatal error: concurrent map writes` (DT-124), `fatal error: all goroutines are asleep - deadlock!` (Chapter 7), out of memory. The runtime stops the program because its own state can no longer be trusted.

### Deep & Tricky

**DT-163. `panic(nil)` became a real panic in Go 1.21.** *(Version-dependent guarantee)* Before 1.21, `panic(nil)` made `recover()` return nil, indistinguishable from "no panic". Since 1.21 (for modules with `go 1.21` or later), `recover()` returns a `*runtime.PanicNilError` with the message `panic called with nil argument`.

**DT-164. Re-panicking keeps the original stack in the message.** *(Runtime behaviour)* If a deferred function recovers and calls `panic(r)` again (for example, after logging), the final output shows both panics, marked `[recovered]`. Use this to add cleanup without hiding the original crash.

**DT-165. `runtime.Goexit` runs defers but is not a panic.** *(Guarantee)* `Goexit` terminates the calling goroutine after running its deferred calls; `recover` returns nil during it. `t.FailNow` and `t.Fatal` in tests use `Goexit`, which is why they must be called from the test's own goroutine (Unit 4.1).

### Mastery check

1. **Explain.** Give two situations where panicking is right and two where returning an error is right.
2. **Predict.** A function defers `fmt.Println("A")`, then defers a closure that calls `recover()` and prints it, then defers `fmt.Println("C")`, then panics with `"boom"`. What is printed, in which order, and does the program exit?
3. **Write.** `func protect(f func()) (err error)` that runs `f` and converts any panic into an error that includes the panic value. Test with a nil map write and with a normal function.

## Topic 3E — Packages and modules

## Unit 3.12 — Packages

**One-line summary:** A package is a directory of `.go` files compiled together. Names starting with an upper-case letter are **exported** (visible to importers); everything else is private to the package. Good packages have short names, a focused purpose, and a small exported API. `internal/` directories restrict who may import, import cycles are forbidden, and initialisation happens in a defined order.

### Packages and directories

- All `.go` files in one directory (excluding `_test.go` files of an external test package) belong to **one package**, named in each file's `package` clause.
- The **import path** is the module path plus the directory: in module `example.com/library`, the directory `internal/catalog` is imported as `example.com/library/internal/catalog`.
- By convention the package name equals the last element of the import path (`catalog`).
- `package main` with `func main()` builds an executable; any other name builds a library.

### Exported vs unexported

```go
package catalog

type Book struct {   // exported type
	ID    string     // exported field
	title string     // unexported field: only code in package catalog can use it
}

func New() *Library  // exported
func countLoans()    // unexported
```

Capitalisation is the *only* visibility mechanism. There is no `public`/`private`/`protected`. Export as little as possible: everything exported is a promise to callers.

### Naming packages

Package names are short, lower-case, single words, no underscores or mixedCaps: `strconv`, `http`, `catalog`. Avoid meaningless names like `util`, `common`, `helpers`, `models` — they become dumping grounds. Since callers write `pkg.Name`, avoid stutter: `catalog.Book`, not `catalog.CatalogBook`; `http.Server`, not `http.HTTPServer`.

### Package documentation

A comment directly before the `package` clause documents the package; a comment directly before an exported name documents it, starting with that name:

```go
// Package catalog holds the library's domain rules: books, members, and loans.
package catalog

// Borrow lends one copy of a book to a member and returns the due date.
func (l *Library) Borrow(bookID, memberID string) (time.Time, error)
```

`go doc catalog.Library.Borrow` prints it; pkg.go.dev renders it. Since Go 1.19, doc comments support headings, lists, and links (`[Library.Borrow]`).

### `internal/`

A package in a directory named `internal` can be imported only by code rooted at the parent of `internal`. `example.com/library/internal/catalog` is importable from anywhere inside `example.com/library/...`, but not from other modules. Use it for everything you do not want to support as a public API — in applications, that is usually almost everything.

### Import cycles are forbidden

If package `a` imports `b`, then `b` (directly or indirectly) may not import `a`: compile error `import cycle not allowed`. This forces a layered design. Common fixes: move the shared type into a third, lower package; or have the lower package define an interface that the higher one implements (consumer-defined interfaces, P-23 — `catalog` defines `Store`, `store` implements it, and `catalog` never imports `store`).

### Initialisation order

1. Imported packages are initialised first (each only once, even if imported many times).
2. Within a package, package-level variables are initialised in **dependency order** (a variable whose initialiser uses another is initialised after it), otherwise in declaration order across files (files presented to the compiler in name order).
3. Then each `func init()` runs, in the order they appear (several per file allowed).
4. Finally, `main.main`.

```go
var a = b + 1   // initialised second
var b = 10      // initialised first
func init() { fmt.Println("init:", a, b) } // init: 11 10
```

Keep `init` minimal: it runs before `main`, cannot return errors, makes tests harder, and hides work. Prefer explicit initialisation called from `main`. Legitimate uses: registering drivers or codecs (`image/png` registers itself; `import _ "image/png"` imports a package only for its `init` side effect).

### Deep & Tricky

**DT-166. A test file can be in the same package or in `pkg_test`.** *(Toolchain behaviour)* `catalog_test.go` with `package catalog` sees unexported names (white-box tests); with `package catalog_test` it sees only the exported API (black-box tests), exactly like a real user — and it can import other packages that import `catalog` without a cycle. The library project's tests use the external form.

**DT-167. Unexported fields are invisible to reflection-based encoders.** *(Guarantee)* `encoding/json` cannot read or write unexported fields: a struct with only lower-case fields encodes as `{}`. Data that must be serialised needs exported fields (plus struct tags for the wire names), or custom marshalling (Unit 5.4).

**DT-168. Dot imports and package-name shadowing hurt readability.** *(Practice)* `import . "fmt"` lets you write `Println` unqualified — and makes every reader guess where names come from. A local variable named like an imported package (`url := ...` with `net/url` imported) shadows the package (Unit 1.9). Rename the import (`neturl "net/url"`) or the variable.

### Mastery check

1. **Explain.** How does `internal/` differ from simply not documenting a package?
2. **Predict.** Package `a` imports `b`, and `b` needs a type from `a`. What error do you get, and name two ways to restructure.
3. **Write.** A module with packages `money` (a `Paise` type, `Format`, `Parse`) and `cart` (uses `money`), plus `cmd/cart` main. Add doc comments and run `go doc ./money`.

## Unit 3.13 — Modules

**One-line summary:** A module is a versioned collection of packages, defined by a `go.mod` file at its root. `go.mod` lists the module path, the Go version, and required dependencies; `go.sum` records cryptographic hashes so builds are reproducible and tamper-evident. Go picks dependency versions with **minimal version selection**.

### `go.mod`

```
module example.com/library

go 1.27

toolchain go1.27.1

require (
	github.com/google/go-cmp v0.7.0
	golang.org/x/text v0.24.0
)

require golang.org/x/sys v0.33.0 // indirect

tool golang.org/x/tools/cmd/stringer
```

| Line | Meaning |
| --- | --- |
| `module` | the module path: the prefix of every package import path in it |
| `go` | the language version the code is written for (enables features such as per-iteration loop variables, DT-72); since 1.21 also the *minimum* Go version required |
| `toolchain` | optional: preferred toolchain to use when this module is the main module |
| `require` | dependencies and their minimum versions; `// indirect` marks ones not imported directly |
| `replace` | use a different module or a local directory instead (for local development or forks) |
| `exclude`, `retract` | skip a bad version / declare that your own published version should not be used |
| `tool` | (Go 1.24+) a tool dependency, run with `go tool stringer` |
| `godebug` | default GODEBUG settings for this program |

### Commands

```
go mod init example.com/library   # create go.mod (Go 1.26+ writes a go line one minor version below the toolchain)
go get github.com/google/go-cmp@v0.7.0   # add or change a dependency
go get -u ./...                   # upgrade dependencies (carefully)
go mod tidy                       # add missing and remove unused requirements; update go.sum
go list -m all                    # every module in the build, with versions
go mod why -m golang.org/x/sys    # why is this module needed?
go mod download / go mod verify   # fetch / check hashes of the module cache
```

Run `go mod tidy` before committing; CI should fail if it would change anything.

### Semantic versioning and major versions

Module versions are `vMAJOR.MINOR.PATCH`. Within a major version, newer versions must be backwards compatible. A breaking change requires a new major version, and **from v2 on, the major version is part of the module path**: `github.com/user/lib/v2`. So `lib` v1 and `lib/v2` are different modules and can even be used together in one build. Versions `v0.x.y` promise nothing.

### Minimal version selection (MVS)

If your module requires `A v1.2.0` and another dependency requires `A v1.4.0`, Go selects **v1.4.0** — the *minimum* version that satisfies everyone, never "the latest available". Builds are therefore reproducible without a lock file: the same `go.mod` files always select the same versions. Upgrades happen only when someone changes a `go.mod` (`go get -u`).

### `go.sum`, the proxy, and the checksum database

`go.sum` contains a hash of every module version used. On download, the `go` command verifies hashes against `go.sum` and, for new modules, against the public **checksum database** (`sum.golang.org`), so a compromised server cannot hand you different code for the same version. Modules are fetched through `GOPROXY` (default `https://proxy.golang.org,direct`). For private code set `GOPRIVATE=example.com/private/*` so it bypasses the public proxy and checksum database.

### Workspaces

`go work init ./app ./lib` creates `go.work`, letting you develop several modules together with local changes and no `replace` lines. Usually not committed.

### Deep & Tricky

**DT-169. The `go` line can trigger a toolchain download.** *(Toolchain behaviour, Go 1.21+)* If `go.mod` says `go 1.27` and your installed Go is 1.26, the `go` command downloads and runs Go 1.27 automatically (controlled by `GOTOOLCHAIN`). In locked-down environments this fails with a download error — the reason the code in this book was checked with whatever toolchain was available, with newer features marked.

**DT-170. Language changes are gated by each module's `go` line.** *(Guarantee)* A dependency with `go 1.21` keeps the old loop-variable semantics even when your module says `go 1.27` (DT-87). The same mechanism gates generic methods (1.27) and promoted-field literals (1.27): using them in a module whose `go` line is older is a compile error telling you which version is needed.

**DT-171. Never edit `go.sum` by hand, and commit it.** *(Practice)* It is the integrity record of your build. Merge conflicts in `go.sum` are resolved by `go mod tidy`.

### Mastery check

1. **Explain.** Why does minimal version selection make builds reproducible without a lock file?
2. **Explain.** Why must a v2 module change its import path?
3. **Write.** Create a module, add `golang.org/x/text`, use it to title-case a string with `cases.Title(language.English)`, then run `go mod tidy`, `go list -m all`, and `go mod why golang.org/x/text`. Explain each output line.

## Topic 3F — Generics and iterators

## Unit 3.14 — Generics I

**One-line summary:** Type parameters let one function or type work for many types while staying statically type-checked: `func Max[T cmp.Ordered](a, b T) T`. A **constraint** (an interface) says which types are allowed and which operations the code may use. The compiler usually infers the type arguments.

**Mental model — a mould with a slot for the material.** A generic function is a mould with a slot: "fill with any material that can be compared". You can cast it in steel or in brass, and the compiler checks each casting separately. Before generics, Go programmers either wrote the mould once per material (copy-paste) or used `any` and checked at run time.

### Generic functions

```go
func Map[T, U any](s []T, f func(T) U) []U {
	out := make([]U, 0, len(s))
	for _, v := range s {
		out = append(out, f(v))
	}
	return out
}

lengths := Map([]string{"go", "rust"}, func(s string) int { return len(s) }) // [2 4]
```

- Type parameters go in square brackets before the regular parameters: `[T, U any]`.
- **Type inference** works out `T = string, U = int` from the arguments. You can also write them: `Map[string, int](...)`. Since Go 1.21 inference also works from the assigned type in more places, and Go 1.27 extended it to every context where a generic function is assigned or converted to a matching function type.

### Constraints

A constraint is an interface that limits the type arguments:

```go
func Max[T cmp.Ordered](a, b T) T { // cmp.Ordered: types supporting < <= > >=
	if a > b {
		return a
	}
	return b
}

func Index[T comparable](s []T, v T) int { // comparable: types supporting == and !=
	for i, x := range s {
		if x == v {
			return i
		}
	}
	return -1
}
```

| Constraint | Allows | Operations you may use |
| --- | --- | --- |
| `any` | every type | assignment, passing, `var zero T` — no `==`, no `<`, no `+` |
| `comparable` | types with `==` | `==`, `!=`, map keys |
| `cmp.Ordered` | integers, floats, strings (and named types based on them) | `< <= > >=` plus `==` |
| your own interface with methods | types with those methods | calling the methods |

The compiler checks the generic body *once*, against the constraint: you may only use operations that every allowed type supports.

### Generic types

```go
type Stack[T any] struct {
	items []T
}

func (s *Stack[T]) Push(v T) { s.items = append(s.items, v) }

func (s *Stack[T]) Pop() (T, bool) {
	var zero T // the zero value of whatever T is
	if len(s.items) == 0 {
		return zero, false
	}
	v := s.items[len(s.items)-1]
	s.items = s.items[:len(s.items)-1]
	return v, true
}

var s Stack[int] // instantiate with int; the zero value is ready to use
s.Push(1)
```

Inside methods, the receiver repeats the type parameter names (`Stack[T]`). `var zero T` is the standard way to get a zero value of a type parameter.

### Deep & Tricky

**DT-172. `comparable` admits interface types, whose `==` can panic.** *(Guarantee, since Go 1.20)* `Index[any]([]any{[]int{1}}, []int{1})` compiles, and the comparison panics at run time (DT-148). "Strictly comparable" types (no interfaces inside) never panic.

**DT-173. Type inference never uses the result type of a call alone.** *(Guarantee)* `func Zero[T any]() T` cannot be called as `var n int = Zero()`. With no arguments to infer from, write `Zero[int]()`. Inference works from argument types (and, since 1.21, from the *function type* a generic function is assigned to).

### Mastery check

1. **Explain.** What does a constraint do *for the caller* and *for the function body*?
2. **Predict.** (a) `Max(3, 7.5)` (b) `Max("go", "Go")` (c) `Index([]float64{math.NaN()}, math.NaN())` (d) a generic `Sum[T any]` that writes `s += v` — does it compile?
3. **Write.** `Filter[T any](s []T, keep func(T) bool) []T`, `Reduce[T, A any](s []T, init A, f func(A, T) A) A`, and use them to compute the total length of all words longer than 3 letters.

## Unit 3.15 — Generics II

**One-line summary:** Constraints can list types with `|` and `~`, generic data structures replace copy-paste, and since Go 1.27 methods may have their own type parameters. Use generics for algorithms and containers that are truly type-independent — not as a reflex.

### Union and `~` constraints

```go
type Number interface {
	~int | ~int8 | ~int16 | ~int32 | ~int64 | ~float32 | ~float64
}

func Sum[T Number](xs []T) T {
	var s T
	for _, x := range xs {
		s += x // allowed: every type in the union supports +
	}
	return s
}

type Paise int64
Sum([]Paise{100, 250}) // 350 — works because of ~int64
```

- `A | B` means "A or B".
- `~int64` means "any type whose **underlying** type is `int64`", including your named types. Without `~`, `Sum([]Paise{...})` would be rejected.
- Interfaces containing type unions can be used **only as constraints**, not as ordinary variable types.
- The standard `cmp.Ordered` is defined exactly this way.

### Generic data structures

```go
type Set[T comparable] struct{ m map[T]struct{} }

func NewSet[T comparable](items ...T) Set[T] {
	s := Set[T]{m: make(map[T]struct{}, len(items))}
	for _, it := range items {
		s.m[it] = struct{}{}
	}
	return s
}

func (s Set[T]) Has(v T) bool { _, ok := s.m[v]; return ok }
func (s Set[T]) Add(v T)      { s.m[v] = struct{}{} }
func (s Set[T]) Len() int     { return len(s.m) }
```

Chapter 6 builds a full generic data-structure library (heap, queue, LRU cache, graph).

### Generic methods (Go 1.27)

Before Go 1.27, a method could use its type's parameters but could not declare new ones, so helper "methods" like `Map` had to be top-level functions. Go 1.27 allows methods to have their own type parameters:

```go
type List[T any] struct{ items []T }

// Go 1.27+: Map declares its own type parameter U.
func (l List[T]) Map[U any](f func(T) U) List[U] {
	out := List[U]{items: make([]U, 0, len(l.items))}
	for _, v := range l.items {
		out.items = append(out.items, f(v))
	}
	return out
}
```

Two restrictions remain: **interface methods cannot have type parameters**, and a generic method **cannot be used to satisfy an interface**. (Satisfying an interface requires a fixed method signature; a generic method is a family of signatures.)

### When NOT to use generics

- When an **interface with methods** expresses the need: `func Render(w io.Writer)` is better than `func Render[W io.Writer](w W)`.
- When the code is written for **one** type today. Wait until you have two or three real uses.
- When different types need different *implementations* — that is what methods and interfaces are for.

Good uses: container types, algorithms over slices and maps (`slices`, `maps`), functional helpers, type-safe wrappers (`atomic.Pointer[T]`, `sync.OnceValue`).

### How generics are compiled (briefly)

The Go compiler uses **GC-shape stenciling with dictionaries**: it generates one copy of the code per *memory shape* (all pointer types share a shape, `int` and `int64` share a shape on 64-bit, and so on) and passes a hidden dictionary describing the actual type. This keeps binaries small; the cost is that some generic code is a little slower than hand-written code for one type, particularly when calling methods on type parameters (Chapter 10 measures it).

### Deep & Tricky

**DT-174. A type parameter's methods are only those in its constraint.** *(Guarantee)* Inside `func F[T fmt.Stringer](v T)`, you may call `v.String()`, but not any other method, even if every type you plan to pass has it. And you cannot type-switch on `T` directly; you can only switch on `any(v)`.

**DT-175. Generic code that calls methods through a type parameter may be slower than an interface call.** *(Implementation detail)* Because all pointer types share one shape, a call like `v.String()` inside a generic function goes through the dictionary — an extra indirection on top of the method lookup. For performance-critical code, measure; sometimes a plain interface parameter is faster *and* simpler.

### Pattern

**P-27. Generics for algorithms and containers; interfaces for behaviour.** *(Go design practice)* If you need "the same code for many types", use type parameters. If you need "different code behind the same call", use an interface. Start concrete, generalise when the second or third use appears. *Trade-off:* generics remove duplication and `any`-casting, but add type-parameter noise and can obscure simple code.

### Mastery check

1. **Explain.** What does `~` add to a constraint? Why does `cmp.Ordered` use it?
2. **Explain.** Why can a generic method not satisfy an interface method?
3. **Write.** `Set[T]` with `Union`, `Intersect`, and `Sorted` (for `T cmp.Ordered` — think about where that constraint must go); tests with `Set[string]` and `Set[int]`.

## Unit 3.16 — Iterators

**One-line summary:** Since Go 1.23, `for range` accepts functions of the shapes `func(yield func(V) bool)` and `func(yield func(K, V) bool)`. The `iter` package names them `iter.Seq[V]` and `iter.Seq2[K, V]`. Iterators let collections expose their elements lazily and uniformly, and the standard library's `slices` and `maps` packages produce and consume them.

### Range over a function

```go
// Countdown yields n, n-1, ..., 1.
func Countdown(n int) iter.Seq[int] {
	return func(yield func(int) bool) {
		for i := n; i > 0; i-- {
			if !yield(i) { // the loop body ran; false means the loop said "stop" (break, return)
				return
			}
		}
	}
}

for v := range Countdown(3) {
	fmt.Println(v) // 3 2 1
}
```

How it works: the compiler turns the loop *body* into the `yield` function. Each `yield(v)` runs the body once with `v`. If the body executes `break` (or `return`, or a labelled jump out), `yield` returns false, and the iterator **must** stop calling it — calling `yield` again after it returned false panics.

### Iterators in the standard library

```go
for i, v := range slices.All(s) {}    // iter.Seq2[int, E]
for v := range slices.Values(s) {}    // iter.Seq[E]
for k := range maps.Keys(m) {}        // iter.Seq[K]
for k, v := range maps.All(m) {}      // iter.Seq2[K, V]

keys := slices.Sorted(maps.Keys(m))   // consume an iterator into a sorted slice
vals := slices.Collect(maps.Values(m))

for line := range strings.Lines(text) {}       // Go 1.24
for part := range strings.SplitSeq(s, ",") {}  // Go 1.24, no intermediate slice
```

### Exposing your collection as an iterator

```go
type Library struct{ books []Book }

func (l *Library) Books() iter.Seq[Book] {
	return func(yield func(Book) bool) {
		for _, b := range l.books {
			if !yield(b) {
				return
			}
		}
	}
}
```

Callers get read-only, lazy access (no copied slice; compare DT-155) and can stop early. The iterator can also do work per element — filter, decode, page through an API — that would otherwise require building a slice first.

### Pull iterators

Sometimes you need to pull values on demand, for example to merge two sorted sequences. `iter.Pull` converts a push iterator into a `next` function:

```go
next, stop := iter.Pull(seq)
defer stop()            // always call stop, or the iterator's resources leak
v, ok := next()
```

### Deep & Tricky

**DT-176. An iterator that ignores `yield`'s false result panics.** *(Guarantee)* If the loop breaks and the iterator calls `yield` again, the runtime panics with `range function continued iteration after function for loop body returned false`. Always `if !yield(v) { return }`.

**DT-177. `defer` inside an iterator runs when the iterator function returns — after the loop ends or breaks.** *(Guarantee)* This makes iterators good at managing resources: open a file, `defer f.Close()`, yield lines. Breaking out of the caller's loop makes `yield` return false, the iterator returns, and the file closes. (But see DT-176 — the iterator must actually return.)

**DT-178. Single-use vs reusable iterators.** *(Convention)* `slices.Values(s)` can be ranged over many times; an iterator reading from a network stream can be used once. Document which kind you return. Iterators returned by `iter.Pull` are single-use by nature.

### Mastery check

1. **Explain.** What does the compiler turn the loop body into? What happens on `break`?
2. **Predict.** `for v := range Countdown(5) { if v == 3 { break }; fmt.Print(v) }`. And what happens if `Countdown` ignored the result of `yield`?
3. **Write.** `Fibonacci() iter.Seq[int]` (infinite), `Take[T any](seq iter.Seq[T], n int) iter.Seq[T]`, and `Filter[T any](seq iter.Seq[T], keep func(T) bool) iter.Seq[T]`. Print the first 10 even Fibonacci numbers.

## Chapter 3 Project — `library`, a lending-library CLI

**Goal:** a command-line program for a small lending library, organised into packages with a clean domain layer, a storage layer behind a consumer-defined interface, typed and sentinel errors, an enum, and tests. This is the first project that looks like a real Go codebase.

### Specification

```
library add-book <id> <copies> <genre> <title...>
library add-member <id> <name...>
library borrow <book-id> <member-id>
library return <book-id> <member-id>
library list
library overdue
```

- Data is kept in a JSON file: `$LIBRARY_DATA`, or `library.json` in the current directory.
- A book has an ID, title, genre (fiction, science, history, children), and number of copies. A loan lasts 14 days.
- Borrowing fails if the book or member does not exist, or if all copies are out. Returning fails if that member has not borrowed that book.
- Exit codes: 0 success, 1 operation failed (message on stderr), 2 usage error (message and usage text on stderr).

### Required structure

```
library/
├── go.mod                       module example.com/library
├── cmd/library/main.go          argument parsing and output only
└── internal/
    ├── catalog/                 domain: types, rules, errors, the Store interface
    │   ├── catalog.go
    │   └── catalog_test.go      tests through the public API (package catalog_test)
    └── store/                   Memory and File implementations of catalog.Store
        └── store.go
```

**Requirements**

1. `catalog` does not import `store` (the dependency points *towards* the domain, P-23).
2. `catalog.Store` has only the methods `catalog` actually calls.
3. Sentinel errors for conditions callers branch on (`ErrNotFound`, `ErrAlreadyExists`, `ErrNoCopies`, `ErrNotBorrowed`); a typed `*ValidationError` with the field name; every other error wrapped with context.
4. `Genre` is an enum with `String()` and `ParseGenre`; the zero value means unknown.
5. Time is injectable so tests are deterministic (`WithClock`).
6. `store.File` saves atomically (write a temporary file, then rename).
7. `go vet ./...` clean; tests cover borrow/return success, no copies, not borrowed, not found, duplicates, validation, and genre parsing.

### Reference solution — `internal/catalog/catalog.go`

```go
// Package catalog holds the library's domain rules: books, members, and
// loans. It knows nothing about files or the command line; storage is
// reached through the small Store interface, which this package defines
// because this package is the one that uses it.
package catalog

import (
	"cmp"
	"errors"
	"fmt"
	"slices"
	"strings"
	"time"
)

// Genre is an enum: a named integer type with a fixed set of constants.
type Genre int

const (
	GenreUnknown Genre = iota // zero value means "not set"
	Fiction
	Science
	History
	Children
)

var genreNames = [...]string{"unknown", "fiction", "science", "history", "children"}

func (g Genre) String() string {
	if g < 0 || int(g) >= len(genreNames) {
		return fmt.Sprintf("Genre(%d)", int(g))
	}
	return genreNames[g]
}

// ParseGenre converts a name such as "science" to a Genre.
func ParseGenre(s string) (Genre, error) {
	for i, name := range genreNames {
		if i > 0 && strings.EqualFold(s, name) {
			return Genre(i), nil
		}
	}
	return GenreUnknown, &ValidationError{Field: "genre", Problem: fmt.Sprintf("unknown genre %q", s)}
}

type Book struct {
	ID     string
	Title  string
	Author string
	Genre  Genre
	Copies int // copies owned by the library
}

type Member struct {
	ID   string
	Name string
}

type Loan struct {
	BookID   string
	MemberID string
	Due      time.Time
}

// Sentinel errors: callers compare with errors.Is.
var (
	ErrNotFound      = errors.New("not found")
	ErrAlreadyExists = errors.New("already exists")
	ErrNoCopies      = errors.New("no copies available")
	ErrNotBorrowed   = errors.New("book is not borrowed by this member")
)

// ValidationError is a typed error: callers extract it with errors.As
// (or errors.AsType in Go 1.26+) to learn which field was wrong.
type ValidationError struct {
	Field   string
	Problem string
}

func (e *ValidationError) Error() string { return e.Field + ": " + e.Problem }

// Store is what the catalog needs from storage. Small on purpose.
type Store interface {
	Book(id string) (Book, error) // returns an error wrapping ErrNotFound if missing
	PutBook(b Book) error
	Books() ([]Book, error)
	Member(id string) (Member, error)
	PutMember(m Member) error
	Loans() ([]Loan, error)
	PutLoans(loans []Loan) error
}

// LoanPeriod is how long a member may keep a book.
const LoanPeriod = 14 * 24 * time.Hour

// Library applies the rules. Create it with New.
type Library struct {
	store Store
	now   func() time.Time // replaceable in tests
}

func New(s Store) *Library {
	return &Library{store: s, now: time.Now}
}

// WithClock returns a copy of l that uses now instead of time.Now.
func (l *Library) WithClock(now func() time.Time) *Library {
	c := *l
	c.now = now
	return &c
}

func (l *Library) AddBook(b Book) error {
	b.ID = strings.TrimSpace(b.ID)
	b.Title = strings.TrimSpace(b.Title)
	switch {
	case b.ID == "":
		return &ValidationError{Field: "id", Problem: "must not be empty"}
	case b.Title == "":
		return &ValidationError{Field: "title", Problem: "must not be empty"}
	case b.Copies < 1:
		return &ValidationError{Field: "copies", Problem: fmt.Sprintf("must be at least 1, got %d", b.Copies)}
	}
	if _, err := l.store.Book(b.ID); err == nil {
		return fmt.Errorf("book %q: %w", b.ID, ErrAlreadyExists)
	} else if !errors.Is(err, ErrNotFound) {
		return err
	}
	return l.store.PutBook(b)
}

func (l *Library) AddMember(m Member) error {
	if strings.TrimSpace(m.ID) == "" {
		return &ValidationError{Field: "id", Problem: "must not be empty"}
	}
	if _, err := l.store.Member(m.ID); err == nil {
		return fmt.Errorf("member %q: %w", m.ID, ErrAlreadyExists)
	} else if !errors.Is(err, ErrNotFound) {
		return err
	}
	return l.store.PutMember(m)
}

// Borrow lends one copy of a book to a member and returns the due date.
func (l *Library) Borrow(bookID, memberID string) (time.Time, error) {
	book, err := l.store.Book(bookID)
	if err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	if _, err := l.store.Member(memberID); err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	loans, err := l.store.Loans()
	if err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	if out := countLoans(loans, bookID); out >= book.Copies {
		return time.Time{}, fmt.Errorf("borrow %q: all %d copies are out: %w", bookID, book.Copies, ErrNoCopies)
	}
	due := l.now().Add(LoanPeriod)
	loans = append(loans, Loan{BookID: bookID, MemberID: memberID, Due: due})
	if err := l.store.PutLoans(loans); err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	return due, nil
}

// Return ends a member's loan of a book.
func (l *Library) Return(bookID, memberID string) error {
	loans, err := l.store.Loans()
	if err != nil {
		return fmt.Errorf("return: %w", err)
	}
	i := slices.IndexFunc(loans, func(ln Loan) bool {
		return ln.BookID == bookID && ln.MemberID == memberID
	})
	if i < 0 {
		return fmt.Errorf("return %q by %q: %w", bookID, memberID, ErrNotBorrowed)
	}
	return l.store.PutLoans(slices.Delete(loans, i, i+1))
}

// Availability is one line of the catalogue listing.
type Availability struct {
	Book      Book
	Available int
}

// List returns every book with its number of available copies, by title.
func (l *Library) List() ([]Availability, error) {
	books, err := l.store.Books()
	if err != nil {
		return nil, err
	}
	loans, err := l.store.Loans()
	if err != nil {
		return nil, err
	}
	out := make([]Availability, 0, len(books))
	for _, b := range books {
		out = append(out, Availability{Book: b, Available: b.Copies - countLoans(loans, b.ID)})
	}
	slices.SortFunc(out, func(a, b Availability) int {
		return cmp.Or(
			strings.Compare(a.Book.Title, b.Book.Title),
			strings.Compare(a.Book.ID, b.Book.ID),
		)
	})
	return out, nil
}

// Overdue returns the loans whose due date is before now.
func (l *Library) Overdue() ([]Loan, error) {
	loans, err := l.store.Loans()
	if err != nil {
		return nil, err
	}
	now := l.now()
	return slices.DeleteFunc(loans, func(ln Loan) bool { return !ln.Due.Before(now) }), nil
}

func countLoans(loans []Loan, bookID string) int {
	n := 0
	for _, ln := range loans {
		if ln.BookID == bookID {
			n++
		}
	}
	return n
}
```

`cmp.Or` (Go 1.22) returns its first non-zero argument — a neat way to chain comparison tie-breakers.

### Reference solution — `internal/store/store.go`

```go
// Package store implements catalog.Store in memory and in a JSON file.
package store

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"maps"
	"os"
	"slices"

	"example.com/library/internal/catalog"
)

// Memory keeps everything in maps. Its zero value is NOT ready to use
// (nil maps panic on write), so callers use NewMemory.
type Memory struct {
	books   map[string]catalog.Book
	members map[string]catalog.Member
	loans   []catalog.Loan
}

// Compile-time check that *Memory satisfies catalog.Store.
var _ catalog.Store = (*Memory)(nil)

func NewMemory() *Memory {
	return &Memory{
		books:   make(map[string]catalog.Book),
		members: make(map[string]catalog.Member),
	}
}

func (m *Memory) Book(id string) (catalog.Book, error) {
	b, ok := m.books[id]
	if !ok {
		return catalog.Book{}, fmt.Errorf("book %q: %w", id, catalog.ErrNotFound)
	}
	return b, nil
}

func (m *Memory) PutBook(b catalog.Book) error { m.books[b.ID] = b; return nil }

func (m *Memory) Books() ([]catalog.Book, error) {
	return slices.Collect(maps.Values(m.books)), nil
}

func (m *Memory) Member(id string) (catalog.Member, error) {
	mem, ok := m.members[id]
	if !ok {
		return catalog.Member{}, fmt.Errorf("member %q: %w", id, catalog.ErrNotFound)
	}
	return mem, nil
}

func (m *Memory) PutMember(mem catalog.Member) error { m.members[mem.ID] = mem; return nil }

func (m *Memory) Loans() ([]catalog.Loan, error) { return slices.Clone(m.loans), nil }

func (m *Memory) PutLoans(loans []catalog.Loan) error { m.loans = slices.Clone(loans); return nil }

// File is a Memory that is loaded from and saved to a JSON file.
// Embedding *Memory promotes all of its methods; File overrides the
// three that change data so it can save after each change.
type File struct {
	*Memory
	path string
}

var _ catalog.Store = (*File)(nil)

type fileData struct {
	Books   []catalog.Book   `json:"books"`
	Members []catalog.Member `json:"members"`
	Loans   []catalog.Loan   `json:"loans"`
}

// OpenFile loads path, or starts empty if the file does not exist yet.
func OpenFile(path string) (*File, error) {
	f := &File{Memory: NewMemory(), path: path}
	data, err := os.ReadFile(path)
	if errors.Is(err, fs.ErrNotExist) {
		return f, nil
	}
	if err != nil {
		return nil, err
	}
	var fd fileData
	if err := json.Unmarshal(data, &fd); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	for _, b := range fd.Books {
		f.books[b.ID] = b
	}
	for _, m := range fd.Members {
		f.members[m.ID] = m
	}
	f.loans = fd.Loans
	return f, nil
}

func (f *File) PutBook(b catalog.Book) error     { f.Memory.PutBook(b); return f.save() }
func (f *File) PutMember(m catalog.Member) error { f.Memory.PutMember(m); return f.save() }
func (f *File) PutLoans(l []catalog.Loan) error  { f.Memory.PutLoans(l); return f.save() }

func (f *File) save() error {
	fd := fileData{Loans: f.loans}
	for _, id := range slices.Sorted(maps.Keys(f.books)) {
		fd.Books = append(fd.Books, f.books[id])
	}
	for _, id := range slices.Sorted(maps.Keys(f.members)) {
		fd.Members = append(fd.Members, f.members[id])
	}
	data, err := json.MarshalIndent(fd, "", "  ")
	if err != nil {
		return err
	}
	// Write to a temporary file, then rename: a crash never leaves half a file.
	tmp := f.path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, f.path)
}
```

`Memory` returns *clones* of its loans slice and stores clones of what it is given: callers can never change the store's data through a slice they hold (DT-155). JSON encoding (`json.MarshalIndent`, struct tags) is taught properly in Unit 5.4; the `Genre` field is stored as its number.

### Reference solution — `cmd/library/main.go`

```go
// Command library manages a small lending library stored in a JSON file.
//
//	library add-book <id> <copies> <genre> <title...>
//	library add-member <id> <name...>
//	library borrow <book-id> <member-id>
//	library return <book-id> <member-id>
//	library list
//	library overdue
//
// The data file is $LIBRARY_DATA, or library.json in the current directory.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

const usage = `usage:
  library add-book <id> <copies> <genre> <title...>
  library add-member <id> <name...>
  library borrow <book-id> <member-id>
  library return <book-id> <member-id>
  library list
  library overdue`

// errUsage marks errors for which the usage text should be printed.
var errUsage = errors.New("bad usage")

func main() {
	err := run(os.Args[1:], os.Stdout)
	if err == nil {
		return
	}
	fmt.Fprintln(os.Stderr, "library:", err)
	if errors.Is(err, errUsage) {
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(2)
	}
	os.Exit(1)
}

func run(args []string, out io.Writer) error {
	if len(args) == 0 {
		return fmt.Errorf("no command: %w", errUsage)
	}
	path := os.Getenv("LIBRARY_DATA")
	if path == "" {
		path = "library.json"
	}
	st, err := store.OpenFile(path)
	if err != nil {
		return err
	}
	lib := catalog.New(st)

	cmd, rest := args[0], args[1:]
	switch cmd {
	case "add-book":
		if len(rest) < 4 {
			return fmt.Errorf("add-book needs 4 or more arguments: %w", errUsage)
		}
		copies, err := strconv.Atoi(rest[1])
		if err != nil {
			return fmt.Errorf("copies %q: %w", rest[1], err)
		}
		genre, err := catalog.ParseGenre(rest[2])
		if err != nil {
			return err
		}
		b := catalog.Book{ID: rest[0], Copies: copies, Genre: genre, Title: strings.Join(rest[3:], " ")}
		if err := lib.AddBook(b); err != nil {
			return err
		}
		fmt.Fprintf(out, "added %s %q\n", b.ID, b.Title)
	case "add-member":
		if len(rest) < 2 {
			return fmt.Errorf("add-member needs 2 or more arguments: %w", errUsage)
		}
		if err := lib.AddMember(catalog.Member{ID: rest[0], Name: strings.Join(rest[1:], " ")}); err != nil {
			return err
		}
		fmt.Fprintf(out, "added member %s\n", rest[0])
	case "borrow":
		if len(rest) != 2 {
			return fmt.Errorf("borrow needs 2 arguments: %w", errUsage)
		}
		due, err := lib.Borrow(rest[0], rest[1])
		if err != nil {
			return err
		}
		fmt.Fprintf(out, "due %s\n", due.Format("2006-01-02"))
	case "return":
		if len(rest) != 2 {
			return fmt.Errorf("return needs 2 arguments: %w", errUsage)
		}
		if err := lib.Return(rest[0], rest[1]); err != nil {
			return err
		}
		fmt.Fprintln(out, "returned")
	case "list":
		items, err := lib.List()
		if err != nil {
			return err
		}
		for _, it := range items {
			fmt.Fprintf(out, "%-6s %-30s %-9s %d/%d available\n",
				it.Book.ID, it.Book.Title, it.Book.Genre, it.Available, it.Book.Copies)
		}
	case "overdue":
		loans, err := lib.Overdue()
		if err != nil {
			return err
		}
		for _, ln := range loans {
			fmt.Fprintf(out, "%s borrowed by %s, due %s\n", ln.BookID, ln.MemberID, ln.Due.Format("2006-01-02"))
		}
	default:
		return fmt.Errorf("unknown command %q: %w", cmd, errUsage)
	}
	return nil
}
```

### Reference solution — `internal/catalog/catalog_test.go`

```go
package catalog_test

import (
	"errors"
	"testing"
	"time"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

func newLib(t *testing.T) *catalog.Library {
	t.Helper()
	fixed := time.Date(2026, 1, 1, 10, 0, 0, 0, time.UTC)
	lib := catalog.New(store.NewMemory()).WithClock(func() time.Time { return fixed })
	if err := lib.AddBook(catalog.Book{ID: "b1", Title: "Go", Copies: 1}); err != nil {
		t.Fatal(err)
	}
	if err := lib.AddMember(catalog.Member{ID: "m1", Name: "Asha"}); err != nil {
		t.Fatal(err)
	}
	return lib
}

func TestBorrowAndReturn(t *testing.T) {
	lib := newLib(t)
	due, err := lib.Borrow("b1", "m1")
	if err != nil {
		t.Fatal(err)
	}
	if want := time.Date(2026, 1, 15, 10, 0, 0, 0, time.UTC); !due.Equal(want) {
		t.Errorf("due = %v, want %v", due, want)
	}
	if _, err := lib.Borrow("b1", "m1"); !errors.Is(err, catalog.ErrNoCopies) {
		t.Errorf("second borrow: got %v, want ErrNoCopies", err)
	}
	if err := lib.Return("b1", "m1"); err != nil {
		t.Fatal(err)
	}
	if err := lib.Return("b1", "m1"); !errors.Is(err, catalog.ErrNotBorrowed) {
		t.Errorf("second return: got %v, want ErrNotBorrowed", err)
	}
}

func TestErrors(t *testing.T) {
	lib := newLib(t)
	if _, err := lib.Borrow("nope", "m1"); !errors.Is(err, catalog.ErrNotFound) {
		t.Errorf("unknown book: got %v", err)
	}
	if err := lib.AddBook(catalog.Book{ID: "b1", Title: "Again", Copies: 1}); !errors.Is(err, catalog.ErrAlreadyExists) {
		t.Errorf("duplicate: got %v", err)
	}
	err := lib.AddBook(catalog.Book{ID: "b2", Title: "X", Copies: 0})
	var ve *catalog.ValidationError
	if !errors.As(err, &ve) || ve.Field != "copies" {
		t.Errorf("zero copies: got %v", err)
	}
}

func TestGenre(t *testing.T) {
	if g, err := catalog.ParseGenre("Science"); err != nil || g != catalog.Science {
		t.Errorf("ParseGenre = %v, %v", g, err)
	}
	if s := catalog.Genre(42).String(); s != "Genre(42)" {
		t.Errorf("String() = %q", s)
	}
}
```

A real session:

```
$ library add-book b1 2 science The Go Programming Language
added b1 "The Go Programming Language"
$ library add-book b2 1 fiction Malgudi Days
added b2 "Malgudi Days"
$ library add-member m1 Asha Rao
added member m1
$ library borrow b2 m1
due 2026-11-29
$ library borrow b2 m1; echo $?
library: borrow "b2": all 1 copies are out: no copies available
1
$ library list
b2     Malgudi Days                   fiction   0/1 available
b1     The Go Programming Language    science   2/2 available
$ library fly; echo $?
library: unknown command "fly": bad usage
usage:
  ...
2
```

### Review checklist

- Does `catalog` import `store`? It must not. Draw the import graph.
- Is any error compared with `==` or matched by its text? Use `errors.Is` / `errors.As`.
- Can a caller corrupt store data through a returned slice? (Try it in a test.)
- Is the `Store` interface larger than what `catalog` calls?
- Are there typed-nil error returns (DT-147)?
- Is the JSON write atomic? What happens if the program is killed in the middle of `os.WriteFile` of the real file, without the rename trick?
- **Known limitation to discuss:** two `library` processes running at the same moment can each read the file, change it, and write it, losing one update. Fixing this needs file locking or a database — exactly the problem Chapter 9 solves with transactions.

### Extensions

1. Add an `iter.Seq[Loan]` method `LoansOf(memberID)` and use it in a new `member <id>` command.
2. Add a `history` command using a new `Event` enum and an append-only event list.
3. Replace `Store` with a generic `Repo[K comparable, V any]` for books and members. Is the code simpler or not? Decide and justify (P-27).

## Answers to the Chapter 3 prediction questions

**3.1 Q2.** (a) `6` (b) compile error: mismatched types Meters and float64 (c) `1000000000` — `D` has none of `Duration`'s methods (DT-137) (d) 2 nanoseconds.

**3.2 Q2.** Small = 1, Medium = 2, Large = 3; `Size(0)` prints `0`.

**3.3 Q2.** `1` (the method value copied `c` when it was created), then `51` (`inc` holds `&c`).

**3.5 Q2.** (a) `false`, and printing `err` shows `my` (b) `true` (c) `false true` (d) `false` — different dynamic types (`int` and `float64`).

**3.6 Q2.** `nil`, `integer 42`, `error: x`, `stringer: 1.0°C`, `other []int`.

**3.7 Q2.** It compiles; `x.Close()` is a compile error (`ambiguous selector x.Close`) unless the outer type declares its own `Close`.

**3.9 Q2.** `false` (different values, DT-158); `false` — `%v` formats the error into text, so the result is a brand-new error, not `io.EOF` (and even with `%w`, `==` would be false; only `errors.Is` sees through wrapping).

**3.10 Q2.** (a) `true` (b) `false` (c) `true` (d) `true`.

**3.11 Q2.** `C`, then the closure prints `boom`, then `A`. The program does not crash: the panic was recovered, and the function returns normally (with its result values as they were).

**3.12 Q2.** `import cycle not allowed`. Move the shared type to a new lower package both can import, or have `b` define an interface that `a`'s type satisfies.

**3.14 Q2.** (a) `7.5` — both untyped constants, so `T` is inferred as float64 (b) `"go"` — lower-case letters sort after upper-case (c) `-1`, because NaN never equals NaN (d) no: `+` is not allowed on `any`.

**3.16 Q2.** Prints `54`. If `Countdown` ignored `yield`'s false result and called it again, the program would panic: `range function continued iteration after function for loop body returned false` (DT-176).
