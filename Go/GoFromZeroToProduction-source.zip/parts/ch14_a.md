# Chapter 14 — Capstone: Production Routing Backend

*Goal: independently design, build, and operate a serious routing service.*

This chapter is different. Earlier chapters taught; this one asks you to **lead**. You will write a design document, build a routing service from OpenStreetMap data to a production deployment, prove its performance with load tests and profiles, make it observable and safe to operate, and defend it in a senior-level architecture review. Each unit gives you the requirements, the decisions you must make (with the trade-offs you now know how to weigh), a working starting point where it helps, and the acceptance criteria.

A complete, tested starting point exists: the Chapter 13 packages plus the `server` package and `routed` command in this chapter, which were built, tested (including hot reload under concurrent load), and load-tested while writing this book. Your capstone should go well beyond it.

**Capstone deliverables**

1. A design document (Unit 14.1) reviewed before you write most of the code.
2. A repository with: an ingestion command, a graph file format, the routing service, tests (unit, differential, integration, load), Dockerfile, CI, deployment manifests, dashboards and alerts as code.
3. A performance report (Unit 14.6) in the Chapter 10 format.
4. An operations runbook (Unit 14.7).
5. A recorded or written architecture review (Unit 14.8).

## Topic 14A — Design

## Unit 14.1 — Requirements and design document with trade-off decisions

**One-line summary:** Before building, write down what the system must do, how well, under what constraints, and how it will fail — and get it reviewed. A design document is a thinking tool first and a communication tool second.

### A design document template

1. **Context and goals** — the problem, who has it, what success looks like.
2. **Non-goals** — what you deliberately will not do (turn-by-turn voice guidance, public transport, live traffic in version 1).
3. **Requirements** — functional (route between two coordinates for cars; alternative routes later; a distance/time matrix later) and non-functional with numbers (Unit 12.10):
   - Coverage: one metropolitan region (e.g. Pune: ~1–2 million graph nodes after contraction of shape points).
   - Latency: p99 < 50 ms per route at the target load, measured at the server.
   - Throughput: 500 routes/s sustained per instance; horizontal scaling to 5,000/s.
   - Availability: 99.9%; data updates weekly without downtime.
   - Correctness: routes optimal for the cost model (verified by differential tests); snapping within 500 m or a clear error.
4. **Estimates** — graph size in memory (bytes per node and edge × counts, from Unit 13.4's 3.3 MB for 90,000 nodes and 189,370 edges, about 37 bytes per node-with-edges), preprocessing time, request bandwidth (polyline sizes), instance counts.
5. **API** — endpoints, parameters, responses, errors, versioning (Unit 8.6).
6. **Architecture** — components and data flow (ingestion → graph file → service instances behind a load balancer); diagrams.
7. **Key decisions with alternatives considered** — the heart of the document. For each: options, trade-offs, decision, and what would make you revisit it.
8. **Failure modes** — for every component and dependency.
9. **Observability, security, rollout, and testing plans.**
10. **Open questions and risks.**

### Decisions you must make and justify

| Decision | Options | Trade-offs to discuss |
| --- | --- | --- |
| Routing algorithm | A* with planar heuristic; ALT; contraction hierarchies | query speed vs preprocessing time and memory vs ease of updating weights (Unit 13.7) |
| Graph model | node-based; edge-based (turn restrictions) | correctness for real roads vs ~3× size |
| Data format | build at startup from PBF; custom binary file; memory-mapped file | startup time, deploy simplicity, `unsafe` risk (Unit 13.8) |
| Protocol | REST/JSON; gRPC | clients, tooling, streaming (Unit 8.8) |
| Scaling | replicate the full graph per instance; shard by region | simplicity vs memory; cross-region routes |
| Caching | none; cache frequent origin–destination pairs | hit rate on random queries is low — measure before adding; if added, follow P-36 |
| Updates | restart with new data; hot reload; blue-green instances | availability vs memory during the swap |

A good design document records *why* — six months later, the team needs to know whether the reason for a decision still holds.

### Acceptance criteria

The document fits in about 6–10 pages, states every requirement as a measurable number, lists at least two alternatives for each major decision, and contains a failure-mode table covering at least: bad input, oversized input, corrupt data file, out-of-memory, overload, slow clients, a bad deploy, and a dependency outage.

### Mastery check

1. **Write.** Your capstone design document, then ask someone (a colleague, a study partner) to review it with the Unit 14.8 questions before you build.

## Topic 14B — Build

## Unit 14.2 — Ingestion pipeline and storage

**One-line summary:** Turn a raw OSM extract into a validated, versioned, binary graph file in a reproducible batch job, separate from the service. The service only ever loads finished, checked files.

### The pipeline

```
city.osm.pbf ──read (2 passes, parallel PBF blocks)──▶ roads + used nodes
             ──build──▶ CSR graph (+ reverse, + spatial index data)
             ──contract shape points (DT-288), reorder nodes (Unit 13.8)
             ──preprocess (ALT tables or CH shortcuts, Unit 13.7)
             ──validate──▶ graph-2026-11-15.bin (header: magic, version, counts, source hash, CRC)
```

Requirements:

- **Reproducible:** same input file and code version → byte-identical output (sort everything; no map iteration order in outputs — P-21).
- **Validated before publishing:** connectivity (size of the largest strongly connected component; flag islands), sanity of speeds and coordinates, and a **golden set** of routes whose durations must stay within a tolerance of the previous version (a regression test for data, not just code).
- **Versioned and immutable:** files are never modified in place; the service is told which version to load.
- **Streamed and bounded:** memory proportional to the road network, not to the raw file (Units 5.1, 13.3).

### Starting point

`gencity` produces test inputs; `osm.Read` + `graph.Build` + `Reverse` build the graph. Your work: PBF input, shape-point contraction, node reordering, a binary format (Unit 13.8's exercise), validation, and a CLI (`buildgraph -in city.osm.pbf -out graph.bin`).

### Acceptance criteria

The pipeline runs in CI on a small extract, produces identical files on repeated runs (`sha256sum` equal), rejects a deliberately corrupted input with a clear error, and its golden-route check fails when you change a speed default.

## Unit 14.3 — Graph preprocessing and fast routing

**One-line summary:** Choose and implement the routing speed-up your requirements need, validated against plain Dijkstra as an oracle on thousands of random pairs.

### Requirements

- At least A* with a cheap admissible heuristic (planar coordinates precomputed, Unit 13.6 Extension 1).
- Stretch: ALT or contraction hierarchies (Unit 13.7).
- The differential test of Chapter 13 extended to 10,000 random pairs, including unreachable pairs and pairs on one-way streets, run in CI.
- Benchmarks reporting time and settled nodes per algorithm on the target region (Unit 10.1 rigour, `benchstat` comparisons for every optimisation).

### Starting point

`route.Router` with Dijkstra, A*, bidirectional Dijkstra, the stamped O(1) reset, and the specialised heap; measured on the 90,000-node synthetic city at 4.56 ms / 2.75 ms / 3.34 ms per query.

### Acceptance criteria

Zero disagreements with the oracle; the chosen algorithm meets the latency requirement for single queries with headroom (aim for p99 at least 3× below the target, because load adds queueing); every performance claim backed by benchstat output.

## Unit 14.4 — Service API

**One-line summary:** Expose routing over HTTP (and optionally gRPC) with strict input validation, snapping, clear errors, compact responses, and safe concurrency.

### The starting point: `server` package

```go
// Package server answers routing queries over HTTP and can swap in a new
// road graph without downtime.
package server

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"example.com/routing/geo"
	"example.com/routing/graph"
	"example.com/routing/osm"
	"example.com/routing/route"
)

// Engine is an immutable, fully built routing dataset.
type Engine struct {
	G, Rev  *graph.Graph
	Index   *graph.Index
	Loaded  time.Time
	Source  string
	routers sync.Pool // *route.Router: not concurrency-safe, so one per request
}

// Load builds an Engine from an OSM XML file.
func Load(path string) (*Engine, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	d, err := osm.Read(bufio.NewReaderSize(f, 1<<20))
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	g, err := graph.Build(d)
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	if g.NumNodes() == 0 {
		return nil, fmt.Errorf("%s: no roads", path)
	}
	e := &Engine{G: g, Rev: g.Reverse(), Index: graph.NewIndex(g, 0.002), Loaded: time.Now(), Source: path}
	e.routers.New = func() any { return route.New(e.G, e.Rev) }
	return e, nil
}

type Server struct {
	engine  atomic.Pointer[Engine] // swapped atomically on reload (Unit 7.6)
	log     *slog.Logger
	maxSnap float64 // metres: farther from any road is an error
}

func New(e *Engine, log *slog.Logger) *Server {
	s := &Server{log: log, maxSnap: 500}
	s.engine.Store(e)
	return s
}

// Swap installs a new engine. In-flight requests finish on the old one,
// which the garbage collector frees when they are done.
func (s *Server) Swap(e *Engine) { s.engine.Store(e) }

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /route", s.route)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		e := s.engine.Load()
		fmt.Fprintf(w, "ok nodes=%d edges=%d loaded=%s\n", e.G.NumNodes(), e.G.NumEdges(), e.Loaded.Format(time.RFC3339))
	})
	return mux
}

type routeResponse struct {
	DurationS    float64 `json:"duration_s"`
	DistanceM    float64 `json:"distance_m"`
	Polyline     string  `json:"polyline"`
	SnapFromM    float64 `json:"snap_from_m"`
	SnapToM      float64 `json:"snap_to_m"`
	SettledNodes int     `json:"settled_nodes"`
	Algorithm    string  `json:"algorithm"`
}

func (s *Server) route(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	from, err1 := parsePoint(q.Get("from"))
	to, err2 := parsePoint(q.Get("to"))
	if err := errors.Join(err1, err2); err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	algo := q.Get("algo")
	if algo == "" {
		algo = "astar"
	}
	e := s.engine.Load() // one consistent dataset for the whole request
	src, ds := e.Index.Nearest(from)
	dst, dd := e.Index.Nearest(to)
	if ds > s.maxSnap || dd > s.maxSnap {
		httpError(w, http.StatusUnprocessableEntity, fmt.Sprintf("point is more than %.0f m from any road", s.maxSnap))
		return
	}
	rt := e.routers.Get().(*route.Router)
	defer e.routers.Put(rt)
	var res route.Result
	var err error
	switch algo {
	case "dijkstra":
		res, err = rt.Dijkstra(src, dst)
	case "astar":
		res, err = rt.AStar(src, dst)
	case "bidirectional":
		res, err = rt.Bidirectional(src, dst)
	default:
		httpError(w, http.StatusBadRequest, "algo must be dijkstra, astar, or bidirectional")
		return
	}
	if errors.Is(err, route.ErrNoRoute) {
		httpError(w, http.StatusNotFound, "no route between these points")
		return
	}
	pts := route.Geometry(e.G, res.Nodes)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(routeResponse{
		DurationS: float64(res.DurationMs) / 1000, DistanceM: route.LengthM(e.G, res.Nodes),
		Polyline: geo.EncodePolyline(pts), SnapFromM: ds, SnapToM: dd,
		SettledNodes: res.Settled, Algorithm: algo,
	})
}

func parsePoint(s string) (geo.Point, error) {
	a, b, ok := strings.Cut(s, ",")
	if !ok {
		return geo.Point{}, fmt.Errorf("point %q must be lat,lon", s)
	}
	lat, err1 := strconv.ParseFloat(strings.TrimSpace(a), 64)
	lon, err2 := strconv.ParseFloat(strings.TrimSpace(b), 64)
	if err1 != nil || err2 != nil || lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return geo.Point{}, fmt.Errorf("point %q is not a valid lat,lon", s)
	}
	return geo.Point{Lat: lat, Lon: lon}, nil
}

func httpError(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}
```

Design points to recognise:

- **Immutable engine + `atomic.Pointer`:** a request loads the pointer **once** and uses that engine for the whole request, so a concurrent reload can never mix two datasets in one answer.
- **A `sync.Pool` of routers per engine:** routers hold large scratch arrays and are not concurrency-safe; pooling avoids allocating megabytes per request (Unit 7.11). The pool belongs to the engine, so routers sized for an old graph are never used with a new one.
- **Validation** of every parameter (`errors.Join` reports both bad points at once), **422** for "well-formed but cannot be served" (too far from roads), **404** for "no route".

A real response for a corner-to-corner route across the synthetic city (`from=18.4512,73.8021&to=18.7051,74.0752`), with the 1,738-character polyline shortened here:

```
{"duration_s":3462.631,"distance_m":57356.882265613545,"polyline":"euroBwlmaMClDxD?KeDJ_EK{DTqEQmD…",
 "snap_from_m":39.90819003015627,"snap_to_m":42.7891761858107,"settled_nodes":80274,"algorithm":"astar"}
```

Two things to notice. A route across the whole map settles 80,274 of 90,000 nodes even with A*: the heuristic helps most for short and medium routes, and long routes are where preprocessing (Unit 13.7) pays off. And `distance_m` has fourteen meaningless decimal places — rounding it to whole metres is a small, real improvement to the API.

Your work: API versioning (`/v1/route`), a request size and rate limit (Unit 11.6 `guard`), response field documentation, a `POST /v1/matrix` endpoint (many-to-many durations, a common product need; think about its cost: n×m routes, or one-to-many Dijkstra runs), optional gRPC, and caching only if measurements justify it.

### Acceptance criteria

Every parameter validated with tests for each error; the API documented (OpenAPI or a Markdown reference); no shared mutable state without synchronisation (`go test -race` with concurrent requests).

## Unit 14.5 — Hot reload of graph data and failure handling

**One-line summary:** Replace the graph without downtime and without risk: build the new engine in the background, validate it, swap atomically, keep serving the old one if anything fails — and plan for every other failure the design document lists.

### The starting point

`routed` reloads on `SIGHUP`:

```go
// SIGHUP: rebuild from the file in the background, then swap atomically.
// A bad file is logged and ignored: the old graph keeps serving.
hup := make(chan os.Signal, 1)
signal.Notify(hup, syscall.SIGHUP)
go func() {
	for range hup {
		e, err := server.Load(*path)
		if err != nil {
			log.Error("reload failed; keeping current graph", "err", err)
			continue
		}
		s.Swap(e)
		log.Info("graph reloaded", "nodes", e.G.NumNodes())
	}
}()
```

The test proves the property that matters: **400 requests from 8 concurrent clients all succeed while the graph is swapped** from a 1,600-node to a 3,600-node city mid-flight:

```go
// Hot reload under load: requests keep succeeding while the graph is swapped.
bigger, err := Load(city(t, "60"))
if err != nil {
	t.Fatal(err)
}
var wg sync.WaitGroup
for range 8 {
	wg.Add(1)
	go func() {
		defer wg.Done()
		for range 50 {
			if code, _ := get(q); code != 200 {
				t.Errorf("status %d during reload", code)
				return
			}
		}
	}()
}
s.Swap(bigger)
wg.Wait()
```

### Failure handling to implement

| Failure | Required behaviour |
| --- | --- |
| New data file corrupt or fails validation | keep serving the old graph; alert; expose the loaded version in `/healthz` and metrics |
| Not enough memory for two graphs during the swap | plan capacity (old + new must fit; `GOMEMLIMIT`, Unit 10.6), or do blue-green instance replacement instead of in-process reload |
| Overload | bounded concurrency per instance (semaphore, Unit 7.10), 503 with `Retry-After` beyond it, autoscaling on CPU or in-flight requests |
| Pathological queries (very long routes) | a per-request deadline enforced inside the search loop (check `ctx.Err()` every N settled nodes) |
| Slow clients | server timeouts (Unit 8.4) |
| Bad deploy | readiness gates, canary, automatic rollback on error-rate or latency regression (Unit 11.7) |
| Instance crash | stateless instances; the load balancer routes around it; restarts load the graph quickly (memory-mapped files make this seconds instead of minutes) |

### Acceptance criteria

A chaos test suite: corrupt file reload (old graph keeps serving), reload under load (no errors), overload (503s, no crash, latency of admitted requests within target), a request deadline that stops a cross-region search. All automated.

## Topic 14C — Prove and operate

## Unit 14.6 — Load testing, profiling, and optimisation

**One-line summary:** Find the service's real capacity and its bottleneck with realistic load, then optimise with the Chapter 10 loop until the requirements are met with headroom. Report it like a professional.

### A load generator

```go
// Command loadgen sends random route requests with a fixed number of
// concurrent workers for a fixed time and reports throughput and latency
// percentiles.
//
//	loadgen -url http://localhost:8090 -c 8 -d 20s
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"math/rand/v2"
	"net/http"
	"slices"
	"sync"
	"time"
)

func main() {
	base := flag.String("url", "http://localhost:8090", "server")
	conc := flag.Int("c", 8, "concurrent workers")
	dur := flag.Duration("d", 10*time.Second, "test duration")
	algo := flag.String("algo", "astar", "algorithm")
	flag.Parse()

	ctx, cancel := context.WithTimeout(context.Background(), *dur)
	defer cancel()
	client := &http.Client{Timeout: 5 * time.Second,
		Transport: &http.Transport{MaxIdleConnsPerHost: *conc}} // DT-246: reuse connections
	var mu sync.Mutex
	var lat []time.Duration
	errors := 0
	var wg sync.WaitGroup
	for w := range *conc {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := rand.New(rand.NewPCG(uint64(w), 99))
			for ctx.Err() == nil {
				// random points inside the synthetic city's bounding box
				q := fmt.Sprintf("%s/route?from=%.5f,%.5f&to=%.5f,%.5f&algo=%s", *base,
					18.45+r.Float64()*0.26, 73.80+r.Float64()*0.28,
					18.45+r.Float64()*0.26, 73.80+r.Float64()*0.28, *algo)
				start := time.Now()
				resp, err := client.Get(q)
				if err == nil {
					io.Copy(io.Discard, resp.Body)
					resp.Body.Close()
				}
				d := time.Since(start)
				mu.Lock()
				if err != nil || resp.StatusCode >= 500 {
					errors++
				} else {
					lat = append(lat, d)
				}
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	slices.Sort(lat)
	p := func(q float64) time.Duration { return lat[int(q*float64(len(lat)-1))].Round(10 * time.Microsecond) }
	fmt.Printf("%s, %d workers, %v: %d requests (%.0f/s), errors %d, p50 %v, p95 %v, p99 %v, max %v\n",
		*algo, *conc, *dur, len(lat), float64(len(lat))/dur.Seconds(), errors, p(0.50), p(0.95), p(0.99), lat[len(lat)-1].Round(10*time.Microsecond))
}
```

This is a **closed-loop** generator: each worker waits for a response before sending the next request, so it measures capacity at a given concurrency. Real users form an **open loop** (requests arrive regardless of how fast you answer), which closed-loop tests can under-represent at overload ("coordinated omission"); tools such as `vegeta` (constant request rate) or `k6` model open loops. Use both.

### Real results for the starting point

The synthetic 90,000-node city, `routed` and `loadgen` on the same 2-vCPU machine (so the load generator steals CPU from the server — a real test uses separate machines), 4 workers, 10 seconds:

```
dijkstra, 4 workers, 10s: 4266 requests (427/s), errors 0, p50 6.98ms, p95 27.4ms, p99 38.47ms, max 98.9ms
astar,    4 workers, 10s: 7236 requests (724/s), errors 0, p50 2.85ms, p95 20.84ms, p99 31.33ms, max 79.62ms
```

How to read it: A* serves 70% more requests per second at a lower median; but p95 and p99 are an order of magnitude above the median — random origin–destination pairs vary from a few blocks to across the city, and queueing on 2 cores amplifies the long ones. The single-query benchmark (2.75 ms average for A*) does not predict the p99 under load: **only a load test does**.

### What to do next (your capstone work)

1. Profile under load (`/debug/pprof/profile`, Unit 10.2). Expect the haversine heuristic, heap operations, JSON encoding of long polylines, and `Nearest` to be visible.
2. Apply the Chapter 13 extensions (cheap heuristic, node reordering) and, if needed, ALT or CH; measure each with benchstat and with the load test.
3. Test with realistic query distributions (most real routes are short; use a distribution from logs or a gravity model), at the target rate, for long enough to see GC and tail behaviour (minutes, not seconds).
4. Find the knee: the request rate at which p99 starts to rise sharply. Set autoscaling and load-shedding thresholds below it.

### Acceptance criteria

A performance report (the Chapter 10 project's format) showing the requirement met — p99 under target at target load — with profiles before and after each optimisation, the open-loop results, and the capacity knee per instance.

## Unit 14.7 — Observability, deployment, and scalability

**One-line summary:** Operate the service like the Chapter 11 shortener — structured logs, RED metrics, traces, health checks, a secure container, CI/CD, Kubernetes — plus routing-specific signals and a scaling plan.

### Routing-specific observability

- Metrics: route latency histogram per algorithm; **settled nodes** histogram (work per query — a regression in data or code shows here before latency does); snapping distance histogram; error counts by type (`no_route`, `too_far`); loaded graph version, node and edge counts, load time; reload success/failure counter.
- Logs: one line per request with origin and destination **rounded** (precise coordinates are personal data — DT-293), duration, settled nodes, request ID.
- Traces: spans for snapping, search, and response encoding.
- Dashboards and alerts as code (Prometheus rules, Grafana JSON) in the repository.

### Deployment

The Chapter 11 Dockerfile, CI, and Kubernetes manifests apply directly, with two changes: the graph file is mounted from a volume or downloaded at startup (not baked into the image, so data and code deploy independently), and readiness stays false until the graph is loaded (startup can take seconds or minutes; use a Kubernetes `startupProbe` so liveness does not kill a slowly loading pod).

### Scalability

- **Vertical:** the graph is read-only and shared by all goroutines; throughput scales with cores until memory bandwidth limits it.
- **Horizontal:** stateless instances behind a load balancer; each holds a full copy of the regional graph.
- **Beyond one region's memory:** shard by region (a route between regions needs either an overlay graph of boundary nodes or a coarser long-distance graph) — say what you would do, even if you do not build it.

### The runbook

For each alert: what it means, how to confirm it, how to mitigate (roll back, scale out, shed load, revert data), how to escalate. Include: "graph reload failed", "p99 latency above SLO", "error rate above 1%", "memory near limit", "settled nodes per query doubled". Practise each once.

### Acceptance criteria

Dashboards that answer "is it healthy, is it fast, is it correct, what data version is it running" at a glance; alerts tied to the SLO; a runbook entry for every alert; a deployment that survives a pod being killed under load with no user-visible errors.

### Deep & Tricky

**DT-293. Location data is personal data.** *(Privacy and law)* Origins and destinations reveal homes, workplaces, hospitals, and places of worship. Logging exact coordinates with user identifiers creates a sensitive dataset subject to privacy law (India's DPDP Act, the EU's GDPR). Round or truncate coordinates in logs, avoid storing request histories by default, set retention limits, and restrict access.

## Unit 14.8 — Final senior-level architecture review

**One-line summary:** Present the system and answer the questions a principal engineer would ask. Being able to defend decisions with evidence — and to say clearly what you would change — is the final skill this book teaches.

### Prepare

A 20-minute walkthrough: the problem and requirements, the architecture, three key decisions with alternatives and evidence, the performance report, the failure-mode table, the operational story, and what you would do with another month.

### Questions to be ready for

**Correctness**
- How do you know your routes are optimal? What is your oracle, how many cases does it check, and what classes of bug would it miss?
- What happens with one-way streets, turn restrictions, ferries, and closed roads? Which do you ignore, and what is the user impact?
- How do you detect a bad data import before users see it?

**Performance**
- What is the p99 at target load, measured how, on what hardware, with what query distribution? Where is the knee?
- What does the CPU profile look like at peak? What is the next optimisation and its expected gain?
- How much memory does an instance need, and what happens during a reload?

**Reliability and operations**
- Walk me through a node failure, a bad deploy, a corrupt data file, and a 10× traffic spike.
- How long does a new instance take to become ready? What would make it faster?
- Which alerts would wake someone up, and are they all actionable?

**Design judgement**
- Why this algorithm and not contraction hierarchies (or why CH and not A*)? What would make you change your mind?
- Where did you choose simplicity over performance, and how will you know when that choice stops being right?
- What would you do differently if you started again?

**Security and privacy**
- What input can make the service misbehave or consume excessive resources? How is it bounded?
- What data do you log and keep, and why?

### Acceptance criteria

You can answer every question above with evidence (a test, a measurement, a design-document section) or with a clear "we have not done this; here is the risk and the plan". The second kind of answer, given honestly, is a mark of seniority — not a failure.

## Where to go from here

You started this book with the difference between compile time and run time and ended designing a production routing system. Along the way you built a habit that matters more than any single fact: **do not guess — measure, test, and read the evidence.** Every chapter's "notes from development" — the guessed test values that were wrong, the race that the tests did not catch, the `go vet` warnings that found real bugs, the PGO run that changed nothing — are the normal texture of professional work. Expect them, and build the checks that catch them.

Ways to keep growing:

- **Read Go's source and proposals** (Unit 5.11): `go.dev/issue`, the release notes of each new version, and the design documents behind generics, iterators, and the memory model.
- **Contribute** to an open-source Go project: a bug fix with a good test teaches more than many tutorials.
- **Go deeper in a direction** this book opened: databases (*Designing Data-Intensive Applications*), distributed systems (the Raft paper, Jepsen analyses), performance (the Go runtime source, *Systems Performance*), routing (the contraction-hierarchies and customisable-route-planning papers).
- **Teach**: explaining a concept to someone else — as this book's original notes were written, one unit at a time — is the fastest way to find what you have not yet understood.
