| Word | Simple meaning |
| --- | --- |
| Address | The number of one byte-sized box in memory |
| Binary | Base-2 number system; only digits 0 and 1 |
| Binary / executable | A file containing machine code that the computer can run directly |
| Bit | One 0-or-1 value; the smallest unit of data |
| Byte | 8 bits; can hold 256 different values (0 to 255) |
| Compile error | ANY reason the compiler refuses to build; no program is produced |
| Compile time | The moment the compiler checks and translates code, before running |
| Compiler | A program that translates your whole source code into machine code before it runs |
| CPU | The chip that executes instructions, one tiny step at a time, very fast |
| ELF / PE / Mach-O | Executable file formats: ELF for Linux, PE (.exe) for Windows, Mach-O for macOS |
| Endianness | The order in which the bytes of a multi-byte number are stored |
| Exit code | A number a finished process gives to the OS; 0 = success |
| GOARCH | Go setting that picks the target CPU type, e.g. amd64, arm64 |
| GOOS | Go setting that picks the target operating system, e.g. linux, windows, darwin |
| Hexadecimal (hex) | Base-16 system, digits 0-9 and A-F; one hex digit = 4 bits |
| IEEE 754 | The worldwide standard for how float numbers are stored and calculated |
| Inf | Special float value meaning infinity (+Inf or -Inf) |
| Interpreter | A program that reads and runs source code directly, step by step, while running |
| Literal | A value written directly in code, like `42`, `0xFF`, or `"hi"` |
| Machine code | Instructions in the CPU's own language (just bytes) |
| NaN | "Not a Number": special float value for undefined results like 0.0/0.0 |
| Octal | Base-8 system; Go literals start with `0o` (or an old-style leading `0`) |
| Panic | Go's name for a serious run-time error that stops the program unless handled |
| Process | A program that is currently running, with its own memory given by the OS |
| RAM | The computer's main working memory; fast, and cleared when power goes off |
| Run time | The period when the program is actually executing |
| Source code | The human-readable text you write, e.g. main.go |
| Stack trace | The list of function calls printed when a panic happens, showing where it failed |
| Syntax error | Grammar of the code is broken (missing bracket, brace, etc.); one kind of compile error |
| System call | A request from a program to the OS, e.g. "write this text to the screen" |
| Type error | Code has correct grammar but mixes types wrongly, e.g. string + int |
