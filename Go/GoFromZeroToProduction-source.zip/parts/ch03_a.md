# Chapter 3 — Types, Methods, Interfaces, Errors, Packages, Generics

*Goal: organise programs with clean abstractions and clear boundaries.*

Chapters 1 and 2 taught the pieces. This chapter teaches how to *organise* them: your own types with behaviour (methods), contracts between parts of a program (interfaces), composition instead of inheritance (embedding), failure as ordinary values (errors), code in packages and modules, and code that works for many types (generics and iterators). These are the tools senior Go engineers use to keep a 200,000-line codebase understandable.

Go's approach is deliberately small. There are no classes, no inheritance, no exceptions, no annotations, no constructors as a language feature. Each of those absences is a design decision, and you will learn what replaces each one and why.

**What you will be able to do after this chapter**

- Define named types and enums with methods, and choose value or pointer receivers correctly.
- Design small interfaces, explain interface values (and the nil-interface trap), and use type switches.
- Handle errors like a professional: wrap with context, inspect with `errors.Is` / `errors.As`, and know when to panic.
- Split a program into packages with a clean public API, and manage dependencies with modules.
- Write generic functions and types, and your own iterators — and know when *not* to.

## Topic 3A — Your own types

## Unit 3.1 — Named types

**One-line summary:** `type Celsius float64` creates a brand-new type with the same underlying representation as `float64` but a different identity: the compiler will not mix it with `float64` or with `Fahrenheit` unless you convert explicitly. Only named types defined in your package can have methods.

**Mental model — the same steel, different moulds.** Two containers made from the same steel (the **underlying type**) are still different products if they come from different moulds (different **named types**): a milk can and a petrol can. You can melt one and recast it as the other (a **conversion**), but you cannot pour petrol into the milk can by accident.

### Type definitions

```go
type Celsius float64
type Fahrenheit float64
type UserID int64
type Path []string

func CToF(c Celsius) Fahrenheit { return Fahrenheit(c*9/5 + 32) }

var t Celsius = 36.6
var f Fahrenheit = CToF(t) // OK
// f = t                   // compile error: cannot use t (variable of type Celsius) as Fahrenheit value
f = Fahrenheit(t)          // compiles — but is semantically wrong! Conversion only changes the label.
```

- The **underlying type** of `Celsius` is `float64`. Operators that work on the underlying type work on the named type: `t + 1`, `t * 2`, `t < 40`.
- Arithmetic between two `Celsius` values gives a `Celsius`. Between `Celsius` and `float64` *variables*: type error. Untyped constants adapt as usual (Unit 1.2).
- **Conversion** `T(x)` is allowed between types with the same underlying type. It never changes bits, so it cannot change meaning — `Fahrenheit(t)` of 36.6 °C is 36.6 °F, which is wrong. Use functions like `CToF` for real unit changes.

Named types catch whole classes of bugs at compile time: passing a `UserID` where an `OrderID` is expected, mixing metres and feet, or seconds and milliseconds (the standard library's `time.Duration` is `type Duration int64`).

### Type aliases

```go
type MyByte = byte // an ALIAS: MyByte and byte are the SAME type
```

An alias (note the `=`) is just a second name; it creates no new type and adds no type safety. Aliases exist mainly for gradual refactoring (moving a type between packages without breaking callers). `byte` = `uint8` and `rune` = `int32` are aliases (DT-15), and `any` = `interface{}`. Since Go 1.24, aliases may have type parameters (`type Set[T comparable] = map[T]struct{}`).

### Defined types vs type literals

`[]string`, `map[string]int`, `func(int) bool` are **type literals** (unnamed types). A value of an unnamed type can be assigned to a variable of a named type with the same underlying type without conversion:

```go
type Path []string
var p Path = []string{"usr", "local"} // OK: []string is unnamed
var q []string = p                    // OK too: one side is unnamed
```

This is why `sort.Sort(sort.StringSlice(names))` and `http.HandlerFunc(f)` work smoothly.

### Methods need a defined type in your package

You can declare methods only on types defined in the same package (Unit 3.3). You cannot add a method to `int` or to `time.Time`; you can define `type Celsius float64` and add methods to that.

### Deep & Tricky

**DT-137. A named type does not inherit the methods of its underlying named type.** *(Guarantee)* `type MyDuration time.Duration` has the *representation* of `time.Duration` but **none** of its methods: `MyDuration(5).String()` does not compile. (The method set of an *embedded* type is promoted — Unit 3.7 — but a type definition is not embedding.) An alias, by contrast, keeps everything, because it *is* the same type.

**DT-138. Typed constants of a named type give you compile-time checked "units".** *(Guarantee)* `time.Second` is a constant of type `time.Duration`. `time.Sleep(2)` compiles (untyped 2 becomes 2 nanoseconds!) but `time.Sleep(n)` with an `int` variable does not; you must write `time.Duration(n) * time.Second`. That bit of friction prevents seconds-vs-nanoseconds bugs everywhere except with bare constants, which is why `time.Sleep(2)` is a classic mistake.

### Common mistakes

- Using conversion to change units (`Fahrenheit(c)`).
- `time.Sleep(5)` meaning 5 seconds (it is 5 ns).
- Expecting a defined type to keep the methods of the type it was defined from.

### Mastery check

1. **Explain.** What is the difference between `type A = int` and `type A int`? Give a reason to use each.
2. **Predict.** (a) `type Meters float64; var m Meters = 3; fmt.Println(m * 2)` (b) `var f float64 = 1; m = m + f` (c) `type D time.Duration; fmt.Println(D(time.Second))` (d) `time.Sleep(2)` — how long?
3. **Write.** Types `Rupees` and `Paise` (int64) with conversion functions, and show at least one bug that the compiler now prevents.

## Unit 3.2 — Enums in Go

**One-line summary:** Go has no `enum` keyword. The idiom is a named integer type plus a `const` block with `iota`, plus a `String()` method so values print as names. You must handle invalid values yourself.

### The idiom

```go
type Weekday int

const (
	Sunday Weekday = iota // 0
	Monday                // 1, type Weekday
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)

func (d Weekday) String() string {
	names := [...]string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}
	if d < 0 || int(d) >= len(names) {
		return fmt.Sprintf("Weekday(%d)", int(d))
	}
	return names[d]
}

fmt.Println(Tuesday)          // Tuesday   — fmt calls String() automatically (Unit 3.4)
fmt.Printf("%d\n", Tuesday)   // 2
```

Repeating an expression in a `const` block also repeats its *type*, so every constant is a `Weekday`. That gives type safety: a function `func schedule(d Weekday)` will not accept a stray `int` variable.

### Make the zero value mean "unknown"

Every variable starts at its zero value (DT-43). If 0 is a real choice (`Sunday`), you cannot tell "deliberately Sunday" from "forgot to set it". Common fix:

```go
type Status int

const (
	StatusUnknown Status = iota // zero value: not set
	StatusActive
	StatusSuspended
	StatusClosed
)
```

### Invalid values are possible

Nothing stops `Status(42)` or a value decoded from a database or JSON. Defend at the edges:

```go
func (s Status) Valid() bool { return s > StatusUnknown && s <= StatusClosed }

func ParseStatus(text string) (Status, error) { ... } // the only way in from outside
```

A `switch` over an enum should have a `default` that handles (or reports) unexpected values. The `exhaustive` linter checks that every named constant appears in a switch.

### Generating `String()` with `stringer`

Writing name tables by hand is error-prone when constants change. The `stringer` tool generates them:

```go
//go:generate go run golang.org/x/tools/cmd/stringer -type=Status
```

`go generate ./...` then writes `status_string.go`. The generated code even includes a compile-time check that breaks the build if the constants change without regenerating.

### Bit-flag enums

When values can combine, use `1 << iota` (Unit 1.4, P-7) on a named type:

```go
type Perm uint8

const (
	PermRead Perm = 1 << iota
	PermWrite
	PermExec
)

func (p Perm) Has(q Perm) bool { return p&q == q }
```

### Deep & Tricky

**DT-139. `%v` on a type with a `String()` method that formats itself with `%v` recurses forever.** *(fmt behaviour)* `func (s Status) String() string { return fmt.Sprintf("%v", s) }` calls itself through fmt until the stack overflows (`fatal error: stack overflow`). Inside `String`, convert to the underlying type first: `fmt.Sprintf("Status(%d)", int(s))`. `go vet` catches the most direct form of this.

**DT-140. Untyped constants still sneak through.** *(Guarantee)* With `func schedule(d Weekday)`, the call `schedule(42)` compiles, because 42 is an untyped constant representable as `Weekday`. Only *variables* of other types are rejected. Validation at run time is still required.

### Mastery check

1. **Explain.** Why should the zero value of an enum usually mean "unknown"? What bug does it prevent?
2. **Predict.** `type Size int; const ( Small Size = iota + 1; Medium; Large )` — values? `fmt.Println(Size(0))` without a `String` method?
3. **Write.** A `Priority` enum (Low, Medium, High, Critical) with `String`, `ParsePriority` (case-insensitive), and `Valid`; a test that round-trips every value through `String` and `ParsePriority`.

## Topic 3B — Methods and interfaces

## Unit 3.3 — Methods

**One-line summary:** A method is a function with a **receiver**: `func (a Account) Balance() int64`. A value receiver works on a copy; a pointer receiver works on the original. Which methods a type "has" (its **method set**) depends on whether you hold a value or a pointer, and that decides which interfaces it satisfies.

**Mental model — a form vs a pointer to the form.** A value-receiver method is handed a photocopy of the form: it can read everything, but scribbles on the copy are lost. A pointer-receiver method is handed the address of the original form: its changes stick.

### Declaring methods

```go
type Account struct {
	owner   string
	balance int64 // paise
}

func (a Account) Balance() int64 { return a.balance }   // value receiver: reads a copy

func (a *Account) Deposit(amt int64) {                  // pointer receiver: changes the original
	a.balance += amt
}

acc := Account{owner: "Asha"}
acc.Deposit(500)            // Go automatically takes &acc because acc is addressable
fmt.Println(acc.Balance())  // 500
```

A method is just a function whose first parameter is written before the name. In fact `acc.Deposit(500)` is the same call as `(*Account).Deposit(&acc, 500)`.

### Value or pointer receiver?

Use a **pointer receiver** when:

- the method modifies the receiver;
- the type contains something that must not be copied (`sync.Mutex`, DT-136);
- the struct is large and copying it on every call is wasteful;
- for consistency: **if any method needs a pointer receiver, give all methods pointer receivers** (P-22).

Use a **value receiver** for small, immutable-feeling types (`time.Time`, `Celsius`, `Point`), where copies are cheap and safe, and for maps, functions, and channels (already reference-like).

### Automatic `&` and `*` — and where it fails

Go inserts `&` or `*` for you when calling methods:

- `v.PtrMethod()` becomes `(&v).PtrMethod()` — **only if `v` is addressable** (a variable, a field of an addressable struct, a slice element, `*p`).
- `p.ValueMethod()` becomes `(*p).ValueMethod()` — always allowed for a pointer `p`.

Non-addressable values cannot call pointer methods:

```go
m := map[string]Account{"a": {}}
m["a"].Deposit(5)      // compile error: cannot call pointer method Deposit on Account
Account{}.Deposit(5)   // compile error: same reason (a composite literal value is not addressable)
```

### Method sets: the rule that decides interfaces

| Type | Its method set contains |
| --- | --- |
| `T` | methods with receiver `T` |
| `*T` | methods with receiver `T` **and** `*T` |

So if `Deposit` has a pointer receiver, the type `Account` does *not* have `Deposit` in its method set; only `*Account` does. This matters as soon as interfaces appear (Unit 3.4): a `*Account` can satisfy an interface requiring `Deposit`; an `Account` cannot. The reason: an interface may hold a copy of an `Account` value that is not addressable, so the compiler could not take its address safely.

### Methods on any defined type

Receivers do not have to be structs:

```go
type Celsius float64
func (c Celsius) String() string { return fmt.Sprintf("%.1f°C", float64(c)) }

type IntSet map[int]struct{}
func (s IntSet) Add(n int) { s[n] = struct{}{} } // value receiver is fine: the map is shared

type HandlerFunc func(string)
func (f HandlerFunc) Handle(s string) { f(s) }   // methods on a function type (net/http does this)
```

### Method values and method expressions

```go
acc := &Account{}
dep := acc.Deposit      // method VALUE: bound to acc — a func(int64)
dep(100)                // acc.balance == 100

f := (*Account).Deposit // method EXPRESSION: receiver becomes the first argument — func(*Account, int64)
f(acc, 50)
```

Method values are handy for callbacks: `defer mu.Unlock()`, `time.AfterFunc(d, srv.Shutdown)`, `slices.SortFunc(s, cmpByName)`.

### Nil receivers are legal

A pointer-receiver method can be called on a nil pointer; it only panics if it dereferences it. Some types use this deliberately:

```go
type Tree struct{ Left, Right *Tree; Val int }

func (t *Tree) Sum() int {
	if t == nil {
		return 0
	}
	return t.Val + t.Left.Sum() + t.Right.Sum()
}
```

### Deep & Tricky

**DT-141. A method value evaluates (copies) its receiver immediately.** *(Guarantee)* With a value receiver, `g := c.Get` copies `c` at that moment; later changes to `c` are invisible to `g`. With a pointer receiver, `inc := c.Inc` stores `&c`, so `inc()` changes `c`. This is the same "photo vs window" distinction as `defer` (DT-88).

**DT-142. Map elements and return values are not addressable, so they cannot call pointer methods.** *(Guarantee)* `m[k].Deposit(1)` and `getAccount().Deposit(1)` are compile errors. Store pointers in the map, or copy out, modify, and store back.

**DT-143. Mixing value and pointer receivers creates "lost update" bugs.** *(Classic bug)* If `Deposit` mistakenly has a value receiver, `acc.Deposit(500)` compiles, runs, modifies a copy, and the balance stays 0. Nothing warns you. Consistent pointer receivers for mutable types prevent it.

### Mastery check

1. **Explain.** State the method-set rule. Why can a `*T` call value-receiver methods but a non-addressable `T` cannot call pointer-receiver methods?
2. **Predict.** `type C struct{ n int }; func (c C) Get() int { return c.n }; func (c *C) Inc() { c.n++ }` then `c := C{1}; g := c.Get; c.n = 50; fmt.Println(g()); inc := c.Inc; inc(); fmt.Println(c.n)`.
3. **Write.** A `Counter` type with `Inc`, `Add(n)`, `Value`, and `Reset`. Write one version with a value receiver on `Inc` by mistake, show the bug in a test, then fix it.

## Unit 3.4 — Interfaces I

**One-line summary:** An interface is a set of method signatures. Any type with those methods satisfies the interface automatically — there is no `implements` keyword. Small interfaces defined where they are *used* are the backbone of decoupled, testable Go code.

**Mental model — a job description, not a family tree.** A job ad for "driver" says: *must be able to `Drive()` and `Park()`*. Anyone with those skills qualifies, whatever their background. The ad (interface) and the people (types) never need to know about each other in advance.

### Declaring and satisfying

```go
type Shape interface {
	Area() float64
	Perimeter() float64
}

type Rect struct{ W, H float64 }
func (r Rect) Area() float64      { return r.W * r.H }
func (r Rect) Perimeter() float64 { return 2 * (r.W + r.H) }

type Circle struct{ R float64 }
func (c Circle) Area() float64      { return math.Pi * c.R * c.R }
func (c Circle) Perimeter() float64 { return 2 * math.Pi * c.R }

func totalArea(shapes []Shape) float64 {
	sum := 0.0
	for _, s := range shapes {
		sum += s.Area() // dynamic dispatch: calls Rect.Area or Circle.Area
	}
	return sum
}

totalArea([]Shape{Rect{2, 3}, Circle{1}})
```

`Rect` never mentions `Shape`. It satisfies `Shape` because it has the methods. This is **implicit** (or **structural**) satisfaction. Consequence: you can define an interface *after the fact* that existing types — even types from other packages you cannot change — already satisfy.

### The most important interfaces in the standard library

```go
type Stringer interface { String() string }                   // fmt uses it for %v and Println
type error interface { Error() string }                        // Unit 3.9
type Reader interface { Read(p []byte) (n int, err error) }    // io: anything you can read bytes from
type Writer interface { Write(p []byte) (n int, err error) }   // io: anything you can write bytes to
```

`io.Reader` and `io.Writer` (Chapter 5) are satisfied by files, network connections, buffers, HTTP bodies, compressors, hashers, and more. A function that accepts an `io.Reader` works with all of them — which is how `wordfreq` (Chapter 2 project) could be tested with `strings.NewReader`.

### Small interfaces

"The bigger the interface, the weaker the abstraction." — Go proverb. One- or two-method interfaces (`Reader`, `Writer`, `Stringer`, `error`, `sort.Interface` has three) are easy to satisfy, easy to fake in tests, and compose well. An interface with fifteen methods has one implementation and one mock and abstracts nothing.

### Define interfaces where they are used

In Java, the type author declares the interface. In Go, the **consumer** usually does:

```go
// package report — needs only to fetch orders
type OrderSource interface {
	OrdersSince(t time.Time) ([]Order, error)
}

func Weekly(src OrderSource) (Summary, error) { ... }
```

The database package exports a concrete `*Store` with twenty methods; `report` declares the one method it needs. Tests pass a tiny fake. The database package does not even know `report` exists. The library project in this chapter does exactly this with `catalog.Store`.

### Accept interfaces, return concrete types

A common guideline: functions should *accept* the narrowest interface they need (flexible for callers), and *return* concrete types (callers get all methods and fields, and you can add methods later without breaking anyone). Exceptions exist — `error` is always returned as an interface, and some constructors return interfaces to hide implementations — but it is a strong default.

### Compile-time satisfaction check

Because satisfaction is implicit, a typo in a method name silently means "does not implement". Add an assertion that fails the build:

```go
var _ Shape = Rect{}            // value type must satisfy Shape
var _ io.Writer = (*MyWriter)(nil) // pointer type must satisfy io.Writer
```

### Deep & Tricky

**DT-144. Value vs pointer receivers decide which types satisfy an interface.** *(Guarantee, from method sets)* If `Area` had a pointer receiver, `Shape(Rect{2, 3})` would not compile (`Rect does not implement Shape (method Area has pointer receiver)`), while `Shape(&Rect{2, 3})` would. This is the method-set rule of Unit 3.3 in action.

**DT-145. `fmt` checks for `error` before `Stringer`.** *(fmt behaviour)* If a type implements both `Error()` and `String()`, `%v` prints `Error()`. Also, `fmt` recovers panics inside `String` and `Error` methods and prints them as `%!v(PANIC=String method: ...)` — which is why a nil-pointer panic in a `String` method can appear as odd text in logs instead of a crash.

**DT-146. Interfaces are satisfied by method *names and signatures*, not meaning.** *(Language design)* Any type with `Read([]byte) (int, error)` is an `io.Reader`, whether or not it follows `io.Reader`'s documented contract (for example: return `n > 0` bytes before an error, never return `0, nil` repeatedly). The compiler checks shape; tests and documentation must check behaviour.

### Pattern

**P-23. Consumer-defined, minimal interfaces.** *(Core Go design practice)*

- *Problem it solves:* tight coupling between packages and hard-to-test code that depends on concrete databases, clocks, or network clients.
- *How:* in the package that *uses* a dependency, declare an interface with only the methods it calls. Accept that interface. Provide the real implementation in `main` (wiring) and a fake in tests.
- *When not to:* do not create an interface for every type "just in case". If there is one implementation and no test need, a concrete type is simpler. Interfaces are discovered, not designed up front.
- *Trade-off:* a level of indirection (and a tiny call cost) in exchange for decoupling and testability.

### Mastery check

1. **Explain.** What does "implicit satisfaction" let you do that Java-style `implements` does not?
2. **Explain.** Why should the *consumer* define the interface? Use the `report`/database example.
3. **Write.** An interface `Notifier { Notify(to, msg string) error }`, two implementations (`EmailNotifier` that prints, `RecordingNotifier` that stores messages in a slice for tests), and a function `remindOverdue(n Notifier, ...)` tested with the recording one. Add compile-time checks.

## Unit 3.5 — Interfaces II: interface values

**One-line summary:** An interface value is a pair: **(dynamic type, dynamic value)**. It is nil only when *both* are absent. Storing a nil pointer in an interface gives a non-nil interface — the most famous trap in Go.

**Mental model — a labelled box.** An interface variable is a box with a label slot and a content slot. An empty box (no label, no content) is `nil`. A box with the label "`*MyErr`" and empty content is *not* empty — it has a label. `box == nil` asks "is the box completely empty?", and a labelled box answers no.

### The two words

```go
var s fmt.Stringer        // (nil, nil) — a nil interface
s = Celsius(36.6)         // (Celsius, 36.6)
s = &Rect{}               // (*Rect, pointer to a Rect)
```

In memory (current implementation) an interface value is two words: a pointer to type information (including the method table for this type/interface pair) and a pointer to the data (or, for some small values, the data itself). That is why `unsafe.Sizeof` of an interface is 16 on 64-bit platforms (Unit 2.10). Calling `s.String()` looks up the method in the table and calls it: **dynamic dispatch**.

### The nil-interface trap

```go
type MyErr struct{}
func (*MyErr) Error() string { return "my" }

func find() error {
	var p *MyErr // nil pointer
	// ... nothing went wrong ...
	return p     // returns (type *MyErr, value nil) — NOT a nil error!
}

err := find()
fmt.Println(err == nil) // false
fmt.Println(err)        // my   — the method still runs on a nil receiver
```

The interface has a dynamic type (`*MyErr`), so it is not nil, even though the pointer inside is nil. Callers check `if err != nil`, see an error, and report a failure that never happened.

**The rule:** never return a typed nil pointer as an interface. Return a literal `nil` in the success path:

```go
func find() error {
	if somethingWrong {
		return &MyErr{}
	}
	return nil // untyped nil → (nil, nil)
}
```

Watch especially for functions whose *result variable* is a concrete pointer type (`var err *MyErr`) that is later returned as `error`.

### `any` (the empty interface)

`interface{}` has no methods, so every type satisfies it. Since Go 1.18 it has the alias `any`. `fmt.Println(a ...any)` accepts anything because of it. Using `any` throws away static type information: to get the value back you need a type assertion (Unit 3.6). Prefer concrete types or generics (Unit 3.14) where possible; use `any` for genuinely heterogeneous data (decoded JSON, printing, containers before generics existed).

### Comparing interface values

Two interface values are equal if their dynamic types are identical and their dynamic values are equal. If the dynamic type is not comparable (a slice, map, or function), the comparison **panics at run time**:

```go
var a, b any = []int{1}, []int{1}
fmt.Println(a == b) // panic: runtime error: comparing uncomparable type []int
```

The same panic happens when such a value is used as a map key of interface type. It compiles because the compiler cannot know what the interfaces will hold.

### Storing a value in an interface may allocate

Converting a non-pointer value (a struct, a large number, a string) to an interface often copies it to the heap so the interface can point to it — the `escapes to heap` lines you saw in Unit 2.12 when passing values to `fmt.Println`. Small integers (0–255) and zero-size values are optimised. In hot code this "boxing" can matter (Chapter 10).

### Deep & Tricky

**DT-147. A nil pointer inside an interface is not a nil interface.** *(Guarantee)* The interface `(*MyErr, nil)` compares unequal to `nil`. This is the source of countless "error is not nil but prints `<nil>`" bugs. `fmt.Println` of such an error may print `<nil>` (if the method handles nil) or the method's output — which makes the bug even more confusing.

**DT-148. Interface comparison can panic.** *(Guarantee)* `==` on interface values compiles even when it may hold slices or maps, and panics at run time with `comparing uncomparable type`. Map keys of type `any` have the same risk.

**DT-149. Method calls through interfaces cost an indirect call and block some optimisations.** *(Implementation detail)* The compiler usually cannot inline a call through an interface (it does not know which method will run), unless it can *devirtualize* it — prove the dynamic type — which PGO helps with (Unit 10.9). For almost all code this cost is irrelevant; in the hottest inner loops it can matter.

### Common mistakes

- Returning a typed nil pointer as `error`.
- Comparing `any` values that might hold slices.
- Using `any` where a generic type parameter or a concrete type would keep type safety.

### Mastery check

1. **Explain.** Draw the two-word picture for `var s fmt.Stringer = (*Rect)(nil)` and explain why `s != nil`.
2. **Predict.** (a) the `find()` program (b) `var e error; fmt.Println(e == nil)` (c) `var p *MyErr; var e error = p; fmt.Println(e == nil, p == nil)` (d) `any(1) == any(1.0)`
3. **Write.** A function `validate(s string) error` that *reproduces* the typed-nil bug, a test that catches it, and the fix.

## Unit 3.6 — Type assertions and type switches

**One-line summary:** A type assertion `x.(T)` extracts the concrete value (or a narrower interface) from an interface value. Use the comma-ok form to avoid a panic. A type switch tests several types at once.

### Type assertions

```go
var s fmt.Stringer = Celsius(36.6)

c := s.(Celsius)          // c is a Celsius. If s held something else: PANIC
c, ok := s.(Celsius)      // comma-ok: ok == false instead of a panic
r, ok := s.(Rect)         // ok == false, r is the zero Rect
```

The asserted type can also be an **interface**, which asks "does the dynamic value *also* have these methods?":

```go
if wt, ok := w.(io.WriterTo); ok {
	// fast path: the value knows how to write itself
}
```

This "upgrade" check is how the standard library offers optional fast paths: `io.Copy` checks whether its source implements `io.WriterTo` or its destination implements `io.ReaderFrom`.

### Type switches

```go
func describe(v any) string {
	switch x := v.(type) {
	case nil:
		return "nil"
	case int, int64:
		return fmt.Sprintf("integer %v", x) // in a multi-type case, x has the interface type (any)
	case string:
		return "string of length " + strconv.Itoa(len(x)) // here x is a string
	case error:
		return "error: " + x.Error()
	case fmt.Stringer:
		return "stringer: " + x.String()
	default:
		return fmt.Sprintf("other %T", x)
	}
}
```

- Cases are checked in order; put specific cases before general interfaces.
- In a single-type case, `x` has that type; in a multi-type case or `default`, `x` keeps the original interface type.
- `fallthrough` is not allowed in type switches.

### Interface embedding

Interfaces can include other interfaces:

```go
type ReadWriter interface {
	io.Reader
	io.Writer
}
```

`ReadWriter`'s method set is the union. `io.ReadCloser`, `io.ReadWriteCloser`, and friends are built this way.

### When type switches are a smell

If you find yourself writing `switch v := s.(type) { case Rect: ...; case Circle: ... }` to compute area, the behaviour belongs in a method on the interface. Type switches are right for *external* variety you do not control (decoded JSON values, AST nodes, events from another system) and for optional capabilities; they are wrong as a replacement for polymorphism.

### Deep & Tricky

**DT-150. Errors should be inspected with `errors.As`, not type assertions.** *(Practice + guarantee)* `err.(*fs.PathError)` fails if the error was wrapped (`fmt.Errorf("load: %w", err)`, Unit 3.10). `errors.As` and `errors.AsType` walk the whole chain. Direct assertions on errors are a latent bug as soon as anyone adds context.

**DT-151. A failed assertion to an interface type and to a concrete type panic differently.** *(Runtime behaviour)* `s.(Rect)` panics with `interface conversion: fmt.Stringer is main.Celsius, not main.Rect`; `s.(io.Writer)` panics with `interface conversion: main.Celsius is not io.Writer: missing method Write`. The message tells you the dynamic type, which is often the fastest clue when debugging.

### Mastery check

1. **Explain.** When is a type switch the right tool, and when should the behaviour be a method instead?
2. **Predict.** `describe(nil)`, `describe(42)`, `describe(errors.New("x"))`, `describe(Celsius(1))` (given `Celsius` has `String()`), `describe([]int{})`.
3. **Write.** `func sizeOf(v any) (int, bool)` that returns a length for strings, slices of int, maps of string to int, and anything with a `Len() int` method; `false` otherwise.

## Topic 3C — Composition and type design

## Unit 3.7 — Embedding and composition

**One-line summary:** Embedding a type in a struct (writing the type without a field name) promotes its fields and methods to the outer struct. It is composition with convenient syntax — not inheritance: there is no "super", no overriding of calls made *inside* the embedded type, and the outer type is not a subtype of the inner one.

### Struct embedding

```go
type Logger struct{ prefix string }
func (l *Logger) Logf(format string, args ...any) {
	fmt.Printf(l.prefix+format+"\n", args...)
}

type Server struct {
	*Logger         // embedded: field name is "Logger"
	addr    string
}

s := Server{Logger: &Logger{prefix: "[srv] "}, addr: ":8080"}
s.Logf("listening on %s", s.addr) // promoted: same as s.Logger.Logf(...)
```

- The embedded field's name is the type name (`Logger`); you can always use it explicitly: `s.Logger.Logf`.
- Promoted methods become part of the outer type's method set, so `Server` can satisfy interfaces through them.
- You can embed a value type (`Logger`) or a pointer (`*Logger`). With a pointer, a zero `Server` has a nil `Logger`, and calling `s.Logf` panics.

Since Go 1.27, a struct literal may also set promoted fields directly by their names: with `type Point struct{ X, Y int }` and `type Pixel struct{ Point; Color string }`, `Pixel{X: 1, Y: 2, Color: "red"}` is allowed (before 1.27 you had to write `Pixel{Point: Point{1, 2}, Color: "red"}`).

### Shadowing and ambiguity

If the outer struct declares a field or method with the same name, it wins (the shallower depth wins):

```go
func (s *Server) Logf(format string, args ...any) {
	s.Logger.Logf("(server) "+format, args...) // wrap the embedded method explicitly
}
```

If two embedded types at the same depth have the same name, using that name is a compile error (`ambiguous selector`) — but only if you use it.

### Embedding is not inheritance

```go
type Base struct{}
func (Base) Name() string   { return "base" }
func (b Base) Hello() string { return "hello from " + b.Name() }

type Derived struct{ Base }
func (Derived) Name() string { return "derived" }

fmt.Println(Derived{}.Hello()) // "hello from base" — NOT "derived"
```

`Hello` is a method of `Base`. When it runs, its receiver is the inner `Base` value; it knows nothing about `Derived`. There are no virtual methods. If you want behaviour to be pluggable, pass an interface (or a function) explicitly. The library project uses this: `store.File` embeds `*store.Memory` and *overrides* the write methods, but if any `Memory` method called `m.PutBook` internally, it would call `Memory.PutBook`, not `File.PutBook`.

Also, a `Server` is not a `Logger`: you cannot pass a `Server` where a `*Logger` is expected. Only interfaces give substitutability.

### Embedding interfaces in structs

```go
type countingWriter struct {
	io.Writer // embed the interface: all Writer methods are promoted
	n int
}

func (c *countingWriter) Write(p []byte) (int, error) {
	n, err := c.Writer.Write(p) // delegate
	c.n += n
	return n, err
}
```

This is the decorator pattern in a few lines. Embedding an interface in a test fake is also useful: implement only the methods a test needs; calling any other panics (the embedded interface value is nil) — a clear signal that the test touched something unexpected.

### Composition over inheritance

Instead of deep class hierarchies, Go programs build types from small parts: a `Server` *has* a logger, a store, and a clock. Behaviour is shared through functions and interfaces. Advantages: no fragile base classes, explicit dependencies, and easy substitution in tests.

### Deep & Tricky

**DT-152. Embedding a type with a `sync.Mutex` promotes `Lock` and `Unlock` — publicly.** *(Guarantee + design consequence)* `type Cache struct { sync.Mutex; m map[string]string }` lets *any caller* do `c.Lock()`, making the lock part of your API forever. Use a named, unexported field: `mu sync.Mutex`.

**DT-153. Embedding a type promotes its `String()` or `Error()`, which can hijack printing.** *(Guarantee + surprise)* Embed `time.Time` in a struct, and `fmt.Println(event)` prints only the time, because `Event` now has a promoted `String()` method and fmt uses it (Unit 3.4). The same happens with an embedded error. Use a named field if you do not want the outer type to *be* a Stringer.

**DT-154. Promoted fields in composite literals are a Go 1.27 feature.** *(Version-dependent)* Code using `Pixel{X: 1, Color: "red"}` compiles only when the module's `go` line is 1.27 or later. Libraries supporting older Go versions must keep the nested form.

### Pattern

**P-24. Decorate with embedded interfaces.** *(Go idiom)* Wrap an interface value in a struct that embeds the interface and overrides one or two methods to add behaviour (counting, logging, metrics, limiting). Used throughout `net/http` middleware (Chapter 8) and `io` (Chapter 5). *Trade-off:* methods you do not override pass through unchanged — including optional interfaces like `io.WriterTo`, which the wrapper silently *hides* because the wrapper type does not have them.

### Mastery check

1. **Explain.** Why does `Derived{}.Hello()` print "hello from base"? What would you do to make the name pluggable?
2. **Predict.** A struct embedding both `A` and `B`, each with a method `Close()`: does it compile? Does `x.Close()` compile?
3. **Write.** A `countingWriter` as above; use it with `fmt.Fprintf` to count bytes written to `os.Stdout`.

## Unit 3.8 — Designing types

**One-line summary:** Good Go types are simple to create, hard to misuse, and useful at their zero value where possible. When a zero value cannot work, provide a `NewX` constructor that validates and initialises. For many optional settings, use an options struct.

### Make the zero value useful (DT-48)

```go
var b bytes.Buffer  // ready to use
b.WriteString("hi")

var mu sync.Mutex   // unlocked, ready to use
var wg sync.WaitGroup
```

Design trick: lazily initialise internal state on first use, so the zero value works:

```go
type Counter struct {
	m map[string]int
}

func (c *Counter) Add(key string) {
	if c.m == nil {
		c.m = make(map[string]int) // lazy init: zero Counter is usable
	}
	c.m[key]++
}
```

### Constructors: `NewX`

When there are required values or invariants, provide a constructor and keep fields unexported so callers cannot build invalid values:

```go
type Temperature struct{ kelvin float64 }

func NewTemperature(celsius float64) (Temperature, error) {
	if celsius < -273.15 {
		return Temperature{}, fmt.Errorf("%.2f°C is below absolute zero", celsius)
	}
	return Temperature{kelvin: celsius + 273.15}, nil
}

func (t Temperature) Celsius() float64 { return t.kelvin - 273.15 }
```

Naming conventions: `New` if the package has one main type (`list.New`), `NewX` otherwise (`bytes.NewBuffer`); getters are named after the field without a `Get` prefix (`t.Celsius()`, not `t.GetCelsius()`); setters are `SetX`.

### Options structs

For constructors with many optional parameters (Go has no default arguments), pass a struct whose zero values mean "use the default":

```go
type ServerOptions struct {
	Addr         string        // default ":8080"
	ReadTimeout  time.Duration // default 5s
	MaxBodyBytes int64         // default 1 MiB
}

func NewServer(opts ServerOptions) *Server {
	if opts.Addr == "" {
		opts.Addr = ":8080"
	}
	if opts.ReadTimeout == 0 {
		opts.ReadTimeout = 5 * time.Second
	}
	...
}

srv := NewServer(ServerOptions{Addr: ":9000"})
```

The alternative "functional options" pattern (`NewServer(WithAddr(":9000"), WithTimeout(time.Second))`) is popular in libraries that need to evolve without breaking callers; it is more code and more indirection. Prefer the options struct unless you need what functional options add.

### Immutability by convention

Go has no `const` for struct values. To make a value effectively immutable, keep fields unexported, expose getters, and return *copies* of internal slices and maps (`slices.Clone`), or callers can modify your internal state through the returned slice.

### Deep & Tricky

**DT-155. Returning an internal slice leaks write access.** *(Guarantee + design consequence)* `func (r *Registry) Names() []string { return r.names }` lets callers do `reg.Names()[0] = "hacked"` and change the registry. Return `slices.Clone(r.names)` — or, since Go 1.23, an iterator (`slices.Values(r.names)`, Unit 3.16) that gives read access without copying.

**DT-156. Options structs make "zero" and "unset" the same.** *(Design trade-off)* With `MaxRetries int` in an options struct, you cannot express "zero retries" if zero means "default". Fixes: choose a default that is also the natural zero, use a pointer (`*int`, nil = unset — and Go 1.26's `new(0)` makes setting it easy), or use a negative sentinel with documentation.

### Pattern

**P-25. Constructors that validate; unexported fields that protect invariants.** *(Go design practice)*

- *Problem it solves:* values in invalid states (negative balance, empty ID) created by struct literals anywhere in the code.
- *How:* unexported fields + `NewX(...) (X, error)` that validates; methods maintain the invariant.
- *When not to:* plain data carriers (DTOs decoded from JSON, configuration, test tables) are better as exported fields with a separate `Validate() error` method.
- *Trade-off:* safety and a single place for rules versus more boilerplate and less convenient literals.

### Mastery check

1. **Explain.** Give two standard-library types whose zero values are useful, and one whose zero value is not (and how you get a usable one).
2. **Explain.** Options struct vs functional options: what does each cost and buy?
3. **Write.** A `RateLimiter` type with an options struct (`PerSecond int`, default 10; `Burst int`, default equal to `PerSecond`) and a constructor that rejects negative values. Tests for defaults and validation.
