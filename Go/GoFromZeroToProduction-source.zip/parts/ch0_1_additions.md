@@INTRO 0
*Goal: understand what a running program physically is before writing real Go.*

Most Go books start with "Hello, World" and move straight to syntax. This one starts one level lower, because almost every confusing Go behaviour you will meet later (silent overflow, `NaN`, compile errors that look like run-time errors, stack vs heap, why `go run` prints `exit status 2`) is explained by what the machine is actually doing. Six short units, one small project. Nothing here is wasted: every later chapter refers back to it.

**What you will be able to do after this chapter**

- Explain the path from `main.go` to a process running on a CPU, and say for any error whether it happens at compile time or at run time.
- Read and write numbers in binary, hex, and octal, and predict exactly what a fixed-size integer does when it overflows.
- Explain two's complement well enough to predict `int8(200)` without running the code.
- Describe registers, caches, the stack, and the heap, and why a Go programmer cares about each.

**One question to carry through the whole book:** *"Who calculates this, and when?"* The compiler (at compile time, with exact constants) or the CPU (at run time, with fixed-size values)? You will be surprised how many puzzles this one question solves.

@@UNIT 0.1
#### Misconceptions worth a second look

- **"Every compile error is a syntax error."** Syntax is only grammar. `"total" + 5` is a *type* error; `100 / 0` breaks a *rule*; an unused import breaks another rule. All are compile errors; only the first kind is a syntax error. Read the message: the compiler prints `syntax error:` only for grammar.
- **"`invalid operation:` means a rule error."** It begins both type errors and rule errors. The words in brackets decide: `(mismatched types untyped string and untyped int)` is a type error; `division by zero` with no types mentioned is a rule error.
- **"`fmt.Println(4.0 / 0.0)` prints `+Inf`."** Both operands are constants, so the *compiler* must compute an exact answer. Exact numbers have no infinity: compile error. `+Inf` only appears when a float *variable* is divided at run time (DT-10).
- **"`NaN == NaN` is true."** It is false. NaN equals nothing, not even itself. Use `math.IsNaN`.
- **"`echo $?` shows my program's exit code"** — only if nothing else ran in between, and not after `go run`, which reports its own code (DT-9, DT-11).

#### Mastery check

1. **Explain.** In your own words: why is a compile error cheaper than a panic? Give one real example of a costly run-time failure that a compile error could not have caught.
2. **Predict.** For each line, say *compile error* (and which kind), *panic*, or the printed output:
   (a) `fmt.Println(10 / 0)` (b) `x := 0; fmt.Println(10 / x)` (c) `f := 5.0; fmt.Println(f / 0)` (d) `fmt.Println("total" + 5)` (e) `z := 0.0; fmt.Println(z / z == z / z)`
3. **Write.** Write a program that panics. Build it with `go build`, run the binary directly, and record its exit code. Then run it with `go run` and record that exit code. Explain the difference.
4. **Write.** Cross-compile any program for `GOOS=linux GOARCH=amd64` and for `GOOS=windows GOARCH=arm64`. Use the `file` command on both results and explain each part of its output.

@@UNIT 0.2
#### Misconceptions worth a second look

- **"`%3d` adds three spaces."** The number is a *minimum width*, not a count of spaces. `%3d` of 7 is `··7` (two spaces), of 42 is `·42`, of 12345 is `12345` (never cut). Same for `%08b`: 13 becomes `00001101`, four zeros, not eight.
- **"A byte holds values up to 256."** It holds 256 *different* values: 0 to 255.
- **"My hex output is correct — I tested it."** With 34 the hex is `22` in both `%x` and `%X`. Choose test values that can actually reveal the bug (DT-18).

#### Mastery check

1. **Explain.** Why does one hex digit correspond to exactly 4 bits, and one octal digit to exactly 3? Use the 2^n rule.
2. **Predict.** What do these print? (a) `fmt.Printf("%08b\n", 42)` (b) `fmt.Printf("%X\n", 255)` (c) `fmt.Println(010)` (d) `fmt.Printf("%4d|%-4d|\n", 42, 42)` (e) `fmt.Println(0b1010 + 0x0A + 0o12)`
3. **Write.** A program that prints a table of the numbers 0 to 16 in decimal, binary (padded to 8 digits), octal, and uppercase hex, with aligned columns.
4. **Convert by hand, then check with code:** 200 to binary and hex; `0x7F` to decimal; `rwxr-x---` to octal.

@@UNIT 0.3
#### Misconceptions worth a second look

- **"`fmt.Println(math.MaxUint64)` fails because Println does not accept untyped values."** Println accepts untyped constants happily (`fmt.Println(42)`). The constant receives its default type, `int`, and 1.8 × 10^19 does not fit in an `int`. `math.MaxUint32` fits, so it prints (DT-20).
- **"`x + 1` fails for a constant `x` because constants cannot be reassigned."** Nothing is reassigned; `x + 1` creates a new value. It is checked because both operands are constants, so the compiler computes it — and checks it.

#### Mastery check

1. **Explain.** Why does Go wrap on overflow instead of panicking? What is the cost of that choice?
2. **Predict.** With `var b uint8 = 250`: (a) `b + 10` (b) `b * 2` (c) `uint8(0) - 1` written with a variable (d) `var c uint8 = 256` (e) `fmt.Printf("%T\n", b+b)`
3. **Write.** A function `addUint8(a, b uint8) (uint8, bool)` that returns the sum and `false` if it overflowed — without using a wider type. (Hint: if the sum is smaller than `a`, it wrapped.)

@@UNIT 0.4
#### Misconceptions worth a second look

- **"At run time, the compiler throws away the extra bit."** The compiler is finished before the program runs. The CPU executes instructions the compiler chose, and its 8-bit result simply has no ninth place (DT-28).
- **"The default type of an integer constant is int64."** It is `int`. On 64-bit machines `int` has the same *size* as `int64`, but they are different *types* (DT-29).
- **"`uint8(300)` and `int8(300)` are both 44 because 300 is positive."** The reason is the top bit of the *kept* 8 bits. 300 → keep `0010 1100` → top bit 0, so both read 44. 200 is positive too, but `int8(200)` is −56 because `1100 1000` has its top bit set.

#### Mastery check

1. **Explain.** Why did two's complement win over "sign bit + magnitude"? Give both reasons.
2. **Predict.** (a) `int8(200)` with a variable (b) `var x int8 = 127; x++` (c) `var m int8 = -128; m = -m` (d) `fmt.Printf("%b\n", int8(-5))` (e) `fmt.Printf("%08b\n", uint8(int8(-5)))`
3. **Write.** By hand, compute the 8-bit two's complement of −37, then verify with Go.
4. **Explain.** Pick one of the real-world bugs (Year 2038, YouTube, Boeing 787) and describe exactly which type overflowed and when.

@@UNIT 0.5
#### Misconceptions worth a second look

- **"Reading one byte brings the next 63 (or 127) bytes."** A cache line is an *aligned* block. Memory is divided into fixed blocks (0–63, 64–127, … on x86; 128-byte blocks on Apple Silicon). Reading a byte loads the whole block it lives in — bytes before it as well as after (DT-33).
- **"Go requires explicit casting."** Go's word is *conversion*: `int64(x)`. The specification has no "cast". In C a cast can reinterpret memory unsafely; a Go conversion follows defined rules.

#### Mastery check

1. **Explain.** Using the kitchen analogy, why can an algorithm that does *more* arithmetic run faster than one that does less?
2. **Explain.** Why do CPUs have separate signed and unsigned *compare* and *divide* instructions but a single *add* instruction?
3. **Write.** Find your machine's cache-line size and page size (`sysctl hw.cachelinesize` and `pagesize` on macOS; `getconf LEVEL1_DCACHE_LINESIZE` and `getconf PAGESIZE` on Linux).

@@UNIT 0.6
#### Misconceptions worth a second look

- **"LIFO means the last box is removed last."** "In" and "out" are about *time*. The last one put in is the first one taken out.
- **"If data dies when the function returns, how can `square` return 9?"** The *variables* die with the frame; the returned *value* is copied out first. The box is gone; its contents survived as a photocopy.
- **"Infinite recursion causes a panic."** It is a *fatal error* (`fatal error: stack overflow`), which cannot be recovered (DT-39).
- **"The spec guarantees locals live on the stack."** The spec never mentions stack or heap (DT-34).
- **"`square(4)` reuses `square(3)`'s memory because of LIFO."** LIFO is the rule; the mechanism is that returning moves the stack pointer back, so the next frame is placed at the same addresses and overwrites the old bytes.
- **"The GC cleans stack frames."** The GC manages the heap only. Frames are created and removed by moving the stack pointer. Clean starting values come from zero-initialization (DT-43).

#### Mastery check

1. **Explain.** Draw the stack, step by step, for `main → sumOfSquares(3, 4) → square(3)` and back.
2. **Explain.** Why is returning a plain value never a problem, while returning a reference to a local could be — and what does Go do about it?
3. **Write.** Write a recursive function without a base case. Build it, run the binary, and record: the first line of the error, the stack-limit message, and the exit code.
4. **Write.** Run `go build -gcflags=-m` on a small program that returns `&x` for a local `x`. Find the line that says the variable moved to the heap.

@@PROJECT 0
### Chapter 0 Project — `numinfo`

**Goal:** a command-line tool that takes one integer and prints everything this chapter taught about it.

**New tools you need (full lessons come later):**

- `os.Args` — the command-line words. `os.Args[0]` is the program's name; `os.Args[1]` is the first argument; `len(os.Args)` counts them.
- `strconv.ParseInt(text, 10, 64)` — turns text like `"200"` into an `int64`, and returns an error if the text is not a valid 64-bit integer. (`strconv.Atoi` is the shortcut for `int`.)
- `if cond { ... }` and `switch` — run code only when a condition holds (Unit 1.6).
- `fmt.Fprintln(os.Stderr, ...)` prints to stderr; `os.Exit(1)` stops with exit code 1.
- `%-10s` prints a string left-aligned in a 10-character field, so labels line up.

**Requirements**

1. Exactly one argument; otherwise print a usage line to stderr and exit with code 1.
2. A non-integer (or out-of-range) argument: a clear message on stderr naming the bad input, exit code 1.
3. Print, one per line with aligned labels: sign (positive/negative/zero), decimal, binary, octal (`0o` prefix), hex (`0x` prefix, uppercase digits; negatives as `-0x…`).
4. Print the lowest 8 bits as a padded 8-digit binary, and read as `uint8` and as `int8`.
5. Print every type from `int8 uint8 int16 uint16 int32 uint32 int64 uint64` that can hold the number.
6. Must work for `math.MinInt64` (the hex line is the trap: DT-24, DT-70).
7. Formatted with `gofmt`, passes `go vet`.

**Test plan** — run each and record output AND exit code from a *real run*:

| Input | Must show |
| --- | --- |
| `200` | hex `0xC8`, as int8 `-56`, fits `uint8` but not `int8` |
| `-1` | hex `-0x1`, low 8 bits `11111111`, as uint8 `255` |
| `0` | sign zero, fits everything |
| `300` | low 8 bits `00101100`, both readings 44 |
| `-9223372036854775808` | hex `-0x8000000000000000` (no double minus) |
| `abc`, no argument, two arguments | stderr message, exit 1 |

**Reference solution**

```go
// Command numinfo prints facts about one integer: its bases, its lowest
// 8 bits read as uint8 and int8, and which integer types can hold it.
package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
)

const usage = "usage: numinfo <integer>"

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(1)
	}
	n, err := strconv.ParseInt(os.Args[1], 10, 64)
	if err != nil {
		fmt.Fprintf(os.Stderr, "numinfo: %q is not a 64-bit integer\n", os.Args[1])
		os.Exit(1)
	}

	switch {
	case n > 0:
		fmt.Printf("%-10s %s\n", "sign:", "positive")
	case n < 0:
		fmt.Printf("%-10s %s\n", "sign:", "negative")
	default:
		fmt.Printf("%-10s %s\n", "sign:", "zero")
	}

	fmt.Printf("%-10s %d\n", "decimal:", n)
	fmt.Printf("%-10s %b\n", "binary:", n)
	fmt.Printf("%-10s %O\n", "octal:", n)
	if n < 0 {
		// uint64(-n) is the correct size even for MinInt64 (DT-70).
		fmt.Printf("%-10s -0x%X\n", "hex:", uint64(-n))
	} else {
		fmt.Printf("%-10s 0x%X\n", "hex:", n)
	}

	low := uint8(n) // keeps only the lowest 8 bits (DT-41)
	fmt.Printf("%-10s %08b\n", "low 8:", low)
	fmt.Printf("%-10s %d\n", "as uint8:", low)
	fmt.Printf("%-10s %d\n", "as int8:", int8(n))

	fmt.Printf("%-10s", "fits:")
	if n >= math.MinInt8 && n <= math.MaxInt8 {
		fmt.Print(" int8")
	}
	if n >= 0 && n <= math.MaxUint8 {
		fmt.Print(" uint8")
	}
	if n >= math.MinInt16 && n <= math.MaxInt16 {
		fmt.Print(" int16")
	}
	if n >= 0 && n <= math.MaxUint16 {
		fmt.Print(" uint16")
	}
	if n >= math.MinInt32 && n <= math.MaxInt32 {
		fmt.Print(" int32")
	}
	if n >= 0 && n <= math.MaxUint32 {
		fmt.Print(" uint32")
	}
	fmt.Print(" int64")
	if n >= 0 {
		fmt.Print(" uint64")
	}
	fmt.Println()
}
```

Real output for `200`:

```
sign:      positive
decimal:   200
binary:    11001000
octal:     0o310
hex:       0xC8
low 8:     11001000
as uint8:  200
as int8:   -56
fits:      uint8 int16 uint16 int32 uint32 int64 uint64
```

**Review checklist** (the issues reviewers find most often in this project)

- The `0x` prefix is missing, or `%#x` was used (lowercase digits), or `%#X` (uppercase `0X` prefix). `"0x%X"` is what the requirement asks for.
- Negative hex printed with `%X` directly gives `-1` style output; for `MinInt64`, printing `-0x%X` of `-n` gives a *double* minus because `-n` is still negative. Use `uint64(-n)`.
- `n&0xFF` and `uint8(n)` both give the low 8 bits; choose one and make the code match the choice.
- Labels aligned with `\t` depend on the reader's tab width; `%-10s` gives the same layout everywhere.
- `fmt.Scan` reads stdin, not arguments. An "upgrade" must keep everything that already works (arguments, validation, exit codes).
- Remove scaffold comments ("TODO: step 3"); comments should explain the code that exists.
- Every requirement line checked against the final output before submitting.

@@INTRO 1
*Goal: know the exact rules of Go's building blocks.*

This chapter covers the core language: variables, constants, operators, floating point, control flow, functions, scope, closures, `defer`, reading input, and random numbers. It is longer than Chapter 0 because precision matters here. Professionals are rarely bitten by *what* `for` does; they are bitten by the edge cases: integer division of negative numbers, `0.1 + 0.2`, shadowed `err`, a deferred argument evaluated too early. Every edge case in this chapter has caused real bugs in real systems.

**What you will be able to do after this chapter**

- Predict the type and value of any expression built from constants, variables, and operators.
- Write idiomatic control flow with guard clauses, and loops without off-by-one errors.
- Design functions with `(value, error)` and `(value, ok)` results; use closures and `defer` correctly.
- Build a complete, testable command-line program that reads input safely.

@@UNIT 1.1
#### Misconceptions worth a second look

- **"`x, y := 6, 7` is illegal because `x` already exists."** It is legal: at least one name (`y`) is new; `x` is simply assigned.
- **"int8 can't hold −128 to 127, so minus 1 was truncated."** int8 *can* hold −128; it cannot hold −129. `1000 0000` − 1 = `0111 1111` = 127. That is wraparound. *Truncation* is what a conversion to a smaller type does.
- **Editor message ≠ compiler message.** `count := 0` at package level: VS Code (gopls) says "expected declaration, found count"; `go build` says `syntax error: non-declaration statement outside function body` (DT-49).

#### Mastery check

1. **Explain.** When would you write `var count int` instead of `count := 0`? When `var ratio float32 = 1.5` instead of `ratio := 1.5`?
2. **Predict.** (a) `x := 1; x, y := x+1, x+10; fmt.Println(x, y)` (b) `n := 1e3; fmt.Printf("%T\n", n)` (c) `c := 'a'; fmt.Printf("%T %v\n", c, c)` (d) `var s string; fmt.Printf("%q\n", s)`
3. **Write.** Swap two variables without a temporary; then rotate three variables `a, b, c = b, c, a` and print the result.

@@UNIT 1.2
#### Misconceptions worth a second look

- **"`const limit int = 10; var f float64 = limit` fails because constants cannot be reassigned."** Nothing is reassigned; `limit` is only read. It fails because `limit` is a *typed* constant (int), and typed constants do not adapt. Fix: make it untyped (`const limit = 10`) or convert (`float64(limit)`).
- **"I predicted the error correctly"** — only if the predicted *reason* matches the compiler's real message. Always run it and read the message.

#### Mastery check

1. **Explain.** Use the water/ice analogy to explain why `f * 2` compiles but `f * n` does not (for `f float64`, `n := 2`).
2. **Predict.** (a) `fmt.Println('a' + 1)` (b) `var i int = 2.0` (c) `var i int = 2.5` (d) `const big = 1 << 100; fmt.Println(big >> 98)` (e) the values of `A, B, C, D` in `const ( A = iota * 10; B; _; D )`
3. **Write.** Constants `KB, MB, GB, TB` using `iota` and shifts; print each.

@@UNIT 1.3
#### Misconceptions worth a second look

- **"`var f float64 = 9 / 2; fmt.Println(f)` prints 4.0."** It prints `4`: the division is an integer constant expression (4), and `Println` prints floats in the shortest form (DT-54, DT-57). Use `%.1f` to see `4.0`.
- **"`x++` is not valid in Go."** It is valid as a *statement* on its own line; it is invalid inside an expression.

#### Mastery check

1. **Explain.** Why is `d != 0 && 10/d > 1` safe and `10/d > 1 && d != 0` not?
2. **Predict.** (a) `-7 / 2` (b) `-7 % 3` (c) `7 % -3` (d) `"Zebra" < "apple"` (e) `"10" < "9"` (f) `var f float64 = 7 / 2`
3. **Write.** A function `isOdd(n int) bool` that is correct for negative numbers, with a table of test inputs including −3, −2, 0, 3.

@@UNIT 1.4
#### Misconceptions worth a second look

- **`&^` clears only where the right side has 1s.** For `a = 1100 1010`, `b = 0101 0110`, the top bit of `b` is 0, so the top bit of `a` *stays*: `a &^ b = 1000 1000`.
- **"`x >> 1` and `x / 2` are the same."** For negative numbers, shift rounds *down* (−7 >> 1 = −4) and division rounds towards *zero* (−7 / 2 = −3) (DT-58).

#### Mastery check

1. **Explain.** Why does `x & 1 == 0` do what you mean in Go but not in C?
2. **Predict.** With `a, b := uint8(0b1100_1010), uint8(0b1010_0110)`: (a) `a & b` (b) `a | b` (c) `a ^ b` (d) `a &^ b` (e) `^a` — all in `%08b`. Then (f) `1 << 2 + 1` (g) `2 ^ 3`.
3. **Write.** Four permission flags (Read, Write, Exec, Admin) with `iota`; a function that prints which flags are set in a value; tests that set, clear, and toggle flags.

@@UNIT 1.5
#### Misconceptions worth a second look

- **Money printed as `total: 425`.** Keep money in paise, but format at the edge: `fmt.Printf("₹%d.%02d\n", total/100, total%100)` prints `₹4.25`.
- **"Variables are compiled at run time."** Variables are *calculated* at run time. Compiling happens once, before running.

#### Mastery check

1. **Explain.** Why is 0.5 exact in a float64 but 0.1 is not? Why does `0.1 + 0.2 == 0.3` give a different answer for constants and variables?
2. **Predict.** (a) `int(-3.9)` (b) `math.Round(-2.5)` (c) `math.Floor(-2.5)` (d) summing `0.1` ten times in a loop (e) `fmt.Println(1000000.0)` (f) `float64(float32(0.1))`
3. **Write.** A bill calculator that reads item prices like `12.50` as text, stores them in paise without using floats for the arithmetic, and prints the total as `₹x.yy`. (Hint: split on `.` with `strings.Cut`.)

@@UNIT 1.6
#### Misconceptions worth a second look

- **An "upgrade" that rewrites the program.** When asked to extend working code, keep what works and change only what was asked. Rewriting silently drops validation and tests.
- **Reasoning is not output.** When a bug is explained, also show the *real* output that proves it (for example the `-0x-8000000000000000` double minus).

#### Mastery check

1. **Explain.** What is a guard clause, and why does it make `else` unnecessary after a `return`?
2. **Predict.** A tagless switch with cases `marks >= 35`, `marks >= 75`, `marks >= 90` in that order: what grade does 95 get? Fix the order.
3. **Predict.** The `fallthrough` example in DT-67 with `x := 2`.
4. **Write.** `classify(n int) string` returning "negative", "zero", "small" (1–9), "large" (10–99), or "huge", using a tagless switch; test the boundaries 0, 1, 9, 10, 99, 100, −1.

@@UNIT 1.7
#### Misconceptions worth a second look

- **The unsigned countdown wraps to 255.** Only for `uint8`. With `uint` (64 bits on most machines), 0 − 1 wraps to 18,446,744,073,709,551,615.
- **`range 3` starts at 1.** It gives 0, 1, 2.

#### Mastery check

1. **Explain.** What is the difference between changing `i` inside a three-part loop and inside a `for i := range n` loop (DT-71)?
2. **Predict.** (a) `for i := 0; i < 10; i += 3 { fmt.Print(i, " ") }` (b) a `switch` with `break` inside a `for` — does the loop stop? (c) the labelled-break example in this unit: which `(i, j)` pairs are visited?
3. **Write.** FizzBuzz from 1 to 30 (check order: 15 before 3 and 5). Then a loop that finds the first number above 1000 that is divisible by 7 and 13, using `break`.

@@UNIT 1.8
#### Misconceptions worth a second look

- **The guard clause must come first.** `largest(nums ...int)` that reads `nums[0]` and *then* checks `len(nums) == 0` panics with zero arguments, because Go runs lines top to bottom. And the case you designed for is the one you must actually *run*.
- **"Go returns a tuple."** Go has no tuples; multiple results cannot be stored in one variable (DT-79).
- **"Undefined function" vs "nil function."** A function that was never written is a compile error (`undefined: apply`). A function *variable* that was never assigned is `nil`; calling it compiles and panics (DT-77).
- **"Without a base case it runs forever."** Infinite *recursion* dies with a stack overflow; an infinite *loop* runs forever.

#### Mastery check

1. **Explain.** Go is always pass-by-value. How, then, can a function change data the caller can see? (Preview of DT-75.)
2. **Predict.** (a) `func double(x int) { x *= 2 }` then `n := 5; double(n); fmt.Println(n)` (b) `fmt.Println(divmod(17, 5))` (c) `x := divmod(17, 5)` (d) `var f func(); f()`
3. **Write.** `largest(nums ...int) (int, bool)` with the guard first; run it with zero, one, and several arguments, including all-negative numbers.
4. **Write.** `factorial(n int) int` recursively, then iteratively. Which one survives `n = 10_000_000` (ignore the overflowing result)? Why?

@@UNIT 1.9
#### Misconceptions worth a second look

- **"`max` is recreated as a new variable."** Nothing is recreated: the built-in still exists in the universe scope; a new local named `max` hides it in this block.

#### Mastery check

1. **Explain.** Describe the `err` shadowing bug and two ways to fix it.
2. **Predict.** `total := 10; for i := range 3 { total := total + i; fmt.Println("in loop:", total) }; fmt.Println("after:", total)`
3. **Predict.** `true := false; fmt.Println(true)` — compile error or output?
4. **Write.** Deliberately write the `err` shadowing bug, then run `go vet` and a shadow checker (`go run golang.org/x/tools/go/analysis/passes/shadow/cmd/shadow@latest ./...`) and record what each reports.

@@UNIT 1.10
#### Misconceptions worth a second look

- **"Copy the value inside the closure to keep it."** Code inside a closure runs only when the closure is *called*. A copy written inside the body is taken at call time. To keep the old value, take the copy *outside*, before creating the closure.

#### Mastery check

1. **Explain.** Window vs photo: what does a closure capture, and when does it read the value?
2. **Predict.** `n := 1; inc := func() { n++ }; set := func() { n = 100 }; inc(); inc(); fmt.Println(n); set(); fmt.Println(n)`
3. **Predict.** The loop-closure program in this unit with `go 1.21` vs `go 1.22` in `go.mod`.
4. **Write.** `makeAccumulator(start int) func(int) int` that returns the running total; create two independent accumulators and show they do not share state. Confirm with `-gcflags=-m` where the captured variable lives.

@@UNIT 1.11
#### Misconceptions worth a second look

- **"Defers added in a loop run in loop order."** LIFO applies to every defer. A loop that defers 0, 1, 2 prints 2, 1, 0.
- **"During a panic, the panic message prints first."** Deferred calls run first; the message is printed only after them (DT-90).
- **"Actual output = my prediction."** Never fill in "actual" without running. If you did not run it, write "not run".

#### Mastery check

1. **Explain.** The three steps of `return`, and why a deferred closure can change a named result but not an unnamed one.
2. **Predict.**
   ```go
   func a() (n int) { defer func() { n++ }(); return 10 }
   func b() int { n := 10; defer func() { n++ }(); return n }
   func c() (n int) { defer func() { n *= 3 }(); n = 5; return n * 2 }
   ```
3. **Predict.** `x := 1; defer fmt.Println("A:", x); defer func() { fmt.Println("B:", x) }(); x = 2`
4. **Write.** A program whose `main` defers a "cleanup" print and then calls `os.Exit(1)`. Run the binary and show cleanup is skipped. Rewrite it with the `run()` pattern (P-14) and show cleanup runs.

@@UNIT 1.12
#### Misconceptions worth a second look

- **"Typing is testing."** Repeatable tests use pipes: `printf "abc\n" | ./age; echo $?`. The EOF case is the one most often broken.
- **Silent rejection.** If input is rejected, tell the user *why* on stderr; otherwise they cannot fix it.

#### Mastery check

1. **Explain.** Why must `scanner.Err()` be checked after the loop? Name two situations in which `Scan()` returns false.
2. **Predict.** What does `fmt.Scan(&n)` leave in `n` when the user types `abc`? What happens to the text `abc`?
3. **Write.** An "ask until valid" program: read an age (0–150); reject invalid lines with a reason on stderr; handle EOF with a clear message and exit code 1. Test it with three `printf` pipes: valid on the first line, invalid then valid, and invalid then EOF.

@@UNIT 1.13
#### Mastery check

1. **Explain.** What is a seed? Why does a fixed-seed generator make tests possible?
2. **Explain.** Why must an OTP never come from `math/rand`? What does an attacker gain?
3. **Predict.** Can `rand.IntN(6)` return 6? What does `rand.IntN(0)` do? What range does `10 + rand.IntN(91)` produce?
4. **Write.** A dice simulator that rolls two dice 1,000,000 times and prints how often each total 2–12 appears, as a percentage. Compare with the expected values (7 should be about 16.7%).

@@UNIT 2.1
#### Mastery check

1. **Explain.** Why is the length part of an array's type? What does that make impossible?
2. **Predict.** (a) `a := [3]int{1, 2, 3}; b := a; b[0] = 9; fmt.Println(a[0])` (b) `[...]int{5: 1}` — what is its length? (c) `[2]int{1, 2} == [2]int{1, 2}` (d) `i := 3; var a [3]int; a[i] = 1`
3. **Predict.** In `for i, v := range arr { if i == 0 { arr[2] = 100 }; fmt.Println(v) }` with `arr := [3]int{1, 2, 3}`, what is printed for `v` at index 2 (DT-98)?
4. **Write.** A tic-tac-toe board `[3][3]rune` and a function `winner(b [3][3]rune) rune` that returns `'X'`, `'O'`, or `0`. Use the board as a map key to count how many distinct positions you have seen.

@@PROJECT 1
### Chapter 1 Project — `playtool`

**Goal:** one command-line program with two modes that uses everything in this chapter: constants, operators, floats, `if`/`switch`, loops, functions, closures or small helpers, `defer`, input, and randomness — plus the Chapter 0 conventions (stderr, exit codes, validation at the edge).

**Modes**

- `playtool guess [seed]` — guess a secret number from 1 to 100 in at most 7 attempts. An optional seed makes the secret repeatable for testing.
- `playtool convert` — read lines like `10 km mi`, `100 c f`, `5 kg lb` (and reverse directions) until `quit` or EOF.

**New tools**

- `strings.Fields(line)` splits a line on whitespace; `strings.TrimSpace` removes surrounding whitespace.
- `strconv.ParseFloat(text, 64)` and `strconv.ParseUint(text, 10, 64)` convert text, returning an error on bad input.
- `errors.New("...")` and `fmt.Errorf("... %w", err)` create error values that `run()` returns (full lesson in Chapter 3).

**Exact constants:** 1 mile = 1.609344 km; 1 pound = 0.45359237 kg; °F = °C × 9 / 5 + 32.

**Requirements**

- *G1* No mode or unknown mode → usage on stderr, exit 1. *G2* Secret in [1, 100], from `math/rand/v2`; with a seed, from a fixed-seed generator. *G3* Invalid seed → error that keeps the original reason, exit 1. *G4* After each guess print "too low", "too high", or "correct". *G5* A rejected line (not a number, out of range) prints the reason on stderr and does **not** use up an attempt. *G6* On a win, print the attempts used and a rating. *G7* Out of attempts → reveal the number, exit 1. *G8* EOF during the game → "game aborted", exit 1; a real read error is reported differently.
- *C1* Six conversions, all exact constants; `−40 c f` must give −40 (watch `9/5`). *C2* Wrong word count, bad number, or unknown pair → reason on stderr, keep going. *C3* `quit` or EOF ends with "bye", exit 0. *C4* Check `scanner.Err()`.
- *P1* `main` only calls `run()` and exits (P-14). *P2* No magic numbers: `minNumber`, `maxNumber`, `maxAttempts`. *P3* Each problem reported once. *P4* `gofmt`, `go vet` clean.

**Test plan** (run every line; record real output and `echo $?`):

```
./playtool; echo $?                                  # usage, 1
./playtool fly; echo $?                              # unknown mode, 1
./playtool guess x; echo $?                          # invalid seed with reason, 1
printf "50\n75\n62\n" | ./playtool guess 42; echo $? # win in 3 (with this solution's seeding), 0
printf "1\n2\nabc\n3\n4\n5\n6\n7\n" | ./playtool guess 42; echo $?   # abc not counted; out of attempts, 1
printf "50\n" | ./playtool guess 42; echo $?         # EOF: aborted, 1
printf "10 km mi\n-40 c f\nabc\nquit\n" | ./playtool convert; echo $?  # 0
```

**Reflection questions**

1. Why are 7 attempts always enough for 1–100 with the best strategy? (Hint: 2^7.)
2. What does a fixed seed give you in testing that a random seed cannot?
3. Which package would you use for the secret in a game, and which for a password-reset link? Why?

**Reference solution**

```go
// Command playtool is a number-guessing game and a unit converter.
//
//	playtool guess [seed]   guess a number from 1 to 100 in at most 7 attempts
//	playtool convert        convert lines like "10 km mi" until "quit" or EOF
package main

import (
	"bufio"
	"errors"
	"fmt"
	"math/rand/v2"
	"os"
	"strconv"
	"strings"
)

const usage = "usage: playtool guess [seed] | playtool convert"

const (
	minNumber   = 1
	maxNumber   = 100
	maxAttempts = 7
)

const (
	kmPerMi = 1.609344
	kgPerLb = 0.45359237
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

// run checks the arguments and dispatches to a mode. It never calls os.Exit,
// so every deferred call inside it runs (P-14).
func run(args []string) error {
	if len(args) == 0 {
		return errors.New(usage)
	}
	switch args[0] {
	case "guess":
		if len(args) > 2 {
			return errors.New(usage)
		}
		seedArg := ""
		if len(args) == 2 {
			seedArg = args[1]
		}
		secret, err := newSecret(seedArg)
		if err != nil {
			return err
		}
		return playGuess(bufio.NewScanner(os.Stdin), secret)
	case "convert":
		if len(args) != 1 {
			return errors.New(usage)
		}
		return runConvert(bufio.NewScanner(os.Stdin))
	default:
		return fmt.Errorf("unknown mode %q\n%s", args[0], usage)
	}
}

// newSecret returns a random number in [minNumber, maxNumber]. With a seed,
// the number is the same on every run, which makes the game testable.
func newSecret(seedArg string) (int, error) {
	span := maxNumber - minNumber + 1
	if seedArg == "" {
		return minNumber + rand.IntN(span), nil
	}
	seed, err := strconv.ParseUint(seedArg, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid seed %q: %w", seedArg, err)
	}
	r := rand.New(rand.NewPCG(seed, seed))
	return minNumber + r.IntN(span), nil
}

func playGuess(sc *bufio.Scanner, secret int) error {
	fmt.Printf("I picked a number from %d to %d. You have %d attempts.\n",
		minNumber, maxNumber, maxAttempts)
	attempt := 1
	for attempt <= maxAttempts {
		fmt.Printf("attempt %d/%d: ", attempt, maxAttempts)
		if !sc.Scan() {
			if err := sc.Err(); err != nil {
				return fmt.Errorf("reading input: %w", err)
			}
			return errors.New("game aborted: input ended")
		}
		text := strings.TrimSpace(sc.Text())
		guess, err := strconv.Atoi(text)
		if err != nil || guess < minNumber || guess > maxNumber {
			// A rejected line does not use up an attempt.
			fmt.Fprintf(os.Stderr, "please enter a whole number from %d to %d (got %q)\n",
				minNumber, maxNumber, text)
			continue
		}
		switch {
		case guess < secret:
			fmt.Println("too low")
		case guess > secret:
			fmt.Println("too high")
		default:
			fmt.Printf("correct! %d attempt(s): %s\n", attempt, rating(attempt))
			return nil
		}
		attempt++
	}
	return fmt.Errorf("out of attempts, the number was %d", secret)
}

func rating(attempts int) string {
	switch {
	case attempts <= 3:
		return "well played"
	case attempts <= 5:
		return "good"
	default:
		return "just made it"
	}
}

func runConvert(sc *bufio.Scanner) error {
	fmt.Println(`enter "<value> <from> <to>" (km mi kg lb c f), or "quit"`)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		if line == "quit" {
			break
		}
		fields := strings.Fields(line)
		if len(fields) != 3 {
			fmt.Fprintf(os.Stderr, "need 3 words, got %d: %q\n", len(fields), line)
			continue
		}
		v, err := strconv.ParseFloat(fields[0], 64)
		if err != nil {
			fmt.Fprintf(os.Stderr, "not a number: %q\n", fields[0])
			continue
		}
		out, ok := convert(v, fields[1], fields[2])
		if !ok {
			fmt.Fprintf(os.Stderr, "unknown conversion %s -> %s\n", fields[1], fields[2])
			continue
		}
		fmt.Printf("%g %s = %.4f %s\n", v, fields[1], out, fields[2])
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("reading input: %w", err)
	}
	fmt.Println("bye")
	return nil
}

// convert reports ok == false for an unknown pair of units.
func convert(v float64, from, to string) (float64, bool) {
	switch from + ">" + to {
	case "km>mi":
		return v / kmPerMi, true
	case "mi>km":
		return v * kmPerMi, true
	case "kg>lb":
		return v / kgPerLb, true
	case "lb>kg":
		return v * kgPerLb, true
	case "c>f":
		return v*9/5 + 32, true
	case "f>c":
		return (v - 32) * 5 / 9, true
	}
	return 0, false
}
```

Note `v*9/5 + 32`: operators of equal precedence go left to right, so this is `(v*9)/5`. `v*9` is a float64 multiplication and there is no integer trap. Writing `9/5*v + 32` instead computes `9/5` first, and both are untyped *integer* constants, so `9/5` is exactly 1 (DT-54): −40 °C would become −8 °F. That is why the −40 test is in the requirements: −40 is the one temperature that is equal in both scales, so any wrong formula shows up immediately.

**Review checklist** (issues reviewers find most often)

1. `scanner.Err()` never checked: a read error or a line over 64 KB (DT-92) is reported as "bye" with exit 0.
2. The same problem reported twice: a message printed on stderr *and* an error returned and printed by `main`. One problem, one report.
3. Magic numbers: `100` and `7` repeated in the welcome text, the range check, the loop, and the secret.
4. `run()` doing everything: move seed parsing into `newSecret(seedArg string) (int, error)`.
5. Original errors thrown away: `errors.New("bad seed")` hides *why*; `fmt.Errorf("invalid seed %q: %w", s, err)` keeps it.
6. Exported names in `package main` (`KmPerMi`): nothing imports `main`, so use `kmPerMi`.
7. `rand.IntN(maxNumber) + minNumber` is only right while `minNumber` is 1. Once values are named constants, every formula must be correct for *any* value of them: `minNumber + rand.IntN(maxNumber-minNumber+1)`.
8. The test plan and reflection answers are part of the deliverable. The path you did not run (often the *winning* path) is where the bug hides.

**Reflection answers:** (1) Each guess halves the remaining range; 2^7 = 128 ≥ 100, so 7 halvings always isolate one number. (2) Determinism: the same input gives the same output every run, so tests can assert exact results and bugs can be reproduced. (3) `math/rand/v2` for the game (predictability harms no one); `crypto/rand` for the reset link (an attacker must not be able to predict it, P-15).

@@ANSWERS 0
### Answers to the Chapter 0 prediction questions

**0.1 Q2.** (a) Compile error, rule: `invalid operation: division by zero`. (b) Panic: `integer divide by zero`, exit code 2. (c) `+Inf`. (d) Compile error, type: mismatched types untyped string and untyped int. (e) `false` — NaN equals nothing.

**0.2 Q2.** (a) `00101010` (b) `FF` (c) `8` — leading zero means octal (d) `  42|42  |` (e) `30` (10 + 10 + 10).

**0.3 Q2.** (a) 4 (260 − 256) (b) 244 (500 − 256) (c) 255 (d) compile error: constant 256 overflows uint8 (e) `uint8`.

**0.4 Q2.** (a) −56 (b) −128 (c) −128 (DT-24) (d) `-101` (e) `11111011`.

**0.4 Q3.** 37 = `0010 0101` → flip `1101 1010` → add 1 → `1101 1011`. Check: −128 + 64 + 16 + 8 + 2 + 1 = −37.

@@ANSWERS 1
### Answers to the Chapter 1 prediction questions

**1.1 Q2.** (a) `2 11` (right side evaluated with old values, DT-46) (b) `float64` (c) `int32 97` (d) `""`.

**1.2 Q2.** (a) `98` (b) compiles, i = 2 (c) compile error: truncated (d) `4` (e) A = 0, B = 10, D = 30.

**1.3 Q2.** (a) −3 (b) −1 (c) 1 (d) `true` (e) `true` (f) 3 (prints `3`).

**1.4 Q2.** (a) `10000010` (b) `11101110` (c) `01101100` (d) `01001000` (e) `00110101` (f) 5 (g) 1 (XOR).

**1.5 Q2.** (a) −3 (b) −3 (c) −3 (d) `0.9999999999999999` (e) `1e+06` (f) `0.10000000149011612`.

**1.6 Q2.** Grade for "pass" (the first true case wins). Put the strictest condition first: 90, then 75, then 35. **Q3.** `two` then `hundred`.

**1.7 Q2.** (a) `0 3 6 9` (b) no — `break` leaves only the switch (DT-68) (c) (0,0) (0,1) (0,2) (1,0) (1,1) (1,2) — at (1,2) `i*j == 2`, `break outer` ends both loops.

**1.8 Q2.** (a) 5 (b) `3 2` (c) compile error: assignment mismatch (d) panic: nil pointer dereference.

**1.8 Q4.** The iterative version. Each recursive call adds a frame; ten million frames exceed the 1 GB stack limit: `fatal error: stack overflow` (DT-39, DT-76).

**1.9 Q2.** `in loop: 10`, `in loop: 11`, `in loop: 12`, `after: 10`. **Q3.** Compiles and prints `false` (DT-80).

**1.10 Q2.** `3` then `100`. **Q3.** `go 1.21`: 3 3 3; `go 1.22`+: 0 1 2.

**1.11 Q2.** a() = 11, b() = 10, c() = 30. **Q3.** `B: 2` then `A: 1` (LIFO; A took a photo, B looks through a window).

**1.12 Q2.** `n` stays 0, an error is returned, and `abc` may remain unread on stdin, so the next `Scan` can see it again.

**1.13 Q3.** No; it returns 0–5. `rand.IntN(0)` panics. `10 + rand.IntN(91)` gives 10 to 100 inclusive.

**2.1 Q2.** (a) 1 (b) 6 (c) `true` (d) run-time panic: index out of range [3] with length 3. **Q3.** `3` — range iterates over a copy made before the loop started.
