# Chapter 13 — Geospatial Computing & Routing Algorithms

*Goal: the domain knowledge for the routing capstone.*

Navigation is one of the most impressive everyday applications of computer science: a phone finds the fastest route across a country with millions of road segments in milliseconds. This chapter builds that capability from the ground up in Go: coordinates and distances, spatial indexes, OpenStreetMap data, a compact road graph, snapping points to roads, and the routing algorithms — Dijkstra, A*, bidirectional search, and the preprocessing techniques (landmarks, contraction hierarchies) that make continental routing fast.

All code in this chapter was built and tested. Because a real OpenStreetMap extract could not be downloaded in the environment used to write this book, the tests and measurements use a **synthetic city** generated as a genuine OSM XML file (a 300 × 300 grid of streets near Pune with arterial roads, one-way streets, varied speeds, and missing segments). The parser and every algorithm treat it exactly like a real extract; run the same code on a real city's extract from Geofabrik or BBBike to see real-world numbers.

**What you will be able to do after this chapter**

- Work correctly with latitude/longitude, WGS84, great-circle distances, projections, geohashes, and polylines.
- Choose and implement spatial indexes (grids, geohash, quadtrees, R-trees; S2 and H3 concepts).
- Read OpenStreetMap data and build a directed, weighted road graph in compact CSR form.
- Snap GPS points to the network.
- Implement and compare Dijkstra, A*, and bidirectional Dijkstra, and explain ALT and contraction hierarchies.
- Return routes users can use: geometry, encoded polylines, distances, and travel times.

## Topic 13A — Geography in code

## Unit 13.1 — Coordinates

**One-line summary:** A position on Earth is a latitude (−90 to 90, north–south) and longitude (−180 to 180, east–west) in the **WGS84** datum used by GPS. Distances on a sphere use the **haversine** formula; maps flatten the Earth with **projections** that always distort something. Order matters: humans say "lat, lon", but many formats (GeoJSON, PostGIS's `ST_MakePoint`) use "lon, lat".

### Latitude, longitude, and what a degree means

- One degree of **latitude** is about 111 km everywhere.
- One degree of **longitude** is about 111 km × cos(latitude): 105 km in Pune (18.5° N), 72 km in London (51.5° N), 0 at the poles.
- Five decimal places (0.00001°) ≈ 1.1 m; seven ≈ 1.1 cm. Store coordinates as `float64` (Unit 1.5) or as fixed-point `int32` in units of 10⁻⁷ degrees (what OSM does internally — 4 bytes instead of 8, exact, and enough precision).

### Haversine distance

```go
// Point is a WGS84 coordinate in degrees.
type Point struct{ Lat, Lon float64 }

const EarthRadiusM = 6_371_008.8 // mean Earth radius in metres

func rad(d float64) float64 { return d * math.Pi / 180 }

// Haversine returns the great-circle distance in metres. It treats the Earth
// as a sphere: error up to about 0.5% versus the WGS84 ellipsoid, which is
// fine for routing heuristics and nearest-neighbour search.
func Haversine(a, b Point) float64 {
	dLat := rad(b.Lat - a.Lat)
	dLon := rad(b.Lon - a.Lon)
	h := math.Sin(dLat/2)*math.Sin(dLat/2) +
		math.Cos(rad(a.Lat))*math.Cos(rad(b.Lat))*math.Sin(dLon/2)*math.Sin(dLon/2)
	return 2 * EarthRadiusM * math.Asin(math.Min(1, math.Sqrt(h)))
}
```

Pune to Mumbai comes out at about 120 km as the crow flies (the test checks it). The `math.Min(1, …)` guards against floating-point rounding pushing the argument of `Asin` just above 1 (which would return NaN — DT-7 in a navigation app). For sub-metre accuracy over long distances, use an ellipsoidal formula (Vincenty, or Karney's algorithm in `github.com/golang/geo` or GeographicLib ports).

For short distances (a few kilometres), the **equirectangular approximation** is several times faster and accurate to centimetres — the snapping index in this chapter uses it:

```go
func Equirectangular(a, b Point) float64 {
	x := rad(b.Lon-a.Lon) * math.Cos(rad((a.Lat+b.Lat)/2))
	y := rad(b.Lat - a.Lat)
	return EarthRadiusM * math.Sqrt(x*x+y*y)
}
```

### Projections

A projection maps the sphere to a plane. **Web Mercator** (EPSG:3857), used by almost every web map, preserves angles and local shapes but inflates areas towards the poles (Greenland looks as big as Africa). **UTM** zones give nearly true metres within a 6°-wide zone — good for local engineering calculations. Rule: store and exchange WGS84 lat/lon (EPSG:4326); project only for display or for local planar computations.

### Deep & Tricky

**DT-287. The antimeridian and the poles break naive code.** *(Geometry fact)* A bounding box from longitude 179° to −179° is 2° wide, not 358°; "is this point inside the box?" with `minLon <= lon <= maxLon` fails across the 180° line (Fiji, the Aleutians, the Pacific routes of every airline). Near the poles, longitude differences mean almost nothing. Most city routing never meets these cases — but global services must.

### Mastery check

1. **Explain.** Why is one degree of longitude shorter in London than in Pune?
2. **Predict.** Roughly how far apart are two points that differ by 0.001° in latitude? In longitude, at 18.5° N?
3. **Write.** `Bearing(a, b Point) float64` returning the initial compass bearing in degrees; test with known city pairs.

## Unit 13.2 — Spatial indexing

**One-line summary:** "Which roads are near this point?" over millions of objects needs a **spatial index**. A uniform **grid** is simplest and fast for evenly spread data; **geohash** encodes cells as sortable strings; **quadtrees** adapt to density; **R-trees** index rectangles and power spatial databases; **S2** and **H3** are global hierarchical cell systems used at Google and Uber.

### Grid index

Divide the bounding box into cells of fixed size; store each object in its cell; to find the nearest object to a point, search the point's cell, then rings of cells outwards until no unvisited cell can contain anything closer than the best found. This chapter's `graph.Index` does exactly that, stored in CSR form (one flat slice of node IDs plus cell offsets, Unit 6.13):

```go
// Nearest returns the closest node and its distance in metres, searching
// rings of cells outwards until no closer node can exist.
func (ix *Index) Nearest(p geo.Point) (int32, float64) {
	r0 := min(max(int((p.Lat-ix.minLat)/ix.cellDeg), 0), ix.rows-1)
	c0 := min(max(int((p.Lon-ix.minLon)/ix.cellDeg), 0), ix.cols-1)
	best, bestD := int32(-1), math.Inf(1)
	cellM := ix.cellDeg * 111_000 * math.Cos(p.Lat*math.Pi/180) // narrowest cell side in metres
	for ring := 0; ring <= max(ix.rows, ix.cols); ring++ {
		if best >= 0 && float64(ring-1)*cellM > bestD {
			break // every unvisited cell is farther than the best found
		}
		for r := r0 - ring; r <= r0+ring; r++ {
			for c := c0 - ring; c <= c0+ring; c++ {
				if r < 0 || c < 0 || r >= ix.rows || c >= ix.cols {
					continue
				}
				if max(abs(r-r0), abs(c-c0)) != ring {
					continue // only the ring's border
				}
				cell := r*ix.cols + c
				for _, v := range ix.nodes[ix.cellStart[cell]:ix.cellStart[cell+1]] {
					if d := geo.Equirectangular(p, ix.g.Point(v)); d < bestD {
						best, bestD = v, d
					}
				}
			}
		}
	}
	return best, bestD
}
```

The stopping rule is the subtle part: a ring at distance k cells can contain points as close as (k − 1) cell widths, so the search stops only when even that lower bound exceeds the best distance. The project's test compares `Nearest` with a brute-force scan on 200 random points — a differential test (as in Unit 6's PQ tests).

Weakness: uneven data. City centres have thousands of nodes per cell; rural cells are empty and the ring search walks far.

### Geohash

A geohash interleaves the bits of longitude and latitude (alternately halving the world) and writes them in base 32. Precision 7 is a cell of about 153 m × 153 m; nearby points usually share a prefix, so a geohash string can be a database key with prefix queries (`LIKE 'te7u%'`). Edge cases: two points a metre apart across a cell boundary can have completely different hashes, so proximity queries always check the neighbouring cells too. The chapter's implementation reproduces the reference value from geohash.org's original example (`u4pruydqqvj` for 57.64911, 10.40744):

```go
const base32 = "0123456789bcdefghjkmnpqrstuvwxyz"

// Geohash encodes p with the given number of characters (precision 7 is a
// cell of about 153 m × 153 m). Nearby points usually share a prefix.
func Geohash(p Point, precision int) string {
	latLo, latHi, lonLo, lonHi := -90.0, 90.0, -180.0, 180.0
	var sb strings.Builder
	bit, ch, even := 0, 0, true
	for sb.Len() < precision {
		if even { // longitude bit
			mid := (lonLo + lonHi) / 2
			if p.Lon >= mid {
				ch |= 1 << (4 - bit)
				lonLo = mid
			} else {
				lonHi = mid
			}
		} else { // latitude bit
			mid := (latLo + latHi) / 2
			if p.Lat >= mid {
				ch |= 1 << (4 - bit)
				latLo = mid
			} else {
				latHi = mid
			}
		}
		even = !even
		if bit++; bit == 5 {
			sb.WriteByte(base32[ch])
			bit, ch = 0, 0
		}
	}
	return sb.String()
}
```

This is binary search (Unit 6.5) on two dimensions at once, and bit manipulation (Unit 1.4) to pack the result.

### Quadtrees, R-trees, S2, H3

- **Quadtree:** recursively split a square into four children until each holds at most k points. Adapts to density: deep in city centres, shallow in the countryside.
- **R-tree:** a balanced tree (a cousin of the B-tree, Unit 6.7) of nested bounding rectangles; indexes shapes (road segments, polygons) as well as points. PostGIS's GiST index is R-tree-like (Unit 9.6). Go packages: `github.com/tidwall/rtree`.
- **S2 (Google):** projects the sphere onto a cube and orders cells along a Hilbert curve, so cell IDs are 64-bit integers whose numeric ranges correspond to regions — spatial queries become integer range scans. `github.com/golang/geo/s2`.
- **H3 (Uber):** a hierarchy of hexagonal cells; hexagons have uniform neighbour distances, which suits aggregation (demand per cell) and movement analysis.

### Mastery check

1. **Explain.** Why must a nearest-neighbour search in a grid continue past the first non-empty cell?
2. **Explain.** Why do two points one metre apart sometimes have geohashes with no common prefix?
3. **Write.** A quadtree with `Insert(p)` and `Nearest(p)`, and a differential test against brute force.

## Topic 13B — Map data and the road graph

## Unit 13.3 — OpenStreetMap data

**One-line summary:** OpenStreetMap (OSM) models the world with **nodes** (points with an ID and coordinates), **ways** (ordered lists of node IDs: roads, rivers, building outlines), and **relations** (groups such as turn restrictions or bus routes), each with free-form **tags** (`highway=primary`, `oneway=yes`, `maxspeed=50`). Data comes as XML (`.osm`) or the compact binary PBF format.

### The data model in practice

```xml
<node id="123" lat="18.5204" lon="73.8567"/>
<way id="456">
  <nd ref="123"/><nd ref="124"/><nd ref="125"/>
  <tag k="highway" v="primary"/>
  <tag k="name" v="FC Road"/>
  <tag k="oneway" v="yes"/>
  <tag k="maxspeed" v="40"/>
</way>
<relation id="789">
  <member type="way" ref="456" role="from"/>
  <member type="node" ref="125" role="via"/>
  <member type="way" ref="457" role="to"/>
  <tag k="type" v="restriction"/>
  <tag k="restriction" v="no_left_turn"/>
</relation>
```

Tags are conventions, not a schema, so code must be defensive: `maxspeed` may be `50`, `50 km/h`, `30 mph`, `IN:urban`, or missing; `oneway` may be `yes`, `true`, `1`, `-1` (one way *against* the drawing direction), or `reversible`; `highway` values decide whether cars may use a way at all (`footway`, `cycleway`, and `path` are not for cars).

### Reading OSM XML in constant memory

A city extract is hundreds of megabytes of XML, a country many gigabytes — never build a DOM. Stream tokens with `encoding/xml`'s `Decoder.Token` (Unit 5.4's streaming idea for XML) and keep only what routing needs:

```go
// Read streams OSM XML with an xml.Decoder token by token, so memory holds
// only the extracted data, not the whole document tree.
func Read(r io.Reader) (*Data, error) {
	d := &Data{Nodes: map[int64]Node{}}
	dec := xml.NewDecoder(r)
	var cur *Way
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "node":
				n, err := parseNode(t.Attr)
				if err != nil {
					return nil, err
				}
				d.Nodes[n.ID] = n
			case "way":
				id, err := strconv.ParseInt(attr(t.Attr, "id"), 10, 64)
				if err != nil {
					return nil, fmt.Errorf("way id: %w", err)
				}
				cur = &Way{ID: id}
			case "nd":
				if cur != nil {
					ref, err := strconv.ParseInt(attr(t.Attr, "ref"), 10, 64)
					if err != nil {
						return nil, fmt.Errorf("way %d: nd ref: %w", cur.ID, err)
					}
					cur.Nodes = append(cur.Nodes, ref)
				}
			case "tag":
				if cur != nil {
					applyTag(cur, attr(t.Attr, "k"), attr(t.Attr, "v"))
				}
			}
		case xml.EndElement:
			if t.Name.Local == "way" && cur != nil {
				if carRoads[cur.Highway] && len(cur.Nodes) >= 2 {
					d.Ways = append(d.Ways, *cur)
				}
				cur = nil
			}
		}
	}
	return d, nil
}
```

Real numbers for the synthetic city: a **28.9 MB** OSM file with 90,000 nodes and 171,430 ways parses in **865 ms**. `encoding/xml` is not fast; production importers read **PBF** (protocol-buffer blocks, zlib-compressed, decodable in parallel — `github.com/paulmach/osm` and `github.com/qedus/osmpbf`) and keep all nodes in compact arrays, because a country has hundreds of millions of nodes (a `map[int64]Node` would need tens of gigabytes). A real pipeline does two passes: first collect the node IDs used by roads, then read only those nodes' coordinates.

### Deep & Tricky

**DT-288. Most OSM nodes are not intersections.** *(Data fact)* Ways contain many shape points to follow curves; only nodes shared by two or more ways (or way ends) are intersections where a route can turn. Keeping every shape point as a graph node makes the graph several times larger than necessary. Production builders contract degree-2 chains into single edges and keep the shape points separately for drawing the route (Unit 13.9).

### Mastery check

1. **Explain.** Why stream OSM XML token by token instead of decoding it into structs with `xml.Unmarshal`?
2. **Write.** Extend `applyTag` to handle `maxspeed` values like `IN:urban` with a lookup table, and `oneway=reversible` (treat as not routable), with a table test of tag combinations.

## Unit 13.4 — Building a road graph

**One-line summary:** A road network becomes a **directed, weighted graph**: nodes are intersections (and shape points), edges are road segments in each permitted direction, and weights are **travel times** from length and speed. Stored in **CSR** form — flat arrays of numbers — the graph is compact, cache-friendly, and nearly invisible to the garbage collector.

### From ways to edges

For each consecutive pair of nodes in a road way: compute the segment's length (haversine), its speed (`maxspeed`, or a default by road type), and its travel time; add an edge forwards unless the road is one-way backwards, and backwards unless it is one-way forwards. Then renumber the used OSM nodes 0…n−1, so every later structure is a slice indexed by node number, not a map (DT-219, Unit 6.13).

### Compressed sparse row (CSR)

Sort edges by source node; then the outgoing edges of node v are the positions `First[v]` to `First[v+1]` of the parallel arrays `To` and `Cost`:

```go
// Graph: the outgoing edges of node v are To[First[v]:First[v+1]], with
// travel times in milliseconds in Cost at the same positions.
type Graph struct {
	Lat, Lon []float64 // per node
	First    []int32   // len = nodes+1
	To       []int32   // per edge
	Cost     []uint32  // per edge, milliseconds
	MaxSpeed float64   // fastest speed in the graph, m/s (for A*)
	OSMID    []int64   // per node, for debugging
}
```

Iterating a node's neighbours is a sequential walk through two arrays. The synthetic city's 90,000 nodes and 189,370 edges take **3.3 MB** as CSR arrays (the whole live heap after loading was 4.6 MB). The same graph as `map[int64]*Node` with `[]*Edge` slices would take ten or more times as much memory and be scanned by the GC on every cycle — while CSR's pointer-free slices are not scanned at all (DT-269).

Design choices worth noticing:

- `int32` node IDs and `uint32` millisecond costs: half the memory of `int`/`uint64`, more values per cache line, and enough range (2 billion nodes; 49 days per edge).
- **Integer** costs (milliseconds, rounded **up**): exact arithmetic, no floating-point comparison trouble (Unit 1.5) in the priority queue.
- A **reverse graph** (every edge flipped) for searching backwards from the target (bidirectional search), built by counting incoming edges, prefix-summing, and filling — the same CSR construction again.

### Real-world complications

- **Turn restrictions** (OSM relations: no left turn from way A to way B via node N) and **turn costs** (U-turns, left turns across traffic) cannot be expressed on a node-based graph. Production routers use an **edge-based graph**, whose nodes are the original graph's edges, so a turn becomes an edge with its own cost — at the price of a graph about three times larger.
- **Speeds vary by time** (traffic): time-dependent edge costs, or live traffic overlays applied to a profile, with algorithms adapted accordingly.
- **Profiles:** car, bicycle, and pedestrian graphs differ in accessible roads, directions, and speeds — usually separate graphs.

### Deep & Tricky

**DT-289. Round edge times up, never down.** *(Algorithmic subtlety)* A* needs a heuristic that never overestimates the true remaining cost. If edge costs were rounded *down*, the real cost of a path could be lower than its straight-line time at maximum speed rounded normally — breaking admissibility by a millisecond here and there and occasionally returning non-optimal routes that differential tests catch only rarely. Rounding edges up and the heuristic down keeps the inequality safe.

### Mastery check

1. **Explain.** How do you find the outgoing edges of node 7 in CSR? Its incoming edges?
2. **Write.** `Stats(g)` that reports nodes, edges, average and maximum out-degree, and the number of nodes with no outgoing edges (dead ends) — then explain where the dead ends in the synthetic city come from.

## Unit 13.5 — Snapping a point to the nearest road

**One-line summary:** Users and GPS devices give coordinates that are not on the road graph. **Snapping** finds the nearest road position — at its simplest, the nearest graph node (with a spatial index, Unit 13.2); properly, the nearest point on the nearest *edge*, inserting a virtual node there. Reject points that are too far from any road.

### Node snapping

The project's `Index.Nearest(p)` returns the nearest node and its distance. The routing service rejects requests where either point is more than 500 m from any node (`422 Unprocessable Content`: the request is well-formed but cannot be served) — a user in the middle of a lake should get an error, not a route from the nearest shore 20 km away.

### Edge snapping (production)

On long roads, the nearest *node* can be far from the nearest *road*: a point next to the middle of a 1 km segment snaps to one of its ends, 500 m away. Proper snapping projects the point onto each nearby segment (vector projection clamped to the segment, computed in a local planar approximation), picks the closest, and inserts a temporary node splitting that edge, with partial costs for both halves. Spatial indexes over segments (R-trees, or a grid storing each segment in every cell it touches) find candidates.

### Snapping GPS traces (map matching)

A sequence of noisy GPS points (a recorded trip) is matched to the most likely road path with a **hidden Markov model**: candidate roads per point are the hidden states, distance from point to road gives emission probabilities, and the plausibility of driving between candidates (route distance vs straight-line distance) gives transition probabilities; the **Viterbi** algorithm (dynamic programming, Unit 6.12) finds the best sequence. This is how ride-sharing apps compute fares and how traffic speeds are inferred.

### Mastery check

1. **Explain.** Why is snapping to the nearest node inadequate on long segments? Draw an example.
2. **Write.** `NearestOnSegment(p, a, b geo.Point) (geo.Point, float64)` using a local equirectangular projection; test with points before, beside, and after a segment.

## Topic 13C — Routing algorithms

## Unit 13.6 — Faster searches

**One-line summary:** Dijkstra (Unit 6.11) explores outward in all directions. **A\*** adds an admissible estimate of the remaining cost (straight-line distance at the maximum speed), steering the search towards the target. **Bidirectional Dijkstra** searches from both ends and stops when the frontiers meet. Measured on the synthetic city: A* settles 3.3× fewer nodes than Dijkstra on random routes.

### The router

Per-query arrays (`dist`, `prev`, `settled`) of size n would cost O(n) to reset before every query — 90,000 writes for a route that might settle 1,000 nodes. The router instead **stamps** each entry with a query number and treats entries with an old stamp as unset: an O(1) reset (DT-290). A `Router` therefore holds mutable scratch space and is not safe for concurrent use; the routing service keeps a `sync.Pool` of them (Unit 7.11).

```go
// Router owns per-query scratch space. Searches reuse it without clearing
// it, by stamping entries with a query number (O(1) reset instead of O(n)).
// A Router is not safe for concurrent use; create one per goroutine.
type Router struct {
	g, rev  *graph.Graph
	dist    [2][]uint64
	prev    [2][]int32
	stamp   [2][]uint32
	settled [2][]uint32
	query   uint32
	heaps   [2]heap
}

func (r *Router) d(side int, v int32) uint64 {
	if r.stamp[side][v] != r.query {
		return inf
	}
	return r.dist[side][v]
}
```

### Dijkstra and A* in one function

A* is Dijkstra with the priority `dist[v] + h(v)` instead of `dist[v]`, where `h` is a **lower bound** on the remaining cost. With `h ≡ 0` it *is* Dijkstra:

```go
// Dijkstra is the baseline: expand nodes in order of travel time.
func (r *Router) Dijkstra(src, dst int32) (Result, error) {
	return r.astar(src, dst, func(int32) uint64 { return 0 })
}

// AStar adds a lower bound on the remaining time: straight-line distance
// at the fastest speed in the graph. It never overestimates (admissible),
// so the result is still optimal, but far fewer nodes are settled.
func (r *Router) AStar(src, dst int32) (Result, error) {
	target := r.g.Point(dst)
	maxSpeed := r.g.MaxSpeed
	return r.astar(src, dst, func(v int32) uint64 {
		return uint64(geo.Haversine(r.g.Point(v), target) / maxSpeed * 1000) // ms, rounded down
	})
}

func (r *Router) astar(src, dst int32, h func(int32) uint64) (Result, error) {
	r.begin()
	g := r.g
	r.set(0, src, 0, -1)
	r.heaps[0].push(h(src), src)
	settled := 0
	for r.heaps[0].len() > 0 {
		_, v := r.heaps[0].pop()
		if r.settled[0][v] == r.query {
			continue // stale heap entry
		}
		r.settled[0][v] = r.query
		settled++
		if v == dst {
			return Result{Nodes: r.path(src, dst), DurationMs: r.d(0, dst), Settled: settled}, nil
		}
		dv := r.d(0, v)
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			nd := dv + uint64(g.Cost[e])
			if nd < r.d(0, w) {
				r.set(0, w, nd, v)
				r.heaps[0].push(nd+h(w), w)
			}
		}
	}
	return Result{Settled: settled}, ErrNoRoute
}
```

Why A* stays optimal: if `h` never overestimates (no road is faster than the fastest road in a straight line), the target cannot be popped before every cheaper path has been considered. The cost: one haversine (trigonometry) per pushed node.

### Bidirectional Dijkstra

```go
// Bidirectional runs Dijkstra forwards from src and backwards (on the
// reversed graph) from dst, alternating, and stops when the two searches
// can no longer improve the best meeting point.
func (r *Router) Bidirectional(src, dst int32) (Result, error) {
	r.begin()
	gs := [2]*graph.Graph{r.g, r.rev}
	r.set(0, src, 0, -1)
	r.set(1, dst, 0, -1)
	r.heaps[0].push(0, src)
	r.heaps[1].push(0, dst)
	best, meet := uint64(inf), int32(-1)
	settled := 0
	for r.heaps[0].len() > 0 || r.heaps[1].len() > 0 {
		// Stop when the smallest keys on both sides sum to at least best.
		if best != inf && r.heaps[0].minKey()+r.heaps[1].minKey() >= best {
			break
		}
		side := 0
		if r.heaps[1].len() > 0 && (r.heaps[0].len() == 0 || r.heaps[1].minKey() < r.heaps[0].minKey()) {
			side = 1
		}
		_, v := r.heaps[side].pop()
		if r.settled[side][v] == r.query {
			continue
		}
		r.settled[side][v] = r.query
		settled++
		dv := r.d(side, v)
		g := gs[side]
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			nd := dv + uint64(g.Cost[e])
			if nd < r.d(side, w) {
				r.set(side, w, nd, v)
				r.heaps[side].push(nd, w)
			}
			if other := r.d(1-side, w); other != inf && nd+other < best {
				best, meet = nd+other, w
			}
		}
	}
	...
}
```

Two searches of radius r/2 explore about half the area of one search of radius r (area grows with the square of the radius in a planar network). The **stopping rule** is the classic trap: stopping at the first node settled by both sides can return a suboptimal route; the correct rule is to stop when `minKey(forward) + minKey(backward) ≥ best` (DT-291).

### Measured

On the synthetic city (90,000 nodes, 189,370 edges), 200 random routable pairs, Go 1.24 on a 2-vCPU x86 server:

| Algorithm | Time per query | Nodes settled per query |
| --- | --- | --- |
| Dijkstra | 4.56 ms | 44,834 |
| A* (haversine heuristic) | 2.75 ms | 13,772 |
| Bidirectional Dijkstra | 3.34 ms | 30,713 |

A* settles **3.3×** fewer nodes but is only **1.7×** faster: each pushed node pays for a haversine with five trigonometric functions. (An equirectangular heuristic, or precomputing each node's projected x/y once, makes it cheaper — Extension 1.) Bidirectional Dijkstra helps less here than on real road networks, because a dense grid's one-way streets make the backward search's frontier irregular. Every algorithm returned **exactly the same travel time** on 300 random pairs in the correctness test — the property that matters most.

### Deep & Tricky

**DT-290. Resetting O(n) arrays per query can cost more than the query.** *(Performance)* A short route in a large graph settles a few hundred nodes; clearing `dist` arrays of 10 million entries costs milliseconds per query. Generation stamps (store the query number with each entry) or a list of touched entries to reset afterwards make the reset proportional to the work actually done.

**DT-291. Bidirectional search must not stop at the first meeting node.** *(Algorithmic subtlety)* The first node settled by both searches is not necessarily on the shortest path. Keep the best `dist_f(u) + cost(u,w) + dist_b(w)` seen while relaxing edges, and stop only when the two queues' minimum keys together cannot beat it. The project's differential test against plain Dijkstra on 300 pairs is what gives confidence in this code.

### Mastery check

1. **Explain.** Why does A* remain optimal with an admissible heuristic, and what goes wrong with an inadmissible one?
2. **Explain.** Why did A* settle 3.3× fewer nodes but run only 1.7× faster?
3. **Write.** Bidirectional A* is subtle (the two heuristics must be made consistent); research the "average potential" method and implement it, with the differential test as your safety net.

## Unit 13.7 — Preprocessing for speed

**One-line summary:** For continental graphs (tens of millions of nodes), even A* settles too many nodes per query. **Preprocessing** spends minutes or hours once to make each query take microseconds to milliseconds: **ALT** precomputes distances to a few landmarks for a much better A* heuristic; **contraction hierarchies (CH)** add shortcut edges so a bidirectional search only ever goes "upwards" through a node ordering and settles a few hundred nodes.

### ALT: A*, Landmarks, Triangle inequality

Pick a few (8–16) **landmarks**, usually on the edge of the map. Precompute the travel time from every node to every landmark and from every landmark to every node (two Dijkstra runs per landmark on the full graph). By the triangle inequality, for any node v, target t, and landmark L:

```
dist(v, t) ≥ dist(L, t) − dist(L, v)
dist(v, t) ≥ dist(v, L) − dist(t, L)
```

The maximum of these bounds over all landmarks is an admissible heuristic that is far tighter than straight-line distance, because it knows about the actual road network (rivers, missing bridges, one-way systems). Memory: 2 × landmarks × nodes distances (for 10 million nodes and 16 landmarks, about 1.3 GB as `uint32`). Typical speed-up over Dijkstra: 10–50×. ALT also adapts easily to changing weights (only landmark distances need recomputing).

### Contraction hierarchies

1. **Order** the nodes by importance (heuristics: edge difference, how many shortcuts contracting it would add, its depth; small residential nodes first, motorway junctions last).
2. **Contract** nodes in that order: remove node v, and for every pair of neighbours u → v → w whose shortest path goes through v, add a **shortcut** edge u → w with the combined cost (a small local "witness search" checks whether another path is as short; if so, no shortcut is needed).
3. **Query:** a bidirectional Dijkstra in which each side only relaxes edges leading to *higher-ranked* nodes. Both searches climb towards the important roads and meet near the top of the hierarchy. On continental road networks, a query settles **a few hundred nodes** and takes well under a millisecond — thousands of times faster than Dijkstra.
4. **Unpack** shortcuts recursively (each remembers the node it bypassed) to recover the full path.

CH is the basis of OSRM, GraphHopper, and many production routers. Its weakness is changing weights: live traffic requires re-contraction, which led to **customisable** variants (CCH, CRP/multi-level Dijkstra) that separate a slow metric-independent preprocessing from a fast per-metric customisation.

### Choosing

| Approach | Preprocessing | Memory | Query (country-scale) | Weight changes |
| --- | --- | --- | --- | --- |
| Dijkstra / A* | none | graph only | 100s of ms – seconds | instant |
| ALT | minutes | + landmark tables | 10s of ms | recompute landmarks |
| Contraction hierarchies | minutes – hours | + shortcuts (~graph size) | < 1 ms | re-contract (or CCH) |

For a city (the capstone's scale), A* with a good heuristic is often enough; CH is the natural next step and the capstone's stretch goal.

### Mastery check

1. **Explain.** Use the triangle inequality to explain why landmark bounds never overestimate.
2. **Explain.** Why does a CH query only need to go "upwards"? What guarantees that the shortest path is found?
3. **Write.** Implement ALT with 8 landmarks chosen by the "farthest" heuristic (each new landmark is the node farthest from those already chosen). Report settled nodes vs A* on the synthetic city, with the differential test.

## Topic 13D — Engineering the graph

## Unit 13.8 — Compact graph layouts

**One-line summary:** At country scale, memory layout decides whether routing fits in RAM and how fast it runs. Use flat arrays of small integers (CSR), number nodes so that nearby nodes have nearby IDs (locality), avoid pointers, and store the preprocessed graph in a file that can be **memory-mapped** for instant startup.

### Techniques

- **Small types:** `int32` IDs, `uint32` costs, coordinates as `int32` fixed-point (10⁻⁷ degrees) instead of `float64` — the 90,000-node graph's coordinates would shrink from 1.44 MB to 0.72 MB.
- **Struct of arrays** (Unit 6.13): the search loop touches only `First`, `To`, and `Cost`; coordinates are in separate arrays, used only by A* and for output.
- **Node ordering for locality:** renumber nodes along a space-filling curve (Hilbert or Z-order, the idea behind geohash and S2) or in BFS/DFS order, so a node's neighbours tend to be stored nearby. The search then reads memory in mostly sequential runs — the 13× row/column-major lesson of Unit 6.13, applied to graphs. Real routers report 20–50% faster queries from reordering alone.
- **No pointers:** the GC never scans the graph (DT-269); a 2 GB graph costs the GC nothing per cycle.

### Memory-mapped graph files

Building a large graph takes minutes; loading it should not. Write the arrays to a file in a fixed binary layout (a header with counts and offsets, then each array, aligned — Unit 5.5's `encoding/binary` ideas), then at startup **memory-map** the file (`syscall.Mmap` on Unix, `golang.org/x/exp/mmap` for read-only access) and view the mapped bytes as typed slices with `unsafe.Slice` (Unit 10.10). Startup becomes instant (pages are loaded lazily as queries touch them), several processes share one copy of the graph in the OS page cache, and a new graph is deployed by writing a new file and switching to it.

The risks are exactly those of Unit 10.10: endianness and alignment must match the file format, and a truncated or corrupted file must be detected (checksums, a magic number and version in the header) *before* any slice is created over it.

### Mastery check

1. **Explain.** Why does renumbering nodes along a space-filling curve speed up Dijkstra without changing a single algorithmic step?
2. **Write.** `WriteGraph(w io.Writer, g *Graph)` and `ReadGraph(r io.Reader) (*Graph, error)` with a header (magic, version, counts, CRC32), little-endian arrays, and tests including a truncated file. (Use plain reading first; memory-mapping is the extension.)

## Unit 13.9 — Routes for users

**One-line summary:** A route is useful only when presented well: the sequence of nodes becomes **geometry** (coordinates, including shape points), encoded compactly as a **polyline**; plus total **distance** and **travel time**, turn-by-turn **instructions**, and sensible handling of the start and end (snapping distances).

### Geometry and polylines

The node path converts to coordinates (`route.Geometry`). Sending thousands of coordinate pairs as JSON numbers is wasteful; **Google's encoded polyline format** stores each coordinate as the difference from the previous one, scaled to integers (1e-5 degrees), zig-zag encoded, in 5-bit chunks mapped to printable characters:

```go
// EncodePolyline encodes points in Google's polyline format (precision 1e5),
// the compact string format most map clients accept.
func EncodePolyline(pts []Point) string {
	var sb strings.Builder
	var pLat, pLon int64
	for _, p := range pts {
		lat := int64(math.Round(p.Lat * 1e5))
		lon := int64(math.Round(p.Lon * 1e5))
		encodeSigned(&sb, lat-pLat)
		encodeSigned(&sb, lon-pLon)
		pLat, pLon = lat, lon
	}
	return sb.String()
}

func encodeSigned(sb *strings.Builder, v int64) {
	u := uint64(v << 1)
	if v < 0 {
		u = ^u // zig-zag: small negative numbers become small positive ones
	}
	for u >= 0x20 {
		sb.WriteByte(byte((0x20 | (u & 0x1f)) + 63))
		u >>= 5
	}
	sb.WriteByte(byte(u + 63))
}
```

The test reproduces Google's documented example exactly (`_p~iF~ps|U_ulLnnqC_mqNvxq\`@` for three points). Notice the techniques from earlier chapters: delta encoding, two's complement and bit manipulation (Units 0.4, 1.4), variable-length integers (like `binary.AppendUvarint`, Unit 5.5).

### Distance, time, instructions

- **Travel time** is the route's cost (already computed); **distance** sums segment lengths (`route.LengthM`).
- **Turn-by-turn instructions** come from the angles between consecutive segments (bearing changes, Unit 13.1's exercise), road names from the OSM ways (keep a way index per edge), and road-class changes ("merge onto the motorway"). Most of the work is presentation logic and localisation.
- **ETAs** should add realistic penalties the graph lacks (turns, traffic lights), or be calibrated against historical trip data.

### Deep & Tricky

**DT-292. Rounding in polyline encoding accumulates if you encode absolute values carelessly.** *(Format subtlety)* The format encodes *differences* of rounded integer coordinates. Computing differences of the unrounded floats and rounding each difference instead lets rounding errors accumulate along the line, drifting long routes off the road. Round each absolute coordinate first, then take integer differences — as the code above does.

### Mastery check

1. **Explain.** Why does the polyline format use differences and zig-zag encoding?
2. **Write.** `DecodePolyline(s string) ([]Point, error)` and a property-based round-trip test (encode random points rounded to 1e-5, decode, compare exactly).

## Chapter 13 Project — Point-to-point routing on a city's OSM data

**Goal:** build a working router from an OSM extract: parse the data, build a CSR road graph with one-way streets and speeds, snap coordinates to the network, and answer fastest-route queries with Dijkstra, A*, and bidirectional Dijkstra — proving they agree, and measuring how much work each does.

### Requirements

1. `geo`: haversine, equirectangular distance, geohash, polyline encoding — each tested against published reference values.
2. `osm`: streaming XML reader keeping car-accessible roads, `oneway` (including `-1`), `maxspeed` (including mph), names.
3. `graph`: CSR graph with `int32` node IDs and `uint32` millisecond costs rounded up; a reverse graph; a grid spatial index with an exact nearest-node search (tested against brute force).
4. `route`: Dijkstra, A*, and bidirectional Dijkstra sharing one `Router` with O(1) per-query reset; a specialised heap; results with path, duration, and settled-node count.
5. Tests: all three algorithms return identical durations on at least 300 random pairs, and the returned path's edge costs sum to the reported duration.
6. A benchmark comparing time and settled nodes per algorithm on a large city.
7. `cmd/gencity` to generate test cities (or use a real extract: convert PBF to XML with `osmium cat city.osm.pbf -o city.osm`).

### Reference solution

All the code for `geo`, `osm`, `graph`, and `route` appears in the units above: `Haversine`, `Equirectangular`, `Geohash`, and `EncodePolyline` (Units 13.1, 13.2, 13.9); `osm.Read` (Unit 13.3) with this tag handling:

```go
func applyTag(w *Way, k, v string) {
	switch k {
	case "highway":
		w.Highway = v
	case "name":
		w.Name = v
	case "oneway":
		switch v {
		case "yes", "true", "1":
			w.OneWay = 1
		case "-1", "reverse":
			w.OneWay = -1
		}
	case "maxspeed":
		// "50", "50 km/h", or "30 mph"
		f := strings.Fields(v)
		if len(f) > 0 {
			if n, err := strconv.Atoi(f[0]); err == nil {
				if len(f) > 1 && f[1] == "mph" {
					n = n * 1609 / 1000
				}
				w.MaxSpeed = n
			}
		}
	}
	if w.Highway == "motorway" && w.OneWay == 0 {
		w.OneWay = 1 // motorways are one-way by convention unless tagged otherwise
	}
}
```

…the graph builder:

```go
// Build turns OSM ways into a directed graph. Only nodes used by roads are
// kept, renumbered 0..n-1 (slices instead of maps from here on, Unit 6.13).
func Build(d *osm.Data) (*Graph, error) {
	idx := map[int64]int32{}
	g := &Graph{}
	node := func(id int64) (int32, error) {
		if i, ok := idx[id]; ok {
			return i, nil
		}
		n, ok := d.Nodes[id]
		if !ok {
			return 0, fmt.Errorf("way refers to missing node %d", id)
		}
		i := int32(len(g.Lat))
		idx[id] = i
		g.Lat = append(g.Lat, n.Lat)
		g.Lon = append(g.Lon, n.Lon)
		g.OSMID = append(g.OSMID, id)
		return i, nil
	}
	var edges []edge
	for _, w := range d.Ways {
		kmh := w.MaxSpeed
		if kmh == 0 {
			kmh = defaultSpeed[w.Highway]
		}
		if kmh == 0 {
			kmh = 30
		}
		mps := float64(kmh) / 3.6
		g.MaxSpeed = max(g.MaxSpeed, mps)
		for i := 0; i+1 < len(w.Nodes); i++ {
			a, err := node(w.Nodes[i])
			if err != nil {
				return nil, err
			}
			b, err := node(w.Nodes[i+1])
			if err != nil {
				return nil, err
			}
			ms := uint32(math.Ceil(geo.Haversine(g.Point(a), g.Point(b)) / mps * 1000))
			if w.OneWay >= 0 {
				edges = append(edges, edge{a, b, ms})
			}
			if w.OneWay <= 0 {
				edges = append(edges, edge{b, a, ms})
			}
		}
	}
	slices.SortFunc(edges, func(x, y edge) int { return int(x.from) - int(y.from) })
	n := len(g.Lat)
	g.First = make([]int32, n+1)
	g.To = make([]int32, len(edges))
	g.Cost = make([]uint32, len(edges))
	for i, e := range edges {
		g.First[e.from+1]++
		g.To[i], g.Cost[i] = e.to, e.cost
	}
	for v := range n {
		g.First[v+1] += g.First[v]
	}
	return g, nil
}
```

…the reverse graph:

```go
// Reverse returns the graph with every edge flipped (for searching backwards
// from the target, as bidirectional Dijkstra does).
func (g *Graph) Reverse() *Graph {
	n := g.NumNodes()
	r := &Graph{Lat: g.Lat, Lon: g.Lon, OSMID: g.OSMID, MaxSpeed: g.MaxSpeed,
		First: make([]int32, n+1), To: make([]int32, len(g.To)), Cost: make([]uint32, len(g.Cost))}
	for v := range n {
		for e := g.First[v]; e < g.First[v+1]; e++ {
			r.First[g.To[e]+1]++
		}
	}
	for v := range n {
		r.First[v+1] += r.First[v]
	}
	next := slices.Clone(r.First[:n])
	for v := range n {
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			r.To[next[w]], r.Cost[next[w]] = int32(v), g.Cost[e]
			next[w]++
		}
	}
	return r
}
```

…and the specialised heap used by the router:

```go
// heap is a binary min-heap of (key, node) specialised for speed: no
// interfaces, no closures, no generics in the hot loop (Unit 10.8).
type heap struct {
	keys  []uint64
	nodes []int32
}

func (h *heap) push(k uint64, v int32) {
	h.keys = append(h.keys, k)
	h.nodes = append(h.nodes, v)
	i := len(h.keys) - 1
	for i > 0 {
		p := (i - 1) / 2
		if h.keys[p] <= h.keys[i] {
			break
		}
		h.keys[p], h.keys[i] = h.keys[i], h.keys[p]
		h.nodes[p], h.nodes[i] = h.nodes[i], h.nodes[p]
		i = p
	}
}

func (h *heap) pop() (uint64, int32) {
	k, v := h.keys[0], h.nodes[0]
	n := len(h.keys) - 1
	h.keys[0], h.nodes[0] = h.keys[n], h.nodes[n]
	h.keys, h.nodes = h.keys[:n], h.nodes[:n]
	i := 0
	for {
		l, s := 2*i+1, i
		if l < n && h.keys[l] < h.keys[s] {
			s = l
		}
		if l+1 < n && h.keys[l+1] < h.keys[s] {
			s = l + 1
		}
		if s == i {
			return k, v
		}
		h.keys[s], h.keys[i] = h.keys[i], h.keys[s]
		h.nodes[s], h.nodes[i] = h.nodes[i], h.nodes[s]
		i = s
	}
}
```

(Keys and nodes in two parallel slices rather than a slice of structs: a struct-of-arrays layout, Unit 6.13 — the comparisons in `pop` touch only the keys.)

### The decisive test

```go
// All three algorithms must agree on the optimal travel time.
func TestAlgorithmsAgree(t *testing.T) {
	g, rev := loadCity(t, 60)
	r := New(g, rev)
	rnd := rand.New(rand.NewPCG(1, 2))
	n := int32(g.NumNodes())
	agreed, noRoute := 0, 0
	for range 300 {
		s, d := rnd.Int32N(n), rnd.Int32N(n)
		a, errA := r.Dijkstra(s, d)
		b, errB := r.AStar(s, d)
		c, errC := r.Bidirectional(s, d)
		if (errA == nil) != (errB == nil) || (errA == nil) != (errC == nil) {
			t.Fatalf("%d->%d: errors differ: %v %v %v", s, d, errA, errB, errC)
		}
		if errA != nil {
			noRoute++
			continue
		}
		if a.DurationMs != b.DurationMs || a.DurationMs != c.DurationMs {
			t.Fatalf("%d->%d: durations differ: dijkstra %d, A* %d, bidirectional %d", s, d, a.DurationMs, b.DurationMs, c.DurationMs)
		}
		// the returned path must really have that duration
		if got := pathCost(g, c.Nodes); got != c.DurationMs {
			t.Fatalf("%d->%d: bidirectional path costs %d, reported %d", s, d, got, c.DurationMs)
		}
		agreed++
	}
	t.Logf("%d routes agreed, %d pairs unreachable", agreed, noRoute)
}
```

Result: `300 routes agreed, 0 pairs unreachable`. A plain Dijkstra is easy to get right; the faster algorithms are where subtle bugs hide (DT-289, DT-291) — so the simple one becomes the **oracle** for the clever ones. This differential-testing technique is how production routing engines are validated.

### Real measurements (summary)

- 28.9 MB OSM XML → 90,000 nodes, 189,370 edges, parsed in 865 ms, built in 68 ms, **3.3 MB** of graph arrays.
- Per query on random pairs: Dijkstra 4.56 ms / 44,834 settled; A* 2.75 ms / 13,772; bidirectional 3.34 ms / 30,713.

### Review checklist

- Do all algorithms agree on hundreds of random pairs, including unreachable ones?
- Are edge costs rounded up and the heuristic rounded down (DT-289)?
- Is per-query reset O(work), not O(n) (DT-290)?
- Does the nearest-node search match brute force?
- Does a `oneway=-1` way produce edges only in the reverse direction? (Add a unit test with a hand-written three-node OSM snippet.)

### Extensions

1. Make A*'s heuristic cheaper: precompute each node's local planar x, y in metres once, and use Euclidean distance on them. Measure the speed-up.
2. Implement ALT (Unit 13.7's exercise) and contraction hierarchies, validating both with the differential test.
3. Download a real city extract (Geofabrik provides country and region files; BBBike provides city cuts), convert it, and report the same measurements. Compare graph size, settled nodes, and query times with the synthetic city.

## Answers to the Chapter 13 prediction questions

**13.1 Q2.** 0.001° of latitude ≈ 111 m. 0.001° of longitude at 18.5° N ≈ 111 m × cos(18.5°) ≈ 105 m.
