# Chapter 12 — Distributed Systems & System Design

*Goal: design systems that keep working when parts fail.*

Once a system has more than one process — two instances behind a load balancer, a service and its database, a producer and a consumer — it is a distributed system, and it inherits a set of problems that no amount of careful single-machine code can remove: messages are lost or duplicated, clocks disagree, any call can time out with no way to know whether it happened, and parts fail independently. This chapter gives you the concepts and patterns professionals use to build reliable systems from unreliable parts, and a method for system design.

The chapter's project is real and was run against PostgreSQL under injected failures: an event-driven order pipeline in which **162 calls to a flaky payment gateway** — with transient errors, retries, and simulated crashes — produced **exactly 90 charges, 90 shipments, and 10 compensating cancellations**.

**What you will be able to do after this chapter**

- Explain partial failure, latency, and partitions, and why "exactly once" delivery is impossible while exactly-once *effects* are achievable.
- Reason about time and ordering with logical clocks.
- Explain replication, partitioning, consistent hashing, CAP/PACELC, consistency models, and Raft at a working level.
- Build messaging with the outbox pattern, idempotent consumers, retries with backoff and jitter, dead-letter queues, and sagas.
- Apply reliability patterns (timeouts, circuit breakers, bulkheads, rate limiting, load balancing) and architecture patterns (CQRS, event sourcing).
- Run a structured system-design process with estimates and failure analysis.

## Topic 12A — Fundamentals

## Unit 12.1 — Why distributed systems are hard

**One-line summary:** In a distributed system, a request can succeed, fail, or **neither as far as you can tell** (a timeout). Components fail independently and partially, latency is variable and sometimes huge, and the network can split the system into groups that cannot talk to each other. Every design must say what happens in each case.

### The fallacies

Engineers new to distributed systems tend to assume (the "fallacies of distributed computing"): the network is reliable, latency is zero, bandwidth is infinite, the network is secure, topology does not change, there is one administrator, transport cost is zero, the network is homogeneous. Each false assumption is a class of outage.

### The timeout problem

The shortener calls a database; the payment service calls a bank. The call times out after 2 seconds. Did the bank charge the card? **You cannot know.** The request may have been lost on the way, processed with the reply lost, or still be in progress. Three responses:

1. **Retry** — risks doing it twice unless the operation is **idempotent** (Unit 8.3, Unit 12.7).
2. **Give up** — risks never doing it.
3. **Ask** — query the other side's state later ("did order 42 get charged?"), if it supports that.

Every call that crosses the network must be designed for all three outcomes. This is the single most important idea in the chapter.

### Partial failure, latency, partitions

- **Partial failure:** one of five replicas is slow, one disk is full, one region is down. The system is neither up nor down — it is degraded, and code must handle it.
- **Latency is a distribution:** p50 1 ms, p99 50 ms, p99.9 2 s. A request that calls 100 services in parallel almost certainly hits someone's p99 ("tail at scale"). Timeouts, hedged requests, and fewer dependencies help.
- **Partitions:** a network fault splits nodes into groups. Each group may believe the others are dead. If both groups keep accepting writes, they diverge ("split brain"). Unit 12.4 is about choosing what to do.

### Deep & Tricky

**DT-281. Exactly-once *delivery* is impossible; exactly-once *effects* are not.** *(Theorem + practice)* With message loss and crashes, a sender must retry, so a receiver may see duplicates; or it must not retry, and may lose messages. Systems that advertise "exactly once" achieve exactly-once **processing**: at-least-once delivery plus idempotent handling (deduplication or naturally idempotent operations). The project does exactly this.

### Mastery check

1. **Explain.** A client sends `POST /payments` and gets a timeout. List what may have happened and what the client should do in each case.
2. **Explain.** Why does calling 100 backends in parallel make the p99 of the whole request much worse than any one backend's p99?

## Unit 12.2 — Time and ordering

**One-line summary:** Clocks on different machines disagree and can jump, so wall-clock timestamps cannot reliably order events across machines. **Logical clocks** (Lamport clocks, vector clocks) capture the "happened-before" order that matters, and Unit 7.7's happens-before idea reappears at the scale of networks.

### Physical clocks

Each machine's clock drifts (parts per million), NTP corrects it periodically (possibly jumping backwards), and leap seconds and virtualisation add surprises. Typical skew between well-synchronised servers is milliseconds; badly configured ones can be off by minutes. Consequences:

- "Last write wins" by timestamp can lose the *actual* last write if its machine's clock is behind.
- A lease ("I own this lock until 12:00:05") is unsafe if clocks disagree about when 12:00:05 is.
- Within one process, measure durations with the monotonic clock (Unit 5.6); across processes, do not compare raw timestamps for correctness.

(Google's Spanner uses GPS and atomic clocks to bound uncertainty and *waits out* the uncertainty interval before committing — an expensive, hardware-assisted solution that shows how hard the problem is.)

### Lamport clocks

Each process keeps a counter. Increment it for each local event; send it with each message; on receiving, set it to `max(local, received) + 1`. If event A happened before event B (same process earlier, or A is a send and B the matching receive, transitively), then `L(A) < L(B)`. The converse does not hold: `L(A) < L(B)` does not prove causality.

```go
type Lamport struct {
	mu sync.Mutex
	t  uint64
}

func (l *Lamport) Tick() uint64 { l.mu.Lock(); defer l.mu.Unlock(); l.t++; return l.t }

func (l *Lamport) Observe(remote uint64) uint64 {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.t = max(l.t, remote) + 1
	return l.t
}
```

Tie-breaking by process ID gives a total order consistent with causality — enough for many replication and locking algorithms.

### Vector clocks

Each process keeps a vector of counters, one per process. They can tell "A before B", "B before A", or "**concurrent**" — which is exactly what you need to detect conflicting concurrent updates (two people edited the same document offline). Dynamo-style databases and collaborative editors use them or their relatives (version vectors, CRDTs).

### Deep & Tricky

**DT-282. Database-generated IDs and timestamps do not order events across services.** *(Practice)* `created_at` from two services' clocks or two databases' sequences cannot be merged into a reliable global order. When order matters, give events a sequence from a single authority (one partition of a log, Unit 12.6), or use logical clocks, or design so that order does not matter (commutative operations like counters).

### Mastery check

1. **Explain.** Why can last-write-wins by wall-clock time lose the newest update?
2. **Write.** Simulate three processes exchanging messages with Lamport clocks; print each event's clock and verify that every receive has a larger clock than its send.

## Topic 12B — Distributing data

## Unit 12.3 — Replication and partitioning

**One-line summary:** **Replication** keeps copies of the same data on several machines for availability and read scaling; **partitioning (sharding)** splits data across machines for capacity and write scaling. **Consistent hashing** assigns keys to partitions so that adding or removing a node moves only a small fraction of keys.

### Replication

- **Leader–follower (primary–replica):** one leader accepts writes and streams changes to followers, which serve reads. PostgreSQL streaming replication, MySQL, most systems. **Synchronous** replication waits for followers before acknowledging (no data loss on leader failure, slower writes); **asynchronous** does not (fast, but the last writes can be lost on failover, and followers lag — **replication lag**: a user writes, then reads from a follower and does not see their own write).
- **Multi-leader:** several nodes accept writes (multi-region setups); concurrent writes conflict and need resolution.
- **Leaderless (Dynamo-style):** clients write to and read from several replicas; with N replicas, writing to W and reading from R where R + W > N guarantees overlap (quorums). Cassandra, DynamoDB's ancestry.

Common read-after-write fix: read from the leader for a short time after a user's own write, or carry a "minimum log position" with the session.

### Partitioning

Split data by key: **range partitioning** (keys a–f on node 1, g–m on node 2: good for range scans, prone to hot spots) or **hash partitioning** (hash(key) mod N: even spread, no range scans). Choose the partition key so that the common queries hit one partition and load spreads evenly. A viral short link or a celebrity's account is a **hot key** that no partitioning scheme spreads by itself — it needs caching (Unit 9.7), replication of that key, or splitting the key (sharded counters).

### Consistent hashing

With `hash(key) % N`, changing N from 4 to 5 moves about 80% of keys — a disaster for caches. **Consistent hashing** places nodes and keys on a ring of hash values; each key belongs to the next node clockwise. Adding a node moves only the keys between it and its predecessor (about 1/N of them). **Virtual nodes** (each server placed at many points) even out the load.

```go
type Ring struct {
	points []uint64          // sorted hash points
	owner  map[uint64]string // point -> node
}

func NewRing(nodes []string, vnodes int) *Ring {
	r := &Ring{owner: map[uint64]string{}}
	for _, n := range nodes {
		for i := range vnodes {
			h := hash64(fmt.Sprintf("%s#%d", n, i))
			r.points = append(r.points, h)
			r.owner[h] = n
		}
	}
	slices.Sort(r.points)
	return r
}

func (r *Ring) Node(key string) string {
	h := hash64(key)
	i, _ := slices.BinarySearch(r.points, h) // first point >= h (Unit 6.5)
	if i == len(r.points) {
		i = 0 // wrap around the ring
	}
	return r.owner[r.points[i]]
}

func hash64(s string) uint64 {
	h := fnv.New64a()
	h.Write([]byte(s))
	return h.Sum64()
}
```

Used by distributed caches (Memcached clients, Redis Cluster uses a related fixed-slot scheme), Dynamo-style databases, and load balancers that need session affinity.

### Mastery check

1. **Explain.** Why does `hash % N` move most keys when N changes, and how does consistent hashing avoid it?
2. **Write.** Test the ring above: with 4 nodes and 100 virtual nodes each, assign 100,000 keys, add a fifth node, and measure the fraction of keys that moved and the load spread. Then try 1 virtual node per server.

## Unit 12.4 — CAP / PACELC and consistency models

**One-line summary:** During a network **p**artition, a replicated system must choose between **c**onsistency (refuse some requests) and **a**vailability (answer with possibly stale or divergent data) — CAP. **E**lse, in normal operation, it trades **l**atency against **c**onsistency — PACELC. Consistency models (linearizable, sequential, causal, eventual, read-your-writes) describe precisely what clients can observe.

### CAP, properly stated

CAP is often misquoted as "pick two of three". Partitions are not optional — networks fail — so the real choice is what to do *during* a partition:

- **CP:** keep consistency; the minority side refuses writes (and maybe reads). Example: a Raft-based store (etcd, Consul), a single-leader database whose leader is unreachable.
- **AP:** stay available; both sides accept requests and reconcile later. Example: Dynamo-style stores, DNS, caches.

### PACELC

Most of the time there is no partition, and the trade-off is **latency vs consistency**: synchronously waiting for replicas (consistent, slower) or answering from the nearest copy (fast, possibly stale). Spanner is PC/EC; Cassandra with low consistency levels is PA/EL.

### Consistency models (strongest to weakest, simplified)

| Model | Guarantee | Cost |
| --- | --- | --- |
| **Linearizable** | every operation appears to take effect at one instant between its start and end; everyone sees the same order, respecting real time | coordination on every operation |
| **Sequential** | everyone sees the same order, consistent with each client's program order (not necessarily real time) | coordination |
| **Causal** | operations related by happens-before are seen in that order by everyone; concurrent ones may be seen in different orders | track dependencies (vector clocks) |
| **Read-your-writes / monotonic reads** | a client always sees its own writes, and never goes back in time | session tracking |
| **Eventual** | if writes stop, replicas converge | none during operation |

Choose per use case, not per system: account balances and inventory reservations need strong guarantees; like counts, view counters, and recommendations are fine eventually consistent. The Chapter 9 shortener's hit counts are eventually consistent (up to a second behind), deliberately.

### Mastery check

1. **Explain.** Why is "CA" (consistent and available, no partition tolerance) not a real option for a distributed system?
2. **Explain.** For a shopping cart, a seat reservation, and a "people also bought" list, which consistency model does each need, and why?

## Unit 12.5 — Consensus concepts: Raft

**One-line summary:** Consensus lets a group of machines agree on a sequence of values (a replicated log) despite failures, as long as a **majority** is alive and connected. **Raft** does it with an elected leader that replicates log entries to followers and commits an entry once a majority has stored it. etcd, Consul, CockroachDB, and many others build on it.

### The pieces of Raft

- **Terms:** time is divided into numbered terms; each has at most one leader.
- **Leader election:** followers expect regular heartbeats from the leader. A follower that hears nothing for a randomised **election timeout** (e.g. 150–300 ms) becomes a candidate, increments the term, votes for itself, and asks others for votes. A node grants at most one vote per term, and only to a candidate whose log is at least as up to date as its own. A candidate with votes from a **majority** becomes leader. Randomised timeouts make split votes rare.
- **Log replication:** clients send commands to the leader; it appends them to its log and sends them to followers. Once a **majority** has stored an entry, it is **committed**; the leader applies it to its state machine and tells followers, who apply it too. Every node applies the same commands in the same order, so they reach the same state.
- **Safety:** a committed entry is present in the log of every future leader (because any majority that elects a leader overlaps with the majority that stored the entry, and voters reject candidates with older logs).

### Majorities and fault tolerance

With 2f + 1 nodes, Raft tolerates f failures: 3 nodes tolerate 1, 5 tolerate 2. A cluster of 4 tolerates only 1 (a majority of 4 is 3), so odd sizes are used. During a partition, only the side with a majority can elect a leader and commit — Raft is CP (Unit 12.4).

### When you need it

Rarely directly. You use consensus *through* systems: etcd or ZooKeeper for configuration, leader election, and distributed locks; Kubernetes stores its state in etcd. Use `go.etcd.io/etcd/client/v3`'s `concurrency` package for leader election among your service instances rather than inventing a protocol. If you ever implement Raft, use the `etcd-io/raft` or `hashicorp/raft` libraries — correct consensus implementations take years to harden.

### Deep & Tricky

**DT-283. A distributed lock needs a fencing token.** *(Classic bug)* A client acquires a lock with a 10-second lease, pauses for 15 seconds (a GC pause, a VM migration), the lease expires, another client acquires the lock, and the first client wakes up and writes, believing it still holds the lock. The fix: the lock service issues a monotonically increasing **fencing token** with each grant, and the storage rejects writes carrying a token older than the newest it has seen.

### Mastery check

1. **Explain.** Why must a Raft candidate have an up-to-date log to win an election? What could go wrong otherwise?
2. **Explain.** Why do clusters have 3 or 5 nodes, not 4?

## Topic 12C — Communication and reliability

## Unit 12.6 — Messaging

**One-line summary:** Message queues and logs (RabbitMQ, Kafka, NATS, SQS, or a database table) decouple producers from consumers in time and load. Their delivery guarantee is usually **at least once**, so consumers must be **idempotent**. The **transactional outbox** pattern publishes events reliably together with database changes.

### Queues vs logs

- **Queue** (RabbitMQ, SQS): messages are delivered to one of several competing consumers and deleted when acknowledged. Good for distributing work.
- **Log** (Kafka, Redpanda, NATS JetStream): an append-only, partitioned, retained sequence; each consumer group tracks its own position (offset) and can replay. Order is guaranteed **within a partition**; choose the partition key (an order ID) so related events stay in order. Good for event streams many services read.

### Delivery guarantees

- **At most once:** acknowledge before processing; a crash loses the message.
- **At least once:** acknowledge after processing; a crash causes redelivery — duplicates (DT-281).
- **Exactly-once effects:** at least once + idempotent consumers (deduplicate by message ID, or make operations naturally idempotent: `SET status = 'paid' WHERE status = 'placed'`, upserts, `ON CONFLICT DO NOTHING`).

### The dual-write problem and the outbox

A service must update its database **and** publish an event. Two separate operations can half-fail: the database commit succeeds and the publish fails (event lost: downstream never ships the order), or the publish succeeds and the commit fails (an event for an order that does not exist). The **transactional outbox**: write the event into an `outbox` table **in the same database transaction** as the business change; a separate relay reads the outbox and publishes to the broker (at least once), marking rows as sent. The project goes one step further and uses the outbox table *directly as the queue*, which is a sound design for moderate volumes on PostgreSQL:

```go
// Place stores the order and its event in ONE transaction: either both
// exist or neither does. No "saved the order but lost the event".
func Place(ctx context.Context, db *pgxpool.Pool, id string, amount int64) error {
	return pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO orders (id, amount_paise) VALUES ($1, $2)`, id, amount); err != nil {
			return err
		}
		return queue.Publish(ctx, tx, "order.placed", OrderEvent{id, amount})
	})
}
```

Change data capture (Debezium reading the database's write-ahead log) is the other common way to turn database changes into events without dual writes.

### Competing consumers with `SKIP LOCKED`

```sql
SELECT id, topic, payload, attempts FROM messages
WHERE topic = $1 AND available_at <= now()
ORDER BY id
LIMIT 1
FOR UPDATE SKIP LOCKED
```

`FOR UPDATE` locks the claimed row for this transaction; `SKIP LOCKED` makes other consumers skip rows already locked instead of waiting, so many workers process different messages in parallel. If a worker crashes, its transaction rolls back, the lock is released, and another worker picks the message up — automatic redelivery.

### Deep & Tricky

**DT-284. Ordering and parallelism pull in opposite directions.** *(Design trade-off)* Strict order means one consumer at a time per ordering key; parallelism means messages can complete out of order (DT-239). Kafka resolves it with partitions (order per key, parallelism across keys). In the project's table queue, messages for one order travel on different topics in sequence, so per-order order is ensured by the workflow itself; within a topic, consumers may finish out of order — and nothing depends on it.

### Mastery check

1. **Explain.** Describe both half-failures of a dual write and how the outbox removes them.
2. **Explain.** Why does `SKIP LOCKED` give automatic redelivery when a worker crashes?

## Unit 12.7 — Reliability patterns

**One-line summary:** Every remote call gets a **timeout**; retries are only for **idempotent** operations and use **exponential backoff with jitter** and a cap; **idempotency keys** make non-idempotent operations safe to retry; **circuit breakers** stop calling a failing dependency; **bulkheads** keep one failing dependency from exhausting shared resources; **dead-letter queues** take poison messages out of the way.

### Timeouts and deadlines

Covered in Units 7.9 and 8.7: a context deadline on every call, propagated downstream. A timeout should be shorter than the caller's own deadline, leaving time to handle the failure.

### Retries with exponential backoff and jitter

Immediate retries by thousands of clients hammer a recovering service ("retry storm"). Back off exponentially and add **jitter** so clients do not retry in lockstep. "Full jitter" (a random delay between 0 and the exponential backoff) spreads load best. From the project:

```go
backoff := c.BaseBackoff << (attempts - 1)               // 1x, 2x, 4x, ...
delay := time.Duration(rand.Int64N(int64(backoff) + 1)) // full jitter: uniform in [0, backoff]
```

Rules: retry only transient failures (timeouts, 503, connection reset, serialization failures) — never 400s; cap attempts and total time; retry at **one** layer (if every layer of a five-service chain retries 3 times, one failure becomes 243 calls); and respect `Retry-After`.

### Idempotency keys

For operations that are not naturally idempotent (charging money, sending an email), the caller generates a unique key per *logical* operation and sends it with every attempt; the server stores the key with the result and returns the stored result for repeats. In the project, the payment handler uses the order ID as the gateway's idempotency key, so a redelivered message cannot charge twice — **even though the gateway call is outside the database transaction**. The test's gateway counts real charges per key: 162 calls, 90 charges, never two for one order.

### Circuit breakers

When a dependency is failing, continuing to call it wastes resources and slows every request to the timeout. A circuit breaker tracks recent failures:

- **Closed** (normal): calls go through; if failures exceed a threshold, it **opens**.
- **Open:** calls fail immediately (fast failure, perhaps a fallback), giving the dependency time to recover.
- **Half-open:** after a cool-down, a few trial calls go through; success closes the circuit, failure reopens it.

Libraries: `github.com/sony/gobreaker`. Combine with fallbacks where possible (serve cached data, degrade a feature).

### Bulkheads

Separate resource pools per dependency (separate HTTP clients with their own connection limits, separate worker pools, separate database pools for different workloads), so that one slow dependency exhausting its pool does not take down unrelated requests — like watertight compartments in a ship. The semaphore of Unit 7.10 per dependency is the simplest bulkhead.

### Dead-letter queues

A **poison message** (a payload that can never be processed) retried forever blocks progress and burns resources. After a maximum number of attempts, or immediately for permanent errors, move it to a dead-letter table or queue, alert on it, and let a human inspect and replay. The project does this; its test includes a poison message, which lands in `dead_letters` and does not disturb the 100 real orders.

### Deep & Tricky

**DT-285. A retry is a new request to a system that may already be overloaded.** *(Operations)* Retries multiply load exactly when the dependency is weakest. Retry budgets (e.g. retries may add at most 10% to normal traffic), circuit breakers, and backoff with jitter keep retries from turning a brief slowdown into a prolonged outage.

### Pattern

**P-38. At-least-once delivery + idempotent handlers + bounded retries with jittered backoff + a dead-letter queue.** *(Distributed-systems practice)*

- *Problem it solves:* lost messages, duplicated effects, retry storms, and stuck poison messages.
- *How:* publish via an outbox; consume with acknowledgement after processing; deduplicate by message ID (or make effects idempotent) in the same transaction as the effects; pass idempotency keys to external systems; retry transient errors with capped exponential backoff and full jitter; dead-letter permanent failures and exhausted retries.
- *When not to:* fire-and-forget telemetry may accept at-most-once and skip all of this.
- *Trade-off:* more tables and code, and duplicates must be designed for everywhere — in exchange for no lost work and no double charges.

### Mastery check

1. **Explain.** Why must retries happen at only one layer of a call chain?
2. **Write.** A generic `Retry(ctx, policy, f)` with capped exponential backoff, full jitter, a maximum elapsed time, and a predicate for retryable errors; test it with an injected random source and clock.

## Unit 12.8 — Traffic control

**One-line summary:** **Rate limiting** protects services and enforces fairness; the main algorithms are fixed window, sliding window, token bucket, and leaky bucket. **Load balancing** spreads requests across instances; algorithms range from round robin to least-connections and "power of two choices", and must account for health.

### Rate-limiting algorithms

| Algorithm | How | Trade-offs |
| --- | --- | --- |
| Fixed window | count requests per calendar window (per minute) | simple; allows 2× bursts at window boundaries |
| Sliding window log | keep timestamps of recent requests | exact; memory per request |
| Sliding window counter | weight the previous window's count by overlap | close to exact, cheap |
| Token bucket | tokens refill at rate r up to burst b; each request spends one | allows controlled bursts; the Chapter 11 project's limiter |
| Leaky bucket | requests drain from a queue at a fixed rate | smooths output; adds queueing delay |

Distributed limits (the same client hitting any of several instances) need shared state: Redis with an atomic script (a token bucket in Lua, or `INCR` with `EXPIRE` for fixed windows), or approximate per-instance limits of r/N. Respond with 429 and `Retry-After`; limit per API key or user, not only per IP (many users share IPs behind NAT).

### Load balancing

- **Round robin:** simple; ignores differences in load and request cost.
- **Least connections / least outstanding requests:** sends to the least busy instance; good for variable request costs.
- **Power of two choices:** pick two instances at random, send to the less loaded one. Nearly as good as global least-loaded, with no global state — used widely in modern proxies.
- **Consistent hashing:** for affinity (cache locality, sticky sessions), Unit 12.3.
- **Health:** remove instances failing readiness (Unit 11.5); slow-start new instances; eject outliers with high error rates.

L4 balancers forward TCP connections (cheap; one long-lived HTTP/2 or gRPC connection pins all its requests to one backend — DT-286); L7 balancers understand HTTP and balance individual requests, retry, and route by path.

### Deep & Tricky

**DT-286. Long-lived connections defeat connection-level load balancing.** *(Operations)* gRPC and HTTP/2 clients multiplex many requests over one connection; behind an L4 load balancer, all of a client's traffic goes to one backend, and newly added backends receive nothing. Use L7 balancing, client-side balancing (gRPC's `round_robin` policy with DNS or xDS), or periodic connection recycling (`MaxConnectionAge` on gRPC servers).

### Mastery check

1. **Explain.** Show how a fixed-window limiter of 100/minute can admit 200 requests within two seconds.
2. **Write.** A simulation comparing random assignment, round robin, and power-of-two-choices for 10 servers with random request durations; report the maximum queue length for each.

## Topic 12D — Architecture

## Unit 12.9 — Architecture patterns

**One-line summary:** Caching at scale, **CQRS** (separate models for writes and reads), **event sourcing** (store events, derive state), and **sagas** (multi-step workflows with compensating actions instead of distributed transactions) are tools for specific problems. Each adds complexity; use them when the problem demands it.

### Caching at scale

Layers (Unit 9.7) multiply: CDN → reverse-proxy cache → service cache → database cache. At scale, the risks grow: cache stampedes (singleflight, early probabilistic refresh), hot keys (local in-process caches in front of Redis), cold starts (warm caches gradually, DT-260), and consistency (invalidate via events from the outbox).

### CQRS

Command Query Responsibility Segregation separates the **write model** (normalised, enforcing invariants) from one or more **read models** (denormalised for specific queries — a search index, a reporting table), updated from events. The Chapter 9 `daily_hits` table is a tiny read model maintained alongside the write. Benefits: each side is optimised for its job and scales independently. Costs: read models are eventually consistent and there is more code and infrastructure.

### Event sourcing

Instead of storing current state, store the sequence of **events** ("OrderPlaced", "PaymentCaptured", "OrderShipped") and derive state by replaying them (with snapshots for speed). Benefits: a complete audit history, the ability to rebuild read models or fix bugs by replaying, temporal queries ("what was the balance on 1 March?"). Costs: schema evolution of events is hard (events are forever), queries need projections, and the mental model is unfamiliar. Natural for ledgers and domains where history *is* the data; overkill for most CRUD.

### Sagas

A business process spanning several services (order → payment → shipping) cannot use one database transaction, and distributed transactions (two-phase commit) are slow, fragile, and unavailable across most modern systems. A **saga** is a sequence of local transactions, each publishing an event that triggers the next; if a step fails, **compensating transactions** undo the earlier steps (refund the payment, cancel the order, release the reserved stock).

- **Choreography:** each service reacts to events (the project: `order.placed` → payment → `payment.succeeded` → shipping; `payment.failed` → cancel). Simple for short flows; hard to follow as flows grow.
- **Orchestration:** a central coordinator tells each service what to do and tracks the saga's state. Easier to understand, monitor, and change for long flows. (Workflow engines such as Temporal implement durable orchestration.)

Compensations must be idempotent and must handle "the step you are compensating may not have happened yet" (a cancellation that arrives before the payment event).

### Mastery check

1. **Explain.** Why do sagas need compensating actions instead of rollbacks?
2. **Explain.** When would you choose event sourcing, and what is the hardest long-term cost?

## Unit 12.10 — System design method

**One-line summary:** Design systems in a fixed order: clarify **requirements** (functional and non-functional), **estimate** load and storage, define **APIs** and **data models**, sketch the **architecture**, then walk through **failure modes**, trade-offs, and evolution. Write it down as a design document.

### The steps

1. **Requirements.** Functional: what users can do (shorten URLs, redirect, see stats). Non-functional, with numbers: availability (99.9% = 43 minutes of downtime a month; 99.99% = 4.3 minutes), latency (p99 redirect < 50 ms), durability, consistency needs (Unit 12.4), security and compliance. Out of scope, explicitly.
2. **Estimates (back-of-the-envelope).** Requests per second (average and peak), read/write ratio, data size per record × records × years, bandwidth, cache size for the hot set. Example for a shortener: 100 M new links/month ≈ 40 writes/s average, perhaps 400/s peak; 100:1 reads ≈ 4,000 redirects/s average, 40,000 peak; 500 bytes per link × 1.2 B links/year ≈ 600 GB/year. Round numbers to orders of magnitude; the point is to find which component is the bottleneck.
3. **APIs.** Endpoints or RPCs with request/response shapes, errors, idempotency, pagination (Unit 8.6).
4. **Data model.** Entities, keys, indexes, partition keys (Unit 9.1–9.2, 12.3), retention.
5. **High-level architecture.** Clients, load balancers, stateless services, caches, databases, queues, background workers — and why each exists. Start simple: one service and one database handle more than most people expect (thousands of requests per second on modest hardware).
6. **Deep dives** on the hardest parts (code generation without collisions, the hot-link problem, analytics at scale).
7. **Failure modes.** For every component: what if it is slow, down, or wrong? What if a whole zone fails? What do users see? How is it detected (metrics, alerts) and recovered (failover, replay, runbook)?
8. **Trade-offs and evolution.** What you chose not to do, what would change at 10× scale, what you would build next.

### Useful numbers (orders of magnitude)

| Operation | Time |
| --- | --- |
| L1 cache reference | ~1 ns |
| Main memory reference | ~100 ns |
| Read 1 MB sequentially from memory | ~10–50 µs |
| Round trip within a datacentre | ~0.5 ms |
| SSD random read | ~100 µs |
| Read 1 MB sequentially from SSD | ~0.2–1 ms |
| Round trip between continents | ~100–150 ms |

(Unit 0.5's table, extended. Exact values vary; the ratios drive designs.)

### Mastery check

1. **Explain.** Why estimate before designing? Give an example where an estimate changes the design.
2. **Write.** A two-page design document for a "notifications service" (email, SMS, push; 10 M users; per-user preferences; at most one SMS per user per minute), following the steps above, including failure modes.

## Chapter 12 Project — An event-driven order pipeline with idempotent consumers

**Goal:** build an order workflow — place an order, charge payment, ship or cancel — as a choreographed saga over a durable PostgreSQL-backed queue, with at-least-once delivery, idempotent consumers, retries with exponential backoff and full jitter, dead-lettering, and an external payment gateway called with idempotency keys. Prove its guarantees under injected failures.

### Design

```
Place ──order.placed──▶ payments ──payment.succeeded──▶ shipping
                                 └─payment.failed────▶ cancel (compensation)
```

- **`queue` package:** `messages` table as transactional outbox *and* queue; `Publish(ctx, tx, topic, v)` writes inside the caller's transaction; `Consumer` claims messages with `FOR UPDATE SKIP LOCKED`, records `(consumer, message_id)` in `processed` for idempotency, runs the handler inside a **savepoint**, deletes the message on success, and on failure records the error and reschedules with backoff and jitter, or moves it to `dead_letters`.
- **`shop` package:** `Place` writes the order and its event atomically; `PaymentHandler` charges through a `Gateway` interface with the order ID as idempotency key; `ShippingHandler` and `CancelHandler` are idempotent by construction (`ON CONFLICT DO NOTHING`, guarded status transitions).
- **The test** places 100 orders (10 to be declined) plus one poison message, runs three competing workers per topic, uses a gateway that fails transiently 30% of the time, and injects a crash *after* a handler's effects but *before* commit for every fifth message.

### Reference solution — `queue/queue.go`

```go
// Package queue is a durable message queue stored in PostgreSQL.
//
// Publishing happens inside the caller's transaction, so a message is
// stored if and only if the business change commits: the transactional
// outbox pattern, with the outbox table serving directly as the queue.
// Delivery is at least once; consumers must be idempotent.
package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand/v2"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const Schema = `
CREATE TABLE IF NOT EXISTS messages (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    topic        text        NOT NULL,
    payload      jsonb       NOT NULL,
    attempts     int         NOT NULL DEFAULT 0,
    available_at timestamptz NOT NULL DEFAULT now(),
    last_error   text
);
CREATE INDEX IF NOT EXISTS messages_ready ON messages (topic, available_at);
CREATE TABLE IF NOT EXISTS dead_letters (
    id       bigint PRIMARY KEY,
    topic    text  NOT NULL,
    payload  jsonb NOT NULL,
    attempts int   NOT NULL,
    error    text  NOT NULL,
    died_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS processed (
    consumer   text   NOT NULL,
    message_id bigint NOT NULL,
    PRIMARY KEY (consumer, message_id)
);`

// Publish stores a message in the caller's transaction.
func Publish(ctx context.Context, tx pgx.Tx, topic string, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	_, err = tx.Exec(ctx, `INSERT INTO messages (topic, payload) VALUES ($1, $2)`, topic, b)
	return err
}

// Message is one delivery. ID is stable across redeliveries.
type Message struct {
	ID       int64
	Topic    string
	Payload  []byte
	Attempts int
}

// Handler processes one message inside tx. Returning nil commits the
// message's removal together with everything the handler wrote in tx.
type Handler func(ctx context.Context, tx pgx.Tx, m Message) error

// ErrPermanent marks failures that retrying cannot fix (bad payload):
// the message goes straight to the dead-letter table.
var ErrPermanent = errors.New("permanent failure")

type Consumer struct {
	DB          *pgxpool.Pool
	Name        string // used for idempotency records
	Topic       string
	Handle      Handler
	MaxAttempts int
	BaseBackoff time.Duration
}

// Run polls for messages until ctx is done.
func (c *Consumer) Run(ctx context.Context) error {
	for {
		n, err := c.ProcessBatch(ctx, 10)
		if err != nil && ctx.Err() == nil {
			return err
		}
		if n == 0 {
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(50 * time.Millisecond):
			}
		}
	}
}

// ProcessBatch claims up to n ready messages and handles each in its own
// transaction. FOR UPDATE SKIP LOCKED lets many consumers work in parallel
// without taking the same message.
func (c *Consumer) ProcessBatch(ctx context.Context, n int) (int, error) {
	done := 0
	for range n {
		ok, err := c.processOne(ctx)
		if err != nil || !ok {
			return done, err
		}
		done++
	}
	return done, nil
}

func (c *Consumer) processOne(ctx context.Context) (bool, error) {
	tx, err := c.DB.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(context.WithoutCancel(ctx))

	var m Message
	err = tx.QueryRow(ctx, `
		SELECT id, topic, payload, attempts FROM messages
		WHERE topic = $1 AND available_at <= now()
		ORDER BY id
		LIMIT 1
		FOR UPDATE SKIP LOCKED`, c.Topic).Scan(&m.ID, &m.Topic, &m.Payload, &m.Attempts)
	if errors.Is(err, pgx.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}

	// Idempotency: if this consumer already processed this message (a
	// previous attempt committed its effects but crashed before the
	// message was deleted), skip the work.
	tag, err := tx.Exec(ctx, `INSERT INTO processed (consumer, message_id) VALUES ($1, $2)
		ON CONFLICT DO NOTHING`, c.Name, m.ID)
	if err != nil {
		return false, err
	}
	if tag.RowsAffected() == 1 {
		// Run the handler in a savepoint so a failure can be recorded
		// without losing the claim on the message.
		herr := pgx.BeginFunc(ctx, tx, func(sp pgx.Tx) error { return c.Handle(ctx, sp, m) })
		if herr != nil {
			if _, err := tx.Exec(ctx, `DELETE FROM processed WHERE consumer = $1 AND message_id = $2`, c.Name, m.ID); err != nil {
				return false, err
			}
			if err := c.fail(ctx, tx, m, herr); err != nil {
				return false, err
			}
			return true, tx.Commit(ctx)
		}
	}
	if _, err := tx.Exec(ctx, `DELETE FROM messages WHERE id = $1`, m.ID); err != nil {
		return false, err
	}
	return true, tx.Commit(ctx)
}

// fail schedules a retry with exponential backoff and full jitter, or
// moves the message to dead_letters.
func (c *Consumer) fail(ctx context.Context, tx pgx.Tx, m Message, herr error) error {
	attempts := m.Attempts + 1
	if attempts >= c.MaxAttempts || errors.Is(herr, ErrPermanent) {
		_, err := tx.Exec(ctx, `
			WITH moved AS (DELETE FROM messages WHERE id = $1 RETURNING id, topic, payload)
			INSERT INTO dead_letters (id, topic, payload, attempts, error)
			SELECT id, topic, payload, $2, $3 FROM moved`, m.ID, attempts, herr.Error())
		return err
	}
	backoff := c.BaseBackoff << (attempts - 1)              // 1x, 2x, 4x, ...
	delay := time.Duration(rand.Int64N(int64(backoff) + 1)) // full jitter: uniform in [0, backoff]
	_, err := tx.Exec(ctx, `UPDATE messages SET attempts = $2, last_error = $3,
		available_at = now() + $4 * interval '1 microsecond' WHERE id = $1`,
		m.ID, attempts, herr.Error(), delay.Microseconds())
	if err != nil {
		return fmt.Errorf("scheduling retry: %w", err)
	}
	return nil
}
```

Three details carry the correctness:

1. **Savepoint.** `pgx.BeginFunc(ctx, tx, ...)` on an existing transaction creates a *savepoint*. If the handler fails, only its writes are rolled back; the outer transaction keeps its lock on the message and records the failure (`attempts`, `available_at`) — so failures are counted even though the handler's work is undone.
2. **Idempotency record in the same transaction as the effects.** `processed(consumer, message_id)` commits together with the handler's database writes and the message deletion — all or nothing. If the process dies at any point, either everything committed (and a redelivery is impossible because the message is gone) or nothing did (and the redelivery redoes everything).
3. **External effects use idempotency keys.** The gateway call cannot join the transaction, so it can happen several times — the key makes the repeats harmless.

(Why keep the `processed` table at all, if the message is deleted in the same transaction? Because real systems often split consumption from deletion — a relay to Kafka, or handlers that call `queue.Publish` into another database — and the table makes the dedup rule explicit and testable. In this exact design it is defence in depth.)

### Reference solution — `shop/shop.go`

```go
// Package shop is a small event-driven order pipeline:
//
//	Place ──order.placed──▶ payment consumer ──payment.succeeded──▶ shipping consumer
//	                                          └─payment.failed────▶ order cancelled (compensation)
package shop

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/orders/queue"
)

const Schema = `
CREATE TABLE IF NOT EXISTS orders (
    id           text PRIMARY KEY,
    amount_paise bigint NOT NULL CHECK (amount_paise > 0),
    status       text   NOT NULL DEFAULT 'placed'
                 CHECK (status IN ('placed', 'paid', 'cancelled', 'shipped'))
);
CREATE TABLE IF NOT EXISTS shipments (
    order_id text PRIMARY KEY REFERENCES orders (id)
);`

type OrderEvent struct {
	OrderID string `json:"order_id"`
	Amount  int64  `json:"amount_paise"`
}

// Place stores the order and its event in ONE transaction: either both
// exist or neither does. No "saved the order but lost the event".
func Place(ctx context.Context, db *pgxpool.Pool, id string, amount int64) error {
	return pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO orders (id, amount_paise) VALUES ($1, $2)`, id, amount); err != nil {
			return err
		}
		return queue.Publish(ctx, tx, "order.placed", OrderEvent{id, amount})
	})
}

// Gateway is an external payment provider. Charge must be idempotent per
// key: calling it twice with the same key charges once (real providers
// support idempotency keys for exactly this reason).
type Gateway interface {
	Charge(ctx context.Context, idempotencyKey string, amount int64) (approved bool, err error)
}

var ErrDeclined = errors.New("payment declined")

// PaymentHandler charges for an order and publishes the outcome.
func PaymentHandler(gw Gateway) queue.Handler {
	return func(ctx context.Context, tx pgx.Tx, m queue.Message) error {
		var ev OrderEvent
		if err := json.Unmarshal(m.Payload, &ev); err != nil || ev.OrderID == "" {
			return fmt.Errorf("%w: bad payload: %v", queue.ErrPermanent, err)
		}
		// The order ID is the idempotency key: a redelivered message cannot
		// charge the customer twice, even though the gateway is outside our
		// database transaction.
		approved, err := gw.Charge(ctx, "order-"+ev.OrderID, ev.Amount)
		if err != nil {
			return err // transient: retried with backoff
		}
		if !approved {
			return queue.Publish(ctx, tx, "payment.failed", ev)
		}
		if _, err := tx.Exec(ctx, `UPDATE orders SET status = 'paid' WHERE id = $1 AND status = 'placed'`, ev.OrderID); err != nil {
			return err
		}
		return queue.Publish(ctx, tx, "payment.succeeded", ev)
	}
}

// ShippingHandler creates exactly one shipment per paid order.
func ShippingHandler(ctx context.Context, tx pgx.Tx, m queue.Message) error {
	var ev OrderEvent
	if err := json.Unmarshal(m.Payload, &ev); err != nil {
		return fmt.Errorf("%w: %v", queue.ErrPermanent, err)
	}
	if _, err := tx.Exec(ctx, `INSERT INTO shipments (order_id) VALUES ($1) ON CONFLICT DO NOTHING`, ev.OrderID); err != nil {
		return err
	}
	_, err := tx.Exec(ctx, `UPDATE orders SET status = 'shipped' WHERE id = $1 AND status = 'paid'`, ev.OrderID)
	return err
}

// CancelHandler is the saga's compensating action for a failed payment.
func CancelHandler(ctx context.Context, tx pgx.Tx, m queue.Message) error {
	var ev OrderEvent
	if err := json.Unmarshal(m.Payload, &ev); err != nil {
		return fmt.Errorf("%w: %v", queue.ErrPermanent, err)
	}
	_, err := tx.Exec(ctx, `UPDATE orders SET status = 'cancelled' WHERE id = $1 AND status = 'placed'`, ev.OrderID)
	return err
}
```

Status transitions are guarded (`WHERE status = 'placed'`), so applying any handler twice changes nothing the second time — naturally idempotent effects.

### Reference solution — `shop/shop_test.go` (the failure-injection test)

```go
// flakyGateway fails transiently 30% of the time, declines orders whose
// amount ends in 13, and remembers keys so a repeated key charges once.
type flakyGateway struct {
	mu      sync.Mutex
	charged map[string]int // key -> number of real charges
	calls   int
	r       *mrand.Rand
}

func (g *flakyGateway) Charge(_ context.Context, key string, amount int64) (bool, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.calls++
	if g.r.IntN(10) < 3 {
		return false, errors.New("gateway timeout")
	}
	if amount%100 == 13 {
		return false, nil
	}
	if g.charged[key] == 0 {
		g.charged[key]++ // the provider deduplicates by idempotency key
	}
	return true, nil
}

// crashAfterEffects simulates a consumer that dies after its handler's
// work but before commit, on the first attempt of every 5th message.
func crashAfterEffects(h queue.Handler) queue.Handler {
	var mu sync.Mutex
	crashed := map[int64]bool{}
	return func(ctx context.Context, tx pgx.Tx, m queue.Message) error {
		if err := h(ctx, tx, m); err != nil {
			return err
		}
		mu.Lock()
		defer mu.Unlock()
		if m.ID%5 == 0 && !crashed[m.ID] {
			crashed[m.ID] = true
			return errors.New("simulated crash before commit")
		}
		return nil
	}
}

func TestPipeline(t *testing.T) {
	db := newDB(t) // fresh database per test, as in Unit 9.8
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	const n = 100
	for i := range n {
		amount := int64(1000 + i*100)
		if i%10 == 0 {
			amount += 13 // declined
		}
		if err := Place(ctx, db, fmt.Sprintf("o%03d", i), amount); err != nil {
			t.Fatal(err)
		}
	}
	// A poison message: retrying can never fix it.
	pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
		return queue.Publish(ctx, tx, "order.placed", map[string]string{"nonsense": "x"})
	})

	gw := &flakyGateway{charged: map[string]int{}, r: mrand.New(mrand.NewPCG(1, 2))}
	consumers := []*queue.Consumer{
		{Name: "payments", Topic: "order.placed", Handle: crashAfterEffects(PaymentHandler(gw))},
		{Name: "shipping", Topic: "payment.succeeded", Handle: crashAfterEffects(ShippingHandler)},
		{Name: "cancel", Topic: "payment.failed", Handle: CancelHandler},
	}
	var wg sync.WaitGroup
	for _, c := range consumers {
		c.DB, c.MaxAttempts, c.BaseBackoff = db, 8, 5*time.Millisecond
		for range 3 { // three competing workers per topic
			wg.Add(1)
			go func() {
				defer wg.Done()
				if err := c.Run(ctx); err != nil {
					t.Error(err)
				}
			}()
		}
	}

	deadline := time.Now().Add(20 * time.Second)
	for {
		var left int
		db.QueryRow(ctx, `SELECT count(*) FROM messages`).Scan(&left)
		if left == 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("%d messages still queued", left)
		}
		time.Sleep(50 * time.Millisecond)
	}
	cancel()
	wg.Wait()

	// ... count orders by status, shipments, dead letters (see the full file) ...
	if counts["shipped"] != 90 || counts["cancelled"] != 10 || shipments != 90 {
		t.Errorf("want 90 shipped and 10 cancelled, got %v and %d shipments", counts, shipments)
	}
	for k, c := range gw.charged {
		if c != 1 {
			t.Errorf("%s charged %d times", k, c)
		}
	}
	if len(gw.charged) != 90 || dead != 1 {
		t.Errorf("real charges = %d (want 90), dead letters = %d (want 1)", len(gw.charged), dead)
	}
}
```

(The waiting loop polls a database count — acceptable here because the condition is external state, and it has a deadline; Unit 7.12's "no sleeps" rule is about waiting for goroutines you control.)

### Real result

Four consecutive runs with the race detector, all identical:

```
orders by status: map[cancelled:10 shipped:90], shipments: 90, dead letters: 1, gateway calls: 162, real charges: 90
--- PASS: TestPipeline (0.55s)
```

**162 gateway calls** — first attempts, transient-failure retries, and redeliveries after simulated crashes — produced **exactly 90 real charges**, one per approved order; **90 shipments**, one per paid order; **10 cancellations** via the compensating action; and the poison message parked in `dead_letters` after one attempt, without blocking anything.

### Review checklist

- Kill a worker (cancel its context) in the middle of processing: is the message redelivered and processed exactly once in effect?
- Raise the gateway's failure rate to 90%: do messages end up in `dead_letters` after `MaxAttempts`, with the last error recorded?
- Run with one worker and with ten: same final state?
- What happens if the shipping consumer is down for an hour? (Messages wait; nothing is lost; the backlog drains when it returns.)
- **Known limitations to discuss:** the handler runs while the message row is locked, so a slow handler holds a database transaction open (DT-256) — production systems often use a **lease** (`locked_until` timestamp) instead of a long transaction; polling every 50 ms adds latency and load (PostgreSQL `LISTEN/NOTIFY` can wake consumers); the `processed` table grows forever (delete old rows on a schedule); per-order ordering within one topic is not guaranteed.

### Extensions

1. Replace the long transaction with leases: claim with `UPDATE … SET locked_until = now() + interval '30 seconds' … RETURNING`, process outside the transaction, then delete.
2. Add `LISTEN/NOTIFY` so consumers wake immediately on new messages.
3. Add an orchestrated version of the same saga (a coordinator with a `sagas` table) and compare the code and observability.

## Answers to the Chapter 12 prediction questions

**12.1 Q2.** If each backend has a 1% chance of a slow (p99) response, a request that waits for all 100 has a 1 − 0.99¹⁰⁰ ≈ 63% chance of hitting at least one slow response. The slow path becomes the common path.

**12.5 Q2.** A majority of 4 is 3, so 4 nodes tolerate only 1 failure — the same as 3 nodes — while adding one more machine that can fail and one more vote to collect.
