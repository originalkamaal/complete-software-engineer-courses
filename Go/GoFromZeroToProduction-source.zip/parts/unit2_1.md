## Unit 2.1 — Arrays

**One-line summary:** An array is a fixed number of values of one type, stored side by side in memory. The length is part of the type, and arrays are VALUES: assigning or passing an array copies every element.

**Mental model — a steel tiffin carrier with a fixed number of boxes.** A 3-tier tiffin always has exactly 3 boxes, stacked together, numbered from 0. You cannot add a 4th tier; a 4-tier tiffin is a different product. Giving someone your tiffin (assignment, function call) means giving them a full COPY of all boxes and their food.

**Declaring arrays:**

```go
var a [3]int                 // [0 0 0]  (zero values)
b := [3]int{10, 20, 30}      // [10 20 30]
c := [...]int{1, 2, 3, 4}    // compiler counts: type is [4]int
d := [5]int{2: 7, 4: 9}      // [0 0 7 0 9]  (index: value)
```

**Indexing:** `a[0]` is the first element, `a[len(a)-1]` the last. `len(a)` is the length, known at compile time.

**Out-of-range index — "who calculates?" again:**

| Code | Result |
| --- | --- |
| `a[3] = 1` (constant index, length 3) | compile error: index 3 out of bounds |
| `i := 3; a[i] = 1` | run-time panic: `index out of range [3] with length 3` |

Go checks every index (bounds checking), so it can never read or write memory outside the array (unlike C, where this causes crashes and security holes).

**The length is part of the type:** `[3]int` and `[4]int` are different types. `var p [3]int; var q [4]int; p = q` is a type error.

**Arrays are values (copied):**

```go
a := [3]int{1, 2, 3}
b := a        // b is a full COPY
b[0] = 99
fmt.Println(a, b) // [1 2 3] [99 2 3]
```

Passing an array to a function also copies it (DT-75). Arrays of comparable elements can be compared with `==` (element by element) and used as map keys.

**Memory layout:** elements sit next to each other with no gaps between same-size elements. `[4]int64` is exactly 32 bytes. Walking through an array in order is very cache-friendly (Unit 0.5).

**Iterating:**

```go
for i := range a { ... }     // index only
for i, v := range a { ... }  // index and a COPY of the element
for _, v := range a { ... }  // value only
```

Changing `v` does not change the array; write `a[i] = ...` instead.

**Multi-dimensional arrays:** `var board [3][3]int` is an array of 3 arrays of 3 ints (a tic-tac-toe board). `board[1][2]` is row 1, column 2.

**Where arrays are used in real Go:** fixed-size values where copying is fine or wanted: hashes (`sha256.Sum256` returns `[32]byte`), IPv4 addresses (4 bytes), small matrices, game boards, map keys made of several numbers. For lists whose size changes, Go uses SLICES (Unit 2.2), which are built on top of arrays.

**Common mistakes:**

- Expecting `b := a` to share data (it copies).
- Expecting a function to change the caller's array.
- Changing `v` in a range loop and expecting the array to change.
- Mixing arrays of different lengths.
- Using huge arrays as function parameters (every call copies all of it).

### Deep & Tricky

**DT-98. `range` over an array iterates over a COPY of the array.** *(Guarantee)* The range expression is evaluated once before the loop starts. For an array, that means the whole array is copied when you use the value variable. So changing `arr[2]` inside `for i, v := range arr` does not change the `v` values you see later in the same loop. Ranging over `&arr` (a pointer, Chapter 2) or a slice avoids the copy and sees the changes.

**DT-99. Constant indexes are checked at compile time.** *(Guarantee)* `a[5]` on a `[3]int` with a constant 5 does not compile. With a variable index, the compiler inserts a bounds check that panics at run time. When the compiler can prove an index is always valid (for example `for i := range a { a[i] }`), it removes the check: "bounds-check elimination" (Chapter 10).

**DT-100. Arrays are comparable and can be map keys; slices cannot.** *(Guarantee)* `[3]int{1, 2, 3} == [3]int{1, 2, 3}` is true. This makes arrays useful as composite map keys, for example `map[[2]int]bool` for visited grid cells (useful in Chapter 6 and in routing). Slices cannot be compared with `==` (only with nil) and cannot be map keys.

### Pattern

**P-16. Arrays for fixed-size values, slices for lists.** *(Go convention)*

- *Use arrays when:* the size is part of the meaning and never changes (a 32-byte hash, a 4-byte IPv4 address, RGB colour `[3]uint8`, a 3×3 board), you want value semantics (a copy is a separate thing), or you need a comparable map key.
- *Use slices when:* the number of elements can change or is known only at run time (almost every "list" in Go code).
- *Trade-off:* arrays are copied completely on assignment and function calls; that is cheap for small arrays and expensive for big ones.
