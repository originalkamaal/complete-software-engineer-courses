# Chapter 5 — Standard Library & I/O

*Goal: use Go's strong standard library instead of reaching for dependencies.*

Go ships with a standard library that covers files, streams, compression, JSON, CSV, binary encodings, time, command-line flags, signals, subprocesses, structured logging, templates, regular expressions, big numbers, and cryptographic randomness — all maintained by the Go team and covered by the compatibility promise. Experienced Go engineers reach for the standard library first and add dependencies only for a clear reason.

The single most important idea in this chapter is **streaming composition**: `io.Reader` and `io.Writer` are tiny interfaces, and almost everything that moves bytes implements them. Snap a file, a gzip decompressor, a hash, and a network connection together like pipes, and data flows through all of them in constant memory.

**What you will be able to do after this chapter**

- Compose readers and writers, and process files of any size in constant memory.
- Work safely with files, paths, permissions, and embedded assets.
- Encode and decode JSON (including its traps), CSV, and binary formats.
- Handle time correctly: durations, time zones, monotonic clocks, timers.
- Build professional command-line tools: flags, signals, subprocesses, exit codes, structured logs.
- Read the standard library's own source to learn how experts write Go.

## Topic 5A — I/O foundations

## Unit 5.1 — Readers and writers

**One-line summary:** `io.Reader` has one method, `Read(p []byte) (n int, err error)`; `io.Writer` has one method, `Write(p []byte) (n int, err error)`. Because they are so small, files, network connections, buffers, compressors, hashes, and HTTP bodies all implement them, and functions written against them work with all of these.

**Mental model — garden hoses and connectors.** A reader is a tap that delivers water in cupfuls when asked. A writer is a drain that accepts cupfuls. Adapters (gzip, buffering, hashing, limiting) are hose connectors: water goes in one side and comes out the other, changed. You can connect any number of them, and at no point does the whole tank of water need to be in one place.

### The contracts

```go
type Reader interface {
	Read(p []byte) (n int, err error)
}
type Writer interface {
	Write(p []byte) (n int, err error)
}
```

**Read** fills up to `len(p)` bytes into `p` and returns how many (`n`). Key rules:

- It may return **fewer** bytes than requested, even if more are coming (a network packet, a pipe). Never assume a full buffer.
- At the end of the data it returns `io.EOF` — possibly *together with* the last bytes (`n > 0, err == io.EOF`). **Always process the `n` bytes before looking at `err`.**
- `io.EOF` is a sentinel that means "normal end", not a failure (and should not be wrapped, DT-162).

**Write** writes all of `p` or returns an error explaining why it wrote less (`n < len(p)` must come with `err != nil`).

The correct hand-written read loop:

```go
buf := make([]byte, 32*1024)
for {
	n, err := r.Read(buf)
	if n > 0 {
		process(buf[:n]) // first use the data
	}
	if err == io.EOF {
		break // normal end
	}
	if err != nil {
		return err // real failure
	}
}
```

You will rarely write this loop, because helpers do it for you.

### The helpers

| Need | Use |
| --- | --- |
| Copy everything from a reader to a writer | `io.Copy(dst, src)` (constant memory, 32 KB buffer) |
| Read everything into memory | `io.ReadAll(r)` (only for data you *know* is small) |
| Read exactly n bytes | `io.ReadFull(r, buf)` |
| Read at most n bytes | `io.LimitReader(r, n)` — wrap untrusted input! |
| Concatenate readers | `io.MultiReader(r1, r2, ...)` |
| Write to several writers at once | `io.MultiWriter(w1, w2, ...)` |
| Copy what is read into a writer | `io.TeeReader(r, w)` |
| Connect a writer to a reader in memory | `io.Pipe()` (with goroutines, Chapter 7) |
| Discard output | `io.Discard` |
| Read from a string / byte slice | `strings.NewReader(s)`, `bytes.NewReader(b)` |
| Collect writes in memory | `bytes.Buffer`, `strings.Builder` |

### Composition in action

Compute the SHA-256 of a gzip file's *decompressed* contents while also counting bytes, without holding the file in memory:

```go
f, err := os.Open("data.csv.gz")
if err != nil {
	return err
}
defer f.Close()

gz, err := gzip.NewReader(f) // file -> decompressor
if err != nil {
	return err
}
defer gz.Close()

h := sha256.New()               // a hash is an io.Writer
n, err := io.Copy(h, gz)        // decompressed bytes flow into the hash
if err != nil {
	return err
}
fmt.Printf("%d bytes, sha256 %x\n", n, h.Sum(nil))
```

Change `os.Open` to an HTTP response body, or `sha256.New()` to an `os.Stdout`, and nothing else changes. That is the power of small interfaces (Unit 3.4).

### Optional fast paths

`io.Copy` checks for `io.WriterTo` on the source and `io.ReaderFrom` on the destination (Unit 3.6). For example, copying from an `*os.File` to a network connection can use the operating system's `sendfile`/`splice` calls, moving data without ever copying it into your process. Wrapping a reader in your own type hides these interfaces (P-24's trade-off).

### Deep & Tricky

**DT-190. `Read` can return data and `io.EOF` at the same time.** *(Contract)* Code that checks `err` first and breaks on EOF loses the last chunk. Process `n` bytes, then inspect `err`. This bug survives testing with `strings.NewReader` (which returns EOF on a separate call) and appears with other readers.

**DT-191. `io.ReadAll` on untrusted input is a denial-of-service bug.** *(Practice)* A client that sends 20 GB makes your server allocate 20 GB. Wrap with `io.LimitReader(r, maxBytes)` (or `http.MaxBytesReader` for HTTP bodies, Unit 8.4) and treat "limit reached" as an error.

### Pattern

**P-29. Write functions against `io.Reader`/`io.Writer`, not file names.** *(Core Go practice)*

- *Problem it solves:* functions that open files themselves cannot be reused for network data, compressed input, or in-memory tests.
- *How:* `func Parse(r io.Reader) (...)`, `func Render(w io.Writer, ...) error`. A thin wrapper opens the file and calls them.
- *When not to:* when you need random access (`io.ReaderAt`, `io.Seeker`) or file metadata — then take the narrowest interface that provides it.
- *Trade-off:* almost none; this is one of the few near-universal rules.

### Mastery check

1. **Explain.** Why must you process `n` bytes before checking `err` in a read loop?
2. **Predict.** `r := io.LimitReader(strings.NewReader("hello world"), 5); b, _ := io.ReadAll(r); fmt.Println(string(b))`; and `io.Copy(io.Discard, strings.NewReader("abc"))` returns what?
3. **Write.** An `upperWriter` that wraps an `io.Writer` and upper-cases ASCII letters on the way through; use it with `io.Copy(upperWriter{os.Stdout}, os.Stdin)`. Then a `countingReader` that counts bytes read.

## Unit 5.2 — Files

**One-line summary:** `os.Open`, `os.Create`, and `os.OpenFile` give you an `*os.File` (a reader and writer). Use `bufio` for efficient line-by-line reading and buffered writing, handle `Close` errors on writes, set permissions deliberately, and write files atomically when a crash must not leave half a file.

### Opening files

```go
f, err := os.Open(path)        // read only
f, err := os.Create(path)      // write; create or TRUNCATE; mode 0o666 before umask
f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644) // full control
```

The flags are bit flags (P-7): `O_RDONLY`, `O_WRONLY`, `O_RDWR`, combined with `O_APPEND`, `O_CREATE`, `O_EXCL` (fail if it exists), `O_TRUNC`. The permission argument is used only when the file is created, and the process's **umask** (usually `022`) removes bits: `0o666` becomes `0o644` (Unit 0.2's octal permissions).

For small files, the whole-file helpers are simplest: `os.ReadFile(path)` and `os.WriteFile(path, data, 0o644)`.

### Errors you will meet

```go
_, err := os.Open("missing.txt")
fmt.Println(err)                         // open missing.txt: no such file or directory
errors.Is(err, fs.ErrNotExist)           // true
var pe *fs.PathError
errors.As(err, &pe)                      // pe.Op "open", pe.Path "missing.txt", pe.Err syscall.ENOENT
```

Check conditions with `errors.Is(err, fs.ErrNotExist)`, `fs.ErrPermission`, `fs.ErrExist` — portable across operating systems.

### Reading large files in constant memory

```go
f, err := os.Open(path)
if err != nil {
	return err
}
defer f.Close()

sc := bufio.NewScanner(f)
sc.Buffer(make([]byte, 0, 64*1024), 16*1024*1024) // allow long lines (DT-92)
for sc.Scan() {
	handle(sc.Text())
}
return sc.Err()
```

Memory use is the size of the buffer, whether the file is 1 KB or 100 GB. `sc.Split(bufio.ScanWords)` splits on words instead; `bufio.ScanRunes` on runes; you can write a custom `SplitFunc` for other formats. For records that are not line-based, `bufio.NewReader(f)` offers `ReadString('\n')`, `ReadByte`, `ReadRune`, and `Peek`.

`sc.Bytes()` returns a slice of the scanner's internal buffer, overwritten by the next `Scan` — copy it if you keep it (the sub-slice idea of Unit 2.4). `sc.Text()` allocates a new string each time, which is safe.

### Writing efficiently and safely

Every `Write` on an `*os.File` is a system call. Many small writes are slow; buffer them:

```go
func writeReport(path string, rows []Row) (err error) {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer func() {
		if cerr := f.Close(); cerr != nil && err == nil {
			err = cerr
		}
	}()
	w := bufio.NewWriter(f)
	for _, r := range rows {
		fmt.Fprintf(w, "%s,%d\n", r.Name, r.Count)
	}
	return w.Flush() // without Flush, the last buffered bytes are LOST
}
```

Forgetting `Flush` is one of the most common file bugs in Go: the program "works" but the last few kilobytes of the output are missing.

### Atomic writes

If the program crashes (or the machine loses power) during a write, the file is left half-written. Write to a temporary file in the **same directory**, sync it, then rename over the target — `rename` within one file system is atomic on POSIX systems, so readers see either the old file or the new one, never a mix:

```go
tmp, err := os.CreateTemp(filepath.Dir(path), ".tmp-*")
... write to tmp ...
tmp.Sync()                    // force data to the disk (durability)
tmp.Close()
os.Rename(tmp.Name(), path)   // atomic replace
```

The Chapter 3 project did a simpler version of this.

### Other operations

`os.Stat` (size, mode, modification time; `errors.Is(err, fs.ErrNotExist)` to test existence), `os.Remove`, `os.RemoveAll`, `os.Rename`, `os.MkdirAll(dir, 0o755)`, `os.ReadDir` (sorted directory entries), `os.Chmod`, `os.TempDir`, `os.CreateTemp`, `os.MkdirTemp`. Since Go 1.24, `os.Root` (`os.OpenRoot(dir)`) opens files *only inside* a directory, rejecting `../` escapes and symbolic links that lead outside — essential when file names come from users (Unit 11.2).

### Deep & Tricky

**DT-192. `defer f.Close()` on a file you wrote can lose errors — and data.** *(OS behaviour)* Many file systems (especially network file systems) report write failures only at `Close` or `Sync`. Ignoring `Close`'s error means a full disk can silently produce a truncated file. Check it, as in `writeReport` above (P-13's caveat).

**DT-193. Checking whether a file exists before opening it is a race.** *(Concurrency fact)* Between `os.Stat` saying "does not exist" and `os.Create`, another process may create it. Use `os.OpenFile` with `O_CREATE|O_EXCL` to "create only if absent" atomically, and simply handle the error from `Open` instead of checking first.

### Mastery check

1. **Explain.** Why does writing through `bufio.Writer` need an explicit `Flush`, and what happens if you forget?
2. **Explain.** Why must the temporary file for an atomic write be in the same directory as the target?
3. **Write.** `tail(path string, n int) ([]string, error)` that returns the last n lines of a file of any size using constant memory (hint: a ring buffer of n strings, Unit 6.3 preview).

## Unit 5.3 — Paths and file systems

**One-line summary:** Use `path/filepath` for operating-system file paths, `path` for slash-separated paths (URLs, embedded files), `io/fs` for read-only file-system abstractions, and `embed` to compile files into your binary.

### `path/filepath`

```go
filepath.Join("data", "2026", "log.txt") // data/2026/log.txt (data\2026\log.txt on Windows)
filepath.Base("/a/b/c.txt")              // c.txt
filepath.Dir("/a/b/c.txt")               // /a/b
filepath.Ext("archive.tar.gz")           // .gz
filepath.Clean("a//b/../c/./d")          // a/c/d
filepath.Abs("x.txt")                    // absolute path based on the working directory
filepath.Rel("/a/b", "/a/b/c/d")         // c/d
filepath.Match("*.go", "main.go")        // true, nil
filepath.Glob("testdata/*.json")
```

Never build paths with `+ "/" +`: it breaks on Windows and creates `//` or missing separators. And never trust a path component from a user: `filepath.Join("uploads", "../../etc/passwd")` cleans to `../etc/passwd`, outside your directory (use `os.Root` or `filepath.IsLocal`, Go 1.20+).

### Walking a directory tree

```go
err := filepath.WalkDir("src", func(path string, d fs.DirEntry, err error) error {
	if err != nil {
		return err // or log and return nil to keep going
	}
	if d.IsDir() && d.Name() == ".git" {
		return filepath.SkipDir
	}
	if !d.IsDir() && filepath.Ext(path) == ".go" {
		fmt.Println(path)
	}
	return nil
})
```

`WalkDir` (Go 1.16) is faster than the older `Walk` because it does not `Stat` every file.

### `io/fs`: file systems as interfaces

`fs.FS` is a read-only file-system interface with one method, `Open(name string) (fs.File, error)`, using slash-separated paths. Implementations include a real directory (`os.DirFS("static")`), embedded files (`embed.FS`), zip archives (`zip.Reader`), and test fakes (`testing/fstest.MapFS`). Functions like `fs.ReadFile`, `fs.WalkDir`, `fs.Glob`, and `template.ParseFS` and `http.FileServerFS` work with any of them. Same idea as `io.Reader`, one level up.

### `embed`: files inside your binary

```go
import "embed"

//go:embed templates/*.html static
var assets embed.FS

//go:embed version.txt
var version string
```

At build time the files are copied into the binary; `assets` behaves as an `fs.FS`. Deploying becomes copying one file (DT-2's advantage, extended to templates, migrations, and web assets). Patterns cannot contain `..`, and files beginning with `.` or `_` are excluded unless you use the `all:` prefix.

### Deep & Tricky

**DT-194. `path` and `path/filepath` are different on Windows.** *(Guarantee)* `path.Join` always uses `/`; `filepath.Join` uses the OS separator. Use `path` for URLs and `fs.FS` paths (always slash-separated, even on Windows), and `filepath` for real OS paths. Mixing them works on Linux and macOS and breaks on Windows.

### Mastery check

1. **Explain.** Why is `fs.FS` useful for testing code that reads templates?
2. **Predict.** `filepath.Clean("/a/../../b")`, `filepath.Ext("noext")`, `filepath.Join("a", "/b")`.
3. **Write.** `du(dir string) (map[string]int64, error)` that sums file sizes per file extension under a directory, skipping hidden directories; test it with `fstest.MapFS` by writing it against `fs.FS`.

## Topic 5B — Data formats

## Unit 5.4 — encoding/json

**One-line summary:** `json.Marshal` and `json.Unmarshal` convert between Go values and JSON using struct fields and tags; `json.Encoder`/`Decoder` do the same over streams. Know the traps: only exported fields, `omitempty` vs `omitzero`, numbers becoming `float64`, unknown fields silently ignored, and nil vs empty slices. Since Go 1.27, `encoding/json` runs on the new v2 implementation, and `encoding/json/v2` is available with stricter defaults.

### Struct tags control the mapping

```go
type Order struct {
	ID        string    `json:"id"`
	Customer  string    `json:"customer"`
	Items     []Item    `json:"items"`
	Total     int64     `json:"total_paise"`
	Note      string    `json:"note,omitempty"` // omitted when ""
	CreatedAt time.Time `json:"created_at"`     // RFC 3339 text
	Paid      *bool     `json:"paid,omitempty"` // nil = unknown, distinct from false
	internal  int       // unexported: never encoded (DT-167)
	Secret    string    `json:"-"`              // never encoded
}

data, err := json.Marshal(order)             // []byte
data, err := json.MarshalIndent(order, "", "  ")

var o Order
err = json.Unmarshal(data, &o)               // pass a POINTER
```

Matching on decode is **case-insensitive** on field names (`"ID"`, `"id"`, `"Id"` all fill `ID`) in v1 semantics. Unknown fields in the JSON are **silently ignored** by default.

### Type mapping

| Go | JSON |
| --- | --- |
| `bool` | `true` / `false` |
| integers, floats | number |
| `string` | string (invalid UTF-8 replaced with U+FFFD in v1; rejected in v2) |
| struct | object |
| `map[string]T` (also integer keys, as strings) | object, keys sorted on encode |
| slice, array | array; **nil slice → `null`**, empty slice → `[]` |
| `[]byte` | base64 string |
| pointer | the pointed-to value, or `null` |
| `time.Time` | RFC 3339 string |
| `any` on decode | `map[string]any`, `[]any`, `float64`, `string`, `bool`, `nil` |

### The traps

**Numbers into `any` become `float64`** — and integers above 2^53 lose precision (DT-66):

```go
var v any
json.Unmarshal([]byte(`{"id": 9007199254740993}`), &v)
// v["id"] is float64 9.007199254740992e+15 — the ID changed!
```

Decode into a typed struct (`ID int64`), or use `dec.UseNumber()` to get `json.Number` (a string you convert yourself).

**`omitempty` does not omit zero structs** (including `time.Time`):

```go
type A struct {
	T  time.Time `json:"t,omitempty"`  // still encoded: "0001-01-01T00:00:00Z"
	T2 time.Time `json:"t2,omitzero"`  // Go 1.24+: omitted when zero (or when IsZero() reports true)
}
```

`omitempty` omits false, 0, "", nil pointers and interfaces, and empty slices and maps — but never structs. Use `omitzero` (Go 1.24) or a pointer.

**Unknown fields and typos.** A client sends `"custmer"`; your `Customer` stays empty and no error is reported. For strict APIs:

```go
dec := json.NewDecoder(r)
dec.DisallowUnknownFields()
err := dec.Decode(&o) // json: unknown field "custmer"
```

### Streaming

```go
enc := json.NewEncoder(w)   // writes to any io.Writer, one value per Encode, newline-terminated
enc.SetIndent("", "  ")
enc.Encode(report)

dec := json.NewDecoder(r)   // reads from any io.Reader
for {
	var e Event
	if err := dec.Decode(&e); err == io.EOF {
		break
	} else if err != nil {
		return err
	}
	handle(e)
}
```

This handles **JSON Lines** (one object per line) in constant memory — the standard format for logs and data pipelines.

### Custom marshalling

Implement `json.Marshaler` / `json.Unmarshaler` (or `encoding.TextMarshaler`/`TextUnmarshaler`, used also for map keys and other encodings) to control a type's form:

```go
func (g Genre) MarshalText() ([]byte, error) { return []byte(g.String()), nil }

func (g *Genre) UnmarshalText(b []byte) error {
	v, err := ParseGenre(string(b))
	if err != nil {
		return err
	}
	*g = v
	return nil
}
```

Now `Genre` appears in JSON as `"science"` instead of `2` — readable and stable even if the constant order changes.

### JSON v2 (Go 1.27)

Go 1.27 added `encoding/json/v2` and the low-level `encoding/json/jsontext`, and re-implemented the classic `encoding/json` on top of the new engine (with options that keep v1 behaviour; unmarshalling became significantly faster). The v2 API (`json.Marshal(v, opts...)`, `json.UnmarshalRead(r, &v)`, `MarshalWrite`) has **stricter defaults**: it rejects invalid UTF-8 and duplicate object names, matches field names case-sensitively, and encodes nil slices and maps as `[]` and `{}`. For new code that handles untrusted input on Go 1.27+, v2's strictness removes several of the traps above. Existing code using `encoding/json` keeps working; error message *texts* may differ, so never match on them.

### Deep & Tricky

**DT-195. Unmarshalling into a non-empty value merges.** *(Guarantee)* `json.Unmarshal` into a struct that already has values only overwrites fields present in the JSON; others keep their old values. Into a map, it adds keys. Reusing one variable across decodes in a loop can leak values from the previous record. Declare a fresh variable per record.

**DT-196. Duplicate keys: v1 takes the last, v2 rejects.** *(Version-dependent behaviour)* `{"role":"user","role":"admin"}` decodes as `admin` with v1 semantics. If one system validates with the first value and another uses the last, attackers can exploit the difference. v2's default rejection closes the hole.

**DT-197. HTML characters are escaped by default.** *(v1 behaviour)* `json.Marshal` escapes `<`, `>`, and `&` as `<` and so on, so JSON can be embedded in HTML safely. Use an `Encoder` with `SetEscapeHTML(false)` if the output is not going into HTML and must be human-readable.

### Pattern

**P-30. Separate wire types from domain types.** *(Design practice)* Define small structs that mirror the JSON exactly (tags, pointers for optional fields), decode into them, validate, and convert to domain types. Changing the API format then never ripples through business logic, and validation has one obvious place. *Trade-off:* some duplicated fields and conversion code.

### Mastery check

1. **Explain.** Why does `{"id": 9007199254740993}` decoded into `any` come back as a different number? Name two fixes.
2. **Predict.** Encoding `struct{ S []int \`json:"s"\` }{}`; `struct{ S []int \`json:"s,omitempty"\` }{S: []int{}}`; a struct with an unexported field only.
3. **Write.** Give the `Genre` enum of Chapter 3 `MarshalText`/`UnmarshalText`, and a test that a `Book` round-trips through JSON with `"genre":"science"` and that `"genre":"poetry"` produces an error.

## Unit 5.5 — CSV and binary formats

**One-line summary:** `encoding/csv` reads and writes comma-separated records correctly (quotes, embedded commas, newlines inside fields). `encoding/binary` converts numbers to and from bytes with an explicit byte order, which is how file formats and network protocols are built.

### CSV

```go
r := csv.NewReader(f)
r.FieldsPerRecord = 3   // error if a row has a different number of fields (0 = same as first row)
r.TrimLeadingSpace = true
for {
	rec, err := r.Read() // []string
	if err == io.EOF {
		break
	}
	if err != nil {
		return err // *csv.ParseError includes line and column
	}
	...
}

w := csv.NewWriter(os.Stdout)
w.Write([]string{"name", "city"})
w.Write([]string{"Rao, Asha", "Pune"}) // written as "Rao, Asha",Pune
w.Flush()
if err := w.Error(); err != nil { ... }
```

Never split CSV with `strings.Split(line, ",")`: quoted fields with commas or newlines break it. `r.Comma = '\t'` handles tab-separated files; `r.ReuseRecord = true` avoids allocating a new slice per row in hot loops.

### Binary encoding and byte order

```go
buf := make([]byte, 8)
binary.BigEndian.PutUint32(buf, 0xCAFEBABE)          // CA FE BA BE
binary.LittleEndian.PutUint32(buf[4:], 0xCAFEBABE)   // BE BA FE CA
x := binary.BigEndian.Uint32(buf)                    // 0xCAFEBABE

b := binary.BigEndian.AppendUint16(nil, 443)         // append form (Go 1.19+)

// Variable-length integers: small numbers take fewer bytes
b = binary.AppendUvarint(b, 300)                     // 2 bytes: AC 02
v, n := binary.Uvarint(b[2:])

// Fixed-size structs (all fields fixed-size numbers)
type Header struct {
	Magic   uint32
	Version uint16
	Flags   uint16
}
err := binary.Read(r, binary.LittleEndian, &h)
```

Remember DT-16: the format's specification decides the byte order, never the machine's. Network protocols are usually big-endian ("network byte order"); many file formats (and most CPUs) are little-endian. Mixing them up produces numbers that look like garbage: 1 becomes 16,777,216.

### Other formats in the standard library

`encoding/xml`, `encoding/base64`, `encoding/hex`, `encoding/pem`, `encoding/gob` (Go-to-Go only), `archive/zip`, `archive/tar`, `compress/gzip`, `compress/zlib`, `hash/crc32`, `crypto/sha256`. The `uuid` package (Go 1.27) generates and parses UUIDs. Protocol Buffers (Unit 8.8) and YAML/TOML need external modules.

### Deep & Tricky

**DT-198. `binary.Read` with a struct is reflection-based and slow.** *(Implementation detail)* It is convenient for headers, but for millions of records decode fields manually with `binary.LittleEndian.Uint32(buf[0:4])` and so on — often more than ten times faster (measure, Chapter 10).

**DT-199. A UTF-8 byte-order mark can hide in CSV files from Excel.** *(Real-world format quirk)* Files saved as "CSV UTF-8" by spreadsheet programs often start with the bytes `EF BB BF`. The first header becomes `"﻿name"` and `rec[0] == "name"` is false. Strip a leading BOM before parsing.

### Mastery check

1. **Explain.** Why is `strings.Split` wrong for CSV? Show a row that breaks it.
2. **Predict.** The bytes of `binary.BigEndian.PutUint16` and `LittleEndian.PutUint16` for 258; `binary.AppendUvarint(nil, 127)` and `(nil, 128)` lengths.
3. **Write.** A tiny binary file format: a header (magic `"GOAP"`, version uint16) followed by records (uint32 ID, uvarint name length, name bytes). Write an encoder and decoder with tests, including a truncated file.

## Topic 5C — Time, command-line tools, and logging

## Unit 5.6 — time

**One-line summary:** `time.Time` is an instant (with a location for display), `time.Duration` is an `int64` count of nanoseconds. Formatting uses a reference time (`Mon Jan 2 15:04:05 MST 2006`) instead of `%Y`-style codes. Compare instants with `Before`/`After`/`Equal`, measure elapsed time with the monotonic clock, store and transmit times in UTC.

### Instants and durations

```go
now := time.Now()
later := now.Add(90 * time.Minute)
d := later.Sub(now)            // time.Duration: 1h30m0s
d.Minutes()                    // 90 (float64)
time.Since(start)              // shorthand for time.Now().Sub(start)
time.Until(deadline)

t := time.Date(2026, time.November, 15, 14, 5, 9, 0, time.UTC)
t.Year(), t.Month(), t.Day(), t.Weekday(), t.YearDay()
t.AddDate(0, 1, 0)             // calendar arithmetic: one month later
t.Truncate(time.Hour)          // 14:00:00
```

`AddDate` normalises: `Jan 31 + 1 month` is `Feb 31`, which normalises to **March 3** (in 2026). Calendar arithmetic needs explicit business rules ("end of month" billing must handle this).

### Comparing

Use `t1.Before(t2)`, `t1.After(t2)`, `t1.Equal(t2)`, and `t1.Compare(t2)` (Go 1.20). Do not use `==`: two `Time` values for the same instant can differ in location or monotonic reading, making `==` false (DT-200).

### Formatting with the reference time

Go formats by example. The reference instant is `Mon Jan 2 15:04:05 MST 2006` — memorable as **1 2 3 4 5 6 7**: month 1, day 2, hour 3 (15), minute 4, second 5, year 6, zone -7.

```go
t.Format("2006-01-02")               // 2026-11-15
t.Format("02/01/2006 3:04PM")        // 15/11/2026 2:05PM
t.Format(time.RFC3339)               // 2026-11-15T14:05:09Z — use for machines
t.Format(time.DateTime)              // 2026-11-15 14:05:09 (Go 1.20 constants: DateTime, DateOnly, TimeOnly)
t.Format("YYYY-MM-DD")               // "YYYY-MM-DD" — literal text! No error.
time.Parse("2006-01-02", "2026-11-15")
time.ParseInLocation("2006-01-02 15:04", "2026-11-15 09:30", ist)
```

### Time zones

```go
ist, err := time.LoadLocation("Asia/Kolkata") // needs the tz database (embed with import _ "time/tzdata")
fmt.Println(t.In(ist))                        // 2026-11-15 19:35:09 +0530 IST
```

A `Time` stores the instant once; the location only affects display and calendar calculations. Store and transmit in UTC (`t.UTC()`), convert to a user's zone at the edge. A day is not always 24 hours: across daylight-saving changes, `t.AddDate(0, 0, 1)` and `t.Add(24 * time.Hour)` give different results in zones that observe DST.

### The monotonic clock

`time.Now()` reads two clocks: the **wall clock** (can jump when NTP corrects it or an admin changes it) and the **monotonic clock** (only moves forward). `t2.Sub(t1)` uses the monotonic readings when both values have them, so elapsed-time measurements are correct even if the wall clock jumps. `fmt.Println(time.Now())` shows the monotonic part as `m=+0.000123`. Operations that produce a "calendar" time (`t.Round(0)`, `t.In`, `t.UTC`, parsing, decoding) strip it.

### Timers and tickers

```go
time.Sleep(200 * time.Millisecond)
<-time.After(time.Second)          // a channel that receives once (Chapter 7)
timer := time.NewTimer(5 * time.Second)
defer timer.Stop()
ticker := time.NewTicker(time.Minute)
defer ticker.Stop()
for t := range ticker.C { ... }
time.AfterFunc(d, f)               // run f in its own goroutine after d
```

Since Go 1.23, unreferenced timers and tickers are garbage-collected even if not stopped, and their channels are unbuffered, so `Reset` and `Stop` no longer leave a stale value behind (Go 1.27 removed the old behaviour completely). Chapter 7 uses timers with `select` for timeouts.

### Deep & Tricky

**DT-200. Never compare `time.Time` with `==`, and never use it as a map key without normalising.** *(Guarantee + trap)* `==` compares the location pointer and monotonic reading too. `t.Equal(u)` compares instants. As map keys, use `t.UTC().Round(0)` or a Unix timestamp.

**DT-201. `time.Duration(n) * time.Second` vs `time.Duration(n * time.Second)`.** *(Type rules)* With `n int`, `n * time.Second` does not compile (mismatched types, Unit 3.1). Write `time.Duration(n) * time.Second`. But `time.Duration(1.5) * time.Second` with a *constant* 1.5 is a compile error (truncated), and with a float variable converts 1.5 to 1 first. Use `time.Duration(f * float64(time.Second))` for fractional seconds.

**DT-202. Layout mistakes compile and fail silently.** *(fmt-like behaviour)* `t.Format("2006-01-02 15:04:05")` is right; `"2006-02-01"` swaps month and day; `"2006-01-02 03:04:05"` gives a 12-hour clock without AM/PM; `"YYYY"` is printed literally. Test formatting with a date whose day is greater than 12 (like the 15th) so swapped fields are visible (the DT-18 lesson again).

### Mastery check

1. **Explain.** What is the monotonic clock for, and why does `time.Since(start)` stay correct when NTP adjusts the system time?
2. **Predict.** (a) `time.Date(2026, 1, 31, 0, 0, 0, 0, time.UTC).AddDate(0, 1, 0)` (b) `t.Format("YYYY")` (c) `time.Duration(90) * time.Minute` (d) `time.Sleep(2)`.
3. **Write.** `nextBusinessDay(t time.Time) time.Time` (skip Saturday and Sunday), and `billingDate(start time.Time, month int) time.Time` that clamps to the last day of the month instead of overflowing; tests including January 31 and leap years.

## Unit 5.7 — Command-line tools

**One-line summary:** `flag` parses command-line flags; `os/signal` lets a program react to Ctrl+C and termination signals; `os/exec` runs other programs safely; exit codes and stdout/stderr follow the conventions of P-3.

### `flag`

```go
var (
	addr    = flag.String("addr", ":8080", "listen address")
	verbose = flag.Bool("v", false, "verbose output")
	timeout = flag.Duration("timeout", 5*time.Second, "request timeout")
)

func main() {
	flag.Parse()
	files := flag.Args() // remaining non-flag arguments
	...
}
```

- Accepts `-flag value`, `-flag=value`, `--flag`; booleans as `-v` or `-v=false`. Parsing stops at the first non-flag argument or `--`.
- `-h` / `-help` prints generated usage. `flag.Usage = func() {...}` customises it.
- For testable programs, use a `flag.NewFlagSet(name, flag.ContinueOnError)` inside `run(args)` instead of the global set (the Chapter 5 project does this).
- `flag.Var` and `flag.TextVar` accept custom types (any `encoding.TextUnmarshaler`, like the `Genre` of Unit 5.4).
- Subcommands (`git commit -m`) are done with one `FlagSet` per subcommand. Larger CLIs often use the `cobra` module; the standard library is enough for most tools.

### Signals

```go
ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
defer stop()

for {
	select {
	case <-ctx.Done():
		fmt.Fprintln(os.Stderr, "interrupted, cleaning up")
		return saveProgress()
	case job := <-jobs:
		process(job)
	}
}
```

Ctrl+C sends `SIGINT` (`os.Interrupt`); `kill` and container orchestrators send `SIGTERM` and, after a grace period, the un-catchable `SIGKILL`. A good tool or server catches SIGINT/SIGTERM, stops taking new work, finishes or saves current work, and exits — **graceful shutdown** (Unit 8.7, Unit 11.8). `context` is fully explained in Unit 7.9; here, `ctx.Done()` simply means "a signal arrived". After the first signal, `stop()` restores the default behaviour, so a second Ctrl+C kills the program immediately.

### Running other programs: `os/exec`

```go
cmd := exec.CommandContext(ctx, "git", "log", "--oneline", "-n", "5")
cmd.Dir = repoDir
out, err := cmd.Output() // stdout; on failure err is *exec.ExitError with Stderr captured
if err != nil {
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return fmt.Errorf("git failed (exit %d): %s", ee.ExitCode(), ee.Stderr)
	}
	return err // e.g. git not installed: exec.ErrNotFound
}
```

- Arguments are passed directly to the program, **not through a shell**, so user input cannot inject shell commands (`; rm -rf /`). Never write `exec.Command("sh", "-c", "git log " + userInput)`.
- `cmd.Stdin`, `cmd.Stdout`, `cmd.Stderr` accept readers and writers (Unit 5.1) — stream large outputs instead of buffering them.
- `CommandContext` kills the process when the context is cancelled (timeouts).
- `exec.LookPath("git")` finds a program; since Go 1.19 it refuses to run programs from the current directory implicitly (a Windows security issue).

### Exit codes

`os.Exit(n)` with 0 for success, 1 for general failure, 2 for usage errors is the common convention (the `flag` package exits with 2 on bad flags when using `ExitOnError`). Remember that `os.Exit` skips deferred calls (Unit 1.11) — the `run()` pattern (P-14) keeps them working.

### Deep & Tricky

**DT-203. Child processes do not die automatically when your program is killed.** *(OS behaviour)* If your program is killed with SIGKILL, programs it started with `os/exec` keep running (orphans). `CommandContext` helps only when your process is alive to cancel the context. For robust supervision, use process groups (`SysProcAttr` on Unix) or a supervisor.

**DT-204. `cmd.Output()` with a huge output buffers it all in memory.** *(Library behaviour)* Like `io.ReadAll` (DT-191). For large or unbounded output, set `cmd.Stdout` to a writer or use `cmd.StdoutPipe()` and stream it.

### Mastery check

1. **Explain.** Why must a program that starts subprocesses never build a shell command string from user input?
2. **Predict.** With `fs := flag.NewFlagSet("x", flag.ContinueOnError)`, a `-n int` flag, and args `["-n", "3", "file.txt", "-v"]`: what are `n`, `fs.Args()`, and is `-v` parsed?
3. **Write.** `countdown -from 10 -interval 1s` that prints a countdown; on Ctrl+C it prints "aborted at N" and exits with code 130 (the shell convention: 128 + signal number 2).

## Unit 5.8 — Logging with log/slog

**One-line summary:** `log/slog` (Go 1.21) writes **structured** logs: a message plus typed key–value attributes, rendered as text or JSON, with levels. Structured logs can be searched and aggregated by machines, which plain `fmt.Println` lines cannot.

### Basics

```go
logger := slog.New(slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelInfo}))
slog.SetDefault(logger) // also routes the old log package through it

slog.Info("order placed", "order_id", id, "amount_paise", amt, "items", len(items))
slog.Warn("slow query", "duration", d, "query", name)
slog.Error("payment failed", "order_id", id, "err", err)
```

```json
{"time":"2026-11-15T14:05:09.123Z","level":"INFO","msg":"order placed","order_id":"o-17","amount_paise":125000,"items":3}
```

- Levels: `Debug`, `Info`, `Warn`, `Error` (and any integer in between). The handler's `Level` filters.
- `slog.NewTextHandler` writes `key=value` lines — readable in development; JSON in production, where a log system indexes the keys.
- `logger.With("request_id", rid)` returns a logger that adds attributes to every record — pass it down a request's call chain (or put it in a `context`, Unit 7.9).
- For hot paths, use typed attributes to avoid allocations: `slog.Int("items", n)`, `slog.String("user", u)`, and `logger.LogAttrs(ctx, slog.LevelInfo, "msg", attrs...)`.
- `slog.Group("http", "method", m, "path", p)` nests attributes.

### What to log

- **Events with context**, not narration: "payment failed" with the order ID, amount, provider, and error — not "entering function X".
- **Errors once**, where they are handled (Unit 3.9's handle-once rule).
- **Never secrets or personal data**: passwords, tokens, full card numbers, OTPs. Implement `slog.LogValuer` on sensitive types to redact them automatically.
- Consistent key names across the codebase (`user_id`, not `userId` here and `uid` there), so queries work.

### Deep & Tricky

**DT-205. A mismatched key–value list produces `!BADKEY`.** *(Library behaviour)* `slog.Info("x", "user")` (missing value) logs `!BADKEY=user`. `go vet`'s `slog` check catches many of these; typed `slog.Attr` constructors avoid them entirely.

**DT-206. Arguments are evaluated even when the level is disabled.** *(Language rule)* `slog.Debug("state", "dump", expensiveDump())` calls `expensiveDump()` before `slog` checks the level. Guard expensive work with `if logger.Enabled(ctx, slog.LevelDebug)`, or pass a `slog.LogValuer` whose `LogValue` runs only if the record is emitted.

### Mastery check

1. **Explain.** What can you do with structured logs that you cannot do with `fmt.Printf` lines?
2. **Write.** A `User` type with `LogValue()` that logs only the ID and a masked email (`a***@example.com`); show the JSON output.

## Topic 5D — Text and numbers

## Unit 5.9 — Text processing

**One-line summary:** Beyond `strings` and `bytes` (Unit 2.6), the standard library offers `regexp` (guaranteed linear-time regular expressions), `text/template` for generating text, `html/template` for generating HTML safely, and `text/tabwriter` for aligned columns.

### `regexp`

```go
var datePat = regexp.MustCompile(`^(\d{4})-(\d{2})-(\d{2})$`) // compile once (Unit 3.11 Must)

datePat.MatchString("2026-11-15")              // true
m := datePat.FindStringSubmatch("2026-11-15")  // ["2026-11-15" "2026" "11" "15"]
re := regexp.MustCompile(`(?P<user>\w+)@(?P<host>[\w.]+)`)
re.ReplaceAllString(text, "$user at $host")
re.FindAllString(text, -1)
```

Go's `regexp` uses the RE2 algorithm: matching time is **linear** in the input size, guaranteed. It cannot be made to take exponential time by a malicious pattern or input (the "ReDoS" attacks that affect backtracking engines in other languages). The price: no backreferences (`\1`) and no lookaround. Use raw strings for patterns (`\d` without double escaping), compile once at package level, and prefer `strings` functions when no pattern is needed — they are much faster.

### `text/template`

```go
const report = `Order {{.ID}} for {{.Customer}}
{{range .Items}}  {{printf "%-20s" .Name}} x{{.Qty}}
{{end}}{{if .Paid}}PAID{{else}}DUE{{end}}
`
tmpl := template.Must(template.New("report").Parse(report))
err := tmpl.Execute(os.Stdout, order)
```

`{{.Field}}` accesses fields and methods, `{{range}}`, `{{if}}`, `{{with}}`, `{{template "name" .}}`, pipelines (`{{.Name | printf "%q"}}`), and custom functions with `Funcs`. Templates are good for emails, reports, generated code, and configuration files.

### `html/template`: safe HTML

`html/template` has the same API but **escapes data according to context**: inside HTML text, inside an attribute, inside JavaScript, inside a URL. A user name of `<script>alert(1)</script>` is rendered harmlessly. Always use `html/template` for HTML; using `text/template` for HTML is a cross-site scripting (XSS) vulnerability (Unit 11.2).

### `text/tabwriter`

Aligns columns by padding cells — used by the Chapter 5 project's text report:

```go
tw := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
fmt.Fprintln(tw, "NAME\tCOUNT")
fmt.Fprintln(tw, "go\t42")
tw.Flush()
```

### Deep & Tricky

**DT-207. `regexp` matches are leftmost-first, like Perl — not longest.** *(Library behaviour)* `regexp.MustCompile("a|ab").FindString("ab")` is `"a"`. Use `CompilePOSIX` (or `re.Longest()`) for POSIX leftmost-longest semantics.

**DT-208. Templates fail at execution, not only at parse.** *(Library behaviour)* `{{.Nmae}}` (a typo) parses fine and fails only when executed with data that has no `Nmae` field — possibly halfway through writing output. Test every template with realistic data, and render into a buffer first if partial output would be harmful.

### Mastery check

1. **Explain.** What is ReDoS, and why is Go's `regexp` immune?
2. **Write.** A template that renders the `wordfreq` top-N as a Markdown table; then render the same data as an HTML table with `html/template` and show that a word containing `<b>` is escaped.

## Unit 5.10 — Exact numbers and secure randomness

**One-line summary:** `math/big` gives arbitrary-precision integers (`big.Int`), rationals (`big.Rat`), and floats (`big.Float`). Money uses integer minor units (P-8) or a decimal library with explicit rounding. `crypto/rand` provides secrets (P-15).

### `math/big`

```go
a := new(big.Int)
a.SetString("123456789012345678901234567890", 10)
b := big.NewInt(1_000_000_007)
c := new(big.Int).Mul(a, a)       // result goes into the receiver
c.Mod(c, b)
fmt.Println(c.String())

f := new(big.Int).MulRange(1, 50) // 50!
r := big.NewRat(1, 3)             // exact 1/3
r.Add(r, big.NewRat(1, 6))        // exactly 1/2
```

The API style is unusual: methods store the result in the receiver and also return it (`z.Add(x, y)` sets `z = x + y`), so you can reuse values and avoid allocations. Values must not be copied (use pointers). `big.Int` is used for cryptography, exact combinatorics, and IDs that overflow `uint64`. Go 1.27 added `Int.Divide` with explicit rounding modes (`Trunc`, `Floor`, `Round`, `Ceil`).

### Money, revisited

- Store amounts as `int64` minor units (paise, cents) — P-8. `int64` holds ±92 quadrillion rupees in paise; enough.
- For rates, taxes, conversions, and interest, compute with `big.Rat` or a decimal library (`github.com/shopspring/decimal`, `github.com/cockroachdb/apd`) and **round once, explicitly**, at a business-defined point ("round half to even at the invoice line").
- Splitting ₹100 three ways is 3333 + 3333 + 3334 paise — someone gets the extra paisa, and the rule for who is a business decision written in code.

### `crypto/rand`

```go
token := rand.Text()            // Go 1.24+: 26 base32 characters, 128+ bits of randomness
b := make([]byte, 32)
rand.Read(b)                    // never fails since Go 1.24 (DT-97)
n, err := rand.Int(rand.Reader, big.NewInt(1_000_000)) // uniform in [0, 1e6): a 6-digit OTP
otp := fmt.Sprintf("%06d", n)
```

Use it for every secret (P-15). Go 1.26 also made the cryptographic packages ignore caller-provided randomness sources in key generation, always using the secure source (tests use `testing/cryptotest.SetGlobalRandom`).

### Mastery check

1. **Explain.** Why does `big.Int`'s API put the result in the receiver?
2. **Write.** `split(total int64, n int) []int64` that splits paise as evenly as possible (differences of at most 1 paisa, sum exactly equal to total), plus tests for 10000 ÷ 3 and negative totals.

## Topic 5E — Learning from the source

## Unit 5.11 — Reading standard-library source code

**One-line summary:** The standard library is the largest body of idiomatic, reviewed, production Go you can read for free, and it is on your machine. Reading it teaches patterns, edge cases, and performance techniques no book covers fully.

### How to find and read it

```
$ go env GOROOT                  # where your Go installation lives
$ go doc -src strings.Cut        # print a function's source
$ go doc -src io.Copy
$ go doc bytes.ExampleBuffer     # Go 1.27: print an example's source
```

Or jump to definition in your editor, or browse `cs.opensource.google/go/go`. Start with small, self-contained packages:

| Package | What you learn |
| --- | --- |
| `strings` (`Cut`, `Fields`, `Builder`) | fast paths for ASCII, careful allocation, the copy check of DT-118 |
| `io` (`Copy`, `LimitReader`, `MultiReader`, `Pipe`) | interface composition, optional fast paths (`WriterTo`) |
| `bufio` (`Scanner`) | buffer management, `SplitFunc` design, error semantics |
| `errors` (`Is`, `As`, `Join`) | how wrapping is traversed |
| `sort` / `slices` (`pdqsort`) | a modern sorting algorithm with fallbacks |
| `sync` (`Once`, `WaitGroup`) | memory-model-correct synchronisation (Chapter 7) |
| `container/heap`, `container/list` | classic data structures in Go style (Chapter 6) |
| `net/http` (`Server`, `Transport`) | large-scale API design (Chapter 8) |

### How to read

1. Read the **package documentation** and the exported API first — the contract.
2. Read the **tests** and **examples**: they show intended use and edge cases.
3. Read one function at a time and ask: why this check first? why this buffer size? what does this comment protect against? Many comments cite issues (`go.dev/issue/NNNN`) — read them for the history of a decision.
4. Notice the conventions you now know: guard clauses, `(value, error)`, small interfaces, zero values that work, careful documentation of every exported name.

### Mastery check

1. **Write.** Read the source of `strings.Fields`. Explain its ASCII fast path and why it counts fields before allocating the result.
2. **Write.** Read `io.Copy` (`copyBuffer`). List the optional interfaces it checks and in what order, and why `LimitReader` hides one of them.

## Chapter 5 Project — `logscan`, a streaming log analyzer

**Goal:** a professional command-line tool that summarises HTTP access logs of any size in constant memory, reads plain or gzip-compressed files or stdin, filters by time, prints a text or JSON report, logs problems in structured form, and stops gracefully on Ctrl+C with a partial report.

### Input format

```
2026-11-01T10:00:00Z GET /api/users 200 123ms 512
time (RFC 3339)      method path status duration bytes
```

### Specification

```
logscan [-from T] [-to T] [-top N] [-slow D] [-json] [file ...]
```

- `-from` (inclusive) and `-to` (exclusive) filter by time; `-top` (default 5) paths; `-slow` (default 500ms) threshold; `-json` switches the output format.
- Report: requests, invalid lines, bytes, time range, counts per status class, slow requests, latency p50/p95/p99, top paths (count descending, then path).
- Invalid lines are counted; the first three are logged with `slog` (file, line number, reason) on stderr.
- Memory must not grow with the number of lines (it may grow with the number of *distinct paths*).
- Ctrl+C stops reading and prints the report marked partial.
- Bad flags → error and exit 1.

### Design notes

- **Constant-memory percentiles.** Storing every duration to sort it is O(lines) memory. Instead, count requests in 1 ms buckets up to 60 s (a fixed array of 60,001 counters, about 480 KB). The p95 is the first bucket where the cumulative count reaches 95% of the total — exact to 1 ms. This is a **histogram**, the same idea monitoring systems such as Prometheus use (Unit 11.5).
- **Composition.** `os.File` → (optional) `gzip.Reader` → `bufio.Scanner`. Nothing else in the program knows whether the input was compressed.
- **Testability.** `run(ctx, args, stdin, stdout, stderr)` with its own `FlagSet`; tests pass strings and buffers.

### Reference solution — `main.go`

```go
// Command logscan summarises HTTP access logs in constant memory.
//
//	logscan [flags] [file ...]
//
// Each input line has six space-separated fields:
//
//	2026-11-01T10:00:00Z GET /api/users 200 123ms 512
//	time (RFC 3339)      method path status duration bytes
//
// Files ending in .gz are decompressed on the fly. With no files, logscan
// reads standard input. Ctrl+C stops reading and prints a partial report.
package main

import (
	"bufio"
	"compress/gzip"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"os"
	"os/signal"
	"strings"
	"time"
)

type config struct {
	from, to time.Time
	top      int
	slow     time.Duration
	asJSON   bool
}

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err := run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr); err != nil {
		fmt.Fprintln(os.Stderr, "logscan:", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, args []string, stdin io.Reader, stdout, stderr io.Writer) error {
	fs := flag.NewFlagSet("logscan", flag.ContinueOnError)
	fs.SetOutput(stderr)
	var cfg config
	var from, to string
	fs.StringVar(&from, "from", "", "only lines at or after this RFC 3339 time")
	fs.StringVar(&to, "to", "", "only lines before this RFC 3339 time")
	fs.IntVar(&cfg.top, "top", 5, "number of paths to list")
	fs.DurationVar(&cfg.slow, "slow", 500*time.Millisecond, "requests at least this long count as slow")
	fs.BoolVar(&cfg.asJSON, "json", false, "print the report as JSON")
	if err := fs.Parse(args); err != nil {
		return err // flag already printed the message and usage
	}
	var err error
	if cfg.from, err = parseTimeFlag("from", from); err != nil {
		return err
	}
	if cfg.to, err = parseTimeFlag("to", to); err != nil {
		return err
	}
	if cfg.top < 1 {
		return fmt.Errorf("-top must be at least 1, got %d", cfg.top)
	}

	log := slog.New(slog.NewTextHandler(stderr, &slog.HandlerOptions{Level: slog.LevelWarn}))
	st := newStats()

	if fs.NArg() == 0 {
		if err := scan(ctx, stdin, "stdin", cfg, st, log); err != nil {
			return err
		}
	}
	for _, name := range fs.Args() {
		if err := scanFile(ctx, name, cfg, st, log); err != nil {
			return err
		}
	}

	rep := st.report(cfg)
	if ctx.Err() != nil {
		rep.Partial = true
	}
	if cfg.asJSON {
		enc := json.NewEncoder(stdout)
		enc.SetIndent("", "  ")
		return enc.Encode(rep)
	}
	return rep.writeText(stdout)
}

func parseTimeFlag(name, v string) (time.Time, error) {
	if v == "" {
		return time.Time{}, nil
	}
	t, err := time.Parse(time.RFC3339, v)
	if err != nil {
		return time.Time{}, fmt.Errorf("-%s: %w", name, err)
	}
	return t, nil
}

func scanFile(ctx context.Context, name string, cfg config, st *stats, log *slog.Logger) error {
	f, err := os.Open(name)
	if err != nil {
		return err
	}
	defer f.Close()

	var r io.Reader = f
	if strings.HasSuffix(name, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			return fmt.Errorf("%s: %w", name, err)
		}
		defer gz.Close()
		r = gz // readers compose: file -> gzip -> scanner
	}
	return scan(ctx, r, name, cfg, st, log)
}

// scan reads r line by line. Memory use does not depend on the input size.
func scan(ctx context.Context, r io.Reader, name string, cfg config, st *stats, log *slog.Logger) error {
	sc := bufio.NewScanner(r)
	lineNo := 0
	for sc.Scan() {
		lineNo++
		if lineNo%4096 == 0 && ctx.Err() != nil {
			return nil // interrupted: keep what we have
		}
		e, err := parseLine(sc.Text())
		if err != nil {
			st.invalid++
			if st.invalid <= 3 {
				log.Warn("skipping invalid line", "file", name, "line", lineNo, "err", err)
			}
			continue
		}
		if !cfg.from.IsZero() && e.time.Before(cfg.from) {
			continue
		}
		if !cfg.to.IsZero() && !e.time.Before(cfg.to) {
			continue
		}
		st.add(e, cfg)
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("%s: %w", name, err)
	}
	return nil
}

var errFields = errors.New("want 6 fields")

type entry struct {
	time     time.Time
	method   string
	path     string
	status   int
	duration time.Duration
	bytes    int64
}

func parseLine(line string) (entry, error) {
	f := strings.Fields(line)
	if len(f) != 6 {
		return entry{}, fmt.Errorf("%w, got %d", errFields, len(f))
	}
	var e entry
	var err error
	if e.time, err = time.Parse(time.RFC3339, f[0]); err != nil {
		return entry{}, err
	}
	e.method, e.path = f[1], f[2]
	if _, err := fmt.Sscanf(f[3], "%d", &e.status); err != nil || e.status < 100 || e.status > 599 {
		return entry{}, fmt.Errorf("bad status %q", f[3])
	}
	if e.duration, err = time.ParseDuration(f[4]); err != nil {
		return entry{}, err
	}
	if _, err := fmt.Sscanf(f[5], "%d", &e.bytes); err != nil || e.bytes < 0 {
		return entry{}, fmt.Errorf("bad byte count %q", f[5])
	}
	return e, nil
}
```

### Reference solution — `stats.go`

```go
package main

import (
	"cmp"
	"fmt"
	"io"
	"maps"
	"slices"
	"text/tabwriter"
	"time"
)

// Latencies are counted in 1 ms buckets up to maxBucket; longer requests
// share the last bucket. Fixed memory, and percentiles exact to 1 ms.
const maxBucket = 60_000 // 60 s

type stats struct {
	total, invalid, slow int
	bytes                int64
	byClass              [6]int // index 1..5 = 1xx..5xx
	byPath               map[string]int
	latency              [maxBucket + 1]int
	first, last          time.Time
}

func newStats() *stats { return &stats{byPath: make(map[string]int)} }

func (s *stats) add(e entry, cfg config) {
	s.total++
	s.bytes += e.bytes
	s.byClass[e.status/100]++
	s.byPath[e.path]++ // distinct paths: memory grows with paths, not lines
	ms := min(int(e.duration/time.Millisecond), maxBucket)
	s.latency[ms]++
	if e.duration >= cfg.slow {
		s.slow++
	}
	if s.first.IsZero() || e.time.Before(s.first) {
		s.first = e.time
	}
	if e.time.After(s.last) {
		s.last = e.time
	}
}

// percentile returns the smallest bucket value with at least p of requests at or below it.
func (s *stats) percentile(p float64) time.Duration {
	if s.total == 0 {
		return 0
	}
	need := int(p*float64(s.total) + 0.999999) // ceil
	seen := 0
	for ms, n := range s.latency {
		seen += n
		if seen >= need {
			return time.Duration(ms) * time.Millisecond
		}
	}
	return maxBucket * time.Millisecond
}

type pathCount struct {
	Path  string `json:"path"`
	Count int    `json:"count"`
}

// Report is what logscan prints; the struct tags define the JSON form.
type Report struct {
	Requests     int            `json:"requests"`
	InvalidLines int            `json:"invalid_lines"`
	Bytes        int64          `json:"bytes"`
	First        *time.Time     `json:"first,omitempty"`
	Last         *time.Time     `json:"last,omitempty"`
	StatusClass  map[string]int `json:"status_classes"`
	Slow         int            `json:"slow_requests"`
	P50          string         `json:"p50"`
	P95          string         `json:"p95"`
	P99          string         `json:"p99"`
	TopPaths     []pathCount    `json:"top_paths"`
	Partial      bool           `json:"partial,omitempty"`
}

func (s *stats) report(cfg config) Report {
	r := Report{
		Requests:     s.total,
		InvalidLines: s.invalid,
		Bytes:        s.bytes,
		StatusClass:  map[string]int{},
		Slow:         s.slow,
		P50:          s.percentile(0.50).String(),
		P95:          s.percentile(0.95).String(),
		P99:          s.percentile(0.99).String(),
	}
	if s.total > 0 {
		r.First, r.Last = &s.first, &s.last
	}
	for c := 1; c <= 5; c++ {
		if s.byClass[c] > 0 {
			r.StatusClass[fmt.Sprintf("%dxx", c)] = s.byClass[c]
		}
	}
	for _, p := range slices.Collect(maps.Keys(s.byPath)) {
		r.TopPaths = append(r.TopPaths, pathCount{p, s.byPath[p]})
	}
	slices.SortFunc(r.TopPaths, func(a, b pathCount) int {
		return cmp.Or(cmp.Compare(b.Count, a.Count), cmp.Compare(a.Path, b.Path))
	})
	r.TopPaths = r.TopPaths[:min(cfg.top, len(r.TopPaths))]
	return r
}

func (r Report) writeText(w io.Writer) error {
	tw := tabwriter.NewWriter(w, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "requests\t%d\n", r.Requests)
	fmt.Fprintf(tw, "invalid lines\t%d\n", r.InvalidLines)
	fmt.Fprintf(tw, "bytes sent\t%d\n", r.Bytes)
	if r.First != nil {
		fmt.Fprintf(tw, "time range\t%s – %s\n", r.First.Format(time.RFC3339), r.Last.Format(time.RFC3339))
	}
	for _, c := range slices.Sorted(maps.Keys(r.StatusClass)) {
		fmt.Fprintf(tw, "status %s\t%d\n", c, r.StatusClass[c])
	}
	fmt.Fprintf(tw, "slow requests\t%d\n", r.Slow)
	fmt.Fprintf(tw, "latency p50/p95/p99\t%s / %s / %s\n", r.P50, r.P95, r.P99)
	fmt.Fprintln(tw, "top paths\t")
	for _, p := range r.TopPaths {
		fmt.Fprintf(tw, "  %s\t%d\n", p.Path, p.Count)
	}
	if r.Partial {
		fmt.Fprintln(tw, "(partial: interrupted)\t")
	}
	return tw.Flush()
}
```

Note the pointers `First` and `Last`: with plain `time.Time` fields, `omitempty` would still print `0001-01-01T00:00:00Z` for an empty report (Unit 5.4). On Go 1.24+ `time.Time` with `omitzero` is the cleaner alternative.

### Reference solution — `main_test.go`

```go
package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const sample = `2026-11-01T10:00:00Z GET /api/users 200 120ms 512
2026-11-01T10:00:01Z GET /api/users 200 80ms 512
2026-11-01T10:00:02Z POST /api/orders 201 640ms 64
2026-11-01T10:00:03Z GET /health 200 1ms 2
this line is broken
2026-11-01T10:00:04Z GET /api/users 500 2s 0
`

func TestParseLine(t *testing.T) {
	e, err := parseLine("2026-11-01T10:00:00Z GET /x 404 1.5s 10")
	if err != nil {
		t.Fatal(err)
	}
	if e.status != 404 || e.duration != 1500*time.Millisecond || e.path != "/x" {
		t.Errorf("got %+v", e)
	}
	for _, bad := range []string{"", "a b c", "2026-11-01T10:00:00Z GET /x 999 1s 1", "2026-11-01T10:00:00Z GET /x 200 fast 1"} {
		if _, err := parseLine(bad); err == nil {
			t.Errorf("parseLine(%q) succeeded", bad)
		}
	}
}

func TestReportJSON(t *testing.T) {
	var out, errOut bytes.Buffer
	err := run(context.Background(), []string{"-json", "-top", "2"}, strings.NewReader(sample), &out, &errOut)
	if err != nil {
		t.Fatal(err)
	}
	var r Report
	if err := json.Unmarshal(out.Bytes(), &r); err != nil {
		t.Fatal(err)
	}
	if r.Requests != 5 || r.InvalidLines != 1 || r.Slow != 2 {
		t.Errorf("requests=%d invalid=%d slow=%d", r.Requests, r.InvalidLines, r.Slow)
	}
	if r.StatusClass["2xx"] != 4 || r.StatusClass["5xx"] != 1 {
		t.Errorf("status classes = %v", r.StatusClass)
	}
	if len(r.TopPaths) != 2 || r.TopPaths[0].Path != "/api/users" || r.TopPaths[0].Count != 3 {
		t.Errorf("top paths = %+v", r.TopPaths)
	}
	if r.P50 != "120ms" || r.P99 != "2s" {
		t.Errorf("p50=%s p99=%s", r.P50, r.P99)
	}
	if !strings.Contains(errOut.String(), "skipping invalid line") {
		t.Errorf("no warning logged: %q", errOut.String())
	}
}

func TestTimeFilterAndGzip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "access.log.gz")
	var buf bytes.Buffer
	zw := gzip.NewWriter(&buf)
	zw.Write([]byte(sample))
	zw.Close()
	if err := os.WriteFile(path, buf.Bytes(), 0o644); err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	args := []string{"-json", "-from", "2026-11-01T10:00:01Z", "-to", "2026-11-01T10:00:04Z", path}
	if err := run(context.Background(), args, nil, &out, new(bytes.Buffer)); err != nil {
		t.Fatal(err)
	}
	var r Report
	json.Unmarshal(out.Bytes(), &r)
	if r.Requests != 3 { // 10:00:01, :02, :03
		t.Errorf("requests = %d, want 3", r.Requests)
	}
}

func TestBadFlags(t *testing.T) {
	for _, args := range [][]string{{"-top", "0"}, {"-from", "yesterday"}, {"-nosuchflag"}} {
		if err := run(context.Background(), args, strings.NewReader(""), new(bytes.Buffer), new(bytes.Buffer)); err == nil {
			t.Errorf("run(%q) succeeded", args)
		}
	}
}

func BenchmarkScan(b *testing.B) {
	var sb strings.Builder
	for i := range 10_000 {
		fmt.Fprintf(&sb, "2026-11-01T10:%02d:%02dZ GET /p/%d 200 %dms 100\n", i/60%60, i%60, i%50, i%900)
	}
	input := sb.String()
	b.SetBytes(int64(len(input)))
	for b.Loop() {
		if err := run(context.Background(), []string{"-json"}, strings.NewReader(input), new(bytes.Buffer), new(bytes.Buffer)); err != nil {
			b.Fatal(err)
		}
	}
}
```

A real run:

```
$ printf '...four valid lines and one "garbage" line...' | ./logscan
time=2026-11-15T01:15:20.651Z level=WARN msg="skipping invalid line" file=stdin line=4 err="want 6 fields, got 1"
requests             4
invalid lines        1
bytes sent           1088
time range           2026-11-01T10:00:00Z – 2026-11-01T10:00:04Z
status 2xx           3
status 5xx           1
slow requests        2
latency p50/p95/p99  120ms / 2s / 2s
top paths
  /api/users         3
  /api/orders        1
```

The benchmark reports about **51 MB/s** on the machine used for this book. That is slow for line parsing — Chapter 10's project profiles this program and finds why (spoiler: `fmt.Sscanf` and `time.Parse` dominate).

### Review checklist

- Run it on a generated 1 GB file and watch memory (`/usr/bin/time -v`): does it stay flat?
- Does a `.gz` file give exactly the same report as the uncompressed file?
- Are the first, middle, and last percentile buckets correct? (Test with 100 requests of 1..100 ms: p50 must be 50ms, p95 95ms.)
- Is any invalid line silently dropped without being counted?
- Does Ctrl+C on a large file print a partial report within a second?
- Is the JSON schema documented (field names are an API, Unit 8.6)?

### Extensions

1. Accept JSON Lines input (`{"time":...,"path":...}`) with `-format jsonl`, using `json.Decoder` in streaming mode.
2. Add per-minute request counts (a map keyed by `t.Truncate(time.Minute)`): what is the memory bound now?
3. Read several files concurrently (after Chapter 7) and merge their `stats`.

## Answers to the Chapter 5 prediction questions

**5.1 Q2.** `hello`; `io.Copy` returns `3, nil` (EOF is not an error for `Copy`).

**5.3 Q2.** `/b` (cannot go above the root); `""`; `a/b` (`Join` does not treat a leading `/` in later elements as absolute).

**5.4 Q2.** `{"s":null}`; `{}` — `omitempty` omits an empty slice; `{}`.

**5.5 Q2.** 258 = 0x0102: big-endian `01 02`, little-endian `02 01`. `AppendUvarint(nil, 127)` is 1 byte; 128 needs 2 bytes (7 bits per byte).

**5.6 Q2.** (a) 2026-03-03 (b) the literal text `YYYY` (c) 1h30m0s (d) 2 nanoseconds (DT-138).

**5.7 Q2.** `n = 3`; `fs.Args()` is `["file.txt", "-v"]`; `-v` is not parsed because flag parsing stops at the first non-flag argument.
