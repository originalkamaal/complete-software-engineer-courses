# Chapter 9 — Databases, Persistence & Caching

*Goal: store data correctly and fast.*

Almost every backend system is, at its core, a careful conversation with a database. Most production incidents in such systems are not exotic: a missing index, a lost update between two concurrent requests, a migration that locked a table, a connection pool exhausted by a slow query, a cache that served stale data or collapsed under a stampede. This chapter teaches you to prevent each of them.

Everything in this chapter was run against a real PostgreSQL 16 server and a real Redis server while writing it; the query plans, timings, and anomalies you will see are real output.

**What you will be able to do after this chapter**

- Design relational schemas and write the SQL you need (joins, grouping, constraints).
- Read query plans and choose indexes; know why deep OFFSET pagination is slow.
- Use `database/sql` and `pgx` correctly: pools, contexts, scanning, NULLs, errors.
- Use transactions and isolation levels to prevent lost updates and other anomalies.
- Evolve schemas safely with migrations, and stop SQL injection.
- Understand spatial data in PostgreSQL/PostGIS (for the routing chapters).
- Cache with cache-aside, TTLs, invalidation, and stampede protection.
- Test against real databases.

## Topic 9A — SQL and schema design

## Unit 9.1 — Relational model and SQL

**One-line summary:** A relational database stores data in **tables** of rows and typed columns, connects tables through **keys**, and enforces rules with **constraints**. SQL describes *what* data you want (`SELECT … FROM … JOIN … WHERE … GROUP BY …`); the database decides *how* to get it.

**Mental model — a set of well-kept ledgers.** Each table is a ledger with fixed columns. Every row has a unique ID (the **primary key**). Ledgers refer to each other by those IDs (**foreign keys**), so a fact is written once — a customer's address lives in the customers ledger, not copied into every order — and the clerk (the database) refuses entries that break the rules.

### A schema

```sql
CREATE TABLE customers (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email      text NOT NULL UNIQUE,
    name       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE orders (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id  bigint NOT NULL REFERENCES customers (id),
    status       text   NOT NULL CHECK (status IN ('new', 'paid', 'shipped', 'cancelled')),
    amount_paise bigint NOT NULL CHECK (amount_paise >= 0),   -- P-8: money as integers
    created_at   timestamptz NOT NULL DEFAULT now()
);
```

Constraints are your last line of defence: `NOT NULL`, `UNIQUE`, `CHECK`, `REFERENCES` (foreign keys), and `PRIMARY KEY` are enforced for **every** writer — your service, a migration, a support engineer with `psql`. Application validation (P-4) gives good error messages; constraints guarantee integrity. Use both.

Types worth knowing in PostgreSQL: `bigint` (Go `int64`), `text` (Go `string`; no length limit, add `CHECK` if needed), `boolean`, `numeric` (exact decimals), `timestamptz` (an instant; always prefer it over `timestamp`, which has no time zone), `date`, `jsonb` (indexed JSON), `uuid`, arrays (`text[]`).

### Querying

```sql
-- the 5 customers who spent the most on paid orders this year
SELECT c.name, sum(o.amount_paise) AS total_paise, count(*) AS orders
FROM orders o
JOIN customers c ON c.id = o.customer_id
WHERE o.status = 'paid'
  AND o.created_at >= date_trunc('year', now())
GROUP BY c.id, c.name
HAVING count(*) >= 2
ORDER BY total_paise DESC
LIMIT 5;
```

- `JOIN … ON` combines rows from two tables where the condition holds (an **inner** join). `LEFT JOIN` keeps every row from the left table, with NULLs where the right has no match (the project's daily-hits query uses one to show days with zero hits).
- `WHERE` filters rows *before* grouping; `HAVING` filters groups *after*.
- `GROUP BY` collapses rows into groups for aggregates (`count`, `sum`, `avg`, `min`, `max`).
- **Logical order of evaluation:** FROM/JOIN → WHERE → GROUP BY → HAVING → SELECT → ORDER BY → LIMIT. This explains why you cannot use a SELECT alias in WHERE.

`INSERT … RETURNING`, `UPDATE … RETURNING`, and `INSERT … ON CONFLICT … DO UPDATE` (an **upsert**) are PostgreSQL features the project uses heavily — each saves a round trip and avoids race conditions between "check" and "write".

### Normalisation

Store each fact once. If a customer's email is copied into every order row, changing it requires updating many rows, and they can disagree. **Normal forms** formalise this: every non-key column should depend on the key, the whole key, and nothing but the key. In practice: one table per entity, foreign keys for relationships, a join table for many-to-many relationships (`order_items(order_id, product_id, quantity)`).

**Denormalisation** (deliberately storing derived or duplicated data) is a performance tool, used with care: the project stores `links.hits` (a running total) *and* `daily_hits` (per-day counts), because reading one number is much cheaper than counting millions of click rows on every stats request. The cost is keeping them consistent — which is why the project updates both in one transaction.

### NULL

`NULL` means "unknown", and SQL uses three-valued logic: `NULL = NULL` is NULL (not true), `WHERE x <> 'a'` skips rows where x is NULL, `count(column)` skips NULLs. Use `IS NULL` / `IS NOT NULL`, and declare columns `NOT NULL` unless "unknown" is a real state. In Go, NULLs need special types (Unit 9.3).

### Deep & Tricky

**DT-250. PostgreSQL stores timestamps with microsecond precision; Go has nanoseconds.** *(Seen in this chapter's project)* A `time.Time` created with `time.Now()` and stored in `timestamptz` comes back with its last three digits gone: `…876921805Z` became `…876921Z`. Tests that compare a written value with the read value using `==` or `Equal` fail mysteriously. Truncate before storing (`t.Truncate(time.Microsecond)`) or compare with tolerance.

**DT-251. `NOT IN` with a NULL in the list returns nothing.** *(SQL three-valued logic)* `WHERE id NOT IN (SELECT customer_id FROM blocked)` returns no rows at all if any `customer_id` is NULL, because `x <> NULL` is unknown. Use `NOT EXISTS`, which behaves as expected.

### Mastery check

1. **Explain.** Why should integrity rules live in the database as constraints even if the application validates input?
2. **Predict.** How many rows does `SELECT count(*), count(email) FROM customers` return, and how do the two counts differ?
3. **Write.** A schema for a library (books, copies, members, loans) with all constraints you can justify, and a query listing members with overdue loans and how many days overdue.

## Unit 9.2 — Indexes and query plans

**One-line summary:** An index is a separate, sorted data structure (usually a B-tree, Unit 6.7) that lets the database find rows without scanning the whole table. `EXPLAIN ANALYZE` shows the plan the database chose and what it actually cost. Indexes speed up reads and slow down writes; choose them from your queries.

### Seeing the difference

A table of 1,000,000 orders, searching for one customer's orders — real output:

```
EXPLAIN ANALYZE SELECT * FROM orders WHERE customer_id = 4242;

-- without an index on customer_id
 Gather  (cost=1000.00..14813.43 rows=11 width=38) (actual time=2.739..26.596 rows=14 loops=1)
   Workers Planned: 2
   ->  Parallel Seq Scan on orders  (cost=0.00..13812.33 rows=5 width=38) (actual time=1.499..20.550 rows=5 loops=3)
         Filter: (customer_id = 4242)
         Rows Removed by Filter: 333329
 Execution Time: 26.618 ms

-- after CREATE INDEX orders_customer_idx ON orders (customer_id);
 Bitmap Heap Scan on orders  (cost=4.51..47.47 rows=11 width=38) (actual time=0.033..0.050 rows=14 loops=1)
   Recheck Cond: (customer_id = 4242)
   ->  Bitmap Index Scan on orders_customer_idx  (cost=0.00..4.51 rows=11 width=0) (actual time=0.028..0.028 rows=14 loops=1)
         Index Cond: (customer_id = 4242)
 Execution Time: 0.070 ms
```

From 26.6 ms (three processes reading a million rows and throwing away 999,986 of them) to 0.07 ms — **380 times faster**. At 1,000 requests per second, the first version needs about 27 CPU-seconds per second; the second needs 0.07.

### Reading a plan

- Read from the **innermost** (most indented) node outwards.
- `cost=start..total` is the planner's *estimate* in abstract units; `actual time=start..total` and `rows=` are *measurements* (with `ANALYZE`). A big difference between estimated and actual rows means stale statistics (`ANALYZE table`) or a hard-to-estimate condition.
- Node types: `Seq Scan` (read everything), `Index Scan` (follow the index, fetch each row), `Index Only Scan` (the index contains all needed columns), `Bitmap Heap Scan` (collect matching row locations from the index, then read the table pages in order), `Nested Loop` / `Hash Join` / `Merge Join` (join strategies), `Sort`, `Limit`.
- `EXPLAIN (ANALYZE, BUFFERS)` adds how many pages came from cache vs disk.

A sequential scan is not always bad: for a query returning a large fraction of a table, reading everything sequentially beats jumping around through an index (Unit 0.5's locality again). The planner chooses using statistics.

### Designing indexes

- Index the columns used in `WHERE`, `JOIN`, and `ORDER BY` of frequent queries.
- **Composite indexes** serve queries on a *prefix* of their columns: an index on `(customer_id, created_at)` serves `WHERE customer_id = ?` and `WHERE customer_id = ? AND created_at > ?` and `… ORDER BY created_at`, but not `WHERE created_at > ?` alone. Put equality columns first, range or sort columns last.
- **Unique indexes** enforce `UNIQUE` constraints (the project's primary key on `code` is one).
- **Partial indexes** index only some rows: `CREATE INDEX ON orders (created_at) WHERE status = 'new'`.
- **Expression indexes**: a function applied to a column defeats a plain index:

```
EXPLAIN SELECT * FROM orders WHERE date_trunc('day', created_at) = '2026-06-01';
 Parallel Seq Scan on orders
   Filter: (date_trunc('day'::text, created_at) = ...)
```

Rewrite as a range (`created_at >= '2026-06-01' AND created_at < '2026-06-02'`), or create an index on the expression.

- Every index slows `INSERT`/`UPDATE`/`DELETE` and uses disk and memory. Do not index "just in case"; check `pg_stat_user_indexes` for indexes never used.
- On a live table, `CREATE INDEX CONCURRENTLY` builds without blocking writes (Unit 9.5).

### Why deep OFFSET pagination is slow

Real output, same table, page 45,001 of 20 rows:

```
EXPLAIN ANALYZE SELECT id, created_at FROM orders ORDER BY created_at, id LIMIT 20 OFFSET 900000;
 Limit (actual time=511.139..511.151 rows=20 loops=1)
   ->  Index Only Scan using orders_created_idx on orders (actual time=0.047..486.967 rows=900020 loops=1)
 Execution Time: 511.166 ms

EXPLAIN ANALYZE SELECT id, created_at FROM orders
WHERE (created_at, id) > ($last_created_at, $last_id) ORDER BY created_at, id LIMIT 20;
 Limit (actual time=0.035..0.048 rows=20 loops=1)
   ->  Index Only Scan using orders_created_idx on orders (actual time=0.034..0.045 rows=20 loops=1)
         Index Cond: (ROW(created_at, id) > ROW(...))
 Execution Time: 0.068 ms
```

OFFSET must walk past 900,000 index entries to throw them away (511 ms); **keyset** (cursor) pagination seeks directly to the last-seen key and reads 20 (0.07 ms). This is the reason behind Unit 8.6's advice. The `id` in the key breaks ties, so no row is skipped or repeated when timestamps are equal.

### Deep & Tricky

**DT-252. A query on a nullable or low-selectivity column may ignore your index — correctly.** *(Planner behaviour)* An index on `status` (4 values over a million rows) rarely helps: each value matches 25% of the table, and a sequential scan is cheaper. Indexes pay off for *selective* conditions. Check the plan instead of assuming.

**DT-253. `LIKE 'abc%'` can use a B-tree index; `LIKE '%abc'` cannot.** *(Index structure)* A sorted index can find a prefix range, not a suffix or substring. Substring search needs a trigram index (`pg_trgm`) or full-text search.

### Mastery check

1. **Explain.** Why does an index on `(customer_id, created_at)` help `WHERE customer_id = 7 ORDER BY created_at DESC LIMIT 10` but not `WHERE created_at > now() - interval '1 day'`?
2. **Explain.** In the OFFSET plan, why does the `Index Only Scan` show `rows=900020`?
3. **Write.** Load a million rows of your own, write three queries your application would run, and design indexes for them. Record `EXPLAIN ANALYZE` before and after for each.

## Topic 9B — Go and databases

## Unit 9.3 — database/sql and pgx

**One-line summary:** Go talks to databases through a **connection pool**. `database/sql` is the standard, driver-agnostic API; `pgx` is a PostgreSQL-specific driver and toolkit with its own faster API (`pgxpool`). Always pass a context, always close rows, scan into typed variables, and handle `NULL` and "no rows" explicitly.

### The pool

`sql.Open` / `pgxpool.New` do not open a single connection; they create a **pool** that opens connections on demand, reuses them, and limits their number. Create **one pool per database per process** at startup and share it (it is safe for concurrent use).

```go
cfg, err := pgxpool.ParseConfig(dsn)
if err != nil {
	return nil, err
}
cfg.MaxConns = 20                    // more is not better: see DT-254
cfg.MaxConnIdleTime = 5 * time.Minute
db, err := pgxpool.NewWithConfig(ctx, cfg)
if err != nil {
	return nil, err
}
if err := db.Ping(ctx); err != nil { // fail fast at startup if the database is unreachable
	return nil, err
}
```

The equivalent with `database/sql`: `db, err := sql.Open("pgx", dsn)` (using pgx's `stdlib` adapter), then `db.SetMaxOpenConns(20)`, `db.SetMaxIdleConns(20)`, `db.SetConnMaxIdleTime(5*time.Minute)`.

### Exec, Query, QueryRow

```go
// Exec: statements that return no rows
tag, err := db.Exec(ctx, `UPDATE links SET hits = hits + 1 WHERE code = $1`, code)
if tag.RowsAffected() == 0 { /* no such code */ }

// QueryRow: exactly one row expected
var l links.Link
err := db.QueryRow(ctx,
	`SELECT code, url, created_at, hits FROM links WHERE code = $1`, code,
).Scan(&l.Code, &l.URL, &l.CreatedAt, &l.Hits)
if errors.Is(err, pgx.ErrNoRows) { // database/sql: sql.ErrNoRows
	return links.Link{}, links.ErrNotFound
}

// Query: many rows
rows, err := db.Query(ctx, `SELECT code, hits FROM links ORDER BY hits DESC LIMIT $1`, n)
if err != nil {
	return nil, err
}
defer rows.Close() // returns the connection to the pool
var out []TopLink
for rows.Next() {
	var t TopLink
	if err := rows.Scan(&t.Code, &t.Hits); err != nil {
		return nil, err
	}
	out = append(out, t)
}
return out, rows.Err() // an error that ended the iteration early
```

pgx also offers `pgx.CollectRows(rows, pgx.RowToStructByName[T])` and similar helpers that remove the loop boilerplate; the project's `Daily` uses `CollectRows`.

Rules:

- **Placeholders, always** (`$1`, `$2` in PostgreSQL; `?` in MySQL and SQLite). Never build SQL with `fmt.Sprintf` and user data (SQL injection, Unit 9.5).
- **Context on every call** (P-33): a cancelled request stops waiting for its query, and the driver cancels the query on the server.
- **Close rows** (`defer rows.Close()`), or the connection never returns to the pool, and after `MaxConns` leaks every query waits forever.
- **Check `rows.Err()`** after the loop — the same lesson as `scanner.Err()` (Unit 1.12).

### NULLs in Go

A column that can be NULL cannot be scanned into a plain `string` (error: "cannot scan NULL into *string"). Options: a pointer (`*string`, nil for NULL), `sql.Null[string]` (Go 1.22's generic version of `sql.NullString`), or pgx's `pgtype.Text`. Or avoid the problem: `NOT NULL` columns, `coalesce(col, '')` in the query when "empty" is acceptable.

### Errors from the database

PostgreSQL reports errors with a five-character SQLSTATE code. pgx exposes them as `*pgconn.PgError`:

```go
var pgErr *pgconn.PgError
if errors.As(err, &pgErr) && pgErr.Code == "23505" { // unique_violation
	return links.ErrCodeTaken
}
```

Common codes: `23505` unique violation, `23503` foreign key violation, `23514` check violation, `40001` serialization failure (retry, Unit 9.4), `40P01` deadlock detected (retry), `57014` query cancelled. Translating them into domain errors (P-26) keeps SQL details out of the rest of the program.

### `database/sql` vs pgx

| | `database/sql` (+ a driver) | pgx native API |
| --- | --- | --- |
| Databases | any with a driver | PostgreSQL only |
| Performance | good | better (binary protocol, fewer allocations) |
| PostgreSQL features | basic | arrays, `COPY`, `LISTEN/NOTIFY`, batch queries, rich types |
| Ecosystem | `sqlc`, `sqlx`, many ORMs | `sqlc` supports it too |

For a PostgreSQL-only service, pgx's native API is the common choice; libraries that must support several databases use `database/sql`. Many teams generate type-safe Go code from SQL with `sqlc` instead of writing scanning by hand — a good middle ground between hand-written SQL and an ORM.

### Deep & Tricky

**DT-254. A bigger connection pool can make a database slower.** *(Database behaviour)* Each PostgreSQL connection is a process with its own memory; beyond a few times the number of CPU cores, more concurrent queries just contend for CPU, locks, and disk, and throughput drops. With 10 service instances × 50 connections you have 500 backends — often worse than 10 × 10. Size pools from measurement; put PgBouncer in front of PostgreSQL when many instances share one database.

**DT-255. A query that is waiting for a pool connection is not yet running.** *(Pool behaviour)* When all connections are busy, `Query` blocks inside the pool until one frees up (or the context ends). Latency graphs show "slow queries" that are actually fast queries queued behind a few slow ones. `db.Stat()` (`pgxpool.Stat`: `EmptyAcquireCount`, `AcquireDuration`) reveals pool waits; export it as a metric (Unit 11.5).

**DT-256. Holding a transaction or an unclosed `rows` while calling another service ties up a connection.** *(Practice)* A handler that opens a transaction, then calls a slow payment API, then commits, holds a database connection (and row locks) for the whole call. Under load the pool empties. Do external calls outside transactions.

### Mastery check

1. **Explain.** What happens to the pool if a function returns early without `rows.Close()`, and how would the bug show up in production?
2. **Explain.** Why should `UNIQUE` violations be detected from the database error rather than by checking with a `SELECT` first?
3. **Write.** `TopLinks(ctx, n int) ([]links.Link, error)` with `pgx.CollectRows` and `pgx.RowToStructByName`, plus an integration test (Unit 9.8).

## Unit 9.4 — Transactions

**One-line summary:** A transaction groups statements so they succeed or fail together (**atomicity**) and controls how concurrent transactions see each other (**isolation**). PostgreSQL's default, READ COMMITTED, still allows **lost updates** with read-modify-write code. Fix them with atomic statements, row locks (`SELECT … FOR UPDATE`), or SERIALIZABLE isolation with retries.

### ACID

- **Atomicity:** all statements commit, or none do (`ROLLBACK`, or a crash before `COMMIT`).
- **Consistency:** constraints hold after every transaction.
- **Isolation:** concurrent transactions do not see each other's partial work; the *level* decides how much they can see.
- **Durability:** once `COMMIT` returns, the data survives a crash (it is in the write-ahead log on disk).

### Transactions in Go

```go
err := pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
	// every statement uses tx, not db
	if _, err := tx.Exec(ctx, `UPDATE accounts SET balance = balance - $1 WHERE id = $2`, amt, from); err != nil {
		return err // BeginFunc rolls back
	}
	_, err := tx.Exec(ctx, `UPDATE accounts SET balance = balance + $1 WHERE id = $2`, amt, to)
	return err // nil: BeginFunc commits
})
```

`pgx.BeginFunc` commits if the function returns nil and rolls back otherwise (including on panic). With `database/sql`, the manual form is `tx, err := db.BeginTx(ctx, nil)`, then `defer tx.Rollback()` (a no-op after a successful commit), then `tx.Commit()`. The classic bug: using `db.Exec` instead of `tx.Exec` inside the transaction — that statement runs on *another* connection, outside the transaction.

### The lost update — measured

Fifty goroutines each add 1 to a balance, concurrently, against real PostgreSQL. Five strategies, real results:

```
read-modify-write (lost updates)   balance =  2  (failed: 0)
atomic update                      balance = 50  (failed: 0)
select ... for update              balance = 50  (failed: 0)
serializable, no retry             balance =  6  (failed: 44)
serializable, with retry           balance = 50  (failed: 0)
```

1. **Read-modify-write** (`SELECT balance`, compute `b+1` in Go, `UPDATE … SET balance = $1`): **48 of 50 increments were lost**, with no error anywhere. Every goroutine read nearly the same old balance and overwrote the others — Unit 7.1's `counter++` race, at database scale. This is the default behaviour under READ COMMITTED.
2. **Atomic update** (`UPDATE accounts SET balance = balance + 1`): correct. The database reads and writes the row under its own row lock. Prefer this whenever the change can be expressed in one statement.
3. **`SELECT … FOR UPDATE`** inside a transaction: correct. The `SELECT` locks the row; other transactions wait at their own `SELECT … FOR UPDATE` until the first commits. Use it when the new value needs logic in Go between read and write.
4. **SERIALIZABLE without retry:** the database detects that concurrent transactions could not have run in some serial order and **aborts** them with SQLSTATE `40001` — 44 failed. Correct (nothing was lost silently), but useless without the next step.
5. **SERIALIZABLE with retry:** correct. Retry the whole transaction on `40001`.

The code of the read-modify-write and retry versions:

```go
// WRONG under concurrency: lost updates
var b int64
db.QueryRow(ctx, `SELECT balance FROM accounts WHERE id = 1`).Scan(&b)
db.Exec(ctx, `UPDATE accounts SET balance = $1 WHERE id = 1`, b+1)

// SERIALIZABLE with retry
for {
	err := pgx.BeginTxFunc(ctx, db, pgx.TxOptions{IsoLevel: pgx.Serializable}, func(tx pgx.Tx) error {
		var b int64
		if err := tx.QueryRow(ctx, `SELECT balance FROM accounts WHERE id = 1`).Scan(&b); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `UPDATE accounts SET balance = $1 WHERE id = 1`, b+1)
		return err
	})
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "40001" { // serialization_failure: try again
		continue // production code: bounded retries with backoff and jitter (Unit 12.7)
	}
	return err
}
```

### Isolation levels and anomalies

| Level (PostgreSQL) | Dirty read | Non-repeatable read | Phantom read | Lost update / write skew |
| --- | --- | --- | --- | --- |
| READ COMMITTED (default) | no | possible | possible | possible |
| REPEATABLE READ (snapshot) | no | no | no (in PostgreSQL) | lost update detected (error); **write skew possible** |
| SERIALIZABLE | no | no | no | no (aborts with `40001`) |

- **Non-repeatable read:** reading the same row twice in one transaction gives different values because another transaction committed in between.
- **Phantom:** re-running a query returns new rows inserted by another transaction.
- **Write skew:** two transactions read overlapping data, make decisions, and write *different* rows, together breaking a rule neither broke alone. Classic example: "at least one doctor must be on call" — two doctors each check that the other is on call and both go off call. Only SERIALIZABLE (or explicit locking) prevents it.

### Locking and deadlocks

Writes lock rows until commit. Two transactions that lock rows in opposite orders deadlock; PostgreSQL detects it after `deadlock_timeout` (1 s by default) and aborts one with `40P01`. Prevent with a consistent lock order (sort IDs before updating several rows — the same rule as Unit 7.8), keep transactions short, and treat `40P01` as retryable.

### Deep & Tricky

**DT-257. Isolation anomalies produce no errors at READ COMMITTED.** *(Measured above)* The lost-update run returned `failed: 0` and a balance of 2. Nothing in logs, no exception: just wrong data. That is why "it works in testing" means little for concurrent database code; test with real concurrency against a real database.

**DT-258. Retrying requires the whole transaction to be re-run, including the reads.** *(Practice)* Retrying only the failed `UPDATE` reuses a stale read and recreates the bug. Put the entire transaction in a function and retry the function, and make sure it has no side effects outside the database (no emails sent inside the transaction function).

### Pattern

**P-35. Prefer one atomic statement; otherwise lock or serialize — and retry.** *(Data-correctness practice)*

- *Problem it solves:* lost updates and check-then-act races in concurrent requests.
- *How:* express changes as single statements (`SET x = x + 1`, `INSERT … ON CONFLICT`, `UPDATE … WHERE version = $n RETURNING`); when logic must sit between read and write, use `SELECT … FOR UPDATE` or SERIALIZABLE with a bounded retry loop on `40001`/`40P01`.
- *When not to:* read-only reporting queries need none of this.
- *Trade-off:* locks reduce concurrency; SERIALIZABLE costs retries under contention; atomic statements are the cheapest when they fit.

### Mastery check

1. **Explain.** Why did the read-modify-write version lose 48 updates without any error?
2. **Explain.** Write skew: why does REPEATABLE READ not prevent the on-call doctors example, and what does?
3. **Write.** A `Transfer(ctx, from, to, amount)` that never lets a balance go negative, is safe under concurrency, and cannot deadlock when two transfers between the same accounts run in opposite directions. Test it with 100 concurrent transfers and check that the total money is unchanged.

## Unit 9.5 — Migrations and safety

**One-line summary:** Schema changes are code: versioned **migration** files applied in order, recorded in the database, reviewed like code, and designed to run against a live database without downtime. Queries are always parameterised, which makes SQL injection impossible.

### Migrations

A migration is a numbered SQL file. A migration tool records which ones have run (the project uses a `schema_migrations` table) and applies the rest in order at deploy time. The project's minimal migrator embeds the files into the binary (`//go:embed`, Unit 5.3), takes a PostgreSQL **advisory lock** so two instances starting at once do not both migrate, and runs each file in its own transaction (PostgreSQL can roll back DDL):

```go
//go:embed migrations/*.sql
var migrations embed.FS

func Migrate(ctx context.Context, db *pgxpool.Pool) error {
	conn, err := db.Acquire(ctx)
	if err != nil {
		return err
	}
	defer conn.Release()

	const lockID = 727274 // any constant shared by all instances
	if _, err := conn.Exec(ctx, `SELECT pg_advisory_lock($1)`, lockID); err != nil {
		return err
	}
	defer conn.Exec(context.Background(), `SELECT pg_advisory_unlock($1)`, lockID)
	...
}
```

Mature tools (`golang-migrate`, `goose`, `atlas`) add down-migrations, dirty-state detection, and CLI support; the principles are the same.

### Changing a live schema safely

During a rolling deploy, **old and new versions of your code run at the same time against the same schema**. So every migration must be compatible with the code before and after it. The **expand–contract** pattern:

1. **Expand:** add the new column (nullable, or with a default), new table, or new index — old code ignores it.
2. **Migrate code:** deploy code that writes both old and new, then reads new.
3. **Backfill** existing rows in small batches (not one giant `UPDATE` that locks the table and bloats the log).
4. **Contract:** once no code uses the old column, drop it in a later release.

Dangerous operations on big tables: adding a column with a volatile default (rewrites the table in old PostgreSQL versions), adding `NOT NULL` without a default, changing a column's type, creating an index without `CONCURRENTLY` (blocks writes for the whole build). Set `lock_timeout` in migrations so a migration that cannot get its lock fails fast instead of queueing behind a long query and blocking all traffic behind *itself*.

### SQL injection

```go
// VULNERABLE: user input becomes SQL
q := fmt.Sprintf("SELECT * FROM links WHERE code = '%s'", code)
// code = "x' OR '1'='1"  → returns every row
// code = "x'; DROP TABLE links; --"  → worse

// SAFE: the value is sent separately from the SQL text
db.QueryRow(ctx, `SELECT * FROM links WHERE code = $1`, code)
```

With placeholders, the database receives the SQL and the values separately; no value can change the query's structure. Identifiers (table and column names) cannot be parameterised: if they must vary, choose from a fixed allow-list in code (`switch sortColumn { case "hits": … }`) or quote with `pgx.Identifier{name}.Sanitize()`. Prepared statements (pgx prepares and caches statements automatically) also save parsing time for repeated queries.

### Deep & Tricky

**DT-259. A migration waiting for a lock blocks everything behind it.** *(PostgreSQL locking)* `ALTER TABLE` needs a strong lock. If a long-running query holds a weaker lock, the `ALTER` waits — and every new query on that table queues behind the `ALTER`. A two-second schema change becomes a full outage. Always `SET lock_timeout = '3s'` (and retry later) in migrations on busy tables.

### Mastery check

1. **Explain.** Why must a migration work with both the old and the new version of the code?
2. **Write.** Plan (as a sequence of migrations and deploys) renaming `links.url` to `links.target_url` with zero downtime.

## Topic 9C — Spatial data

## Unit 9.6 — PostgreSQL + PostGIS introduction

**One-line summary:** PostGIS adds geometry and geography types, spatial functions, and spatial indexes (GiST, an R-tree-like structure) to PostgreSQL, so "find the 5 nearest charging stations" or "which delivery zone contains this point" become indexed SQL queries. Chapter 13 builds on these ideas.

*(PostGIS was not installed on the machine used to write this chapter, so the SQL below is shown but was not executed here. It uses standard, long-stable PostGIS functions.)*

### Types

- `geometry(Point, 4326)`: coordinates in a planar system; with SRID 4326 (WGS84 longitude/latitude, Unit 13.1) distances come out in **degrees**, which is wrong for most purposes.
- `geography(Point, 4326)`: coordinates on the Earth's ellipsoid; distances in **metres**. Simpler to use correctly, a bit slower.
- `LineString` (a road), `Polygon` (a zone), `MultiPolygon` (a city with islands).

```sql
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE stations (
    id   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    loc  geography(Point, 4326) NOT NULL
);
CREATE INDEX stations_loc_idx ON stations USING gist (loc);

INSERT INTO stations (name, loc)
VALUES ('Shivajinagar', ST_SetSRID(ST_MakePoint(73.8478, 18.5308), 4326)::geography); -- (lon, lat)!
```

### Queries

```sql
-- stations within 2 km of a point (uses the GiST index)
SELECT name, ST_Distance(loc, ST_MakePoint(73.8567, 18.5204)::geography) AS metres
FROM stations
WHERE ST_DWithin(loc, ST_MakePoint(73.8567, 18.5204)::geography, 2000)
ORDER BY metres;

-- the 5 nearest stations: index-assisted nearest neighbour with the <-> operator
SELECT name
FROM stations
ORDER BY loc <-> ST_MakePoint(73.8567, 18.5204)::geography
LIMIT 5;

-- which zone contains a point
SELECT zone_id FROM zones WHERE ST_Contains(boundary, ST_SetSRID(ST_MakePoint($1, $2), 4326));
```

Two classic bugs: **longitude comes first** in `ST_MakePoint(lon, lat)` (the opposite of how people say coordinates), and `ST_Distance(a, b) < 2000` in `WHERE` cannot use the index while `ST_DWithin` can.

### From Go

Pass coordinates as plain numbers and build points in SQL (`ST_MakePoint($1, $2)`), or exchange well-known text/binary (`ST_AsText`, `ST_GeomFromText`). Libraries such as `github.com/twpayne/go-geom` handle encoding when you need full geometries.

### Mastery check

1. **Explain.** Why is `geometry` with SRID 4326 a trap for distance queries?
2. **Write.** (If you can install PostGIS.) Load 100,000 random points in a city's bounding box, and compare `EXPLAIN ANALYZE` of a 1 km `ST_DWithin` query with and without the GiST index.

## Topic 9D — Caching

## Unit 9.7 — Caching strategies

**One-line summary:** A cache keeps copies of expensive-to-get data in faster storage. **Cache-aside** (read the cache, on a miss read the source and fill the cache) with a **TTL** is the default pattern. The hard parts are **invalidation** (stale data), **stampedes** (many simultaneous misses), and deciding what consistency your users actually need.

**Mental model — the kitchen counter again.** Unit 0.5's counter (L1 cache) and kirana shop (RAM) are the same idea one level up: Redis or an in-process map is the counter; the database is the shop. A good cache serves most requests from the counter; a bad one serves stale milk.

### Where to cache

| Layer | Example | Speed | Shared across instances? |
| --- | --- | --- | --- |
| In-process | a map + mutex, the LRU of Unit 6.13 | ~100 ns | no |
| Distributed | Redis, Memcached | ~0.2–1 ms (network) | yes |
| HTTP | `Cache-Control`, CDN | avoids reaching you at all | yes |
| Database | its own buffer cache | automatic | — |

### Cache-aside

```go
func (c *Links) lookup(ctx context.Context, code string) (string, error) {
	v, found, err := c.kv.Get(ctx, key(code))
	if err != nil {
		c.log.WarnContext(ctx, "cache get failed; using database", "err", err)
	} else if found {
		if v == notFound {
			return "", links.ErrNotFound
		}
		return v, nil
	}
	res, err, _ := c.group.Do(code, func() (any, error) {
		l, err := c.backend.Get(ctx, code)
		switch {
		case errors.Is(err, links.ErrNotFound):
			c.kv.Set(ctx, key(code), notFound, c.negTTL)
			return "", err
		case err != nil:
			return "", err
		}
		if err := c.kv.Set(ctx, key(code), l.URL, c.ttl); err != nil {
			c.log.WarnContext(ctx, "cache set failed", "err", err)
		}
		return l.URL, nil
	})
	if err != nil {
		return "", err
	}
	return res.(string), nil
}
```

(From this chapter's project.) Four production details are in those lines:

1. **A cache failure is not a request failure.** If Redis is down, log and fall through to the database. The cache is an optimisation.
2. **TTL.** Every entry expires (`c.ttl`), bounding how stale data can be and how long a bug's effects last.
3. **Negative caching.** "No such code" is cached briefly too, so a bot hammering random codes cannot turn every request into a database query.
4. **Stampede protection.** When a popular entry expires, hundreds of concurrent requests miss at once and all hit the database. `singleflight.Group` (from `golang.org/x/sync`) makes concurrent calls with the same key share one execution. The project's test proves it: **100 concurrent cold requests cause exactly 1 database read**.

### Invalidation

"There are only two hard things in computer science: cache invalidation and naming things." Strategies:

- **TTL only:** simplest; data is stale for up to the TTL. Fine for data that rarely changes or where slight staleness is harmless.
- **Delete on write:** after updating the database, delete the cache key; the next read refills it. Small race: a reader that loaded the old value just before the update can write it back to the cache after the delete. TTL limits the damage.
- **Write-through:** write the new value to the cache as part of the write (the project's `Create` does this, which also clears a cached "not found").
- **Versioned keys:** include a version or updated-at in the key; old entries simply age out.

Never cache without thinking: what is the worst thing a stale value can cause here? A stale redirect target for a minute is harmless; a stale account balance or permission is not.

### Write-behind batching

The project caches the redirect lookup, but each redirect also *counts a hit*. Writing a row per redirect would put the database right back on the hot path. Instead, hits are counted in memory and flushed every second in **one** statement for the whole batch (`UPDATE … FROM unnest($1::text[], $2::bigint[])`). The trade-offs, written down in the package documentation: counts reach the database up to a second late (the stats endpoint adds the pending counts so users do not notice), and a crash loses at most one second of counts. For hit counters that is a good trade; for payments it would be unacceptable.

### Redis basics

Redis is an in-memory data-structure server: strings with TTL (`SET key value EX 600`, `GET`), counters (`INCR`), hashes, lists, sets, sorted sets (leaderboards, rate limiters), pub/sub, streams. With `github.com/redis/go-redis/v9`:

```go
rdb := redis.NewClient(&redis.Options{Addr: "localhost:6379",
	DialTimeout: 2 * time.Second, ReadTimeout: 200 * time.Millisecond, WriteTimeout: 200 * time.Millisecond})
err := rdb.Set(ctx, "link:godocs", "https://go.dev/doc/", 10*time.Minute).Err()
v, err := rdb.Get(ctx, "link:godocs").Result()
if errors.Is(err, redis.Nil) { /* not in cache */ }
```

Short timeouts matter: a cache that takes 5 seconds to fail is worse than no cache.

### Deep & Tricky

**DT-260. Caches hide capacity problems until they fail.** *(Operations)* A database sized for 10% of traffic (because 90% hits the cache) falls over the moment the cache is flushed, restarted, or a deploy changes key formats — a "cold start" outage. Know your database's capacity without the cache, warm caches gradually, and use singleflight and request coalescing.

**DT-261. A decorator hides optional interfaces unless it forwards them.** *(Seen in this chapter's project, P-24)* The cache layer wraps the store. The store has an optional `Daily` method (checked with a type assertion, Unit 3.6), but the cache type does not have it unless it explicitly implements and forwards it. Without the forwarding method, the analytics endpoint would silently return 501 "not available" after adding the cache.

### Pattern

**P-36. Cache-aside with TTL, negative caching, and singleflight; the cache is never required.** *(Caching practice)* Read through the cache, fill on miss, expire everything, cache "not found" briefly, collapse concurrent misses, and treat every cache error as a miss. *Trade-off:* bounded staleness and extra moving parts in exchange for lower latency and database load.

### Mastery check

1. **Explain.** Describe the race in "delete on write" invalidation step by step. How does a TTL limit it?
2. **Explain.** What would happen to the database if the cache's singleflight were removed and a link with 5,000 requests per second expired?
3. **Write.** Add a `Delete` endpoint to the shortener: delete from the database, then invalidate the cache key. Write a test that would catch the stale-redirect bug if the invalidation were missing.

## Topic 9E — Testing with databases

## Unit 9.8 — Integration testing with real databases in containers

**One-line summary:** Database code must be tested against a real database of the same kind and version — mocks cannot reproduce SQL semantics, constraints, isolation, or query plans. Give each test an isolated database (or schema, or transaction), start the server in a container in CI, and skip cleanly when it is unavailable.

### Why not mock the database?

A mock of `Exec` and `QueryRow` would have "passed" every test of the lost-update code in Unit 9.4, never seen a `23505` unique violation, never noticed that PostgreSQL truncates nanoseconds (DT-250), and never tested a migration. The database's behaviour *is* what you are testing. Use fakes (the in-memory store) for testing *other* layers; test the store against the real thing.

### Isolation strategies

| Strategy | How | Speed | Notes |
| --- | --- | --- | --- |
| Database per test | `CREATE DATABASE test_<random>`, migrate, drop at cleanup | ~50–200 ms per test | complete isolation; the project uses this |
| Template database | migrate once into a template, `CREATE DATABASE … TEMPLATE` per test | fast | PostgreSQL feature |
| Schema per test | `CREATE SCHEMA`, set `search_path` | fast | isolation within one database |
| Transaction per test | begin, run the test, roll back | fastest | cannot test code that commits or uses several connections |

The project's helper:

```go
// newDB creates a fresh, migrated database for one test and drops it after.
// It needs TEST_DATABASE_URL pointing at a server where the user may create
// databases, e.g. postgres://postgres@localhost/postgres.
func newDB(t *testing.T) *pgxpool.Pool {
	t.Helper()
	admin := os.Getenv("TEST_DATABASE_URL")
	if admin == "" {
		t.Skip("TEST_DATABASE_URL not set; skipping PostgreSQL integration test")
	}
	ctx := context.Background()
	conn, err := pgx.Connect(ctx, admin)
	if err != nil {
		t.Fatal(err)
	}
	name := "test_" + strings.ToLower(rand.Text()[:10])
	if _, err := conn.Exec(ctx, "CREATE DATABASE "+name); err != nil {
		t.Fatal(err)
	}
	cfg, _ := pgx.ParseConfig(admin)
	cfg.Database = name
	db, err := Open(ctx, cfg.ConnString())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		db.Close()
		conn.Exec(ctx, "DROP DATABASE "+name)
		conn.Close(ctx)
	})
	return db
}
```

(`CREATE DATABASE` cannot take a placeholder; the name is generated by the test, never from input, so concatenation is safe here — and only here.)

### Containers

`docker run -d -p 5432:5432 -e POSTGRES_HOST_AUTH_METHOD=trust postgres:16` gives every developer and CI job the same database version. CI systems (GitHub Actions `services:`, GitLab services) start one next to the test job. The `testcontainers-go` library starts containers from inside `TestMain` (DT-182), waits until they accept connections, and removes them afterwards — so `go test ./...` works with no manual setup when Docker is available.

### Make it fast enough to run always

- Run integration tests in parallel (`t.Parallel`) — each has its own database.
- Migrate once into a template database, then clone it per test.
- Keep a separate build tag or the skip-without-environment approach for developers without Docker, but **always** run them in CI.

### Mastery check

1. **Explain.** Name three bugs from this chapter that a mocked database would never reveal.
2. **Write.** Convert the project's `newDB` to the template-database strategy and measure the time saved per test.

## Chapter 9 Project — The URL shortener on PostgreSQL, with a cache and analytics

**Goal:** turn the Chapter 8 shortener into a persistent, multi-instance-safe service: PostgreSQL storage with embedded migrations, per-day analytics, a Redis cache-aside layer with stampede protection and negative caching, batched hit counting, and integration tests against a real database.

### Requirements

1. `pgstore.Store` implements `links.Store` with `pgx`: unique codes enforced by the database (`23505` → `links.ErrCodeTaken`), `ErrNotFound` for missing codes, every call with a context.
2. Migrations embedded in the binary, applied at startup under an advisory lock, recorded in `schema_migrations`, safe to run twice.
3. `daily_hits(code, day, hits)` maintained in the same transaction as `links.hits`; a new endpoint `GET /api/links/{code}/daily?days=7` returns one entry per day including zeros (1–366 days).
4. `cache.Links` decorates the store: cache-aside for redirects, TTL 10 minutes, negative caching 30 s, `singleflight` for misses, Redis optional (in-process cache when `REDIS_ADDR` is empty), cache errors never fail requests.
5. Hits are counted in memory and flushed every second with one batched statement; a failed flush keeps the counts for the next attempt; shutdown flushes after the HTTP server has stopped.
6. Configuration from environment variables (`DATABASE_URL`, `REDIS_ADDR`, `ADDR`) — the twelve-factor style expanded in Unit 11.1.
7. Integration tests with a fresh database per test (skipped without `TEST_DATABASE_URL`), cache tests that prove 100 concurrent cold hits cause one backend read, and `go vet` clean.

### What changed from Chapter 8

`links` gains an optional capability, and the service exposes it:

```go
// DayCount is the number of hits on one day (YYYY-MM-DD, UTC).
type DayCount struct {
	Day  string `json:"day"`
	Hits int64  `json:"hits"`
}

// DailyCounter is an optional Store capability (Unit 3.6).
type DailyCounter interface {
	Daily(ctx context.Context, code string, days int) ([]DayCount, error)
}

var ErrUnsupported = errors.New("not supported by this store")

// Daily returns per-day hits for the last days (1-366).
func (s *Service) Daily(ctx context.Context, code string, days int) ([]DayCount, error) {
	if days < 1 || days > 366 {
		return nil, &InvalidError{"days must be between 1 and 366"}
	}
	dc, ok := s.store.(DailyCounter)
	if !ok {
		return nil, ErrUnsupported
	}
	return dc.Daily(ctx, code, days)
}
```

`httpapi` gains one route and one error mapping:

```go
	mux.HandleFunc("GET /api/links/{code}/daily", a.daily)
...
func (a *API) daily(w http.ResponseWriter, r *http.Request) {
	days := 7
	if v := r.URL.Query().Get("days"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			a.writeError(w, r, http.StatusBadRequest, "days must be a number")
			return
		}
		days = n
	}
	counts, err := a.svc.Daily(r.Context(), r.PathValue("code"), days)
	if err != nil {
		a.fail(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, counts)
}
...
	case errors.Is(err, links.ErrUnsupported):
		a.writeError(w, r, http.StatusNotImplemented, "not available")
```

### `internal/pgstore/migrations`

`001_links.sql`:

```sql
CREATE TABLE links (
    code       text        PRIMARY KEY,
    url        text        NOT NULL CHECK (length(url) <= 2048),
    created_at timestamptz NOT NULL DEFAULT now(),
    hits       bigint      NOT NULL DEFAULT 0 CHECK (hits >= 0)
);
```

`002_daily_hits.sql`:

```sql
-- One row per link per day: small, and fast to aggregate.
CREATE TABLE daily_hits (
    code text   NOT NULL REFERENCES links (code) ON DELETE CASCADE,
    day  date   NOT NULL,
    hits bigint NOT NULL CHECK (hits > 0),
    PRIMARY KEY (code, day)
);
```

### `internal/pgstore/migrate.go`

```go
package pgstore

import (
	"context"
	"embed"
	"fmt"
	"io/fs"
	"slices"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

//go:embed migrations/*.sql
var migrations embed.FS

// Migrate applies every migration not yet recorded in schema_migrations,
// in file-name order, each in its own transaction. An advisory lock makes
// it safe when several instances start at once.
func Migrate(ctx context.Context, db *pgxpool.Pool) error {
	conn, err := db.Acquire(ctx)
	if err != nil {
		return err
	}
	defer conn.Release()

	const lockID = 727274 // any constant shared by all instances
	if _, err := conn.Exec(ctx, `SELECT pg_advisory_lock($1)`, lockID); err != nil {
		return err
	}
	defer conn.Exec(context.Background(), `SELECT pg_advisory_unlock($1)`, lockID)

	if _, err := conn.Exec(ctx, `CREATE TABLE IF NOT EXISTS schema_migrations (
		name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`); err != nil {
		return err
	}
	names, err := fs.Glob(migrations, "migrations/*.sql")
	if err != nil {
		return err
	}
	slices.Sort(names)
	for _, name := range names {
		var done bool
		if err := conn.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM schema_migrations WHERE name = $1)`, name).Scan(&done); err != nil {
			return err
		}
		if done {
			continue
		}
		sql, err := migrations.ReadFile(name)
		if err != nil {
			return err
		}
		err = pgx.BeginFunc(ctx, conn, func(tx pgx.Tx) error {
			if _, err := tx.Exec(ctx, string(sql)); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `INSERT INTO schema_migrations (name) VALUES ($1)`, name)
			return err
		})
		if err != nil {
			return fmt.Errorf("migration %s: %w", name, err)
		}
	}
	return nil
}
```

The advisory lock is taken on a dedicated connection (`Acquire`), because PostgreSQL session locks belong to a connection: taking it through the pool and unlocking through a different pooled connection would not release it.

### `internal/pgstore/pgstore.go`

```go
// Package pgstore stores links in PostgreSQL.
package pgstore

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/shortener/internal/links"
)

type Store struct {
	db  *pgxpool.Pool
	now func() time.Time
}

var (
	_ links.Store        = (*Store)(nil)
	_ links.DailyCounter = (*Store)(nil)
)

func New(db *pgxpool.Pool) *Store { return &Store{db: db, now: time.Now} }

// Open connects, checks the connection, and applies migrations.
func Open(ctx context.Context, dsn string) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, err
	}
	cfg.MaxConns = 20
	cfg.MaxConnIdleTime = 5 * time.Minute
	db, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, err
	}
	if err := db.Ping(ctx); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping database: %w", err)
	}
	if err := Migrate(ctx, db); err != nil {
		db.Close()
		return nil, err
	}
	return db, nil
}

const uniqueViolation = "23505"

func (s *Store) Create(ctx context.Context, l links.Link) error {
	_, err := s.db.Exec(ctx,
		`INSERT INTO links (code, url, created_at) VALUES ($1, $2, $3)`,
		l.Code, l.URL, l.CreatedAt)
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == uniqueViolation {
		return links.ErrCodeTaken // the database enforces uniqueness, even across instances
	}
	return err
}

func (s *Store) Get(ctx context.Context, code string) (links.Link, error) {
	var l links.Link
	err := s.db.QueryRow(ctx,
		`SELECT code, url, created_at, hits FROM links WHERE code = $1`, code,
	).Scan(&l.Code, &l.URL, &l.CreatedAt, &l.Hits)
	if errors.Is(err, pgx.ErrNoRows) {
		return links.Link{}, links.ErrNotFound
	}
	return l, err
}

// Hit counts one visit and returns the URL: two writes in one transaction.
func (s *Store) Hit(ctx context.Context, code string) (string, error) {
	var url string
	err := pgx.BeginFunc(ctx, s.db, func(tx pgx.Tx) error {
		err := tx.QueryRow(ctx,
			`UPDATE links SET hits = hits + 1 WHERE code = $1 RETURNING url`, code).Scan(&url)
		if errors.Is(err, pgx.ErrNoRows) {
			return links.ErrNotFound
		}
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `
			INSERT INTO daily_hits (code, day, hits) VALUES ($1, $2, 1)
			ON CONFLICT (code, day) DO UPDATE SET hits = daily_hits.hits + 1`,
			code, s.now().UTC().Format(time.DateOnly))
		return err
	})
	return url, err
}

// AddHits applies many counted hits at once: one round trip and one
// transaction for a whole batch (used by the cache's flusher).
func (s *Store) AddHits(ctx context.Context, hits map[string]int64) error {
	if len(hits) == 0 {
		return nil
	}
	codes := make([]string, 0, len(hits))
	counts := make([]int64, 0, len(hits))
	for c, n := range hits {
		codes = append(codes, c)
		counts = append(counts, n)
	}
	day := s.now().UTC().Format(time.DateOnly)
	return pgx.BeginFunc(ctx, s.db, func(tx pgx.Tx) error {
		_, err := tx.Exec(ctx, `
			UPDATE links SET hits = links.hits + b.n
			FROM unnest($1::text[], $2::bigint[]) AS b(code, n)
			WHERE links.code = b.code`, codes, counts)
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `
			INSERT INTO daily_hits (code, day, hits)
			SELECT b.code, $3::date, b.n
			FROM unnest($1::text[], $2::bigint[]) AS b(code, n)
			WHERE EXISTS (SELECT 1 FROM links WHERE links.code = b.code)
			ON CONFLICT (code, day) DO UPDATE SET hits = daily_hits.hits + EXCLUDED.hits`,
			codes, counts, day)
		return err
	})
}

// Daily returns hits per day for the last `days` days, oldest first,
// including days with zero hits.
func (s *Store) Daily(ctx context.Context, code string, days int) ([]links.DayCount, error) {
	if _, err := s.Get(ctx, code); err != nil {
		return nil, err
	}
	today := s.now().UTC().Truncate(24 * time.Hour)
	rows, err := s.db.Query(ctx, `
		SELECT d::date, coalesce(h.hits, 0)
		FROM generate_series($2::date - ($3::int - 1), $2::date, interval '1 day') AS d
		LEFT JOIN daily_hits h ON h.code = $1 AND h.day = d::date
		ORDER BY d`, code, today, days)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, func(r pgx.CollectableRow) (links.DayCount, error) {
		var dc links.DayCount
		var day time.Time
		err := r.Scan(&day, &dc.Hits)
		dc.Day = day.Format(time.DateOnly)
		return dc, err
	})
}
```

Notes: `AddHits` sends whole arrays as two parameters and lets `unnest` turn them into rows — one round trip for any batch size, and still fully parameterised. The `WHERE EXISTS` guard stops a hit for a deleted link from violating the foreign key and failing the whole batch.

### `internal/cache/cache.go`

```go
// Package cache puts a cache-aside layer in front of a links.Store.
//
// Redirects are the hot path. Cached links skip the database read, and
// hits are counted in memory and written to the store in batches, so a
// redirect usually costs one cache lookup and no database work at all.
// The price: hit counts reach the database up to one flush interval late,
// and a crash loses at most that interval's counts.
package cache

import (
	"context"
	"errors"
	"log/slog"
	"sync"
	"time"

	"golang.org/x/sync/singleflight"

	"example.com/shortener/internal/links"
)

// KV is the small part of a key-value cache (such as Redis) that we use.
type KV interface {
	Get(ctx context.Context, key string) (value string, found bool, err error)
	Set(ctx context.Context, key, value string, ttl time.Duration) error
}

// Backend is a store that can also apply hits in batches.
type Backend interface {
	links.Store
	AddHits(ctx context.Context, hits map[string]int64) error
}

const notFound = "\x00" // cached marker for "no such code" (negative caching)

type Links struct {
	backend Backend
	kv      KV
	ttl     time.Duration
	negTTL  time.Duration
	log     *slog.Logger
	group   singleflight.Group
	mu      sync.Mutex
	pending map[string]int64 // hits not yet written to the backend
}

func New(backend Backend, kv KV, ttl time.Duration, log *slog.Logger) *Links {
	return &Links{backend: backend, kv: kv, ttl: ttl, negTTL: 30 * time.Second,
		log: log, pending: make(map[string]int64)}
}

var _ links.Store = (*Links)(nil)

func key(code string) string { return "link:" + code }

func (c *Links) Create(ctx context.Context, l links.Link) error {
	if err := c.backend.Create(ctx, l); err != nil {
		return err
	}
	// Overwrite any cached "not found" marker for this code.
	if err := c.kv.Set(ctx, key(l.Code), l.URL, c.ttl); err != nil {
		c.log.WarnContext(ctx, "cache set failed", "err", err)
	}
	return nil
}

// Get is not cached: stats should be as fresh as the database, plus the
// hits still waiting in memory.
func (c *Links) Get(ctx context.Context, code string) (links.Link, error) {
	l, err := c.backend.Get(ctx, code)
	if err != nil {
		return l, err
	}
	c.mu.Lock()
	l.Hits += c.pending[code]
	c.mu.Unlock()
	return l, nil
}

// Daily passes the optional capability through. Without this method the
// decorator would hide it (P-24's trade-off) and the endpoint would 501.
func (c *Links) Daily(ctx context.Context, code string, days int) ([]links.DayCount, error) {
	dc, ok := c.backend.(links.DailyCounter)
	if !ok {
		return nil, links.ErrUnsupported
	}
	if err := c.Flush(ctx); err != nil { // include recent hits
		return nil, err
	}
	return dc.Daily(ctx, code, days)
}

func (c *Links) Hit(ctx context.Context, code string) (string, error) {
	url, err := c.lookup(ctx, code)
	if err != nil {
		return "", err
	}
	c.mu.Lock()
	c.pending[code]++
	c.mu.Unlock()
	return url, nil
}

// lookup is cache-aside: try the cache, else load from the backend and fill
// the cache. singleflight makes concurrent misses for one code share a single
// backend call, so a popular link expiring cannot stampede the database.
func (c *Links) lookup(ctx context.Context, code string) (string, error) {
	v, found, err := c.kv.Get(ctx, key(code))
	if err != nil {
		c.log.WarnContext(ctx, "cache get failed; using database", "err", err)
	} else if found {
		if v == notFound {
			return "", links.ErrNotFound
		}
		return v, nil
	}
	res, err, _ := c.group.Do(code, func() (any, error) {
		l, err := c.backend.Get(ctx, code)
		switch {
		case errors.Is(err, links.ErrNotFound):
			c.kv.Set(ctx, key(code), notFound, c.negTTL)
			return "", err
		case err != nil:
			return "", err
		}
		if err := c.kv.Set(ctx, key(code), l.URL, c.ttl); err != nil {
			c.log.WarnContext(ctx, "cache set failed", "err", err)
		}
		return l.URL, nil
	})
	if err != nil {
		return "", err
	}
	return res.(string), nil
}

// Flush writes pending hits to the backend. On failure the hits are put
// back, so they are retried at the next flush.
func (c *Links) Flush(ctx context.Context) error {
	c.mu.Lock()
	batch := c.pending
	c.pending = make(map[string]int64)
	c.mu.Unlock()
	if len(batch) == 0 {
		return nil
	}
	if err := c.backend.AddHits(ctx, batch); err != nil {
		c.mu.Lock()
		for k, n := range batch {
			c.pending[k] += n
		}
		c.mu.Unlock()
		return err
	}
	return nil
}

// Run flushes every interval until ctx is done, then flushes once more.
func (c *Links) Run(ctx context.Context, interval time.Duration) {
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			if err := c.Flush(ctx); err != nil {
				c.log.ErrorContext(ctx, "flushing hits", "err", err)
			}
		case <-ctx.Done():
			final, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
			if err := c.Flush(final); err != nil {
				c.log.Error("final flush", "err", err)
			}
			cancel()
			return
		}
	}
}
```

The final flush uses `context.WithoutCancel(ctx)` (Unit 7.9): `ctx` is already cancelled at that point, but the last hits must still be written, within their own 5-second budget.

### `internal/cache/kv.go`

```go
package cache

import (
	"context"
	"errors"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"
)

// RedisKV adapts a go-redis client to KV.
type RedisKV struct{ C *redis.Client }

func (r RedisKV) Get(ctx context.Context, key string) (string, bool, error) {
	v, err := r.C.Get(ctx, key).Result()
	if errors.Is(err, redis.Nil) {
		return "", false, nil
	}
	if err != nil {
		return "", false, err
	}
	return v, true, nil
}

func (r RedisKV) Set(ctx context.Context, key, value string, ttl time.Duration) error {
	return r.C.Set(ctx, key, value, ttl).Err()
}

// MemoryKV is an in-process KV with expiry, for tests and single-instance use.
type MemoryKV struct {
	mu  sync.Mutex
	m   map[string]memEntry
	now func() time.Time
}

type memEntry struct {
	v   string
	exp time.Time
}

func NewMemoryKV() *MemoryKV { return &MemoryKV{m: map[string]memEntry{}, now: time.Now} }

func (k *MemoryKV) Get(_ context.Context, key string) (string, bool, error) {
	k.mu.Lock()
	defer k.mu.Unlock()
	e, ok := k.m[key]
	if !ok || k.now().After(e.exp) {
		return "", false, nil
	}
	return e.v, true, nil
}

func (k *MemoryKV) Set(_ context.Context, key, value string, ttl time.Duration) error {
	k.mu.Lock()
	defer k.mu.Unlock()
	k.m[key] = memEntry{value, k.now().Add(ttl)}
	return nil
}
```

(`MemoryKV` never deletes expired entries: fine for tests; for production single-instance use, combine it with the LRU of Unit 6.13 to bound memory.)

### `cmd/shortener/main.go`

```go
// Command shortener runs the URL shortener HTTP service.
//
// Configuration comes from the environment:
//
//	DATABASE_URL  PostgreSQL connection string (required)
//	REDIS_ADDR    Redis address, e.g. localhost:6379 (optional; in-process cache if empty)
//	ADDR          listen address (default :8080)
package main

import (
	"cmp"
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"

	"example.com/shortener/internal/cache"
	"example.com/shortener/internal/httpapi"
	"example.com/shortener/internal/links"
	"example.com/shortener/internal/pgstore"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil))
	if err := run(log); err != nil {
		log.Error("shortener stopped", "err", err)
		os.Exit(1)
	}
}

func run(log *slog.Logger) error {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		return errors.New("DATABASE_URL is required")
	}
	startCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	db, err := pgstore.Open(startCtx, dsn)
	cancel()
	if err != nil {
		return err
	}
	defer db.Close()

	var kv cache.KV = cache.NewMemoryKV()
	if addr := os.Getenv("REDIS_ADDR"); addr != "" {
		rdb := redis.NewClient(&redis.Options{Addr: addr, DialTimeout: 2 * time.Second,
			ReadTimeout: 200 * time.Millisecond, WriteTimeout: 200 * time.Millisecond})
		defer rdb.Close()
		kv = cache.RedisKV{C: rdb}
	}
	cached := cache.New(pgstore.New(db), kv, 10*time.Minute, log)
	flushCtx, stopFlush := context.WithCancel(context.Background())
	flushed := make(chan struct{})
	go func() {
		defer close(flushed)
		cached.Run(flushCtx, time.Second)
	}()
	// Runs last (defers are LIFO): after the HTTP server has stopped, stop the
	// flusher, which writes the remaining hits, and wait for it.
	defer func() {
		stopFlush()
		<-flushed
	}()

	srv := &http.Server{
		Addr:              cmp.Or(os.Getenv("ADDR"), ":8080"),
		Handler:           httpapi.New(links.NewService(cached), log),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() {
		log.Info("listening", "addr", srv.Addr)
		errCh <- srv.ListenAndServe()
	}()
	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}
	log.Info("shutting down")
	shutdownCtx, cancel2 := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel2()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		return err
	}
	log.Info("http server stopped; flushing hits")
	return nil
}
```

A note from development: the first version called `stopFlush()` only at the end of the happy path, and `go vet` reported `the stopFlush function is not used on all paths (possible context leak)` — if `ListenAndServe` failed at startup, the flusher goroutine would never be stopped. Moving the stop into a `defer` fixed it. Run `go vet` on every change; it catches exactly the bugs that are easy to miss in review.

### Tests

`internal/pgstore/pgstore_test.go` (the `newDB` helper is shown in Unit 9.8):

```go
func TestStore(t *testing.T) {
	db := newDB(t)
	s := New(db)
	s.now = func() time.Time { return time.Date(2026, 11, 15, 10, 0, 0, 0, time.UTC) }
	ctx := context.Background()

	l := links.Link{Code: "godocs", URL: "https://go.dev/doc/", CreatedAt: s.now()}
	if err := s.Create(ctx, l); err != nil {
		t.Fatal(err)
	}
	if err := s.Create(ctx, l); !errors.Is(err, links.ErrCodeTaken) {
		t.Fatalf("duplicate: %v", err)
	}
	for range 3 {
		if url, err := s.Hit(ctx, "godocs"); err != nil || url != l.URL {
			t.Fatalf("Hit = %q, %v", url, err)
		}
	}
	if _, err := s.Hit(ctx, "nope"); !errors.Is(err, links.ErrNotFound) {
		t.Fatalf("unknown: %v", err)
	}
	if err := s.AddHits(ctx, map[string]int64{"godocs": 10, "ghost": 5}); err != nil {
		t.Fatal(err)
	}
	got, err := s.Get(ctx, "godocs")
	if err != nil || got.Hits != 13 {
		t.Fatalf("Get = %+v, %v; want 13 hits", got, err)
	}
	days, err := s.Daily(ctx, "godocs", 3)
	if err != nil {
		t.Fatal(err)
	}
	want := []links.DayCount{{Day: "2026-11-13"}, {Day: "2026-11-14"}, {Day: "2026-11-15", Hits: 13}}
	if len(days) != 3 || days[0] != want[0] || days[2] != want[2] {
		t.Errorf("Daily = %+v, want %+v", days, want)
	}
}

func TestMigrateIsIdempotent(t *testing.T) {
	db := newDB(t) // already migrated once by Open
	if err := Migrate(context.Background(), db); err != nil {
		t.Fatalf("second migration run: %v", err)
	}
}
```

`internal/cache/cache_test.go`:

```go
package cache

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"example.com/shortener/internal/links"
)

// slowBackend is an in-memory backend whose Get is slow and counted.
type slowBackend struct {
	*links.Memory
	gets  atomic.Int64
	mu    sync.Mutex
	added map[string]int64
	fail  bool
}

func (b *slowBackend) Get(ctx context.Context, code string) (links.Link, error) {
	b.gets.Add(1)
	time.Sleep(20 * time.Millisecond)
	return b.Memory.Get(ctx, code)
}

func (b *slowBackend) AddHits(_ context.Context, hits map[string]int64) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.fail {
		return errors.New("database down")
	}
	for k, n := range hits {
		b.added[k] += n
	}
	return nil
}

func setup(t *testing.T) (*Links, *slowBackend) {
	t.Helper()
	b := &slowBackend{Memory: links.NewMemory(), added: map[string]int64{}}
	if err := b.Memory.Create(context.Background(), links.Link{Code: "go", URL: "https://go.dev"}); err != nil {
		t.Fatal(err)
	}
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	return New(b, NewMemoryKV(), time.Minute, log), b
}

func TestStampedeProtectionAndBatching(t *testing.T) {
	c, b := setup(t)
	ctx := context.Background()
	var wg sync.WaitGroup
	for range 100 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if url, err := c.Hit(ctx, "go"); err != nil || url != "https://go.dev" {
				t.Errorf("Hit = %q, %v", url, err)
			}
		}()
	}
	wg.Wait()
	if n := b.gets.Load(); n != 1 {
		t.Errorf("100 concurrent cold hits caused %d backend reads, want 1", n)
	}
	if err := c.Flush(ctx); err != nil {
		t.Fatal(err)
	}
	if b.added["go"] != 100 {
		t.Errorf("flushed %d hits, want 100", b.added["go"])
	}
}

func TestNegativeCaching(t *testing.T) {
	c, b := setup(t)
	for range 5 {
		if _, err := c.Hit(context.Background(), "nope"); !errors.Is(err, links.ErrNotFound) {
			t.Fatalf("err = %v", err)
		}
	}
	if n := b.gets.Load(); n != 1 {
		t.Errorf("5 misses for an unknown code caused %d backend reads, want 1", n)
	}
}

func TestFailedFlushKeepsHits(t *testing.T) {
	c, b := setup(t)
	ctx := context.Background()
	c.Hit(ctx, "go")
	c.Hit(ctx, "go")
	b.fail = true
	if err := c.Flush(ctx); err == nil {
		t.Fatal("expected flush error")
	}
	b.fail = false
	c.Hit(ctx, "go")
	if err := c.Flush(ctx); err != nil {
		t.Fatal(err)
	}
	if b.added["go"] != 3 {
		t.Errorf("hits after retry = %d, want 3", b.added["go"])
	}
}
```

Real results: `TEST_DATABASE_URL=postgres://postgres@/postgres?host=/tmp go test -race ./...` — all pass, including the integration tests against PostgreSQL 16.

### A real session with PostgreSQL and Redis

```
$ DATABASE_URL=postgres://postgres@/shortener?host=/tmp REDIS_ADDR=localhost:6379 ADDR=127.0.0.1:18081 shortener &
$ curl -s -X POST -d '{"url":"https://go.dev/doc/","code":"godocs"}' http://127.0.0.1:18081/api/links
{"code":"godocs","url":"https://go.dev/doc/","created_at":"2026-11-15T01:41:29.876921805Z","hits":0}
$ for i in $(seq 1 200); do curl -s -o /dev/null http://127.0.0.1:18081/godocs; done
$ curl -s http://127.0.0.1:18081/api/links/godocs
{"code":"godocs","url":"https://go.dev/doc/","created_at":"2026-11-15T01:41:29.876921Z","hits":200}
$ psql -tAc "select hits from links where code='godocs'"
1
$ curl -s "http://127.0.0.1:18081/api/links/godocs/daily?days=3"
[{"day":"2026-11-13","hits":0},{"day":"2026-11-14","hits":0},{"day":"2026-11-15","hits":200}]
$ redis-cli get link:godocs
https://go.dev/doc/
$ kill -INT %1
$ psql -tAc "select hits from links where code='godocs'"
200
```

Read it carefully, because it shows every design decision at work:

- The API reports **200** hits while the database row says **1**: 199 hits are still in memory, waiting for the next flush — and the stats endpoint adds them, so users see the right number (eventual consistency, hidden well).
- The `daily` call flushed first, so it shows all 200.
- The redirect target is in Redis.
- After `SIGINT`, the database has all **200**: the final flush ran after the HTTP server stopped.
- `created_at` lost its last three digits on the way through PostgreSQL (DT-250).

### Review checklist

- Run two instances against one database: are codes still unique? Are hit counts still exact? (They should be: increments are additive.)
- Stop Redis while the service runs: do redirects keep working (slower)?
- Kill the database for 10 seconds: do pending hits survive and arrive later? What do users see?
- Is every query parameterised? Is every `rows` closed? Is every call given a context?
- **Known limitations to discuss:** if an instance crashes, up to one second of hits is lost; cache entries can serve a deleted link for up to 10 minutes unless deletion invalidates the key; a single `links` row for a viral link becomes a write hotspot (batching helps; Chapter 12 discusses sharded counters).

## Answers to the Chapter 9 prediction questions

**9.1 Q2.** One row. `count(*)` counts all rows; `count(email)` counts rows where `email` is not NULL — equal here, because `email` is `NOT NULL`.

**9.2 Q2.** OFFSET must produce and discard the first 900,000 rows in order, so the index scan really walks 900,020 entries; only the last 20 are returned.
