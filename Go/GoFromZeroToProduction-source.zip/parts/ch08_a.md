# Chapter 8 — Networking, HTTP & RPC

*Goal: build production-shaped network services.*

Go was designed at Google for writing network servers, and it shows: a TCP server is twenty lines, a production-quality HTTP server is in the standard library, and the goroutine-per-connection model (Chapter 7) makes concurrent servers straightforward. This chapter goes from packets and sockets up to HTTP APIs and RPC, always with the robustness habits that separate a demo from a service: timeouts everywhere, bounded inputs, graceful shutdown, and clear error contracts.

**What you will be able to do after this chapter**

- Explain IP, ports, TCP, UDP, DNS, and TLS well enough to debug real network problems.
- Write TCP servers and clients with `net`, including deadlines and graceful shutdown.
- Explain HTTP semantics (methods, status codes, headers, connection reuse, HTTP/2).
- Build HTTP servers with Go 1.22+ routing and middleware, and HTTP clients that do not leak.
- Design REST APIs (resources, versioning, pagination, idempotency, error formats).
- Test services with `httptest`, and know when to use gRPC.

## Topic 8A — Network fundamentals

## Unit 8.1 — How networks work

**One-line summary:** Data crosses networks in packets. **IP** addresses machines and routes packets (best effort, no guarantees); **ports** address programs on a machine; **TCP** adds a reliable, ordered byte stream on top of IP; **UDP** sends independent datagrams with no guarantees; **DNS** turns names into addresses; **TLS** encrypts and authenticates a TCP connection.

**Mental model — the postal system.** IP is the postal network: it moves envelopes between addresses but may lose, delay, or reorder them. A port is the flat number in a building. TCP is a registered-mail conversation: numbered letters, receipts, and resending of anything lost, so the reader gets every page in order. UDP is a postcard: cheap and fast, no receipt. DNS is the directory that turns "go.dev" into an address. TLS is a sealed, tamper-proof envelope with an ID check of the recipient.

### The layers you work with

| Layer | Examples | What it gives you |
| --- | --- | --- |
| Application | HTTP, gRPC, DNS, your chat protocol | meaning: requests, responses, messages |
| Security | TLS | confidentiality, integrity, server (and optionally client) identity |
| Transport | TCP, UDP (QUIC is built on UDP) | process-to-process delivery; TCP: reliable ordered stream |
| Network | IPv4, IPv6 | machine-to-machine routing |
| Link | Ethernet, Wi-Fi | one hop |

### TCP essentials

- **Connection setup:** the three-way handshake (SYN, SYN-ACK, ACK) costs one round trip before any data. Over a 100 ms link that is 100 ms per new connection — which is why HTTP reuses connections (Unit 8.3).
- **A byte stream, not messages.** If the client writes "hello" and "world" in two calls, the server may read "hellowor" and "ld". Your protocol must define message boundaries (newlines in the chat server, length prefixes in binary protocols, HTTP's headers and `Content-Length`).
- **Reliability:** lost segments are retransmitted; a connection can stall for seconds before an error appears. Without timeouts, a program can wait forever on a dead peer (Unit 8.2).
- **Flow and congestion control:** TCP slows down when the receiver or the network cannot keep up — backpressure at the network level.
- **Closing:** each side closes its direction (FIN). A reader sees EOF when the other side has closed for writing. A connection reset (RST) appears as `connection reset by peer`.

### UDP

No connection, no ordering, no retransmission; each datagram arrives whole or not at all. Used where speed matters more than completeness (DNS queries, video, games, metrics) and as the base for QUIC (HTTP/3).

### DNS

A name lookup asks a resolver, which asks the DNS hierarchy and caches answers for their TTL. Practical consequences: a lookup can take tens of milliseconds or fail; one name can have many addresses (load balancing, IPv4 and IPv6); results change over time (do not cache them forever in a long-running process). Go's resolver (`net.LookupHost`, used automatically by `net.Dial`) has a pure-Go implementation and can use the system's C resolver (DT-4 territory).

### TLS in one paragraph

TLS performs a handshake in which the server proves its identity with a **certificate** signed by a certificate authority the client trusts, both sides agree on keys, and from then on everything is encrypted and integrity-protected. TLS 1.3 needs one round trip for the handshake. In Go, `crypto/tls` implements it entirely in Go (no OpenSSL), and HTTPS clients verify certificates by default. Since Go 1.24, TLS key exchange includes post-quantum hybrid algorithms by default, and Go 1.27 adds ML-DSA signatures. Never set `InsecureSkipVerify: true` outside a throwaway test.

### Deep & Tricky

**DT-241. "It works on localhost" hides latency and loss.** *(Network reality)* Localhost has ~0.05 ms round trips and no packet loss. Production paths have 1–200 ms, occasional loss, and middleboxes that drop idle connections. Code that makes 50 sequential requests per page feels instant locally and takes seconds in production. Test with realistic latency (Linux `tc netem` can add delay and loss).

### Mastery check

1. **Explain.** Why must a TCP-based protocol define message boundaries? Give two ways to do it.
2. **Explain.** What does one extra round trip cost for a user 150 ms away, and how does connection reuse help?

## Unit 8.2 — Sockets with the net package

**One-line summary:** `net.Listen` and `Accept` give a server one `net.Conn` per client; `net.Dial` gives a client a `net.Conn`. A `net.Conn` is an `io.Reader` and `io.Writer` (Chapter 5) with deadlines. The standard server pattern is one goroutine per connection, with read and write deadlines so dead clients cannot hold resources forever.

### A TCP echo server

```go
ln, err := net.Listen("tcp", ":9000")
if err != nil {
	return err
}
defer ln.Close()
for {
	conn, err := ln.Accept()
	if err != nil {
		return err
	}
	go func() {
		defer conn.Close()
		io.Copy(conn, conn) // echo everything back until the client closes
	}()
}
```

And a client:

```go
conn, err := net.DialTimeout("tcp", "localhost:9000", 3*time.Second)
if err != nil {
	return err
}
defer conn.Close()
fmt.Fprintln(conn, "hello")
reply, err := bufio.NewReader(conn).ReadString('\n')
```

Use `":0"` as the address in tests to get any free port, then read it from `ln.Addr()`.

### Deadlines

```go
conn.SetReadDeadline(time.Now().Add(5 * time.Minute))  // an absolute time, not a duration
conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
```

A blocked `Read` or `Write` returns an error once the deadline passes (`errors.Is(err, os.ErrDeadlineExceeded)`). Deadlines are absolute, so reset them before each operation that should have its own budget (an "idle timeout" resets on every read). Without deadlines, a client that disappears without closing (network cable pulled, NAT entry expired) keeps its goroutine and file descriptor forever — a slow leak that eventually exhausts the server.

### Protocol framing

The chat server in this chapter's project uses **newline-delimited text** with a `bufio.Scanner` capped at 1 KB per line (an unbounded line is an attack, DT-191). Binary protocols usually send a **length prefix** (`binary.BigEndian.Uint32`, Unit 5.5) and then exactly that many bytes (`io.ReadFull`), with a maximum length check before allocating.

### Graceful shutdown of a TCP server

`Accept` blocks; to stop the loop, close the listener from another goroutine (that makes `Accept` return an error), then wait for connection goroutines to finish:

```go
go func() {
	<-ctx.Done()
	ln.Close() // unblocks Accept
}()
for {
	conn, err := ln.Accept()
	if err != nil {
		if ctx.Err() != nil {
			wg.Wait() // let active connections finish
			return nil
		}
		return err
	}
	wg.Add(1)
	go func() { defer wg.Done(); handle(ctx, conn) }()
}
```

### Deep & Tricky

**DT-242. A write that succeeded does not mean the peer received it.** *(TCP semantics)* `Write` returns when the data is in the kernel's send buffer. If the peer crashes, the error appears on a *later* write or read. Protocols that need confirmation must have application-level acknowledgements (HTTP responses, database commits).

**DT-243. Each connection uses a file descriptor, and the limit is finite.** *(OS resource)* Linux defaults to 1024 open files per process in many shells (`ulimit -n`). A server holding 10,000 connections must raise it (systemd `LimitNOFILE`, container settings). The error is `accept: too many open files`; well-written servers back off and retry instead of spinning (`net/http` sleeps briefly after such errors).

### Mastery check

1. **Explain.** Why are deadlines absolute times, and how do you implement an idle timeout with them?
2. **Write.** A length-prefixed message protocol: `WriteMsg(w io.Writer, b []byte) error` and `ReadMsg(r io.Reader, max int) ([]byte, error)`, with tests for truncated input and oversized messages.

## Topic 8B — HTTP

## Unit 8.3 — HTTP semantics

**One-line summary:** HTTP is a request–response protocol: a method on a resource path, headers, an optional body; a status code, headers, and a body back. Methods have defined meanings (safe, idempotent), status codes have defined classes, and connections are reused (keep-alive in HTTP/1.1, multiplexing in HTTP/2).

### A request and a response

```
POST /api/links HTTP/1.1
Host: sho.rt
Content-Type: application/json
Content-Length: 46

{"url": "https://go.dev/doc/", "code": "godocs"}
```

```
HTTP/1.1 201 Created
Content-Type: application/json
Location: /api/links/godocs
X-Request-Id: J2PWT5LTNERQ

{"code":"godocs","url":"https://go.dev/doc/","created_at":"2026-11-15T01:34:13.391124175Z","hits":0}
```

(A real exchange with this chapter's project.)

### Methods

| Method | Meaning | Safe (no side effects)? | Idempotent (repeat = same effect)? |
| --- | --- | --- | --- |
| GET | read a resource | yes | yes |
| HEAD | GET without the body | yes | yes |
| POST | create / perform an action | no | **no** |
| PUT | replace a resource entirely | no | yes |
| PATCH | modify part of a resource | no | not necessarily |
| DELETE | remove a resource | no | yes |
| OPTIONS | ask what is allowed (CORS preflight) | yes | yes |

**Idempotency** matters for retries (Unit 12.7): a client that times out can safely retry a PUT or DELETE, but retrying a POST may create a duplicate order — unless the API supports idempotency keys (Unit 8.6). Never change state in a GET: crawlers, link previewers, and prefetchers will call it.

### Status codes

| Class | Meaning | Common codes |
| --- | --- | --- |
| 2xx | success | 200 OK, 201 Created, 202 Accepted, 204 No Content |
| 3xx | redirection | 301 Moved Permanently, 302 Found, 304 Not Modified, 307/308 (keep the method) |
| 4xx | **client** error — do not retry unchanged | 400 Bad Request, 401 Unauthorized (not authenticated), 403 Forbidden (not allowed), 404 Not Found, 405 Method Not Allowed, 409 Conflict, 413 Content Too Large, 422 Unprocessable Content, 429 Too Many Requests |
| 5xx | **server** error — may succeed on retry | 500 Internal Server Error, 502 Bad Gateway, 503 Service Unavailable, 504 Gateway Timeout |

The 4xx/5xx split drives client behaviour (retry or not), alerting (5xx pages the on-call engineer; 4xx usually does not), and dashboards. Get it right.

### Headers you must know

`Content-Type`, `Content-Length`, `Location` (with 201 and 3xx), `Authorization`, `Cache-Control`, `ETag` / `If-None-Match` (conditional requests → 304), `Accept`, `User-Agent`, `Retry-After` (with 429 and 503), `X-Request-ID` (correlation, a de facto standard). Header names are case-insensitive; Go canonicalises them (`x-request-id` → `X-Request-Id`).

### Connections: keep-alive, HTTP/2, HTTP/3

- **HTTP/1.1** reuses a TCP (and TLS) connection for many requests one after another ("keep-alive"), saving the handshakes. But one connection serves one request at a time; browsers open several.
- **HTTP/2** multiplexes many concurrent requests over one connection as interleaved streams, compresses headers, and is binary. Go's `net/http` uses it automatically over TLS for both servers and clients.
- **HTTP/3** runs over QUIC (UDP), avoiding TCP's head-of-line blocking. Not in Go's standard library (third-party `quic-go` exists).

### Mastery check

1. **Explain.** Why is it dangerous for a GET endpoint to delete something?
2. **Predict.** Which status for: (a) malformed JSON (b) valid JSON but `quantity: -3` (c) the user is logged in but not allowed (d) the database is down (e) creating a link whose custom code exists (f) too many requests from one client?

## Unit 8.4 — HTTP servers

**One-line summary:** A handler is anything with `ServeHTTP(http.ResponseWriter, *http.Request)`. Since Go 1.22, `http.ServeMux` routes by method and path patterns with wildcards (`GET /api/links/{code}`). Middleware is a function that wraps a handler. Every request runs in its own goroutine with a context cancelled when the client goes away.

### Handlers

```go
type Handler interface {
	ServeHTTP(w http.ResponseWriter, r *http.Request)
}

// http.HandlerFunc turns any function with the right signature into a Handler
// (a method on a function type, Unit 3.3).
http.HandleFunc("/hello", func(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	fmt.Fprintf(w, "hello, %s\n", name)
})
```

Writing to the `ResponseWriter`:

1. Set headers: `w.Header().Set("Content-Type", "application/json")`.
2. Write the status: `w.WriteHeader(201)` — optional, the first `Write` sends 200.
3. Write the body: `w.Write(...)`, `fmt.Fprintf(w, ...)`, `json.NewEncoder(w).Encode(v)`.

Headers set after the first `Write` (or `WriteHeader`) are silently ignored; a second `WriteHeader` logs `superfluous response.WriteHeader call`. Order matters.

### Routing with `ServeMux` (Go 1.22+)

```go
mux := http.NewServeMux()
mux.HandleFunc("POST /api/links", a.create)
mux.HandleFunc("GET /api/links/{code}", a.stats)       // r.PathValue("code")
mux.HandleFunc("GET /files/{path...}", serveFile)        // {name...} matches the rest of the path
mux.HandleFunc("GET /{$}", home)                         // {$}: exactly "/", not every path
mux.HandleFunc("GET /{code}", a.redirect)
```

- A method in the pattern restricts it (GET also matches HEAD). A request to a known path with the wrong method gets an automatic **405 Method Not Allowed** with an `Allow` header — the project's test checks this.
- When several patterns match, the **most specific** wins (`/api/links/{code}` beats `/{code}` for `/api/links/x`); patterns that conflict ambiguously cause a panic at registration, not a surprise at run time.
- Before Go 1.22, `ServeMux` had no methods or wildcards, which is why routers like `chi` and `gorilla/mux` became popular. For most services the standard mux is now enough.

### Middleware

Middleware wraps a handler to add behaviour before and/or after it — logging, request IDs, panic recovery, authentication, rate limiting, CORS, compression, metrics:

```go
func logRequests(log *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(rec, r)
		log.InfoContext(r.Context(), "request",
			"method", r.Method, "path", r.URL.Path, "status", rec.status,
			"duration", time.Since(start), "request_id", RequestID(r.Context()))
	})
}
```

`statusRecorder` embeds the `ResponseWriter` and overrides `WriteHeader` to remember the code (the decorator pattern, P-24). Chain middleware by nesting: `requestID(logRequests(log, recoverPanics(log, mux)))` — the outermost runs first.

### Request handling essentials

- **Body size:** `r.Body = http.MaxBytesReader(w, r.Body, 16<<10)` — reading more fails with an error (and the server closes the connection). Unbounded bodies are a denial-of-service hole (DT-191).
- **JSON input:** `json.NewDecoder(r.Body)` with `DisallowUnknownFields` for strict APIs (Unit 5.4); validate after decoding (P-30).
- **Context:** `r.Context()` is cancelled when the client disconnects or the server shuts down; pass it to every database and HTTP call the handler makes (P-33).
- **Concurrency:** handlers run concurrently. Shared state needs synchronisation (the project's store uses a `sync.RWMutex`).
- **Panics:** `net/http` recovers a panic in a handler, logs it, and closes the connection; recovery middleware lets you log it with context and return a proper 500. `panic(http.ErrAbortHandler)` deliberately aborts a response.
- **Errors:** map domain errors to status codes in **one** place (the project's `fail` function); never send internal error text to clients (it leaks implementation details and sometimes secrets).

### Deep & Tricky

**DT-244. `http.ListenAndServe` with no timeouts is vulnerable to slow clients.** *(Library defaults)* The zero `http.Server` has no read or write timeouts; a client can open connections and send headers one byte per minute ("Slowloris"), holding goroutines and descriptors indefinitely. Always construct an `http.Server` with at least `ReadHeaderTimeout`, and usually `ReadTimeout`, `WriteTimeout`, and `IdleTimeout` (the project's `main` shows a reasonable set). `go vet` does not catch this; reviewers must.

**DT-245. `WriteTimeout` covers the whole handler.** *(Library behaviour)* It is measured from the end of reading the request headers until the response is written, so a slow handler (or a long streaming response) gets cut off silently: the client sees a closed connection, the handler keeps running. For per-handler budgets, use `http.TimeoutHandler` or `http.NewResponseController(w).SetWriteDeadline` (Go 1.20) and context deadlines.

### Pattern

**P-34. One error-to-status mapping per service.** *(API practice)* Handlers return or pass domain errors to a single function that maps sentinel and typed errors to HTTP status codes and a uniform JSON error body, logs unexpected errors with the request ID, and returns a generic message for 500s. *Trade-off:* a little indirection; in exchange, consistent APIs and no leaked internals.

### Mastery check

1. **Explain.** In which order do `requestID(logRequests(log, recoverPanics(log, mux)))` run, and why must `requestID` be outermost?
2. **Predict.** A handler calls `w.Write([]byte("ok"))` and then `w.WriteHeader(500)`. What status does the client get?
3. **Write.** Middleware `requireJSON` that rejects POST requests without `Content-Type: application/json` with 415, and a test using `httptest.NewRecorder`.

## Unit 8.5 — HTTP clients

**One-line summary:** Use an `http.Client` with a **timeout**, create requests with a context, **always close response bodies**, check status codes yourself, and reuse one client so connections are pooled. The default client has no timeout.

### The correct shape

```go
var client = &http.Client{Timeout: 10 * time.Second} // one per program (or per downstream), reused

func getUser(ctx context.Context, id string) (User, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, baseURL+"/users/"+url.PathEscape(id), nil)
	if err != nil {
		return User{}, err
	}
	req.Header.Set("Accept", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		return User{}, fmt.Errorf("get user %s: %w", id, err) // network error, timeout, cancellation
	}
	defer resp.Body.Close()                                      // ALWAYS, even on error statuses
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return User{}, fmt.Errorf("get user %s: %s: %s", id, resp.Status, b)
	}
	var u User
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&u); err != nil {
		return User{}, fmt.Errorf("decode user %s: %w", id, err)
	}
	return u, nil
}
```

The checklist this code satisfies:

- **Timeout.** `http.DefaultClient` and `http.Get` have **no** timeout; a hung server hangs your goroutine forever. Set `Client.Timeout` and pass a context with the caller's deadline.
- **Close the body.** An unclosed body leaks the connection (it cannot be reused or released). `defer resp.Body.Close()` right after the error check (P-13).
- **Status codes are not errors.** `client.Do` returns `err == nil` for a 404 or 500; check `resp.StatusCode`.
- **Bounded reads.** A misbehaving server can send gigabytes (DT-191).
- **Escaping.** `url.PathEscape` and `url.Values{...}.Encode()` for query strings; never concatenate raw user input into URLs.

### Connection reuse

`http.Client` uses an `http.Transport` that keeps idle connections per host and reuses them. Two conditions for reuse: the body was read to the end and closed. (Go 1.27's HTTP/1 transport drains unread content on `Close` automatically up to a limit, which fixes many accidental non-reuse cases; older code drains with `io.Copy(io.Discard, resp.Body)`.) Tune `Transport.MaxIdleConnsPerHost` (default 2!) for services that call one backend heavily — otherwise most requests open new connections, each paying TCP and TLS handshakes.

### Deep & Tricky

**DT-246. Creating a new `http.Client` (or `Transport`) per request defeats pooling.** *(Library behaviour)* Each new `Transport` has its own empty pool, so every request does a full TCP+TLS handshake, and old idle connections accumulate until the Transport is garbage-collected. Create clients once and share them; they are safe for concurrent use.

**DT-247. `Client.Timeout` includes reading the body.** *(Library behaviour)* The timeout covers the whole exchange, including your `io.ReadAll` of a large body. A large download that legitimately takes minutes needs a longer timeout, or a context deadline per phase, or streaming with progress-based deadlines.

### Mastery check

1. **Explain.** List the five mistakes the `getUser` example avoids.
2. **Write.** A client for the shortener API (`Shorten`, `Stats`) with typed errors (`ErrNotFound`, `ErrConflict`) mapped from status codes, tested against the real handler via `httptest.NewServer`.

## Topic 8C — API design and robustness

## Unit 8.6 — REST API design

**One-line summary:** A good HTTP API models **resources** with nouns and uses methods for actions, returns accurate status codes, has a consistent error format, paginates collections, versions breaking changes, and makes non-idempotent operations safe to retry with idempotency keys.

### Resources and URLs

```
GET    /api/v1/links              list (paginated)
POST   /api/v1/links              create
GET    /api/v1/links/{code}       read one
PATCH  /api/v1/links/{code}       change some fields
DELETE /api/v1/links/{code}       delete
GET    /api/v1/links/{code}/hits  a sub-resource
```

Plural nouns, lower case, hyphens for multiple words, no verbs in paths (`POST /links`, not `/createLink`). Actions that are not CRUD can be modelled as sub-resources (`POST /orders/{id}/cancellation`).

### Consistent errors

Pick one format and use it for every error. The project uses `{"error": "...", "request_id": "..."}`. A standard alternative is RFC 9457 *Problem Details* (`application/problem+json` with `type`, `title`, `status`, `detail`). Include a request ID so support can find the logs; include field-level detail for validation errors; never include stack traces or SQL.

### Pagination

Never return an unbounded collection. Two styles:

- **Offset:** `?limit=50&offset=100`. Simple, allows jumping to page N, but slow for deep pages (the database still scans the skipped rows) and inconsistent when rows are inserted while paging.
- **Cursor (keyset):** `?limit=50&after=<opaque cursor>`, where the cursor encodes the last item's sort key (`created_at`, `id`). Fast at any depth and stable under inserts. Return `next_cursor` in the response. Preferred for large or changing collections (Unit 9.2 explains why it is fast).

Always enforce a maximum `limit`.

### Versioning and compatibility

Adding a field to a response or an optional field to a request is **compatible** (clients must ignore unknown fields — and your JSON decoding should be strict only where you control the clients). Removing or renaming fields, changing types or meanings, or tightening validation are **breaking**. Breaking changes need a new version (`/api/v2/...` or a header), a migration period, and communication. The JSON field names are your API (P-30).

### Idempotency keys

A mobile app sends `POST /payments`, the connection drops before the response, and the app retries. Did the payment happen once or twice? With an `Idempotency-Key: <uuid>` header, the server stores the key with the result of the first request; a retry with the same key returns the stored result instead of acting again. Unit 12.7 builds this; Stripe's API is the well-known example.

### Mastery check

1. **Explain.** Why is cursor pagination stable when new rows are inserted, and offset pagination is not?
2. **Explain.** Which of these are breaking: adding `expires_at` to responses; making `code` required; changing `hits` from a number to a string; adding a new optional query parameter?
3. **Write.** Design (on paper) the endpoints, request and response bodies, status codes, and errors for a "team todo list" API with users, lists, and items, including pagination and one idempotent operation.

## Unit 8.7 — Robust services

**One-line summary:** A robust service bounds everything (time, body size, concurrency), shuts down gracefully, propagates request contexts, and is tested end to end with `httptest` — including failure paths.

### Timeouts everywhere

| Where | How |
| --- | --- |
| Incoming connections | `http.Server` `ReadHeaderTimeout`, `ReadTimeout`, `WriteTimeout`, `IdleTimeout` (DT-244) |
| Each request's work | the request context, plus `context.WithTimeout` for budgets inside the handler |
| Outgoing HTTP | `Client.Timeout` and per-request contexts (Unit 8.5) |
| Database calls | context on every query (Unit 9.3) |
| Shutdown | a deadline for `Server.Shutdown` |

A request that waits forever on any dependency ties up a goroutine, a connection, and memory; under load those accumulate until the service falls over. Timeouts turn slow failures into fast, visible errors.

### Graceful shutdown

When Kubernetes (Unit 11.8) or a deploy script stops your service, it sends SIGTERM and waits a grace period before SIGKILL. In that window: stop accepting new connections, let in-flight requests finish, close idle connections, flush logs and metrics, close the database pool. `http.Server.Shutdown(ctx)` does the HTTP part:

```go
ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
defer stop()

errCh := make(chan error, 1)
go func() { errCh <- srv.ListenAndServe() }()

select {
case err := <-errCh:
	return err // could not start (port in use, ...)
case <-ctx.Done():
}
shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
defer cancel()
if err := srv.Shutdown(shutdownCtx); err != nil { // stop accepting; wait for in-flight requests
	return err
}
if err := <-errCh; !errors.Is(err, http.ErrServerClosed) {
	return err
}
```

Note the fresh `context.Background()` for the shutdown deadline: the signal context is already cancelled. `ListenAndServe` returns `http.ErrServerClosed` after `Shutdown` — that is the normal case, not an error. Long-lived connections (WebSockets, streaming) are not tracked by `Shutdown`; register `srv.RegisterOnShutdown` callbacks to tell them to finish.

### Testing with `httptest`

Two tools:

- `httptest.NewRecorder()` — a fake `ResponseWriter` for calling one handler directly: fast unit tests of handlers and middleware.
- `httptest.NewServer(handler)` — a real HTTP server on a random local port: end-to-end tests through the real client stack, middleware, routing, and JSON. The project's tests use it.

```go
rec := httptest.NewRecorder()
req := httptest.NewRequest(http.MethodGet, "/api/links/nope", nil)
handler.ServeHTTP(rec, req)
if rec.Code != http.StatusNotFound { ... }
```

Test failure paths as thoroughly as success: invalid JSON, unknown fields, too-large bodies, wrong methods, conflicts, timeouts of dependencies (with stubbed stores that block until the context is cancelled). Go 1.27's `httptest.NewTestServer` runs on an in-memory network that works with `testing/synctest` for time-dependent tests (Unit 7.12).

### Deep & Tricky

**DT-248. Shutdown and readiness must be coordinated with the load balancer.** *(Operations)* If the service stops accepting connections the instant it receives SIGTERM, but the load balancer still sends it traffic for a few seconds (its health check has not noticed yet), users get errors. Production services first fail their readiness check, wait a few seconds, then call `Shutdown` (Unit 11.8).

### Mastery check

1. **Explain.** Why does the shutdown code use `context.Background()` rather than the signal context for the shutdown deadline?
2. **Write.** A test proving that a handler whose store blocks until the context is cancelled returns promptly when the client gives up (use a client with a 50 ms timeout and a stub store).

## Topic 8D — RPC

## Unit 8.8 — Protocol Buffers and gRPC

**One-line summary:** gRPC is an RPC framework: you define services and messages in a `.proto` file, generate Go code, and call remote methods like local functions over HTTP/2, with binary Protocol Buffers encoding, deadlines, streaming, and interceptors. It shines for internal service-to-service communication; REST/JSON remains better for public and browser-facing APIs.

### Defining a service

```proto
syntax = "proto3";
package shortener.v1;
option go_package = "example.com/shortener/gen/shortenerv1";

service Shortener {
  rpc Shorten(ShortenRequest) returns (Link);
  rpc GetStats(GetStatsRequest) returns (Link);
  rpc WatchHits(WatchHitsRequest) returns (stream HitEvent); // server streaming
}

message ShortenRequest {
  string url = 1;   // field numbers identify fields on the wire: never reuse or change them
  string code = 2;
}

message Link {
  string code = 1;
  string url = 2;
  int64 hits = 3;
  google.protobuf.Timestamp created_at = 4;
}
```

`protoc` (or `buf`) with the `protoc-gen-go` and `protoc-gen-go-grpc` plugins generates message structs and client/server interfaces.

### Server and client (requires `google.golang.org/grpc`; shown, not compiled for this book)

```go
type server struct {
	shortenerv1.UnimplementedShortenerServer // forward compatibility: new methods return Unimplemented
	svc *links.Service
}

func (s *server) Shorten(ctx context.Context, req *shortenerv1.ShortenRequest) (*shortenerv1.Link, error) {
	l, err := s.svc.Shorten(ctx, req.GetUrl(), req.GetCode())
	switch {
	case errors.Is(err, links.ErrCodeTaken):
		return nil, status.Error(codes.AlreadyExists, "code already in use")
	case err != nil:
		return nil, toStatus(err) // map domain errors to gRPC codes, like P-34
	}
	return &shortenerv1.Link{Code: l.Code, Url: l.URL, Hits: l.Hits}, nil
}

// client
conn, err := grpc.NewClient("shortener:9090", grpc.WithTransportCredentials(creds))
c := shortenerv1.NewShortenerClient(conn)
ctx, cancel := context.WithTimeout(ctx, 2*time.Second) // the deadline travels to the server
defer cancel()
link, err := c.Shorten(ctx, &shortenerv1.ShortenRequest{Url: "https://go.dev"})
```

### What gRPC gives you

- **Deadlines propagate:** the client's context deadline is sent to the server, whose handler context expires at the same moment, and onward to calls it makes. End-to-end timeouts for free (P-33).
- **Streaming:** client streaming, server streaming, and bidirectional streams over one HTTP/2 connection.
- **Interceptors:** gRPC's middleware (unary and stream), for logging, auth, metrics, retries.
- **Status codes:** `codes.NotFound`, `InvalidArgument`, `AlreadyExists`, `DeadlineExceeded`, `Unavailable` (retryable), and so on — analogous to HTTP status classes.
- **Schema evolution:** add fields with new numbers; never reuse numbers; old clients ignore new fields.

### When to choose what

| | REST + JSON | gRPC |
| --- | --- | --- |
| Clients | browsers, third parties, curl | your own services |
| Schema | OpenAPI (optional) | `.proto` (required, generated code) |
| Encoding | text, human-readable | binary, compact, fast |
| Streaming | limited (SSE, WebSockets) | built in |
| Tooling to debug | universal | needs `grpcurl` and similar |

### Deep & Tricky

**DT-249. Protobuf zero values are indistinguishable from "unset" for scalars in proto3.** *(Encoding rule)* `hits = 0` and "hits not sent" decode identically unless the field is declared `optional` (which generates a pointer field and `Has` methods). Same problem as JSON's `omitempty` (DT-156) — design messages so zero is a valid default or use `optional`.

### Mastery check

1. **Explain.** How does a gRPC deadline propagate across three services, and why is that valuable?
2. **Explain.** Why must a protobuf field number never be reused?

## Chapter 8 Projects — A TCP chat server, then a URL-shortener API

This chapter has two projects: a TCP chat server (sockets, protocol framing, deadlines, goroutine ownership, graceful shutdown) and the first version of the **URL shortener** service, which Chapters 9 and 11 extend into a database-backed, production-ready system.

### Project A — `chat`, a TCP chat server

**Specification**

- Listen on `-addr` (default `localhost:9000`); clients connect with `nc localhost 9000`.
- The first line a client sends is its name. Every later line is broadcast to all other clients as `name: text`. `/who` lists users; `/quit` leaves. Joins and leaves are announced.
- Lines are capped at 1 KB; a client idle for 5 minutes is disconnected.
- A slow client (whose outgoing queue of 32 messages is full) is disconnected instead of slowing everyone else down.
- Ctrl+C shuts down gracefully: stop accepting, close all clients, return.

**Design: one owner per piece of state.** The **hub** goroutine owns the set of clients (no mutex: confinement, P-32), and is the *only* goroutine that sends on or closes a client's outgoing channel ("only the sender closes", Unit 7.3). Each connection has a **reader** (the connection's goroutine) and a **writer** goroutine (the only one that writes to the socket). A note from development: the first version of this design let the reader goroutine send the welcome message and `/who` reply directly on the client's channel. The tests passed — but during shutdown the hub could close that channel at the same moment, which panics with `send on closed channel`. Moving *all* sends to the hub fixed it. Rare interleavings are exactly what tests miss and ownership rules prevent.

```go
// Command chat is a line-based TCP chat server. Connect with
// "nc localhost 9000"; the first line you send is your name.
// Commands: /who lists users, /quit leaves.
package main

import (
	"bufio"
	"context"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"slices"
	"strings"
	"sync"
	"time"
)

const (
	idleTimeout = 5 * time.Minute
	maxLine     = 1024
	outBuffer   = 32 // messages queued per client before it is considered too slow
)

type client struct {
	name string
	out  chan string // the hub sends; the client's writer goroutine receives
}

type message struct {
	from *client
	text string
}

// Hub owns the set of clients. Only the hub's goroutine touches the map,
// and only the hub sends on or closes a client's out channel: state
// confinement (P-32) and "only the sender closes" (Unit 7.3).
type Hub struct {
	join  chan *client
	leave chan *client
	msgs  chan message
	who   chan *client
}

func NewHub() *Hub {
	return &Hub{
		join:  make(chan *client),
		leave: make(chan *client),
		msgs:  make(chan message),
		who:   make(chan *client),
	}
}

func (h *Hub) Run(ctx context.Context) {
	clients := map[*client]bool{}
	send := func(c *client, text string) {
		select {
		case c.out <- text:
		default: // slow client: drop it rather than block everyone (backpressure)
			delete(clients, c)
			close(c.out)
		}
	}
	broadcast := func(text string, except *client) {
		for c := range clients {
			if c != except {
				send(c, text)
			}
		}
	}
	for {
		select {
		case c := <-h.join:
			clients[c] = true
			send(c, "welcome, "+c.name+" (/who, /quit)")
			broadcast(c.name+" joined", c)
		case c := <-h.leave:
			if clients[c] {
				delete(clients, c)
				close(c.out)
				broadcast(c.name+" left", nil)
			}
		case m := <-h.msgs:
			broadcast(m.from.name+": "+m.text, m.from)
		case c := <-h.who:
			if !clients[c] {
				continue
			}
			var names []string
			for other := range clients {
				names = append(names, other.name)
			}
			slices.Sort(names)
			send(c, "online: "+strings.Join(names, ", "))
		case <-ctx.Done():
			for c := range clients {
				close(c.out)
			}
			return
		}
	}
}

// Serve accepts connections until ctx is done, then waits for them to end.
func Serve(ctx context.Context, ln net.Listener, h *Hub, log *slog.Logger) error {
	var wg sync.WaitGroup
	go func() {
		<-ctx.Done()
		ln.Close() // unblocks Accept
	}()
	for {
		conn, err := ln.Accept()
		if err != nil {
			if ctx.Err() != nil {
				wg.Wait()
				return nil
			}
			return err
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			handle(ctx, conn, h, log)
		}()
	}
}

func handle(ctx context.Context, conn net.Conn, h *Hub, log *slog.Logger) {
	defer conn.Close()
	log.Info("connected", "remote", conn.RemoteAddr())
	sc := bufio.NewScanner(conn)
	sc.Buffer(make([]byte, 0, maxLine), maxLine)

	readLine := func() (string, bool) {
		conn.SetReadDeadline(time.Now().Add(idleTimeout))
		if !sc.Scan() {
			return "", false
		}
		return strings.TrimSpace(sc.Text()), true
	}

	fmt.Fprint(conn, "name: ")
	name, ok := readLine()
	if !ok || name == "" {
		return
	}
	c := &client{name: name, out: make(chan string, outBuffer)}

	select {
	case h.join <- c: // from now on the hub owns c.out and will close it
	case <-ctx.Done():
		return
	}

	// Writer goroutine: the only goroutine that writes to conn from now on.
	// It ends when the hub closes c.out (after /quit, on shutdown, or
	// because this client was too slow).
	writerDone := make(chan struct{})
	go func() {
		defer close(writerDone)
		for line := range c.out {
			conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if _, err := fmt.Fprintln(conn, line); err != nil {
				break
			}
		}
		conn.Close() // also unblocks the reader below
		for range c.out {
			// drain until the hub closes the channel, so the hub never blocks
		}
	}()

	for {
		line, ok := readLine()
		if !ok || line == "/quit" {
			break
		}
		switch {
		case line == "":
		case line == "/who":
			select {
			case h.who <- c:
			case <-ctx.Done():
			}
		default:
			select {
			case h.msgs <- message{c, line}:
			case <-ctx.Done():
			}
		}
		if ctx.Err() != nil {
			break
		}
	}
	select {
	case h.leave <- c:
	case <-ctx.Done():
	}
	<-writerDone
	if err := sc.Err(); err != nil && !errors.Is(err, net.ErrClosed) {
		log.Info("read error", "name", name, "err", err)
	}
	log.Info("disconnected", "name", name)
}

func main() {
	addr := flag.String("addr", "localhost:9000", "listen address")
	flag.Parse()
	log := slog.New(slog.NewTextHandler(os.Stderr, nil))

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Error("listen", "err", err)
		os.Exit(1)
	}
	log.Info("listening", "addr", ln.Addr())
	h := NewHub()
	go h.Run(ctx)
	if err := Serve(ctx, ln, h, log); err != nil {
		log.Error("serve", "err", err)
		os.Exit(1)
	}
}
```

**Test (`chat_test.go`)** — real TCP connections on a random port, then a graceful-shutdown check:

```go
package main

import (
	"bufio"
	"context"
	"io"
	"log/slog"
	"net"
	"strings"
	"testing"
	"time"
)

type testClient struct {
	conn net.Conn
	r    *bufio.Reader
}

func dial(t *testing.T, addr, name string) *testClient {
	t.Helper()
	conn, err := net.Dial("tcp", addr)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { conn.Close() })
	c := &testClient{conn: conn, r: bufio.NewReader(conn)}
	c.expect(t, "name: ")
	c.send(t, name)
	c.expectLine(t, "welcome, "+name)
	return c
}

func (c *testClient) send(t *testing.T, s string) {
	t.Helper()
	if _, err := io.WriteString(c.conn, s+"\n"); err != nil {
		t.Fatal(err)
	}
}

func (c *testClient) expect(t *testing.T, prefix string) {
	t.Helper()
	c.conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	buf := make([]byte, len(prefix))
	if _, err := io.ReadFull(c.r, buf); err != nil || string(buf) != prefix {
		t.Fatalf("got %q, %v; want %q", buf, err, prefix)
	}
}

func (c *testClient) expectLine(t *testing.T, prefix string) {
	t.Helper()
	c.conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	line, err := c.r.ReadString('\n')
	if err != nil || !strings.HasPrefix(line, prefix) {
		t.Fatalf("got %q, %v; want prefix %q", line, err, prefix)
	}
}

func start(t *testing.T) (string, context.CancelFunc, chan error) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0") // port 0: any free port
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	h := NewHub()
	go h.Run(ctx)
	done := make(chan error, 1)
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	go func() { done <- Serve(ctx, ln, h, log) }()
	return ln.Addr().String(), cancel, done
}

func TestChat(t *testing.T) {
	addr, cancel, done := start(t)
	defer cancel()

	asha := dial(t, addr, "asha")
	ravi := dial(t, addr, "ravi")
	asha.expectLine(t, "ravi joined")

	asha.send(t, "namaste")
	ravi.expectLine(t, "asha: namaste")

	ravi.send(t, "/who")
	ravi.expectLine(t, "online: asha, ravi")

	ravi.send(t, "/quit")
	asha.expectLine(t, "ravi left")

	cancel() // graceful shutdown: Serve must return
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Serve did not stop after cancel")
	}
}
```

It passes `go test -race -count=20`.

### Project B — `shortener`, a URL-shortener REST API

**Specification**

```
POST /api/links          {"url": "...", "code": "optional"}  -> 201 + link, Location header
GET  /api/links/{code}   -> 200 + link with hit count
GET  /{code}             -> 302 redirect to the target URL (counts a hit)
GET  /healthz            -> 200 "ok"
```

- URLs must be `http`/`https` with a host, at most 2048 bytes. Custom codes: 3–32 letters, digits, `-`, `_`. Generated codes: 7 characters from an alphabet without look-alike characters, from `crypto/rand` (guessable codes would let anyone enumerate links), with retry on collision.
- Errors: 400 invalid input, 404 unknown code, 409 code taken, 405 wrong method, 500 internal (generic message, details logged). Every error body is `{"error": ..., "request_id": ...}`.
- Request bodies limited to 16 KB; unknown JSON fields rejected.
- Middleware: request ID (accepting a client-supplied `X-Request-ID`), structured access logs, panic recovery.
- Server timeouts and graceful shutdown on SIGINT/SIGTERM.
- Storage behind a `links.Store` interface with an in-memory implementation (Chapter 9 adds PostgreSQL).

**Layout**

```
shortener/
├── cmd/shortener/main.go        wiring, server, shutdown
└── internal/
    ├── links/                   domain: Link, Store, Service, errors
    │   ├── links.go
    │   ├── memory.go
    │   └── links_test.go
    └── httpapi/                 HTTP: routes, handlers, middleware, error mapping
        ├── httpapi.go
        └── httpapi_test.go
```

**`internal/links/links.go`**

```go
// Package links holds the URL shortener's rules: validating URLs,
// generating short codes, and resolving them. Storage is behind Store.
package links

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"time"
)

type Link struct {
	Code      string    `json:"code"`
	URL       string    `json:"url"`
	CreatedAt time.Time `json:"created_at"`
	Hits      int64     `json:"hits"`
}

var (
	ErrNotFound  = errors.New("link not found")
	ErrCodeTaken = errors.New("code already in use")
)

// InvalidError reports bad input; the HTTP layer maps it to 400.
type InvalidError struct{ Reason string }

func (e *InvalidError) Error() string { return "invalid input: " + e.Reason }

// Store is what the service needs from storage.
type Store interface {
	// Create saves l, or returns ErrCodeTaken if l.Code exists.
	Create(ctx context.Context, l Link) error
	// Get returns the link, or ErrNotFound.
	Get(ctx context.Context, code string) (Link, error)
	// Hit increments the hit counter and returns the target URL, or ErrNotFound.
	Hit(ctx context.Context, code string) (string, error)
}

type Service struct {
	store Store
	now   func() time.Time
}

func NewService(s Store) *Service { return &Service{store: s, now: time.Now} }

var codeRE = regexp.MustCompile(`^[A-Za-z0-9_-]{3,32}$`)

const (
	alphabet  = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O, 1/l/I
	genLength = 7
	maxURLLen = 2048
)

// Shorten stores rawURL under code, or under a generated code if code is "".
func (s *Service) Shorten(ctx context.Context, rawURL, code string) (Link, error) {
	if err := validateURL(rawURL); err != nil {
		return Link{}, err
	}
	if code != "" {
		if !codeRE.MatchString(code) {
			return Link{}, &InvalidError{"code must be 3-32 letters, digits, '-' or '_'"}
		}
		l := Link{Code: code, URL: rawURL, CreatedAt: s.now().UTC()}
		return l, s.store.Create(ctx, l)
	}
	// Random codes can collide; with 56^7 ≈ 1.7e12 codes it is rare, but retry.
	for range 5 {
		l := Link{Code: randomCode(), URL: rawURL, CreatedAt: s.now().UTC()}
		err := s.store.Create(ctx, l)
		if errors.Is(err, ErrCodeTaken) {
			continue
		}
		return l, err
	}
	return Link{}, fmt.Errorf("could not find a free code: %w", ErrCodeTaken)
}

// Resolve returns the target URL for code and counts the hit.
func (s *Service) Resolve(ctx context.Context, code string) (string, error) {
	return s.store.Hit(ctx, code)
}

// Stats returns the link with its hit count.
func (s *Service) Stats(ctx context.Context, code string) (Link, error) {
	return s.store.Get(ctx, code)
}

func validateURL(raw string) error {
	if len(raw) > maxURLLen {
		return &InvalidError{fmt.Sprintf("url longer than %d bytes", maxURLLen)}
	}
	u, err := url.Parse(raw)
	if err != nil {
		return &InvalidError{"url does not parse"}
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return &InvalidError{"url must start with http:// or https://"}
	}
	if u.Host == "" {
		return &InvalidError{"url has no host"}
	}
	return nil
}

func randomCode() string {
	b := make([]byte, genLength)
	rand.Read(b) // crypto/rand: codes must not be guessable (P-15)
	for i := range b {
		b[i] = alphabet[int(b[i])%len(alphabet)] // tiny modulo bias (DT-96) is acceptable here
	}
	return string(b)
}
```

**`internal/links/memory.go`**

```go
package links

import (
	"context"
	"sync"
)

// Memory is an in-memory Store, safe for concurrent use.
type Memory struct {
	mu    sync.RWMutex
	links map[string]Link
}

var _ Store = (*Memory)(nil)

func NewMemory() *Memory { return &Memory{links: make(map[string]Link)} }

func (m *Memory) Create(_ context.Context, l Link) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.links[l.Code]; ok {
		return ErrCodeTaken
	}
	m.links[l.Code] = l
	return nil
}

func (m *Memory) Get(_ context.Context, code string) (Link, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	l, ok := m.links[code]
	if !ok {
		return Link{}, ErrNotFound
	}
	return l, nil
}

func (m *Memory) Hit(_ context.Context, code string) (string, error) {
	m.mu.Lock() // a write: the hit counter changes
	defer m.mu.Unlock()
	l, ok := m.links[code]
	if !ok {
		return "", ErrNotFound
	}
	l.Hits++
	m.links[code] = l
	return l.URL, nil
}
```

**`internal/httpapi/httpapi.go`**

```go
// Package httpapi exposes the shortener over HTTP.
//
//	POST /api/links          {"url": "...", "code": "optional"} -> 201 + link
//	GET  /api/links/{code}   -> 200 + link with hit count
//	GET  /{code}             -> 302 redirect to the target URL
//	GET  /healthz            -> 200 "ok"
package httpapi

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"time"

	"example.com/shortener/internal/links"
)

const maxBodyBytes = 16 << 10

type API struct {
	svc *links.Service
	log *slog.Logger
}

// New returns the complete handler, with middleware applied.
func New(svc *links.Service, log *slog.Logger) http.Handler {
	a := &API{svc: svc, log: log}
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/links", a.create)
	mux.HandleFunc("GET /api/links/{code}", a.stats)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("GET /{code}", a.redirect)
	// Middleware is applied outside-in: requestID runs first.
	return requestID(logRequests(log, recoverPanics(log, mux)))
}

type createRequest struct {
	URL  string `json:"url"`
	Code string `json:"code"`
}

func (a *API) create(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	var req createRequest
	if err := dec.Decode(&req); err != nil {
		a.writeError(w, r, http.StatusBadRequest, "body must be JSON like {\"url\": \"https://...\"}: "+err.Error())
		return
	}
	l, err := a.svc.Shorten(r.Context(), req.URL, req.Code)
	if err != nil {
		a.fail(w, r, err)
		return
	}
	w.Header().Set("Location", "/api/links/"+l.Code)
	writeJSON(w, http.StatusCreated, l)
}

func (a *API) stats(w http.ResponseWriter, r *http.Request) {
	l, err := a.svc.Stats(r.Context(), r.PathValue("code"))
	if err != nil {
		a.fail(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, l)
}

func (a *API) redirect(w http.ResponseWriter, r *http.Request) {
	target, err := a.svc.Resolve(r.Context(), r.PathValue("code"))
	if err != nil {
		a.fail(w, r, err)
		return
	}
	http.Redirect(w, r, target, http.StatusFound)
}

// fail maps domain errors to HTTP status codes in one place.
func (a *API) fail(w http.ResponseWriter, r *http.Request, err error) {
	var inv *links.InvalidError
	switch {
	case errors.As(err, &inv):
		a.writeError(w, r, http.StatusBadRequest, inv.Reason)
	case errors.Is(err, links.ErrNotFound):
		a.writeError(w, r, http.StatusNotFound, "no such link")
	case errors.Is(err, links.ErrCodeTaken):
		a.writeError(w, r, http.StatusConflict, "code already in use")
	case errors.Is(err, context.Canceled):
		// the client went away; nobody will read a response
	default:
		a.log.ErrorContext(r.Context(), "internal error", "err", err, "request_id", RequestID(r.Context()))
		a.writeError(w, r, http.StatusInternalServerError, "internal error") // never leak details
	}
}

type errorBody struct {
	Error     string `json:"error"`
	RequestID string `json:"request_id"`
}

func (a *API) writeError(w http.ResponseWriter, r *http.Request, status int, msg string) {
	writeJSON(w, status, errorBody{Error: msg, RequestID: RequestID(r.Context())})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// ---- middleware ----

type ctxKey struct{}

// RequestID returns the request's ID, or "" outside a request.
func RequestID(ctx context.Context) string {
	id, _ := ctx.Value(ctxKey{}).(string)
	return id
}

func requestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get("X-Request-ID")
		if id == "" || len(id) > 64 {
			id = rand.Text()[:12]
		}
		w.Header().Set("X-Request-ID", id)
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), ctxKey{}, id)))
	})
}

// statusRecorder remembers the status code a handler wrote.
type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (s *statusRecorder) WriteHeader(code int) {
	s.status = code
	s.ResponseWriter.WriteHeader(code)
}

func (s *statusRecorder) Unwrap() http.ResponseWriter { return s.ResponseWriter } // for http.ResponseController

func logRequests(log *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(rec, r)
		log.InfoContext(r.Context(), "request",
			"method", r.Method, "path", r.URL.Path, "status", rec.status,
			"duration", time.Since(start), "request_id", RequestID(r.Context()))
	})
}

func recoverPanics(log *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if v := recover(); v != nil {
				if v == http.ErrAbortHandler { // deliberate abort: let net/http handle it
					panic(v)
				}
				log.ErrorContext(r.Context(), "panic", "value", fmt.Sprint(v), "request_id", RequestID(r.Context()))
				http.Error(w, "internal error", http.StatusInternalServerError)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
```

**`cmd/shortener/main.go`**

```go
// Command shortener runs the URL shortener HTTP service.
package main

import (
	"context"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"example.com/shortener/internal/httpapi"
	"example.com/shortener/internal/links"
)

func main() {
	if err := run(); err != nil {
		slog.Error("shortener stopped", "err", err)
		os.Exit(1)
	}
}

func run() error {
	addr := flag.String("addr", ":8080", "listen address")
	flag.Parse()
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil))

	srv := &http.Server{
		Addr:              *addr,
		Handler:           httpapi.New(links.NewService(links.NewMemory()), log),
		ReadHeaderTimeout: 5 * time.Second, // slow clients cannot hold connections forever
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       60 * time.Second,
		MaxHeaderBytes:    16 << 10,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	errCh := make(chan error, 1)
	go func() {
		log.Info("listening", "addr", *addr)
		errCh <- srv.ListenAndServe()
	}()

	select {
	case err := <-errCh:
		return err // could not start (port in use, ...)
	case <-ctx.Done():
	}
	log.Info("shutting down")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil { // stop accepting; wait for in-flight requests
		return err
	}
	if err := <-errCh; !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	log.Info("stopped cleanly")
	return nil
}
```

**Tests — `internal/httpapi/httpapi_test.go`**

```go
package httpapi

import (
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"example.com/shortener/internal/links"
)

func newServer(t *testing.T) *httptest.Server {
	t.Helper()
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	srv := httptest.NewServer(New(links.NewService(links.NewMemory()), log))
	t.Cleanup(srv.Close)
	return srv
}

// noRedirect makes the client return 3xx responses instead of following them.
var noRedirect = &http.Client{CheckRedirect: func(*http.Request, []*http.Request) error {
	return http.ErrUseLastResponse
}}

func post(t *testing.T, srv *httptest.Server, body string) (*http.Response, map[string]any) {
	t.Helper()
	resp, err := http.Post(srv.URL+"/api/links", "application/json", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var m map[string]any
	json.NewDecoder(resp.Body).Decode(&m)
	return resp, m
}

func TestCreateRedirectStats(t *testing.T) {
	srv := newServer(t)
	resp, body := post(t, srv, `{"url": "https://go.dev/doc/", "code": "godocs"}`)
	if resp.StatusCode != http.StatusCreated || body["code"] != "godocs" {
		t.Fatalf("create: %d %v", resp.StatusCode, body)
	}
	if resp.Header.Get("X-Request-ID") == "" {
		t.Error("no request ID header")
	}

	for range 3 {
		r, err := noRedirect.Get(srv.URL + "/godocs")
		if err != nil {
			t.Fatal(err)
		}
		r.Body.Close()
		if r.StatusCode != http.StatusFound || r.Header.Get("Location") != "https://go.dev/doc/" {
			t.Fatalf("redirect: %d %q", r.StatusCode, r.Header.Get("Location"))
		}
	}

	r, err := http.Get(srv.URL + "/api/links/godocs")
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	var l links.Link
	json.NewDecoder(r.Body).Decode(&l)
	if l.Hits != 3 {
		t.Errorf("hits = %d, want 3", l.Hits)
	}
}

func TestErrors(t *testing.T) {
	srv := newServer(t)
	post(t, srv, `{"url": "https://example.com", "code": "taken"}`)
	tests := []struct {
		name, body string
		want       int
	}{
		{"not json", `hello`, 400},
		{"unknown field", `{"url": "https://x.com", "colour": "red"}`, 400},
		{"bad scheme", `{"url": "ftp://x.com"}`, 400},
		{"no host", `{"url": "https://"}`, 400},
		{"bad code", `{"url": "https://x.com", "code": "a b"}`, 400},
		{"duplicate code", `{"url": "https://x.com", "code": "taken"}`, 409},
		{"too big", `{"url": "https://x.com/` + strings.Repeat("a", 20000) + `"}`, 400},
		{"generated code", `{"url": "https://x.com"}`, 201},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			resp, body := post(t, srv, tt.body)
			if resp.StatusCode != tt.want {
				t.Errorf("status %d, want %d (%v)", resp.StatusCode, tt.want, body)
			}
			if tt.want >= 400 && body["request_id"] == "" {
				t.Error("error body has no request_id")
			}
		})
	}
	r, _ := http.Get(srv.URL + "/nope")
	if r.StatusCode != 404 {
		t.Errorf("unknown code: %d", r.StatusCode)
	}
	req, _ := http.NewRequest(http.MethodDelete, srv.URL+"/api/links/taken", nil)
	r, _ = http.DefaultClient.Do(req)
	if r.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("DELETE: %d, want 405", r.StatusCode)
	}
}
```

**Tests — `internal/links/links_test.go`** (a stub store that collides, to test the retry loop)

```go
package links

import (
	"context"
	"errors"
	"testing"
)

// collidingStore reports ErrCodeTaken for the first n creates.
type collidingStore struct {
	*Memory
	n int
}

func (c *collidingStore) Create(ctx context.Context, l Link) error {
	if c.n > 0 {
		c.n--
		return ErrCodeTaken
	}
	return c.Memory.Create(ctx, l)
}

func TestShortenGeneratesCodes(t *testing.T) {
	svc := NewService(NewMemory())
	seen := map[string]bool{}
	for range 1000 {
		l, err := svc.Shorten(context.Background(), "https://example.com/x", "")
		if err != nil {
			t.Fatal(err)
		}
		if !codeRE.MatchString(l.Code) || len(l.Code) != genLength || seen[l.Code] {
			t.Fatalf("bad or repeated code %q", l.Code)
		}
		seen[l.Code] = true
	}
}

func TestShortenRetriesCollisions(t *testing.T) {
	svc := NewService(&collidingStore{Memory: NewMemory(), n: 3})
	if _, err := svc.Shorten(context.Background(), "https://a.com", ""); err != nil {
		t.Fatalf("3 collisions should be retried: %v", err)
	}
	svc = NewService(&collidingStore{Memory: NewMemory(), n: 100})
	if _, err := svc.Shorten(context.Background(), "https://a.com", ""); !errors.Is(err, ErrCodeTaken) {
		t.Fatalf("want ErrCodeTaken after 5 attempts, got %v", err)
	}
}
```

**A real session**

```
$ shortener -addr 127.0.0.1:18080 &
$ curl -i -X POST -d '{"url":"https://go.dev/doc/","code":"godocs"}' http://127.0.0.1:18080/api/links
HTTP/1.1 201 Created
Content-Type: application/json
Location: /api/links/godocs
X-Request-Id: J2PWT5LTNERQ

{"code":"godocs","url":"https://go.dev/doc/","created_at":"2026-11-15T01:34:13.391124175Z","hits":0}
$ curl -s -o /dev/null -w "%{http_code} -> %{redirect_url}\n" http://127.0.0.1:18080/godocs
302 -> https://go.dev/doc/
$ curl -s http://127.0.0.1:18080/api/links/godocs
{"code":"godocs","url":"https://go.dev/doc/","created_at":"2026-11-15T01:34:13.391124175Z","hits":1}
$ kill -INT %1
{"level":"INFO","msg":"shutting down"}
{"level":"INFO","msg":"stopped cleanly"}
```

### Review checklist (both projects)

- Every network read and write has a deadline or a context.
- Every goroutine has an owner and an exit path; `go test -race -count=20` passes.
- Inputs are bounded: line length, body size, URL length, header size.
- 4xx vs 5xx is correct for every error path; 500s never leak internal text.
- `Shutdown` is tested (the chat test does it; add one for the shortener).
- **Known limitations to discuss:** the shortener's data vanishes on restart (Chapter 9 fixes it); the redirect counts a hit with a write lock on every request — fine for thousands of requests per second, a contention point for much more (Chapter 9 moves counting to the database, Chapter 12 discusses batching); the chat server has no authentication, so anyone can pretend to be anyone.

## Answers to the Chapter 8 prediction questions

**8.3 Q2.** (a) 400 (b) 422 (or 400; be consistent) (c) 403 (d) 503 (or 500) (e) 409 (f) 429 with `Retry-After`.

**8.4 Q2.** 200: the first `Write` sends the status line with 200; the later `WriteHeader(500)` is ignored (and logged as superfluous).

**8.6 Q2.** Breaking: making `code` required; changing `hits` to a string. Compatible: adding `expires_at`; adding an optional query parameter.
