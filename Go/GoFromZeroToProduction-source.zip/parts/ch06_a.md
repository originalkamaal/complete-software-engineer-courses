# Chapter 6 — Data Structures, Algorithms & Complexity

*Goal: the computer science behind fast software — and behind the routing capstone.*

You have been using data structures since Chapter 2: slices are dynamic arrays, maps are hash tables, and `slices.Sort` is a sophisticated sorting algorithm. This chapter opens the box. You will learn to describe the cost of code precisely (Big-O), implement the classic structures and algorithms in idiomatic Go, and — just as important — learn when the theory's predictions are overturned by the machine (Unit 0.5's caches).

Everything here leads to Chapters 13 and 14: a routing engine is a graph, a priority queue, a few clever preprocessing tricks, and a lot of attention to memory layout.

**What you will be able to do after this chapter**

- Analyse time and space complexity, including amortised cost.
- Implement and choose between queues, stacks, heaps, hash tables, trees, tries, and union-find.
- Write correct binary searches (a famously error-prone task) and explain sorting trade-offs.
- Model problems as graphs and solve them with BFS, DFS, topological sort, and Dijkstra.
- Recognise dynamic programming, two-pointer, and sliding-window problems.
- Prove with benchmarks that memory layout can matter more than Big-O.

## Topic 6A — Tools for analysis

## Unit 6.1 — Big-O

**One-line summary:** Big-O describes how an algorithm's cost grows as the input grows, ignoring constant factors. O(1) does not grow, O(log n) grows very slowly, O(n) grows in proportion, O(n log n) is the cost of good sorting, O(n²) becomes painful quickly. Amortised analysis explains why `append` is O(1) on average even though it sometimes copies everything.

**Mental model — searching for a name.** Looking up page 512 of a book by its page number: O(1). Finding a name in a phone book by opening the middle and halving: O(log n). Reading every page to find all mentions of "Pune": O(n). Comparing every page with every other page to find duplicates: O(n²).

### The common classes

| Class | Name | n = 1,000 | n = 1,000,000 | Typical example |
| --- | --- | --- | --- | --- |
| O(1) | constant | 1 | 1 | slice index, map lookup (average) |
| O(log n) | logarithmic | ~10 | ~20 | binary search, balanced tree lookup, heap push |
| O(n) | linear | 1,000 | 1,000,000 | scanning a slice, `strings.Contains` |
| O(n log n) | linearithmic | ~10,000 | ~20,000,000 | `slices.Sort`, merge sort |
| O(n²) | quadratic | 1,000,000 | 10¹² — hours | nested loops over the same data, insertion sort |
| O(2ⁿ) | exponential | — | — | trying every subset |

At a billion simple operations per second, O(n²) for n = 1,000,000 takes about 17 minutes; O(n log n) takes 20 milliseconds. Choosing the right class beats any micro-optimisation.

### Rules for working it out

- **Count the work in terms of the input size.** One loop over n items: O(n). A loop inside a loop over the same items: O(n²). A loop that halves the range each time: O(log n).
- **Drop constants and smaller terms.** 3n + 50 is O(n); n² + n is O(n²).
- **Different inputs get different letters.** `countLoans` called for each book in Chapter 3's `List` is O(books × loans) — written O(b·l), not O(n²) (DT-186).
- **Hidden costs count.** `strings.Contains` inside a loop is a loop. `s += x` in a loop is O(n²) bytes copied (Unit 2.6). `slices.Contains` on a slice in a loop over the same slice is O(n²); a map makes it O(n).
- **Space complexity** is analysed the same way: how much extra memory as n grows. `logscan` was designed to be O(1) in lines and O(p) in distinct paths.

### Best, worst, average, amortised

- **Worst case:** the guarantee. Map lookups are O(n) in the worst case (every key collides) but O(1) on average with a good hash.
- **Amortised:** the average over a *sequence* of operations, guaranteed. `append` copies all n elements when it grows — O(n) for that one call — but because capacity doubles (Unit 2.3), the total copying for n appends is at most n + n/2 + n/4 + … < 2n. So the cost *per append*, averaged over the sequence, is O(1).

### Big-O is not the whole story

Big-O ignores constants, and constants matter: an O(n) scan of a contiguous slice can beat an O(log n) walk of a pointer-based tree for thousands of elements, because the slice scan streams through cache lines while the tree misses cache on every node (Unit 6.13 measures it). Use Big-O to avoid disasters; use benchmarks to choose between reasonable options.

### Deep & Tricky

**DT-209. Amortised O(1) still has O(n) spikes.** *(Consequence of amortisation)* An `append` that triggers growth of a 100-million-element slice copies 800 MB at once — a latency spike in a server even though the average is tiny. Pre-sizing (P-17) or chunked structures avoid spikes when latency matters.

**DT-210. Hash maps are O(1) only on average.** *(Algorithmic fact)* A hash function that maps many keys to the same bucket makes lookups linear. Go seeds its map hash randomly per map so attackers cannot construct colliding keys (hash-flooding attacks, which took down web servers in other languages in 2011).

### Mastery check

1. **Explain.** Why is `append` O(1) amortised? Use the doubling argument.
2. **Predict.** The Big-O of: (a) checking whether a slice has duplicates with two nested loops (b) the same with a map (c) sorting then comparing neighbours (d) `strings.Join` of n parts (e) `List` in Chapter 3.
3. **Write.** Rewrite Chapter 3's `List` to be O(b + l) and confirm with the Chapter 4 benchmark.

## Unit 6.2 — Recursion

**One-line summary:** A recursive function solves a problem by calling itself on smaller instances until a base case. It is natural for trees, divide-and-conquer, and backtracking. In Go each call costs a stack frame and there is no tail-call optimisation, so very deep recursion should become a loop with an explicit stack.

### Thinking recursively

Three questions: What is the **base case** (smallest problem with a direct answer)? How do I make the problem **smaller**? How do I **combine** the smaller answer into mine?

```go
// sum of a slice: base case empty; smaller = the rest; combine = first + sum(rest)
func sum(s []int) int {
	if len(s) == 0 {
		return 0
	}
	return s[0] + sum(s[1:])
}
```

### Memoisation: remembering answers

Naive recursive Fibonacci recomputes the same values exponentially many times (fib(40) makes about 300 million calls). Store answers:

```go
func fibMemo(n int, memo map[int]int) int {
	if n < 2 {
		return n
	}
	if v, ok := memo[n]; ok {
		return v
	}
	v := fibMemo(n-1, memo) + fibMemo(n-2, memo)
	memo[n] = v
	return v
}
```

Now each value is computed once: O(n). This is the doorway to dynamic programming (Unit 6.12).

### Recursion vs iteration in Go

- Each call adds a frame (Unit 0.6). Go's goroutine stacks grow by copying (DT-35) up to 1 GB, so recursion depth of tens of thousands is fine; millions are not (DT-39, DT-76).
- Recursion over a *balanced* tree is depth O(log n) — always safe. Recursion over a linked list, a degenerate tree, or a path in a large graph can be depth O(n) — convert to iteration with an explicit stack (a slice):

```go
// depth-first traversal without recursion
stack := []*node{root}
for len(stack) > 0 {
	n := stack[len(stack)-1]
	stack = stack[:len(stack)-1]
	visit(n)
	if n.right != nil {
		stack = append(stack, n.right)
	}
	if n.left != nil {
		stack = append(stack, n.left)
	}
}
```

### Deep & Tricky

**DT-211. Recursive closures must be declared before they are assigned.** *(Scope rule, Unit 1.9)* `walk := func(n *node) { walk(n.left) }` does not compile: `walk` is not in scope inside its own initialiser (DT-83). Declare first: `var walk func(*node)`, then `walk = func(n *node) { ... walk(n.left) ... }`. You will see this pattern in the trie and BST code of this chapter.

### Mastery check

1. **Explain.** Why is naive recursive Fibonacci exponential, and how does memoisation make it linear?
2. **Write.** `permutations(s []int) [][]int` by recursion (backtracking); then count how many results for n = 8 (should be 40,320).
3. **Write.** Convert a recursive in-order traversal of a binary tree to an iterative one with an explicit stack.

## Topic 6B — Linear structures and hashing

## Unit 6.3 — Lists, stacks, queues

**One-line summary:** A **stack** (LIFO) and a **queue** (FIFO) are access disciplines; in Go both are usually built on slices. A **ring buffer** makes a queue O(1) at both ends with no wasted memory. **Linked lists** have O(1) insertion in the middle but poor cache behaviour, so they are rarely the right choice in Go.

### Stack on a slice

```go
var stack []int
stack = append(stack, 1, 2, 3) // push
top := stack[len(stack)-1]     // peek: 3
stack = stack[:len(stack)-1]   // pop
```

Uses: undo history, expression evaluation, DFS (Unit 6.10), matching brackets. Unit 0.6's call stack is the same idea in hardware.

### Queue: why `s = s[1:]` is not enough

Popping with `q = q[1:]` is O(1), but the front of the backing array is never reused: in a long-running queue, `append` keeps allocating new arrays while old space is wasted. A **ring buffer** reuses slots by wrapping indexes around with `%`:

```go
// Queue is a FIFO queue backed by a growable ring buffer.
// The zero value is an empty queue ready to use.
type Queue[T any] struct {
	buf        []T
	head, size int
}

func (q *Queue[T]) Push(v T) {
	if q.size == len(q.buf) {
		q.grow()
	}
	q.buf[(q.head+q.size)%len(q.buf)] = v
	q.size++
}

func (q *Queue[T]) Pop() (v T, ok bool) {
	if q.size == 0 {
		return v, false
	}
	v = q.buf[q.head]
	var zero T
	q.buf[q.head] = zero // do not keep a reference for the GC
	q.head = (q.head + 1) % len(q.buf)
	q.size--
	return v, true
}

func (q *Queue[T]) grow() {
	n := max(4, 2*len(q.buf))
	nb := make([]T, n)
	for i := range q.size {
		nb[i] = q.buf[(q.head+i)%len(q.buf)]
	}
	q.buf, q.head = nb, 0
}
```

A fixed-capacity ring buffer that *overwrites* the oldest element is the classic structure for "last n log lines" (the `tail` exercise in Unit 5.2) and for buffers between producers and consumers. A **deque** (double-ended queue) adds push and pop at the front with the same technique.

### Linked lists

A linked list stores each element in its own node with a pointer to the next (and previous) node. Insert and delete at a known node are O(1); finding the k-th element is O(k). `container/list` provides a doubly linked list.

In practice, Go programmers rarely use linked lists, because every node is a separate heap allocation scattered in memory: walking a list of a million nodes allocated in random order was **114 times slower** than summing a slice in this book's benchmark (Unit 6.13). They earn their place inside other structures where O(1) *unlinking of a known node* is needed — the LRU cache of Unit 6.13 is the classic case.

### Deep & Tricky

**DT-212. A slice-based queue that pops with `q = q[1:]` can leak memory.** *(Consequence of Unit 2.4)* Popped elements stay in the backing array until it is reallocated; for pointer elements the GC cannot free their targets. The ring buffer above zeroes each slot on pop for the same reason.

### Mastery check

1. **Explain.** Why does a ring buffer need `%` (or a mask with power-of-two sizes)? Trace head and size through five pushes and three pops on capacity 4.
2. **Write.** A fixed-size `Ring[T]` that overwrites the oldest element when full, with `Push`, `Len`, and `All() iter.Seq[T]` (oldest first). Use it to implement `tail -n`.

## Unit 6.4 — Hash tables from scratch

**One-line summary:** A hash table turns a key into an array index with a hash function, handles collisions (two keys, one slot) by chaining or open addressing, and grows when the **load factor** gets too high, keeping operations O(1) on average.

### The pieces

1. **Hash function:** turns a key into a number, spreading similar keys far apart. Go provides `hash/maphash` (seeded, fast) for your own tables.
2. **Index:** `hash % len(buckets)` (or `hash & (len-1)` when the length is a power of two).
3. **Collision handling:**
   - *Chaining:* each bucket holds a small list of entries.
   - *Open addressing:* on collision, probe other slots in a fixed order (linear probing: the next slot). Better cache behaviour; deletions need care ("tombstones").
4. **Load factor** = entries / slots. Above a threshold (often 0.75–0.875), allocate a table twice as big and re-insert everything. Doubling makes growth amortised O(1), exactly like `append`.

### A minimal chained hash map

```go
type entry[V any] struct {
	key string
	val V
}

type HashMap[V any] struct {
	seed    maphash.Seed
	buckets [][]entry[V]
	n       int
}

func NewHashMap[V any]() *HashMap[V] {
	return &HashMap[V]{seed: maphash.MakeSeed(), buckets: make([][]entry[V], 8)}
}

func (m *HashMap[V]) index(k string) int {
	return int(maphash.String(m.seed, k) % uint64(len(m.buckets)))
}

func (m *HashMap[V]) Put(k string, v V) {
	i := m.index(k)
	for j := range m.buckets[i] {
		if m.buckets[i][j].key == k {
			m.buckets[i][j].val = v
			return
		}
	}
	m.buckets[i] = append(m.buckets[i], entry[V]{k, v})
	m.n++
	if m.n > len(m.buckets)*3/4 { // load factor 0.75
		m.resize(2 * len(m.buckets))
	}
}

func (m *HashMap[V]) Get(k string) (V, bool) {
	for _, e := range m.buckets[m.index(k)] {
		if e.key == k {
			return e.val, true
		}
	}
	var zero V
	return zero, false
}

func (m *HashMap[V]) resize(n int) {
	old := m.buckets
	m.buckets = make([][]entry[V], n)
	for _, b := range old {
		for _, e := range b {
			i := m.index(e.key)
			m.buckets[i] = append(m.buckets[i], e)
		}
	}
}
```

Go's built-in map is far more sophisticated (Swiss tables with groups of 8 slots and SIMD-style control bytes, DT-119; incremental growth), but the ideas are these. Building your own is an exercise in understanding; in production, use the built-in map unless measurements show a specialised table is needed.

### Deep & Tricky

**DT-213. A good hash for a composite key combines all its parts.** *(Algorithmic practice)* Hashing only the first field of a struct key puts all keys with equal first fields into one bucket. `maphash.Comparable(seed, key)` (Go 1.24) hashes any comparable value correctly; Go 1.27's `maphash.Hasher` interface and `ComparableHasher` support custom hash-based containers.

### Mastery check

1. **Explain.** What is the load factor and why must the table grow when it gets high? Why does doubling keep `Put` amortised O(1)?
2. **Write.** Add `Delete` to the chained map, plus a test that inserts 100,000 random keys, deletes half, and checks the rest. Count the longest bucket chain; how does it compare with the average?

## Topic 6C — Searching and sorting

## Unit 6.5 — Binary search and its variants

**One-line summary:** Binary search finds an element in a sorted slice in O(log n) by halving the search range. Write it with a clear **invariant** to avoid the classic off-by-one bugs, and generalise it to "find the first position where a condition becomes true" — which solves many problems that do not look like searching.

### The invariant-based version

```go
// lowerBound returns the first index i with s[i] >= x (len(s) if none).
func lowerBound(s []int, x int) int {
	lo, hi := 0, len(s) // invariant: s[:lo] < x, s[hi:] >= x
	for lo < hi {
		mid := int(uint(lo+hi) >> 1) // avoids overflow
		if s[mid] < x {
			lo = mid + 1
		} else {
			hi = mid
		}
	}
	return lo
}
```

With `s = [1 3 3 3 7 9]`: `lowerBound(s, 3)` is 1 (first 3), `lowerBound(s, 4)` is 4 (where 4 would be inserted), `lowerBound(s, 10)` is 6 (`len(s)`). "Is x present?" is `i < len(s) && s[i] == x`. "Last element ≤ x" and "count of x" follow from lower bounds of x and x+1.

The standard library does this for you: `slices.BinarySearch(s, x)` returns `(index, found)`, `slices.BinarySearchFunc` takes a comparison, and `sort.Search(n, func(i int) bool)` finds the first i where a predicate is true.

### Binary search on the answer

The real power: any monotone condition (false…false, true…true) can be searched.

```go
// firstTrue finds the smallest n in [lo, hi) for which ok(n) is true,
// given ok is false...false true...true. Returns hi if never true.
func firstTrue(lo, hi int, ok func(int) bool) int {
	for lo < hi {
		mid := int(uint(lo+hi) >> 1)
		if ok(mid) {
			hi = mid
		} else {
			lo = mid + 1
		}
	}
	return lo
}

firstTrue(0, 1000, func(n int) bool { return n*n >= 700 }) // 27: smallest n with n² ≥ 700
```

Examples: the smallest capacity that ships all parcels within D days; the first commit where a test fails (`git bisect` is binary search); the smallest timeout that makes 99% of requests succeed.

### Deep & Tricky

**DT-214. `(lo + hi) / 2` can overflow.** *(Classic bug)* For huge indexes, `lo + hi` exceeds the maximum int and becomes negative (Unit 0.4). This bug existed in Java's standard library for nine years. `int(uint(lo+hi) >> 1)` (what Go's `sort.Search` uses) or `lo + (hi-lo)/2` is safe. On 64-bit Go with slice indexes it is mostly theoretical, but in binary search over a *numeric range* of int64 values it is real.

### Mastery check

1. **Explain.** State the invariant of `lowerBound`. Why does the loop terminate, and why is `lo` the answer?
2. **Predict.** `slices.BinarySearch([]int{1, 3, 3, 3, 7}, 3)` and `(..., 4)`.
3. **Write.** `shipCapacity(weights []int, days int) int` — the smallest truck capacity that ships parcels in order within `days` (each day loads parcels in order until the next would exceed capacity). Use `firstTrue`.

## Unit 6.6 — Sorting

**One-line summary:** Insertion sort is O(n²) but fast on tiny or nearly-sorted inputs; merge sort is O(n log n) and stable; quicksort is O(n log n) on average and in place; heap sort is O(n log n) worst case. Go's `slices.Sort` uses **pdqsort**, a hybrid that combines their strengths. Know stability and comparison-function rules.

### Insertion sort

```go
func insertionSort[T cmp.Ordered](s []T) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && s[j] < s[j-1]; j-- {
			s[j], s[j-1] = s[j-1], s[j]
		}
	}
}
```

O(n²) in general, O(n) on sorted input, and the fastest choice below about a dozen elements — which is why hybrid sorts finish small partitions with it.

### Merge sort

```go
func mergeSort[T cmp.Ordered](s []T) []T {
	if len(s) <= 1 {
		return s
	}
	mid := len(s) / 2
	left, right := mergeSort(s[:mid]), mergeSort(s[mid:])
	out := make([]T, 0, len(s))
	i, j := 0, 0
	for i < len(left) && j < len(right) {
		if right[j] < left[i] { // strict: equal elements keep left first -> stable
			out = append(out, right[j])
			j++
		} else {
			out = append(out, left[i])
			i++
		}
	}
	out = append(out, left[i:]...)
	return append(out, right[j:]...)
}
```

Always O(n log n), **stable**, but needs O(n) extra memory. Its merge step is also how you combine sorted files too large for memory (external sorting).

### Quicksort

```go
func quickSort[T cmp.Ordered](s []T) {
	if len(s) <= 1 {
		return
	}
	p := s[len(s)/2] // middle element as pivot
	i, j := 0, len(s)-1
	for i <= j { // Hoare-style partition
		for s[i] < p {
			i++
		}
		for s[j] > p {
			j--
		}
		if i <= j {
			s[i], s[j] = s[j], s[i]
			i++
			j--
		}
	}
	quickSort(s[:j+1])
	quickSort(s[i:])
}
```

In place and very fast on average, but O(n²) with consistently bad pivots, and not stable.

### Heap sort

Build a binary heap (Unit 6.8), then repeatedly move the maximum to the end. O(n log n) worst case, in place, not stable, and cache-unfriendly in practice.

### What Go actually uses

`slices.Sort` and `sort.Sort` use **pattern-defeating quicksort** (pdqsort): quicksort with smart pivot choice, insertion sort for small partitions, detection of already-sorted runs, and a switch to heap sort if partitioning goes badly — O(n log n) worst case and very fast on real data. `slices.SortStableFunc` uses a stable insertion/merge strategy.

### Comparison functions must be consistent

`slices.SortFunc(s, cmp)` requires a **strict weak ordering**: if `cmp(a, b) < 0` then `cmp(b, a) > 0`; transitive; equal elements compare 0. A comparison that is inconsistent (comparing floats including NaN with `<`, or a random tie-break) can produce an unsorted result. `cmp.Compare` handles NaN consistently (NaN sorts before all other floats).

### Deep & Tricky

**DT-215. Comparison-based sorting cannot beat O(n log n).** *(Theorem)* Any sort that only compares elements needs about log₂(n!) ≈ n log₂ n comparisons in the worst case. Faster sorts (counting sort, radix sort: O(n + k)) exploit the *structure* of keys — small integers, fixed-length strings — and are worth knowing for large numeric datasets.

**DT-216. Sorting floats with NaN using `<` breaks.** *(IEEE 754 + algorithm contract)* `NaN < x` and `x < NaN` are both false, so NaN "equals" everything, violating transitivity; elements around NaN may end up out of order. `slices.Sort` on `[]float64` handles NaN by placing them first; a hand-written `func(a, b float64) int` using `<` does not.

### Mastery check

1. **Explain.** What does "stable" mean, and give a real case where it matters (hint: sort orders by date, then stably by customer).
2. **Explain.** Why do hybrid sorts switch to insertion sort for small partitions?
3. **Write.** Counting sort for a slice of exam marks (0–100), stable, and benchmark it against `slices.Sort` for 10 million marks.

## Topic 6D — Trees and heaps

## Unit 6.7 — Trees

**One-line summary:** A binary search tree (BST) keeps keys ordered so lookup, insert, and delete take O(height). Unbalanced, the height can become n; **balanced** trees (AVL, red-black) keep it O(log n). **B-trees** keep many keys per node to match disk and cache blocks, which is why every database index is one.

### A generic BST

```go
type BST[K cmp.Ordered, V any] struct {
	root *bstNode[K, V]
	n    int
}

type bstNode[K cmp.Ordered, V any] struct {
	key         K
	val         V
	left, right *bstNode[K, V]
}

func (t *BST[K, V]) Put(k K, v V) {
	p := &t.root // pointer to the link we might replace
	for *p != nil {
		switch c := cmp.Compare(k, (*p).key); {
		case c < 0:
			p = &(*p).left
		case c > 0:
			p = &(*p).right
		default:
			(*p).val = v
			return
		}
	}
	*p = &bstNode[K, V]{key: k, val: v}
	t.n++
}

func (t *BST[K, V]) Get(k K) (V, bool) {
	n := t.root
	for n != nil {
		switch c := cmp.Compare(k, n.key); {
		case c < 0:
			n = n.left
		case c > 0:
			n = n.right
		default:
			return n.val, true
		}
	}
	var zero V
	return zero, false
}

// InOrder visits keys in sorted order.
func (t *BST[K, V]) InOrder(visit func(K, V)) {
	var walk func(*bstNode[K, V])
	walk = func(n *bstNode[K, V]) {
		if n == nil {
			return
		}
		walk(n.left)
		visit(n.key, n.val)
		walk(n.right)
	}
	walk(t.root)
}
```

The pointer-to-pointer trick in `Put` (`p := &t.root`) avoids special-casing the root: `p` always points at the link to replace.

### Balance

Insert 1, 2, 3, …, n into a plain BST and every node becomes a right child: a linked list of height n, so every operation is O(n). Balanced trees restructure on insert and delete:

- **AVL trees** keep the heights of every node's subtrees within 1, using rotations. Very strictly balanced: fast lookups.
- **Red-black trees** colour nodes and enforce rules that keep the longest path at most twice the shortest. Fewer rotations on updates. Used in many standard libraries (C++ `std::map`, Java `TreeMap`, the Linux kernel's scheduler).

You rarely implement these by hand; know what they guarantee, and that Go's standard library deliberately has no ordered map (use a sorted slice for small, read-mostly data, or a third-party B-tree such as `github.com/google/btree`).

### B-trees and databases

A B-tree node holds many keys (hundreds) and many children. The tree is very shallow — four levels can index billions of rows — and each node is one disk page or several cache lines, so a lookup touches only a handful of pages. PostgreSQL indexes, SQLite, MySQL InnoDB, and file systems use B-trees or B+ trees (Unit 9.2). It is the same lesson as Unit 0.5: design for the memory hierarchy.

### Deep & Tricky

**DT-217. Sorted slices beat trees for read-mostly data.** *(Performance practice)* A sorted slice with binary search is compact, cache-friendly, and has zero per-element allocation; inserts are O(n) because of shifting. For data built once and queried often (configuration, routing tables, dictionaries), it is usually faster than any tree. Trees win when inserts and deletes are frequent and interleaved with lookups.

### Mastery check

1. **Explain.** Why does inserting sorted keys into a plain BST destroy its performance?
2. **Write.** Add `Min`, `Max`, and `Floor(k)` (largest key ≤ k) to the BST, and a `Height()` method. Insert 1..1000 in order and in random order; compare heights.

## Unit 6.8 — Heaps and priority queues

**One-line summary:** A binary heap is a complete binary tree stored in a slice where every parent is smaller (min-heap) than its children. It gives O(1) access to the minimum and O(log n) push and pop — the data structure behind priority queues, Dijkstra's algorithm, schedulers, timers, and top-k problems.

### The array layout

A heap needs no pointers: for the element at index i, its children are at 2i+1 and 2i+2, and its parent at (i−1)/2. **Push** appends at the end and "sifts up" while smaller than its parent; **Pop** takes the root, moves the last element to the root, and "sifts down" while larger than its smallest child. Both walk one path of a tree of height log₂ n.

The generic priority queue from this chapter's project:

```go
// PQ is a priority queue: Pop returns the element for which less
// reports true against all others. Create it with NewPQ.
type PQ[T any] struct {
	items []T
	less  func(a, b T) bool
}

func NewPQ[T any](less func(a, b T) bool) *PQ[T] { return &PQ[T]{less: less} }

func (p *PQ[T]) Len() int { return len(p.items) }

func (p *PQ[T]) Push(v T) {
	p.items = append(p.items, v)
	p.up(len(p.items) - 1)
}

func (p *PQ[T]) Pop() (v T, ok bool) {
	n := len(p.items)
	if n == 0 {
		return v, false
	}
	v = p.items[0]
	p.items[0] = p.items[n-1]
	var zero T
	p.items[n-1] = zero
	p.items = p.items[:n-1]
	if len(p.items) > 0 {
		p.down(0)
	}
	return v, true
}

func (p *PQ[T]) up(i int) {
	for i > 0 {
		parent := (i - 1) / 2
		if !p.less(p.items[i], p.items[parent]) {
			return
		}
		p.items[i], p.items[parent] = p.items[parent], p.items[i]
		i = parent
	}
}

func (p *PQ[T]) down(i int) {
	n := len(p.items)
	for {
		smallest := i
		l, r := 2*i+1, 2*i+2
		if l < n && p.less(p.items[l], p.items[smallest]) {
			smallest = l
		}
		if r < n && p.less(p.items[r], p.items[smallest]) {
			smallest = r
		}
		if smallest == i {
			return
		}
		p.items[i], p.items[smallest] = p.items[smallest], p.items[i]
		i = smallest
	}
}
```

### `container/heap`

The standard library's heap works on any type implementing `heap.Interface` (`sort.Interface` plus `Push` and `Pop`):

```go
type Task struct {
	Name     string
	Priority int
}

type taskHeap []Task

func (h taskHeap) Len() int           { return len(h) }
func (h taskHeap) Less(i, j int) bool { return h[i].Priority > h[j].Priority } // max-heap
func (h taskHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *taskHeap) Push(x any)        { *h = append(*h, x.(Task)) }
func (h *taskHeap) Pop() any {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

func topTasks(tasks []Task) []string {
	h := &taskHeap{}
	for _, t := range tasks {
		heap.Push(h, t) // call heap.Push, NOT h.Push
	}
	var out []string
	for h.Len() > 0 {
		out = append(out, heap.Pop(h).(Task).Name)
	}
	return out
}
```

Note the confusing part: your `Push`/`Pop` methods only append and remove the *last* element; the package functions `heap.Push`/`heap.Pop` do the sifting. `heap.Fix(h, i)` restores order after changing element i's priority — needed for "decrease-key" in some graph algorithms. The generic `PQ` above is easier to use and avoids `any` boxing; `container/heap` predates generics.

### Top-k in O(n log k)

To find the 10 largest of a billion numbers, keep a **min**-heap of size 10: push each number; if the heap exceeds 10, pop the minimum. Memory O(k), time O(n log k).

### Deep & Tricky

**DT-218. Building a heap from n elements is O(n), not O(n log n).** *(Algorithmic fact)* `heap.Init` sifts down from the middle of the array to the start; most elements are near the bottom and move very little, and the total work sums to O(n). Pushing n elements one by one is O(n log n).

### Mastery check

1. **Explain.** For index 9 in a heap slice, which indexes are its parent and children?
2. **Write.** `topK(nums []int, k int) []int` using a min-heap of size k, and a test comparing it with sorting the whole slice.
3. **Write.** Merge k sorted slices into one sorted slice in O(n log k) with a heap of (value, slice index, position).

## Unit 6.9 — Tries and string algorithms basics

**One-line summary:** A trie stores strings by their characters along tree paths, so all words with a given prefix sit under one node — ideal for autocomplete, prefix routing, and dictionaries. Simple string-search ideas (naive search, the idea behind KMP and rolling hashes) round out the basics.

### A trie

```go
type Trie struct {
	children map[rune]*Trie
	end      bool // a word ends here
}

func (t *Trie) Insert(word string) {
	n := t
	for _, r := range word { // runes, so Hindi and emoji work (Unit 2.5)
		if n.children == nil {
			n.children = make(map[rune]*Trie)
		}
		next, ok := n.children[r]
		if !ok {
			next = &Trie{}
			n.children[r] = next
		}
		n = next
	}
	n.end = true
}

// WithPrefix returns all stored words that start with prefix, sorted.
func (t *Trie) WithPrefix(prefix string) []string {
	n := t
	for _, r := range prefix {
		if n = n.children[r]; n == nil {
			return nil
		}
	}
	var out []string
	var walk func(*Trie, []rune)
	walk = func(n *Trie, cur []rune) {
		if n.end {
			out = append(out, string(cur))
		}
		for r, c := range n.children {
			walk(c, append(cur, r))
		}
	}
	walk(n, []rune(prefix))
	slices.Sort(out) // map order is random (Unit 2.7)
	return out
}
```

Lookup is O(length of the word), independent of how many words are stored. The cost is memory: one map per node. Production tries compress chains of single-child nodes (radix trees), which is how HTTP routers (`net/http`'s `ServeMux` patterns, Unit 8.4) and IP routing tables match prefixes quickly.

### String search in brief

- **Naive search** compares the pattern at every position: O(n·m) worst case. Go's `strings.Index` is much smarter: it uses fast byte search (often SIMD instructions) for the first byte and a Rabin–Karp rolling hash or other techniques for longer patterns.
- **Rabin–Karp** computes a hash of each window of the text in O(1) from the previous window ("rolling hash"), comparing strings only when hashes match. Also the basis of content-defined chunking in backup tools.
- **KMP** precomputes, for each prefix of the pattern, how far to fall back after a mismatch, giving O(n + m) worst case.

Use `strings.Index`, `strings.Contains`, `bytes.Index` — they are highly optimised. Know the ideas so you recognise them in specialised problems (searching many patterns at once uses **Aho–Corasick**, a trie with failure links).

### Mastery check

1. **Explain.** Why is trie lookup independent of the number of stored words? What does it cost instead?
2. **Write.** Add `Delete(word)` that also removes now-empty nodes, and a `Count()` of stored words; test with words sharing prefixes ("go", "gopher", "golang").

## Topic 6E — Graphs

## Unit 6.10 — Graph basics

**One-line summary:** A graph is a set of nodes (vertices) connected by edges, directed or undirected, weighted or not. Represent it as an **adjacency list** (usually) or an **adjacency matrix** (dense graphs). **BFS** explores level by level (shortest paths in unweighted graphs); **DFS** goes deep first (reachability, cycles); **topological sort** orders tasks by their dependencies.

**Mental model — the city map.** Intersections are nodes, roads are edges, one-way streets are directed edges, travel times are weights. Almost every "connections" problem — road networks, social networks, package dependencies, build systems, network routing — is a graph problem.

### Representations

| | Adjacency list | Adjacency matrix |
| --- | --- | --- |
| Go form | `map[Node][]Node` or `[][]int` (nodes numbered 0..n−1) | `[][]bool` or flat `[]float64` of size n² |
| Memory | O(V + E) | O(V²) |
| "Is there an edge u→v?" | O(degree of u) | O(1) |
| "All neighbours of u" | O(degree of u) | O(V) |
| Use for | sparse graphs (roads, the web) | small or dense graphs |

Road networks are very sparse (an intersection has about 3 neighbours), so adjacency lists — eventually in compact flat-array form (Unit 13.8) — are the right choice for routing.

### Breadth-first search

BFS uses a **queue**: visit the start, then all nodes 1 edge away, then 2 edges away, … The first time BFS reaches a node is along a path with the fewest edges. The Chapter 6 project's `Grid.BFS` is BFS on a grid graph (Unit 6.3's `Queue` does the work). O(V + E).

### Depth-first search

DFS uses recursion (or an explicit stack): go as deep as possible, then backtrack.

```go
type Graph map[string][]string // adjacency list

// DFS visits every node reachable from start, in depth-first order.
func DFS(g Graph, start string, visit func(string)) {
	seen := map[string]bool{}
	var walk func(string)
	walk = func(n string) {
		if seen[n] {
			return
		}
		seen[n] = true
		visit(n)
		for _, m := range g[n] {
			walk(m)
		}
	}
	walk(start)
}
```

Uses: reachability ("can this package import that one?"), connected components, cycle detection (a node seen again *while still on the current path*), maze generation, and topological sort.

### Topological sort

Given dependencies ("pay before ship"), find an order where every task comes after the tasks it depends on. Kahn's algorithm repeatedly takes a node with no remaining incoming edges:

```go
var ErrCycle = errors.New("graph has a cycle")

// TopoSort returns an order in which every node comes after its
// dependencies (Kahn's algorithm). Edges point from a node to the nodes
// that depend on it.
func TopoSort(g Graph) ([]string, error) {
	indeg := map[string]int{}
	for n, outs := range g {
		if _, ok := indeg[n]; !ok {
			indeg[n] = 0
		}
		for _, m := range outs {
			indeg[m]++
		}
	}
	var ready []string
	for n, d := range indeg {
		if d == 0 {
			ready = append(ready, n)
		}
	}
	slices.Sort(ready) // deterministic output
	var order []string
	for len(ready) > 0 {
		n := ready[0]
		ready = ready[1:]
		order = append(order, n)
		next := slices.Clone(g[n])
		slices.Sort(next)
		for _, m := range next {
			indeg[m]--
			if indeg[m] == 0 {
				ready = append(ready, m)
			}
		}
	}
	if len(order) != len(indeg) {
		return nil, ErrCycle // some nodes never became ready: they are in a cycle
	}
	return order, nil
}

TopoSort(Graph{"shop": {"pay", "ship"}, "pay": {"ship"}, "ship": {"done"}})
// [shop pay ship done]
```

This is how `go build` orders package compilation, how `make` orders targets, and how database migrations and package initialisation (Unit 3.12) are ordered. An import cycle (forbidden in Go) is exactly a graph cycle.

### Deep & Tricky

**DT-219. Recursive DFS on large graphs can overflow the stack — or just be slow.** *(Go-specific, DT-39, DT-76)* A road graph with millions of nodes can produce DFS paths millions deep. Use an explicit stack for production graph code. Note also that `map[string]bool` for "seen" is convenient but slow at scale; numbering nodes 0..n−1 and using a `[]bool` (or a bitset) is often 10× faster (Unit 13.8).

### Mastery check

1. **Explain.** Why does BFS find the fewest-edges path, and why does it fail for weighted roads?
2. **Write.** Detect a cycle in a directed graph with DFS (three colours: unvisited, on the current path, finished) and return the cycle's nodes.
3. **Write.** Given a module's `go list -m -json all`-style dependency pairs, print a valid build order or report the cycle.

## Unit 6.11 — Shortest paths

**One-line summary:** **Dijkstra's algorithm** finds cheapest paths from a source in graphs with non-negative edge weights, using a priority queue: O((V + E) log V). **Union-find** answers "are these connected?" in nearly O(1) and powers minimum spanning trees. These are the foundation of the routing chapters.

### Dijkstra

Idea: always expand the cheapest unexplored node; with non-negative weights, its distance is then final.

1. `dist[start] = 0`; push (start, 0) into a min-priority queue.
2. Pop the node with the smallest distance. If this entry is stale (a cheaper distance was already found), skip it.
3. If it is the target, stop. Otherwise, for each neighbour, if `dist[node] + weight` improves the neighbour's distance, record it and its predecessor, and push it.
4. Rebuild the path by following predecessors back from the target.

The project's implementation on a weighted grid:

```go
func (g *Grid) Dijkstra() ([]Point, int, error) {
	type item struct {
		p    Point
		dist int
	}
	dist := map[Point]int{g.Start: 0}
	prev := make(map[Point]Point)
	pq := ds.NewPQ(func(a, b item) bool { return a.dist < b.dist })
	pq.Push(item{g.Start, 0})
	for pq.Len() > 0 {
		it, _ := pq.Pop()
		if it.dist > dist[it.p] {
			continue // stale entry: a shorter route was found after it was pushed
		}
		if it.p == g.End {
			return path(prev, g.Start, g.End), it.dist, nil
		}
		g.neighbours(it.p, func(n Point) {
			nd := it.dist + g.cost[n.R*g.cols+n.C]
			if old, ok := dist[n]; !ok || nd < old {
				dist[n] = nd
				prev[n] = it.p
				pq.Push(item{n, nd})
			}
		})
	}
	return nil, 0, ErrNoPath
}
```

"Lazy deletion" (pushing a node again instead of decreasing its key, and skipping stale entries) is simpler than `heap.Fix` and usually as fast. Negative weights break Dijkstra; Bellman–Ford handles them in O(V·E). For routing on real maps, Chapter 13 adds A* (Dijkstra guided by a distance estimate), bidirectional search, and preprocessing (contraction hierarchies) that answer queries thousands of times faster.

### Union-find (disjoint sets)

```go
// UnionFind tracks a partition of the integers 0..n-1 into sets.
type UnionFind struct {
	parent, size []int
}

func NewUnionFind(n int) *UnionFind {
	u := &UnionFind{parent: make([]int, n), size: make([]int, n)}
	for i := range n {
		u.parent[i], u.size[i] = i, 1
	}
	return u
}

// Find returns the representative of x's set, compressing the path.
func (u *UnionFind) Find(x int) int {
	for u.parent[x] != x {
		u.parent[x] = u.parent[u.parent[x]] // path halving
		x = u.parent[x]
	}
	return x
}

// Union merges the sets of a and b and reports whether they were separate.
func (u *UnionFind) Union(a, b int) bool {
	ra, rb := u.Find(a), u.Find(b)
	if ra == rb {
		return false
	}
	if u.size[ra] < u.size[rb] {
		ra, rb = rb, ra // attach the smaller tree under the larger
	}
	u.parent[rb] = ra
	u.size[ra] += u.size[rb]
	return true
}
```

With union by size and path compression, operations take amortised O(α(n)) — the inverse Ackermann function, below 5 for any input that fits in the universe. Uses: connected components of a road network (which parts of the map are reachable at all — useful before routing), Kruskal's minimum spanning tree, and clustering.

### Deep & Tricky

**DT-220. Dijkstra's correctness depends on non-negative weights — and so does your early exit.** *(Algorithmic fact)* With a negative edge, a node popped "final" can later be improved, and stopping when the target is popped returns a wrong answer. Road travel times are never negative, but "rewards" or "discounts" modelled as negative costs break the algorithm silently.

### Mastery check

1. **Explain.** Why can Dijkstra stop as soon as it pops the target? What about a target pushed but not yet popped?
2. **Write.** Dijkstra on an adjacency-list graph (`[][]Edge` with `To int; W int`) using `ds.PQ`, returning distances to all nodes; test against a brute-force Bellman–Ford on random small graphs.
3. **Write.** Count the connected components of a grid map with union-find (cells are nodes; join open neighbours).

## Topic 6F — Techniques and real-world speed

## Unit 6.12 — Problem-solving techniques

**One-line summary:** **Dynamic programming** solves problems with overlapping subproblems by building a table of answers; **two pointers** walk a sorted sequence from both ends; a **sliding window** maintains a running answer over a moving range. Recognising the pattern is most of the work.

### Dynamic programming

When a problem's answer depends on answers to smaller versions of the same problem, and those smaller problems repeat, store them. Two styles: top-down with memoisation (Unit 6.2) or bottom-up with a table.

**Fewest coins** for an amount — greedy (always take the largest coin) fails for coins {1, 3, 4} and amount 6 (greedy: 4+1+1 = 3 coins; best: 3+3 = 2 coins):

```go
// minCoins returns the fewest coins that sum to amount, or -1.
func minCoins(coins []int, amount int) int {
	const inf = 1 << 62
	best := make([]int, amount+1) // best[a] = fewest coins for a
	for a := 1; a <= amount; a++ {
		best[a] = inf
		for _, c := range coins {
			if c <= a && best[a-c] != inf {
				best[a] = min(best[a], best[a-c]+1)
			}
		}
	}
	if best[amount] == inf {
		return -1
	}
	return best[amount]
}
```

**Longest common subsequence** (the core of `diff` tools) with two rolling rows to use O(m) memory:

```go
func lcs(a, b string) int {
	prev := make([]int, len(b)+1)
	cur := make([]int, len(b)+1)
	for i := 1; i <= len(a); i++ {
		for j := 1; j <= len(b); j++ {
			if a[i-1] == b[j-1] {
				cur[j] = prev[j-1] + 1
			} else {
				cur[j] = max(prev[j], cur[j-1])
			}
		}
		prev, cur = cur, prev
	}
	return prev[len(b)]
}
```

`lcs("AGGTAB", "GXTXAYB")` is 4 ("GTAB"). The recipe: define the state (`best[a]`, `L[i][j]`), write the recurrence, choose an order so dependencies are computed first, identify the base cases.

### Two pointers

On a sorted slice, find a pair with a given sum in O(n) instead of O(n²):

```go
func pairWithSum(s []int, target int) (int, int, bool) {
	i, j := 0, len(s)-1
	for i < j {
		switch sum := s[i] + s[j]; {
		case sum == target:
			return i, j, true
		case sum < target:
			i++ // need a bigger sum
		default:
			j-- // need a smaller sum
		}
	}
	return 0, 0, false
}
```

Also: merging sorted lists, removing duplicates in place, reversing, and the in-place filter of Unit 2.4.

### Sliding window

Maintain a window `[start, i]` that satisfies a condition, extending on the right and shrinking on the left:

```go
// longestUniqueRun returns the length of the longest substring of s
// without repeated bytes.
func longestUniqueRun(s string) int {
	last := [256]int{} // last index+1 where each byte was seen
	best, start := 0, 0
	for i := 0; i < len(s); i++ {
		if last[s[i]] > start {
			start = last[s[i]] // jump past the previous occurrence
		}
		last[s[i]] = i + 1
		best = max(best, i+1-start)
	}
	return best
}
```

Real uses: rate limiters ("requests in the last 60 seconds", Unit 12.8), moving averages in monitoring, and detecting bursts in logs.

### Mastery check

1. **Explain.** Why does greedy coin change fail for {1, 3, 4}, and why does the DP succeed?
2. **Write.** `maxSumWindow(s []int, k int) int` (maximum sum of any k consecutive elements) in O(n).
3. **Write.** Edit distance (insert, delete, replace) between two strings with DP; then make it work on runes, not bytes, and test with Hindi words.

## Unit 6.13 — Caches and memory-friendly design

**One-line summary:** An LRU cache combines a hash map and a doubly linked list for O(1) lookups and evictions. And memory layout — contiguous slices, row-major traversal, values instead of pointers — can change real speed by an order of magnitude or more without changing Big-O. Measure it.

### LRU cache

"Least recently used" eviction keeps the most useful items when space runs out (Unit 9.7 uses it in front of a database):

```go
type LRU[K comparable, V any] struct {
	cap        int
	items      map[K]*lruNode[K, V]
	head, tail *lruNode[K, V] // head = most recent
}

type lruNode[K comparable, V any] struct {
	key        K
	val        V
	prev, next *lruNode[K, V]
}

func (c *LRU[K, V]) Get(k K) (v V, ok bool) {
	n, ok := c.items[k]
	if !ok {
		return v, false
	}
	c.moveToFront(n)
	return n.val, true
}

func (c *LRU[K, V]) Put(k K, v V) {
	if n, ok := c.items[k]; ok {
		n.val = v
		c.moveToFront(n)
		return
	}
	if len(c.items) == c.cap {
		old := c.tail // evict the least recently used
		c.unlink(old)
		delete(c.items, old.key)
	}
	n := &lruNode[K, V]{key: k, val: v}
	c.items[k] = n
	c.pushFront(n)
}
```

The map finds a node in O(1); the list moves it to the front or removes the tail in O(1) because each node knows its neighbours. The full code (with `unlink`, `pushFront`, `moveToFront`) is in the project. This is the textbook case where a linked list earns its place. (This version is not safe for concurrent use; Chapter 7 adds a mutex.)

### The measurements

Benchmarks run for this book (Go 1.24, x86-64 server, 2²⁰ = 1,048,576 integers):

| Operation | Time | Relative |
| --- | --- | --- |
| Sum a `[]int` | 0.43 ms | 1× |
| Sum a `container/list` built in order | 3.55 ms | 8× |
| Sum a hand-made linked list whose nodes were shuffled in memory | 48.6 ms | **114×** |
| Sum a 2048×2048 `[]int32` grid row by row | 2.07 ms | 1× |
| Same grid, column by column | 27.7 ms | **13×** |

All of these are O(n). The differences come entirely from the memory hierarchy (Unit 0.5): the slice and the row-major walk read memory sequentially, so every cache line brings 8 or 16 useful values and the hardware prefetcher streams ahead; the shuffled list and the column walk jump around, so almost every access waits for RAM.

### Design rules that follow

- Prefer slices of values (`[]Point`) over slices of pointers (`[]*Point`) for data you scan (Unit 2.12).
- Traverse multi-dimensional data in the order it is laid out (row-major for `r*cols + c`).
- Number your nodes 0..n−1 and use slices instead of maps keyed by structs or strings in hot graph code (Unit 13.8).
- Keep hot fields together and cold fields elsewhere ("struct of arrays" for very large datasets: `xs []float64; ys []float64` instead of `[]struct{ x, y float64; name string; ... }` when you only scan x and y).
- And always: **benchmark** (Unit 4.5) before and after.

### Deep & Tricky

**DT-221. The same algorithm can be 100× apart depending on allocation order.** *(Measured above)* The in-order `container/list` was 14× faster than the shuffled list: its nodes happened to be allocated next to each other. Benchmarks of pointer-based structures built in a tidy order can wildly overstate their real-world performance, where nodes are allocated at different times and scattered across the heap.

### Pattern

**P-31. Pick data structures by access pattern, then verify by measurement.** *(Engineering practice)*

- *Problem it solves:* choosing structures by Big-O alone, then discovering they are slow in practice, or by habit ("a tree for sorted data") when a sorted slice is faster.
- *How:* write down the operations and their frequencies (reads vs writes, point lookups vs scans, sizes); choose the simplest structure that serves them; benchmark with realistic sizes and allocation patterns.
- *When not to:* for small data, choose the clearest code; performance work belongs where profiles point (Chapter 10).
- *Trade-off:* measurement takes time, but guessing wrong in a hot path costs far more.

### Mastery check

1. **Explain.** Why does an LRU cache need both a map and a doubly linked list? What would each alone cost?
2. **Explain.** Using cache lines, explain the 13× difference between row-major and column-major traversal.
3. **Write.** A benchmark comparing `[]struct{ X, Y float64; Name string; Tags []string }` with two separate `[]float64` slices for computing the average X. Predict the ratio first.

## Chapter 6 Project — A generic data-structures library and a city-grid route finder

**Goal:** build `ds`, a small generic library (ring-buffer queue, priority queue, LRU cache, union-find) with tests and benchmarks, then use it in `grid`, a route finder for a city map with walls and slow roads, comparing BFS (fewest steps) with Dijkstra (lowest cost).

### Map format

```
S.....#...
.####.#.#.
.#..9.9.#.
.#.##.#.#.
...#....#E
```

`#` wall, `.` cost 1 to enter, `1`–`9` slow road costing that much to enter, `S` start, `E` end (cost 1). Moves: up, down, left, right.

### Requirements

1. `ds.Queue[T]`: zero value usable; ring buffer; Pop on empty reports `ok == false`; popped slots zeroed.
2. `ds.PQ[T]` with a `less` function; tested against `slices.Sort` on random input with duplicates (a *differential* test).
3. `ds.LRU[K, V]` with O(1) `Get`/`Put`, eviction of the least recently used, update without eviction.
4. `ds.UnionFind` with path halving and union by size.
5. `grid.Parse` validates the map (rectangular, known characters, exactly one S and E) and stores costs in a flat slice (Unit 2.4).
6. `Grid.BFS` and `Grid.Dijkstra` return paths; `ErrNoPath` when unreachable.
7. `cmd/gridpath` reads a map from stdin and draws both paths.

### Reference solution — `ds/ds.go`

```go
// Package ds provides small generic data structures: a ring-buffer
// queue, a binary-heap priority queue, an LRU cache, and union-find.
package ds

// Queue is a FIFO queue backed by a growable ring buffer.
// The zero value is an empty queue ready to use.
type Queue[T any] struct {
	buf        []T
	head, size int
}

func (q *Queue[T]) Len() int { return q.size }

func (q *Queue[T]) Push(v T) {
	if q.size == len(q.buf) {
		q.grow()
	}
	q.buf[(q.head+q.size)%len(q.buf)] = v
	q.size++
}

// Pop removes and returns the oldest element. ok is false if q is empty.
func (q *Queue[T]) Pop() (v T, ok bool) {
	if q.size == 0 {
		return v, false
	}
	v = q.buf[q.head]
	var zero T
	q.buf[q.head] = zero // do not keep a reference for the GC
	q.head = (q.head + 1) % len(q.buf)
	q.size--
	return v, true
}

func (q *Queue[T]) grow() {
	n := max(4, 2*len(q.buf))
	nb := make([]T, n)
	for i := range q.size {
		nb[i] = q.buf[(q.head+i)%len(q.buf)]
	}
	q.buf, q.head = nb, 0
}

// PQ is a priority queue: Pop returns the element for which less
// reports true against all others. Create it with NewPQ.
type PQ[T any] struct {
	items []T
	less  func(a, b T) bool
}

func NewPQ[T any](less func(a, b T) bool) *PQ[T] { return &PQ[T]{less: less} }

func (p *PQ[T]) Len() int { return len(p.items) }

func (p *PQ[T]) Push(v T) {
	p.items = append(p.items, v)
	p.up(len(p.items) - 1)
}

func (p *PQ[T]) Pop() (v T, ok bool) {
	n := len(p.items)
	if n == 0 {
		return v, false
	}
	v = p.items[0]
	p.items[0] = p.items[n-1]
	var zero T
	p.items[n-1] = zero
	p.items = p.items[:n-1]
	if len(p.items) > 0 {
		p.down(0)
	}
	return v, true
}

func (p *PQ[T]) up(i int) {
	for i > 0 {
		parent := (i - 1) / 2
		if !p.less(p.items[i], p.items[parent]) {
			return
		}
		p.items[i], p.items[parent] = p.items[parent], p.items[i]
		i = parent
	}
}

func (p *PQ[T]) down(i int) {
	n := len(p.items)
	for {
		smallest := i
		l, r := 2*i+1, 2*i+2
		if l < n && p.less(p.items[l], p.items[smallest]) {
			smallest = l
		}
		if r < n && p.less(p.items[r], p.items[smallest]) {
			smallest = r
		}
		if smallest == i {
			return
		}
		p.items[i], p.items[smallest] = p.items[smallest], p.items[i]
		i = smallest
	}
}

// LRU is a fixed-capacity cache that evicts the least recently used key.
// Get and Put are O(1): a map finds entries, a doubly linked list keeps
// them in recency order.
type LRU[K comparable, V any] struct {
	cap        int
	items      map[K]*lruNode[K, V]
	head, tail *lruNode[K, V] // head = most recent
}

type lruNode[K comparable, V any] struct {
	key        K
	val        V
	prev, next *lruNode[K, V]
}

func NewLRU[K comparable, V any](capacity int) *LRU[K, V] {
	if capacity < 1 {
		panic("ds: LRU capacity must be at least 1")
	}
	return &LRU[K, V]{cap: capacity, items: make(map[K]*lruNode[K, V], capacity)}
}

func (c *LRU[K, V]) Len() int { return len(c.items) }

func (c *LRU[K, V]) Get(k K) (v V, ok bool) {
	n, ok := c.items[k]
	if !ok {
		return v, false
	}
	c.moveToFront(n)
	return n.val, true
}

func (c *LRU[K, V]) Put(k K, v V) {
	if n, ok := c.items[k]; ok {
		n.val = v
		c.moveToFront(n)
		return
	}
	if len(c.items) == c.cap {
		old := c.tail
		c.unlink(old)
		delete(c.items, old.key)
	}
	n := &lruNode[K, V]{key: k, val: v}
	c.items[k] = n
	c.pushFront(n)
}

func (c *LRU[K, V]) unlink(n *lruNode[K, V]) {
	if n.prev != nil {
		n.prev.next = n.next
	} else {
		c.head = n.next
	}
	if n.next != nil {
		n.next.prev = n.prev
	} else {
		c.tail = n.prev
	}
	n.prev, n.next = nil, nil
}

func (c *LRU[K, V]) pushFront(n *lruNode[K, V]) {
	n.next = c.head
	if c.head != nil {
		c.head.prev = n
	}
	c.head = n
	if c.tail == nil {
		c.tail = n
	}
}

func (c *LRU[K, V]) moveToFront(n *lruNode[K, V]) {
	if c.head == n {
		return
	}
	c.unlink(n)
	c.pushFront(n)
}

// UnionFind tracks a partition of the integers 0..n-1 into sets.
type UnionFind struct {
	parent, size []int
}

func NewUnionFind(n int) *UnionFind {
	u := &UnionFind{parent: make([]int, n), size: make([]int, n)}
	for i := range n {
		u.parent[i], u.size[i] = i, 1
	}
	return u
}

// Find returns the representative of x's set, compressing the path.
func (u *UnionFind) Find(x int) int {
	for u.parent[x] != x {
		u.parent[x] = u.parent[u.parent[x]] // path halving
		x = u.parent[x]
	}
	return x
}

// Union merges the sets of a and b and reports whether they were separate.
func (u *UnionFind) Union(a, b int) bool {
	ra, rb := u.Find(a), u.Find(b)
	if ra == rb {
		return false
	}
	if u.size[ra] < u.size[rb] {
		ra, rb = rb, ra
	}
	u.parent[rb] = ra
	u.size[ra] += u.size[rb]
	return true
}
```

### Reference solution — `ds/ds_test.go`

```go
package ds

import (
	"math/rand/v2"
	"slices"
	"testing"
)

func TestQueue(t *testing.T) {
	var q Queue[int]
	for i := range 10 {
		q.Push(i)
		if i%3 == 0 {
			q.Pop() // wrap around inside the ring
		}
	}
	var got []int
	for q.Len() > 0 {
		v, _ := q.Pop()
		got = append(got, v)
	}
	if want := []int{4, 5, 6, 7, 8, 9}; !slices.Equal(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
	if _, ok := q.Pop(); ok {
		t.Error("Pop on empty queue reported ok")
	}
}

func TestPQSortsLikeSlicesSort(t *testing.T) {
	r := rand.New(rand.NewPCG(1, 2))
	for trial := range 50 {
		n := r.IntN(200)
		in := make([]int, n)
		pq := NewPQ(func(a, b int) bool { return a < b })
		for i := range in {
			in[i] = r.IntN(50) // duplicates on purpose
			pq.Push(in[i])
		}
		var out []int
		for pq.Len() > 0 {
			v, _ := pq.Pop()
			out = append(out, v)
		}
		slices.Sort(in)
		if !slices.Equal(in, out) {
			t.Fatalf("trial %d: heap order %v, want %v", trial, out, in)
		}
	}
}

func TestLRU(t *testing.T) {
	c := NewLRU[string, int](2)
	c.Put("a", 1)
	c.Put("b", 2)
	c.Get("a")    // a is now most recent
	c.Put("c", 3) // evicts b
	if _, ok := c.Get("b"); ok {
		t.Error("b should have been evicted")
	}
	if v, ok := c.Get("a"); !ok || v != 1 {
		t.Errorf("Get(a) = %v, %v", v, ok)
	}
	c.Put("a", 10) // update, no eviction
	if c.Len() != 2 {
		t.Errorf("Len = %d", c.Len())
	}
	if v, _ := c.Get("a"); v != 10 {
		t.Errorf("updated a = %d", v)
	}
}

func TestUnionFind(t *testing.T) {
	u := NewUnionFind(6)
	u.Union(0, 1)
	u.Union(1, 2)
	u.Union(3, 4)
	if u.Find(0) != u.Find(2) || u.Find(0) == u.Find(3) || u.Union(2, 0) {
		t.Error("wrong partition")
	}
}

func BenchmarkPQ(b *testing.B) {
	r := rand.New(rand.NewPCG(1, 2))
	for b.Loop() {
		pq := NewPQ(func(a, b int) bool { return a < b })
		for range 10_000 {
			pq.Push(r.IntN(1_000_000))
		}
		for pq.Len() > 0 {
			pq.Pop()
		}
	}
}
```

### Reference solution — `grid/grid.go`

```go
// Package grid finds shortest paths on a rectangular city map.
//
// The map is text: '#' is a wall, '.' costs 1 to enter, digits '1'..'9'
// cost that much to enter (slow roads), 'S' is the start and 'E' the end
// (both cost 1). Moves go up, down, left, and right.
package grid

import (
	"errors"
	"fmt"
	"strings"

	"example.com/dsgrid/ds"
)

type Point struct{ R, C int }

type Grid struct {
	rows, cols int
	cost       []int // flat row-major: cost[r*cols+c]; 0 means wall
	Start, End Point
}

var ErrNoPath = errors.New("no path")

// Parse reads a map. Every row must have the same length.
func Parse(text string) (*Grid, error) {
	lines := strings.Fields(text)
	if len(lines) == 0 {
		return nil, errors.New("empty map")
	}
	g := &Grid{rows: len(lines), cols: len(lines[0])}
	g.cost = make([]int, g.rows*g.cols)
	foundS, foundE := false, false
	for r, line := range lines {
		if len(line) != g.cols {
			return nil, fmt.Errorf("row %d has %d cells, want %d", r, len(line), g.cols)
		}
		for c := range len(line) {
			ch := line[c]
			i := r*g.cols + c
			switch {
			case ch == '#':
				g.cost[i] = 0
			case ch == '.':
				g.cost[i] = 1
			case ch >= '1' && ch <= '9':
				g.cost[i] = int(ch - '0')
			case ch == 'S':
				g.cost[i], g.Start, foundS = 1, Point{r, c}, true
			case ch == 'E':
				g.cost[i], g.End, foundE = 1, Point{r, c}, true
			default:
				return nil, fmt.Errorf("row %d col %d: unknown cell %q", r, c, ch)
			}
		}
	}
	if !foundS || !foundE {
		return nil, errors.New("map needs one S and one E")
	}
	return g, nil
}

func (g *Grid) neighbours(p Point, yield func(Point)) {
	for _, d := range [4]Point{{-1, 0}, {1, 0}, {0, -1}, {0, 1}} {
		q := Point{p.R + d.R, p.C + d.C}
		if q.R >= 0 && q.R < g.rows && q.C >= 0 && q.C < g.cols && g.cost[q.R*g.cols+q.C] > 0 {
			yield(q)
		}
	}
}

// BFS returns a path with the fewest steps, ignoring costs.
func (g *Grid) BFS() ([]Point, error) {
	prev := make(map[Point]Point)
	seen := map[Point]bool{g.Start: true}
	var q ds.Queue[Point]
	q.Push(g.Start)
	for q.Len() > 0 {
		p, _ := q.Pop()
		if p == g.End {
			return path(prev, g.Start, g.End), nil
		}
		g.neighbours(p, func(n Point) {
			if !seen[n] {
				seen[n] = true
				prev[n] = p
				q.Push(n)
			}
		})
	}
	return nil, ErrNoPath
}

// Dijkstra returns a cheapest path and its total cost (the cost of every
// cell entered after the start).
func (g *Grid) Dijkstra() ([]Point, int, error) {
	type item struct {
		p    Point
		dist int
	}
	dist := map[Point]int{g.Start: 0}
	prev := make(map[Point]Point)
	pq := ds.NewPQ(func(a, b item) bool { return a.dist < b.dist })
	pq.Push(item{g.Start, 0})
	for pq.Len() > 0 {
		it, _ := pq.Pop()
		if it.dist > dist[it.p] {
			continue // stale entry: a shorter route was found after it was pushed
		}
		if it.p == g.End {
			return path(prev, g.Start, g.End), it.dist, nil
		}
		g.neighbours(it.p, func(n Point) {
			nd := it.dist + g.cost[n.R*g.cols+n.C]
			if old, ok := dist[n]; !ok || nd < old {
				dist[n] = nd
				prev[n] = it.p
				pq.Push(item{n, nd})
			}
		})
	}
	return nil, 0, ErrNoPath
}

func path(prev map[Point]Point, start, end Point) []Point {
	var out []Point
	for p := end; p != start; p = prev[p] {
		out = append(out, p)
	}
	out = append(out, start)
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}

// Draw returns the map with the path marked by '*'.
func (g *Grid) Draw(text string, p []Point) string {
	rows := strings.Fields(text)
	b := make([][]byte, len(rows))
	for i, r := range rows {
		b[i] = []byte(r)
	}
	for _, pt := range p {
		if pt != g.Start && pt != g.End {
			b[pt.R][pt.C] = '*'
		}
	}
	var sb strings.Builder
	for _, r := range b {
		sb.Write(r)
		sb.WriteByte('\n')
	}
	return sb.String()
}
```

### Reference solution — `grid/grid_test.go`

```go
package grid

import (
	"errors"
	"testing"
)

const city = `
S.....#...
.####.#.#.
.#..9.9.#.
.#.##.#.#.
...#....#E
`

func TestBFSAndDijkstraDiffer(t *testing.T) {
	g, err := Parse(city)
	if err != nil {
		t.Fatal(err)
	}
	bp, err := g.BFS()
	if err != nil {
		t.Fatal(err)
	}
	dp, cost, err := g.Dijkstra()
	if err != nil {
		t.Fatal(err)
	}
	if steps := len(bp) - 1; steps != 17 {
		t.Errorf("BFS steps = %d, want 17", steps)
	}
	if steps := len(dp) - 1; steps != 21 || cost != 21 {
		t.Errorf("Dijkstra steps = %d cost = %d, want 21 and 21", steps, cost)
	}
	// The fewest-steps path goes through a '9' cell, so it costs more.
	if bc := pathCost(g, bp); bc != 25 {
		t.Errorf("BFS path cost = %d, want 25", bc)
	}
}

func pathCost(g *Grid, p []Point) int {
	sum := 0
	for _, pt := range p[1:] {
		sum += g.cost[pt.R*g.cols+pt.C]
	}
	return sum
}

func TestNoPath(t *testing.T) {
	g, err := Parse("S#.\n##E")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := g.BFS(); !errors.Is(err, ErrNoPath) {
		t.Errorf("BFS err = %v", err)
	}
	if _, _, err := g.Dijkstra(); !errors.Is(err, ErrNoPath) {
		t.Errorf("Dijkstra err = %v", err)
	}
}

func TestParseErrors(t *testing.T) {
	for _, bad := range []string{"", "S..\n..", "S.x\n..E", "...\n..E"} {
		if _, err := Parse(bad); err == nil {
			t.Errorf("Parse(%q) succeeded", bad)
		}
	}
}
```

### Reference solution — `cmd/gridpath/main.go`

```go
// Command gridpath reads a city map on stdin and prints the fewest-steps
// path (BFS) and the cheapest path (Dijkstra).
package main

import (
	"fmt"
	"io"
	"os"

	"example.com/dsgrid/grid"
)

func main() {
	data, err := io.ReadAll(io.LimitReader(os.Stdin, 10<<20))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	g, err := grid.Parse(string(data))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	bp, err := g.BFS()
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	dp, cost, _ := g.Dijkstra()
	fmt.Printf("fewest steps (BFS): %d steps\n%s\n", len(bp)-1, g.Draw(string(data), bp))
	fmt.Printf("cheapest (Dijkstra): %d steps, cost %d\n%s", len(dp)-1, cost, g.Draw(string(data), dp))
}
```

A real run on the sample map:

```
fewest steps (BFS): 17 steps
S*****#***
.####*#*#*
.#..9***#*
.#.##.#.#*
...#....#E

cheapest (Dijkstra): 21 steps, cost 21
S*****#***
.####*#*#*
.#..9*9*#*
.#.##*#*#*
...#.***#E
```

BFS takes the short route straight through a `9` (17 steps, but cost 25); Dijkstra walks 4 more steps to avoid both 9s and pays only 21. This is the difference between "shortest" and "fastest" route that every navigation app must get right. (A note on honesty: when the test for this project was first written, its expected numbers were *guessed* — and wrong. The real run corrected them. Never fill expected values from your head.)

### Review checklist

- Does every structure handle the empty case (Pop on empty, LRU of capacity 1, union of an element with itself)?
- Is the PQ tested against a reference implementation (differential testing) rather than a few hand-picked cases?
- Are popped slots zeroed in `Queue` and `PQ` (DT-212)?
- In `Dijkstra`, is the stale-entry check present? (Remove it and measure how many extra nodes are expanded on a 1000×1000 map.)
- Would the grid code survive a 10,000×10,000 map? The `map[Point]...` structures are the bottleneck: replace them with flat slices indexed by `r*cols+c` and benchmark (Unit 6.13).

### Extensions

1. Replace the maps in `BFS` and `Dijkstra` with flat `[]int32` slices; benchmark on a generated 2000×2000 map.
2. Add diagonal moves with cost × √2 (use float costs) — and think about how to keep costs exact (P-8).
3. Implement A* with the Manhattan distance as the heuristic (preview of Unit 13.6) and count expanded nodes vs Dijkstra.

## Answers to the Chapter 6 prediction questions

**6.1 Q2.** (a) O(n²) (b) O(n) expected (c) O(n log n) (d) O(total length) (e) O(b·l) for b books and l loans (DT-186).

**6.5 Q2.** `(1, true)` — the first 3 (`BinarySearch` returns the lowest index of equal elements); `(4, false)` — where 4 would be inserted.

**6.8 Q1.** Parent (9−1)/2 = 4; children 2·9+1 = 19 and 20.
