# Chapter 2 — Composite Data & Memory

*Goal: master arrays, slices, strings, maps, structs, and pointers — the places where most real Go bugs live.*

Chapter 1 worked with single values: one int, one float, one string. Real programs work with *collections* and *records*: a list of orders, a map from user ID to session, a struct describing a shipment. Go gives you a small set of composite types, and each one has a precise memory story. Once you can draw that story (what is copied, what is shared, where the bytes are), the "mysterious" bugs — an `append` that changes another slice, a map that panics, a string that `len` says is 18 characters long — stop being mysterious.

**What you will be able to do after this chapter**

- Draw the slice header and backing array for any slicing or `append` operation and predict aliasing.
- Process text correctly in any language: bytes vs runes vs what a human calls a character.
- Use maps idiomatically (comma-ok, sets, deterministic output) and know their limits.
- Design structs with sensible memory layout, and choose between value and pointer semantics with a reason.

**The central question of this chapter:** *"Is this a copy, or is it shared?"* Every composite type answers it differently:

| Type | Assignment / passing copies… | So the original data is… |
| --- | --- | --- |
| Array `[N]T` | all N elements | never shared |
| Struct | all fields (shallowly) | never shared, except through fields that are themselves pointers, slices, or maps |
| Slice `[]T` | a 3-word header (pointer, len, cap) | **shared** (the backing array) |
| String | a 2-word header (pointer, len) | shared, but immutable, so sharing is safe |
| Map | one pointer to the runtime's map | **shared** |
| Pointer `*T` | the address | **shared** |

Keep this table in mind; the rest of the chapter explains each row.

## Topic 2A — Arrays and slices

@@UNIT21@@

## Unit 2.2 — Slices I: the slice header

**One-line summary:** A slice is a small descriptor — a pointer to an element of an array, a length, and a capacity — that gives you a *window* onto that array. Copying a slice copies the descriptor, not the elements, so two slices can look at the same memory.

**Mental model — a window onto a long shelf.** Picture a long shelf of numbered jars (the **backing array**). A slice is a cardboard frame you hold up in front of the shelf. The frame records three things: which jar it starts at (the **pointer**), how many jars you can see through it (the **length**), and how many jars there are from its start to the end of the shelf (the **capacity**). Two people can hold two frames over overlapping parts of the same shelf: if one of them changes a jar, the other sees it.

```
backing array:  [ 10 | 20 | 30 | 40 | 50 ]
index:             0    1    2    3    4

s := arr[1:3]   ptr ──────┐
                len = 2   ▼
                cap = 4  [ 20 | 30 ] 40   50     (40 and 50 are "beyond len, within cap")
```

### The slice header

In the current implementation a slice value is exactly three machine words:

| Field | Meaning | On 64-bit |
| --- | --- | --- |
| `ptr` | address of the first element the slice can see | 8 bytes |
| `len` | how many elements you may index: `s[0]` to `s[len-1]` | 8 bytes |
| `cap` | how many elements exist from `ptr` to the end of the backing array | 8 bytes |

`unsafe.Sizeof(s)` is 24 on every 64-bit platform, whether the slice holds 3 elements or 3 million. This is why passing a slice to a function is cheap: only 24 bytes are copied.

### Making slices

```go
a := []int{10, 20, 30}        // slice literal: Go creates a [3]int and a slice over it
b := make([]int, 3)           // len 3, cap 3, all zero: [0 0 0]
c := make([]int, 0, 100)      // len 0, cap 100: room for 100 appends without moving
var d []int                   // nil slice: ptr = nil, len 0, cap 0
arr := [5]int{10, 20, 30, 40, 50}
e := arr[1:3]                 // a slice over an existing array: [20 30]
```

Note the difference from arrays: `[3]int{...}` (length inside the brackets) is an array; `[]int{...}` (empty brackets) is a slice.

### Slicing: `s[lo:hi]`

`s[lo:hi]` makes a new header that starts at element `lo` and stops *before* `hi`:

- new `len` = `hi − lo`
- new `cap` = old `cap − lo`
- new `ptr` = address of element `lo`

Defaults: `s[:hi]` means `s[0:hi]`; `s[lo:]` means `s[lo:len(s)]`; `s[:]` is the whole slice.

| Starting from `arr := [5]int{10, 20, 30, 40, 50}` | Elements | len | cap |
| --- | --- | --- | --- |
| `arr[:]` | 10 20 30 40 50 | 5 | 5 |
| `arr[1:3]` | 20 30 | 2 | 4 |
| `arr[2:]` | 30 40 50 | 3 | 3 |
| `arr[:0]` | (none) | 0 | 5 |
| `arr[4:5]` | 50 | 1 | 1 |

**The bounds rule:** `0 <= lo <= hi <= cap(s)`. Note: `hi` may go up to the *capacity*, not just the length. So you can **re-slice upwards** into the hidden part:

```go
s := make([]int, 2, 5) // [0 0], cap 5
s = s[:4]              // allowed: [0 0 0 0] — reveals elements that were beyond len
// s[:6] would panic: slice bounds out of range [:6] with capacity 5
```

Indexing (`s[i]`) is checked against `len`; slicing (`s[lo:hi]`) is checked against `cap`. Both panic at run time when out of range.

### Aliasing: two slices, one array

Because slicing never copies elements, slices made from the same array share them:

```go
arr := [5]int{10, 20, 30, 40, 50}
x := arr[0:3] // [10 20 30]
y := arr[2:5] // [30 40 50]
y[0] = 99
fmt.Println(arr, x, y) // [10 20 99 40 50] [10 20 99] [99 40 50]
```

One write through `y` changed what `arr` and `x` see, because `x[2]`, `y[0]`, and `arr[2]` are the same memory. This is called **aliasing**. It is a feature (cheap views, no copying) and a classic source of bugs (an unexpected change "from nowhere").

### Slices are not comparable

`s1 == s2` is a compile error for slices; the only allowed comparison is with `nil`. (Should `==` compare headers or elements? Either answer surprises someone, so Go allows neither.) Compare elements with `slices.Equal(s1, s2)` (Unit 2.4).

### Deep & Tricky

**DT-101. A slice expression on an array makes the array escape — or not.** *(Implementation detail)* `arr[:]` creates a pointer into `arr`. If that slice is returned or stored somewhere long-lived, `arr` must outlive the function, so escape analysis moves it to the heap (Unit 0.6). A slice used only locally lets the array stay on the stack. `-gcflags=-m` shows the decision.

**DT-102. `len` and `cap` of a nil slice are 0, and you can range over it, append to it, and slice it with `[:0]`.** *(Guarantee)* A nil slice behaves exactly like an empty slice for reading. You almost never need to check `s == nil` before using a slice; check `len(s) == 0` instead, which covers both.

**DT-103. Re-slicing up to capacity can expose "deleted" data.** *(Guarantee + security consequence)* If a function shortens a slice with `s = s[:n]` to "remove" secret bytes, the bytes are still in the backing array, and anyone holding the slice can bring them back with `s[:cap(s)]`. To really erase data, overwrite it (`clear(s[n:])`, Unit 2.4) before shortening, or copy the part you keep into a fresh slice.

**DT-104. Indexing is checked against `len`, slicing against `cap`.** *(Guarantee)* `s[3]` with `len(s) == 3` panics even if `cap(s)` is 10; `s[:10]` with the same slice is fine. The error messages say which limit was hit: `index out of range [3] with length 3` vs `slice bounds out of range [:11] with capacity 10`.

### Common mistakes

- Thinking `b := a` for slices copies the elements. It copies the header; both share the array.
- Forgetting that a sub-slice keeps the *whole* backing array alive (see Unit 2.4, memory leaks).
- Confusing `[3]int{}` (array) with `[]int{}` (slice).
- Comparing slices with `==`.

### Mastery check

1. **Explain.** What three things are in a slice header? Why does passing a 1,000,000-element slice to a function cost the same as passing a 3-element slice?
2. **Predict.** With `arr := [6]int{0, 1, 2, 3, 4, 5}` and `s := arr[2:4]`: (a) `len(s), cap(s)` (b) `s[:4]` (c) `s[2]` (d) `s[1:5]` (e) after `s[0] = 9`, what is `arr`?
3. **Write.** Draw (on paper) the shelf-and-frames picture for `x := arr[1:4]; y := x[1:2]; y = y[:3]`, then write the code and print `len`, `cap`, and contents of `x` and `y` to check your drawing.

## Unit 2.3 — Slices II: append, copy, and growth

**One-line summary:** `append` adds elements to a slice. If the backing array has room (len < cap), it writes into that array and the new slice *shares* it with the old one; if not, it allocates a bigger array, copies everything, and the new slice no longer shares anything with the old one. Always use the result of `append`.

**Mental model — the shelf again.** Appending to a slice means "put a jar just after the last visible one, and widen my frame by one". If there is an empty spot on the shelf right there (capacity), the jar goes on the *same shelf* — and anyone else whose frame covers that spot sees it. If the shelf is full, Go fetches a *new, longer shelf*, moves all the jars across, puts the new jar at the end, and gives you a frame on the new shelf. Your old frame (and everyone else's) still looks at the old shelf.

### The rule of `append`

```go
s = append(s, x)            // one element
s = append(s, x, y, z)      // several
s = append(s, other...)     // all elements of another slice
b = append(b, "text"...)    // special case: append a string's bytes to a []byte
```

`append` returns a new slice header. You must store it, usually back into the same variable. `append(s, x)` on its own line is a compile error (`append(s, x) (value of type []int) is not used`), because forgetting the result is always a bug.

What happens inside:

1. If `len(s) + number of new elements <= cap(s)`: write the new elements into the existing backing array right after `len(s)`, and return a header with the larger `len` and the **same** `ptr` and `cap`.
2. Otherwise: allocate a new, larger array; copy the old elements; write the new ones; return a header pointing to the **new** array.

### Growth: how big is the new array?

The exact policy is an implementation detail, but you should know its shape. Appending one element at a time to an empty slice on Go 1.24 gives these capacities:

```
1 2 4 8 16 32 64 128 256 512 848 1280 1792 2560 ...
```

Small slices double; from 256 elements on, growth smoothly decreases towards about 1.25× per step; and the final size is rounded up to one of the memory allocator's **size classes**, which is why you see 848 rather than 640. The doubling is what makes `append` fast *on average*: if each growth doubles the capacity, the total copying over n appends is at most about 2n element copies, so each append costs O(1) **amortized** (Unit 6.1 proves it).

**Pre-size when you know the size:** `make([]T, 0, n)` gives capacity n up front, so n appends never reallocate. This is one of the simplest and most effective Go performance habits.

```go
names := make([]string, 0, len(users))
for _, u := range users {
	names = append(names, u.Name)
}
```

### The aliasing trap

Case 1 — capacity available, so the append writes into *shared* memory:

```go
a := []int{1, 2, 3, 4, 5}
b := a[1:3]          // [2 3], len 2, cap 4
b = append(b, 99)    // room available: writes into a[3]!
fmt.Println(a)       // [1 2 3 99 5]   <- a changed
fmt.Println(b)       // [2 3 99]
```

Case 2 — no capacity, so the append moves to a new array and the link breaks:

```go
a := []int{1, 2, 3}  // len 3, cap 3
b := append(a, 4)    // must grow: new array
b[0] = 100
fmt.Println(a, b)    // [1 2 3] [100 2 3 4]  <- a unchanged
```

The same line of code (`append`) shares memory in one case and not in the other, depending on a number you usually cannot see. That is the trap. The rule that keeps you safe: **after `b := append(a, ...)`, treat `a` as possibly sharing memory with `b`, and do not use both for writing.** If you need independent slices, copy explicitly.

### The full slice expression: `s[lo:hi:max]`

A third index limits the capacity of the new slice: `cap = max − lo`. With capacity equal to length, the next `append` *must* allocate, so it cannot overwrite the original array:

```go
a := []int{1, 2, 3, 4, 5}
c := a[1:3:3]        // [2 3], len 2, cap 2
c = append(c, 77)    // no room: new array
fmt.Println(a, c)    // [1 2 3 4 5] [2 3 77]   <- a is safe
```

Use it when you hand out a sub-slice and do not want the receiver's appends to scribble over your data.

### `copy`

```go
n := copy(dst, src) // copies min(len(dst), len(src)) elements, returns that number
```

- `copy` never grows `dst`; it copies only as many elements as fit in `dst`'s **length** (not capacity). `copy(make([]int, 0, 10), src)` copies nothing.
- It works correctly when `dst` and `src` overlap (like `memmove` in C).
- `copy(b, "string")` copies a string's bytes into a `[]byte`.

The idiomatic ways to make an independent copy:

```go
c1 := make([]int, len(s))
copy(c1, s)

c2 := append([]int(nil), s...) // older idiom
c3 := slices.Clone(s)           // clearest (Go 1.21+)
```

### nil slice vs empty slice

```go
var a []int     // nil:   a == nil is true,  len 0, cap 0
b := []int{}    // empty: b == nil is false, len 0, cap 0
```

For almost everything — `len`, `range`, `append`, printing (`[]` both) — they behave the same. They differ when the difference is *observed*: `encoding/json` encodes a nil slice as `null` and an empty slice as `[]` (Chapter 5), and `reflect.DeepEqual(a, b)` is false. Idiomatic Go: declare with `var s []T` (nil) and let `append` allocate; check emptiness with `len(s) == 0`.

### Passing slices to functions

Go is always pass-by-value (DT-75): the function receives a *copy of the header*. So:

```go
func setFirst(s []int)  { s[0] = 100 }       // visible to the caller: same backing array
func addOne(s []int)    { s = append(s, 1) } // NOT visible: the caller's header still has the old len
func addOneOK(s []int) []int { return append(s, 1) }

nums := make([]int, 3, 10)
setFirst(nums)            // nums[0] == 100
addOne(nums)              // nums is still len 3 (though nums[:4][3] is now 1 — the write happened!)
nums = addOneOK(nums)     // len 4
```

The `addOne` case is subtle: the append *did* write into the shared array (cap was 10), but the caller's header still says `len 3`, so the caller cannot see it. Return the new slice, exactly as `append` itself does. This is why the standard library's functions that grow slices (`append`, `strconv.AppendInt`, `slices.Insert`) all *return* the slice.

### Deep & Tricky

**DT-105. Growth rounds up to size classes.** *(Implementation detail; changes between versions)* After computing the target capacity, the runtime rounds the allocation up to the nearest malloc size class so no space is wasted. For `[]int` that turns 640 elements (5120 bytes) into 848 (6784 bytes) on Go 1.24. So `cap` after a growth is not a number you can rely on — only `cap >= len` is guaranteed.

**DT-106. `append` to a nil slice works; there is no need to `make` first.** *(Guarantee)* `var s []int; s = append(s, 1)` allocates the first array. Pre-sizing with `make` is an optimisation, not a requirement.

**DT-107. A function that appends to a shared slice can corrupt the caller's other data.** *(Guarantee; classic production bug)* A function receives `s[:2]` of a 5-element slice and appends. Because cap is 5, it overwrites elements 2, 3, … of the caller's slice — data the function was never meant to see. Defensive code that hands out sub-slices uses the three-index form `s[:2:2]`.

**DT-108. `copy` copies by length, not capacity.** *(Guarantee)* `dst := make([]int, 0, len(src)); copy(dst, src)` copies zero elements and silently leaves `dst` empty. Use `make([]int, len(src))`.

### Pattern

**P-17. Pre-size slices with `make([]T, 0, n)` when n is known or estimable.** *(Performance idiom)*

- *Problem it solves:* repeated growth in a loop reallocates and copies many times and creates garbage for the GC.
- *How:* `out := make([]T, 0, len(in))`, then `append`. Use `make([]T, n)` plus `out[i] = ...` when you fill every index.
- *When not to:* when n is unknown and could be huge (pre-allocating the worst case wastes memory), or when the slice is tiny and short-lived. Measure first in hot paths (Chapter 10).
- *Trade-off:* a little more code for fewer allocations; over-estimating wastes memory.

**P-18. Functions that may grow a slice return it.** *(Go convention)* `func appendDigits(dst []byte, n int) []byte` — mirror `append`'s shape: accept the slice, return the possibly-new slice, let the caller reassign. Never rely on the caller "seeing" an append.

### Common mistakes

- `append(s, x)` without assigning (compile error) or assigning to a different variable and then using both for writes (aliasing bug).
- Expecting `copy` to grow the destination.
- Appending to a function parameter and expecting the caller to see the new length.
- Assuming a specific capacity after growth.

### Mastery check

1. **Explain.** Why can the same `append` line sometimes change another slice and sometimes not? What decides it?
2. **Predict.**
   ```go
   a := make([]int, 3, 4)
   b := append(a, 1)
   c := append(a, 2)
   fmt.Println(a, b, c)
   ```
3. **Predict.** `s := []int{1, 2, 3}; t := s[:1]; t = append(t, 9); fmt.Println(s)` — then the same with `t := s[:1:1]`.
4. **Write.** A function `appendUnique(s []string, v string) []string` that appends `v` only if it is not already present. Show with `len`/`cap` printing that your caller code reassigns correctly.
5. **Write.** Append 10,000 elements to a nil slice and print every new capacity. Then do it again with `make([]int, 0, 10_000)` and count the allocations with `testing.AllocsPerRun` (preview of Chapter 4).

## Unit 2.4 — Slices III: working with slices

**One-line summary:** Real code needs 2D slices, insert and delete, filtering, sorting, and searching. The `slices` package (Go 1.21+) and the `clear` built-in cover most of it; knowing what they do to the backing array keeps you out of memory leaks.

### 2D slices

A slice of slices: each row is its own slice header, possibly with its own length.

```go
grid := make([][]int, rows)
for i := range grid {
	grid[i] = make([]int, cols)
}
grid[1][2] = 5
```

Each row is a separate allocation and rows can be scattered in memory. For a big, fixed-shape grid, one flat slice with index arithmetic is faster (one allocation, sequential memory — Unit 0.5):

```go
cells := make([]int, rows*cols)
at := func(r, c int) *int { return &cells[r*cols+c] }
*at(1, 2) = 5
```

Compare with arrays: `[3][3]int` is one solid block of 9 ints, copied as a whole; `[][]int` is a header pointing to headers pointing to rows.

### The `slices` package

| Task | Function |
| --- | --- |
| Sort in place | `slices.Sort(s)`; custom order: `slices.SortFunc(s, func(a, b T) int {...})`; stable: `slices.SortStableFunc` |
| Search a sorted slice | `i, found := slices.BinarySearch(s, x)` |
| Linear search | `slices.Contains(s, x)`, `slices.Index(s, x)`, `slices.IndexFunc(s, pred)` |
| Compare | `slices.Equal(a, b)`, `slices.Compare(a, b)` |
| Min / max | `slices.Min(s)`, `slices.Max(s)` (panic on an empty slice) |
| Insert / delete | `s = slices.Insert(s, i, v...)`, `s = slices.Delete(s, i, j)`, `s = slices.DeleteFunc(s, pred)` |
| Copy / grow / combine | `slices.Clone(s)`, `s = slices.Grow(s, n)`, `slices.Concat(a, b, c)` |
| Other | `slices.Reverse(s)`, `s = slices.Compact(s)` (remove adjacent duplicates), `slices.Chunk(s, n)` |

Comparison functions return an `int`: negative if `a` sorts before `b`, zero if equal, positive if after. `cmp.Compare(a, b)` produces exactly that for ordered types:

```go
slices.SortFunc(people, func(a, b Person) int {
	if c := cmp.Compare(a.Age, b.Age); c != 0 {
		return c
	}
	return strings.Compare(a.Name, b.Name) // tie-break: name
})
```

### `clear`

`clear(s)` (Go 1.21+) sets every element of `s[:len(s)]` to its zero value; length and capacity do not change. (On a map, `clear` removes all entries — Unit 2.8.)

### Insert and delete by hand (to understand what the package does)

```go
// delete element i, keep order
s = append(s[:i], s[i+1:]...)

// delete element i, order does not matter (O(1))
s[i] = s[len(s)-1]
s = s[:len(s)-1]

// insert v at i
s = append(s, zero)        // grow by one
copy(s[i+1:], s[i:])       // shift right
s[i] = v
```

The first form moves elements left inside the *same* backing array, so the last slot of the old slice still holds a (now duplicated) value beyond the new length. `slices.Delete` (since Go 1.22) clears those vacated slots to the zero value:

```go
x := []int{1, 2, 3, 4, 5}
x = slices.Delete(x, 1, 3)
fmt.Println(x, x[:5]) // [1 4 5] [1 4 5 0 0]
```

### Filtering in place

```go
// keep only even numbers, reusing the same backing array: no allocation
out := s[:0]
for _, v := range s {
	if v%2 == 0 {
		out = append(out, v)
	}
}
clear(s[len(out):]) // optional: drop references in the leftover tail (important for pointers)
s = out
```

Or simply `s = slices.DeleteFunc(s, func(v int) bool { return v%2 != 0 })`.

### Memory leaks through sub-slices

A slice keeps its **entire** backing array alive, even if it only shows one element:

```go
func firstLine(data []byte) []byte {   // data is a 50 MB file
	i := bytes.IndexByte(data, '\n')
	return data[:i]                     // 20 bytes visible, 50 MB kept alive
}
```

As long as the returned slice is used, the garbage collector cannot free the 50 MB, because the GC sees a live pointer into that array (Unit 0.6). Fix: copy what you keep: `return bytes.Clone(data[:i])` (or `slices.Clone`).

The same problem in a subtler form: a slice of *pointers* shortened with `s = s[:n]` still holds the pointers in `s[n:cap]`, so the objects they point to cannot be collected. `clear(s[n:])` before shortening fixes it — which is exactly what `slices.Delete` does for you.

### `range` over slices

```go
for i, v := range s { ... } // v is a COPY of s[i]
```

- The range expression is evaluated **once**; the number of iterations is fixed by `len(s)` at the start. Appending inside the loop does not add iterations.
- `v` is a copy. Modifying `v` changes nothing; write `s[i] = ...`. For a slice of large structs, `for i := range s { p := &s[i]; ... }` avoids copying each element and lets you modify in place.
- Unlike an array (DT-98), ranging over a slice does *not* copy the elements first: a change to `s[2]` made during iteration *is* seen when the loop reaches index 2 (the header was copied, not the array).

### Deep & Tricky

**DT-109. `slices.Delete` and friends zero the tail (Go 1.22+).** *(Library behaviour, version-dependent)* `Delete`, `DeleteFunc`, `Compact`, `CompactFunc`, and `Replace` clear the elements between the new and old length. Before Go 1.22 they did not, and the old tail kept pointers alive. If you rely on the old values still being there (you should not), your code changed behaviour.

**DT-110. `range` over a slice sees writes; over an array it does not.** *(Guarantee)* For `sl := []int{1, 2, 3}`, setting `sl[2] = 100` during the first iteration makes the third iteration print 100. For `arr := [3]int{1, 2, 3}` it prints 3, because ranging an array copies the array (DT-98). Same code, different collection type, different output.

**DT-111. `slices.Sort` is not stable; `slices.SortStableFunc` is.** *(Guarantee)* "Stable" means equal elements keep their original order. `slices.Sort` uses pattern-defeating quicksort (pdqsort), which may reorder equals. If output order of ties matters (and in user-visible output it usually does), either use a stable sort or add a tie-breaker to the comparison so no two elements compare equal.

### Pattern

**P-19. Copy out small pieces of large buffers.** *(Memory practice)* When you keep a small part of a large slice or string (a header line of a file, one field of a big JSON message) beyond the current function, clone it (`bytes.Clone`, `slices.Clone`, `strings.Clone`). *Trade-off:* one small allocation instead of pinning a large one. *When not to:* when the large buffer lives as long as the piece anyway.

### Common mistakes

- Holding a tiny sub-slice of a huge buffer in a long-lived cache.
- Hand-written delete that leaves stale pointers in the tail.
- Calling `slices.Max` on an empty slice (panics) without a length check.
- Sorting user-visible output with an unstable sort and no tie-breaker, so the order changes between runs.

### Mastery check

1. **Explain.** Why can returning `data[:20]` from a function keep 50 MB of memory alive? How do you fix it?
2. **Predict.** `s := []int{1, 2, 3, 4}; for i, v := range s { if i == 0 { s = append(s, 5); s[3] = 40 }; fmt.Print(v, " ") }` — and what is `s` after the loop? (Careful: does the append allocate?)
3. **Write.** `removeAt(s []string, i int) []string` that preserves order, plus a version that does not; benchmark mentally — which is O(1)?
4. **Write.** Sort a slice of `struct{ Name string; Score int }` by score descending, then by name ascending, and print it. Use `slices.SortFunc` and `cmp.Compare`.

## Topic 2B — Strings and text

## Unit 2.5 — Strings, bytes, and runes

**One-line summary:** A Go string is an immutable sequence of **bytes**, conventionally holding UTF-8 text. `len` counts bytes, indexing gives a byte, and `range` decodes **runes** (Unicode code points). What a human calls "one character" can be one byte, several bytes, or even several runes.

**Mental model — beads on a thread.** The string is a thread of bytes. In English text each letter is one bead. In Hindi, Chinese, or emoji, one letter may be 2, 3, or 4 beads tied together. `len` counts beads. `s[i]` picks one bead (possibly half of a letter). `range` walks letter-sized groups of beads (runes).

### Strings are immutable byte sequences

```go
s := "hello"
fmt.Println(len(s), s[0]) // 5 104   (s[0] is the byte 'h' = 104)
// s[0] = 'H'             // compile error: cannot assign to s[0] (neither addressable nor a map index expression)
```

- A string value is a 2-word header: a pointer to the bytes and a length (16 bytes on 64-bit). Assigning a string copies the header, never the bytes.
- Because the bytes can never change, sharing them is always safe. `s[2:4]` creates a new header pointing into the same bytes — no copy.
- "Changing" a string always means building a new one.

### UTF-8 in five minutes

**Unicode** gives every character a number called a **code point**, written `U+` and hex: `A` is U+0041, `é` is U+00E9, `न` is U+0928, `€` is U+20AC, `😀` is U+1F600. **UTF-8** is the encoding that turns code points into bytes:

| Code point range | Bytes | Examples |
| --- | --- | --- |
| U+0000 – U+007F | 1 | ASCII: `A`, `7`, `{` |
| U+0080 – U+07FF | 2 | `é`, `ñ`, Greek, Cyrillic, Arabic |
| U+0800 – U+FFFF | 3 | `न` (Devanagari), Chinese, `€` |
| U+10000 – U+10FFFF | 4 | emoji, rare scripts |

Design points worth knowing: ASCII text is already valid UTF-8 (backwards compatible); the first byte tells you how many bytes follow; continuation bytes always start with `10` in binary, so a decoder can resynchronise in the middle of a stream. Go source files are UTF-8, and string literals are UTF-8.

### `len`, indexing, and `range`

```go
s := "héllo"
fmt.Println(len(s))        // 6, not 5: 'é' takes 2 bytes
fmt.Println(s[1])          // 195: the FIRST byte of 'é' (0xC3)
for i, r := range s {
	fmt.Print(i, ":", string(r), " ")
}
// 0:h 1:é 3:l 4:l 5:o    <- index jumps from 1 to 3
```

- `range` over a string decodes one rune per iteration; `i` is the **byte** offset where the rune starts.
- A **rune** is an `int32` holding a code point. `'é'` is a rune literal (value 233).
- Invalid UTF-8 bytes decode as U+FFFD (the replacement character, `�`), one byte at a time, and the loop continues.

Counting characters:

```go
utf8.RuneCountInString("नमस्ते") // 6 runes
len("नमस्ते")                    // 18 bytes
```

But a person reading नमस्ते sees about 3 or 4 "letters". Devanagari combines a consonant with vowel signs and the *virama* (्), each a separate rune. Likewise `é` can be one rune (U+00E9) or two (`e` + U+0301 combining acute accent) — they look identical and compare **unequal**. What a person perceives as one character is a **grapheme cluster**, and Go's standard library does not segment graphemes (the `golang.org/x/text` module and third-party packages do). For most programs, runes are the right unit; for cursor movement or "truncate to 10 characters" in a UI, graphemes are.

### Converting between strings, bytes, and runes

| Conversion | Result | Copies? |
| --- | --- | --- |
| `[]byte(s)` | the bytes, mutable | yes |
| `string(b)` | a string from bytes | yes |
| `[]rune(s)` | one element per code point | yes |
| `string(r)` for a rune `r` | the UTF-8 encoding of that one rune | yes |
| `string(65)` with an int | `"A"` — **not** `"65"`; `go vet` warns | — |
| `strconv.Itoa(65)` | `"65"` | — |

The copies are necessary: a string is immutable and a `[]byte` is mutable, so they cannot share memory safely. (The compiler skips the copy in a few safe cases — DT-114.)

### Printing text: `%c`, `%q`, `%U`, `% x`

```go
r := 'न'
fmt.Printf("%c %q %U %d\n", r, r, r, r) // न 'न' U+0928 2344
s := "héllo"
fmt.Printf("%q\n", s)       // "héllo"
fmt.Printf("%+q\n", s)      // "h\u00e9llo"   (ASCII-only)
fmt.Printf("% x\n", s)      // 68 c3 a9 6c 6c 6f
```

`%q` is the best way to print a string while debugging: invisible characters, trailing spaces, `\r`, and `\t` become visible.

### Raw string literals

Backquotes make a **raw string**: no escape sequences, may span lines.

```go
path := `C:\new\table`      // backslashes are literal
query := `SELECT id
FROM users`
```

Useful for regular expressions, file paths, SQL, and JSON snippets in tests. A raw string cannot contain a backquote.

### Deep & Tricky

**DT-112. Strings may contain any bytes, not only valid UTF-8.** *(Guarantee)* `"\xff"` is a legal one-byte string. Only *literals* in source code are UTF-8 by convention; data from files and networks may not be. Check with `utf8.ValidString` at the edge (P-4) when it matters.

**DT-113. `string(i)` for an integer `i` is a rune conversion.** *(Guarantee + vet check)* `string(rune(65))` is `"A"`. Writing `string(65)` with an int is allowed by the spec but almost always a bug (the author wanted `"65"`), so `go vet` reports "conversion from int to string yields a string of one rune". Use `strconv.Itoa` for decimal text.

**DT-114. The compiler avoids some `[]byte` ↔ `string` copies.** *(Implementation detail)* `m[string(b)]` for a map lookup, `string(b) == "x"` comparisons, `for i, c := range []byte(s)`, and `s + string(b)` concatenations do not allocate a separate copy of `b` in current compilers, because the temporary string cannot escape. Do not contort code to avoid conversions until a profile says so.

**DT-115. Comparing strings is byte-wise, so "é" may not equal "é".** *(Guarantee + Unicode fact)* Precomposed U+00E9 and decomposed `e` + U+0301 render identically, but their bytes differ, so `==` is false and they sort differently. Normalise to a standard form (NFC) with `golang.org/x/text/unicode/norm` before comparing user-entered text.

### Common mistakes

- Using `len(s)` as "number of characters" for non-ASCII text.
- Indexing `s[i]` and treating the result as a character.
- Slicing a string at a byte offset that falls in the middle of a rune (`"héllo"[:2]` gives `"h\xc3"`, broken text).
- `string(n)` to format a number.
- Assuming one rune is one visible character (combining marks, emoji sequences).

### Mastery check

1. **Explain.** Why is `len("€")` 3? Why does `range` jump byte offsets?
2. **Predict.** (a) `len("Go🙂")` (b) `utf8.RuneCountInString("Go🙂")` (c) `fmt.Println("Go🙂"[2])` (d) `fmt.Printf("%q\n", "Go🙂"[:3])` (e) `string(rune(0x1F642))`
3. **Write.** `reverse(s string) string` that reverses by runes, then test it with `"नमस्ते"` and observe why the result looks broken. Explain what grapheme clusters have to do with it.

## Unit 2.6 — Building and converting strings

**One-line summary:** The `strings` package does searching, splitting, and trimming; `strings.Builder` builds strings efficiently; `strconv` converts between strings and numbers precisely; `unicode` and `unicode/utf8` classify and encode runes. The `bytes` package mirrors `strings` for `[]byte`.

### The `strings` toolbox

| Task | Functions |
| --- | --- |
| Test | `Contains`, `ContainsRune`, `ContainsAny`, `HasPrefix`, `HasSuffix`, `EqualFold` (case-insensitive equality) |
| Find | `Index`, `LastIndex`, `IndexByte`, `IndexRune`, `IndexFunc`, `Count` |
| Split | `Split(s, sep)`, `SplitN`, `Fields` (on any whitespace), `FieldsFunc`, `Cut(s, sep)`, `CutPrefix`, `CutSuffix`, `CutLast` (Go 1.27) |
| Trim | `TrimSpace`, `Trim(s, cutset)`, `TrimPrefix`, `TrimSuffix`, `TrimFunc`, `TrimLeft`, `TrimRight` |
| Change | `ToUpper`, `ToLower`, `Title`-style casing via `golang.org/x/text/cases`, `Replace`, `ReplaceAll`, `Repeat`, `Map` |
| Join | `Join(parts, sep)` |
| Iterate (Go 1.24+) | `Lines`, `SplitSeq`, `FieldsSeq` — iterators that avoid building a slice |

`strings.Cut` deserves special mention; it replaced many awkward `Index` + slicing combinations:

```go
key, value, ok := strings.Cut("name=Ravi", "=")
// key "name", value "Ravi", ok true
```

**Two traps:** `strings.Split("", ",")` returns `[""]` (one empty element), not an empty slice; and `TrimLeft`/`TrimRight` take a *set of characters*, not a prefix: `strings.TrimLeft("aabcd", "ab")` is `"cd"`. For prefixes use `TrimPrefix`.

### Building strings: `+` vs `strings.Builder`

Each `+` makes a new string and copies both sides. In a loop, that is O(n²) bytes copied:

```go
s := ""
for i := range 10_000 {
	s += strconv.Itoa(i) // copies everything built so far, every time
}
```

`strings.Builder` keeps a growing `[]byte` internally and turns it into a string at the end without another copy:

```go
var b strings.Builder           // zero value is ready to use (DT-48)
for i := range 10_000 {
	b.WriteString(strconv.Itoa(i))
	b.WriteByte(',')
}
s := b.String()
```

`b.Grow(n)` pre-sizes it (P-17). A Builder must not be copied after first use (the copy and the original would share the buffer; the type detects it and panics). `fmt.Fprintf(&b, ...)` works too, because `*strings.Builder` is an `io.Writer` (Chapter 5). For a handful of concatenations, `+` or `fmt.Sprintf` is perfectly fine and clearer.

### `strconv`: precise conversions

```go
n, err := strconv.Atoi("42")                 // int
i, err := strconv.ParseInt("-ff", 16, 64)    // base 16, must fit int64: -255
u, err := strconv.ParseUint("300", 10, 8)    // bitSize 8: error "value out of range"
f, err := strconv.ParseFloat("3.25", 64)
ok, err := strconv.ParseBool("true")         // also accepts 1, t, T, TRUE, True, 0, f, ...

s1 := strconv.Itoa(-42)                      // "-42"
s2 := strconv.FormatInt(255, 2)              // "11111111"
s3 := strconv.FormatFloat(1.5, 'f', 2, 64)   // "1.50"
s4 := strconv.Quote("tab\there")             // the text "tab\there", with quotes and a visible \t escape
buf := strconv.AppendInt(nil, 42, 10)        // append form: no intermediate string
```

The errors are `*strconv.NumError` values that say what failed and why (`strconv.ParseUint: parsing "300": value out of range`). Prefer `strconv` over `fmt.Sscanf` for single values: it is faster and stricter.

`ParseInt`'s `base` 0 means "detect from the prefix", accepting `0x`, `0o`, `0b`, and underscores like Go literals: `strconv.ParseInt("0x_FF", 0, 64)` is 255.

### `unicode` and `unicode/utf8`

```go
unicode.IsLetter('न')   // true
unicode.IsMark('े')     // true: a vowel sign is a mark, not a letter
unicode.IsDigit('٣')    // true: Arabic-Indic three
unicode.IsSpace('\u00A0') // true: no-break space
unicode.ToUpper('ß')    // 'ß' — unchanged; see DT-117

r, size := utf8.DecodeRuneInString("€uro") // '€', 3
utf8.RuneLen('€')                          // 3
utf8.ValidString("\xff")                   // false
b := utf8.AppendRune(nil, '€')             // [226 130 172]
```

### `bytes`: the same toolbox for `[]byte`

`bytes.Contains`, `bytes.Split`, `bytes.TrimSpace`, `bytes.Buffer` (a read/write byte buffer), and so on mirror `strings`. Use them when your data is already `[]byte` (file contents, network data) to avoid converting back and forth.

### Deep & Tricky

**DT-116. `strings.ToUpper` can change the length of a string.** *(Unicode fact)* Case mapping is not one-to-one in all languages: some lowercase characters have uppercase forms that are encoded with a different number of bytes (for example Turkish dotless `ı` → `I`, or `ſ` → `S`). Never assume `len(strings.ToUpper(s)) == len(s)`, and never use the byte offsets of one to slice the other.

**DT-117. Simple case mapping is not full case mapping.** *(Library behaviour)* `unicode.ToUpper` works on single runes and uses simple one-to-one mappings, so `ß` stays `ß` (its full uppercase is "SS", two characters). `strings.ToUpper("ß")` also returns `"ß"` for the same reason. Language-aware casing (`İ` in Turkish, "SS" in German) needs `golang.org/x/text/cases`. Case-insensitive comparison should use `strings.EqualFold`, which uses Unicode case folding, not `ToLower(a) == ToLower(b)`.

**DT-118. A `strings.Builder` panics if copied after use.** *(Library behaviour)* The Builder stores a pointer to itself on first write and checks it on every call. `b2 := b1` after writing, then `b2.WriteString(...)`, panics with `strings: illegal use of non-zero Builder copied by value`. Pass `*strings.Builder` to functions.

### Pattern

**P-20. Parse with `strconv`, not `fmt.Sscan`, for single values; always keep the error.** *(Go practice)* `strconv` reports exactly what was wrong (syntax vs range), is several times faster, and does not silently accept trailing garbage the way some `Sscanf` formats do. Wrap the error with context (`fmt.Errorf("parsing port %q: %w", s, err)`, Chapter 3) instead of replacing it.

### Common mistakes

- Building large strings with `+=` in a loop.
- `TrimLeft(s, "prefix")` when `TrimPrefix` was meant.
- Comparing case-insensitively with `ToLower` instead of `EqualFold`.
- `ParseInt(s, 10, 64)` and then converting to `int8` without a range check (silent truncation, DT-41) — pass `bitSize` 8 instead.

### Mastery check

1. **Explain.** Why is `s += x` in a loop O(n²), and how does `strings.Builder` avoid it?
2. **Predict.** (a) `strings.Split("a,b,,c", ",")` (b) `len(strings.Split("", ","))` (c) `strings.TrimLeft("xxhixx", "x")` (d) `strings.Fields("  a \t b\n")` (e) `strconv.ParseUint("256", 10, 8)` (f) `strings.EqualFold("Straße", "STRASSE")`
3. **Write.** `parseKV(line string) (map[string]string, error)` for input like `name=Ravi; city = Pune ;age=30`: split on `;`, then `Cut` on `=`, trim spaces, reject empty keys with a clear error.
