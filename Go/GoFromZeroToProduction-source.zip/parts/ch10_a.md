# Chapter 10 — Performance Engineering & Runtime Internals

*Goal: explain and prove performance instead of guessing.*

Performance work has one rule that matters more than all the techniques: **measure first**. Engineers are reliably wrong about where time goes; profiles are not. This chapter teaches the measuring tools (benchmarks done properly, pprof, execution traces), the compiler and runtime behaviour that explains what you measure (escape analysis, inlining, bounds checks, the garbage collector, the scheduler, how maps and slices and interfaces are built), and the optimisation techniques that follow from them.

The chapter's worked example is real: the Chapter 5 log analyzer, profiled and made **4.2× faster with 89% fewer allocations**, with every number below taken from actual runs.

**What you will be able to do after this chapter**

- Run benchmarks that produce trustworthy comparisons, and read `benchstat`.
- Profile CPU, heap, allocations, blocking, mutexes, and goroutines with pprof, and trace execution.
- Read escape-analysis, inlining, and bounds-check output, and a little assembly.
- Explain and tune the garbage collector (GOGC, GOMEMLIMIT) and the scheduler (G-M-P).
- Explain the internals of slices, strings, maps, interfaces, and channels.
- Use profile-guided optimisation, `runtime/metrics`, and GODEBUG — and know why to avoid `unsafe`.

## Topic 10A — Measurement

## Unit 10.1 — Measure first

**One-line summary:** Optimise only what a measurement shows to be slow, using realistic workloads, repeated runs, and statistical comparison. Decide in advance what "faster" means (latency? throughput? memory? at which percentile?) and stop when the goal is met.

### The loop

1. **Define the goal.** "p99 redirect latency under 5 ms at 2,000 requests/second" or "process a 1 GB log in under 10 seconds with less than 50 MB of memory". Without a target, optimisation never ends.
2. **Build a realistic benchmark** — realistic input sizes and distributions (Unit 4.5's warnings), ideally captured from production.
3. **Measure the baseline**, several runs (`-count 10`).
4. **Profile** to find where the time or memory goes (Unit 10.2). Not where you *think* it goes.
5. **Change one thing.**
6. **Measure again** and compare with `benchstat`. Keep the change only if the improvement is significant *and* worth its complexity.
7. Repeat until the goal is met.

### Benchmark rigour

- Use `b.Loop()` (Go 1.24+) so setup is excluded and results cannot be optimised away (Unit 4.5).
- Report allocations (`-benchmem` or `b.ReportAllocs()`): allocation counts are stable across runs and machines, unlike nanoseconds, and are often the root cause.
- Report throughput with `b.SetBytes(n)` for data-processing code (the log analyzer reports MB/s).
- Run on a quiet machine. Laptops change frequency with temperature and power; CI machines are shared. For decisions, use dedicated hardware or many runs.
- Use sub-benchmarks for several input sizes, because behaviour changes with size (caches, Unit 6.13).

### Reading `benchstat`

The real comparison from this chapter's project, 6 runs each:

```
       │   old.txt   │              new.txt               │
       │   sec/op    │   sec/op     vs base               │
Scan-2   9.768m ± 7%   2.306m ± 5%  -76.39% (p=0.002 n=6)

       │    old.txt    │               new.txt               │
       │     B/op      │     B/op      vs base               │
Scan-2   3991.9Ki ± 0%   958.7Ki ± 0%  -75.99% (p=0.002 n=6)

       │   old.txt   │              new.txt               │
       │  allocs/op  │  allocs/op   vs base               │
Scan-2   90.09k ± 0%   10.07k ± 0%  -88.82% (p=0.002 n=6)
```

- The first number in each column is the **median**; `± 7%` is the spread (a confidence interval).
- `p=0.002` is the probability of seeing a difference this large by chance if there were no real difference. Below 0.05 is conventionally "significant".
- A result shown as `~` means **no significant difference** — as in the PGO experiment of Unit 10.9 (`~ (p=0.132 n=6)`). Do not claim a speed-up that benchstat calls `~`.

### Deep & Tricky

**DT-262. Microbenchmarks can mislead about whole programs.** *(Measurement fact)* A function 3× faster in isolation may make the service 0.1% faster if it was 0.03% of the time; it can even make it slower if the "optimisation" increased memory use and GC work elsewhere. Validate important changes with whole-program measurements (load tests, Unit 14.6) as well as microbenchmarks.

### Mastery check

1. **Explain.** What do `± 5%` and `p=0.002` mean in benchstat output? When should you not trust a result?
2. **Write.** A performance goal statement for the Chapter 9 shortener's redirect endpoint, including the metric, percentile, load, and hardware.

## Unit 10.2 — Profiling with pprof

**One-line summary:** pprof samples where a program spends CPU time, allocates memory, blocks, or contends on locks, and attributes it to call stacks. Collect profiles from benchmarks (`-cpuprofile`, `-memprofile`) or from live services (`net/http/pprof`), then explore with `go tool pprof` (`top`, `list`, `web`, flame graphs).

### Collecting

From a benchmark:

```
go test -run XXX -bench Scan -cpuprofile cpu.out -memprofile mem.out .
go tool pprof logscan.test cpu.out
```

From a running service — import the handler package for its side effect:

```go
import _ "net/http/pprof" // registers /debug/pprof/* on http.DefaultServeMux
```

…and serve `http.DefaultServeMux` **on a separate, internal-only port** (never on the public listener: profiles reveal internals and profiling costs CPU):

```go
go func() { log.Println(http.ListenAndServe("localhost:6060", nil)) }()
```

```
go tool pprof http://localhost:6060/debug/pprof/profile?seconds=30   # CPU, 30 s
go tool pprof http://localhost:6060/debug/pprof/heap                  # live heap
go tool pprof http://localhost:6060/debug/pprof/allocs                # all allocations since start
go tool pprof http://localhost:6060/debug/pprof/goroutine             # where every goroutine is
go tool pprof http://localhost:6060/debug/pprof/block                 # where goroutines block (enable with runtime.SetBlockProfileRate)
go tool pprof http://localhost:6060/debug/pprof/mutex                 # lock contention (runtime.SetMutexProfileFraction)
go tool pprof http://localhost:6060/debug/pprof/goroutineleak         # Go 1.27: leaked goroutines (Unit 7.8)
```

### The profile types

| Profile | Question it answers |
| --- | --- |
| CPU | Where is CPU time spent? (Samples the running stack ~100 times per second.) |
| heap (`inuse_space`) | What is holding memory *right now*? (Leaks, big caches.) |
| allocs (`alloc_space`, `alloc_objects`) | What allocates the most over time? (GC pressure.) |
| block | Where do goroutines wait on channels, mutexes, selects? |
| mutex | Which locks are contended, and who holds them? |
| goroutine | What is every goroutine doing? (Leaks, deadlocks, pile-ups.) |

### Reading `top`

The real CPU profile of the original log analyzer (`go tool pprof -top`):

```
      flat  flat%   sum%        cum   cum%
     570ms  7.71%  7.71%      870ms 11.77%  strings.Fields
     320ms  4.33% 12.04%      980ms 13.26%  fmt.(*ss).ReadRune
     290ms  3.92% 15.97%      290ms  3.92%  runtime.memclrNoHeapPointers
     200ms  2.71% 21.52%      970ms 13.13%  runtime.mallocgcSmallScanNoHeader
     ...
     150ms  2.03% 39.92%     2300ms 31.12%  fmt.(*ss).scanOne
     140ms  1.89% 47.63%     2710ms 36.67%  fmt.(*ss).doScanf
```

- **flat:** time spent in the function itself.
- **cum:** time in the function *and everything it called*.
- Sort by cumulative (`-top -cum`) to find the expensive *subtrees* in your own code:

```
         0     0%     0%      6.44s 87.14%  example.com/logscan.run
     0.02s  0.27%  0.27%      6.01s 81.33%  example.com/logscan.scan
     0.02s  0.27%  0.54%      5.46s 73.88%  example.com/logscan.parseLine
         0     0%  2.03%      3.64s 49.26%  fmt.Sscanf (inline)
     0.57s  7.71% 27.88%      0.87s 11.77%  strings.Fields
         0     0% 39.78%      0.25s  3.38%  time.Parse
```

The diagnosis jumps out: **half of all CPU time** is `fmt.Sscanf` parsing two integers. Most developers would have guessed `time.Parse` (3.4%).

Inside pprof's interactive mode: `top`, `top -cum`, `list parseLine` (annotated source with time per line), `peek`, `web` (call graph in a browser), or run `go tool pprof -http=:8081 cpu.out` for a web UI with **flame graphs** — the fastest way to see where time goes.

### The allocation profile

```
go tool pprof -sample_index=alloc_space -top logscan.test mem.out
      flat  flat%   sum%        cum   cum%
      53MB 27.11% 27.11%   149.01MB 76.21%  example.com/logscan.parseLine
   47.50MB 24.30% 51.40%    47.50MB 24.30%  strings.Fields
   43.50MB 22.25% 73.65%    43.50MB 22.25%  fmt.newScanState
   22.50MB 11.51% 85.16%    22.50MB 11.51%  bufio.(*Scanner).Text (inline)
   21.43MB 10.96% 96.12%    21.43MB 10.96%  example.com/logscan.newStats (inline)
```

`strings.Fields` allocates a new slice per line; `fmt.Sscanf` allocates scanner state per call; and `parseLine` itself allocates because passing `&e.status` to `Sscanf` makes the whole `entry` escape to the heap (Unit 10.4).

### Deep & Tricky

**DT-263. CPU profiles miss time spent waiting.** *(Profiler behaviour)* The CPU profiler samples goroutines that are *running*. A request that takes 2 seconds because it waits 1.9 seconds for a database shows almost nothing in a CPU profile. For latency, look at block and mutex profiles, execution traces (Unit 10.3), and distributed traces (Unit 11.5).

**DT-264. Profile labels attribute samples to requests or tenants.** *(Library feature)* `pprof.Do(ctx, pprof.Labels("endpoint", "redirect"), func(ctx context.Context) {...})` tags samples taken while the function runs; `pprof -tagfocus` filters by label. Since Go 1.27 these labels also appear in goroutine tracebacks.

### Mastery check

1. **Explain.** What is the difference between flat and cumulative time? Why sort by cumulative first?
2. **Write.** Add a pprof endpoint on `localhost:6060` to the shortener, generate load with a loop of requests, capture a 10-second CPU profile, and list the top five functions by cumulative time.

## Unit 10.3 — Execution tracing with go tool trace

**One-line summary:** The execution tracer records every scheduling event — goroutines starting, blocking, unblocking, running on which processor, GC phases, system calls — with nanosecond timestamps. `go tool trace` shows them on a timeline. Use it for latency problems that profiles cannot explain: goroutines waiting to be scheduled, GC pauses at bad moments, poor parallelism.

### Collecting and viewing

```
go test -run TestX -trace trace.out
curl -o trace.out http://localhost:6060/debug/pprof/trace?seconds=5
go tool trace trace.out             # opens a browser UI (Go 1.27: listens on localhost only by default)
```

Or in code: `trace.Start(f)` … `trace.Stop()` from `runtime/trace`. Since Go 1.25, a **flight recorder** (`trace.FlightRecorder`) keeps the last few seconds of trace in memory, so a service can dump the trace *after* noticing a slow request — catching rare events without tracing all the time.

### What to look for

- **Goroutine analysis:** for each goroutine type, how long it spent executing, waiting on the network, blocked on sync, waiting for the scheduler ("scheduler latency"). High scheduler latency means too much runnable work for too few Ps.
- **Timeline:** are all Ps busy (good parallelism) or mostly idle while work waits on a lock?
- **GC:** when do GC cycles run, how long do they take, and which goroutines were drafted into "mark assist" (doing GC work instead of their own because they allocate fast)?
- **User annotations:** `trace.WithRegion(ctx, "parse", func() {...})` and `trace.NewTask` mark your own operations on the timeline.

### Deep & Tricky

**DT-265. Tracing is more expensive than profiling, but cheaper than it used to be.** *(Implementation detail)* Go 1.21 cut tracing overhead to a few percent of CPU (from 10–20%), and Go 1.22 redesigned the trace format to be streamable. Short traces in production are now reasonable; the flight recorder makes it routine.

### Mastery check

1. **Explain.** Give an example of a latency problem a CPU profile would not reveal but a trace would.
2. **Write.** Trace the Chapter 7 worker pool with 2 and with 8 workers on a CPU-heavy job; compare processor utilisation on the timeline.

## Topic 10B — Compiler and allocations

## Unit 10.4 — Escape analysis

**One-line summary:** The compiler places a value on the stack when it can prove the value does not outlive its function; otherwise it **escapes** to the heap. Heap allocations cost allocation time and GC work. `-gcflags=-m` shows the decisions; reducing needless escapes is one of the most effective Go optimisations.

### Common reasons values escape

| Cause | Example |
| --- | --- |
| Returning a pointer to a local | `return &p` (Unit 2.12) |
| Storing a pointer in something long-lived | appending `&x` to a package-level slice or a struct field that escapes |
| Converting to an interface | `fmt.Println(x)`, `any(x)`, storing in `[]any` (Unit 3.5) |
| Closures that capture variables and outlive the function | goroutines, returned functions (DT-86) |
| Passing a pointer to a function the compiler cannot see through | `fmt.Sscanf(s, "%d", &e.status)` — `Sscanf` takes `...any` |
| Sizes unknown at compile time | `make([]byte, n)` with a variable `n` (usually) |
| Very large values | locals over ~64 KB (DT-42) |

The log analyzer's `parseLine` allocated 53 MB in its own frame for exactly the `Sscanf` reason: `&e.status` was passed as an `any`, so `e` escaped — every line allocated an `entry` on the heap. Replacing `Sscanf` with `strconv.Atoi` let `e` stay on the stack.

### Reading `-gcflags=-m`

```
go build -gcflags=-m ./...          # one level of detail
go build -gcflags='-m -m' ./...     # explains WHY something escapes
```

Messages: `moved to heap: x` (a variable became a heap allocation), `x escapes to heap` (a value is copied to the heap, usually through an interface), `does not escape` (good), `can inline f`, `inlining call to f`. Use them to *confirm* what a memory profile shows; do not try to make every line "not escape".

### Techniques to reduce allocations

- Avoid interface conversions in hot paths (`strconv` instead of `fmt` for single values).
- Reuse buffers: `buf = buf[:0]`, `strings.Builder.Reset`, `sync.Pool` (Unit 7.11), `strconv.AppendInt(buf, n, 10)` instead of `Itoa`.
- Pre-size slices and maps (P-17).
- Use fixed-size arrays for small, bounded collections (the optimised `parseLine` uses `var f [6]string`).
- Use iterators instead of building intermediate slices (`strings.FieldsSeq` instead of `strings.Fields`).
- Pass small structs by value (Unit 2.12) rather than pointers that escape.
- Avoid `[]byte` ↔ `string` conversions in loops where possible (DT-114 lists the free cases).

### Deep & Tricky

**DT-266. Inlining changes escape decisions.** *(Compiler behaviour)* A function that returns `&p` makes `p` escape — unless the call is inlined into a caller that does not let the pointer escape, in which case the allocation disappears. That is why `-m` output for the same function can differ between call sites, and why Unit 2.12 needed `//go:noinline` to show the escape reliably.

**DT-267. Go 1.26 can put more slice backing arrays on the stack.** *(Version-dependent optimisation)* Recent compilers allocate small `make([]T, n)` buffers on the stack in more situations, even with variable `n` (using a fixed-size stack buffer when `n` is small). Always re-measure after upgrading Go: some of your manual optimisations may become unnecessary.

### Mastery check

1. **Explain.** Why does passing `&e.status` to `fmt.Sscanf` make the whole `e` escape?
2. **Write.** Find the top allocation site in one of your projects with `-memprofile`, confirm with `-gcflags='-m -m'`, remove it, and show the `benchstat` result for allocs/op.

## Unit 10.5 — The compiler

**One-line summary:** The gc compiler parses and type-checks your code, converts it to **SSA** (static single assignment) form, optimises it (inlining, constant folding, dead-code elimination, bounds-check elimination, escape analysis), and generates machine code for the target architecture. Knowing its main optimisations helps you write code it can make fast — and read the evidence.

### Inlining

Small functions are copied into their callers, removing call overhead and enabling further optimisation (escape analysis, constant folding across the boundary). The compiler uses a cost budget (roughly 80 "nodes"); functions with loops, `defer`, `recover`, or `select` were historically harder to inline. PGO (Unit 10.9) raises the budget for hot call sites. See decisions with `-gcflags=-m`:

```
./stats.go:47:6: can inline (*stats).percentile
./stats.go:90:29: inlining call to (*stats).percentile
```

### Bounds-check elimination (BCE)

Every slice index is checked (DT-99), but the compiler removes checks it can prove unnecessary. Real output of `-gcflags=-d=ssa/check_bce/debug=1` for this file:

```go
func sumFirst4(s []int) int {
	return s[0] + s[1] + s[2] + s[3] // four bounds checks
}

func sumFirst4Hint(s []int) int {
	_ = s[3] // one check up front proves the other indexes are in range
	return s[0] + s[1] + s[2] + s[3]
}

func sumAll(s []int) int {
	t := 0
	for i := range s {
		t += s[i] // the compiler proves i < len(s): no check
	}
	return t
}
```

```
./b.go:4:10: Found IsInBounds
./b.go:4:17: Found IsInBounds
./b.go:4:24: Found IsInBounds
./b.go:4:31: Found IsInBounds
./b.go:8:7: Found IsInBounds
```

Four checks in `sumFirst4`, one in the hinted version (line 8, the `_ = s[3]`), none in `sumAll`. The standard library's `encoding/binary` uses exactly this `_ = b[7]` hint before reading 8 bytes. A bounds check costs very little when predicted correctly; this matters only in the tightest loops — measure.

### Reading assembly

`go build -gcflags=-S` prints the generated assembly (Go's own assembler syntax). For `func add(a, b int) int { return a + b }` on amd64:

```
TEXT	bce.add(SB), NOSPLIT|NOFRAME|ABIInternal, $0-16
ADDQ	BX, AX
RET
```

One instruction and a return: the arguments arrived in registers AX and BX, and the result is returned in AX — the register-based calling convention of DT-38, visible. `NOSPLIT` means the function needs no stack-growth check (it uses no stack). You will rarely write assembly, but reading it settles arguments about what the compiler does. `go tool objdump` disassembles binaries; the Compiler Explorer (godbolt.org) shows Go assembly side by side with source.

### SSA

`GOSSAFUNC=parseLine go build` writes `ssa.html`, showing the function after each of dozens of optimisation passes — the deepest view of what the compiler did. Useful for understanding why an optimisation did or did not happen.

### Mastery check

1. **Explain.** Why does `for i := range s { s[i] }` need no bounds check, while `for i := 0; i <= n; i++ { s[i] }` does?
2. **Write.** Write a function that reads a big-endian `uint32` from `b []byte` at offset `i`, check its bounds checks, and reduce them to one with a hint.

## Topic 10C — Runtime internals

## Unit 10.6 — Garbage collector

**One-line summary:** Go's GC is a concurrent, tri-colour, mark-and-sweep collector: it finds live objects by tracing from roots while your program keeps running, with only very short stop-the-world pauses. Its cost is CPU time (proportional to live heap and pointer density) and memory headroom. `GOGC` trades memory for CPU; `GOMEMLIMIT` sets a soft memory ceiling.

### How it works (enough to reason about it)

1. **Mark:** starting from roots (goroutine stacks, globals, registers), the GC marks every reachable object. Tri-colour: white (not yet seen), grey (seen, children not yet scanned), black (scanned). A **write barrier** keeps the invariant correct while your goroutines modify pointers during marking.
2. **Mark assist:** a goroutine that allocates quickly during marking is made to do some marking work itself, so allocation cannot outrun the collector. This shows up as latency in allocation-heavy code.
3. **Sweep:** memory of unmarked objects is reclaimed, lazily, as new allocations need it.
4. **Pacing:** a new cycle starts when the heap grows to a **target**: by default `live heap × (1 + GOGC/100)`, i.e. with `GOGC=100`, when the heap doubles since the last cycle's live size.

Pauses are typically well under a millisecond. Go 1.26 made the **Green Tea** collector the default: it scans memory in page-sized spans rather than object by object, improving locality and cutting GC CPU cost by 10–40% on many workloads.

### Reading a GC trace

`GODEBUG=gctrace=1` prints one line per cycle. Real output from the optimised log analyzer:

```
gc 1 @0.012s 1%: 0.070+0.82+0.049 ms clock, 0.14+0.079/0.097/0.54+0.098 ms cpu, 3->3->1 MB, 4 MB goal, 0 MB stacks, 0 MB globals, 2 P
```

- `gc 1 @0.012s 1%`: cycle 1, 12 ms after start, GC has used 1% of CPU so far.
- `0.070+0.82+0.049 ms clock`: stop-the-world sweep termination + concurrent mark + stop-the-world mark termination. The pauses are the first and last numbers: 70 µs and 49 µs.
- `3->3->1 MB`: heap at cycle start → at mark end → live after marking.
- `4 MB goal`: the heap size that triggers the next cycle.

### GOGC and GOMEMLIMIT — measured

The log analyzer processing a 51 MB, 1,000,000-line file, real measurements:

| Setting | Time | Peak memory (RSS) | GC cycles |
| --- | --- | --- | --- |
| `GOGC=25` | 0.32 s | 5.9 MB | 61 |
| `GOGC=100` (default) | 0.31 s | 7.8 MB | 22 |
| `GOGC=400` | 0.30 s | 21.8 MB | 4 |
| `GOGC=off` | 0.31 s | 64.9 MB | 0 |

Two lessons. First, the trade-off is real: more GC cycles ↔ less memory. Second, **the run time barely changed** — because the optimisation of Unit 10.2 had already removed 89% of the allocations, the GC had little to do. Reducing allocations beats tuning the collector.

- **`GOGC`** (default 100): higher = fewer GC cycles and more memory; `off` disables collection (only for short batch jobs that fit in memory).
- **`GOMEMLIMIT`** (Go 1.19): a soft limit on total Go memory, such as `GOMEMLIMIT=900MiB` in a container with 1 GiB. The GC runs more often as the limit approaches, avoiding out-of-memory kills. Combined with `GOGC=off`, the GC runs only when needed to stay under the limit. If live data genuinely exceeds the limit, the GC can run continuously ("death spiral" — the runtime caps GC CPU to about 50% to keep the program making progress). Set limits with headroom.
- Both can be set at run time with `debug.SetGCPercent` and `debug.SetMemoryLimit`.

### Reducing GC cost

GC work is proportional to the **live heap** and the number of **pointers** to scan; allocation *rate* sets how often it runs. So: allocate less (Unit 10.4), keep fewer long-lived pointers (a `[]int32` of node IDs instead of `[]*Node`; the GC does not scan memory without pointers — Unit 13.8 uses this), and size `GOMEMLIMIT` to the container.

### Deep & Tricky

**DT-268. Finalizers and `runtime.AddCleanup` are not destructors.** *(Runtime behaviour)* `runtime.SetFinalizer` (and its safer Go 1.24 replacement `runtime.AddCleanup`) run some time after an object becomes unreachable — or never, if the program exits first. Never rely on them to close files or release locks; use `defer` and explicit `Close`. They are a safety net for leaked resources, nothing more.

**DT-269. A large live heap of pointer-free data is nearly free for the GC.** *(Implementation behaviour)* Memory allocated for types without pointers (`[]byte`, `[]float64`, structs of numbers) is marked "no scan": the GC marks the block live without reading it. A 2 GB `[]int32` graph costs almost nothing per GC cycle; 2 GB of `*Node` objects costs a full scan every cycle.

### Mastery check

1. **Explain.** Why did changing `GOGC` hardly change the run time of the optimised analyzer? Predict what it would have done to the *original* version.
2. **Explain.** What does `GOMEMLIMIT` protect against in a container, and what is the risk of setting it too close to the live heap size?
3. **Write.** Run the *original* analyzer with `GODEBUG=gctrace=1` on the same file and compare cycle counts and GC CPU percentage with the optimised version.

## Unit 10.7 — Scheduler

**One-line summary:** The Go scheduler multiplexes many goroutines (G) onto a few OS threads (M), each running Go code only while holding one of `GOMAXPROCS` processors (P). Each P has a local run queue; idle Ps **steal** work from others; long-running goroutines are **preempted**; blocking system calls hand off the P so other goroutines keep running.

### G, M, P in more detail

- **P** owns a local run queue of up to 256 runnable goroutines, plus a "next" slot (a goroutine just woken by the running one runs next, which is good for ping-pong communication). A global run queue holds overflow.
- **Scheduling points:** a goroutine yields when it blocks (channel, mutex, network, sleep), calls `runtime.Gosched`, or is preempted. Since Go 1.14, preemption is **asynchronous**: the runtime signals the thread, so even a tight loop without function calls yields after about 10 ms.
- **Work stealing:** an idle P checks its local queue, then the global queue, then the network poller, then tries to steal half the run queue of a random other P. This keeps all cores busy without a central lock.
- **System calls:** before a blocking syscall (file I/O), the M releases its P; if the syscall takes long, another M picks up the P and continues running goroutines. When the syscall returns, the M tries to get a P back.
- **Network poller:** sockets are non-blocking; a goroutine waiting on network I/O is parked, and the poller (epoll/kqueue/IOCP) wakes it when data arrives. Thousands of idle connections cost no threads.

### Stack growth

Every function prologue checks whether the stack has room for its frame (unless it is `NOSPLIT`, as in Unit 10.5's assembly). If not, the runtime allocates a stack twice as large, copies the old one, and adjusts pointers into it (DT-35). Copying is O(stack size), so deep recursion that repeatedly grows and shrinks can cost noticeable time; it is rarely an issue.

### GOMAXPROCS

Defaults to the number of CPUs the process can use. Since Go 1.25, on Linux the default also respects the container's **CPU limit** (cgroup quota) and updates if it changes. Before 1.25, a container limited to 2 CPUs on a 64-core host got `GOMAXPROCS=64`, causing heavy throttling and latency spikes — the reason the `uber-go/automaxprocs` library existed. Setting `GOMAXPROCS` explicitly overrides the default.

### Deep & Tricky

**DT-270. `runtime.LockOSThread` pins a goroutine to its thread.** *(Runtime API)* Needed when calling C libraries or OS APIs that use thread-local state (some graphics libraries, Linux namespaces). The thread is not used for other goroutines until unlocked. Rarely needed elsewhere, and a source of thread explosion if misused.

**DT-271. Too many runnable goroutines raise latency, not throughput.** *(Scheduling fact)* With 8 Ps and 10,000 runnable CPU-bound goroutines, each waits its turn; the work finishes in the same total time, but individual requests see long scheduler delays. Bound CPU-bound concurrency to roughly GOMAXPROCS (worker pools, Unit 7.10); unbounded concurrency only helps I/O-bound work.

### Mastery check

1. **Explain.** What happens, step by step, when a goroutine reads from a network socket that has no data?
2. **Explain.** Why did containers need `automaxprocs` before Go 1.25?

## Unit 10.8 — Data-structure internals

**One-line summary:** The built-in types have simple, knowable representations: slices are (ptr, len, cap), strings are (ptr, len), interfaces are (type/itab, data), maps are Swiss tables, channels are a locked ring buffer with queues of waiting goroutines. Knowing them explains their costs.

| Type | Representation (64-bit) | Cost implications |
| --- | --- | --- |
| slice | 24 bytes: pointer, length, capacity (Unit 2.2) | cheap to pass; growth copies (Unit 2.3); sub-slices pin memory (Unit 2.4) |
| string | 16 bytes: pointer, length | immutable, so substrings share bytes; conversions to `[]byte` copy |
| array | the elements themselves | copied on assignment; no indirection |
| interface | 16 bytes: `itab` pointer (type + method table) or type pointer for `any`, plus a data pointer | method calls are indirect (DT-149); boxing non-pointer values often allocates |
| map | pointer to a runtime structure: since Go 1.24 a Swiss table (groups of 8 slots with a control word of 7-bit hash fragments, matched several at a time), split into tables that grow independently | O(1) average; iteration order randomised; memory not returned on delete (Unit 2.8) |
| channel | pointer to `hchan`: a mutex, a circular buffer of `cap` elements, send and receive wait queues | every operation takes a lock; unbuffered sends hand the value directly to a waiting receiver |
| func value | pointer to a closure object: code pointer + captured variables | calling through it is indirect; captured variables may live on the heap |

Practical consequences you have already met: `[]*T` vs `[]T` (Unit 2.12), why channels are slower than mutexes for simple shared counters (lock plus queue management), why a map of a million entries is many separate memory regions while a sorted slice is one (DT-217), why `any(x)` in a hot loop allocates.

### Deep & Tricky

**DT-272. A channel operation costs tens of nanoseconds; a mutex lock/unlock costs about ten when uncontended.** *(Implementation behaviour; measure on your hardware)* Channels are the right tool for communication and coordination; for protecting a counter or a map in a hot path, a mutex or an atomic is several times cheaper. Choose by design first (P-32), and let measurements settle hot spots.

### Mastery check

1. **Explain.** Using the representations above, explain why `for _, v := range []any{...}` with a type switch is slower than ranging over a concrete `[]int`.
2. **Write.** Benchmark sending 1,000,000 integers through an unbuffered channel, a buffered channel (capacity 1024), and a mutex-protected slice. Explain the results with the `hchan` design.

## Topic 10D — Advanced tools

## Unit 10.9 — Profile-guided optimisation (PGO)

**One-line summary:** Give the compiler a CPU profile from a representative production workload (`default.pgo` in the main package directory), and it inlines more aggressively at hot call sites and devirtualises hot interface calls. Typical gains are a few percent, with no code changes — but measure, because some workloads gain nothing.

### Using PGO

1. Collect a CPU profile from production or a realistic load test (`/debug/pprof/profile?seconds=30`).
2. Save it as `default.pgo` in the main package's directory and commit it.
3. Build normally: `go build` uses `default.pgo` automatically since Go 1.21 (`-pgo=auto`). `-pgo=off` disables it.
4. Refresh the profile periodically; the compiler tolerates source changes, but a stale profile helps less.

### Measured on this chapter's project

Using the optimised analyzer's own CPU profile:

```
       │   new.txt   │           pgo.txt            │
       │   sec/op    │   sec/op     vs base         │
Scan-2   2.306m ± 5%   2.253m ± 5%  ~ (p=0.132 n=6)
```

**No significant difference.** The hot path (`strings.FieldsSeq`, `time.Parse`, map updates) was already inlined or dominated by work PGO cannot change. This is a useful, honest result: PGO helps most in large programs with deep call chains and hot interface calls (servers, compilers — the Go team reports 2–14% on such workloads), and little in small, already-tight loops. Do not claim a PGO speed-up without benchstat showing one.

### Mastery check

1. **Explain.** Why does PGO help with interface-heavy code (hint: devirtualisation, DT-149)?
2. **Write.** Apply PGO to the Chapter 9 shortener with a profile captured under load, and report the benchstat comparison of a redirect benchmark — whatever the result.

## Unit 10.10 — Low-level tools

**One-line summary:** `unsafe` breaks Go's memory-safety guarantees and should be a last resort behind a safe API and thorough tests. `runtime/metrics` exposes the runtime's internal measurements for monitoring. `GODEBUG` settings switch runtime and library behaviours for debugging and compatibility.

### `unsafe`

`unsafe.Pointer` can convert between any pointer types; `unsafe.Add`, `unsafe.Slice`, `unsafe.String`, `unsafe.StringData`, `unsafe.SliceData` (Go 1.17–1.20) build slices and strings over raw memory without copying. Legitimate uses: zero-copy conversions in hot paths of serialization libraries, interoperating with C or memory-mapped files (Unit 13.8), and inspecting layouts. The costs:

- No compiler or runtime protection: a wrong length or alignment silently corrupts memory or crashes later, far from the cause.
- Code may break with new Go versions (the rules for valid `unsafe.Pointer` patterns are narrow; `go vet`'s `unsafeptr` check enforces some of them).
- `unsafe.String(ptr, n)` over a `[]byte` that is later modified violates string immutability — invisible bugs in maps and comparisons.

Rule: isolate `unsafe` in a tiny package, document why, test heavily, and benchmark to prove it is worth it. Go 1.27's `go fix` has an `unsafefuncs` modernizer that replaces old `reflect.SliceHeader` tricks with the safer functions.

### `runtime/metrics`

```go
samples := []metrics.Sample{
	{Name: "/gc/heap/live:bytes"},
	{Name: "/sched/goroutines:goroutines"},
	{Name: "/gc/cycles/total:gc-cycles"},
	{Name: "/sched/latencies:seconds"}, // a histogram of scheduler latency
}
metrics.Read(samples)
for _, s := range samples {
	switch s.Value.Kind() {
	case metrics.KindUint64:
		fmt.Println(s.Name, s.Value.Uint64())
	case metrics.KindFloat64Histogram:
		fmt.Println(s.Name, "histogram with", len(s.Value.Float64Histogram().Counts), "buckets")
	}
}
```

`metrics.All()` lists every available metric with its description. Prometheus's Go client exports them automatically (Unit 11.5). Prefer `runtime/metrics` over the older `runtime.ReadMemStats`, which stops the world.

### `GODEBUG`

`GODEBUG=name=value,...` changes runtime and library behaviours: `gctrace=1` (Unit 10.6), `schedtrace=1000` (scheduler state every second), `inittrace=1` (time spent in each package's `init`), `madvdontneed=1`, and many **compatibility settings** that let a program keep old behaviour after a Go upgrade (for example, HTTP or TLS defaults). A module can set defaults with `godebug` lines in `go.mod` or `//go:debug` directives in the main package. Go 1.27 accepts removed settings in those places only if they are set to their final default value.

### Deep & Tricky

**DT-273. `unsafe` conversions can outlive their safety.** *(Classic bug)* `s := unsafe.String(&b[0], len(b))` creates a string sharing `b`'s memory. If `b` is later reused (a pooled buffer!), `s` changes — while sitting as a key in a map that hashed the old contents. The resulting bugs look like map corruption and appear far from the cause.

### Mastery check

1. **Explain.** Why is `runtime.ReadMemStats` in a frequently called metrics handler a bad idea, and what replaces it?
2. **Write.** A `/debug/runtime` endpoint (internal port only) that reports live heap, goroutine count, GC cycles, and the p99 of `/sched/latencies:seconds` computed from the histogram buckets.

## Chapter 10 Project — Profile and optimise with evidence

**Goal:** apply the full measure–profile–change–verify loop to two earlier projects, and write up the results like a professional performance report.

### Part 1 — The log analyzer (worked example)

This part is fully worked; repeat it yourself and compare your numbers.

**Baseline.** `go test -run XXX -bench Scan -benchmem -count 6 -cpuprofile cpu.out . > old.txt` on 10,000 generated lines: about **9.8 ms per run, 44 MB/s, 90,089 allocations**.

**Profile.** The cumulative CPU view (Unit 10.2) shows `fmt.Sscanf` at **49%** of CPU and `strings.Fields` at 12%; the allocation profile shows `strings.Fields`, `fmt.newScanState`, and `parseLine`'s own frame (because `&e.status` passed to `Sscanf` makes `e` escape) as the top allocators.

**Change.** Replace `strings.Fields` with a fixed array filled from `strings.FieldsSeq`, and `fmt.Sscanf` with `strconv.Atoi` / `strconv.ParseInt`:

```go
func parseLine(line string) (entry, error) {
	var f [6]string // fixed-size array: no allocation (Unit 2.1)
	n := 0
	for field := range strings.FieldsSeq(line) { // Go 1.24 iterator: no slice built
		if n == len(f) {
			n++
			break
		}
		f[n] = field
		n++
	}
	if n != len(f) {
		return entry{}, errFields
	}
	var e entry
	var err error
	if e.time, err = time.Parse(time.RFC3339, f[0]); err != nil {
		return entry{}, err
	}
	e.method, e.path = f[1], f[2]
	if e.status, err = strconv.Atoi(f[3]); err != nil || e.status < 100 || e.status > 599 {
		return entry{}, fmt.Errorf("bad status %q", f[3])
	}
	if e.duration, err = time.ParseDuration(f[4]); err != nil {
		return entry{}, err
	}
	if e.bytes, err = strconv.ParseInt(f[5], 10, 64); err != nil || e.bytes < 0 {
		return entry{}, fmt.Errorf("bad byte count %q", f[5])
	}
	return e, nil
}
```

(The error for a wrong field count no longer reports how many fields were found — a deliberate small trade-off; the tests still pass because they check that an error occurs, not its text.)

**Verify.** All tests pass, and `benchstat old.txt new.txt`:

```
Scan-2   9.768m ± 7%   2.306m ± 5%  -76.39% (p=0.002 n=6)     sec/op
Scan-2   43.61Mi ± 7%  184.70Mi ± 5% +323.55% (p=0.002 n=6)    B/s
Scan-2   3991.9Ki ± 0% 958.7Ki ± 0%  -75.99% (p=0.002 n=6)     B/op
Scan-2   90.09k ± 0%   10.07k ± 0%   -88.82% (p=0.002 n=6)     allocs/op
```

**4.2× faster, 89% fewer allocations** — from two small, local changes found by a profile, not by guessing.

**Re-profile.** The new top is `strings.FieldsSeq`'s inlined loop (26%), then `time.ParseDuration` (10%), map assignment, and `time.Parse`. Each is now a reasonable cost; the next steps would be a hand-written field splitter for the fixed format, and `sc.Bytes()` instead of `sc.Text()` to avoid one string allocation per line (keeping the map key conversion for new paths only). Stop when the goal is met.

**Whole-program check.** The optimised binary processes a 51 MB, 1,000,000-line file in **0.31 s** with a peak of **7.8 MB** of memory (`GOGC=100`), confirming the constant-memory design under real I/O.

**PGO.** No significant change (Unit 10.9). Reported anyway.

### Part 2 — The shortener's redirect path (your turn)

1. Add `net/http/pprof` on `localhost:6060` to the Chapter 9 shortener.
2. Write a load generator in Go (a worker pool, Unit 7.10, of 50 goroutines sending `GET /{code}` for a set of codes for 30 seconds, recording latencies into the histogram idea of Chapter 5) — or use a tool such as `hey`, `oha`, or `vegeta`.
3. Measure throughput and p50/p99 latency with the in-process cache, with Redis, and with caching disabled (the plain PostgreSQL store).
4. Capture CPU, allocation, block, and mutex profiles under load. Find the top three costs. (Expect to see JSON logging of every request, the `slog` handler, and the `pending` mutex near the top.)
5. Make at most two changes, and prove each with before/after numbers.

### The report

Write one page per part: goal, environment (CPU, Go version, data), baseline with variance, profile evidence (the relevant lines of `top -cum`), each change and its benchstat result, the final whole-program measurement, what you decided *not* to optimise and why, and remaining risks. This is the format senior engineers use to justify performance work in design reviews.

### Review checklist

- Every claim has a number, every number has a variance, every comparison has a p-value.
- Profiles were captured on realistic data and sizes.
- Optimisations kept the code clear, and the tests still pass.
- Allocation counts were reduced before GC tuning was considered.
- Nothing `unsafe` without overwhelming evidence.

## Answers to the Chapter 10 prediction questions

**10.6 Q1.** The optimised version allocates little, so the GC had little work whatever its setting. The original allocated about nine times more objects per line; with it, low `GOGC` would have caused many more cycles and visible extra CPU time, and `GOGC=off` would have used several times more memory before finishing.

**10.5 Q1.** In `for i := range s`, the compiler knows `0 <= i < len(s)` by construction. In `for i := 0; i <= n; i++`, nothing relates `n` to `len(s)` (and `i <= n` even allows `i == n`), so every access is checked — and may panic.
