# Go Apprenticeship — Learning Notes

Sep 26, 2026 · @Kamaal Khan

## How to use these notes

Current position: Stage 2, Unit 2.1 (Arrays). Stages 0 and 1 complete, including both projects. Working agreement: short checks of about 6 questions; rough answers with spelling mistakes are fine. Nothing is marked mastered until you pass all three checks: explain it, predict code behaviour, and write code yourself.

These notes grow with every lesson. Each unit gets its own section. Every mistake you make goes into the Mistakes log with the exact wrong idea and the corrected idea. Surprising, deeper facts go into the Deep & Tricky Go Knowledge section.

Labels used below:

- **Guarantee** = promised by the Go language specification. Will not change.
- **Toolchain behaviour** = what the `go` command or compiler does today. Stable in practice, but it is a tool choice, not a language rule.
- **Implementation detail** = how the current runtime happens to work. Can change between Go versions.

### Progress tracker

| Concept | Status | Evidence so far |
| --- | --- | --- |
| 0.1 Source code to running process | Mastered | Compile vs run time, go run vs go build, OS + CPU dependence, int vs float vs constant division, NaN, go run exit code. |
| 0.2 Bits, bytes, memory | Mastered | 2^n, conversions, hex, octal and permissions, endianness, int size, Printf width. |
| 0.3 Unsigned integers and overflow | Mastered | Wraparound, constant vs run-time overflow, default type int. |
| 0.4 Signed integers and two's complement | Mastered | −128 place model, flip + add 1, signed wrap, reinterpretation, −MinInt8, int vs int64. |
| 0.5 How the CPU runs your program | Mastered | PC and jumps, constant folding, cache lines, signed vs unsigned compare, memory hierarchy. |
| 0.6 Stack and heap (first look) | Mastered | Frames, LIFO, stack pointer, heap and GC, escape analysis, virtual memory, zero values. |
| Stage 0 Project: numinfo | Complete | Final version: correct output for 200, −1, 0, MinInt64 (`uint64(-n)`). |
| 1.1 Variables and zero values | Mastered | Default types, `:=` rules, two-phase assignment, zero values. |
| 1.2 Constants and untyped constants | Mastered | Representability, rune arithmetic, huge constants, iota, typed vs untyped. |
| 1.3 Arithmetic, comparison, logical | Mastered (1 review item) | Truncation towards zero, remainder sign, short-circuit order, string comparison. Review: fill "Actual" only from real runs. |
| 1.4 Bitwise operators, shifts, precedence | Mastered | All operators incl. `&^`, arithmetic shift, precedence, own 4-flag program. |
| 1.5 Floating-point numbers | Mastered | Cutting calculator, power-of-2 denominators, constants vs variables, `int()` truncation, money in paise. |
| 1.6 if, else, and switch | Mastered | Short-statement scope, fallthrough, first-match order, bool-only conditions. |
| 1.7 for loops | Mastered | All loop shapes, range vs three-part variable change, labels, FizzBuzz order. |
| 1.8 Functions | Mastered | divmod, pass by value, (value, ok) design, recursion, guard-first `largest` tested with zero arguments. |
| 1.9 Scope and shadowing | Mastered (1 review item) | err-shadowing bug, built-in and package shadowing, outer value on the right of `:=`. Review: range starts at 0. |
| 1.10 Closures | Mastered | Window vs photo, generators, heap escape seen with -gcflags=-m, Go 1.21 vs 1.22 proved via go.mod, photo taken outside the closure. |
| 1.11 defer | Mastered | LIFO, photo arguments vs closure window (B: 2, A: 1), 3 steps of return with named results (11 / 10 / 30), defers run before the panic message. |
| 1.12 Reading input | Mastered (2 items folded into the project) | bufio.Scanner loop, scanner.Err, EOF with Ctrl+D, fmt.Scan danger, own ask-until-valid program. Folded into the Stage 1 Project: run() pattern with a returned error; rejection reasons on stderr; pipe tests. |
| 1.13 Random numbers | Mastered (verified through the project) | Learner chose to skip the unit check. Evidence will come from the project: IntN range for 1–100, fixed-seed generator for repeatable tests, and the reflection question on math/rand vs crypto/rand. |
| Stage 1 Project: playtool | Complete | Complete. Version 2: all review comments fixed, all required tests pass with correct exit codes, reflection answers correct. Polish left: general range formula in newSecret. |

Learner background: not yet stated. Environment: Go 1.27.1 on macOS, Apple Silicon (darwin/arm64).

Weak areas: (1) calling every compile error a "syntax error"; (2) assuming float division by zero panics like integer division; (3) thinking only the CPU decides whether a binary runs, forgetting the OS — concept fixed, command not yet written; (4) forgetting that all-constant expressions are computed by the compiler, even for floats; (5) NaN comparison.

Recurring mistakes: "syntax error" used as a general name for all compile errors (A3, B1, C3) — improved in retest 1. Habit gap: skipping parts of multi-part questions (A3 run-time example skipped twice, R4.2, second example in R5). Habit gap: not reading notes before answering (DT-7 had the R7 answer). Strongest pattern: parts of questions skipped or requirements not fully followed — in 0.2, C6 and C7 unanswered, C5 labelled as C6, Part E ignored "padded to 8" and "uppercase", F2 measured a succeeding program for the 3rd time. Suggested fix: tick off every numbered item before sending. Mini-check 0.2 again skipped: %3d explanation, Part E fix (output still showed \`101010\` and \`2a\`), why octal fits permissions, the two things removed by -s -w, and the whole Unit 0.3 preview. Teaching adaptation from now on: fill-in answer templates with one blank per sub-question, and shorter checks.

Due for review: none yet.

## Complete Curriculum Index (draft)

**How to read this index:**

- **Chapter** = one stage of the course (Chapter 0 = Stage 0, and so on).
- **Topic** = a group of related units inside a chapter.
- **Unit** = one lesson, with a number (like 1.7) and a status. Each unit ends with a mastery check.
- **Sections** = the main points taught inside that unit.

**Status:** ✅ Done (mastered) · ▶️ Current (being learned now) · ⬜ Planned

This is a draft. Units may be split when a topic needs more time, the order may change, and new sections will be added as we go. Everything promised in earlier lessons ("you will learn this in Stage X") is listed here so nothing gets lost.

**Cross-cutting tracks (continue in every chapter):** Mistakes & Misconceptions Log · Deep & Tricky Go Knowledge · Go Patterns & Engineering Practices · Glossary · spaced review · reading official docs and standard-library source.

### Overview

| Chapter | Title | Units | Project | Status |
| --- | --- | --- | --- | --- |
| 0 | Computing Foundations & Toolchain | 0.1–0.6 | numinfo CLI | ✅ Done |
| 1 | Core Language Fundamentals | 1.1–1.13 | playtool (guessing game + unit converter) | ✅ Done |
| 2 | Composite Data & Memory | 2.1–2.12 | Word-frequency analyzer | ▶️ Current (Unit 2.1) |
| 3 | Types, Methods, Interfaces, Errors, Packages, Generics | 3.1–3.16 | Library-management CLI | ⬜ Planned |
| 4 | Testing, Tooling & Debugging | 4.1–4.8 | Test suite + planted bugs | ⬜ Planned |
| 5 | Standard Library & I/O | 5.1–5.11 | Streaming log analyzer | ⬜ Planned |
| 6 | Data Structures, Algorithms & Complexity | 6.1–6.13 | DS library + grid shortest path | ⬜ Planned |
| 7 | Concurrency | 7.1–7.12 | Concurrent web crawler | ⬜ Planned |
| 8 | Networking, HTTP & RPC | 8.1–8.8 | Chat server + URL shortener API | ⬜ Planned |
| 9 | Databases, Persistence & Caching | 9.1–9.8 | URL shortener on PostgreSQL + cache | ⬜ Planned |
| 10 | Performance Engineering & Runtime Internals | 10.1–10.10 | Profile and optimise earlier projects | ⬜ Planned |
| 11 | Production Engineering | 11.1–11.8 | Productionise the URL shortener | ⬜ Planned |
| 12 | Distributed Systems & System Design | 12.1–12.10 | Event-driven order processing | ⬜ Planned |
| 13 | Geospatial Computing & Routing Algorithms | 13.1–13.9 | City routing on real OSM data | ⬜ Planned |
| 14 | Capstone: Production Routing Backend | 14.1–14.8 | The capstone itself | ⬜ Planned |

### Chapter 0 — Computing Foundations & Toolchain ✅

*Goal: understand what a running program physically is, before writing real Go.*

#### Topic 0A — From source code to a running process

- ✅ **Unit 0.1 — Source code to running process**
  - Sections: source → compiler → binary → process · compile time vs run time · compile errors vs panics · syntax vs type vs rule errors · go run vs go build · exit codes · cross-compilation (GOOS / GOARCH) · integer vs float vs constant division by zero · NaN and Inf

#### Topic 0B — How numbers are stored

- ✅ **Unit 0.2 — Bits, bytes, and memory**
  - Sections: bits and bytes · binary counting · the 2^n rule · hex and octal · Go number literals · Printf verbs and width · endianness · Unix file permissions in octal · KB vs KiB, Mbps vs MB/s
- ✅ **Unit 0.3 — Unsigned integers and overflow**
  - Sections: uint8…uint64 ranges · wraparound (modulo 2^n) · constant overflow vs run-time wrap · `%T` · why Go does not panic on overflow · use int for counts (P-1)
- ✅ **Unit 0.4 — Signed integers and two's complement**
  - Sections: the −128 place model · flip + add 1 · asymmetric ranges · same bits, different type · signed wrap · integer conversions `T(x)` · −MinInt and MinInt / −1 · Year 2038 problem

#### Topic 0C — The machine and its memory

- ✅ **Unit 0.5 — How the CPU runs your program**
  - Sections: fetch-decode-execute · program counter and jumps · registers · constant folding · memory hierarchy and latencies · caches and cache lines · spatial locality · signed vs unsigned instructions
- ✅ **Unit 0.6 — Stack and heap (first look)**
  - Sections: process memory areas · virtual address space and pages · stack frames and LIFO · stack pointer · return values copied out · heap and garbage collector (mark and sweep) · escape analysis idea · spec makes no stack promise · zero values · stack overflow is a fatal error · inlined frames in stack traces

#### Chapter 0 Project

- ✅ **numinfo CLI** — complete (final version handles negatives, MinInt64, and a sign switch)
  - Sections: os.Args · strconv.Atoi · validation at the edge (P-4) · stdout vs stderr and exit codes (P-3) · conversions and range checks · gofmt (P-5) · if/else hex rule with `uint64(-n)` (DT-70) · switch

### Chapter 1 — Core Language Fundamentals ✅

*Goal: know the exact rules of Go's building blocks.*

#### Topic 1A — Values and types

- ✅ **Unit 1.1 — Variables and zero values**
  - Sections: declaration forms (`var`, `:=`, grouped, multiple) · zero values · default types · `=` vs `:=` rules · two-phase assignment and swap · blank identifier · idiomatic choices
- ✅ **Unit 1.2 — Constants and untyped constants**
  - Sections: typed vs untyped constants · default types · representability · kinds of constants · exact huge precision · iota · MixedCaps naming (P-6)

#### Topic 1B — Operators and numbers

- ✅ **Unit 1.3 — Arithmetic, comparison, and logical operators**
  - Sections: integer division towards zero · remainder sign · the `7/2` constant trap · string comparison by bytes · short-circuit evaluation · `++` / `--` as statements · compound assignment
- ✅ **Unit 1.4 — Bitwise operators, shifts, and precedence**
  - Sections: AND, OR, XOR, AND NOT, NOT · shifts and arithmetic shift · shift-count rules · bit flags (P-7) · full precedence table · no power operator
- ✅ **Unit 1.5 — Floating-point numbers**
  - Sections: float32 vs float64 · why 0.1 is not exact · constants vs variables (0.1+0.2) · comparing with tolerance · the 2^53 limit · float → int truncation · Round / Floor / Ceil / Trunc · negative zero · money in paise (P-8)

#### Topic 1C — Control flow

- ✅ **Unit 1.6 — if, else, and switch**
  - Sections: bool-only conditions · if with a short statement · switch with a value · tagless switch and case order · fallthrough · no ternary operator · guard clauses (P-9)
- ✅ **Unit 1.7 — for loops**
  - Sections: three-part loop · condition-only loop · infinite loop · range over int (Go 1.22) · break / continue · labels · Go 1.22 per-iteration variables · float accumulation in loops

#### Topic 1D — Functions and their behaviour

- ✅ **Unit 1.8 — Functions**
  - Sections: syntax · pass by value · multiple results (not tuples) · `(result, error)` (P-10) · `(value, ok)` design · named results · variadic functions · functions as values · nil function values · recursion · built-in min / max · no defaults or overloading
- ✅ **Unit 1.9 — Scope and shadowing**
  - Sections: universe, package, file, and block scope · innermost-first lookup · shadowing · the `err` shadowing bug · shadowing built-ins and package names · predeclared identifiers vs keywords · scope starts after the declaration · keeping scopes small · shadow checks in linters
- ✅ **Unit 1.10 — Closures**
  - Sections: function literals capturing variables · captured variables are shared, not copied · functions that return functions (generators) · captured variables move to the heap · the classic loop-closure bug and the Go 1.22 fix (proved with go.mod) · when to use a struct instead
- ✅ **Unit 1.11 — defer**
  - Sections: when deferred calls run · LIFO order · arguments evaluated immediately vs closures · defer and named results (the 3 steps of return) · defer during panics · `os.Exit` skips defers · defer in loops · nil deferred functions · cost of defer · cleanup right after acquiring (P-13)

#### Topic 1E — Talking to the outside world

- ✅ **Unit 1.12 — Reading input**
  - Sections: arguments vs stdin vs files · stdin as a stream and EOF · `bufio.Scanner` line by line · `scanner.Err()` · trimming and converting · `fmt.Scan` and its traps · prompting · ask-until-valid loops · testing with pipes · the `run()` pattern (P-14)
- ✅ **Unit 1.13 — Random numbers** (verified through the project)
  - Sections: pseudo-random generators and seeds · `math/rand/v2` (IntN, ranges, Shuffle) · off-by-one in ranges · reproducible generators for tests · modulo bias · `crypto/rand` for secrets · choosing between them

#### Chapter 1 Project

- ⬜ **Number-guessing game + unit converter** with full input validation

### Chapter 2 — Composite Data & Memory ⬜

*Goal: master slices, strings, maps, structs, and pointers, where most real Go bugs live.*

#### Topic 2A — Arrays and slices

- ▶️ **Unit 2.1 — Arrays**
  - Sections: fixed size as part of the type · value semantics and copying · comparison · `[...]` length
- ⬜ **Unit 2.2 — Slices I: the slice header**
  - Sections: pointer, len, cap · backing arrays · slicing · aliasing
- ⬜ **Unit 2.3 — Slices II: growth**
  - Sections: `append` and growth · capacity traps · `copy` · full slice expression `a[lo:hi:max]` · nil vs empty slice · passing slices to functions (DT-75)
- ⬜ **Unit 2.4 — Slices III: working with slices**
  - Sections: 2D slices · the `slices` package · `clear` · insert and remove · memory leaks through sub-slices · range over slices

#### Topic 2B — Strings and text

- ⬜ **Unit 2.5 — Strings, bytes, and runes**
  - Sections: immutability · UTF-8 encoding · `len` counts bytes · indexing gives bytes · range gives runes · `%c` `%q` `%U`
- ⬜ **Unit 2.6 — Building and converting strings**
  - Sections: `strings` package · `strings.Builder` · `[]byte(s)` copies · `strconv` · `unicode` and `unicode/utf8`

#### Topic 2C — Maps

- ⬜ **Unit 2.7 — Maps I**
  - Sections: hash table intuition · create, read, write, delete · comma-ok · nil map write panic · random iteration order
- ⬜ **Unit 2.8 — Maps II**
  - Sections: sets with `map[T]struct{}` · map values are not addressable · `maps` package · not safe for concurrent writes

#### Topic 2D — Structs and pointers

- ⬜ **Unit 2.9 — Structs**
  - Sections: fields and literals · zero values · comparison · anonymous structs · struct tags (preview)
- ⬜ **Unit 2.10 — Struct memory layout**
  - Sections: alignment · padding · field order · `unsafe.Sizeof`
- ⬜ **Unit 2.11 — Pointers**
  - Sections: `&` and `*` · nil pointers and nil dereference panics · `new` · no pointer arithmetic
- ⬜ **Unit 2.12 — Value vs pointer semantics**
  - Sections: when to copy and when to share · returning pointers to locals is safe · escape analysis in practice

#### Chapter 2 Project

- ⬜ **Word-frequency analyzer** (Unicode-correct)

### Chapter 3 — Types, Methods, Interfaces, Errors, Packages, Generics ⬜

*Goal: organise programs with clean abstractions and boundaries.*

#### Topic 3A — Your own types

- ⬜ **Unit 3.1 — Named types**
  - Sections: type definitions vs aliases · underlying types · conversions between named types
- ⬜ **Unit 3.2 — Enums in Go**
  - Sections: iota on a named type · `String()` methods · invalid values

#### Topic 3B — Methods and interfaces

- ⬜ **Unit 3.3 — Methods**
  - Sections: value vs pointer receivers · method sets · addressability · method values and expressions
- ⬜ **Unit 3.4 — Interfaces I**
  - Sections: implicit satisfaction · small interfaces · `fmt.Stringer` · `io.Reader` / `io.Writer` preview
- ⬜ **Unit 3.5 — Interfaces II: interface values**
  - Sections: (type, value) pairs · the nil-interface trap · `any`
- ⬜ **Unit 3.6 — Type assertions and type switches**
  - Sections: comma-ok assertions · type switches · interface embedding

#### Topic 3C — Composition and type design

- ⬜ **Unit 3.7 — Embedding and composition**
  - Sections: field and method promotion · shadowing of promoted names · composition over inheritance
- ⬜ **Unit 3.8 — Designing types**
  - Sections: "make the zero value useful" (DT-48) · constructor functions `NewX` · options structs

#### Topic 3D — Errors and panics

- ⬜ **Unit 3.9 — Errors I**
  - Sections: the `error` interface · `errors.New` · `fmt.Errorf` · errors as values · guard clauses with errors
- ⬜ **Unit 3.10 — Errors II**
  - Sections: wrapping with `%w` · `errors.Is` / `errors.As` · sentinel vs typed errors · `errors.Join`
- ⬜ **Unit 3.11 — panic and recover**
  - Sections: when (not) to panic · recover in deferred functions · panics vs fatal errors

#### Topic 3E — Packages and modules

- ⬜ **Unit 3.12 — Packages**
  - Sections: exported names (capitalisation) · package naming · `internal/` · import cycles · `init()` and initialization order
- ⬜ **Unit 3.13 — Modules**
  - Sections: go.mod and go.sum · semantic versioning · minimal version selection · `go get`, `go mod tidy` · `replace` · workspaces · toolchain lines

#### Topic 3F — Generics and iterators

- ⬜ **Unit 3.14 — Generics I**
  - Sections: type parameters · constraints · `any` and `comparable` · type inference
- ⬜ **Unit 3.15 — Generics II**
  - Sections: `~` in constraints · generic data structures · when NOT to use generics
- ⬜ **Unit 3.16 — Iterators**
  - Sections: range over functions · `iter.Seq` and `iter.Seq2`

#### Chapter 3 Project

- ⬜ **Library-management CLI** with domain, storage, and interface packages

### Chapter 4 — Testing, Tooling & Debugging ⬜

*Goal: make verifying code a habit, not an afterthought.*

#### Topic 4A — Writing tests

- ⬜ **Unit 4.1 — Testing basics**
  - Sections: the `testing` package · test files · `go test` · table-driven tests · subtests
- ⬜ **Unit 4.2 — Test helpers and fixtures**
  - Sections: `t.Helper` · `t.Cleanup` · `t.Parallel` · `testdata` · golden files
- ⬜ **Unit 4.3 — Coverage and examples**
  - Sections: coverage reports · example functions as documentation
- ⬜ **Unit 4.4 — Designing for testability**
  - Sections: test doubles (fakes, stubs) · small interfaces as seams

#### Topic 4B — Measuring and fuzzing

- ⬜ **Unit 4.5 — Benchmarks**
  - Sections: `b.Loop` / `b.N` · `benchstat` · avoiding misleading benchmarks
- ⬜ **Unit 4.6 — Fuzzing**

#### Topic 4C — Tools and debugging

- ⬜ **Unit 4.7 — Static analysis**
  - Sections: `go vet` · staticcheck · golangci-lint · gofmt / goimports · govulncheck
- ⬜ **Unit 4.8 — Debugging**
  - Sections: Delve · reading stack traces and panics · a systematic debugging method

#### Chapter 4 Project

- ⬜ **Full test suite and benchmarks for Project 3**, then find planted bugs from failing tests

### Chapter 5 — Standard Library & I/O ⬜

*Goal: use Go's strong standard library instead of reaching for dependencies.*

#### Topic 5A — I/O foundations

- ⬜ **Unit 5.1 — Readers and writers**
  - Sections: `io.Reader` / `io.Writer` as a design idea · `io.Copy` · composing readers and writers
- ⬜ **Unit 5.2 — Files**
  - Sections: `os` · permissions · `bufio` · reading large files with constant memory
- ⬜ **Unit 5.3 — Paths and file systems**
  - Sections: `path/filepath` · `io/fs` · `embed` (`//go:embed`)

#### Topic 5B — Data formats

- ⬜ **Unit 5.4 — encoding/json**
  - Sections: struct tags · omitempty · streaming decoders · custom marshalling · number precision (DT-66)
- ⬜ **Unit 5.5 — CSV and binary formats**
  - Sections: `encoding/csv` · `encoding/binary` · byte order in practice (DT-16)

#### Topic 5C — Time, command-line tools, and logging

- ⬜ **Unit 5.6 — time**
  - Sections: durations · monotonic clock · time zones · formatting with the reference time · timers and tickers
- ⬜ **Unit 5.7 — Command-line tools**
  - Sections: `flag` · `os/signal` · `os/exec` · exit codes
- ⬜ **Unit 5.8 — Logging with log/slog**

#### Topic 5D — Text and numbers

- ⬜ **Unit 5.9 — Text processing**
  - Sections: `strings` / `bytes` deep dive · `regexp` · `text/template` and `html/template`
- ⬜ **Unit 5.10 — Exact numbers and secure randomness**
  - Sections: `math/big` · decimal handling for money · `crypto/rand`

#### Topic 5E — Learning from the source

- ⬜ **Unit 5.11 — Reading standard-library source code**

#### Chapter 5 Project

- ⬜ **Streaming log-analysis CLI** with JSON reports

### Chapter 6 — Data Structures, Algorithms & Complexity ⬜

*Goal: the computer science behind the routing capstone.*

#### Topic 6A — Tools for analysis

- ⬜ **Unit 6.1 — Big-O**
  - Sections: time and space complexity · amortized analysis (append revisited)
- ⬜ **Unit 6.2 — Recursion**
  - Sections: recursion vs iteration · recursion depth in Go (DT-76)

#### Topic 6B — Linear structures and hashing

- ⬜ **Unit 6.3 — Lists, stacks, queues**
  - Sections: linked lists · stacks · queues and deques · ring buffers
- ⬜ **Unit 6.4 — Hash tables from scratch**
  - Sections: hashing · collisions · load factor · resizing

#### Topic 6C — Searching and sorting

- ⬜ **Unit 6.5 — Binary search and its variants**
- ⬜ **Unit 6.6 — Sorting**
  - Sections: insertion, merge, quick, heap sort · stability · `slices.Sort` / `slices.SortFunc`

#### Topic 6D — Trees and heaps

- ⬜ **Unit 6.7 — Trees**
  - Sections: binary search trees · balanced trees (AVL / red-black concepts) · B-trees and databases
- ⬜ **Unit 6.8 — Heaps and priority queues**
  - Sections: binary heaps · `container/heap`
- ⬜ **Unit 6.9 — Tries and string algorithms basics**

#### Topic 6E — Graphs

- ⬜ **Unit 6.10 — Graph basics**
  - Sections: adjacency list vs matrix · BFS · DFS · topological sort
- ⬜ **Unit 6.11 — Shortest paths**
  - Sections: Dijkstra · union-find

#### Topic 6F — Techniques and real-world speed

- ⬜ **Unit 6.12 — Problem-solving techniques**
  - Sections: dynamic programming introduction · two pointers · sliding window
- ⬜ **Unit 6.13 — Caches and memory-friendly design**
  - Sections: LRU cache · cache-friendly data layout, measured with benchmarks

#### Chapter 6 Project

- ⬜ **Generic data-structures library + grid-city shortest-path solver**

### Chapter 7 — Concurrency ⬜

*Goal: write correct, leak-free concurrent programs.*

#### Topic 7A — Foundations

- ⬜ **Unit 7.1 — The operating-system view**
  - Sections: processes and threads · scheduling · concurrency vs parallelism · shared state · what a race is
- ⬜ **Unit 7.2 — Goroutines**
  - Sections: starting goroutines · a first look at the scheduler · goroutine stacks (DT-35)

#### Topic 7B — Channels

- ⬜ **Unit 7.3 — Channels**
  - Sections: unbuffered vs buffered · close · range over a channel · nil channels
- ⬜ **Unit 7.4 — select**
  - Sections: select · timeouts · `time.After`

#### Topic 7C — Shared-memory synchronization

- ⬜ **Unit 7.5 — The sync package**
  - Sections: WaitGroup · Mutex · RWMutex · Once / OnceFunc / OnceValue · Cond
- ⬜ **Unit 7.6 — sync/atomic and typed atomics**
- ⬜ **Unit 7.7 — The Go memory model**
  - Sections: happens-before · visibility

#### Topic 7D — Correctness

- ⬜ **Unit 7.8 — Races, deadlocks, and leaks**
  - Sections: race detector · deadlocks · goroutine leaks

#### Topic 7E — Cancellation and patterns

- ⬜ **Unit 7.9 — context**
  - Sections: cancellation · deadlines · values (and when not to use them)
- ⬜ **Unit 7.10 — Concurrency patterns**
  - Sections: worker pools · pipelines · fan-out / fan-in · semaphores · `errgroup` · backpressure · rate limiting

#### Topic 7F — Advanced tools and testing

- ⬜ **Unit 7.11 — Advanced tools**
  - Sections: `sync.Pool` · `sync.Map` · false sharing and cache lines (DT-32)
- ⬜ **Unit 7.12 — Testing concurrent code**
  - Sections: race-free tests · `testing/synctest`

#### Chapter 7 Project

- ⬜ **Concurrent web crawler** with bounded parallelism, cancellation, and rate limiting

### Chapter 8 — Networking, HTTP & RPC ⬜

*Goal: build production-shaped network services.*

#### Topic 8A — Network fundamentals

- ⬜ **Unit 8.1 — How networks work**
  - Sections: IP and ports · TCP handshake · UDP · DNS · TLS overview
- ⬜ **Unit 8.2 — Sockets with the net package**
  - Sections: listen, accept, dial · deadlines · a TCP chat server

#### Topic 8B — HTTP

- ⬜ **Unit 8.3 — HTTP semantics**
  - Sections: methods · status codes · headers · keep-alive · HTTP/2
- ⬜ **Unit 8.4 — HTTP servers**
  - Sections: handlers · `ServeMux` routing with methods and wildcards · middleware
- ⬜ **Unit 8.5 — HTTP clients**
  - Sections: timeouts · connection reuse · closing bodies

#### Topic 8C — API design and robustness

- ⬜ **Unit 8.6 — REST API design**
  - Sections: resources · versioning · pagination · idempotency · error formats
- ⬜ **Unit 8.7 — Robust services**
  - Sections: timeouts everywhere · graceful shutdown · `httptest`

#### Topic 8D — RPC

- ⬜ **Unit 8.8 — Protocol Buffers and gRPC**
  - Sections: unary and streaming calls · interceptors · deadlines

#### Chapter 8 Project

- ⬜ **TCP chat server, then a URL-shortener REST API**

### Chapter 9 — Databases, Persistence & Caching ⬜

*Goal: store data correctly and fast.*

#### Topic 9A — SQL and schema design

- ⬜ **Unit 9.1 — Relational model and SQL**
  - Sections: SELECT, JOIN, GROUP BY · schema design · normalisation
- ⬜ **Unit 9.2 — Indexes and query plans**
  - Sections: B-tree indexes · `EXPLAIN`

#### Topic 9B — Go and databases

- ⬜ **Unit 9.3 — database/sql and pgx**
  - Sections: connection pools · Query / QueryRow / Exec · scanning · NULLs · context
- ⬜ **Unit 9.4 — Transactions**
  - Sections: isolation levels · anomalies · locking
- ⬜ **Unit 9.5 — Migrations and safety**
  - Sections: migrations · prepared statements · SQL injection

#### Topic 9C — Spatial data

- ⬜ **Unit 9.6 — PostgreSQL + PostGIS introduction**
  - Sections: geometry types · spatial indexes

#### Topic 9D — Caching

- ⬜ **Unit 9.7 — Caching strategies**
  - Sections: cache-aside · TTL · invalidation · stampedes · Redis

#### Topic 9E — Testing with databases

- ⬜ **Unit 9.8 — Integration testing with real databases in containers**

#### Chapter 9 Project

- ⬜ **URL shortener on PostgreSQL + cache**, with analytics

### Chapter 10 — Performance Engineering & Runtime Internals ⬜

*Goal: explain and prove performance instead of guessing.*

#### Topic 10A — Measurement

- ⬜ **Unit 10.1 — Measure first**
  - Sections: benchmark rigour · `benchstat` · realistic workloads
- ⬜ **Unit 10.2 — Profiling with pprof**
  - Sections: CPU · heap · allocations · block · mutex · goroutines
- ⬜ **Unit 10.3 — Execution tracing with go tool trace**

#### Topic 10B — Compiler and allocations

- ⬜ **Unit 10.4 — Escape analysis**
  - Sections: `-gcflags=-m` · reducing allocations · large locals on the heap (DT-42)
- ⬜ **Unit 10.5 — The compiler**
  - Sections: inlining · bounds-check elimination · SSA · reading assembly (`-gcflags=-S`) · register calling convention (DT-38)

#### Topic 10C — Runtime internals

- ⬜ **Unit 10.6 — Garbage collector**
  - Sections: concurrent mark-sweep · GOGC · GOMEMLIMIT · GC tuning
- ⬜ **Unit 10.7 — Scheduler**
  - Sections: G / M / P · work stealing · preemption · stack growth
- ⬜ **Unit 10.8 — Data-structure internals**
  - Sections: maps · strings · slices · interfaces · channels

#### Topic 10D — Advanced tools

- ⬜ **Unit 10.9 — Profile-guided optimisation (PGO)**
- ⬜ **Unit 10.10 — Low-level tools**
  - Sections: `unsafe` and why to avoid it · `runtime/metrics` · GODEBUG

#### Chapter 10 Project

- ⬜ **Profile and optimise Projects 5 and 9** with benchmark evidence

### Chapter 11 — Production Engineering ⬜

*Goal: turn working code into operable software.*

#### Topic 11A — Configuration and security

- ⬜ **Unit 11.1 — Configuration and secrets**
  - Sections: flags · environment variables · config files · secret handling
- ⬜ **Unit 11.2 — Security**
  - Sections: input validation · injection · XSS / CSRF · TLS · password hashing · Go crypto packages · govulncheck and the supply chain
- ⬜ **Unit 11.3 — Authentication**
  - Sections: sessions · JWT · OAuth2 / OpenID Connect
- ⬜ **Unit 11.4 — Authorisation**
  - Sections: roles · permissions

#### Topic 11B — Observability

- ⬜ **Unit 11.5 — Logs, metrics, and traces**
  - Sections: structured logs · Prometheus metrics · OpenTelemetry tracing · health and readiness checks

#### Topic 11C — Delivery and operations

- ⬜ **Unit 11.6 — Containers**
  - Sections: multi-stage Docker builds · `CGO_ENABLED=0` · minimal images · version info with `-ldflags -X` · stripping binaries (DT-12)
- ⬜ **Unit 11.7 — CI/CD pipelines**
  - Sections: tests · linters · race detector · vulnerability checks
- ⬜ **Unit 11.8 — Kubernetes basics**
  - Sections: deployments · probes · rolling updates · config · Go in containers (GOMAXPROCS, memory limits)

#### Chapter 11 Project

- ⬜ **Fully productionise the URL shortener**

### Chapter 12 — Distributed Systems & System Design ⬜

*Goal: design systems that keep working when parts fail.*

#### Topic 12A — Fundamentals

- ⬜ **Unit 12.1 — Why distributed systems are hard**
  - Sections: partial failures · latency · network partitions
- ⬜ **Unit 12.2 — Time and ordering**
  - Sections: clocks · Lamport clocks

#### Topic 12B — Distributing data

- ⬜ **Unit 12.3 — Replication and partitioning**
  - Sections: replication · sharding · consistent hashing
- ⬜ **Unit 12.4 — CAP / PACELC and consistency models**
- ⬜ **Unit 12.5 — Consensus concepts: Raft**

#### Topic 12C — Communication and reliability

- ⬜ **Unit 12.6 — Messaging**
  - Sections: message queues · event-driven design · delivery guarantees · ordering · outbox pattern
- ⬜ **Unit 12.7 — Reliability patterns**
  - Sections: idempotency keys · retries with backoff and jitter · timeouts · circuit breakers · bulkheads
- ⬜ **Unit 12.8 — Traffic control**
  - Sections: rate-limiting algorithms · load balancing

#### Topic 12D — Architecture

- ⬜ **Unit 12.9 — Architecture patterns**
  - Sections: caching at scale · CQRS · event sourcing · sagas
- ⬜ **Unit 12.10 — System design method**
  - Sections: requirements · estimates · APIs · data models · architecture · failure modes

#### Chapter 12 Project

- ⬜ **Event-driven order-processing system** with idempotent consumers

### Chapter 13 — Geospatial Computing & Routing Algorithms ⬜

*Goal: the domain knowledge for the routing capstone.*

#### Topic 13A — Geography in code

- ⬜ **Unit 13.1 — Coordinates**
  - Sections: latitude / longitude · WGS84 · haversine distance · projections
- ⬜ **Unit 13.2 — Spatial indexing**
  - Sections: geohash · quadtrees · R-trees · S2 / H3 concepts

#### Topic 13B — Map data and the road graph

- ⬜ **Unit 13.3 — OpenStreetMap data**
  - Sections: nodes, ways, relations, tags · reading OSM files
- ⬜ **Unit 13.4 — Building a road graph**
  - Sections: directed edges · one-way roads · speeds · turn restrictions
- ⬜ **Unit 13.5 — Snapping a point to the nearest road**

#### Topic 13C — Routing algorithms

- ⬜ **Unit 13.6 — Faster searches**
  - Sections: A\* and admissible heuristics · bidirectional Dijkstra
- ⬜ **Unit 13.7 — Preprocessing for speed**
  - Sections: ALT (landmarks) · contraction hierarchies

#### Topic 13D — Engineering the graph

- ⬜ **Unit 13.8 — Compact graph layouts**
  - Sections: memory-efficient layouts · memory-mapped graph files
- ⬜ **Unit 13.9 — Routes for users**
  - Sections: route reconstruction · geometry · polyline encoding · travel-time estimates

#### Chapter 13 Project

- ⬜ **Point-to-point routing on a real city's OSM extract**

### Chapter 14 — Capstone: Production Routing Backend ⬜

*Goal: independently design, build, and operate a serious routing service.*

#### Topic 14A — Design

- ⬜ **Unit 14.1 — Requirements and design document** with trade-off decisions

#### Topic 14B — Build

- ⬜ **Unit 14.2 — Ingestion pipeline and storage**
- ⬜ **Unit 14.3 — Graph preprocessing and fast routing**
- ⬜ **Unit 14.4 — Service API**
  - Sections: HTTP / gRPC · nearest-node lookup · caching · concurrency
- ⬜ **Unit 14.5 — Hot reload of graph data and failure handling**

#### Topic 14C — Prove and operate

- ⬜ **Unit 14.6 — Load testing, profiling, and optimisation**
- ⬜ **Unit 14.7 — Observability, deployment, and scalability**
- ⬜ **Unit 14.8 — Final senior-level architecture review**

## Stage 0 — Computing Foundations & Toolchain

### Unit 0.1 — From source code to running process

**One-line summary:** You write text (source code). The compiler translates it once into machine code (a binary file). When you run that file, the operating system creates a process, and the CPU executes the instructions.

**Mental model (kitchen analogy):**

- Source code = a recipe written in English. Humans can read it. The CPU cannot.
- Compiler = a translator who converts the full recipe into the CPU's own language before cooking starts.
- Binary / executable = the translated recipe, saved as a file. You can run it many times without translating again.
- Process = the actual cooking happening right now, with its own kitchen space (memory).
- CPU = the cook. It follows very small, simple instructions extremely fast.

**The pipeline:**

```
main.go (text)  --go build-->  hello (binary file)  --./hello-->  process running on CPU
  [you write]      [compile time]      [stored on disk]    [run time]
```

**Key words:**

- **Compile time** = when the compiler is checking and translating your code. The program is not running yet.
- **Run time** = when the program is actually executing as a process.
- **Compile error** = the compiler refuses to make a binary. No program exists to run.
- **Runtime error (panic in Go)** = the binary was made and started, but something went wrong while running.
- **Exit code** = a small number a process gives back to the operating system when it ends. 0 means success. Non-zero means some failure.

**Go is a compiled language.** The whole program is translated to machine code before it runs. Python (normally) is different: an interpreter program reads and executes your code line by line at run time.

**`go run` vs `go build`:**

| Command | What it does | Binary left behind? |
| --- | --- | --- |
| `go build` | Compiles and saves the binary in the current folder | Yes |
| `go run main.go` | Compiles into a temporary folder, runs it, then removes the temporary binary | No |

`go run` is NOT an interpreter. It still compiles fully. It just hides the binary from you.

**Example program:**

```go
package main

import "fmt"

func main() {
    fmt.Println("Hello, Go")
}
```

- `package main` + `func main()` = this package becomes an executable program, and `main` is where execution starts.
- When `main` returns normally, the process exits with code 0.

**Compile time vs run time — the division example:**

```go
fmt.Println(10 / 0)
```

Compile error: `invalid operation: division by zero`. The compiler can see both numbers, so it refuses to build. No binary, no process.

```go
x := 0
fmt.Println(10 / x)
```

This compiles. At run time it panics: `panic: runtime error: integer divide by zero`, prints a stack trace, and the process exits with code 2. (`go run` shows this as `exit status 2`.)

Lesson: the earlier an error is caught, the cheaper it is. Compile errors are caught before any user ever runs your code.

**Common beginner mistakes:**

- Thinking `go run` interprets code like Python. It compiles.
- Thinking the `.go` file itself is what the CPU runs. The CPU only runs machine code.
- Thinking "it compiled" means "it is correct". The compiler catches only some errors. Logic mistakes and many runtime failures are still possible.
- Thinking a binary built on Windows runs on Linux. Machine code is specific to an OS and CPU type (see Deep & Tricky: cross-compilation).

#### Correction 1 — Syntax error is only ONE kind of compile error

Syntax = grammar. Think of English:

- "Dog the rice ate the." Grammar is broken. That is like a **syntax error**.
- "The rice ate the dog." Grammar is perfect, but the meaning breaks a rule. That is like a **type error or rule error**. The compiler still refuses.

The compiler works roughly in steps: first it checks grammar (parsing), then it checks meaning and rules (type checking). Failing ANY step = compile error.

| Code | Kind of compile error | Go's message starts like |
| --- | --- | --- |
| `fmt.Println("hi"` (missing `)`) | Syntax error | `syntax error: ...` |
| `name := "Ravi"; age := 30; fmt.Println(name + age)` | Type error (string + int) | `invalid operation: name + age (mismatched types string and int)` |
| `fmt.Println(100 / 0)` | Rule: constant divisor must not be zero | `invalid operation: division by zero` |
| `import "os"` never used | Rule: no unused imports | `"os" imported and not used` |
| `x := 10` never used | Rule: no unused local variables | `declared and not used: x` |

Tip: the Go compiler itself prints the words `syntax error` only for real grammar problems. Read the message; it tells you the kind.

#### Correction 2 — Integer vs float division by zero

| Code (variables) | Result |
| --- | --- |
| `a, b := 10, 0` then `a / b` | Run-time panic: integer divide by zero |
| `a, b := 5.0, 0.0` then `a / b` | `+Inf` |
| `a, b := -5.0, 0.0` then `a / b` | `-Inf` |
| `a, b := 0.0, 0.0` then `a / b` | `NaN` ("Not a Number") |

Why the difference: every bit pattern of an int is an ordinary number, so there is no value that means "infinity". Float numbers follow the IEEE 754 standard, which reserves special values: `+Inf`, `-Inf`, and `NaN`. So a float division has a legal answer to give, and an integer division does not.

Danger: `NaN` and `Inf` spread silently. `Inf + 1` is still `Inf`. A price calculation can quietly become `NaN` and get saved to a database without any crash. A panic is loud; a `NaN` is silent.

#### Correction 3 — A binary depends on BOTH the OS and the CPU

- CPU type decides which machine instructions are valid (for example amd64 vs arm64).
- OS decides the executable file format (Windows uses PE files, `.exe`; Linux uses ELF files) and how the program asks the OS for services like printing or opening files. These requests are called **system calls**.
- So Go has two settings: `GOOS=linux` (which OS) and `GOARCH=amd64` (which CPU). Example: `GOOS=linux GOARCH=amd64 go build` on Windows gives a binary for a normal Linux server.

#### Correction 4 — Read the WHOLE compiler message (from retest 2)

`invalid operation:` starts both type errors and rule errors. The words in brackets decide:

- `invalid operation: "total" + 5 (mismatched types untyped string and untyped int)` → type error
- `invalid operation: division by zero` → rule error
- Anything starting `syntax error:` → syntax error (for example an extra `}` after `main`)

### Unit 0.2 — Bits, bytes, and how numbers live in memory

**One-line summary:** Everything in a computer is stored as bits (0 or 1). Eight bits make a byte. Memory is a long row of numbered boxes, each holding one byte. With n bits you get exactly 2^n different patterns.

**Mental model:**

- A **bit** = one light switch: off (0) or on (1).
- A **byte** = a row of 8 switches.
- **Memory (RAM)** = a very long street of houses. Each house holds exactly one byte. Each house has a number: its **address**.
- A bigger value (like a 64-bit number) lives in several neighbouring houses (8 bytes in a row).

**Why binary?** Electronic circuits can reliably tell two states apart (voltage high or low). Telling 10 levels apart reliably would be much harder and error-prone.

**Binary place values** (right to left, each place doubles):

| Place | 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 13 = | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 1 |

13 = 8 + 4 + 1, so 13 in binary is `1101` (or `00001101` as a full byte).

**The 2^n rule:** n bits give 2^n different patterns.

| Bits | Patterns | If used for 0 upwards |
| --- | --- | --- |
| 1 | 2 | 0 to 1 |
| 8 (1 byte) | 256 | 0 to 255 |
| 16 | 65,536 | 0 to 65,535 |
| 32 | about 4.29 billion | 0 to 4,294,967,295 |
| 64 | about 1.8 × 10^19 | 0 to 18,446,744,073,709,551,615 |

Largest value = 2^n − 1, because one pattern is used for zero.

**Hexadecimal (hex):** base 16, digits 0–9 then A–F (A=10 … F=15). One hex digit = exactly 4 bits, so one byte = exactly 2 hex digits. `0xFF` = `1111 1111` = 255. Hex is just a shorter way to write bits. Used for memory addresses, colours (`#FF8800`), hashes, and IDs.

**Connection to Unit 0.1:** an integer type uses ALL of its 2^n patterns for normal numbers. No pattern is left over to mean "infinity". The float format deliberately reserves some patterns for `Inf` and `NaN`.

**Go number literals** (all these are the same number, 13):

```go
a := 13      // decimal
b := 0b1101  // binary (prefix 0b)
c := 0xD     // hex (prefix 0x)
d := 0o15    // octal, base 8 (prefix 0o)
e := 1_3     // underscores are allowed between digits, for readability
```

**Printing in different bases with `fmt.Printf`:**

| Verb | Meaning | `fmt.Printf(verb, 13)` prints |
| --- | --- | --- |
| `%d` | decimal | `13` |
| `%b` | binary | `1101` |
| `%08b` | binary, padded with zeros to width 8 | `00001101` |
| `%x` / `%X` | hex, lower / upper case | `d` / `D` |
| `%o` | octal | `15` |

`Printf` does not add a newline by itself. Add `\n` at the end of the format string.

**Width with spaces vs zeros:** `%3d` means "at least 3 characters wide, fill with spaces on the left". `%03d` means the same but fill with zeros. So `fmt.Printf("%3d|%03d\n", 7, 7)` prints `   7|007 ` (two spaces before 7). Useful for lining up columns in tables.

**Units of size:**

- b = bit, B = byte. Internet speed is in megabits per second (Mbps); file sizes are in megabytes (MB). 100 Mbps ≈ 12.5 MB/s (divide by 8).
- KB = 1000 bytes (standard), KiB = 1024 bytes. Many tools mix these; the difference grows with size.

**Common mistakes:**

- Saying a byte holds values up to 256. It holds 256 *different* values, 0 to 255.
- Thinking `0xFF` and `255` are different numbers. Same number, different way of writing.
- Writing a number with a leading zero, like `010`, expecting ten. In Go this is octal (8). See DT-13.
- Mixing up bits and bytes (Mbps vs MB/s).

**Two ways to convert decimal → binary (both correct):**

- *Subtract place values:* 42 → 32 fits (10 left), 8 fits (2 left), 2 fits → `101010`.
- *Repeated division by 2* (your method in B1): divide, write the remainder, repeat; read the remainders bottom to top. Same method with 16 gives hex (200 ÷ 16 = 12 rem 8 → `C8`).

**Binary → hex shortcut:** group bits in 4s from the right, convert each group. `0010 1010` → `2` `A` → `0x2A` = 42. No counting tables needed.

**Octal = groups of 3 bits.** One octal digit = exactly 3 bits (0–7). This is why octal is still used for Unix file permissions: each permission group (owner, group, others) is 3 bits: r = 4, w = 2, x = 1.

| `ls -l` shows | Bits | Octal |
| --- | --- | --- |
| `rwx` | 111 | 7 |
| `r-x` | 101 | 5 |
| `rw-` | 110 | 6 |
| `r--` | 100 | 4 |

So `rwxr-xr-x` (your binaries in F3) = `0o755`. In Go you pass this to functions like `os.WriteFile(name, data, 0o644)`.

### Unit 0.3 — Unsigned integers and overflow

**One-line summary:** A fixed-size integer has a fixed number of patterns. When a run-time calculation goes past the end, Go does NOT panic; the value wraps around, like a car odometer. When a constant goes past the end, the compiler refuses.

**Mental model — the odometer:** A 3-digit odometer shows 000 to 999. At 999, one more km shows 000. There is no 4th digit to hold the 1. A `uint8` is an 8-bit odometer: 255 + 1 → 0, and 0 − 1 → 255.

**Unsigned integer types** (unsigned = no minus sign, only 0 and above):

| Type | Bits | Range |
| --- | --- | --- |
| `uint8` (= `byte`) | 8 | 0 to 255 |
| `uint16` | 16 | 0 to 65,535 |
| `uint32` | 32 | 0 to 4,294,967,295 |
| `uint64` | 64 | 0 to 18,446,744,073,709,551,615 |
| `uint` | 32 or 64 (platform) | 64 on your Mac |

Go gives the limits as constants: `math.MaxUint8`, `math.MaxUint16`, `math.MaxUint32`, `math.MaxUint64`.

**The wraparound rule (guarantee):** for unsigned integers, `+`, `−`, `*` are calculated modulo 2^n. "Modulo" = keep only the remainder after dividing by 2^n. In bit terms: the true answer may need a 9th bit; that bit is simply thrown away.

| Run-time calculation (uint8) | True answer | Stored result | Why |
| --- | --- | --- | --- |
| 255 + 1 | 256 | 0 | 256 mod 256 |
| 200 + 200 | 400 | 144 | 400 − 256 |
| 0 − 1 | −1 | 255 | wraps backwards |
| 16 \* 16 | 256 | 0 | 256 mod 256 |

Binary view of 255 + 1: `1111 1111` + `1` = `1 0000 0000` (9 bits). Keep the lowest 8 bits: `0000 0000` = 0.

**Constants vs run time — "who calculates?" again:**

| Code | What happens |
| --- | --- |
| `var b uint8 = 255` then `b = b + 1` | Runs, `b` becomes 0 (wraps silently) |
| `var c uint8 = 256` | Compile error: constant 256 overflows uint8 |
| `const x uint8 = 255` then `x + 1` | Compile error: a typed constant expression is checked too |

The compiler can check constants because it knows their exact values. It does not know what a variable will hold at run time, so it cannot check `b + 1`.

**`%T` prints the type:** `fmt.Printf("%T\n", g)` prints `uint8`. When you write `g := f + f` and `f` is `uint8`, the result is also `uint8`. The result does not get bigger automatically to fit.

**Why no panic?** CPUs wrap naturally in hardware; checking every `+` would slow down every program. Go chose defined, predictable wrapping instead. The cost: overflow bugs are silent, like NaN.

**Real-world shape of the bug:** a warehouse stores `stock` as an unsigned number. `stock = 5`, a customer orders 7, code does `stock - ordered`. Instead of an error, stock becomes a huge positive number (for uint8, 254), and the system happily sells items that do not exist.

**Common mistakes:**

- Expecting a panic on overflow. Go never panics for integer overflow.
- Expecting the result type to grow (`uint8 + uint8` → still `uint8`).
- Using unsigned types just because a value "should never be negative". Subtraction can still go below zero, and then it wraps to a huge number instead of showing a clear negative value. See P-1.
- Thinking the compiler catches every overflow. It only catches constants.

### Unit 0.4 — Signed integers and two's complement

**One-line summary:** Signed integers store negative numbers using "two's complement": the top bit has a NEGATIVE place value. The same bits mean different numbers depending on the type. Signed overflow also wraps silently in Go.

**The mental model — the top place value is negative.** For `int8`:

| Place | **−128** | 64 | 32 | 16 | 8 | 4 | 2 | 1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `0111 1111` | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `1000 0000` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `1111 1111` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |

- `0111 1111` = 64+32+16+8+4+2+1 = **127** (largest int8)
- `1000 0000` = −128 (smallest int8)
- `1111 1111` = −128 + 127 = **−1**

If the top bit is 1, the number is negative. That is why the top bit is often called the "sign bit", but it is not just a sign: it has the weight −128.

**Range:** n bits → −2^(n−1) to 2^(n−1) − 1. The 256 patterns of 8 bits = 128 negatives + zero + 127 positives. One extra negative, because zero uses one of the "non-negative" patterns.

| Type | Range |
| --- | --- |
| `int8` | −128 to 127 |
| `int16` | −32,768 to 32,767 |
| `int32` (= `rune`) | about −2.1 billion to 2.1 billion (2,147,483,647) |
| `int64` | about ±9.2 × 10^18 (9,223,372,036,854,775,807) |
| `int` | 64 bits on your Mac |

Constants: `math.MaxInt8`, `math.MinInt8`, … `math.MaxInt64`, `math.MinInt64`.

**Making a negative number: flip all bits, then add 1.** 5 = `0000 0101` → flip → `1111 1010` → add 1 → `1111 1011` = −5. Check: −128+64+32+16+8+2+1 = −5. The same steps turn −5 back into 5.

**Why this design won (and the simple "sign bit + size" idea lost):**

- A simple sign bit gives two zeros (`+0` = `0000 0000` and `−0` = `1000 0000`). Wasteful and confusing.
- With two's complement, ONE addition circuit works for both signed and unsigned numbers. `1111 1111 + 0000 0001 = 0000 0000`: as uint8 that is 255 + 1 = 0 (wrap); as int8 it is −1 + 1 = 0 (correct!). Same bits, same circuit, different meaning.

**Bits have no meaning without a type.** `1111 1011` is 251 as `uint8` and −5 as `int8`. The type tells Go how to read the bits.

**Signed overflow wraps too (guarantee):**

| Run-time (int8) | True answer | Stored |
| --- | --- | --- |
| 127 + 1 | 128 | −128 |
| −128 − 1 | −129 | 127 |
| 100 + 100 | 200 | −56 |

**Converting between integer types: `T(x)`.** `uint8(x)` means "give me x as a uint8". Between same-size integer types the bits stay the same; only the meaning changes:

```go
var x int8 = -5
fmt.Printf("%08b %d\n", uint8(x), uint8(x)) // 11111011 251
```

Careful: `uint8(-5)` with a constant is a compile error (the compiler knows −5 cannot be a uint8). With a variable it reinterprets the bits.

**`%b` on a negative number does NOT show the stored bits.** `fmt.Printf("%b", int8(-5))` prints `-101` (a minus sign + the size). To see the real two's-complement bits, convert to the unsigned type of the same size first.

**Real-world signed overflow:**

- **Year 2038 problem:** many systems store time as a signed 32-bit count of seconds since 1 Jan 1970. The max, 2,147,483,647 seconds, is reached on 19 January 2038; the next second wraps to a negative number (a date in 1901). Go's `time` package uses 64-bit values, but databases, file formats, and older C code may not.
- **YouTube, 2014:** the view counter of a very popular video passed 2,147,483,647 (max int32), and YouTube moved the counter to 64 bits.
- **Boeing 787, 2015:** a US aviation safety directive required power cycling because generator control units could fail after 248 days of continuous power. This matches a signed 32-bit counter of hundredths of a second: 2,147,483,647 / 100 seconds ≈ 248.5 days.

**Common mistakes:**

- Thinking the top bit is "just a minus sign" (`1000 0101` is not −5).
- Expecting `int8` to go up to 128, or expecting a symmetric range.
- Expecting `%b` to show two's-complement bits for negative numbers.
- Thinking `-x` is always positive when `x` is negative (see DT-24).

### Unit 0.5 — How the CPU runs your program

**One-line summary:** The CPU repeats one simple loop billions of times per second: fetch the next instruction from memory, decode it, execute it, move on. It works on tiny, very fast storage slots called registers, and waits a long time whenever it needs data from RAM. Caches exist to hide that wait.

**The fetch → decode → execute loop:**

1. **Fetch:** read the next instruction from memory. A special register, the **program counter (PC)**, holds the address of that instruction.
2. **Decode:** work out what the instruction means ("add these two registers").
3. **Execute:** do it.
4. Move the PC to the next instruction, or somewhere else if the instruction was a **jump**.

`if`, loops, and function calls are all built from jumps: "if this comparison is true, set the PC to that address".

**Registers:** a few very fast storage slots inside the CPU. arm64 (your Mac) has 31 general-purpose 64-bit registers; amd64 has 16. The CPU can only do arithmetic on values in registers, so data must be loaded from memory into registers first, and stored back afterwards.

**What `c := a + b` roughly becomes** (simplified, not real assembly):

```
LOAD  R1, [address of a]    // copy a from memory into register R1
LOAD  R2, [address of b]
ADD   R3, R1, R2            // R3 = R1 + R2
STORE R3, [address of c]    // copy result back to memory
```

The compiler is clever: it often keeps values in registers and skips loads and stores, and if `a` and `b` are constants it just writes the answer (see DT-30).

**The memory hierarchy (kitchen analogy, rough orders of magnitude):**

| Level | Kitchen analogy | Rough time to get data | Typical size |
| --- | --- | --- | --- |
| Registers | In your hand | under 1 ns | a few hundred bytes total |
| L1 cache | On the kitchen counter | about 1 ns | tens to a few hundred KB |
| L2 / L3 cache | In the fridge / store room | about 3–40 ns | MBs |
| RAM | Kirana shop down the road | about 100 ns | GBs |
| SSD | Wholesale market across the city | tens to hundreds of µs | hundreds of GB |

(1 ns = one billionth of a second; 1 µs = 1000 ns.) Exact numbers vary by machine; the important point is the RATIO: RAM is roughly 100 times slower than L1, and an SSD is roughly 1000 times slower again.

**Caches and cache lines:** the CPU keeps recently used data in caches automatically. Data moves from RAM to cache in fixed-size chunks called **cache lines** (64 bytes on most x86 machines; check yours with `sysctl hw.cachelinesize`). When you read one byte, its neighbours come along for free.

**Why a Go programmer cares:**

- Reading memory **in order** (like walking through an array or slice) is fast: each cache line brings the next values with it. This is called **spatial locality**.
- Jumping around memory randomly (like following many pointers in a linked list) is slow: almost every step can be a trip to the kirana shop.
- The same Big-O algorithm can be several times faster or slower depending on memory layout. We will measure this ourselves in Stage 6 and Stage 10.

**Common mistakes:**

- Thinking the CPU works directly on RAM. It works on registers; RAM is far away.
- Thinking "fewer instructions" always means faster. Waiting for memory often costs far more than the arithmetic.
- Thinking the CPU knows about Go types. It only sees instructions and bits; the compiler chose the instructions based on the types (DT-31).

### Unit 0.6 — Stack and heap (first look)

**One-line summary:** A running process divides its memory into areas. The **stack** holds short-lived data for function calls and is extremely cheap. The **heap** holds data that must live longer or whose size is not known in advance; it costs more and must be cleaned up (in Go, by the garbage collector). In Go, the compiler decides which one each value uses.

**Process memory layout (simplified):**

| Area | What lives there | Lifetime |
| --- | --- | --- |
| Code (text) | Machine-code instructions of your program | Whole run, read-only |
| Static data | Package-level (global) variables, constant strings | Whole run |
| Stack | Local variables and bookkeeping of each active function call | Until that function returns |
| Heap | Data that must outlive the function that made it, or is too big / of unknown size | Until nothing uses it any more (then GC frees it) |

**The stack — a pile of plates (tiffin carrier):**

- Each function call gets a **stack frame**: a block holding its local variables, its arguments, and the address to jump back to when it returns.
- Calling a function puts a new frame on top. Returning removes the top frame. Last in, first out (LIFO).
- Allocating a frame = moving one register (the **stack pointer**) by a fixed amount. One instruction. Freeing = moving it back. No search, no cleanup work.
- The compiler must know the frame size ahead of time.
- When a function returns, its frame is gone. Nothing in it may be used afterwards.

**The heap — a rented godown (warehouse):**

- For data that must survive after its function returns, or that is very large, or whose size is decided at run time.
- Allocating means finding free space (more work than moving one register).
- Someone must free it. In C the programmer calls `free` (forgetting = memory leak; freeing too early = crash or security bug). In Go the **garbage collector (GC)** finds data nothing refers to any more and frees it automatically. Safe, but the GC itself uses CPU time.

**Who decides in Go? The compiler, using escape analysis.** There is no keyword to choose stack or heap. The compiler studies each value: if it can prove the value is not used after the function returns, it can stay on the stack. If the value "escapes" the function, it goes to the heap. You can see these decisions with `go build -gcflags=-m` (full lesson in Stage 10).

**Why a Go programmer cares (later stages):**

- Heap allocations cost time to create AND create work for the GC. Reducing unnecessary allocations is one of the main Go performance techniques (Stage 10).
- Correctness never depends on stack vs heap in Go. Only performance does (DT-34).

**Each goroutine has its own stack.** Goroutines (Stage 7) are Go's lightweight threads. Their stacks start small and grow when needed (DT-36). The heap is shared by all goroutines.

**Common mistakes:**

- "Small values go on the stack, big values on the heap." Size matters sometimes, but the main question is lifetime: does the value escape?
- "I can choose stack or heap in Go." You cannot directly; the compiler chooses.
- "Heap is bad." The heap is necessary; unnecessary heap allocations are what we avoid.
- Thinking the stack trace is unrelated to the stack. It is literally a printout of the stack frames at the moment of failure.

#### Unit 0.6 — Detailed explanation (added after your questions)

**"Last in, first out" (LIFO) — "in" and "out" are about TIME, not position.** Put three tiffin boxes on a pile: A first, then B, then C. C went in last. You can only take from the top, so C comes out first. The last one IN is the first one OUT. You can also say "first in, last out" (A went in first and comes out last); both describe the same thing. Compare with a queue at a railway ticket counter: first person in line is served first: first in, first out (FIFO).

For function calls: `main` is called first, then `sumOfSquares`, then `square`. `square` (last called) finishes first; `main` (first called) finishes last.

**What "area" means: regions of the process's own address space.** Each process gets its own private range of addresses, called its **virtual address space**. Think: every process thinks it owns a whole street numbered from 0 upwards. The OS and CPU keep a map (the **page table**) from each process's house numbers to real houses in physical RAM. Memory is mapped in fixed blocks called **pages** (16 KB on Apple Silicon Macs, 4 KB on most x86 Linux machines).

Consequences:

- Two processes can both use address `0x1000`; each maps to a different real RAM location. They cannot see or overwrite each other's memory. This is a basic security protection.
- Pages are only given real RAM when actually used.
- The "areas" (code, static data, stack, heap) are just ranges of addresses inside one process's address space. When used, they are backed by real RAM. So yes, they end up in RAM, but organised per process through this map.

**Classic layout (C programs), from low addresses to high:**

```
high addresses
+------------------+
|      stack       |  grows DOWN (towards lower addresses) as calls are made
|        |         |
|        v         |
|                  |  (unused gap)
|        ^         |
|        |         |
|       heap       |  grows UP as more is allocated
+------------------+
|   static data    |  globals
+------------------+
|       code       |  machine instructions (read-only)
+------------------+
low addresses
```

Go twist: goroutine stacks are not placed in that classic stack area. The Go runtime allocates them from memory it manages itself (see DT-37).

**Step-by-step stack snapshots for the lesson program:**

| Step | What happens | Stack (top first) |
| --- | --- | --- |
| 1 | `main` starts | main |
| 2 | main calls `sumOfSquares(3, 4)` | sumOfSquares(a=3,b=4), main |
| 3 | it calls `square(3)` | square(n=3), sumOfSquares, main |
| 4 | `square(3)` returns 9 | sumOfSquares, main |
| 5 | it calls `square(4)` — new frame in the SAME place | square(n=4), sumOfSquares, main |
| 6 | `square(4)` returns 16 | sumOfSquares, main |
| 7 | `sumOfSquares` returns 25 | main (total=25) |
| 8 | `main` returns | empty: process exits with code 0 |

What a frame holds: the function's local variables, its arguments, and the **return address** (where the program counter must jump back to when this function finishes). Removing a frame does NOT erase it; the stack pointer just moves back, and the old bytes stay until the next call overwrites them. That is why reading a frame after its function returned is dangerous (a classic C bug), and why Go never allows it to happen.

**"Data dies when the function returns" — but `square` returns 9 to its caller. How?** (your question) Two different things are involved:

- The **variables** of `square` (`n` and `result`) live in its frame. They die when the frame is removed.
- The **value** being returned (9) is **copied out before the frame is removed**: the return instruction puts a copy of 9 where the caller can pick it up (in current Go on your Mac, a CPU register — see DT-38). Then the frame is removed. The caller (`sumOfSquares`) now holds its own copy.

So `result` (the box) is gone, but 9 (the contents) survived as a photocopy. Like a shopkeeper who closes his shop after handing you your parcel: the shop closes, your parcel is in your hand. What CANNOT survive is anything that still points INTO the closed shop; that is the case escape analysis handles.

**Heap and the garbage collector, in more detail:**

- Some data must outlive its function, for example a function that reads a file of unknown size and returns all its lines to the caller. The frame is thrown away on return, so the lines must live somewhere else: the heap.
- The GC decides what is still in use by **reachability**: it starts from the "roots" (variables in every goroutine's stack frames, and global variables) and follows every reference it can find, marking what it reaches. Anything never reached cannot be used by the program again, so its memory is freed ("sweep"). This is called **mark and sweep**.
- Go's GC mostly runs at the same time as your program (concurrently), using some CPU time; it can briefly pause goroutines. Details in Stage 10.

**Escape analysis — the photocopy analogy:**

- Returning a plain value (like the number 9 from `square`) = handing the caller a **photocopy**. The copy goes into the caller's frame; the original can be thrown away with the frame. Nothing escapes.
- Returning a **reference** to data (its address, Stage 2) = handing the caller a **location slip**. If the data were in the frame that is about to be thrown away, the slip would point to nothing. So the compiler places that data in the heap from the start. The data "escapes".

**Stack vs heap summary:**

|  | Stack | Heap |
| --- | --- | --- |
| Allocation cost | Move one register: tiny | Find free space: more work |
| Freeing | Automatic on function return, free of cost | Garbage collector (costs CPU time) |
| Lifetime | Until the function returns | Until nothing references it |
| Size known at | Compile time | Can be decided at run time |
| Shared between goroutines? | No, each goroutine has its own | Yes, one shared heap |
| Who chooses (in Go)? | Compiler (escape analysis) | Compiler (escape analysis) |

### Stage 0 Project — `numinfo`

**Goal:** a small command-line tool that takes one integer and prints everything Stage 0 taught about it: its bases, its lowest 8 bits as unsigned and signed, and which integer types it fits in. Uses P-3 (stdout/stderr/exit codes) and P-4 (validate at the edge).

**New tools introduced in the project (full lessons later):**

- `os.Args`: the command-line words. `os.Args[0]` is the program's own name; `os.Args[1]` is the first argument. `len(os.Args)` is how many there are.
- `strconv.Atoi(text)`: turns text like `"200"` into an `int`. It also returns an error value if the text is not a valid number.
- `if cond { ... }`: runs the block only when `cond` is true (Stage 1).
- Comparisons `>=`, `<=` give `true` or `false`; `a && b` is true only when both are true.
- `fmt.Fprintln(os.Stderr, ...)`: print to stderr instead of stdout.
- `os.Exit(1)`: stop now with exit code 1.

Status: first version reviewed. All 9 test cases produce correct values and exit codes (0 for valid input, 1 for bad input). 384 and 256 predicted correctly. Small revision requested before Stage 1.

**Senior review notes:**

- Correct conversions (`uint8(n)`, `int8(n)`) and correct range checks with `math` constants.
- Exit codes and stderr usage follow P-3 exactly.
- Hex line misses the required `0x` prefix, and needs a decision for negative numbers (DT-44).
- `n&0xFF` for the low 8 bits is correct; `&` (bitwise AND) has not been taught yet, so its use needs explaining.
- Labels aligned with `\t` depend on the viewer's tab width; fixed spaces (or width verbs like `%-12s`, Stage 1) give the same layout everywhere.
- Remove scaffold comments once done; comments should explain the code that exists, not the task.
- Format every file with `gofmt` (P-5).

## Stage 1 — Core Language Fundamentals

### Unit 1.1 — Variables and zero values

**One-line summary:** A variable is a named box with a fixed type. The type is decided when the variable is declared and can never change. A variable declared without a value holds its type's zero value.

**Mental model:** a labelled steel tiffin box. The label (name) and the shape (type) are fixed when it is made. You can change what is inside (assign a new value of the same type), but you can never turn an `int` box into a `string` box. This is **static typing**: types are checked by the compiler, before the program runs.

**Declaration forms:**

| Form | Example | Type comes from | Where allowed |
| --- | --- | --- | --- |
| var with type, no value | `var count int` | written type; value = zero value | anywhere |
| var with type and value | `var ratio float32 = 1.5` | written type | anywhere |
| var with value only | `var name = "Ravi"` | the value (default type) | anywhere |
| short declaration | `name := "Ravi"` | the value (default type) | inside functions only |
| grouped | `var ( a int; b string )` | as above | anywhere |
| multiple | `x, y := 1, "hi"` | each value | inside functions only |

**Zero values (the starting value when none is given):**

| Type | Zero value |
| --- | --- |
| all integer types | `0` |
| float32, float64 | `0` (prints as `0`) |
| bool | `false` |
| string | `""` (empty string) |
| pointers, slices, maps, channels, functions, interfaces | `nil` (later stages) |

**Default types when the type is inferred from a constant:**

| Value written | Type of `x := value` |
| --- | --- |
| `5` | `int` |
| `5.0` or `1e3` | `float64` |
| `'a'` | `rune` (= `int32`) |
| `"a"` | `string` |
| `true` | `bool` |

**`=` vs `:=`:** `:=` declares (creates) AND assigns. `=` only assigns to a variable that already exists.

**Rules of `:=`:**

- Only inside functions. At package level you must use `var`.
- At least ONE variable on the left must be new in the current scope. The others are simply assigned.
- So `x := 5` then `x := 6` is an error ("no new variables on left side of :="), but `x, y := 6, 7` is allowed: `y` is new, `x` just gets 6.

**Idiomatic choice (what Go reviewers expect):**

- Use `:=` inside functions when you have a starting value: `total := 0`, `name := "Ravi"`.
- Use `var x T` when you deliberately want the zero value, especially when the zero value is meaningful: `var count int`, `var found bool`.
- Use `var x T = value` only when the type must differ from the default type: `var ratio float32 = 1.5`, `var b byte = 'A'`.
- Avoid `var count int = 0`: the `= 0` repeats what the zero value already gives. Linters point this out.

**The blank identifier `_`:** a write-only placeholder that throws a value away: `_, err := strconv.Atoi(s)` when you only need the error. `_ = x` silences "declared and not used" during development, but should not stay in finished code.

**Common mistakes:**

- Using `:=` when the variable already exists (error) or when you meant `=` in an inner block (creates a NEW variable: shadowing, Unit 1.9).
- Trying `:=` at package level.
- Expecting a variable's type to change after assigning a different kind of value.
- Writing `= 0`, `= ""`, `= false` explicitly when the zero value already does it.

### Unit 1.2 — Constants and untyped constants

**One-line summary:** A constant is a value fixed at compile time. Constants written without a type are **untyped**: exact numbers that have not chosen a type yet. They adapt to wherever they are used, and fall back to a default type only when nothing decides for them.

**Declaring constants:**

```go
const pi = 3.14159          // untyped floating-point constant
const maxRetries int = 3    // typed constant: type int, strict
const (
	greeting = "namaste"
	debug    = false
)
```

Rules:

- The value must be computable by the compiler: `x := 5; const y = x` is an error, because `x` is a variable.
- Only booleans, numbers (including runes), and strings can be constants. No constant slices, maps, or structs.
- `:=` cannot make a constant; only `const` can.

**Mental model — untyped constant = water, typed variable = a container.** An untyped constant is like water: it takes the shape of whatever container it is poured into. `2` poured into a `float64` becomes float64 2.0; poured into a `uint8` it becomes uint8 2. If there is no container (`x := 2`, or passing to `fmt.Println`), it uses its default shape (the default type, Unit 1.1). A typed constant is water already frozen into ice of one shape: it only fits that shape.

**Why `f * 2` works but `f * n` does not:**

```go
var f float64 = 2.5
fmt.Println(f * 2)   // 5: the untyped 2 adapts to float64

n := 2               // n is a VARIABLE of type int
fmt.Println(f * n)   // type error: mismatched types float64 and int
```

**Representable or not — the compiler checks the exact value:**

| Code | Result | Why |
| --- | --- | --- |
| `var i int = 2.0` | OK, i = 2 | 2.0 is exactly a whole number, so it fits int |
| `var i int = 2.5` | compile error (truncated) | 2.5 cannot be an int without losing .5 |
| `var b byte = 300` | compile error (overflows) | 300 does not fit in 8 bits |
| `const t int = 5; var f float64 = t` | type error | `t` is typed int; typed constants do not adapt |

**Kinds of untyped constants:** boolean, rune, integer, floating-point, complex, string. When kinds mix in one expression, the result takes the kind that comes later in the list rune → integer → floating-point → complex. Example: `1 + 2.5` is untyped float 3.5; `'a' + 1` is an untyped RUNE constant 98, so `fmt.Println('a' + 1)` prints `98` (not `b`).

**Exact, huge precision:** untyped constants are exact and can be much bigger than any Go type, as long as the final value fits where it is used:

```go
const big = 1 << 100
fmt.Println(big >> 98)   // 4: the huge intermediate is fine
fmt.Println(big)         // compile error: overflows int
```

**iota — a counter inside a const block:**

```go
const (
	Small  = iota // 0
	Medium        // 1  (expression repeated automatically)
	Large         // 2
)
```

- `iota` starts at 0 in each `const` block and goes up by 1 on each line (each constant specification).
- A line with no expression repeats the previous line's expression, with the new iota.
- `_` skips a value: it uses up one iota number without making a name.
- Expressions work: `1 << iota` gives 1, 2, 4, 8 (bit flags); `1 << (10 * (iota + 1))` gives KB, MB, GB.

In Stage 3 you will attach iota constants to your own named type, which is Go's way of writing enums.

**Common mistakes:**

- Thinking a constant has a type just because it has a value (`const x = 5` is untyped).
- Expecting typed constants to adapt like untyped ones.
- Trying to make a constant from a variable or a function call result.
- Expecting `'a' + 1` to be a letter. Runes are numbers.
- Writing constant names in ALL\_CAPS (see P-6).

### Unit 1.3 — Arithmetic, comparison, and logical operators

**One-line summary:** Operators combine values into new values. Go's rules are strict and explicit: both sides must have the same type, integer division drops the fraction, comparisons give `bool`, and `&&` / `||` stop early when the answer is already known.

**Arithmetic operators:** `+  -  *  /  %`

- Both operands must have the same type (untyped constants adapt, Unit 1.2).
- `+` also joins strings: `"Go" + "lang"` = `"Golang"`.
- `%` (remainder) works only on integers.

**Integer division drops the fraction, towards zero:**

| Expression | Result | Note |
| --- | --- | --- |
| `7 / 2` | `3` | .5 dropped |
| `-7 / 2` | `-3` | towards zero (Python gives −4) |
| `7 % 3` | `1` |  |
| `-7 % 3` | `-1` | the remainder takes the sign of the LEFT number |
| `7 % -3` | `1` |  |
| `7.0 / 2` | `3.5` | float division, because 7.0 is a float constant |

The rule that ties them together: `(a / b) * b + a % b == a` always holds.

**Comparison operators:** `==  !=  <  <=  >  >=`. The result is always a `bool`. Strings compare byte by byte, like a dictionary that uses character codes: uppercase letters (65–90) come before lowercase (97–122), so `"Zebra" < "apple"` is `true`, and `"10" < "9"` is `true` (it compares `'1'` with `'9'` first).

**Logical operators:** `&&` (and), `||` (or), `!` (not). They work only on `bool`.

**Short-circuit evaluation (guarantee):** the right side is evaluated only if it is needed.

- `a && b`: if `a` is false, the answer is false; `b` is never evaluated.
- `a || b`: if `a` is true, the answer is true; `b` is never evaluated.

So order matters: `d != 0 && 10/d > 1` is safe even when `d` is 0, but `10/d > 1 && d != 0` panics first.

**Increment and compound assignment:**

- `x++` and `x--` are STATEMENTS, not expressions. They produce no value, so `y := x++` is a syntax error. There is no `++x` form.
- Compound assignment: `x += 5`, `x -= 2`, `x *= 3`, `x /= 2`, `x %= 4` mean `x = x + 5` and so on.

**Precedence (who goes first), simplified:** `*  /  %` before `+  -`, then comparisons, then `&&`, then `||`. Use parentheses whenever a reader might hesitate. The full table, including bit operators, comes in Unit 1.4.

**Common mistakes:**

- Expecting `7 / 2` to be 3.5 (both are integers).
- Checking "odd" with `n%2 == 1`, which is false for negative odd numbers (`-3 % 2` is `-1`). Use `n%2 != 0`.
- Putting the dangerous check on the wrong side of `&&`.
- Comparing strings expecting human alphabetical order regardless of case.
- Using `x++` inside an expression.

### Unit 1.4 — Bitwise operators, shifts, and precedence

**One-line summary:** Bitwise operators work on each bit position separately, like eight (or 64) tiny independent calculations side by side. Shifts slide all bits left or right. Go's precedence rules put bit operators at the same level as multiplication and addition, which avoids C's famous traps.

**The bitwise operators (integers only):**

| Operator | Name | Result bit is 1 when… | Everyday use |
| --- | --- | --- | --- |
| `a & b` | AND | both bits are 1 | check or keep certain bits (a "mask") |
| `a \| b` | OR | at least one bit is 1 | turn bits on |
| `a ^ b` | XOR | the bits are different | flip selected bits |
| `a &^ b` | AND NOT (bit clear) | bit is 1 in `a` and 0 in `b` | turn bits off (Go-specific operator) |
| `^a` | NOT (unary) | the bit of `a` is 0 | flip every bit |

Go uses `^a` for NOT. There is no `~` operator for this (in Go, `~` only appears in generic constraints, Stage 3).

Worked example with `uint8`:

```
a      = 1100 1010
b      = 1010 0110
a & b  = 1000 0010
a | b  = 1110 1110
a ^ b  = 0110 1100
a &^ b = 0100 1000   (start from a, switch off every bit that is 1 in b)
^a     = 0011 0101
```

**Shifts:** `x << n` moves every bit n places left (filling with 0s); `x >> n` moves them right.

- `x << n` multiplies by 2^n, as long as nothing falls off the left end (then it wraps, like overflow).
- `x >> n` for unsigned types divides by 2^n, dropping the remainder. New bits on the left are 0.
- `x >> n` for signed types is an **arithmetic shift**: new bits on the left copy the sign bit, so negative numbers stay negative. `-8 >> 1` = −4.
- The shift count must be an integer and not negative. A negative variable count panics at run time; a negative constant count is a compile error.
- Shifting by the type's width or more is defined (unlike C): `<<` gives 0; `>>` gives 0, or −1 for a negative signed number.

**Bit flags — the classic use:**

```go
const (
	Exec  = 1 << iota // 001 = 1
	Write             // 010 = 2
	Read              // 100 = 4
)

perm := Read | Write          // 110: turn on two flags
hasWrite := perm&Write != 0   // check one flag: true
perm |= Exec                  // turn on Exec: 111
perm &^= Write                // turn off Write: 101
perm ^= Read                  // toggle Read: 001
```

These values match Unix permission bits from Unit 0.2 (r = 4, w = 2, x = 1).

**Full precedence table (higher number = done first):**

| Level | Operators |
| --- | --- |
| 5 | `*  /  %  <<  >>  &  &^` |
| 4 | `+  -  \|  ^` |
| 3 | `==  !=  <  <=  >  >=` |
| 2 | `&&` |
| 1 | `\|\|` |

Operators on the same level go left to right. Unary operators (`-x`, `!x`, `^x`) bind tightest of all.

Consequences worth remembering:

- `x & 1 == 0` means `(x & 1) == 0`, which is what you meant. (In C it means `x & (1 == 0)`, a classic bug.)
- `1 << 2 + 1` means `(1 << 2) + 1` = 5. (In C it is `1 << 3` = 8.)
- `a | b & c` means `a | (b & c)`.
- Even though Go's rules are friendlier, add parentheses whenever mixing bit and arithmetic operators.

**Common mistakes:**

- Using `^` for powers (`2 ^ 3` is XOR = 1, not 8). Go has no power operator; use `1 << n` for powers of two, or `math.Pow` for floats.
- Using `&&` / `||` (logical, for bool) where `&` / `|` (bitwise, for integers) is meant, or the reverse.
- Forgetting `!= 0` when checking a flag: `if perm&Write` does not compile, because the result is an int, not a bool.
- Expecting `>>` on a negative number to behave exactly like `/ 2` (see DT-58).

### Unit 1.5 — Floating-point numbers and their traps

**One-line summary:** A float stores a number like scientific notation in binary: a sign, some significant digits, and a power of 2. This gives a huge range and fractions, but only a fixed number of significant digits, so most decimal fractions (like 0.1) are stored approximately.

**Mental model — scientific notation in base 2.** In school: 6.02 × 10^23 (digits × power of 10). A float64 stores: sign × 1.xxxx (in binary) × 2^exponent.

| Type | Sign | Exponent bits | Fraction bits | About this many correct decimal digits |
| --- | --- | --- | --- | --- |
| `float32` | 1 | 8 | 23 | 6–9 |
| `float64` | 1 | 11 | 52 | 15–17 |

`float64` is the default type for float constants and the normal choice. Use `float32` only when memory matters a lot (graphics, machine learning, huge arrays).

**Why 0.1 is not exact.** In decimal, 1/3 = 0.3333… never ends. In binary, 1/10 never ends: 0.0001100110011… With 52 fraction bits, the computer must cut it off and round. Only fractions whose denominator is a power of 2 are exact: 0.5 (1/2), 0.25 (1/4), 0.75 (3/4), 0.375 (3/8).

```go
a, b := 0.1, 0.2
fmt.Println(a + b)        // 0.30000000000000004
fmt.Println(a+b == 0.3)   // false
fmt.Println(0.1+0.2 == 0.3) // true! (constants are exact; see DT-62)
```

**Comparing floats: use a tolerance, not `==`.**

```go
const eps = 1e-9
if math.Abs(x-y) < eps { /* treat as equal */ }
```

The right tolerance depends on the size of the numbers and the domain. For values that can be very large or very small, compare relative to their size: `math.Abs(x-y) <= eps*math.Max(math.Abs(x), math.Abs(y))`.

**Whole numbers in float64 are exact only up to 2^53 = 9,007,199,254,740,992.** Beyond that, the gaps between representable floats are bigger than 1, so some integers cannot be stored and get rounded to a neighbour.

**Float → int conversion drops the fraction, towards zero:**

| Code | Result |
| --- | --- |
| `int(3.9)` (with a float variable) | 3 |
| `int(-3.9)` | −3 |
| `math.Round(2.5)` | 3 (halves round away from zero) |
| `math.Round(-2.5)` | −3 |
| `math.Floor(-2.5)` | −3 (always down) |
| `math.Ceil(-2.5)` | −2 (always up) |
| `math.Trunc(-2.5)` | −2 (towards zero) |

`math.Round` and friends return a `float64`; convert with `int(...)` afterwards if you need an int.

**Printing floats:** `Println` uses the shortest exact form (DT-57). For reports use `%.2f`. For scientific values use `%e`.

**Special values (from Unit 0.1):** `+Inf`, `-Inf`, `NaN`, and also negative zero `-0` (DT-65).

**Real-world float bugs:**

- **Patriot missile, 1991:** the system counted time in tenths of a second using a number format that could not store 0.1 exactly. After about 100 hours of running, the clock had drifted by about a third of a second, enough to miss an incoming missile; 28 soldiers died. (US GAO report, 1992.)
- **Vancouver Stock Exchange, 1982:** an index was recalculated thousands of times a day and each result was cut (truncated) to 3 decimals instead of rounded. After about two years the index showed roughly half its true value.

**Common mistakes:**

- Using `==` on computed floats.
- Using floats for money (see P-8).
- Expecting `int(2.9)` to round to 3.
- Using `float32` "to save memory" in normal code and losing precision.
- Assuming every large whole number fits exactly in a float64.

#### Unit 1.5 — Simple re-explanation (added on request)

**Idea 1 — The 4-digit calculator.** Imagine a calculator that can show only 4 digits after the decimal point. 1 ÷ 3 = 0.3333 (the rest is cut). Now 0.3333 × 3 = 0.9999, not 1. The small error came from cutting. A float64 is the same kind of calculator: it keeps about 16 significant digits and cuts the rest.

**Idea 2 — Why 0.1 must be cut.** Whether a fraction ends depends on the number system:

- Decimal (base 10): 1/2 = 0.5 ends, 1/4 = 0.25 ends, but 1/3 = 0.333… never ends.
- Binary (base 2): 1/2 = 0.1 ends, 1/4 = 0.01 ends, 3/4 = 0.11 ends, but 1/10 = 0.000110011001100… never ends.

So 0.1 in binary is like 1/3 in decimal: it must be cut, and a tiny error stays. Fractions that are halves, quarters, eighths (and sums of them) are exact; 0.1, 0.2, 0.3 are not.

**Idea 3 — See the hidden digits.** Ask for 20 decimals:

| Code | Prints |
| --- | --- |
| `fmt.Printf("%.20f\n", 0.1)` | `0.10000000000000000555` |
| `fmt.Printf("%.20f\n", 0.2)` | `0.20000000000000001110` |
| `fmt.Printf("%.20f\n", 0.3)` | `0.29999999999999998890` |
| `fmt.Printf("%.20f\n", 0.5)` | `0.50000000000000000000` (exact) |

The stored 0.1 and 0.2 are both a little TOO BIG; the stored 0.3 is a little TOO SMALL. So 0.1 + 0.2 (too big + too big) cannot land on the stored 0.3 (too small). Result: `0.30000000000000004`.

**Idea 4 — Paper vs calculator (constants vs variables).** The compiler working on constants is like doing maths on paper with exact fractions: 1/10 + 2/10 = 3/10 exactly, so `0.1+0.2 == 0.3` is true. Variables are like the cutting calculator: each value is cut first, then added, so `a+b == 0.3` is false.

**Idea 5 — "Close enough" instead of "exactly equal".** A jeweller weighing gold reads 10.0001 g, then 10.0002 g. He does not say "different gold"; the difference is smaller than his scale's accuracy. Same for floats: `math.Abs(x-y) < 0.000001` means "close enough". How small "close enough" should be depends on the job: 1 mm is nothing for distances between cities, but huge for parts inside a phone chip.

**Idea 6 — `int()` tears off the decimal part.** `int(7.8)` = 7 and `int(-7.8)` = −7: the digits after the point are simply thrown away, never rounded. For rounding, use `math.Round(7.5)` = 8.

**Idea 7 — Money in paise.** A shopkeeper who writes ₹2.50 as 250 paise never has decimal problems: 250 + 175 = 425 paise = ₹4.25, exactly. With floats, `x := 0.1; x + x + x` gives `0.30000000000000004`. With paise, `p := 10; p + p + p` gives exactly 30.

### Unit 1.6 — if, else, and switch

**One-line summary:** `if` runs code only when a `bool` condition is true; `else if` / `else` choose between options; `switch` picks the FIRST matching case from top to bottom and then stops. In machine code, all of these are conditional jumps (Unit 0.5).

**`if` rules:**

```go
if marks >= 35 {
	fmt.Println("pass")
} else if marks >= 25 {
	fmt.Println("supplementary exam")
} else {
	fmt.Println("fail")
}
```

- No brackets around the condition; braces `{ }` are ALWAYS required, even for one line.
- The condition must be a `bool`. `if n { }` with an int `n` is a type error; Go has no "truthy" values (0, "" and nil are not automatically false).
- `else` must be on the same line as the closing `}` (automatic semicolons, DT-17).
- Go has no ternary operator (`a > b ? a : b`). Write a short if/else instead.

**`if` with a short statement:**

```go
if n, err := strconv.Atoi(s); err != nil {
	fmt.Println("bad number:", err)
} else {
	fmt.Println("double:", n*2)
}
// n and err do NOT exist here
```

The variables made before the `;` exist only inside this if / else if / else chain (including the else branches). This keeps short-lived variables from leaking into the rest of the function.

**`switch` with a value:**

```go
switch day {
case "Sat", "Sun":          // several values in one case
	fmt.Println("weekend")
case "Mon":
	fmt.Println("start of week")
default:                    // when nothing else matches (optional)
	fmt.Println("weekday")
}
```

- Cases are checked top to bottom; the FIRST match runs, then the switch ends. No `break` needed (unlike C and Java).
- `default` runs when no case matches; it can be written anywhere but is usually last.
- Two identical constant cases are a compile error (`duplicate case`).

**`switch` with no value (tagless switch)** replaces long if-else chains:

```go
switch {
case marks >= 90:
	grade = "A"
case marks >= 75:
	grade = "B"
default:
	grade = "C"
}
```

Order matters: put the most specific (strictest) condition first, because the first true case wins.

**`fallthrough`:** at the end of a case, it jumps into the NEXT case's body WITHOUT checking that case's condition. Rarely needed; many Go programmers never use it. It cannot be used in the last case.

**Common mistakes:**

- Using a non-bool as a condition (`if count`).
- Expecting C-style fall-through between cases (Go stops after one case).
- Thinking `fallthrough` checks the next case's condition.
- Putting a broad condition first in a tagless switch, so later cases never run.
- Trying to use variables from an `if` short statement after the if.

### Unit 1.7 — for loops

**One-line summary:** Go has only ONE loop keyword, `for`, used in four shapes. `break` leaves a loop, `continue` skips to the next round, and labels let you break or continue an outer loop from inside an inner one.

**Mental model:** a loop is a conditional jump backwards (Unit 0.5): "if the condition is still true, jump back to the top of the body".

**The four shapes:**

```go
// 1. Three-part loop: start; condition; after-each-round
for i := 0; i < 5; i++ {
	fmt.Println(i) // 0 1 2 3 4
}

// 2. Condition only (Go's "while")
n := 1
for n < 100 {
	n *= 2
}

// 3. Forever (stop with break or return)
for {
	// ...
	if done {
		break
	}
}

// 4. range over an integer (Go 1.22+): i = 0, 1, 2, 3, 4
for i := range 5 {
	fmt.Println(i)
}
for range 3 { // no variable needed
	fmt.Println("hi")
}
```

`range` also loops over strings, slices, maps, and channels (Stage 2 and Stage 7).

**Order of the three-part loop:** run `init` once → check `condition` → run body → run `post` → check condition → body → … until the condition is false.

**`break` and `continue`:**

- `break` leaves the loop immediately.
- `continue` skips the rest of this round and goes to the next round (in a three-part loop, the `post` statement still runs).

**Labels for nested loops:**

```go
outer:
for i := 0; i < 3; i++ {
	for j := 0; j < 3; j++ {
		if i*j == 2 {
			break outer // leaves BOTH loops
		}
	}
}
```

Without a label, `break` only leaves the innermost loop (or switch, DT-68).

**Common loop recipes:**

- Sum / count: start a variable at 0 before the loop, add inside.
- Largest value: start with the first value, compare each next value.
- Search: loop, and `break` as soon as you find it.

**Common mistakes:**

- Off-by-one: `i <= n` vs `i < n`. Ask: "how many times does this run?" `for i := 0; i < n; i++` runs exactly n times.
- Forgetting to change the condition variable in a condition-only loop (infinite loop).
- Unsigned countdown `for i := uint(3); i >= 0; i--` never ends (DT-22).
- Expecting `break` inside a `switch` to leave the loop.
- Adding floats in a loop and expecting an exact result (DT-74).

### Unit 1.8 — Functions

**One-line summary:** A function is a named, reusable piece of work with inputs (parameters) and outputs (results). Go copies every argument into the function's own frame, can return several results at once, and treats functions as ordinary values.

**Mental model — a tea stall order.** You give the chaiwala an order slip (arguments). He works in his own corner of the stall (his own stack frame, Unit 0.6), and hands back the cups (results). He works on a COPY of your slip: if he scribbles on it, your original slip is unchanged.

**Syntax:**

```go
func add(a int, b int) int {   // parameters, then result type
	return a + b
}

func add2(a, b int) int {       // same type: write it once
	return a + b
}
```

The order of functions in a file does not matter; `main` can call a function written below it.

**Multiple results:**

```go
func divmod(a, b int) (int, int) {
	return a / b, a % b
}

q, r := divmod(17, 5) // q = 3, r = 2
_, r2 := divmod(9, 4) // ignore the first result
```

The most common use in Go: `(value, error)`, as in `strconv.Atoi`. The error is always the LAST result.

**Named results:** `func divmod(a, b int) (q, r int)` gives names to the results. They start at their zero values, and a bare `return` returns their current values. Names help as documentation, but bare `return` in a long function hurts readability; prefer `return q, r`.

**Pass by value (copies):** Go always copies arguments.

```go
func double(x int) { x = x * 2 } // changes only the copy

n := 5
double(n)
fmt.Println(n) // 5
```

To get a new value back, return it: `func double(x int) int { return x * 2 }`, then `n = double(n)`. (Pointers, Stage 2, are the other way.)

**Variadic functions (any number of arguments):**

```go
func total(nums ...int) int { // inside, nums is a slice of int
	sum := 0
	for _, n := range nums {
		sum += n
	}
	return sum
}

total()          // 0
total(1, 2, 3)   // 6
```

Only the LAST parameter can be variadic. `fmt.Println` is variadic.

**Functions are values:**

```go
square := func(x int) int { return x * x } // function literal stored in a variable

func apply(f func(int) int, v int) int {     // f has the function TYPE func(int) int
	return f(v)
}

apply(square, 4) // 16
```

The zero value of a function variable is `nil`; calling a nil function panics.

**Recursion:** a function calling itself. Always needs a base case that stops it.

```go
func factorial(n int) int {
	if n <= 1 { // base case
		return 1
	}
	return n * factorial(n-1)
}
```

Every call adds a stack frame (Unit 0.6). Without a base case: infinite recursion → `fatal error: stack overflow` (DT-39).

**What Go deliberately does NOT have:** default parameter values, function overloading (two functions with the same name), named arguments at the call site. Go prefers one clear way: different names, variadic parameters, or (Stage 3) an options struct.

**Built-in `min` and `max` (Go 1.21+):** `max(3, 7, 5)` = 7. If you name your own function `max`, it hides (shadows) the built-in one in your package (Unit 1.9).

**Common mistakes:**

- Expecting a function to change the caller's variable by assigning to its parameter.
- Forgetting the base case in recursion.
- Putting the error anywhere but the last result.
- Long functions with bare `return` and named results.
- Naming functions `max`, `min`, `len`, `new` and hiding built-ins.

### Unit 1.9 — Scope and shadowing

**One-line summary:** The scope of a name is the part of the code where that name can be used. Scopes nest like boxes inside boxes. Go looks up a name from the innermost box outwards, and a name declared in an inner box hides (shadows) the same name from an outer box.

**Mental model — nicknames at home.** At home, "Bhaiya" means your elder brother. At the office, "Bhaiya" might mean the canteen manager. The word is the same; WHERE you say it decides who answers. Inside the home, the home meaning wins, even though the office one also exists.

**The levels of scope (outermost to innermost):**

| Level | What lives there | Example |
| --- | --- | --- |
| Universe | Predeclared names: types, constants, built-in functions | `int`, `string`, `true`, `nil`, `len`, `max` |
| Package | Top-level names in ANY file of the package | `func largest`, package-level `var`, `const` |
| File | Imports (each file imports for itself) | `import "fmt"` |
| Function | Parameters and results | `nums` in `largest(nums ...int)` |
| Block | Anything declared inside `{ }`, including if / for / switch / case blocks and their short statements | `x := 2` inside an if |

**Lookup rule:** start in the current block, then go outwards one level at a time. The first match wins.

**Shadowing:** declaring a name that already exists in an outer scope creates a NEW variable that hides the old one until the inner block ends.

```go
x := 1
if true {
	x := 2    // NEW x (note :=), hides the outer x
	x++
	fmt.Println("inner", x) // inner 3
}
fmt.Println("outer", x)     // outer 1 (never touched)
```

With `=` instead of `:=` inside the block, there is only one `x`, and the outer one becomes 3.

**The famous `err` shadowing bug:**

```go
var err error
if s != "" {
	n, err := strconv.Atoi(s) // := makes a NEW err inside the if
	_ = n
}
fmt.Println(err)              // always <nil>: the outer err was never set
```

Fix: declare `n` outside too and use `=`, or move the check inside the block.

**Shadowing names from outer levels:**

- Built-ins can be shadowed: `len := 3` makes `len("hi")` fail to compile (`cannot call non-function len`).
- Package names can be shadowed: `fmt := "hi"` makes `fmt.Println` fail (the name `fmt` now means a string).
- Your own package-level names too: a local variable named `largest` inside `func largest` hides the function itself inside its body.

**Order rules:** package-level names can be used before they appear in the file (order does not matter). Inside a function, a variable must be declared before it is used.

**Common mistakes:**

- Using `:=` inside an if / for when you meant to update an outer variable with `=`.
- Naming variables after built-ins (`len`, `max`, `new`, `copy`) or imported packages (`url`, `fmt`, `time`).
- Expecting a variable from an if or for short statement to exist after the block.
- Thinking the compiler always catches shadowing: it only complains if the inner variable is unused.

#### Unit 1.8 / 1.9 fix-up explanations

**The nil-function program.** Expected output when run as a binary:

```
16
true
panic: runtime error: invalid memory address or nil pointer dereference
[signal SIGSEGV: segmentation violation ...]   (details vary by machine)

goroutine 1 [running]:
main.main()
        .../main.go:14 +0x...
```

Exit code 2. `last line` never prints: the panic stops `main` at `g(3)`, so nothing after it runs. It compiled fine, because `g` exists and has the right type; it only fails when the program actually tries to call through a nil value (see DT-84). Compare: `undefined: apply` stops the build itself; no program is ever produced.

**`total := total + i` in a loop:**

| Round | i | right side uses OUTER total (10) | inner total | printed |
| --- | --- | --- | --- | --- |
| 1 | 0 | 10 + 0 | 10 | in loop: 10 |
| 2 | 1 | 10 + 1 | 11 | in loop: 11 |
| 3 | 2 | 10 + 2 | 12 | in loop: 12 |

Then `after: 10`. Each round makes a fresh inner `total` from the untouched outer one, so the values never build up.

### Unit 1.10 — Closures

**One-line summary:** A closure is a function literal that uses variables from the scope around it. It does not take a copy of those variables; it keeps a live link to the variables themselves, and they stay alive as long as the closure does.

**Mental model — a dabba (lunchbox) with a window.** Normally a function's local variables are thrown away when it returns (its frame disappears). A closure is like a small dabba that carries a window looking into the variables it uses. It does not carry a photo of them (a copy) but a real window: if the variable changes, the closure sees the change, and if the closure changes it, everyone else sees the change too.

**Example 1 — the closure sees later changes:**

```go
msg := "hello"
say := func() { fmt.Println(msg) }
msg = "bye"
say() // bye (it reads msg NOW, not when say was created)
```

**Example 2 — the closure can change the outer variable:**

```go
x := 10
add := func(n int) { x += n }
add(5)
add(5)
fmt.Println(x) // 20
```

**Example 3 — a function that returns a function (a generator):**

```go
func makeCounter() func() int {
	count := 0
	return func() int {
		count++
		return count
	}
}

c1 := makeCounter()
fmt.Println(c1(), c1()) // 1 2
c2 := makeCounter()
fmt.Println(c2())       // 1  (its own, separate count)
fmt.Println(c1())       // 3
```

Each call to `makeCounter` creates a NEW `count`. `c1` and `c2` each hold a window onto their own `count`.

**Where does `count` live?** `makeCounter` has returned, so its frame is gone, yet `count` is still used by `c1`. So the compiler's escape analysis moves `count` to the HEAP (Unit 0.6). `go build -gcflags=-m` reports `moved to heap: count`.

**The classic loop-closure bug (and the Go 1.22 fix):**

```go
var fs [3]func()
for i := 0; i < 3; i++ {
	fs[i] = func() { fmt.Println(i) }
}
for j := 0; j < 3; j++ {
	fs[j]()
}
```

- Go 1.22 and later (your go.mod): each round has its own `i`, so it prints 0 1 2.
- Go 1.21 and earlier: there was ONE `i` for the whole loop; all three closures had a window onto that same `i`, which was 3 after the loop, so it printed 3 3 3. This bug hit real production code for years, especially with goroutines (Stage 7).

**Where closures are used:** counters and generators, sorting with a custom comparison, callbacks, HTTP handlers and middleware (Stage 8), deferred cleanup (Unit 1.11).

**Common mistakes:**

- Thinking a closure copies the value at creation time (it links to the variable).
- Forgetting that two closures created in the same scope share the same variable.
- Assuming old code behaves like Go 1.22+ (check the module's go version).
- Using closures to hold lots of state that would be clearer as a struct with methods (P-12).

#### Closure fix: where to take the "photo"

```go
name := "Asha"
photo := name                              // photo taken NOW, outside: "Asha"
greet := func() { fmt.Println("Hi", photo) }
name = "Ravi"
greet()                                    // Hi Asha
```

The body of a closure runs only when the closure is called. A copy written inside the body is taken at CALL time; a copy written outside, before creating the closure, is taken at CREATION time.

### Unit 1.11 — defer

**One-line summary:** `defer` schedules a function call to run just before the surrounding function finishes, whether it finishes normally or because of a panic. Deferred calls run in reverse order (LIFO), and their arguments are worked out immediately, at the `defer` line.

**Mental model — the "before you leave" checklist.** When you enter an office, you note on a sticky pad: "switch off the AC", then "lock the cupboard", then "return the visitor badge". The notes pile up; when you leave, you go through the pile from the TOP (the last note first): badge, cupboard, AC. `defer` adds a note to the pile; leaving the function goes through the pile.

**Basic use:**

```go
func main() {
	fmt.Println("start")
	defer fmt.Println("cleanup") // runs when main is finishing
	fmt.Println("working")
}
// start
// working
// cleanup
```

**Rule 1 — LIFO order:** several defers run last-in, first-out, like stack frames (Unit 0.6).

```go
defer fmt.Println("1")
defer fmt.Println("2")
defer fmt.Println("3")
// prints 3, 2, 1
```

**Rule 2 — arguments are evaluated immediately (a photo), but the call happens later:**

```go
x := 1
defer fmt.Println("value:", x) // x is read NOW: 1 is stored
x = 2
// prints: value: 1
```

If you defer a closure instead, it looks through its window at the END (Unit 1.10):

```go
x := 1
defer func() { fmt.Println("value:", x) }() // reads x when it runs
x = 2
// prints: value: 2
```

Note the `()` at the end: `defer` needs a function CALL, so the function literal is called.

**Rule 3 — deferred calls run after `return` sets the results, and can change NAMED results:**

```go
func double() (n int) {
	defer func() { n *= 2 }()
	return 5 // step 1: n = 5; step 2: defers run (n = 10); step 3: function returns 10
}
```

With an unnamed result, the deferred closure can only change a local variable, not the value already chosen for return.

**Rule 3 — simple re-explanation (added on request).** Think of a courier counter. Every function that returns a value has a **result box** at the counter. `return` does NOT hand the box to the caller immediately. It happens in 3 steps:

1. **Fill the box:** put the return value in the result box.
2. **Do the sticky notes:** run all deferred calls.
3. **Hand over the box:** give the caller whatever is in the box NOW.

Named result `(n int)` = the box has a label, `n`. A deferred closure can reach the box by its name and change what is inside during step 2. Unnamed result `int` = the box has no label. `return n` COPIES the value of the local variable `n` into the unlabelled box in step 1; in step 2 the closure changes the local `n`, but the box already holds the copy.

|  | `func f() (n int)` named | `func g() int` unnamed, local n |
| --- | --- | --- |
| Step 1 | `return 5` puts 5 in box `n` | `return n` copies 5 into the hidden box |
| Step 2 | defer: `n *= 2` changes the BOX to 10 | defer: `n *= 2` changes the LOCAL n to 10; box still 5 |
| Step 3 | caller gets 10 | caller gets 5 |

Why it exists: in Stage 3 a deferred closure can add context to an `err` result after the function decided to return it.

*Understood after re-explanation:* mini-check 11 / 10 / 30 all predicted correctly; f vs g (10, 5) explained as labelled vs unlabelled result box.

**Rule 4 — defers run during a panic** (before the panic message is printed and the program dies). This is how cleanup still happens when something goes wrong, and where `recover` lives (Stage 3).

**Rule 5 — `os.Exit` skips ALL defers.** The process ends immediately. This is one reason library code should return errors instead of calling `os.Exit` (P-3).

**Defer in a loop:** each round adds a note, and NONE run until the whole function ends. With resources like open files, they all stay open until then. Fix: move the loop body into its own function so each round's defer runs at the end of that small function.

**Where defer is used:** closing files and network connections, unlocking mutexes (Stage 7), finishing timers and traces, recovering from panics.

**Common mistakes:**

- Expecting a deferred call to see later changes to its arguments (it took a photo).
- Forgetting the `()` when deferring a function literal.
- Deferring inside a long loop and holding resources too long.
- Expecting defers to run after `os.Exit`.
- Deferring a cleanup BEFORE checking whether the resource was actually obtained (P-13).

### Unit 1.12 — Reading input

**One-line summary:** A program can get input from command-line arguments (`os.Args`), from standard input (stdin: the keyboard or a pipe), or from files (Stage 5). For stdin, the reliable Go way is: read one line at a time with `bufio.Scanner`, clean it, convert it with `strconv`, and validate it.

**Mental model — a conveyor belt.** stdin is a conveyor belt of bytes coming into your program. When you type, the terminal puts each finished line on the belt when you press Enter. When you pipe (`printf "5\n7\n" | ./prog`), another program fills the belt. When the belt is empty and the sender says "no more" (Ctrl+D on Mac/Linux, or the end of a pipe or file), that is **EOF** (end of file).

**The three input sources:**

| Source | How to send | How to read | Good for |
| --- | --- | --- | --- |
| Arguments | `./prog 42 abc` | `os.Args` | a few values known at start |
| stdin | typing, `cmd \| ./prog`, `./prog < file` | `bufio.Scanner`, `fmt.Scan` | interactive input, streams of data |
| Files | file path | `os.Open` (Stage 5) | stored data |

**The standard pattern — line by line with bufio.Scanner:**

```go
scanner := bufio.NewScanner(os.Stdin)
for scanner.Scan() {                    // false at EOF or on error
	line := strings.TrimSpace(scanner.Text())
	n, err := strconv.Atoi(line)
	if err != nil {
		fmt.Fprintf(os.Stderr, "not a number: %q\n", line)
		continue
	}
	// use n
}
if err := scanner.Err(); err != nil {   // was it EOF, or a real error?
	fmt.Fprintln(os.Stderr, "read error:", err)
	os.Exit(1)
}
```

- `scanner.Scan()` reads the next line and returns `true`; it returns `false` at EOF or on an error.
- `scanner.Text()` gives the line WITHOUT the newline at the end.
- After the loop, `scanner.Err()` is `nil` for a normal EOF, or the real error otherwise. Always check it.
- `strings.TrimSpace` removes spaces, tabs, and newlines at both ends, so " 5 " becomes "5".

**`fmt.Scan` (quick but tricky):** `fmt.Scan(&n)` reads the next space-separated value into `n`. The `&` means "the address of n" so Scan knows where to store the value (pointers: Stage 2). It returns `(count, error)`. Problems: invalid input leaves `n` as 0 and returns an error that is easy to ignore; the bad text can stay on the belt; and it treats newlines like spaces, so it does not work line by line. Fine for quick experiments; use `bufio.Scanner` for real programs.

**Prompting:** use `fmt.Print("Enter age: ")` (no newline) so the cursor stays on the same line.

**Testing input programs without typing:** pipe fixed input in: `printf "10\nabc\n5\n" | ./prog`. Same input every time = repeatable tests (Stage 4).

**Common mistakes:**

- Ignoring the error from `fmt.Scan` or `strconv.Atoi`.
- Forgetting `scanner.Err()` after the loop.
- Not trimming spaces before converting.
- Not handling EOF (the user presses Ctrl+D, or the pipe ends) in an "ask until valid" loop, which then loops forever or crashes.
- Using `fmt.Scan` for line-based input.

### Unit 1.13 — Random numbers

**One-line summary:** Computers follow exact instructions, so normal "random" numbers are pseudo-random: a formula produces a long sequence that looks random, starting from a seed. Use `math/rand/v2` for games, simulations, and shuffling; use `crypto/rand` for anything an attacker could benefit from guessing.

**Mental model — a giant pre-shuffled deck.** Imagine a deck of billions of cards, shuffled once in a fixed way. A pseudo-random generator deals cards from this deck. The **seed** decides where in the deck you start. Same seed → same cards in the same order, every time. A different seed → a different starting point, so the numbers look different.

**math/rand/v2 (Go 1.22+):**

```go
import "math/rand/v2"

rand.IntN(6)       // 0, 1, 2, 3, 4, or 5   (never 6!)
rand.IntN(6) + 1   // dice: 1 to 6
rand.Float64()     // 0.0 up to (not including) 1.0
```

- The global functions are seeded randomly by Go at start, so each run gives different numbers. No `Seed` call needed.
- A number from `min` to `max` (both included): `min + rand.IntN(max-min+1)`.
- `rand.IntN(n)` panics if `n <= 0`.

**Reproducible randomness (for tests and debugging):** make your own generator with a fixed seed.

```go
r := rand.New(rand.NewPCG(42, 1024)) // fixed seed
fmt.Println(r.IntN(100), r.IntN(100), r.IntN(100)) // same three numbers on every run
```

A test can then expect exact results, and a bug seen once can be reproduced.

**crypto/rand — for secrets:** reads unpredictable randomness from the operating system. Use it for passwords, OTPs, session IDs, password-reset links, API keys.

```go
import "crypto/rand"

token := rand.Text() // Go 1.24+: a random string, suitable for secret tokens
```

**Which one?**

| Need | Use | Why |
| --- | --- | --- |
| Game dice, shuffling cards, simulations | `math/rand/v2` | fast; predictability does not hurt anyone |
| Retry "jitter" (spreading out retries, Stage 12) | `math/rand/v2` | fast; not a secret |
| Repeatable test data | `math/rand/v2` with a fixed seed | same sequence every run |
| OTP, password, session ID, reset link, API key | `crypto/rand` | an attacker must not be able to predict it |

If both packages are needed in one file, import one under another name: `import crand "crypto/rand"`.

**Common mistakes:**

- Off-by-one: `rand.IntN(6)` never returns 6.
- Using `math/rand` for tokens or OTPs.
- Expecting a fixed-seed generator to give different numbers on each run (it will not).
- Calling `rand.IntN(0)` (panic).

### Stage 1 Project — `playtool`

**Goal:** one command-line program with two modes that uses all of Stage 1: variables and constants, operators, floats, if/switch, loops, functions, closures, defer, reading input, randomness, plus Stage 0 conventions (stderr, exit codes, validation).

**Modes:**

- `./playtool guess [seed]` — number-guessing game, secret number 1–100, at most 7 attempts. The optional seed makes the secret number repeatable for testing.
- `./playtool convert` — unit converter reading lines like `10 km mi`, `100 c f`, `5 kg lb` (and the reverse directions) until `quit` or EOF.

**New tools introduced in the project:**

- `strings.Fields(line)` splits a line on spaces into a list of words; `len(...)` gives how many; `words[0]` is the first.
- `strconv.ParseFloat(text, 64)` converts text to a float64 (with an error, like Atoi).
- `strconv.ParseUint(text, 10, 64)` converts text to a uint64 (for the seed).
- `errors.New("...")` and `fmt.Errorf("... %v", x)` create error values to return from `run()`.

**Exact conversion constants:** 1 mile = 1.609344 km; 1 pound = 0.45359237 kg; °F = °C × 9 / 5 + 32.

Status: COMPLETE. Version 2 fixed all 9 review comments; all 5 required guess tests pass with correct exit codes (usage, unknown mode, win in 3 with "well played", EOF abort, out of attempts); reflection answers correct (2^7 = 128 > 100; fixed seed = deterministic tests; math/rand for games, crypto/rand for secrets). Remaining polish: use \`minNumber + rand.IntN(maxNumber-minNumber+1)\`.

**Senior review of version 1:**

What is good:

- Requirements G1–G8, C1–C6, P1, P3, P4 met in the code; all six conversions correct, including the −40 °C test (no `9/5` trap).
- Clean `run()` pattern; `defer` on every exit path. The output order (`playtool finished` before `error: ...`) proves that `run()`'s defers finish before `main` prints the error and exits.
- Rejected guesses do not use up an attempt; the attempt number stays the same.
- Small conversion functions; `(float64, bool)` result for `convert`.

Must fix:

1. **`scanner.Err()` is never checked** in `playGuess` or `runConvert`. When `Scan()` returns false, the code assumes EOF; a real read error (or a line over 64 KB, DT-92) would be reported as "game aborted" or "bye" with exit code 0.
2. **Missing tests:** no-argument run, unknown mode, and the winning game (rating line never shown).
3. **Reflection questions not answered** (needed to verify Unit 1.13).

Should improve:

4. **Each error is reported twice:** `playGuess` prints a message on stderr AND returns a second error that `main` prints. Return one informative error instead (`fmt.Errorf("out of attempts, the number was %d", secret)`) and let `main` print it once.
5. **Magic numbers:** `100` and `7` appear several times; use `maxNumber` and `maxAttempts` constants (the welcome message, range check, loop, and secret all depend on them).
6. **`run()` does too much:** move seed parsing and secret creation into its own function, for example `newSecret(seedArg string) (int, error)`; `run()` should only check arguments and dispatch.
7. **Keep the original error:** `errors.New("seed must be a valid uint64")` hides why; `fmt.Errorf("invalid seed %q: %v", args[1], err)` keeps the details.
8. **Exported names:** `KmPerMi` and `KgPerLb` start with capitals, which means "exported". In package `main` nothing imports them, so `kmPerMi` and `kgPerLb` are the convention (P-6).
9. **Repeated usage text:** define it once as a constant.

**Version 2 review:** fixes 1 and 4–9 all done correctly (scanner.Err checked in both loops, one error report through `fmt.Errorf`, constants, `newSecret`, original seed error kept, lowercase constants, shared usage text). New finding: `rand.IntN(maxNumber) + minNumber` is only correct while `minNumber` is 1. With `minNumber = 10` it would give 10–109. The general formula is `minNumber + rand.IntN(maxNumber-minNumber+1)` (Unit 1.13). Lesson: once values become named constants, every formula must stay correct for ANY value of those constants, not just today's value.

## Stage 2 — Composite Data & Memory

### Unit 2.1 — Arrays

**One-line summary:** An array is a fixed number of values of one type, stored side by side in memory. The length is part of the type, and arrays are VALUES: assigning or passing an array copies every element.

**Mental model — a steel tiffin carrier with a fixed number of boxes.** A 3-tier tiffin always has exactly 3 boxes, stacked together, numbered from 0. You cannot add a 4th tier; a 4-tier tiffin is a different product. Giving someone your tiffin (assignment, function call) means giving them a full COPY of all boxes and their food.

**Declaring arrays:**

```go
var a [3]int                 // [0 0 0]  (zero values)
b := [3]int{10, 20, 30}      // [10 20 30]
c := [...]int{1, 2, 3, 4}    // compiler counts: type is [4]int
d := [5]int{2: 7, 4: 9}      // [0 0 7 0 9]  (index: value)
```

**Indexing:** `a[0]` is the first element, `a[len(a)-1]` the last. `len(a)` is the length, known at compile time.

**Out-of-range index — "who calculates?" again:**

| Code | Result |
| --- | --- |
| `a[3] = 1` (constant index, length 3) | compile error: index 3 out of bounds |
| `i := 3; a[i] = 1` | run-time panic: `index out of range [3] with length 3` |

Go checks every index (bounds checking), so it can never read or write memory outside the array (unlike C, where this causes crashes and security holes).

**The length is part of the type:** `[3]int` and `[4]int` are different types. `var p [3]int; var q [4]int; p = q` is a type error.

**Arrays are values (copied):**

```go
a := [3]int{1, 2, 3}
b := a        // b is a full COPY
b[0] = 99
fmt.Println(a, b) // [1 2 3] [99 2 3]
```

Passing an array to a function also copies it (DT-75). Arrays of comparable elements can be compared with `==` (element by element) and used as map keys.

**Memory layout:** elements sit next to each other with no gaps between same-size elements. `[4]int64` is exactly 32 bytes. Walking through an array in order is very cache-friendly (Unit 0.5).

**Iterating:**

```go
for i := range a { ... }     // index only
for i, v := range a { ... }  // index and a COPY of the element
for _, v := range a { ... }  // value only
```

Changing `v` does not change the array; write `a[i] = ...` instead.

**Multi-dimensional arrays:** `var board [3][3]int` is an array of 3 arrays of 3 ints (a tic-tac-toe board). `board[1][2]` is row 1, column 2.

**Where arrays are used in real Go:** fixed-size values where copying is fine or wanted: hashes (`sha256.Sum256` returns `[32]byte`), IPv4 addresses (4 bytes), small matrices, game boards, map keys made of several numbers. For lists whose size changes, Go uses SLICES (Unit 2.2), which are built on top of arrays.

**Common mistakes:**

- Expecting `b := a` to share data (it copies).
- Expecting a function to change the caller's array.
- Changing `v` in a range loop and expecting the array to change.
- Mixing arrays of different lengths.
- Using huge arrays as function parameters (every call copies all of it).

## Mistakes & Misconceptions Log

No mistakes recorded yet. Every wrong answer will be added here in this format, so you can revise your own weak spots before cumulative tests.

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.1 | Every compile error is a "syntax error" (said for `100/0` and for an unused import) | Syntax error = grammar of the code is broken (missing brace, missing bracket). Compile error = ANY reason the compiler refuses to build. Syntax errors are only one kind. | In daily talk people say "syntax error" for any code error | Retest 1: concept fixed (R5). Retest 2: missed an extra `}` (Q1f, said "runs fine"). In spaced review. |
| 0.1 | A message starting with `invalid operation` means "other compile-rule error" (Q1e: `"total" + 5`) | `invalid operation:` is used for BOTH type errors and rule errors. Read the part in brackets: `(mismatched types untyped string and untyped int)` means a type error. `division by zero` with no types mentioned is a rule error. | Classified by the first words of the message only | In spaced review |
| 0.1 | `5.0 / 0.0` with float variables panics, same as integers (C5) | With float variables the result is `+Inf` (or `-Inf`, or `NaN` for 0/0). Only integer division by zero panics. | Integer and float division look the same in code | Fixed (retest 1 and 2) |
| 0.1 | A Windows binary fails on Linux mainly because of CPU differences | OS matters too: different executable formats and system calls. Go has `GOOS` and `GOARCH`. | CPU was the main idea in the lesson | Fixed. Proved on own Mac: Mach-O arm64 vs ELF x86-64, `exec format error`. |
| 0.1 (minor) | A3 gave a compile-time case instead of a costly run-time failure; wrote `fmt.println` | Asked for a run-time failure. Go is case-sensitive: `Println`. | Answering what was easiest to recall | Fixed (Q5 banking example was good) |
| 0.1 | `fmt.Println(4.0 / 0.0)` prints `+Inf` (R2c) | All constants, so the compiler calculates it exactly; exact numbers have no infinity: compile error. `+Inf` only happens with a float variable at run time. | Applied "float / 0 = +Inf" without asking "who calculates?" | Fixed (Q1a, Q1d, Q2) |
| 0.1 | `NaN == NaN` is `true` (R7) | `false`. NaN equals nothing, not even itself. Use `math.IsNaN(x)`. | Normal values always equal themselves | Fixed (Q3) |
| 0.1 | `echo $?` after `echo $2` shows the exit code of `go run` | `$?` holds only the LAST command's exit code | Did not see `echo` as a command | Concept fixed (Q4). But the redo measured a program that succeeded (NaN program, exit 0), so go run's code on failure is still unmeasured. |

**Unit 0.2 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.2 (slip) | `10110110` = 186 (B2) | Place values were correct (2+4+16+32+128), but the sum is 182. | Addition done in the head in one go | Fixed (running total used correctly) |
| 0.2 | Used `%b` and `%x` for "binary padded to 8 digits" and "uppercase hex" (Part E) | `%08b` and `%X`. With 34 the hex `22` has no letters, so the mistake was hidden. | The output looked right for this one value | Code fixed on 3rd attempt (`%08b`, `%X`, output `00101010` and `2A`). But the pasted output is missing the "All equal" line, and when age changes to 42 the three literals (still 34) must change too. Pending re-paste. |
| 0.2 | `%3d` means "add 3 spaces before the value" | The number is a MINIMUM WIDTH, not a count of spaces. `%3d` makes the field at least 3 characters: 7 → `··7` (2 spaces), 42 → `·42` (1 space), 123 → `123` (0 spaces), 12345 → `12345` (never cut). Spaces added = width minus the length of the number, never below zero. Same for `%08b`: that is why 13 became `00001101` (4 zeros, not 8). | "3" looks like an amount to add | Pending |
| 0.1 review | Now correct: F1, `{` on the next line is a syntax error | Go inserts semicolons automatically at line ends; see DT-17 | — | Syntax-error category correct |

**Unit 0.3 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.3 | `fmt.Println(math.MaxUint64)` fails because "Println doesn't accept untyped variables" (\[9\]) | There are no untyped *variables*; only constants can be untyped. `Println` accepts untyped constants (`fmt.Println(42)` works). The constant gets its **default type**, `int`. `MaxUint64` (about 1.8 × 10^19) is bigger than the largest `int` (about 9.2 × 10^18), so it overflows int. `math.MaxUint32` fits, so it works. | Remembered "untyped" from DT-20 but not the default-type step | Fixed (0.4 check \[1\]: all 5 predictions and the reason correct) |
| 0.3 | In \[13\], `x + 1` is checked because "a const cannot be reassigned" (\[14\]) | Nothing is reassigned: `x + 1` makes a new value. It is checked because `x` and `1` are both constants, so the compiler calculates it. | "const" is mostly known for "cannot change" | Fixed (0.4 check \[2\]) |
| 0.3 (slip) | "uint8 can hold max 256" (\[7\]) | uint8 holds 256 different values; the max is 255. | 256 and 255 both appear in every uint8 discussion | Not repeated in 0.4 check |
| 0.3 (habit) | \[4\] copied word-for-word from the notes; \[8\] given without a letter | Own-words answers show understanding; copied text does not. | Notes are correct, so copying feels safe | 0.4 \[3\] was in own words |

**Unit 0.4 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.4 | "If we add more than 8 bits into int8, the compiler cannot add it, so it discards the left part" (\[3\]) | At run time the compiler is not involved at all; its job ended when the binary was built. The CPU does the addition, and its 8-bit result simply has no 9th place. The compiler's only role is earlier: rejecting constant overflows. | "Compiler" gets used as a general word for "Go" | Pending |
| 0.4 | Default type of an integer constant is "int64" (\[1\]) | The default type is `int`. On your Mac `int` is 64 bits, the same SIZE as `int64`, but they are different TYPES in Go. | Same size feels like same type | Pending |
| 0.4 (habit) | \[3\] asked for a new analogy and the cost; neither was given | The cost of wrapping: overflow bugs are silent (no crash, the wrong value continues). | Answered "why" but not "what is the cost" | Pending |

**Unit 0.5 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.5 (refinement) | Reading one byte brings "the next 127 bytes" (\[6\]) | A cache line is an ALIGNED block: memory is divided into fixed 128-byte blocks (addresses 0–127, 128–255, …). Reading a byte loads the whole block it sits in. If the byte is at position 100 of its block, you get 27 bytes after it (and 100 before it), not 127. Reading a slice from the start still gets the full benefit, and the CPU's prefetcher usually loads the next blocks early too. | "Chunk" sounds like "starting from here" | Pending |
| 0.1 review | `int + int32` called "compile error" (third time) | Use the specific kind: **type error**. "Compile error" is the group; the kind tells you where to look (a type mismatch means: check the types of the operands, then add an explicit conversion). | The general word is always technically true | Pending |
| 0.5 (terminology) | "Go requires explicit casting" | Go's word is **conversion**: `int64(x)`. The spec has no "cast". In C, a cast can reinterpret memory in unsafe ways; a Go conversion follows defined rules. Using Go's word avoids confusion in code reviews and documentation. | "Cast" is the common word from C, Java, and many tutorials | Pending |

**Unit 0.6 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.6 (clarification) | "Removed from the top" sounds like "last in, LAST out" | "In" and "out" describe the time order of entering and leaving. The box put in last (top) is the first taken out: last in, FIRST out. Equivalent: first in, last out. | "Last" was read as a position (the top/last box) rather than the order of time | Pending (\[7\] in check) |
| 0.6 (clarification) | Unclear what "area" means | Areas are address ranges inside each process's own virtual address space, mapped to real RAM pages by the OS and CPU | The lesson used "area" before explaining virtual memory | Pending (\[8\] in check) |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.6 (clarification) | If data dies when the function returns, how can `square` return 9? | The variables die with the frame; the returned value is copied out first (in a register) and the caller keeps its own copy. | "Data" was used for both the variable and its value | Pending |
| 0.6 | Infinite recursion causes a "panic (stack overflow)" (\[6\]) | It is a **fatal error** (`fatal error: stack overflow`). Panics can be recovered; fatal errors cannot. | Both stop the program with a trace and exit code 2 | Pending |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 0.6 | "Yes, the spec guarantees local variables live on the stack, because they are used locally" (follow-up \[1\]) | The spec never mentions stack or heap. It only promises how long a variable can be used. The compiler decides placement: a local that escapes goes to the heap, and even a very large local that never escapes can be put on the heap. Usually-on-the-stack is common behaviour, not a promise. | The common case was mistaken for a rule | Pending |
| 0.6 | square(4) reuses square(3)'s memory "because of LIFO order" (follow-up \[2\]) | LIFO is the rule; the mechanism is: returning only moves the stack pointer back down. That space is now considered free, so the next call's frame is placed at the same spot and overwrites the old bytes. | The rule and the mechanism were mixed together | Pending |
| 0.6 | The infinite-recursion program's exit code is 1 (follow-up \[4\]) | 1 is `go run`'s own exit code. The program itself exited with 2 (`go run` prints `exit status 2`). Same lesson as DT-9: run the binary directly to see the real code. | `echo $?` after `go run` shows go run's code | Pending |
| 0.1 review | Review answer: "invalid operation, type mismatch" | Correct kind (type mismatch = type error), finally! Missing: the fix, `x * float64(n)` | — | Category improved; give the fix next time |

**Stage 0 Project entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| Project 0 | `uint8(300)` and `int8(300)` are both 44 "because 300 is positive, and signed and unsigned store the same binary, only the sign differs" (\[1\]) | Two steps. (1) Truncation: 300 = `1 0010 1100` needs 9 bits; the conversion keeps only the lowest 8: `0010 1100` = 44. (2) Reading: the top bit of `0010 1100` is 0, so the −128 place adds nothing, and int8 also reads 44. "Positive" is not the reason: 200 is positive but `int8(200)` = −56, because its low 8 bits `1100 1000` have the top bit set. | Mixed up "the original number is positive" with "the top bit of the kept 8 bits is 0" | Pending |
| 0.6 review | Review b answered by copying the lesson's sentences | Own words are needed to show understanding | The lesson text is correct, so copying feels safe | Pending (transfer question) |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| Project 0 | Requirement 2 (`0x` prefix on hex) missed: output `C8` | Requirement says `0xC8`. Read the requirement list once more against the final output before submitting. | The other requirements were met, so it felt complete | Pending (revision) |
| 0.6 / Project \[4\] | "Go has a garbage collector which cleans the memory" as part of how stack frames start clean | The GC manages the HEAP only. Stack frames are created and removed just by moving the stack pointer. The GC does read stacks (to find roots), but never cleans them. Clean starting values come from zero-initialization (DT-43). | Both GC and stack are "memory cleanup" ideas | Pending |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| Project 0 revision | Used `%#x` for "uppercase hex with 0x prefix" (gives `0xc8`, lowercase) | `%#X` gives `0XC8` (uppercase prefix too). `0x` + uppercase digits needs `"0x%X"`, and for negatives a separate rule, which needs `if/else` (Unit 1.6). | `%#x` adds the prefix, so the case was overlooked | Carried to Unit 1.6 |
| Project 0 revision | Said `uint8(n)` is the better choice, but code still uses `n&0xFF`; outputs for 200 and −1 and the reason for the hex style not given | When you decide something in review, change the code to match the decision. Answer every sub-part. | The explanation felt like the work | Carried to Unit 1.6 |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.1 (wording) | "int8 can't hold −128 to 127, so minus 1 caused truncation" (\[6\]) | int8 CAN hold −128 to 127; it cannot hold −129. With bits: `1000 0000` (−128) minus 1 = `0111 1111` = 127. That is wraparound, not truncation (truncation is what a conversion to a smaller type does). | The right idea, said loosely | Pending |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.2 (recurring, also 0.3 \[14\]) | `const limit int = 10; var f float64 = limit` fails because "cannot reassign to a const" (\[1e\]) | Nothing is reassigned: `limit` is only READ, to give `f` its first value. The real problem: `limit` is a TYPED constant (type int), so it does not adapt; putting an int into a float64 is a type error (`cannot use limit (constant 10 of type int) as float64 value`). Fixes: make it untyped (`const limit = 10`) or convert (`float64(limit)`). | "const" is strongly linked in memory with "cannot be changed", so every const error gets that label | Fixed (1.3 retest R1: explained as int vs float64 type mismatch; fixes given) |
| 1.2 (habit) | Prediction marked "same as actual" for (e), but the real compiler message does not mention reassignment | Running the code and reading the message would have shown the real reason | — | Pending |

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.3 | `var f float64 = 9 / 2; fmt.Println(f)` prints `4.0` (\[1f\]) | It prints `4`. `Println` prints floats in the shortest exact form (DT-57). `%.1f` forces `4.0`. | Python and Java print `4.0`; the "actual" line was not from a real run | Fixed (1.4 \[6\]: real run shows `4` and `4.0`) |
| 1.3 (wording) | "The post-increment operator x++ is not valid in Go" (\[5\]) | `x++` IS valid as a statement on its own line; it is invalid inside an expression like `y := x++`. | The error message mentions `++` | Pending |
| 1.3 (habit) | R2: the fix for `price * qty` was not written | Fix: `price * float64(qty)` | — | Pending |

**Unit 1.4 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.4 | Predicted `a &^ b` = `0000 1000` for a = `1100 1010`, b = `0101 0110` | Keep a bit of `a` only where `b` has 0. Top bit: a = 1, b = 0, so it STAYS 1. Result `1000 1000`. | The top bit was cleared by mistake | Fixed (variant \[3\] correct with bit-7 reasoning) |
| 1.4 | Did not explain why −7 >> 1 differs from −7 / 2 | Shift right rounds DOWN (towards minus infinity): −3.5 → −4. Division rounds towards ZERO: −3.5 → −3. Same for positive numbers. | Both are "divide by 2" in everyday thinking | Explained in lesson feedback; will reappear in review |

**Unit 1.5 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.5 (requirement) | Money task printed `total: 425` instead of `₹4.25` | Keep the int in paise, and format only when showing: `fmt.Printf("₹%d.%02d\n", total/100, total%100)`. `%02d` alone pads 425 to at least 2 digits, so it changes nothing here. | The paise part (the hard idea) was right, so the output felt done | Pending (1.6 check \[1\]) |
| 1.5 (wording) | "Variables are compiled in runtime" | Variables are CALCULATED at run time. Compiling happens once, before running; the compiler turns the code into instructions, and the CPU runs them later. | "Compile time vs run time" words got mixed | Pending |

**Unit 1.6 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.6 (requirement) | numinfo "upgrade" written as a new small program: `fmt.Scan(&n)`, no argument check, no error check, other lines removed, low 8 bits printed in decimal | An upgrade keeps everything that already works (os.Args, validation, exit codes, all 10 lines) and changes only what was asked. `fmt.Scan` reads typed input (stdin), not arguments, and its error was ignored: typing `abc` would silently leave n = 0 and print "zero", breaking P-4. | Writing fresh felt quicker than editing | Pending (1.7 check \[7\]) |
| 1.6 (bonus) | MinInt64 problem explained, but actual output not shown | Real output: `hex: -0x-8000000000000000` (a double minus), because `-n` is still MinInt64 and `%X` prints negative numbers with a sign. Fix: print `uint64(-n)` (DT-70). | Reasoning felt like enough | Pending |

**Unit 1.7 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.7 | The unsigned countdown prints 3 2 1 0 255 254 … (\[6\]) | The loop used `uint`, which is 64 bits on your Mac, so 0 − 1 wraps to 18,446,744,073,709,551,615. 255 would only appear with `uint8`. | Most Stage 0 examples used uint8 | Pending |
| 1.7 (requirement, 3rd time) | numinfo final version: the same `fmt.Scan` program was pasted again, unchanged | The task said: start from the ORIGINAL numinfo and change three specific lines. See the 1.8 check \[1\] for exact steps. | Possibly the wrong file was pasted | Pending |

**Unit 1.8 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.8 | `largest` reads `nums[0]` first, then checks `len(nums) == 0` (\[4\]) | With zero arguments, `nums[0]` panics (`index out of range [0] with length 0`) before the check is reached. The guard clause must come FIRST (P-9). And the zero-argument case was the one you designed for, so it is the one you must test. | The check was written, so the case felt handled | Fixed in the 1.9 fix-up |
| 1.8 (wording) | "Return a tuple of value, bool" | Go has no tuple type. A function can return several values, but they are not one combined value: you cannot store them in one variable (DT-79). | Python and other languages return tuples | Pending |
| 1.8 | \[5\] failed to compile: "maybe because the function is not yet defined"; asked what the default value of a function type is | Two different things. (1) `apply` was never written in your file, so `undefined: apply` is a COMPILE error. (2) A function VARIABLE that is declared but not assigned (`var g func(int) int`) has the zero value `nil`; calling it compiles but PANICS at run time (DT-77). | Both feel like "the function does not exist" | Pending (1.9 check \[2\]) |
| 1.8 | \[6\]: drew the stack but did not write the code, print the result, or explain removing the base case | factorial(5) = 120. Without the base case, calls never stop, frames pile up, and the program dies with `fatal error: stack overflow` (DT-39). | — | Pending |

**Unit 1.9 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.8 → 1.9 (2nd time) | `largest` still reads `nums[0]` before the empty check, and `largest()` with zero arguments was not run, although the task asked for it | Go runs lines top to bottom. With zero arguments, line 1 (`nums[0]`) panics before line 2 (the check) is ever reached. Move the check to the very first line, then RUN the zero-argument case to prove it. | The rename was done, so the fix felt complete; without running the risky case, the panic stays invisible | Fixed: guard first; largest() now prints "no numbers" |
| 1.8 \[6\] | "Without a base case it will run forever" | Not forever: every call adds a stack frame, the stack grows until the 1 GB limit, then `fatal error: stack overflow`. An infinite LOOP runs forever (no growth); infinite RECURSION dies. | Both are "never stops" in everyday thinking | Pending |
| 1.9 \[4\] | Predicted 11, 12, 13 | Scope idea correct (the right side uses the OUTER total). But `range 3` gives i = 0, 1, 2, so the lines are 10, 11, 12 (off-by-one; range starts at 0, Unit 1.7). "Actual" was not filled from a run. | Counted from 1 instead of 0 | Pending |
| 1.9 \[6a\] (wording) | "max is recreated as a new variable" | Nothing is recreated: the built-in `max` still exists in the universe scope. A NEW local variable named `max` hides (shadows) it inside this block. | — | — |

**Unit 1.10 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.10 | To keep "Asha", wrote `name := name` INSIDE the closure (\[3\]) | Code inside a closure runs only when the closure is CALLED. By then `name` is already "Ravi", so the "photo" captures Ravi. The copy must be taken OUTSIDE, before the change: `photo := name` above the closure, then use `photo` inside. WHERE (and so WHEN) the copy happens decides the value. | The copy is written "before" the print line, so it feels early enough | Fixed: photo taken outside, before the change (Asha and price: 100 versions both correct) |
| 1.10 | \[2\]: gave the reason but not the predicted output | Output: 3, then 100. Both closures look through windows at the SAME variable `n`. | — | — |

**Unit 1.11 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.11 | "The panic message appears first, then 'deferred runs', because deferred functions run in LIFO order during a panic" (\[6\]) | "deferred runs" appears FIRST. When a panic happens, Go first runs all deferred calls, and only after that prints `panic: ...` and the trace (DT-90). LIFO only decides the order AMONG several deferred calls; it says nothing about the panic message. | LIFO was the most recent rule, so it was applied to everything; the code was not run | Fixed (1.12 \[1\]: explained that defers run while the panic unwinds, before the message is printed) |
| 1.11 | \[5\] answered only "cleanup is not printed" | Also needed: the real run (`working`, exit code 1) and why it matters: anything deferred (closing files, flushing buffered output, removing temp files) is silently skipped. Fix: the `run()` pattern (P-14). | — | Pending (1.12 check \[2\]) |

**Unit 1.12 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.12 \[2\] | Pasted the lesson's run() template instead of writing the task (old code had been deleted) | The task: run() prints "working", returns `errors.New("something failed")`; output shows working, cleanup, the error on stderr, exit code 1. | The code was gone from the Mac | Pending (1.13 check \[1\]) |
| 1.12 \[6\] | Tested only by typing (with go run), not with the two required `printf` pipes; invalid input is skipped silently | Run the exact required tests, especially the EOF case (`printf "abc\n" \| ./age; echo $?`). Tell the user WHY input was rejected (on stderr), otherwise they cannot fix it. | Typing felt like testing | Pending (1.13 check \[2\]) |

**Stage 1 Project entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| Project 1 | `Scan()` returning false = the input ended | `Scan()` returns false for EOF AND for real errors (including a too-long line). Always check `scanner.Err()` after it returns false and report a real error differently from a normal end. | In every manual test, false always meant Ctrl+D or end of pipe | Fixed in version 2 (both loops) |
| Project 1 | Print a message on stderr AND return an error for the same problem | One problem, one report. Put the details into the returned error (`fmt.Errorf`) and let `main` print it once. | Both lines felt helpful | Fixed in version 2 |
| Project 1 (habit) | 3 of 7 tests and all 3 reflection questions skipped | The test plan and questions are part of the deliverable. The skipped win test is exactly the path that was never run (same lesson as `largest()`). | The code felt finished | Still pending: version 2 was submitted without test outputs or answers |
| Project 1 | `rand.IntN(maxNumber) + minNumber` | Correct only while `minNumber` is 1. General: `minNumber + rand.IntN(maxNumber-minNumber+1)`. Named constants must work for any value. | It gives the right range today | Pending |

**Unit 1.11 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.11 | Defers added in a loop run in loop order: defer 0, defer 1, defer 2 (\[2\]) | LIFO applies to every defer, including ones added in a loop. Each round puts a new note ON TOP of the pile. After the loop the pile (top to bottom) is: defer 2, defer 1, defer 0. Leaving the function takes from the top: 2, 1, 0. | In \[3\] LIFO was applied correctly to two separate lines, but a loop "looks" like it should keep its own order | Pending (retest) |
| 1.11 | When a panic happens, the panic message appears first, then "deferred runs" "because of LIFO" (\[6\]) | Order: Go first runs all deferred calls (so cleanup happens), and only after that, since nobody recovered, prints `panic: ...` and exits. Output: `deferred runs` ABOVE the panic message (DT-90). LIFO is about the order of several defers among themselves, not about defers vs the panic message. | "Panic happens first" in time, so its message feels like it should print first | Pending (retest) |
| 1.11 (habit, important) | "Actual" for \[2\] written the same as the prediction, but the real output is different | Never fill "Actual" without running. If you did not run it, write "not run". A copied prediction hides exactly the mistakes the check is designed to find. (Same issue as 1.3 \[1f\].) | Confidence in the prediction | Pending |
| 1.11 | \[1a\]: pasted the fixed code instead of running the OLD code and explaining its output; \[5\]: binary + `echo $?` and "why it matters" not done | Old code prints "Hi Ravi" (copy taken at call time). \[5\]: exit code 1; real programs lose cleanup: files not flushed or closed, temp files left behind, final logs never written. | — | Pending |

**Unit 1.7 entries:**

| Unit | Your wrong idea | Correct idea | Why the wrong idea felt right | Retest result |
| --- | --- | --- | --- | --- |
| 1.7 | The unsigned countdown `for i := uint(3); i >= 0; i--` prints 3 2 1 0 then 255, 254, … (\[6\]) | `uint` is 64 bits on your Mac (DT-14), so 0 − 1 wraps to 18,446,744,073,709,551,615, then counts down from there. 255 would only be right for `uint8`. The wrap idea and the fix (check `i == 0` and break before decrementing) were correct. | `uint8` examples from Stage 0 were remembered as "unsigned" in general | Pending |

Status note (1.7 check): answers to \[1\]–\[5\] were correct, but \[7\] was answered with text written by an AI assistant ("I don't have the exact original numinfo in the available context… Paste the original…"). Mastery of 1.7 is on hold until the working arrangement is agreed again.

## Deep & Tricky Go Knowledge

Things many working developers never learn properly. Each entry says whether it is a language guarantee, toolchain behaviour, or an implementation detail.

### From Unit 0.1

**DT-1. `go run` still compiles, and Go caches builds.** *(Toolchain behaviour)* `go run` builds a real binary in a temporary folder, runs it, and deletes it. Compiled packages are kept in the build cache (see `go env GOCACHE`). That is why the second build of the same code is much faster than the first.

**DT-2. Your binary carries the Go runtime inside it.** *(Implementation detail)* Even "Hello, Go" includes the garbage collector, the goroutine scheduler, and memory-management code. So a Go hello-world binary is usually a few MB, while an equivalent C program can be a few KB. Exact size depends on Go version, OS, and CPU type. Benefit: you copy one file to a server and it runs, with no separate runtime to install.

**DT-3. Cross-compilation is built in.** *(Toolchain behaviour)* `GOOS=linux GOARCH=arm64 go build` on a Windows or Mac laptop produces a Linux ARM binary. `go tool dist list` shows every supported OS/CPU pair. Machine code is specific to OS + CPU, which is why this setting exists.

**DT-4. Pure Go programs are usually statically linked.** *(Toolchain behaviour)* Statically linked means all needed code is inside the one file. If a program uses cgo (calling C code), the binary may depend on system C libraries instead. Some standard-library packages can use cgo on some platforms. `CGO_ENABLED=0` forces pure Go. We will study this properly in Stage 11 (containers).

**DT-5. Unused imports vs unused variables — two different rules.** *(Guarantee vs implementation restriction)* The Go specification itself makes an unused import illegal. For an unused local variable, the spec only *allows* compilers to reject it, and the standard Go compiler does. Unused package-level (global) variables are allowed. Most people think both are the same rule.

**DT-6. Division by zero: compile time, run time, and floats all differ.** *(Guarantee, with one implementation-specific part)*

- `10 / 0` with constants: compile error. The spec requires constant division to have a non-zero divisor.
- `10 / x` where `x` is an int variable holding 0: run-time panic. The spec requires this.
- `a / b` with float64 variables where `b` is 0: no panic in the standard Go compiler; result is `+Inf` (or `NaN` for `0/0`). The spec leaves floating-point division by zero to IEEE 754 rules, and says whether a panic happens is implementation-specific.
- An unrecovered panic makes the process exit with code 2 in the current runtime (normal success is 0).

**DT-7. `NaN` is not equal to itself.** *(Guarantee: Go follows IEEE 754 for float comparison)* `x := 0.0; y := x / x` makes `y` a `NaN`. Then `y == y` is `false`, and `y != y` is `true`. So you can never check for NaN with `==`. Use `math.IsNaN(y)`. This also causes surprises later with maps and sorting.

**DT-8. Same zero, different verdict: int variable vs float variable.** *(Compiler behaviour, consistent with the spec)*

- `x := 7; fmt.Println(x / 0)` is a **compile error**. The divisor is a constant zero and the operands are integers, so the compiler knows it must panic, and rejects it early.
- `f := 7.0; fmt.Println(f / 0)` **compiles** and prints `+Inf`. For floats, a zero divisor has a legal answer, so there is nothing to reject.
- `d := 0; fmt.Println(7 / d)` compiles and **panics** at run time. The compiler does not track the value inside a variable here.

Lesson: the compiler rejects what it can prove is wrong from constants and types. It does not run your program in its head.

**DT-9. `go run` hides the real exit code.** *(Toolchain behaviour; `go help run` documents it)* The documentation says the exit status of `go run` is not the exit status of your compiled program. When your program fails, `go run` prints a line like `exit status 2` (your program's real code) and then exits with its own status (historically 1). In scripts and CI, build the binary and run it directly if the exit code matters. Confirmed from \`go help run\` by you: "The exit status of Run is not the exit status of the compiled binary." Also notice from your own output: the line \`exit status 2\` is printed by \`go run\`, not by your program. When you ran \`./hellp\` directly, that line did not appear. Verified on Go 1.27.1 (macOS, arm64) in \~/exitdemo: \`go run . ; echo $?\` gave 1, and \`./exitdemo ; echo $?\` gave 2. Why: \`go run\` is itself a process (the go tool). It builds your program, starts it as a separate child process, waits, and prints the child's status as text (\`exit status 2\`). Then it exits with its OWN code, 1, meaning "the thing I ran failed".

**DT-10. Go constants are exact numbers, not IEEE floats.** *(Guarantee: Go specification)* The spec says numeric constants are exact values of arbitrary precision and never overflow. Because of this, no constant can be `+Inf`, `-Inf`, or `NaN`. So:

- `fmt.Println(4.0 / 0.0)` is a compile error. Both are constants, the compiler must calculate an exact answer, and none exists.
- `a := 4.0; fmt.Println(a / 0.0)` compiles and prints `+Inf`. Now `a` is a float64 variable, and the division happens at run time using IEEE 754 rules.

First question to ask for any expression: "Will the compiler calculate this, or will it happen at run time?" Only then ask "int or float?". Constants get a full lesson in Stage 1.

**DT-11. `$?` remembers only the last command.** *(Shell behaviour, not Go)* Every command, including `echo`, sets `$?`. To see a program's exit code, check it immediately: `./app; echo $?`. In PowerShell the equivalent is `$LASTEXITCODE`.

**DT-12. Your binary carries debug information too.** *(Toolchain behaviour)* Your `file` output said `statically linked` (confirms DT-4) and `with debug_info, not stripped`. The binary contains a symbol table and debugging data, which help stack traces and debuggers. `go build -ldflags="-s -w"` removes most of it: `-s` drops the symbol table, `-w` drops the DWARF debug data. The binary gets smaller, but debugging tools get less information. Panic stack traces still show function names, because the Go runtime keeps its own separate table for that.

### From Unit 0.2

**DT-13. A leading zero makes a number octal.** *(Guarantee: Go specification)* `fmt.Println(010)` prints `8`, not `10`. Any integer literal starting with `0` (and more digits) is read as base 8. This comes from C and has caused real bugs, for example file permissions like `0755`. Since Go 1.13 you can write `0o755`, which makes the base obvious. Prefer `0o`.

**DT-14. The size of `int` is not fixed by the language.** *(Guarantee that it is 32 OR 64 bits; which one depends on the platform)* The spec says `int` and `uint` are either 32 or 64 bits. On your Mac (arm64) and on normal servers they are 64 bits. On some 32-bit systems they are 32 bits. When the exact size matters (file formats, network protocols), use sized types like `int32` or `int64`.

**DT-15. `byte` is just another name for `uint8`.** *(Guarantee)* `byte` and `uint8` are identical types, not two similar types. Same for `rune` and `int32`. Code can use either name interchangeably.

**DT-16. Byte order (endianness) — the `LSB` in your `file` output.** *(Hardware/platform property)* A 4-byte number must be stored in 4 neighbouring memory boxes. Which end goes first? **Little-endian** stores the least significant byte first (the `LSB` in `ELF 64-bit LSB`). x86-64 and arm64 as used on your Mac and normal Linux servers are little-endian. Network protocols traditionally use **big-endian** ("network byte order"). Go's `encoding/binary` package makes you choose explicitly (`binary.LittleEndian` or `binary.BigEndian`) when turning numbers into bytes. Getting this wrong makes numbers read back as garbage. Full lesson in Stage 5.

**DT-17. Why `{` must be on the same line: automatic semicolons.** *(Guarantee: Go specification)* You almost never type `;` in Go, but the grammar still uses them. The lexer (the first stage of the compiler, which splits text into tokens) automatically inserts a `;` at the end of a line if the line's last token is an identifier, a literal, one of `break continue fallthrough return`, or one of `++ -- ) ] }`. `func main()` ends with `)`, so it becomes `func main();`. The `{` on the next line now starts a new statement, which is illegal: `syntax error: unexpected semicolon or newline before {`. This is not a style preference like in C or Java; it is grammar. The same rule means a multi-line function call or composite literal needs a trailing comma on its last line, which you will see often.

**DT-18. `%x` vs `%X` bugs hide when there are no letters.** *(fmt behaviour)* For 34 the hex is `22`, identical in both verbs. The difference only appears with digits A–F. General lesson for testing: choose test values that can actually reveal the bug.

### From Unit 0.3

**DT-19. Integer overflow never panics in Go, and the result is defined.** *(Guarantee)* The spec says unsigned `+ - *` are computed modulo 2^n, and overflow does not cause a run-time panic. Compare with C: unsigned wraps there too, but signed overflow in C is "undefined behaviour", meaning the compiler may assume it never happens and produce strange code. Go defines signed overflow as well (Unit 0.4). Predictable, but silent.

**DT-20. `fmt.Println(math.MaxUint64)` does not compile.** *(Guarantee, from constant rules)* `math.MaxUint64` is an untyped constant. When you pass an untyped integer constant to `Println`, Go gives it its default type, `int`. The value 18,446,744,073,709,551,615 does not fit in a 64-bit `int` (signed, max about 9.2 × 10^18), so it is a compile error saying it overflows int. Fix: give it a type first, `fmt.Println(uint64(math.MaxUint64))`. Many experienced developers are surprised by this one.

**DT-21. "Underflow" is used loosely.** *(Terminology)* People often say "underflow" for `0 − 1` wrapping to the maximum. Strictly, integer wrapping in either direction is overflow (wraparound). "Underflow" properly means a float result too close to zero to represent. Know both uses so you understand colleagues and documentation.

**DT-22. A countdown with an unsigned counter never ends.** *(Consequence of DT-19; loops come in Stage 1)* `for i := uint(3); i >= 0; i-- { ... }` loops forever: an unsigned value is always `>= 0`, and after 0 it wraps to the maximum. Linters such as staticcheck warn that the condition is always true. One more reason for P-1.

### From Unit 0.4

**DT-23. Same bits, different number — the type decides.** *(Fundamental)* Memory stores only bits. `1111 1111` is 255 as `uint8` and −1 as `int8`. The CPU's addition gives identical bits for both. This is why conversions like `uint8(x)` between same-size integer types cost nothing at run time: no bits change.

**DT-24. Negating the minimum value gives itself.** *(Guarantee, consequence of two's complement)* `var x int8 = -128; x = -x` leaves `x` = −128, because +128 does not exist in int8 (flip `1000 0000` → `0111 1111`, add 1 → `1000 0000`). So an "absolute value" function can return a NEGATIVE number for `math.MinInt64`. A classic bug in code that does `if x < 0 { x = -x }` and then assumes `x >= 0`.

**DT-25. `math.MinInt64 / -1` does not crash in Go.** *(Guarantee: Go specification)* The true answer (+9.2 × 10^18 + 1) does not fit. The Go spec says this quotient equals the dividend (MinInt64) and the remainder is 0. On x86 CPUs this division normally triggers a hardware fault (in C it is undefined behaviour and often crashes); Go's compiler handles this case so the result is defined.

**DT-26. The compiler may NOT assume `x < x + 1`.** *(Guarantee: Go specification)* Because Go defines signed overflow as wrapping, the spec explicitly says a compiler may not optimise code assuming overflow never happens, and gives `x < x + 1` as the example: it is false when `x` is the max value. C compilers may assume the opposite, which has produced famous security bugs where overflow checks were optimised away.

**DT-27. `uint8(-5)` vs `uint8(x)` — "who calculates?" once more.** *(Guarantee)* Constant conversion: compile error, the value −5 cannot be represented as uint8. Variable conversion: allowed, keeps the bits, gives 251. Same text, different rules, decided by whether the compiler or the run time does the work.

**DT-28. Who really drops the 9th bit? The compiler plans it, the CPU does it.** *(Implementation detail; varies by CPU and Go version)* Modern 64-bit CPUs (amd64, arm64) usually do small-integer arithmetic in full 64-bit registers. arm64 has no 8-bit arithmetic registers at all. So for `b = b + 1` with a `uint8`, the compiler typically generates a normal wide addition, plus an instruction that keeps only the lowest 8 bits (a "zero-extend"), or it stores just one byte to memory. Then, at run time, the CPU executes those instructions. So the correct answer to "who discards the bit, and when?" is: the CPU, at run time, by executing instructions the compiler chose in advance. The compiler cannot discard anything itself, because it never knows the run-time value. (A plain arm64 ADD does not even set a carry flag.) You will be able to see the generated instructions yourself in Stage 10 with `go build -gcflags=-S`.

**DT-29. Same size, different type: `int` vs `int64`.** *(Guarantee)* Even where `int` is 64 bits, `int` and `int64` are distinct types. `a + b` with `a int` and `b int64` is a type error: `mismatched types int and int64`. Go never converts between numeric types automatically; you must write `int64(a) + b`. This explicitness prevents silent overflow and precision bugs when moving values between types.

### From Unit 0.5

**DT-30. Constant folding: `c := 2 + 3` has no ADD at run time.** *(Constant expressions: guarantee; folding of other known values: optimisation)* The spec says constant expressions are evaluated exactly at compile time, so the binary simply contains 5. Optimising compilers also fold some non-constant cases when they can prove the values. This is "who calculates?" seen from the machine-code side.

**DT-31. Same ADD, different compare and divide.** *(Hardware fact)* Two's complement lets signed and unsigned addition share one instruction (Unit 0.4). But comparison and division do NOT share: `1000 0000 < 0000 0001` is false as uint8 (128 < 1) and true as int8 (−128 < 1). So CPUs have separate signed and unsigned versions (for example arm64 has SDIV and UDIV, and different condition codes for signed and unsigned comparisons). The CPU never sees your types; the compiler reads your types and picks the right instruction.

**DT-32. Apple Silicon uses bigger cache lines.** *(Hardware detail; check your own machine)* Most x86 CPUs use 64-byte cache lines. Apple's M-series chips report 128 bytes. This will matter in Stage 7 for "false sharing", a concurrency performance problem where two goroutines slow each other down by writing to different variables that happen to sit in the same cache line.

**DT-33. Cache lines are aligned blocks.** *(Hardware detail)* Memory is divided into fixed blocks of the cache-line size (128 bytes on your Mac): addresses 0–127, 128–255, and so on. Reading any byte loads the whole block it belongs to, not "the next 128 bytes from here". A value that crosses a block boundary needs two cache lines. This is one reason the compiler aligns values in memory (struct layout and padding come in Stage 3 and Stage 10).

### From Unit 0.6

**DT-34. The Go specification never mentions "stack" or "heap".** *(Guarantee, by absence)* The language only defines how long a variable can be used, not where it lives. Stack vs heap is entirely the compiler's choice, can differ between Go versions, and never changes what your program computes, only how fast. Example of the consequence: in Go it is completely safe for a function to return the address of its own local variable (pointers come in Stage 2). The compiler simply moves that variable to the heap. In C, the same code is a famous bug.

**DT-35. Goroutine stacks grow by copying.** *(Implementation detail; changes between versions)* An OS thread usually gets a large fixed stack (often several MB). A goroutine starts with a small stack (a few KB) and, when it needs more, the runtime allocates a bigger stack and copies the old one into it. This is why a Go program can run hundreds of thousands of goroutines. Since Go 1.19, the starting size also adapts to the average stack usage the runtime has observed.

**DT-36. Apple Silicon pages are 16 KB.** *(Platform detail)* The OS maps memory in pages. Most x86 Linux systems use 4 KB pages; Apple Silicon macOS uses 16 KB. Check with the `pagesize` command. Page size affects how much memory small programs appear to use and matters for memory-mapped files (Stage 5).

**DT-37. Goroutine stacks live in runtime-managed memory.** *(Implementation detail)* The classic "stack at the top of the address space" picture describes C programs and OS threads. Goroutine stacks are allocated by the Go runtime from memory it manages, which is what makes growing them by copying possible (DT-35). The garbage collector still treats every goroutine stack as a set of roots for reachability.

**DT-38. Go passes arguments and return values in registers.** *(Implementation detail; since Go 1.17 on amd64 and Go 1.18 on arm64)* Older Go versions passed every argument and return value through the stack, which meant extra memory loads and stores. The "register-based calling convention" (ABI) now uses CPU registers for most of them, which made typical programs a few percent faster. So `square`'s 9 travels back to the caller in a register, then the caller decides where to keep it.

**DT-39. Stack overflow is a fatal error, not a panic.** *(Runtime behaviour)* Infinite recursion keeps adding frames until the goroutine's stack hits the runtime's maximum (1 GB on 64-bit systems, shown as `goroutine stack exceeds 1000000000-byte limit`). The runtime then reports `fatal error: stack overflow` and the process exits with code 2. Unlike a panic (such as divide by zero), a fatal error cannot be caught and recovered from with `recover` (Stage 3). The program always dies.

**DT-40. Inlined functions show `(...)` in stack traces.** *(Compiler behaviour; seen in your own output)* Inlining = the compiler copies a small function's body into its caller instead of doing a real call. No real call means no real frame. But the compiler keeps a record of the inlining, so the stack trace still shows every function, in the correct order. You saw the evidence: `main.level3(...)` with `(...)` instead of argument values, and NO `+0x..` offset, while `main.main()` (a real frame) has `+0x28`. Inlining removes call overhead and often lets the compiler optimise further. Stage 10 covers it with `-gcflags=-m`.

**DT-41. Converting to a smaller integer type keeps only the lowest bits.** *(Guarantee)* `uint8(n)` for an `int` `n` keeps the lowest 8 bits and throws the rest away. 300 = `1 0010 1100` → lowest 8 bits `0010 1100` = 44. With `int8(n)`, the same lowest 8 bits are read as two's complement. No panic, no warning; it is silent like all integer overflow. (With a constant, `uint8(300)` is a compile error, "who calculates?".)

**DT-42. Even a local that never escapes may go to the heap.** *(Implementation detail)* The Go compiler puts very large local variables on the heap even if they never escape, because goroutine stacks are meant to be small (the current limit for explicitly declared variables is around 10 MB). Another proof that the spec makes no stack promise (DT-34).

**DT-43. Every variable starts at its zero value — a spec guarantee, implemented cleverly.** *(Guarantee + implementation detail)* The spec says a variable declared without a value starts at its type's **zero value**: `0` for numbers, `false` for bool, `""` for strings (more in Stage 1). So a Go program can never read leftover garbage from an old frame, unlike C. How the compiler achieves it is an implementation detail: it does NOT always wipe whole frames. It writes zeros only where needed, and skips it when the variable is assigned before any use. Memory that will hold pointers must be zeroed so the garbage collector never sees fake addresses. Why it matters: no random values, no leaking old data (a real security issue in C), and programs behave the same every run.

**DT-44. Hex formatting of negative numbers.** *(fmt behaviour)* `%X` of `-1` prints `-1`, and `%x` of `-129` prints `-81`: fmt prints a minus sign plus the size, like `%b`. `%#x` adds a `0x` prefix (`-0x81` for negatives); `%#X` gives an uppercase `0X` prefix. To show the real two's-complement bytes in hex, convert to an unsigned type first, for example `uint8(n)` or `uint64(n)`.

### From Unit 1.1

**DT-45. `:=` with existing variables: the `err` idiom.** *(Guarantee)* Because `:=` only needs one new variable on the left, Go code commonly writes:

```go
a, err := strconv.Atoi(s1)
b, err := strconv.Atoi(s2) // b is new; err is REUSED (assigned), not redeclared
```

This only reuses `err` if it was declared in the SAME scope. Inside an inner block (like an `if`), `:=` creates a brand-new `err` that hides the outer one: the famous shadowing bug (Unit 1.9).

**DT-46. Multiple assignment evaluates the right side first.** *(Guarantee: the spec defines two phases)* `a, b = b, a` swaps two values with no temporary variable. All expressions on the right are evaluated using the OLD values, then the assignments happen. So `x := 1` followed by `x, y := x+1, x+10` gives `x = 2`, `y = 11` (not 12).

**DT-47. `1e3` is a float, even though 1000 is a whole number.** *(Guarantee)* Scientific notation always makes a floating-point constant, so `n := 1e3` gives `n` the type `float64`. `'a'` is a rune constant, so `c := 'a'` makes `c` an `int32` holding 97, not a string. Check with `%T` whenever unsure.

**DT-48. "Make the zero value useful."** *(Go proverb, design principle)* Go designers aim for types whose zero value is ready to use without setup. Examples you will meet: `var sb strings.Builder` and `var mu sync.Mutex` work immediately with no constructor. You will design your own types this way in Stage 3.

**DT-49. Your editor and the compiler can word the same error differently.** *(Tooling behaviour; seen in your own answer)* For `count := 0` at package level, VS Code showed "expected declaration, found count". That message comes from gopls (the Go language server behind the VS Code extension), which uses the `go/parser` package. `go build` uses the compiler's own parser and says `syntax error: non-declaration statement outside function body`. Same problem, same category (syntax error), different words. When asked for "the compiler message", use `go build`.

### From Unit 1.2

**DT-50. `var i int = 2.0` compiles.** *(Guarantee)* An untyped constant can be converted to a type if its exact value is representable in that type. 2.0 is exactly the whole number 2, so it fits `int`. 2.5 is not, so `var i int = 2.5` fails with "truncated". The rule is about the VALUE, not about how it was written.

**DT-51. Compilers must handle very large constants.** *(Guarantee: implementation restriction in the spec)* The spec requires compilers to represent integer constants with at least 256 bits, and floating-point constants with at least a 256-bit mantissa. That is why `1 << 100` is fine as an intermediate value. Overflow is only checked when a constant is finally given a real type.

**DT-52. iota counts lines, not uses.** *(Guarantee)* Two constants on the same line share the same iota:

```go
const (
	a, b = iota, iota * 10 // a=0, b=0
	c, d                   // c=1, d=10 (line repeated with iota = 1)
)
```

**DT-53. `'a' + 1` prints 98.** *(Guarantee)* Mixing a rune constant with an integer constant gives an untyped rune constant, whose default type is `rune` (int32). `fmt.Println` prints an int32 as a number. To print the character, use `%c`: `fmt.Printf("%c\n", 'a'+1)` prints `b`.

### From Unit 1.3

**DT-54. `var f float64 = 7 / 2` gives 3, not 3.5.** *(Guarantee)* Both `7` and `2` are untyped INTEGER constants, so the compiler first calculates `7 / 2` as an integer constant expression: 3. Only then is the result converted to float64: 3.0. The float type on the left does not reach into the expression. Write `7.0 / 2` (or `7 / 2.0`) to get 3.5. The same trap appears with variables: `float64(a / b)` divides as integers first; `float64(a) / float64(b)` gives the fraction.

**DT-55. Go truncates towards zero; Python floors.** *(Guarantee)* Go: `-7 / 2` = −3 and `-7 % 2` = −1. Python: `-7 // 2` = −4 and `-7 % 2` = 1. Code translated from Python (or from maths formulas that assume a non-negative remainder) can silently break for negative inputs. Example: wrapping an index around a circular buffer with `i % n` gives a negative index when `i` is negative.

**DT-56. `x++` is a statement on purpose.** *(Language design)* In C, `y = x++ + ++x` style code is legal but confusing, and some forms are undefined. Go removed the problem: `++` and `--` cannot be used inside expressions at all, and there is no prefix form. One clear way to do it.

**DT-57. `fmt.Println` prints `4.0` as `4`, and `1000000.0` as `1e+06`.** *(fmt behaviour; corrected)* For floats, `%v` (what `Println` uses) prints the shortest text that still represents the exact value, so `4.0` prints as `4` and `4.5` as `4.5`. It switches to exponent form when the exponent is 6 or more, or less than −4: `fmt.Println(1000000.0)` prints `1e+06`, `fmt.Println(1234567.0)` prints `1.234567e+06`, and `fmt.Println(0.00001)` prints `1e-05`. (Correction: an earlier version of this note said the switch happens at `1e+21`. That threshold belongs to `encoding/json`, not `fmt`.) To control output, use `%.2f` (fixed decimals), `%e` (always exponent), or `%g` with a precision.

### From Unit 1.4

**DT-58. `-7 >> 1` is −4, but `-7 / 2` is −3.** *(Guarantee)* An arithmetic right shift rounds DOWN (towards minus infinity): `1111 1001` (−7) shifted right with sign copying gives `1111 1100` (−4). Integer division rounds towards ZERO (DT-55): −3. For non-negative numbers both give the same result, which is why compilers can replace `x / 2` with a shift only when they know `x` is not negative (or add a correction step).

**DT-59. Shifts are fully defined in Go.** *(Guarantee)* In C, shifting by a negative amount or by at least the type's width is undefined behaviour. In Go: a negative variable shift count panics (`negative shift amount`), and a too-large count gives 0 (or −1 for a negative signed value shifted right). Since Go 1.13 the shift count may also be a signed integer type; before that it had to be unsigned.

**DT-60. Untyped constants in non-constant shifts.** *(Guarantee; advanced)* In `1 << s` where `s` is a variable, the untyped `1` gets the type it would have if the shift were not there. So `var i int64 = 1 << s` makes the `1` an int64, but `var f float64 = 1 << s` is a compile error: the `1` would become a float64, and floats cannot be shifted. This example comes straight from the spec.

**DT-61. Go has no power operator.** *(Language design)* `^` is XOR. `2 ^ 3` is `0010 ^ 0011` = `0001` = 1. Powers of two: `1 << n`. Other powers: `math.Pow(x, y)`, which works on float64.

### From Unit 1.5

**DT-62. `0.1 + 0.2 == 0.3` is TRUE in Go when written as constants.** *(Guarantee)* With constants, the compiler does exact arithmetic (Unit 1.2): 0.1 + 0.2 is exactly 0.3, so the comparison is true. With float64 VARIABLES, each value is first rounded to binary, and the sum is 0.30000000000000004, so `a+b == 0.3` is false. Same text, different results: "who calculates?" once more. Many developers who know the classic 0.30000000000000004 fact are surprised by the constant case.

**DT-63. float32 → float64 shows the hidden error.** *(IEEE 754 behaviour)* `f := float32(0.1)` prints as `0.1`, because `Println` prints the shortest text that identifies that float32. But `float64(f)` prints `0.10000000149011612`: converting does not add precision back; it reveals how far the float32 value really was from 0.1.

**DT-64. Out-of-range float → int conversion does not panic.** *(Guarantee that it does not panic; the result is implementation-dependent)* `f := 1e30; i := int64(f)` compiles and runs, but the spec says the result is implementation-dependent when the value does not fit. It may differ between CPU types (amd64 vs arm64). Always check the range before converting floats that come from outside. (A constant like `int64(1e30)` is a compile error instead.)

**DT-65. Negative zero.** *(IEEE 754 behaviour)* Floats have both `+0` and `−0` (sign bit set, everything else zero). `-0.0 == 0.0` is true, so it usually does not matter, but `1 / negZero` gives `-Inf` instead of `+Inf`, and `fmt.Println` prints `-0`. Get it with `math.Copysign(0, -1)`; a constant `-0.0` is just exact 0 (no sign), so it does not produce negative zero.

**DT-66. Integers above 2^53 lose exactness in float64.** *(IEEE 754 behaviour)* `n := 9007199254740993` (2^53 + 1) as an int is exact, but `float64(n)` becomes 9007199254740992. So `int(float64(n)) == n` is false. This matters when JSON numbers pass through JavaScript (which uses float64 for all numbers): large IDs get silently changed. That is why APIs often send big IDs as strings.

### From Unit 1.6

**DT-67. `fallthrough` ignores the next case's condition.** *(Guarantee)*

```go
x := 2
switch x {
case 2:
	fmt.Println("two")
	fallthrough
case 100:
	fmt.Println("hundred") // printed, even though x is not 100
}
```

The word sounds like "continue checking", but it means "run the next body no matter what". It must be the last statement in its case, cannot appear in the last case, and is not allowed in type switches (Stage 3).

**DT-68. `break` inside a switch only leaves the switch.** *(Guarantee; matters in Unit 1.7)* A `break` written in a case ends the switch, not a surrounding `for` loop. To leave the loop from inside a switch you need a labelled break (`break outer`), covered with loops. This catches many people writing a loop with a switch inside.

**DT-69. Switch cases can be any expressions, evaluated in order.** *(Guarantee)* Case values do not have to be constants: `case x * 2:` or `case getLimit():` are legal. They are evaluated top to bottom, left to right, only until a match is found, so a function call in a later case may never run (like short-circuit evaluation). Only duplicate CONSTANT cases are rejected by the compiler.

**DT-70. Safe absolute value for printing: `uint64(-n)`.** *(Guarantee, uses DT-24 and DT-41)* For every negative int64 `n`, `uint64(-n)` gives the correct size, even for MinInt64. Why: `-n` of MinInt64 wraps back to MinInt64 (bits `1000…0000`), and reading those same bits as unsigned gives 2^63 = 9,223,372,036,854,775,808, which is exactly the right size. Small example with int8: n = −128 → −n = −128 (`1000 0000`) → `uint8` reads 128. So `fmt.Printf("-0x%X", uint64(-n))` prints `-0x8000000000000000` correctly.

### From Unit 1.7

**DT-71. Changing the loop variable: three-part loop vs range.** *(Guarantee)*

```go
for i := 0; i < 5; i++ { fmt.Print(i, " "); i += 2 } // 0 3
for i := range 5        { fmt.Print(i, " "); i += 2 } // 0 1 2 3 4
```

In a three-part loop, the change carries into the `i++` and the next check. In `range 5`, the next value always comes from the range itself (0, 1, 2, 3, 4), so changing `i` inside the body has no effect on later rounds.

**DT-72. Since Go 1.22, each loop round gets a NEW variable.** *(Guarantee; depends on the `go` line in go.mod)* Before Go 1.22, a loop had ONE variable `i` reused for all rounds. Code that captured `i` in a closure or goroutine (Unit 1.10, Stage 7) saw only the last value, a very famous bug. Since 1.22, every round has its own `i`. The rule is chosen per module by the `go` version line in `go.mod`: your `go 1.27.1` means the new behaviour. Old modules that say `go 1.21` keep the old behaviour, even with a new toolchain.

**DT-73. Labels are only for break, continue, and goto.** *(Guarantee)* A label (`outer:`) must be used, or it is a compile error (`label outer defined and not used`). `continue outer` jumps to the next round of the outer loop (running its post statement). Go also has `goto`, but it is rarely used and cannot jump over variable declarations or into blocks.

**DT-74. Adding 0.1 ten times gives 0.9999999999999999.** *(IEEE 754 behaviour)* Each addition is rounded, and the small errors build up in a loop: `total := 0.0; for range 10 { total += 0.1 }` prints `0.9999999999999999`. With paise: `p := 0; for range 10 { p += 10 }` gives exactly 100. This is P-8 in action.

### From Unit 1.8

**DT-75. Go is ALWAYS pass-by-value.** *(Guarantee)* Every argument is copied into the called function's frame: ints, floats, strings, arrays, structs, pointers, slices, maps. Some of those values (pointers, slices, maps) CONTAIN an address, so the copy still leads to the same underlying data. That is why a function can change the elements of a slice you pass in, but not the slice's length as seen by the caller (Stage 2). There is no "pass by reference" in Go. Copying a big array (for example `[1_000_000]int`) copies all of it on every call.

**DT-76. Go does not optimise tail calls.** *(Implementation behaviour)* Some languages turn `return f(n-1)` into a jump, so deep recursion uses no extra stack. Go does not: every recursive call adds a frame. Very deep recursion (millions of levels) can hit the 1 GB stack limit and die with `fatal error: stack overflow`. For very deep work, use a loop.

**DT-77. Calling a nil function value panics.** *(Guarantee)* `var f func(int) int` is `nil`. `f(3)` panics: `invalid memory address or nil pointer dereference`. Check `if f != nil` before calling a function value that may be unset.

**DT-78. Function values cannot be compared, except with nil.** *(Guarantee)* `f == g` for two function values is a compile error. Only `f == nil` is allowed. So function values cannot be map keys either.

**DT-79. Multiple results are not tuples.** *(Guarantee)* Go has no tuple type. `x := divmod(7, 2)` is a compile error (`assignment mismatch: 1 variable but divmod returns 2 values`). You also cannot put multiple results inside another expression like `divmod(7, 2) + 1`. One special case IS allowed: if a function's results exactly match another function's parameters, you can pass them straight through: `f(g())`. That is why `fmt.Println(divmod(7, 2))` works: Println accepts any number of values.

### From Unit 1.9

**DT-80. Go has only 25 keywords; `true`, `nil`, `int`, `len` are NOT keywords.** *(Guarantee)* Keywords (like `func`, `if`, `for`, `return`, `var`) can never be used as names. But `true`, `false`, `nil`, `int`, `string`, `len`, `max`, `error`, and friends are predeclared identifiers in the universe scope, so they CAN be shadowed. `true := false` compiles, and after it `fmt.Println(true)` prints `false`. Legal, confusing, and a reason linters exist.

**DT-81. Imports belong to the file, not the package.** *(Guarantee)* Two files in the same package each need their own `import "fmt"`. But package-level functions, variables, and constants are shared by all files of the package. An unused import is checked per file.

**DT-82. The compiler only catches shadowing when the inner variable is unused.** *(Compiler behaviour)* If the shadowing variable is never used, you get `declared and not used`, which sometimes reveals the bug by accident. If it IS used (for example, printed or checked), the code compiles silently. The standard `go vet` does not check shadowing by default; a separate `shadow` analyzer (also available through linters such as golangci-lint) can report it.

**DT-83. A new variable's scope starts AFTER its declaration.** *(Guarantee)* In `total := total + i` inside a block, the right side is evaluated while only the OUTER `total` is visible; the new inner `total` comes into existence after the statement. So it reads the outer value, and then shadows it. The same rule makes `x := x` legal in an inner block (it copies the outer x into a new inner x).

**DT-84. Why calling nil crashes: page zero is never mapped.** *(OS and runtime behaviour)* A Go function value is (in the current implementation) a pointer to a small block that holds the code address. A nil function value points to address 0. Operating systems deliberately leave the lowest page of every process's address space unmapped (Unit 0.6, pages), so any read there makes the CPU raise a fault (`SIGSEGV`). The Go runtime turns that fault into the panic `invalid memory address or nil pointer dereference`. The same mechanism catches nil pointers, nil maps used wrongly, and similar bugs.

### From Unit 1.10

**DT-85. Closures capture variables, not values.** *(Guarantee)* A closure refers to the variable itself. If you want a snapshot of the current value instead, copy it into a new variable first (`v := x`) and use `v` inside the closure, or pass it as an argument.

**DT-86. Captured variables that outlive their function move to the heap.** *(Implementation behaviour, via escape analysis)* In `makeCounter`, `count` must survive after `makeCounter` returns, so the compiler allocates it on the heap. You can see this with `go build -gcflags=-m`: `moved to heap: count`. If a closure is only used inside the function that created it (and does not escape), the captured variables can often stay on the stack. Each heap allocation costs a little time and adds GC work, which matters in very hot code (Stage 10).

**DT-87. The loop-variable change is per module, controlled by go.mod.** *(Guarantee, Go 1.22+)* The new per-iteration loop variables apply only to code in modules whose `go.mod` says `go 1.22` or later. The same source file prints 3 3 3 under `go 1.21` and 0 1 2 under `go 1.22`, even with the same Go toolchain installed. This is how Go changed a language rule without breaking old code.

### From Unit 1.11

**DT-88. `defer` takes a photo of the arguments, and of the function value.** *(Guarantee)* At the `defer` line, Go evaluates the function value and all arguments and stores them; only the call is postponed. So `defer fmt.Println(x)` prints the old `x`. The same rule applies to method receivers: `defer t.Stop()` uses the `t` that existed at the defer line.

**DT-89. Deferring a nil function panics LATER, not at the defer line.** *(Guarantee)* `var f func(); defer f()` does not fail when the `defer` statement runs. It panics when the function is finishing and Go tries to call `f`. The spec says this explicitly. The panic appears far from the line that caused it, which makes it confusing to debug.

**DT-90. Deferred calls run before the panic message is printed.** *(Runtime behaviour)* When a panic is not recovered, Go first runs every deferred call in every function on the way up the stack, and only then prints `panic: ...` and the stack trace. So output from deferred calls appears ABOVE the panic message.

**DT-91. Defer is almost free now (usually).** *(Implementation detail, since Go 1.14)* In most functions, the compiler "open-codes" defers: it inserts the deferred calls directly at each exit, costing only a few nanoseconds. Defers inside loops (and functions with very many defers) cannot be open-coded and use a slower path. So use defer freely for clarity, but avoid it in very hot loops (measure first, Stage 10).

### From Unit 1.12

**DT-92. bufio.Scanner has a 64 KB line limit by default.** *(Standard-library behaviour)* By default, a single line (token) longer than 64 KB (`bufio.MaxScanTokenSize`) makes `Scan()` return false, and `scanner.Err()` returns `bufio.ErrTooLong`. If you forget to check `Err()`, the program silently stops reading in the middle of the input. Raise the limit with `scanner.Buffer(make([]byte, 0, 1024*1024), 10*1024*1024)` when lines can be long (log files, JSON lines).

**DT-93. Scanner removes Windows line endings for you.** *(Standard-library behaviour)* Windows text files end lines with `\r\n`. The default line splitter (`bufio.ScanLines`) drops a trailing `\r`, so `scanner.Text()` is the same on all systems. Code that splits text by hand on `"\n"` keeps the `\r`, and then `strconv.Atoi("42\r")` fails mysteriously.

**DT-94. fmt.Scan treats newlines as spaces; fmt.Scanln does not.** *(fmt behaviour)* `fmt.Scan(&a, &b)` happily reads `a` from one line and `b` from the next line. `fmt.Scanln` stops at the end of the line and returns an error if there are not enough values on it. Mixing these with each other, or with `bufio.Scanner` on the same stdin, gives confusing results because each may have read ahead and buffered input the other never sees.

### From Unit 1.13

**DT-95. Old math/rand gave the SAME numbers every run (before Go 1.20).** *(History; version-dependent)* In the original `math/rand`, the global generator started from seed 1 unless you called `rand.Seed`. Every run of a program produced exactly the same "random" sequence, which surprised countless beginners (and created predictable values in real software). Since Go 1.20 the global generator is seeded randomly, `rand.Seed` is deprecated, and `math/rand/v2` (Go 1.22) is the modern package. Old blog posts and Stack Overflow answers still show `rand.Seed(time.Now().UnixNano())`; you do not need it.

**DT-96. Modulo bias: why `rand.IntN` exists.** *(Maths + library design)* Turning a random 0–255 value into a dice roll with `% 6` is slightly unfair: 256 is not a multiple of 6, so the remainders 0–3 appear 43 times each but 4–5 only 42 times. With huge ranges the bias is tiny, but it is real. `rand.IntN(n)` uses a method that gives every value exactly the same chance. Prefer it over `% n` on raw random numbers.

**DT-97. crypto/rand.Read no longer returns an error (Go 1.24+).** *(Version-dependent)* Since Go 1.24, `crypto/rand.Read` is guaranteed to fill the buffer; if the operating system cannot provide randomness, the program crashes instead of returning an error (continuing with weak randomness would be worse). Older code checks its error; that check is now unnecessary but harmless.

### From Unit 2.1

**DT-98. `range` over an array iterates over a COPY of the array.** *(Guarantee)* The range expression is evaluated once before the loop starts. For an array, that means the whole array is copied when you use the value variable. So changing `arr[2]` inside `for i, v := range arr` does not change the `v` values you see later in the same loop. Ranging over `&arr` (a pointer, Stage 2) or a slice avoids the copy and sees the changes.

**DT-99. Constant indexes are checked at compile time.** *(Guarantee)* `a[5]` on a `[3]int` with a constant 5 does not compile. With a variable index, the compiler inserts a bounds check that panics at run time. When the compiler can prove an index is always valid (for example `for i := range a { a[i] }`), it removes the check: "bounds-check elimination" (Stage 10).

**DT-100. Arrays are comparable and can be map keys; slices cannot.** *(Guarantee)* `[3]int{1, 2, 3} == [3]int{1, 2, 3}` is true. This makes arrays useful as composite map keys, for example `map[[2]int]bool` for visited grid cells (useful in Stage 6 and in routing). Slices cannot be compared with `==` (only with nil) and cannot be map keys.

## Go Patterns & Engineering Practices

Patterns are added only when a real problem in the lessons needs them. Each entry will record: the problem it solves, why Go developers use it, when NOT to use it, and its trade-offs.

**P-0. Fail early (engineering principle, not yet a code pattern).** Prefer errors that are caught at compile time over errors found at run time, and run-time errors caught in tests over errors found by users. Go's strict compiler (unused imports, static types) is designed around this idea.

**P-1. Use `int` for counts and sizes; keep unsigned types for bits and bytes.** *(Go convention)*

- *Problem it solves:* unsigned subtraction below zero silently wraps to a huge number (warehouse stock bug, endless countdown loop).
- *Why Go developers do it:* the standard library itself returns `int` from `len()` and `cap()`, even though lengths are never negative. A negative `int` is an obvious wrong value that is easy to notice and check; a wrapped unsigned value looks like a real, large number.
- *When to use unsigned:* raw bytes (`byte`), bit manipulation, hashes, binary file and network formats where the size is fixed by a specification.
- *Trade-off:* you lose the positive half of the range compared with the same-size unsigned type. With 64 bits this almost never matters.

**P-2. Check before you calculate, when overflow matters.** *(Defensive pattern; full code after `if` in Stage 1)* Go will not warn you at run time. When values come from users or outside systems, check that the operation fits BEFORE doing it (for example, "is `a` greater than `math.MaxUint8 - b`?"). The `math/bits` package also has functions like `bits.Add64` that return a carry flag telling you whether overflow happened.

**P-3. CLI convention: results to stdout, errors to stderr, non-zero exit code on failure.** *(Unix and Go convention)*

- *Problem it solves:* scripts and other programs need to tell success from failure, and separate real output from error messages.
- *How:* every process has two output streams: **stdout** (normal output, `fmt.Println`) and **stderr** (errors, `fmt.Fprintln(os.Stderr, ...)`). A shell can redirect them separately: `./numinfo 42 > out.txt` saves only stdout, and errors still appear on screen. On failure, exit with a non-zero code: `os.Exit(1)`.
- *Why Go developers do it:* the `go` tool and almost every Go CLI behave this way; CI systems and shell scripts depend on it.
- *When not to:* inside library code, never call `os.Exit`. Libraries return errors (Stage 3) and let `main` decide. `os.Exit` also skips deferred cleanup (Stage 1).

**P-4. Validate input at the edge.** *(Engineering practice)* Check everything that comes from outside (command-line arguments, files, network) as soon as it enters the program, and stop with a clear message if it is wrong. The rest of the program can then trust its data. In numinfo: wrong number of arguments and non-numeric input are rejected in the first few lines of `main`.

**P-5. Always format with `gofmt`.** *(Go convention, universal)*

- *Problem it solves:* teams waste time arguing about spaces, braces, and alignment, and diffs fill with formatting noise.
- *How:* `gofmt -d file.go` shows what it would change; `gofmt -w file.go` (or `go fmt ./...`) rewrites the files. Most editors run it on save.
- *Why Go developers do it:* Go has exactly one official format, and almost all public Go code uses it. Code that is not gofmt'd looks unprofessional in review.
- *When not to:* never skip it. It only changes layout, never behaviour.

**P-6. Name constants in MixedCaps, never ALL\_CAPS.** *(Go convention)*

- *How:* `maxRetries` (only usable inside its package) or `MaxRetries` (usable from other packages; the first letter decides visibility, Stage 3). Not `MAX_RETRIES`.
- *Why:* in Go, capitalisation already has a meaning (exported or not), so ALL\_CAPS would make every constant exported and look foreign to Go readers. The standard library follows this: `math.MaxInt64`, `http.StatusOK`.
- *Also:* replace "magic numbers" with named constants: `const maxUploadSize = 10 << 20` is clearer than a bare `10485760` in the middle of code.

**P-7. Bit flags for small sets of on/off options.** *(Common pattern, especially at system boundaries)*

- *Problem it solves:* storing several yes/no options compactly and combining them in one value: file permissions, protocol header flags, OS options. The standard library does this, for example `os.O_RDONLY | os.O_CREATE` when opening files.
- *How:* `const ( A = 1 << iota; B; C )`, then `|` to combine, `&` with `!= 0` to check, `&^` to clear.
- *Why Go developers use it:* cheap to store, copy, and compare; matches how operating systems and network formats already represent options.
- *When NOT to use it:* for a few options inside ordinary application code, separate `bool` fields (Stage 3 structs) are easier to read and debug. Bit flags also stop at 64 options in one `uint64`.
- *Trade-off:* compact and fast versus less readable. Printing a flags value shows a number, not names, unless you write extra code.

**P-8. Never use floats for money; use integer minor units.** *(Universal engineering practice)*

- *Problem it solves:* 0.1 and 0.01 are not exact in binary, so sums of prices drift (0.30000000000000004), and rounding differences across millions of transactions cause accounting mismatches.
- *How:* store money as an integer count of the smallest unit: paise for rupees (₹10.50 = 1050), cents for dollars. Use `int64`. Add and subtract exactly. Format only at the edge: `fmt.Printf("₹%d.%02d\n", p/100, p%100)` (for non-negative amounts).
- *When you need more:* interest rates, currency conversion, or tax with many decimal places need a decimal type (for example the `shopspring/decimal` library, or `math/big`), with explicit rounding rules.
- *Trade-off:* you must think about rounding explicitly (for example, when splitting ₹100 three ways) instead of hiding it inside float errors. That is a feature: the rounding rule becomes a visible business decision.

**P-9. Guard clauses: handle problems first, keep the happy path un-indented.** *(Strong Go convention)*

- *Problem it solves:* deeply nested if/else ("arrow code") where the main logic sits four levels deep and the error handling is far from the check that caused it.
- *How:* check each bad case at the top and leave immediately (`return`, `os.Exit`, later `continue`), so the normal path continues down the left edge. Your numinfo `main` already does this: wrong argument count → exit; bad number → exit; then the real work.
- *Why Go developers do it:* Go code is read top to bottom as "check, check, check, do the work". With errors as values (Stage 3), `if err != nil { return err }` after each step is the standard shape.
- *Related rule:* if an `if` block ends with `return` (or exit), do not write `else`: just continue after the block. Linters flag the unnecessary `else`.
- *When not to:* when both branches are equally normal (for example, choosing a label for even vs odd), a plain if/else is clearer.

**P-10. `(result, error)` with the error last.** *(Universal Go convention)*

- *Problem it solves:* a function that can fail needs to report failure clearly, without exceptions hidden in the flow.
- *How:* return the normal result(s) first and an `error` last. The caller checks `if err != nil` immediately (P-9 guard clause) and uses the result only when `err` is nil. On error, the other results are usually zero values and should not be used.
- *Why Go developers do it:* the whole standard library follows it (`strconv.Atoi`, `os.Open`, `io.Reader.Read`), so every Go reader instantly understands the shape.
- *When not to:* when failure is truly impossible, do not add an error result "just in case". For a simple yes/no lookup, Go often uses `(value, ok bool)` instead (the comma-ok idiom, Stage 2 maps).
- Full error handling (wrapping, `errors.Is`) comes in Stage 3.

**P-11. Keep scopes small, but watch your `:=`.** *(Go convention)*

- *Problem it solves:* variables that live longer than needed get reused by mistake; short-lived values clutter the function.
- *How:* declare variables as close as possible to where they are used; use if / switch short statements (`if v, err := f(); err != nil {...}`) so helper variables disappear after the check.
- *The catch:* in an inner block, `:=` creates a NEW variable. When you mean to update an outer variable, use `=`.
- *Naming:* never name variables after built-ins (`len`, `max`, `new`, `copy`, `error`) or after imported packages. Use `n`, `maxVal`, `u` (for a URL), and so on.
- *When not to:* do not squeeze long logic into an if short statement just to limit scope; readability comes first.

**P-12. Closures for small, local behaviour; structs for real state.** *(Go practice)*

- *Problem it solves:* passing a little custom behaviour (a comparison, a callback, a counter) without creating a whole new type.
- *How:* write a function literal right where it is needed, capturing only what it needs.
- *When NOT to:* when the hidden state grows (several variables, several operations, needs testing or inspection), use a struct with methods (Stage 3). Hidden state inside closures is hard to see, debug, and test.
- *Trade-off:* closures are short and local, but their captured state is invisible from outside; and captured variables may cost a heap allocation (DT-86).

**P-13. Acquire, check, then defer the cleanup.** *(Universal Go idiom)*

```go
f, err := os.Open(path)
if err != nil {
	return err      // nothing was opened, so nothing to close
}
defer f.Close()     // right after success: impossible to forget later
```

- *Problem it solves:* forgetting to release resources (files, locks, connections) on one of many return paths, including panics.
- *Why Go developers do it:* the cleanup sits right next to the acquisition, so a reader sees both together, and every exit path is covered automatically.
- *Order matters:* check the error FIRST. Deferring `f.Close()` before the check could call Close on a nil or invalid value.
- *Caveat:* for files you WRITE, the error from `Close` can mean data was not saved; ignoring it with a plain `defer f.Close()` can hide data loss. Stage 5 shows how to handle it.
- *When not to:* inside a long loop (see defer in loops), and in extremely hot code paths after measuring.

**P-14. Keep `main` tiny: `func run() error` + one `os.Exit`.** *(Common Go pattern for programs)*

```go
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

func run() error {
	defer fmt.Println("cleanup") // runs when run() returns, BEFORE os.Exit
	// ... all the real work, returning errors instead of exiting
	return nil
}
```

- *Problem it solves:* `os.Exit` skips deferred calls (Rule 5), so cleanup in `main` is lost on error exits.
- *How it works:* all work and all defers live in `run()`. `run()` returns normally (so its defers run), and only then does `main` call `os.Exit`.
- *Extra benefit:* `run()` can be called from tests (Stage 4), while `os.Exit` cannot be tested easily. Arguments and I/O can be passed in as parameters later to make it fully testable.
- *When not to:* tiny throwaway scripts.

**P-15. Secrets come from crypto/rand, always.** *(Security practice)*

- *Problem it solves:* `math/rand` output can be predicted by someone who sees enough of it or can guess the seed. Predictable OTPs, session IDs, or reset links let attackers take over accounts.
- *How:* anything that grants access or must stay secret: `crypto/rand`. Everything else (games, simulations, jitter, sampling): `math/rand/v2`.
- *Trade-off:* `crypto/rand` is slower, which almost never matters for secrets because you generate few of them.

**P-16. Arrays for fixed-size values, slices for lists.** *(Go convention)*

- *Use arrays when:* the size is part of the meaning and never changes (a 32-byte hash, a 4-byte IPv4 address, RGB colour `[3]uint8`, a 3×3 board), you want value semantics (a copy is a separate thing), or you need a comparable map key.
- *Use slices when:* the number of elements can change or is known only at run time (almost every "list" in Go code).
- *Trade-off:* arrays are copied completely on assignment and function calls; that is cheap for small arrays and expensive for big ones.

## Glossary (simple meanings)

| Word | Simple meaning |
| --- | --- |
| Address | The number of one byte-sized box in memory |
| Binary | Base-2 number system; only digits 0 and 1 |
| Binary / executable | A file containing machine code that the computer can run directly |
| Bit | One 0-or-1 value; the smallest unit of data |
| Byte | 8 bits; can hold 256 different values (0 to 255) |
| Compile error | ANY reason the compiler refuses to build; no program is produced |
| Compile time | The moment the compiler checks and translates code, before running |
| Compiler | A program that translates your whole source code into machine code before it runs |
| CPU | The chip that executes instructions, one tiny step at a time, very fast |
| ELF / PE / Mach-O | Executable file formats: ELF for Linux, PE (.exe) for Windows, Mach-O for macOS |
| Endianness | The order in which the bytes of a multi-byte number are stored |
| Exit code | A number a finished process gives to the OS; 0 = success |
| GOARCH | Go setting that picks the target CPU type, e.g. amd64, arm64 |
| GOOS | Go setting that picks the target operating system, e.g. linux, windows, darwin |
| Hexadecimal (hex) | Base-16 system, digits 0-9 and A-F; one hex digit = 4 bits |
| IEEE 754 | The worldwide standard for how float numbers are stored and calculated |
| Inf | Special float value meaning infinity (+Inf or -Inf) |
| Interpreter | A program that reads and runs source code directly, step by step, while running |
| Literal | A value written directly in code, like `42`, `0xFF`, or `"hi"` |
| Machine code | Instructions in the CPU's own language (just bytes) |
| NaN | "Not a Number": special float value for undefined results like 0.0/0.0 |
| Octal | Base-8 system; Go literals start with `0o` (or an old-style leading `0`) |
| Panic | Go's name for a serious run-time error that stops the program unless handled |
| Process | A program that is currently running, with its own memory given by the OS |
| RAM | The computer's main working memory; fast, and cleared when power goes off |
| Run time | The period when the program is actually executing |
| Source code | The human-readable text you write, e.g. main.go |
| Stack trace | The list of function calls printed when a panic happens, showing where it failed |
| Syntax error | Grammar of the code is broken (missing bracket, brace, etc.); one kind of compile error |
| System call | A request from a program to the OS, e.g. "write this text to the screen" |
| Type error | Code has correct grammar but mixes types wrongly, e.g. string + int |
