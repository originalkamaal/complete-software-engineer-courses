"""Turn the original learning notes (Chapters 0, 1 and Unit 2.1) into book chapters.

Each unit gets, in order: its lesson text, the Deep & Tricky entries from that
unit, the patterns introduced in that unit, misconceptions, and a mastery check.
"""
import re
from pathlib import Path

ROOT = Path(__file__).parent
src = (ROOT / "source.md").read_text().split("\n")
adds_text = (ROOT / "parts/ch0_1_additions.md").read_text()

# ---------- additions ----------
adds = {}
for block in re.split(r"^@@", adds_text, flags=re.M)[1:]:
    key, _, body = block.partition("\n")
    adds[key.strip()] = body.strip("\n")


def lines_between(start_pat, end_pat):
    s = next(i for i, l in enumerate(src) if re.match(start_pat, l))
    e = next(i for i in range(s + 1, len(src)) if re.match(end_pat, src[i]))
    return src[s:e]


# ---------- units ----------
body = lines_between(r"^## Stage 0 ", r"^## Mistakes & Misconceptions Log")
units = {}
order = []
cur = None
for l in body:
    m = re.match(r"^### Unit (\d+\.\d+) — (.*)", l)
    if m:
        cur = m.group(1)
        order.append(cur)
        units[cur] = {"title": m.group(2), "lines": []}
        continue
    if re.match(r"^### Stage \d Project|^## ", l):
        cur = None
        continue
    if cur:
        units[cur]["lines"].append(l)

# ---------- Deep & Tricky ----------
dt_lines = lines_between(r"^## Deep & Tricky Go Knowledge", r"^## Go Patterns")
dts = {}
cur = None
for l in dt_lines:
    m = re.match(r"^### From Unit (\d+\.\d+)", l)
    if m:
        cur = m.group(1)
        dts[cur] = []
        continue
    if cur:
        dts[cur].append(l)

# ---------- Patterns ----------
p_lines = lines_between(r"^## Go Patterns", r"^## Glossary")
patterns = {}
cur = None
for l in p_lines:
    m = re.match(r"^\*\*P-(\d+)\.", l)
    if m:
        cur = int(m.group(1))
        patterns[cur] = []
    if cur is not None:
        patterns[cur].append(l)

P_UNIT = {0: "0.1", 1: "0.3", 2: "0.3", 3: "P0", 4: "P0", 5: "P0", 6: "1.2", 7: "1.4",
          8: "1.5", 9: "1.6", 10: "1.8", 11: "1.9", 12: "1.10", 13: "1.11", 14: "1.12",
          15: "1.13", 16: "2.1"}

SUBHEAD_RENAMES = {
    r"^#### Correction 1 — ": "#### Going deeper 1 — ",
    r"^#### Correction 2 — ": "#### Going deeper 2 — ",
    r"^#### Correction 3 — ": "#### Going deeper 3 — ",
    r"^#### Correction 4 — Read the WHOLE compiler message \(from retest 2\)": "#### Going deeper 4 — Read the WHOLE compiler message",
    r"^#### Unit 0\.6 — Detailed explanation \(added after your questions\)": "#### A closer look at the stack and the heap",
    r"^#### Unit 1\.5 — Simple re-explanation \(added on request\)": "#### Seven simple ideas that make floats click",
    r"^#### Unit 1\.8 / 1\.9 fix-up explanations": "#### Worked examples",
    r"^#### Closure fix: where to take the \"photo\"": "#### Where to take the \"photo\"",
}

TEXT_REPLACEMENTS = [
    ("(your method in B1)", ""),
    ("(your binaries in F3) ", "(the permissions of a typical program binary) "),
    ("| 64 on your Mac |", "| 64 on all common 64-bit machines |"),
    ("| 64 bits on your Mac |", "| 64 bits on all common 64-bit machines |"),
    ("arm64 (your Mac) has", "arm64 (Apple Silicon, many cloud servers) has"),
    ("**\"Data dies when the function returns\" — but `square` returns 9 to its caller. How?** (your question)",
     "**\"Data dies when the function returns\" — but `square` returns 9 to its caller. How?**"),
    ("(in current Go on your Mac, a CPU register — see DT-38)", "(in current Go on amd64 and arm64, a CPU register — see DT-38)"),
    ("Go 1.22 and later (your go.mod)", "Go 1.22 and later (any module whose go.mod says `go 1.22` or newer)"),
    ("**Rule 3 — simple re-explanation (added on request).**", "**Rule 3 — the courier counter.**"),
    ("seen in your own output", "visible in any stack trace"),
    ("seen in your own answer", "a common surprise"),
    ("(128 bytes on your Mac)", "(128 bytes on Apple Silicon)"),
    ("On your Mac (arm64) and on normal servers", "On amd64 and arm64 machines (laptops and normal servers)"),
    ("the `LSB` in your `file` output", "the `LSB` in `file` output"),
    ("check your own machine", "check your machine"),
    ("your `go 1.27.1` means the new behaviour", "a module saying `go 1.27` gets the new behaviour"),
    ("You saw the evidence: ", "Look for the evidence in a trace: "),
    ("as used on your Mac and normal Linux servers", "as used in Macs, PCs, and normal Linux servers"),
    ("Your `file` output said `statically linked`", "Run `file` on a Go binary built on Linux and it typically says `statically linked`"),
    ("**DT-12. Your binary carries", "**DT-12. A Go binary carries"),
    ('fmt.Printf("%3d|%03d\\n", 7, 7)` prints `   7|007 ` (two spaces before 7)', 'fmt.Printf("%3d|%03d\\n", 7, 7)` prints `  7|007` (two spaces before 7)'),
]

LINE_DROPS = [
    r"^\*Understood after re-explanation:\*",
]


DT9_NEW = ('`go help run` says it directly: "The exit status of Run is not the exit status of the compiled binary." '
 'Try it with a program that panics: `go run . ; echo $?` gives 1, while `go build && ./prog ; echo $?` gives 2. '
 'Notice also that the line `exit status 2` is printed by `go run`, not by your program; running the binary directly never shows it. '
 'Why: `go run` is itself a process (the go tool). It builds your program, starts it as a separate child process, waits, '
 'and prints the child\'s status as text (`exit status 2`). Then it exits with its OWN code, 1, meaning "the thing I ran failed".')


def clean(text: str) -> str:
    if "Confirmed from \\`go help run\\` by you:" in text:
        a = text.index("Confirmed from \\`go help run\\` by you:")
        end_marker = 'meaning "the thing I ran failed".'
        b = text.index(end_marker, a) + len(end_marker)
        text = text[:a] + DT9_NEW + text[b:]
    for a, b in TEXT_REPLACEMENTS:
        text = text.replace(a, b)
    text = re.sub(r"\bStage (\d+)\b", r"Chapter \1", text)
    text = re.sub(r"\bStages (\d+) and (\d+)\b", r"Chapters \1 and \2", text)
    return text


def shift(text: str, n: int = 1) -> str:
    """Remove n leading '#' from markdown headings (outside code fences)."""
    out, fence = [], False
    for l in text.split("\n"):
        if l.startswith("```"):
            fence = not fence
        if not fence and re.match(r"^#{2,6} ", l):
            l = l[n:]
        out.append(l)
    return "\n".join(out)


def unit_md(u: str) -> str:
    info = units[u]
    lines = []
    for l in info["lines"]:
        for pat, rep in SUBHEAD_RENAMES.items():
            l = re.sub(pat, rep, l)
        if any(re.match(p, l) for p in LINE_DROPS):
            continue
        lines.append(l)
    parts = [f"### Unit {u} — {info['title']}", "\n".join(lines).strip()]
    if dts.get(u):
        parts.append("#### Deep & Tricky\n\n" + "\n".join(dts[u]).strip())
    ps = [p for p, uu in P_UNIT.items() if uu == u]
    if ps:
        head = "#### Pattern" if len(ps) == 1 else "#### Patterns"
        parts.append(head + "\n\n" + "\n\n".join("\n".join(patterns[p]).strip() for p in ps))
    if u in adds:
        parts.append(adds[u])
    return shift(clean("\n\n".join(parts)))


def chapter(num: int, title: str, unit_ids, topics) -> str:
    out = [f"# Chapter {num} — {title}", shift(clean(adds[f"INTRO {num}"]))]
    for u in unit_ids:
        if u in topics:
            out.append(f"## {topics[u]}")
        out.append(unit_md(u))
    # project
    proj = adds[f"PROJECT {num}"]
    if num == 0:
        ps = [p for p, uu in P_UNIT.items() if uu == "P0"]
        proj += "\n\n#### Patterns introduced by this project\n\n" + "\n\n".join(
            "\n".join(patterns[p]).strip() for p in ps)
    out.append(shift(clean(proj)))
    out.append(shift(clean(adds[f"ANSWERS {num}"])))
    return "\n\n".join(out) + "\n"


TOPICS0 = {"0.1": "Topic 0A — From source code to a running process",
           "0.2": "Topic 0B — How numbers are stored",
           "0.5": "Topic 0C — The machine and its memory"}
TOPICS1 = {"1.1": "Topic 1A — Values and types",
           "1.3": "Topic 1B — Operators and numbers",
           "1.6": "Topic 1C — Control flow",
           "1.8": "Topic 1D — Functions and their behaviour",
           "1.12": "Topic 1E — Talking to the outside world"}

ch0 = chapter(0, "Computing Foundations & Toolchain", [u for u in order if u.startswith("0.")], TOPICS0)
ch1 = chapter(1, "Core Language Fundamentals", [u for u in order if u.startswith("1.")], TOPICS1)
(ROOT / "src/ch00.md").write_text(ch0)
(ROOT / "src/ch01.md").write_text(ch1)
(ROOT / "parts/unit2_1.md").write_text(unit_md("2.1") + "\n")

# Glossary seed for the appendix
gl = lines_between(r"^## Glossary", r"^THIS_NEVER_MATCHES$") if False else None
start = next(i for i, l in enumerate(src) if l.startswith("## Glossary"))
(ROOT / "parts/glossary_seed.md").write_text("\n".join(src[start + 2:]).strip() + "\n")
print("ok", len(ch0), len(ch1))
