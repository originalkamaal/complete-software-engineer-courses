// Command crawl prints the pages of a web site reachable from a start URL.
//
//	crawl [-depth 2] [-workers 4] [-rps 5] [-timeout 30s] URL
package main

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"time"

	"example.com/crawler/crawl"
)

func main() {
	depth := flag.Int("depth", 2, "maximum link depth")
	workers := flag.Int("workers", 4, "maximum parallel requests")
	rps := flag.Float64("rps", 5, "maximum requests per second (0 = unlimited)")
	timeout := flag.Duration("timeout", 30*time.Second, "overall time limit")
	flag.Parse()
	if flag.NArg() != 1 {
		fmt.Fprintln(os.Stderr, "usage: crawl [flags] URL")
		os.Exit(2)
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	ctx, cancel := context.WithTimeout(ctx, *timeout)
	defer cancel()

	var interval time.Duration
	if *rps > 0 {
		interval = time.Duration(float64(time.Second) / *rps)
	}
	f := crawl.HTTPFetcher{
		Client:   &http.Client{Timeout: 10 * time.Second},
		MaxBytes: 2 << 20,
	}
	var mu sync.Mutex // report is called concurrently
	n := 0
	err := crawl.Crawl(ctx, f, flag.Arg(0), crawl.Options{Workers: *workers, MaxDepth: *depth, Interval: interval},
		func(r crawl.Result) {
			mu.Lock()
			defer mu.Unlock()
			n++
			if r.Err != nil {
				fmt.Printf("%d\t%s\tERROR %v\n", r.Depth, r.URL, r.Err)
				return
			}
			fmt.Printf("%d\t%s\t%d links\n", r.Depth, r.URL, r.Links)
		})
	fmt.Fprintf(os.Stderr, "%d pages\n", n)
	if err != nil {
		fmt.Fprintln(os.Stderr, "crawl stopped:", err)
		os.Exit(1)
	}
}
