package crawl

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// A small site with a cycle, a broken link, and an external link.
var site = map[string]string{
	"/":         `<a href="/a">a</a> <a href="/b">b</a> <a href="https://other.example/x">ext</a>`,
	"/a":        `<a href="/">home</a> <a href="/a/deep">deep</a>`,
	"/b":        `<a href="/missing">broken</a> <a href="/a">a</a>`,
	"/a/deep":   `<a href="/a/deeper">deeper</a>`,
	"/a/deeper": `the end`,
}

func newSite(t *testing.T, delay time.Duration, inFlight, maxInFlight *atomic.Int64) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n := inFlight.Add(1)
		defer inFlight.Add(-1)
		for {
			m := maxInFlight.Load()
			if n <= m || maxInFlight.CompareAndSwap(m, n) {
				break
			}
		}
		select {
		case <-time.After(delay):
		case <-r.Context().Done():
			return
		}
		body, ok := site[r.URL.Path]
		if !ok {
			http.NotFound(w, r)
			return
		}
		fmt.Fprint(w, body)
	}))
	t.Cleanup(srv.Close)
	return srv
}

func collect() (func(Result), func() []Result) {
	var mu sync.Mutex
	var rs []Result
	return func(r Result) {
			mu.Lock()
			rs = append(rs, r)
			mu.Unlock()
		}, func() []Result {
			mu.Lock()
			defer mu.Unlock()
			slices.SortFunc(rs, func(a, b Result) int {
				if a.URL < b.URL {
					return -1
				}
				if a.URL > b.URL {
					return 1
				}
				return 0
			})
			return rs
		}
}

func TestCrawlVisitsEachPageOnce(t *testing.T) {
	var inFlight, maxInFlight atomic.Int64
	srv := newSite(t, 20*time.Millisecond, &inFlight, &maxInFlight)
	report, results := collect()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	err := Crawl(context.Background(), f, srv.URL+"/", Options{Workers: 2, MaxDepth: 5}, report)
	if err != nil {
		t.Fatal(err)
	}
	rs := results()
	var got []string
	errCount := 0
	for _, r := range rs {
		got = append(got, r.URL[len(srv.URL):])
		if r.Err != nil {
			errCount++
			if !errors.Is(r.Err, ErrStatus) {
				t.Errorf("%s: unexpected error %v", r.URL, r.Err)
			}
		}
	}
	want := []string{"/", "/a", "/a/deep", "/a/deeper", "/b", "/missing"}
	if !slices.Equal(got, want) {
		t.Errorf("visited %v, want %v", got, want)
	}
	if errCount != 1 {
		t.Errorf("%d errors, want 1 (the 404)", errCount)
	}
	if m := maxInFlight.Load(); m > 2 {
		t.Errorf("%d requests in flight, limit was 2", m)
	}
}

func TestCrawlDepthLimit(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 0, &a, &b)
	report, results := collect()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	if err := Crawl(context.Background(), f, srv.URL+"/", Options{MaxDepth: 1}, report); err != nil {
		t.Fatal(err)
	}
	for _, r := range results() {
		if r.Depth > 1 {
			t.Errorf("%s visited at depth %d", r.URL, r.Depth)
		}
	}
	if n := len(results()); n != 3 { // /, /a, /b
		t.Errorf("visited %d pages, want 3", n)
	}
}

func TestCrawlCancel(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 2*time.Second, &a, &b) // every page is very slow
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	start := time.Now()
	err := Crawl(ctx, f, srv.URL+"/", Options{MaxDepth: 5}, func(Result) {})
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("err = %v, want DeadlineExceeded", err)
	}
	if d := time.Since(start); d > time.Second {
		t.Errorf("Crawl took %v after cancellation", d)
	}
}

func TestRateLimit(t *testing.T) {
	var a, b atomic.Int64
	srv := newSite(t, 0, &a, &b)
	f := HTTPFetcher{Client: srv.Client(), MaxBytes: 1 << 20}
	start := time.Now()
	err := Crawl(context.Background(), f, srv.URL+"/", Options{Workers: 8, MaxDepth: 5, Interval: 50 * time.Millisecond}, func(Result) {})
	if err != nil {
		t.Fatal(err)
	}
	// 6 requests, at most one every 50ms: the first waits one tick too.
	if d := time.Since(start); d < 250*time.Millisecond {
		t.Errorf("6 requests finished in %v; rate limit not applied", d)
	}
}
