// Package crawl visits the pages of one web site concurrently, with a
// bound on parallel requests, a request-rate limit, a depth limit, and
// cancellation through a context.
package crawl

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"sync"
	"time"
)

// Fetcher downloads a page. It is an interface so tests can use a fake.
type Fetcher interface {
	Fetch(ctx context.Context, url string) (body string, err error)
}

// Result describes one visited page.
type Result struct {
	URL   string
	Depth int
	Links int
	Err   error
}

type Options struct {
	Workers  int           // maximum requests in flight (default 4)
	MaxDepth int           // 0 = only the start page
	Interval time.Duration // minimum time between request starts (0 = no limit)
}

// Crawl visits start and pages linked from it on the same host, up to
// MaxDepth links away. It calls report for every page from several
// goroutines at once, so report must be safe for concurrent use.
// It returns when every reachable page was visited or ctx is done.
func Crawl(ctx context.Context, f Fetcher, start string, opt Options, report func(Result)) error {
	base, err := url.Parse(start)
	if err != nil {
		return fmt.Errorf("start URL: %w", err)
	}
	if opt.Workers < 1 {
		opt.Workers = 4
	}

	var (
		mu   sync.Mutex
		seen = map[string]bool{start: true}
		wg   sync.WaitGroup
		sem  = make(chan struct{}, opt.Workers) // counting semaphore
	)
	var tick <-chan time.Time
	if opt.Interval > 0 {
		t := time.NewTicker(opt.Interval)
		defer t.Stop()
		tick = t.C
	}

	var visit func(u string, depth int)
	visit = func(u string, depth int) {
		defer wg.Done()

		// Wait for a rate-limit slot and a worker slot, or give up on cancel.
		if tick != nil {
			select {
			case <-tick:
			case <-ctx.Done():
				return
			}
		}
		select {
		case sem <- struct{}{}:
		case <-ctx.Done():
			return
		}
		body, err := f.Fetch(ctx, u)
		<-sem // release the worker slot before spawning children

		if err != nil {
			report(Result{URL: u, Depth: depth, Err: err})
			return
		}
		links := sameHostLinks(base, u, body)
		report(Result{URL: u, Depth: depth, Links: len(links)})
		if depth == opt.MaxDepth {
			return
		}
		for _, l := range links {
			mu.Lock()
			isNew := !seen[l]
			seen[l] = true
			mu.Unlock()
			if isNew {
				wg.Add(1)
				go visit(l, depth+1)
			}
		}
	}

	wg.Add(1)
	go visit(start, 0)
	wg.Wait()
	return ctx.Err()
}

// hrefRE is a deliberately simple link finder. A real crawler should use
// an HTML parser (golang.org/x/net/html); regular expressions cannot
// parse HTML in general.
var hrefRE = regexp.MustCompile(`href="([^"#]+)`)

func sameHostLinks(base *url.URL, page, body string) []string {
	pu, err := url.Parse(page)
	if err != nil {
		return nil
	}
	var out []string
	for _, m := range hrefRE.FindAllStringSubmatch(body, -1) {
		ref, err := url.Parse(m[1])
		if err != nil {
			continue
		}
		abs := pu.ResolveReference(ref)
		if abs.Host == base.Host && (abs.Scheme == "http" || abs.Scheme == "https") {
			abs.Fragment = ""
			out = append(out, abs.String())
		}
	}
	return out
}

// HTTPFetcher fetches pages over HTTP with a size limit.
type HTTPFetcher struct {
	Client   *http.Client
	MaxBytes int64
}

var ErrStatus = errors.New("unexpected HTTP status")

func (h HTTPFetcher) Fetch(ctx context.Context, u string) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return "", err
	}
	resp, err := h.Client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("%w: %s", ErrStatus, resp.Status)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, h.MaxBytes))
	return string(b), err
}
