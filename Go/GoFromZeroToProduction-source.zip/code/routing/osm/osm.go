// Package osm reads the parts of OpenStreetMap XML needed for car routing:
// nodes (points) and ways (polylines of node IDs) tagged as roads.
package osm

import (
	"encoding/xml"
	"fmt"
	"io"
	"strconv"
	"strings"
)

type Node struct {
	ID       int64
	Lat, Lon float64
}

type Way struct {
	ID       int64
	Nodes    []int64
	Highway  string // "primary", "residential", ...
	OneWay   int    // 0 both directions, 1 forward only, -1 backward only
	MaxSpeed int    // km/h, 0 if unknown
	Name     string
}

// Data is the subset of a map extract used for routing.
type Data struct {
	Nodes map[int64]Node
	Ways  []Way
}

// carRoads are the highway values cars may drive on.
var carRoads = map[string]bool{
	"motorway": true, "trunk": true, "primary": true, "secondary": true, "tertiary": true,
	"unclassified": true, "residential": true, "service": true, "living_street": true,
	"motorway_link": true, "trunk_link": true, "primary_link": true, "secondary_link": true, "tertiary_link": true,
}

// Read streams OSM XML with an xml.Decoder token by token, so memory holds
// only the extracted data, not the whole document tree.
func Read(r io.Reader) (*Data, error) {
	d := &Data{Nodes: map[int64]Node{}}
	dec := xml.NewDecoder(r)
	var cur *Way
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "node":
				n, err := parseNode(t.Attr)
				if err != nil {
					return nil, err
				}
				d.Nodes[n.ID] = n
			case "way":
				id, err := strconv.ParseInt(attr(t.Attr, "id"), 10, 64)
				if err != nil {
					return nil, fmt.Errorf("way id: %w", err)
				}
				cur = &Way{ID: id}
			case "nd":
				if cur != nil {
					ref, err := strconv.ParseInt(attr(t.Attr, "ref"), 10, 64)
					if err != nil {
						return nil, fmt.Errorf("way %d: nd ref: %w", cur.ID, err)
					}
					cur.Nodes = append(cur.Nodes, ref)
				}
			case "tag":
				if cur != nil {
					applyTag(cur, attr(t.Attr, "k"), attr(t.Attr, "v"))
				}
			}
		case xml.EndElement:
			if t.Name.Local == "way" && cur != nil {
				if carRoads[cur.Highway] && len(cur.Nodes) >= 2 {
					d.Ways = append(d.Ways, *cur)
				}
				cur = nil
			}
		}
	}
	return d, nil
}

func applyTag(w *Way, k, v string) {
	switch k {
	case "highway":
		w.Highway = v
	case "name":
		w.Name = v
	case "oneway":
		switch v {
		case "yes", "true", "1":
			w.OneWay = 1
		case "-1", "reverse":
			w.OneWay = -1
		}
	case "maxspeed":
		// "50", "50 km/h", or "30 mph"
		f := strings.Fields(v)
		if len(f) > 0 {
			if n, err := strconv.Atoi(f[0]); err == nil {
				if len(f) > 1 && f[1] == "mph" {
					n = n * 1609 / 1000
				}
				w.MaxSpeed = n
			}
		}
	}
	if w.Highway == "motorway" && w.OneWay == 0 {
		w.OneWay = 1 // motorways are one-way by convention unless tagged otherwise
	}
}

func parseNode(attrs []xml.Attr) (Node, error) {
	var n Node
	var err error
	if n.ID, err = strconv.ParseInt(attr(attrs, "id"), 10, 64); err != nil {
		return n, fmt.Errorf("node id: %w", err)
	}
	if n.Lat, err = strconv.ParseFloat(attr(attrs, "lat"), 64); err != nil {
		return n, fmt.Errorf("node %d lat: %w", n.ID, err)
	}
	if n.Lon, err = strconv.ParseFloat(attr(attrs, "lon"), 64); err != nil {
		return n, fmt.Errorf("node %d lon: %w", n.ID, err)
	}
	return n, nil
}

func attr(attrs []xml.Attr, name string) string {
	for _, a := range attrs {
		if a.Name.Local == name {
			return a.Value
		}
	}
	return ""
}
