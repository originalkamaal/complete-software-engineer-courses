package graph

import (
	"math"

	"example.com/routing/geo"
)

// Index finds the nearest graph node to a point using a uniform grid of
// cells (a simple spatial index; quadtrees and R-trees generalise it).
type Index struct {
	g                       *Graph
	minLat, minLon, cellDeg float64
	rows, cols              int
	cellStart               []int32 // CSR again: nodes of cell c are nodes[cellStart[c]:cellStart[c+1]]
	nodes                   []int32
}

func NewIndex(g *Graph, cellDeg float64) *Index {
	ix := &Index{g: g, cellDeg: cellDeg, minLat: math.Inf(1), minLon: math.Inf(1)}
	maxLat, maxLon := math.Inf(-1), math.Inf(-1)
	for v := range g.NumNodes() {
		ix.minLat, ix.minLon = min(ix.minLat, g.Lat[v]), min(ix.minLon, g.Lon[v])
		maxLat, maxLon = max(maxLat, g.Lat[v]), max(maxLon, g.Lon[v])
	}
	ix.rows = int((maxLat-ix.minLat)/cellDeg) + 1
	ix.cols = int((maxLon-ix.minLon)/cellDeg) + 1
	ix.cellStart = make([]int32, ix.rows*ix.cols+1)
	cellOf := make([]int32, g.NumNodes())
	for v := range g.NumNodes() {
		c := int32(ix.cell(g.Lat[v], g.Lon[v]))
		cellOf[v] = c
		ix.cellStart[c+1]++
	}
	for c := range ix.rows * ix.cols {
		ix.cellStart[c+1] += ix.cellStart[c]
	}
	ix.nodes = make([]int32, g.NumNodes())
	next := append([]int32(nil), ix.cellStart...)
	for v := range g.NumNodes() {
		ix.nodes[next[cellOf[v]]] = int32(v)
		next[cellOf[v]]++
	}
	return ix
}

func (ix *Index) cell(lat, lon float64) int {
	r := min(max(int((lat-ix.minLat)/ix.cellDeg), 0), ix.rows-1)
	c := min(max(int((lon-ix.minLon)/ix.cellDeg), 0), ix.cols-1)
	return r*ix.cols + c
}

// Nearest returns the closest node and its distance in metres, searching
// rings of cells outwards until no closer node can exist.
func (ix *Index) Nearest(p geo.Point) (int32, float64) {
	r0 := min(max(int((p.Lat-ix.minLat)/ix.cellDeg), 0), ix.rows-1)
	c0 := min(max(int((p.Lon-ix.minLon)/ix.cellDeg), 0), ix.cols-1)
	best, bestD := int32(-1), math.Inf(1)
	cellM := ix.cellDeg * 111_000 * math.Cos(p.Lat*math.Pi/180) // narrowest cell side in metres
	for ring := 0; ring <= max(ix.rows, ix.cols); ring++ {
		if best >= 0 && float64(ring-1)*cellM > bestD {
			break // every unvisited cell is farther than the best found
		}
		for r := r0 - ring; r <= r0+ring; r++ {
			for c := c0 - ring; c <= c0+ring; c++ {
				if r < 0 || c < 0 || r >= ix.rows || c >= ix.cols {
					continue
				}
				if max(abs(r-r0), abs(c-c0)) != ring {
					continue // only the ring's border
				}
				cell := r*ix.cols + c
				for _, v := range ix.nodes[ix.cellStart[cell]:ix.cellStart[cell+1]] {
					if d := geo.Equirectangular(p, ix.g.Point(v)); d < bestD {
						best, bestD = v, d
					}
				}
			}
		}
	}
	return best, bestD
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
