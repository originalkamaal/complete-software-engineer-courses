// Package graph stores a road network in compressed sparse row (CSR) form:
// flat slices of numbers, no pointers, cache-friendly, and nearly free for
// the garbage collector (DT-269).
package graph

import (
	"fmt"
	"math"
	"slices"

	"example.com/routing/geo"
	"example.com/routing/osm"
)

// Graph: the outgoing edges of node v are To[First[v]:First[v+1]], with
// travel times in milliseconds in Cost at the same positions.
type Graph struct {
	Lat, Lon []float64 // per node
	First    []int32   // len = nodes+1
	To       []int32   // per edge
	Cost     []uint32  // per edge, milliseconds
	MaxSpeed float64   // fastest speed in the graph, m/s (for A*)
	OSMID    []int64   // per node, for debugging
}

func (g *Graph) NumNodes() int { return len(g.Lat) }
func (g *Graph) NumEdges() int { return len(g.To) }

func (g *Graph) Point(v int32) geo.Point { return geo.Point{Lat: g.Lat[v], Lon: g.Lon[v]} }

var defaultSpeed = map[string]int{ // km/h when maxspeed is missing
	"motorway": 100, "trunk": 80, "primary": 60, "secondary": 50, "tertiary": 40,
	"residential": 30, "unclassified": 30, "service": 15, "living_street": 10,
}

type edge struct {
	from, to int32
	cost     uint32
}

// Build turns OSM ways into a directed graph. Only nodes used by roads are
// kept, renumbered 0..n-1 (slices instead of maps from here on, Unit 6.13).
func Build(d *osm.Data) (*Graph, error) {
	idx := map[int64]int32{}
	g := &Graph{}
	node := func(id int64) (int32, error) {
		if i, ok := idx[id]; ok {
			return i, nil
		}
		n, ok := d.Nodes[id]
		if !ok {
			return 0, fmt.Errorf("way refers to missing node %d", id)
		}
		i := int32(len(g.Lat))
		idx[id] = i
		g.Lat = append(g.Lat, n.Lat)
		g.Lon = append(g.Lon, n.Lon)
		g.OSMID = append(g.OSMID, id)
		return i, nil
	}
	var edges []edge
	for _, w := range d.Ways {
		kmh := w.MaxSpeed
		if kmh == 0 {
			kmh = defaultSpeed[w.Highway]
		}
		if kmh == 0 {
			kmh = 30
		}
		mps := float64(kmh) / 3.6
		g.MaxSpeed = max(g.MaxSpeed, mps)
		for i := 0; i+1 < len(w.Nodes); i++ {
			a, err := node(w.Nodes[i])
			if err != nil {
				return nil, err
			}
			b, err := node(w.Nodes[i+1])
			if err != nil {
				return nil, err
			}
			ms := uint32(math.Ceil(geo.Haversine(g.Point(a), g.Point(b)) / mps * 1000))
			if w.OneWay >= 0 {
				edges = append(edges, edge{a, b, ms})
			}
			if w.OneWay <= 0 {
				edges = append(edges, edge{b, a, ms})
			}
		}
	}
	slices.SortFunc(edges, func(x, y edge) int { return int(x.from) - int(y.from) })
	n := len(g.Lat)
	g.First = make([]int32, n+1)
	g.To = make([]int32, len(edges))
	g.Cost = make([]uint32, len(edges))
	for i, e := range edges {
		g.First[e.from+1]++
		g.To[i], g.Cost[i] = e.to, e.cost
	}
	for v := range n {
		g.First[v+1] += g.First[v]
	}
	return g, nil
}

// Reverse returns the graph with every edge flipped (for searching backwards
// from the target, as bidirectional Dijkstra does).
func (g *Graph) Reverse() *Graph {
	n := g.NumNodes()
	r := &Graph{Lat: g.Lat, Lon: g.Lon, OSMID: g.OSMID, MaxSpeed: g.MaxSpeed,
		First: make([]int32, n+1), To: make([]int32, len(g.To)), Cost: make([]uint32, len(g.Cost))}
	for v := range n {
		for e := g.First[v]; e < g.First[v+1]; e++ {
			r.First[g.To[e]+1]++
		}
	}
	for v := range n {
		r.First[v+1] += r.First[v]
	}
	next := slices.Clone(r.First[:n])
	for v := range n {
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			r.To[next[w]], r.Cost[next[w]] = int32(v), g.Cost[e]
			next[w]++
		}
	}
	return r
}
