// Package server answers routing queries over HTTP and can swap in a new
// road graph without downtime.
package server

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"example.com/routing/geo"
	"example.com/routing/graph"
	"example.com/routing/osm"
	"example.com/routing/route"
)

// Engine is an immutable, fully built routing dataset.
type Engine struct {
	G, Rev  *graph.Graph
	Index   *graph.Index
	Loaded  time.Time
	Source  string
	routers sync.Pool // *route.Router: not concurrency-safe, so one per request
}

// Load builds an Engine from an OSM XML file.
func Load(path string) (*Engine, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	d, err := osm.Read(bufio.NewReaderSize(f, 1<<20))
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	g, err := graph.Build(d)
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	if g.NumNodes() == 0 {
		return nil, fmt.Errorf("%s: no roads", path)
	}
	e := &Engine{G: g, Rev: g.Reverse(), Index: graph.NewIndex(g, 0.002), Loaded: time.Now(), Source: path}
	e.routers.New = func() any { return route.New(e.G, e.Rev) }
	return e, nil
}

type Server struct {
	engine  atomic.Pointer[Engine] // swapped atomically on reload (Unit 7.6)
	log     *slog.Logger
	maxSnap float64 // metres: farther from any road is an error
}

func New(e *Engine, log *slog.Logger) *Server {
	s := &Server{log: log, maxSnap: 500}
	s.engine.Store(e)
	return s
}

// Swap installs a new engine. In-flight requests finish on the old one,
// which the garbage collector frees when they are done.
func (s *Server) Swap(e *Engine) { s.engine.Store(e) }

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /route", s.route)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		e := s.engine.Load()
		fmt.Fprintf(w, "ok nodes=%d edges=%d loaded=%s\n", e.G.NumNodes(), e.G.NumEdges(), e.Loaded.Format(time.RFC3339))
	})
	return mux
}

type routeResponse struct {
	DurationS    float64 `json:"duration_s"`
	DistanceM    float64 `json:"distance_m"`
	Polyline     string  `json:"polyline"`
	SnapFromM    float64 `json:"snap_from_m"`
	SnapToM      float64 `json:"snap_to_m"`
	SettledNodes int     `json:"settled_nodes"`
	Algorithm    string  `json:"algorithm"`
}

func (s *Server) route(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	from, err1 := parsePoint(q.Get("from"))
	to, err2 := parsePoint(q.Get("to"))
	if err := errors.Join(err1, err2); err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	algo := q.Get("algo")
	if algo == "" {
		algo = "astar"
	}
	e := s.engine.Load() // one consistent dataset for the whole request
	src, ds := e.Index.Nearest(from)
	dst, dd := e.Index.Nearest(to)
	if ds > s.maxSnap || dd > s.maxSnap {
		httpError(w, http.StatusUnprocessableEntity, fmt.Sprintf("point is more than %.0f m from any road", s.maxSnap))
		return
	}
	rt := e.routers.Get().(*route.Router)
	defer e.routers.Put(rt)
	var res route.Result
	var err error
	switch algo {
	case "dijkstra":
		res, err = rt.Dijkstra(src, dst)
	case "astar":
		res, err = rt.AStar(src, dst)
	case "bidirectional":
		res, err = rt.Bidirectional(src, dst)
	default:
		httpError(w, http.StatusBadRequest, "algo must be dijkstra, astar, or bidirectional")
		return
	}
	if errors.Is(err, route.ErrNoRoute) {
		httpError(w, http.StatusNotFound, "no route between these points")
		return
	}
	pts := route.Geometry(e.G, res.Nodes)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(routeResponse{
		DurationS: float64(res.DurationMs) / 1000, DistanceM: route.LengthM(e.G, res.Nodes),
		Polyline: geo.EncodePolyline(pts), SnapFromM: ds, SnapToM: dd,
		SettledNodes: res.Settled, Algorithm: algo,
	})
}

func parsePoint(s string) (geo.Point, error) {
	a, b, ok := strings.Cut(s, ",")
	if !ok {
		return geo.Point{}, fmt.Errorf("point %q must be lat,lon", s)
	}
	lat, err1 := strconv.ParseFloat(strings.TrimSpace(a), 64)
	lon, err2 := strconv.ParseFloat(strings.TrimSpace(b), 64)
	if err1 != nil || err2 != nil || lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return geo.Point{}, fmt.Errorf("point %q is not a valid lat,lon", s)
	}
	return geo.Point{Lat: lat, Lon: lon}, nil
}

func httpError(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}
