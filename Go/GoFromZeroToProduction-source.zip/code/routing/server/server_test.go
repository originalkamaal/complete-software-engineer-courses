package server

import (
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"testing"
)

func city(t *testing.T, size string) string {
	t.Helper()
	out, err := exec.Command("go", "run", "../cmd/gencity", "-w", size, "-h", size, "-seed", "3").Output()
	if err != nil {
		t.Fatal(err)
	}
	p := filepath.Join(t.TempDir(), "city.osm")
	os.WriteFile(p, out, 0o644)
	return p
}

func TestRouteAndHotReload(t *testing.T) {
	e, err := Load(city(t, "40"))
	if err != nil {
		t.Fatal(err)
	}
	s := New(e, slog.New(slog.NewTextHandler(io.Discard, nil)))
	srv := httptest.NewServer(s.Handler())
	defer srv.Close()

	get := func(q string) (int, routeResponse) {
		resp, err := http.Get(srv.URL + "/route?" + q)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		var rr routeResponse
		json.NewDecoder(resp.Body).Decode(&rr)
		return resp.StatusCode, rr
	}
	q := "from=18.4520,73.8020&to=18.4800,73.8300"
	code, rr := get(q)
	if code != 200 || rr.DurationS <= 0 || rr.Polyline == "" {
		t.Fatalf("route: %d %+v", code, rr)
	}
	t.Logf("route: %.0f s, %.0f m, %d settled", rr.DurationS, rr.DistanceM, rr.SettledNodes)
	for _, bad := range []string{"from=x&to=1,2", "from=91,0&to=0,0", "from=18.45,73.80&to=18.48,73.83&algo=magic"} {
		if code, _ := get(bad); code != 400 {
			t.Errorf("%s: %d, want 400", bad, code)
		}
	}
	if code, _ := get("from=19.0,72.8&to=18.48,73.83"); code != 422 { // Mumbai: far from this city
		t.Errorf("far point: %d, want 422", code)
	}

	// Hot reload under load: requests keep succeeding while the graph is swapped.
	bigger, err := Load(city(t, "60"))
	if err != nil {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	for range 8 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for range 50 {
				if code, _ := get(q); code != 200 {
					t.Errorf("status %d during reload", code)
					return
				}
			}
		}()
	}
	s.Swap(bigger)
	wg.Wait()
	if s.engine.Load().G.NumNodes() != 3600 {
		t.Errorf("engine not swapped")
	}
}
