// Command stats loads an OSM file and prints graph size and timings.
package main

import (
	"bufio"
	"fmt"
	"os"
	"runtime"
	"time"

	"example.com/routing/graph"
	"example.com/routing/osm"
)

func main() {
	f, err := os.Open(os.Args[1])
	if err != nil {
		panic(err)
	}
	defer f.Close()
	fi, _ := f.Stat()
	t0 := time.Now()
	d, err := osm.Read(bufio.NewReaderSize(f, 1<<20))
	if err != nil {
		panic(err)
	}
	t1 := time.Now()
	ways := len(d.Ways)
	g, err := graph.Build(d)
	if err != nil {
		panic(err)
	}
	t2 := time.Now()
	d = nil
	runtime.GC()
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	csr := 8*2*g.NumNodes() + 4*(g.NumNodes()+1) + 4*g.NumEdges() + 4*g.NumEdges()
	fmt.Printf("file %.1f MB, %d ways\nnodes %d, edges %d\nparse %v, build %v\nCSR arrays (lat, lon, first, to, cost): %.1f MB; live heap after GC: %.1f MB\n",
		float64(fi.Size())/1e6, ways, g.NumNodes(), g.NumEdges(), t1.Sub(t0).Round(time.Millisecond), t2.Sub(t1).Round(time.Millisecond),
		float64(csr)/1e6, float64(m.HeapAlloc)/1e6)
	runtime.KeepAlive(g)
}
