// Command gencity writes a synthetic city as OpenStreetMap XML: a grid of
// streets around a centre point, with arterial roads every 10 blocks,
// one-way residential streets, varied speeds, and some missing segments.
// It exists because real extracts are large downloads; the routing code
// treats the output exactly like a real OSM file.
//
//	gencity -w 300 -h 300 -seed 1 > city.osm
package main

import (
	"bufio"
	"flag"
	"fmt"
	"math"
	"math/rand/v2"
	"os"
)

func main() {
	w := flag.Int("w", 100, "intersections east-west")
	h := flag.Int("h", 100, "intersections north-south")
	seed := flag.Uint64("seed", 1, "random seed")
	flag.Parse()
	r := rand.New(rand.NewPCG(*seed, *seed))
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()

	const lat0, lon0 = 18.45, 73.80 // south-west corner, near Pune
	const spacingM = 100.0
	dLat := spacingM / 111_320
	dLon := spacingM / (111_320 * math.Cos(lat0*math.Pi/180))
	id := func(row, col int) int64 { return int64(row*(*w)+col) + 1 }

	fmt.Fprintln(out, `<?xml version="1.0" encoding="UTF-8"?>`)
	fmt.Fprintln(out, `<osm version="0.6" generator="gencity">`)
	for row := range *h {
		for col := range *w {
			jitter := func() float64 { return (r.Float64() - 0.5) * 0.15 } // streets are never perfectly straight
			fmt.Fprintf(out, ` <node id="%d" lat="%.7f" lon="%.7f"/>`+"\n",
				id(row, col), lat0+(float64(row)+jitter())*dLat, lon0+(float64(col)+jitter())*dLon)
		}
	}
	wayID := int64(1)
	way := func(a, b int64, highway, oneway string, speed int) {
		fmt.Fprintf(out, ` <way id="%d"><nd ref="%d"/><nd ref="%d"/><tag k="highway" v="%s"/>`, wayID, a, b, highway)
		if oneway != "" {
			fmt.Fprintf(out, `<tag k="oneway" v="%s"/>`, oneway)
		}
		if speed > 0 {
			fmt.Fprintf(out, `<tag k="maxspeed" v="%d"/>`, speed)
		}
		fmt.Fprintln(out, `</way>`)
		wayID++
	}
	segment := func(a, b int64, arterial bool, line int) {
		switch {
		case arterial:
			way(a, b, "primary", "", 60)
		case r.IntN(100) < 5:
			// 5% of residential segments missing (construction, parks, rivers)
		case line%2 == 0:
			way(a, b, "residential", "yes", 20+r.IntN(4)*5) // one-way, alternating direction
		default:
			way(b, a, "residential", "yes", 20+r.IntN(4)*5)
		}
	}
	for row := range *h {
		for col := range *w - 1 {
			segment(id(row, col), id(row, col+1), row%10 == 0, row)
		}
	}
	for col := range *w {
		for row := range *h - 1 {
			segment(id(row, col), id(row+1, col), col%10 == 0, col)
		}
	}
	fmt.Fprintln(out, `</osm>`)
}
