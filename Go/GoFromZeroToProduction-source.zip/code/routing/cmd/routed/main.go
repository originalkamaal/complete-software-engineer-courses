// Command routed serves routes for an OSM extract. SIGHUP reloads the file.
//
//	routed -osm city.osm -addr :8090
package main

import (
	"context"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"example.com/routing/server"
)

func main() {
	path := flag.String("osm", "city.osm", "OpenStreetMap XML file")
	addr := flag.String("addr", ":8090", "listen address")
	flag.Parse()
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil))

	start := time.Now()
	e, err := server.Load(*path)
	if err != nil {
		log.Error("load", "err", err)
		os.Exit(1)
	}
	log.Info("graph loaded", "nodes", e.G.NumNodes(), "edges", e.G.NumEdges(), "took", time.Since(start))
	s := server.New(e, log)

	// SIGHUP: rebuild from the file in the background, then swap atomically.
	// A bad file is logged and ignored: the old graph keeps serving.
	hup := make(chan os.Signal, 1)
	signal.Notify(hup, syscall.SIGHUP)
	go func() {
		for range hup {
			e, err := server.Load(*path)
			if err != nil {
				log.Error("reload failed; keeping current graph", "err", err)
				continue
			}
			s.Swap(e)
			log.Info("graph reloaded", "nodes", e.G.NumNodes())
		}
	}()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	srv := &http.Server{Addr: *addr, Handler: s.Handler(), ReadHeaderTimeout: 5 * time.Second,
		WriteTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}
	go func() {
		<-ctx.Done()
		sctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		srv.Shutdown(sctx)
	}()
	if err := srv.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
		log.Error("serve", "err", err)
		os.Exit(1)
	}
}
