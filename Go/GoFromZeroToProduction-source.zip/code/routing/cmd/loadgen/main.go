// Command loadgen sends random route requests with a fixed number of
// concurrent workers for a fixed time and reports throughput and latency
// percentiles.
//
//	loadgen -url http://localhost:8090 -c 8 -d 20s
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"math/rand/v2"
	"net/http"
	"slices"
	"sync"
	"time"
)

func main() {
	base := flag.String("url", "http://localhost:8090", "server")
	conc := flag.Int("c", 8, "concurrent workers")
	dur := flag.Duration("d", 10*time.Second, "test duration")
	algo := flag.String("algo", "astar", "algorithm")
	flag.Parse()

	ctx, cancel := context.WithTimeout(context.Background(), *dur)
	defer cancel()
	client := &http.Client{Timeout: 5 * time.Second,
		Transport: &http.Transport{MaxIdleConnsPerHost: *conc}} // DT-246: reuse connections
	var mu sync.Mutex
	var lat []time.Duration
	errors := 0
	var wg sync.WaitGroup
	for w := range *conc {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := rand.New(rand.NewPCG(uint64(w), 99))
			for ctx.Err() == nil {
				// random points inside the synthetic city's bounding box
				q := fmt.Sprintf("%s/route?from=%.5f,%.5f&to=%.5f,%.5f&algo=%s", *base,
					18.45+r.Float64()*0.26, 73.80+r.Float64()*0.28,
					18.45+r.Float64()*0.26, 73.80+r.Float64()*0.28, *algo)
				start := time.Now()
				resp, err := client.Get(q)
				if err == nil {
					io.Copy(io.Discard, resp.Body)
					resp.Body.Close()
				}
				d := time.Since(start)
				mu.Lock()
				if err != nil || resp.StatusCode >= 500 {
					errors++
				} else {
					lat = append(lat, d)
				}
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	slices.Sort(lat)
	p := func(q float64) time.Duration { return lat[int(q*float64(len(lat)-1))].Round(10 * time.Microsecond) }
	fmt.Printf("%s, %d workers, %v: %d requests (%.0f/s), errors %d, p50 %v, p95 %v, p99 %v, max %v\n",
		*algo, *conc, *dur, len(lat), float64(len(lat))/dur.Seconds(), errors, p(0.50), p(0.95), p(0.99), lat[len(lat)-1].Round(10*time.Microsecond))
}
