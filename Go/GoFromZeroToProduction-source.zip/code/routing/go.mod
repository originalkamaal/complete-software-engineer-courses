module example.com/routing

go 1.24
