package geo

import (
	"math"
	"testing"
)

func TestHaversine(t *testing.T) {
	pune := Point{18.5204, 73.8567}
	mumbai := Point{19.0760, 72.8777}
	d := Haversine(pune, mumbai)
	if math.Abs(d-119_800) > 1_000 { // about 120 km as the crow flies
		t.Errorf("Pune-Mumbai = %.0f m", d)
	}
	near := Point{18.5304, 73.8667}
	if e, h := Equirectangular(pune, near), Haversine(pune, near); math.Abs(e-h) > 0.5 {
		t.Errorf("equirectangular %.2f vs haversine %.2f", e, h)
	}
}

func TestGeohash(t *testing.T) {
	// Reference value from the original geohash.org example.
	if g := Geohash(Point{57.64911, 10.40744}, 11); g != "u4pruydqqvj" {
		t.Errorf("geohash = %s", g)
	}
}

func TestPolyline(t *testing.T) {
	// Example from Google's polyline documentation.
	pts := []Point{{38.5, -120.2}, {40.7, -120.95}, {43.252, -126.453}}
	if s := EncodePolyline(pts); s != "_p~iF~ps|U_ulLnnqC_mqNvxq`@" {
		t.Errorf("polyline = %q", s)
	}
}
