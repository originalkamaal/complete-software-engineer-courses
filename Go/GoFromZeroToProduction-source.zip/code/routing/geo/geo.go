// Package geo has small, exact-enough tools for geographic coordinates.
package geo

import (
	"math"
	"strings"
)

// Point is a WGS84 coordinate in degrees.
type Point struct{ Lat, Lon float64 }

const EarthRadiusM = 6_371_008.8 // mean Earth radius in metres

func rad(d float64) float64 { return d * math.Pi / 180 }

// Haversine returns the great-circle distance in metres. It treats the Earth
// as a sphere: error up to about 0.5% versus the WGS84 ellipsoid, which is
// fine for routing heuristics and nearest-neighbour search.
func Haversine(a, b Point) float64 {
	dLat := rad(b.Lat - a.Lat)
	dLon := rad(b.Lon - a.Lon)
	h := math.Sin(dLat/2)*math.Sin(dLat/2) +
		math.Cos(rad(a.Lat))*math.Cos(rad(b.Lat))*math.Sin(dLon/2)*math.Sin(dLon/2)
	return 2 * EarthRadiusM * math.Asin(math.Min(1, math.Sqrt(h)))
}

// Equirectangular is a fast approximation of Haversine for short distances
// (a few km): projects onto a plane using the mean latitude.
func Equirectangular(a, b Point) float64 {
	x := rad(b.Lon-a.Lon) * math.Cos(rad((a.Lat+b.Lat)/2))
	y := rad(b.Lat - a.Lat)
	return EarthRadiusM * math.Sqrt(x*x+y*y)
}

const base32 = "0123456789bcdefghjkmnpqrstuvwxyz"

// Geohash encodes p with the given number of characters (precision 7 is a
// cell of about 153 m × 153 m). Nearby points usually share a prefix.
func Geohash(p Point, precision int) string {
	latLo, latHi, lonLo, lonHi := -90.0, 90.0, -180.0, 180.0
	var sb strings.Builder
	bit, ch, even := 0, 0, true
	for sb.Len() < precision {
		if even { // longitude bit
			mid := (lonLo + lonHi) / 2
			if p.Lon >= mid {
				ch |= 1 << (4 - bit)
				lonLo = mid
			} else {
				lonHi = mid
			}
		} else { // latitude bit
			mid := (latLo + latHi) / 2
			if p.Lat >= mid {
				ch |= 1 << (4 - bit)
				latLo = mid
			} else {
				latHi = mid
			}
		}
		even = !even
		if bit++; bit == 5 {
			sb.WriteByte(base32[ch])
			bit, ch = 0, 0
		}
	}
	return sb.String()
}

// EncodePolyline encodes points in Google's polyline format (precision 1e5),
// the compact string format most map clients accept.
func EncodePolyline(pts []Point) string {
	var sb strings.Builder
	var pLat, pLon int64
	for _, p := range pts {
		lat := int64(math.Round(p.Lat * 1e5))
		lon := int64(math.Round(p.Lon * 1e5))
		encodeSigned(&sb, lat-pLat)
		encodeSigned(&sb, lon-pLon)
		pLat, pLon = lat, lon
	}
	return sb.String()
}

func encodeSigned(sb *strings.Builder, v int64) {
	u := uint64(v << 1)
	if v < 0 {
		u = ^u // zig-zag: small negative numbers become small positive ones
	}
	for u >= 0x20 {
		sb.WriteByte(byte((0x20 | (u & 0x1f)) + 63))
		u >>= 5
	}
	sb.WriteByte(byte(u + 63))
}
