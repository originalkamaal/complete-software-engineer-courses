// Package route computes fastest routes on a graph.Graph with Dijkstra,
// A*, and bidirectional Dijkstra.
package route

import (
	"errors"
	"math"

	"example.com/routing/geo"
	"example.com/routing/graph"
)

var ErrNoRoute = errors.New("no route")

// Result of one query.
type Result struct {
	Nodes      []int32 // the path, start to target
	DurationMs uint64
	Settled    int // nodes whose final distance was fixed: the work done
}

// Router owns per-query scratch space. Searches reuse it without clearing
// it, by stamping entries with a query number (O(1) reset instead of O(n)).
// A Router is not safe for concurrent use; create one per goroutine.
type Router struct {
	g, rev  *graph.Graph
	dist    [2][]uint64
	prev    [2][]int32
	stamp   [2][]uint32
	settled [2][]uint32
	query   uint32
	heaps   [2]heap
}

func New(g, rev *graph.Graph) *Router {
	n := g.NumNodes()
	r := &Router{g: g, rev: rev}
	for s := range 2 {
		r.dist[s] = make([]uint64, n)
		r.prev[s] = make([]int32, n)
		r.stamp[s] = make([]uint32, n)
		r.settled[s] = make([]uint32, n)
	}
	return r
}

const inf = math.MaxUint64

func (r *Router) d(side int, v int32) uint64 {
	if r.stamp[side][v] != r.query {
		return inf
	}
	return r.dist[side][v]
}

func (r *Router) set(side int, v int32, d uint64, p int32) {
	r.stamp[side][v] = r.query
	r.dist[side][v] = d
	r.prev[side][v] = p
}

func (r *Router) begin() {
	r.query++
	if r.query == 0 { // wrapped after 4 billion queries: clear for real
		for s := range 2 {
			clear(r.stamp[s])
			clear(r.settled[s])
		}
		r.query = 1
	}
	r.heaps[0].reset()
	r.heaps[1].reset()
}

// Dijkstra is the baseline: expand nodes in order of travel time.
func (r *Router) Dijkstra(src, dst int32) (Result, error) {
	return r.astar(src, dst, func(int32) uint64 { return 0 })
}

// AStar adds a lower bound on the remaining time: straight-line distance
// at the fastest speed in the graph. It never overestimates (admissible),
// so the result is still optimal, but far fewer nodes are settled.
func (r *Router) AStar(src, dst int32) (Result, error) {
	target := r.g.Point(dst)
	maxSpeed := r.g.MaxSpeed
	return r.astar(src, dst, func(v int32) uint64 {
		return uint64(geo.Haversine(r.g.Point(v), target) / maxSpeed * 1000) // ms, rounded down
	})
}

func (r *Router) astar(src, dst int32, h func(int32) uint64) (Result, error) {
	r.begin()
	g := r.g
	r.set(0, src, 0, -1)
	r.heaps[0].push(h(src), src)
	settled := 0
	for r.heaps[0].len() > 0 {
		_, v := r.heaps[0].pop()
		if r.settled[0][v] == r.query {
			continue // stale heap entry
		}
		r.settled[0][v] = r.query
		settled++
		if v == dst {
			return Result{Nodes: r.path(src, dst), DurationMs: r.d(0, dst), Settled: settled}, nil
		}
		dv := r.d(0, v)
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			nd := dv + uint64(g.Cost[e])
			if nd < r.d(0, w) {
				r.set(0, w, nd, v)
				r.heaps[0].push(nd+h(w), w)
			}
		}
	}
	return Result{Settled: settled}, ErrNoRoute
}

// Bidirectional runs Dijkstra forwards from src and backwards (on the
// reversed graph) from dst, alternating, and stops when the two searches
// can no longer improve the best meeting point.
func (r *Router) Bidirectional(src, dst int32) (Result, error) {
	r.begin()
	gs := [2]*graph.Graph{r.g, r.rev}
	r.set(0, src, 0, -1)
	r.set(1, dst, 0, -1)
	r.heaps[0].push(0, src)
	r.heaps[1].push(0, dst)
	best, meet := uint64(inf), int32(-1)
	settled := 0
	for r.heaps[0].len() > 0 || r.heaps[1].len() > 0 {
		// Stop when the smallest keys on both sides sum to at least best.
		if best != inf && r.heaps[0].minKey()+r.heaps[1].minKey() >= best {
			break
		}
		side := 0
		if r.heaps[1].len() > 0 && (r.heaps[0].len() == 0 || r.heaps[1].minKey() < r.heaps[0].minKey()) {
			side = 1
		}
		_, v := r.heaps[side].pop()
		if r.settled[side][v] == r.query {
			continue
		}
		r.settled[side][v] = r.query
		settled++
		dv := r.d(side, v)
		g := gs[side]
		for e := g.First[v]; e < g.First[v+1]; e++ {
			w := g.To[e]
			nd := dv + uint64(g.Cost[e])
			if nd < r.d(side, w) {
				r.set(side, w, nd, v)
				r.heaps[side].push(nd, w)
			}
			if other := r.d(1-side, w); other != inf && nd+other < best {
				best, meet = nd+other, w
			}
		}
	}
	if meet < 0 {
		return Result{Settled: settled}, ErrNoRoute
	}
	// forward half: src..meet; backward half: meet..dst via prev on side 1
	nodes := r.path(src, meet)
	for v := r.prev[1][meet]; v != -1; v = r.prev[1][v] {
		nodes = append(nodes, v)
	}
	return Result{Nodes: nodes, DurationMs: best, Settled: settled}, nil
}

func (r *Router) path(src, dst int32) []int32 {
	var p []int32
	for v := dst; v != -1; v = r.prev[0][v] {
		p = append(p, v)
		if v == src {
			break
		}
	}
	for i, j := 0, len(p)-1; i < j; i, j = i+1, j-1 {
		p[i], p[j] = p[j], p[i]
	}
	return p
}

// heap is a binary min-heap of (key, node) specialised for speed: no
// interfaces, no closures, no generics in the hot loop (Unit 10.8).
type heap struct {
	keys  []uint64
	nodes []int32
}

func (h *heap) reset()   { h.keys, h.nodes = h.keys[:0], h.nodes[:0] }
func (h *heap) len() int { return len(h.keys) }
func (h *heap) minKey() uint64 {
	if len(h.keys) == 0 {
		return inf / 2 // "infinite" but safe to add to another key
	}
	return h.keys[0]
}

func (h *heap) push(k uint64, v int32) {
	h.keys = append(h.keys, k)
	h.nodes = append(h.nodes, v)
	i := len(h.keys) - 1
	for i > 0 {
		p := (i - 1) / 2
		if h.keys[p] <= h.keys[i] {
			break
		}
		h.keys[p], h.keys[i] = h.keys[i], h.keys[p]
		h.nodes[p], h.nodes[i] = h.nodes[i], h.nodes[p]
		i = p
	}
}

func (h *heap) pop() (uint64, int32) {
	k, v := h.keys[0], h.nodes[0]
	n := len(h.keys) - 1
	h.keys[0], h.nodes[0] = h.keys[n], h.nodes[n]
	h.keys, h.nodes = h.keys[:n], h.nodes[:n]
	i := 0
	for {
		l, s := 2*i+1, i
		if l < n && h.keys[l] < h.keys[s] {
			s = l
		}
		if l+1 < n && h.keys[l+1] < h.keys[s] {
			s = l + 1
		}
		if s == i {
			return k, v
		}
		h.keys[s], h.keys[i] = h.keys[i], h.keys[s]
		h.nodes[s], h.nodes[i] = h.nodes[i], h.nodes[s]
		i = s
	}
}

// Geometry returns the path's coordinates.
func Geometry(g *graph.Graph, nodes []int32) []geo.Point {
	pts := make([]geo.Point, len(nodes))
	for i, v := range nodes {
		pts[i] = g.Point(v)
	}
	return pts
}

// LengthM returns the path length in metres.
func LengthM(g *graph.Graph, nodes []int32) float64 {
	sum := 0.0
	for i := 1; i < len(nodes); i++ {
		sum += geo.Haversine(g.Point(nodes[i-1]), g.Point(nodes[i]))
	}
	return sum
}
