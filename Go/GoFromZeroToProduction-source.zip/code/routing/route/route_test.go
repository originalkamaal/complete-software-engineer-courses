package route

import (
	"bytes"
	"math/rand/v2"
	"os/exec"
	"testing"
	"time"

	"example.com/routing/graph"
	"example.com/routing/osm"
)

func loadCity(t testing.TB, size int) (*graph.Graph, *graph.Graph) {
	t.Helper()
	out, err := exec.Command("go", "run", "../cmd/gencity", "-w", itoa(size), "-h", itoa(size), "-seed", "7").Output()
	if err != nil {
		t.Fatal(err)
	}
	d, err := osm.Read(bytes.NewReader(out))
	if err != nil {
		t.Fatal(err)
	}
	g, err := graph.Build(d)
	if err != nil {
		t.Fatal(err)
	}
	return g, g.Reverse()
}

func itoa(n int) string { return string(rune('0'+n/100%10)) + string(rune('0'+n/10%10)) + string(rune('0'+n%10)) }

// All three algorithms must agree on the optimal travel time.
func TestAlgorithmsAgree(t *testing.T) {
	g, rev := loadCity(t, 60)
	r := New(g, rev)
	rnd := rand.New(rand.NewPCG(1, 2))
	n := int32(g.NumNodes())
	agreed, noRoute := 0, 0
	for range 300 {
		s, d := rnd.Int32N(n), rnd.Int32N(n)
		a, errA := r.Dijkstra(s, d)
		b, errB := r.AStar(s, d)
		c, errC := r.Bidirectional(s, d)
		if (errA == nil) != (errB == nil) || (errA == nil) != (errC == nil) {
			t.Fatalf("%d->%d: errors differ: %v %v %v", s, d, errA, errB, errC)
		}
		if errA != nil {
			noRoute++
			continue
		}
		if a.DurationMs != b.DurationMs || a.DurationMs != c.DurationMs {
			t.Fatalf("%d->%d: durations differ: dijkstra %d, A* %d, bidirectional %d", s, d, a.DurationMs, b.DurationMs, c.DurationMs)
		}
		// the returned path must really have that duration
		if got := pathCost(g, c.Nodes); got != c.DurationMs {
			t.Fatalf("%d->%d: bidirectional path costs %d, reported %d", s, d, got, c.DurationMs)
		}
		agreed++
	}
	t.Logf("%d routes agreed, %d pairs unreachable", agreed, noRoute)
}

func pathCost(g *graph.Graph, nodes []int32) uint64 {
	var sum uint64
	for i := 1; i < len(nodes); i++ {
		best := uint64(1 << 62)
		for e := g.First[nodes[i-1]]; e < g.First[nodes[i-1]+1]; e++ {
			if g.To[e] == nodes[i] && uint64(g.Cost[e]) < best {
				best = uint64(g.Cost[e])
			}
		}
		sum += best
	}
	return sum
}

func TestSnapping(t *testing.T) {
	g, _ := loadCity(t, 30)
	ix := graph.NewIndex(g, 0.002)
	rnd := rand.New(rand.NewPCG(3, 4))
	for range 200 {
		v := rnd.Int32N(int32(g.NumNodes()))
		p := g.Point(v)
		p.Lat += 0.0001 // ~11 m off
		got, _ := ix.Nearest(p)
		// brute force check
		best, bestD := int32(-1), 1e18
		for u := range int32(g.NumNodes()) {
			if d := dist2(g, u, p.Lat, p.Lon); d < bestD {
				best, bestD = u, d
			}
		}
		if got != best {
			t.Fatalf("Nearest = %d, brute force = %d", got, best)
		}
	}
}

func dist2(g *graph.Graph, v int32, lat, lon float64) float64 {
	dy, dx := g.Lat[v]-lat, (g.Lon[v]-lon)*0.9483 // cos(18.5°)
	return dx*dx + dy*dy
}

func BenchmarkRouting(b *testing.B) {
	g, rev := loadCity(b, 300)
	r := New(g, rev)
	rnd := rand.New(rand.NewPCG(5, 6))
	n := int32(g.NumNodes())
	pairs := make([][2]int32, 0, 200)
	for len(pairs) < cap(pairs) {
		s, d := rnd.Int32N(n), rnd.Int32N(n)
		if _, err := r.Dijkstra(s, d); err == nil {
			pairs = append(pairs, [2]int32{s, d})
		}
	}
	algos := []struct {
		name string
		f    func(s, d int32) (Result, error)
	}{{"Dijkstra", r.Dijkstra}, {"AStar", r.AStar}, {"Bidirectional", r.Bidirectional}}
	for _, a := range algos {
		b.Run(a.name, func(b *testing.B) {
			settled := 0
			i := 0
			start := time.Now()
			for b.Loop() {
				p := pairs[i%len(pairs)]
				res, _ := a.f(p[0], p[1])
				settled += res.Settled
				i++
			}
			b.ReportMetric(float64(settled)/float64(i), "settled/op")
			_ = start
		})
	}
}
