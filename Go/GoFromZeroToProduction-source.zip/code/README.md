# Companion code for "Go from Zero to Production"

One Go module per chapter project. Each was built and tested with Go 1.24.

| Folder | Chapter | Project |
| --- | --- | --- |
| numinfo | 0 | Number-representation explorer |
| playtool | 1 | Command-line playground tool |
| wordfreq | 2 | Word-frequency counter |
| library | 3–4 | Library management (packages, interfaces, full test suite) |
| logscan | 5, 10 | Streaming log analyser (optimised in Chapter 10) |
| dsgrid | 6 | Data structures and grid path-finding |
| crawler | 7 | Concurrent web crawler |
| chat, shortener | 8 | WebSocket chat server; URL shortener API |
| shortener-db | 9 | Shortener with PostgreSQL, migrations, Redis cache |
| shortener-prod | 11 | Production-ready shortener (config, metrics, Docker, CI, Kubernetes) |
| orders | 12 | Order processing with outbox, queue, and saga |
| routing | 13–14 | OSM routing engine and routing service |

Run `go test ./...` inside a folder. Database tests need PostgreSQL and Redis (see Chapter 9).
For the routing project: `go run ./cmd/gencity -w 300 -h 300 > city.osm` (the 90,000-node city used in the book), then `go run ./cmd/routed -osm city.osm`.
