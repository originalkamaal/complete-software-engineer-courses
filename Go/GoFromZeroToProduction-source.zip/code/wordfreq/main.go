// Command wordfreq counts words in its input and prints the most frequent.
//
//	wordfreq [N] [file ...]
//
// With no files it reads standard input. N (default 10) is how many
// words to print. Words are runs of letters, digits, and combining marks,
// optionally joined by an apostrophe or hyphen ("don't", "well-known").
// Counting is case-insensitive.
package main

import (
	"bufio"
	"cmp"
	"errors"
	"fmt"
	"io"
	"os"
	"slices"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

func main() {
	if err := run(os.Args[1:], os.Stdin, os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "wordfreq:", err)
		os.Exit(1)
	}
}

type entry struct {
	word  string
	count int
}

func run(args []string, stdin io.Reader, stdout io.Writer) error {
	top := 10
	if len(args) > 0 {
		if n, err := strconv.Atoi(args[0]); err == nil {
			if n <= 0 {
				return fmt.Errorf("N must be positive, got %d", n)
			}
			top = n
			args = args[1:]
		}
	}

	counts := make(map[string]int)
	total := 0
	if len(args) == 0 {
		n, err := countWords(stdin, counts)
		if err != nil {
			return fmt.Errorf("stdin: %w", err)
		}
		total += n
	}
	for _, name := range args {
		n, err := countFile(name, counts)
		if err != nil {
			return err
		}
		total += n
	}

	entries := make([]entry, 0, len(counts))
	for w, c := range counts {
		entries = append(entries, entry{w, c})
	}
	// Highest count first; ties in alphabetical order, so output is stable.
	slices.SortFunc(entries, func(a, b entry) int {
		if c := cmp.Compare(b.count, a.count); c != 0 {
			return c
		}
		return strings.Compare(a.word, b.word)
	})
	if len(entries) > top {
		entries = entries[:top]
	}

	width := 0
	for _, e := range entries {
		width = max(width, utf8.RuneCountInString(e.word))
	}
	fmt.Fprintf(stdout, "%d words, %d distinct\n", total, len(counts))
	for _, e := range entries {
		pad := strings.Repeat(" ", width-utf8.RuneCountInString(e.word))
		fmt.Fprintf(stdout, "%s%s  %d\n", e.word, pad, e.count)
	}
	return nil
}

func countFile(name string, counts map[string]int) (int, error) {
	f, err := os.Open(name)
	if err != nil {
		return 0, err // the error already contains the file name
	}
	defer f.Close()
	n, err := countWords(f, counts)
	if err != nil {
		return n, fmt.Errorf("%s: %w", name, err)
	}
	return n, nil
}

// countWords adds every word read from r to counts and returns how many
// words it saw.
func countWords(r io.Reader, counts map[string]int) (int, error) {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 0, 64*1024), 16*1024*1024)
	total := 0
	for sc.Scan() {
		for _, w := range splitWords(sc.Text()) {
			counts[w]++
			total++
		}
	}
	if err := sc.Err(); err != nil {
		if errors.Is(err, bufio.ErrTooLong) {
			return total, fmt.Errorf("a line is longer than 16 MiB: %w", err)
		}
		return total, err
	}
	return total, nil
}

func isWordRune(r rune) bool {
	// unicode.IsMark matters: Devanagari vowel signs (like the "े" in "नमस्ते")
	// are marks, not letters. Without it, Hindi words fall apart.
	return unicode.IsLetter(r) || unicode.IsDigit(r) || unicode.IsMark(r)
}

func isJoiner(r rune) bool {
	return r == '\'' || r == '’' || r == '-'
}

// splitWords returns the lower-cased words in line.
func splitWords(line string) []string {
	var words []string
	runes := []rune(line)
	var b strings.Builder
	flush := func() {
		if b.Len() > 0 {
			words = append(words, b.String())
			b.Reset()
		}
	}
	for i, r := range runes {
		switch {
		case isWordRune(r):
			b.WriteRune(unicode.ToLower(r))
		case isJoiner(r) && b.Len() > 0 && i+1 < len(runes) && isWordRune(runes[i+1]):
			// keep an apostrophe or hyphen only between two word characters
			if r == '’' {
				r = '\''
			}
			b.WriteRune(r)
		default:
			flush()
		}
	}
	flush()
	return words
}
