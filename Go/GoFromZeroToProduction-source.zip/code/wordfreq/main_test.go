package main

import (
	"slices"
	"strings"
	"testing"
)

func TestSplitWords(t *testing.T) {
	tests := []struct {
		in   string
		want []string
	}{
		{"Hello, hello WORLD!", []string{"hello", "hello", "world"}},
		{"don't stop - well-known", []string{"don't", "stop", "well-known"}},
		{"नमस्ते दुनिया", []string{"नमस्ते", "दुनिया"}},
		{"Ünïcödé café", []string{"ünïcödé", "café"}},
		{"'quoted' -dash-", []string{"quoted", "dash"}},
		{"", nil},
	}
	for _, tt := range tests {
		if got := splitWords(tt.in); !slices.Equal(got, tt.want) {
			t.Errorf("splitWords(%q) = %q, want %q", tt.in, got, tt.want)
		}
	}
}

func TestRun(t *testing.T) {
	in := strings.NewReader("b a b c b a\n")
	var out strings.Builder
	if err := run([]string{"2"}, in, &out); err != nil {
		t.Fatal(err)
	}
	want := "6 words, 3 distinct\nb  3\na  2\n"
	if out.String() != want {
		t.Errorf("got %q, want %q", out.String(), want)
	}
}
