package main

import (
	"strings"
	"testing"
)

func FuzzSplitWords(f *testing.F) {
	for _, s := range []string{"Hello, world", "don't", "नमस्ते", ""} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) {
		for _, w := range splitWords(s) {
			if w == "" || strings.ContainsAny(w, " \t\n") || strings.ToLower(w) != w {
				t.Errorf("bad word %q from %q", w, s)
			}
		}
	})
}
