package main

import (
	"bufio"
	"context"
	"io"
	"log/slog"
	"net"
	"strings"
	"testing"
	"time"
)

type testClient struct {
	conn net.Conn
	r    *bufio.Reader
}

func dial(t *testing.T, addr, name string) *testClient {
	t.Helper()
	conn, err := net.Dial("tcp", addr)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { conn.Close() })
	c := &testClient{conn: conn, r: bufio.NewReader(conn)}
	c.expect(t, "name: ")
	c.send(t, name)
	c.expectLine(t, "welcome, "+name)
	return c
}

func (c *testClient) send(t *testing.T, s string) {
	t.Helper()
	if _, err := io.WriteString(c.conn, s+"\n"); err != nil {
		t.Fatal(err)
	}
}

func (c *testClient) expect(t *testing.T, prefix string) {
	t.Helper()
	c.conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	buf := make([]byte, len(prefix))
	if _, err := io.ReadFull(c.r, buf); err != nil || string(buf) != prefix {
		t.Fatalf("got %q, %v; want %q", buf, err, prefix)
	}
}

func (c *testClient) expectLine(t *testing.T, prefix string) {
	t.Helper()
	c.conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	line, err := c.r.ReadString('\n')
	if err != nil || !strings.HasPrefix(line, prefix) {
		t.Fatalf("got %q, %v; want prefix %q", line, err, prefix)
	}
}

func start(t *testing.T) (string, context.CancelFunc, chan error) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0") // port 0: any free port
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	h := NewHub()
	go h.Run(ctx)
	done := make(chan error, 1)
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	go func() { done <- Serve(ctx, ln, h, log) }()
	return ln.Addr().String(), cancel, done
}

func TestChat(t *testing.T) {
	addr, cancel, done := start(t)
	defer cancel()

	asha := dial(t, addr, "asha")
	ravi := dial(t, addr, "ravi")
	asha.expectLine(t, "ravi joined")

	asha.send(t, "namaste")
	ravi.expectLine(t, "asha: namaste")

	ravi.send(t, "/who")
	ravi.expectLine(t, "online: asha, ravi")

	ravi.send(t, "/quit")
	asha.expectLine(t, "ravi left")

	cancel() // graceful shutdown: Serve must return
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Serve did not stop after cancel")
	}
}
