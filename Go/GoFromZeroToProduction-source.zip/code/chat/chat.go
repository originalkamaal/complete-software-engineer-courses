// Command chat is a line-based TCP chat server. Connect with
// "nc localhost 9000"; the first line you send is your name.
// Commands: /who lists users, /quit leaves.
package main

import (
	"bufio"
	"context"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"slices"
	"strings"
	"sync"
	"time"
)

const (
	idleTimeout = 5 * time.Minute
	maxLine     = 1024
	outBuffer   = 32 // messages queued per client before it is considered too slow
)

type client struct {
	name string
	out  chan string // the hub sends; the client's writer goroutine receives
}

type message struct {
	from *client
	text string
}

// Hub owns the set of clients. Only the hub's goroutine touches the map,
// and only the hub sends on or closes a client's out channel: state
// confinement (P-32) and "only the sender closes" (Unit 7.3).
type Hub struct {
	join  chan *client
	leave chan *client
	msgs  chan message
	who   chan *client
}

func NewHub() *Hub {
	return &Hub{
		join:  make(chan *client),
		leave: make(chan *client),
		msgs:  make(chan message),
		who:   make(chan *client),
	}
}

func (h *Hub) Run(ctx context.Context) {
	clients := map[*client]bool{}
	send := func(c *client, text string) {
		select {
		case c.out <- text:
		default: // slow client: drop it rather than block everyone (backpressure)
			delete(clients, c)
			close(c.out)
		}
	}
	broadcast := func(text string, except *client) {
		for c := range clients {
			if c != except {
				send(c, text)
			}
		}
	}
	for {
		select {
		case c := <-h.join:
			clients[c] = true
			send(c, "welcome, "+c.name+" (/who, /quit)")
			broadcast(c.name+" joined", c)
		case c := <-h.leave:
			if clients[c] {
				delete(clients, c)
				close(c.out)
				broadcast(c.name+" left", nil)
			}
		case m := <-h.msgs:
			broadcast(m.from.name+": "+m.text, m.from)
		case c := <-h.who:
			if !clients[c] {
				continue
			}
			var names []string
			for other := range clients {
				names = append(names, other.name)
			}
			slices.Sort(names)
			send(c, "online: "+strings.Join(names, ", "))
		case <-ctx.Done():
			for c := range clients {
				close(c.out)
			}
			return
		}
	}
}

// Serve accepts connections until ctx is done, then waits for them to end.
func Serve(ctx context.Context, ln net.Listener, h *Hub, log *slog.Logger) error {
	var wg sync.WaitGroup
	go func() {
		<-ctx.Done()
		ln.Close() // unblocks Accept
	}()
	for {
		conn, err := ln.Accept()
		if err != nil {
			if ctx.Err() != nil {
				wg.Wait()
				return nil
			}
			return err
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			handle(ctx, conn, h, log)
		}()
	}
}

func handle(ctx context.Context, conn net.Conn, h *Hub, log *slog.Logger) {
	defer conn.Close()
	log.Info("connected", "remote", conn.RemoteAddr())
	sc := bufio.NewScanner(conn)
	sc.Buffer(make([]byte, 0, maxLine), maxLine)

	readLine := func() (string, bool) {
		conn.SetReadDeadline(time.Now().Add(idleTimeout))
		if !sc.Scan() {
			return "", false
		}
		return strings.TrimSpace(sc.Text()), true
	}

	fmt.Fprint(conn, "name: ")
	name, ok := readLine()
	if !ok || name == "" {
		return
	}
	c := &client{name: name, out: make(chan string, outBuffer)}

	select {
	case h.join <- c: // from now on the hub owns c.out and will close it
	case <-ctx.Done():
		return
	}

	// Writer goroutine: the only goroutine that writes to conn from now on.
	// It ends when the hub closes c.out (after /quit, on shutdown, or
	// because this client was too slow).
	writerDone := make(chan struct{})
	go func() {
		defer close(writerDone)
		for line := range c.out {
			conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if _, err := fmt.Fprintln(conn, line); err != nil {
				break
			}
		}
		conn.Close() // also unblocks the reader below
		for range c.out {
			// drain until the hub closes the channel, so the hub never blocks
		}
	}()

	for {
		line, ok := readLine()
		if !ok || line == "/quit" {
			break
		}
		switch {
		case line == "":
		case line == "/who":
			select {
			case h.who <- c:
			case <-ctx.Done():
			}
		default:
			select {
			case h.msgs <- message{c, line}:
			case <-ctx.Done():
			}
		}
		if ctx.Err() != nil {
			break
		}
	}
	select {
	case h.leave <- c:
	case <-ctx.Done():
	}
	<-writerDone
	if err := sc.Err(); err != nil && !errors.Is(err, net.ErrClosed) {
		log.Info("read error", "name", name, "err", err)
	}
	log.Info("disconnected", "name", name)
}

func main() {
	addr := flag.String("addr", "localhost:9000", "listen address")
	flag.Parse()
	log := slog.New(slog.NewTextHandler(os.Stderr, nil))

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Error("listen", "err", err)
		os.Exit(1)
	}
	log.Info("listening", "addr", ln.Addr())
	h := NewHub()
	go h.Run(ctx)
	if err := Serve(ctx, ln, h, log); err != nil {
		log.Error("serve", "err", err)
		os.Exit(1)
	}
}
