module example.com/chat

go 1.24
