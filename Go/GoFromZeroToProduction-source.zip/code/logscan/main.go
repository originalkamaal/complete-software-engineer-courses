// Command logscan summarises HTTP access logs in constant memory.
//
//	logscan [flags] [file ...]
//
// Each input line has six space-separated fields:
//
//	2026-11-01T10:00:00Z GET /api/users 200 123ms 512
//	time (RFC 3339)      method path status duration bytes
//
// Files ending in .gz are decompressed on the fly. With no files, logscan
// reads standard input. Ctrl+C stops reading and prints a partial report.
package main

import (
	"bufio"
	"compress/gzip"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"os"
	"os/signal"
	"strings"
	"time"
)

type config struct {
	from, to time.Time
	top      int
	slow     time.Duration
	asJSON   bool
}

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err := run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr); err != nil {
		fmt.Fprintln(os.Stderr, "logscan:", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, args []string, stdin io.Reader, stdout, stderr io.Writer) error {
	fs := flag.NewFlagSet("logscan", flag.ContinueOnError)
	fs.SetOutput(stderr)
	var cfg config
	var from, to string
	fs.StringVar(&from, "from", "", "only lines at or after this RFC 3339 time")
	fs.StringVar(&to, "to", "", "only lines before this RFC 3339 time")
	fs.IntVar(&cfg.top, "top", 5, "number of paths to list")
	fs.DurationVar(&cfg.slow, "slow", 500*time.Millisecond, "requests at least this long count as slow")
	fs.BoolVar(&cfg.asJSON, "json", false, "print the report as JSON")
	if err := fs.Parse(args); err != nil {
		return err // flag already printed the message and usage
	}
	var err error
	if cfg.from, err = parseTimeFlag("from", from); err != nil {
		return err
	}
	if cfg.to, err = parseTimeFlag("to", to); err != nil {
		return err
	}
	if cfg.top < 1 {
		return fmt.Errorf("-top must be at least 1, got %d", cfg.top)
	}

	log := slog.New(slog.NewTextHandler(stderr, &slog.HandlerOptions{Level: slog.LevelWarn}))
	st := newStats()

	if fs.NArg() == 0 {
		if err := scan(ctx, stdin, "stdin", cfg, st, log); err != nil {
			return err
		}
	}
	for _, name := range fs.Args() {
		if err := scanFile(ctx, name, cfg, st, log); err != nil {
			return err
		}
	}

	rep := st.report(cfg)
	if ctx.Err() != nil {
		rep.Partial = true
	}
	if cfg.asJSON {
		enc := json.NewEncoder(stdout)
		enc.SetIndent("", "  ")
		return enc.Encode(rep)
	}
	return rep.writeText(stdout)
}

func parseTimeFlag(name, v string) (time.Time, error) {
	if v == "" {
		return time.Time{}, nil
	}
	t, err := time.Parse(time.RFC3339, v)
	if err != nil {
		return time.Time{}, fmt.Errorf("-%s: %w", name, err)
	}
	return t, nil
}

func scanFile(ctx context.Context, name string, cfg config, st *stats, log *slog.Logger) error {
	f, err := os.Open(name)
	if err != nil {
		return err
	}
	defer f.Close()

	var r io.Reader = f
	if strings.HasSuffix(name, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			return fmt.Errorf("%s: %w", name, err)
		}
		defer gz.Close()
		r = gz // readers compose: file -> gzip -> scanner
	}
	return scan(ctx, r, name, cfg, st, log)
}

// scan reads r line by line. Memory use does not depend on the input size.
func scan(ctx context.Context, r io.Reader, name string, cfg config, st *stats, log *slog.Logger) error {
	sc := bufio.NewScanner(r)
	lineNo := 0
	for sc.Scan() {
		lineNo++
		if lineNo%4096 == 0 && ctx.Err() != nil {
			return nil // interrupted: keep what we have
		}
		e, err := parseLine(sc.Text())
		if err != nil {
			st.invalid++
			if st.invalid <= 3 {
				log.Warn("skipping invalid line", "file", name, "line", lineNo, "err", err)
			}
			continue
		}
		if !cfg.from.IsZero() && e.time.Before(cfg.from) {
			continue
		}
		if !cfg.to.IsZero() && !e.time.Before(cfg.to) {
			continue
		}
		st.add(e, cfg)
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("%s: %w", name, err)
	}
	return nil
}

var errFields = errors.New("want 6 fields")

type entry struct {
	time     time.Time
	method   string
	path     string
	status   int
	duration time.Duration
	bytes    int64
}

func parseLine(line string) (entry, error) {
	f := strings.Fields(line)
	if len(f) != 6 {
		return entry{}, fmt.Errorf("%w, got %d", errFields, len(f))
	}
	var e entry
	var err error
	if e.time, err = time.Parse(time.RFC3339, f[0]); err != nil {
		return entry{}, err
	}
	e.method, e.path = f[1], f[2]
	if _, err := fmt.Sscanf(f[3], "%d", &e.status); err != nil || e.status < 100 || e.status > 599 {
		return entry{}, fmt.Errorf("bad status %q", f[3])
	}
	if e.duration, err = time.ParseDuration(f[4]); err != nil {
		return entry{}, err
	}
	if _, err := fmt.Sscanf(f[5], "%d", &e.bytes); err != nil || e.bytes < 0 {
		return entry{}, fmt.Errorf("bad byte count %q", f[5])
	}
	return e, nil
}
