package main

import (
	"cmp"
	"fmt"
	"io"
	"maps"
	"slices"
	"text/tabwriter"
	"time"
)

// Latencies are counted in 1 ms buckets up to maxBucket; longer requests
// share the last bucket. Fixed memory, and percentiles exact to 1 ms.
const maxBucket = 60_000 // 60 s

type stats struct {
	total, invalid, slow int
	bytes                int64
	byClass              [6]int // index 1..5 = 1xx..5xx
	byPath               map[string]int
	latency              [maxBucket + 1]int
	first, last          time.Time
}

func newStats() *stats { return &stats{byPath: make(map[string]int)} }

func (s *stats) add(e entry, cfg config) {
	s.total++
	s.bytes += e.bytes
	s.byClass[e.status/100]++
	s.byPath[e.path]++ // distinct paths: memory grows with paths, not lines
	ms := min(int(e.duration/time.Millisecond), maxBucket)
	s.latency[ms]++
	if e.duration >= cfg.slow {
		s.slow++
	}
	if s.first.IsZero() || e.time.Before(s.first) {
		s.first = e.time
	}
	if e.time.After(s.last) {
		s.last = e.time
	}
}

// percentile returns the smallest bucket value with at least p of requests at or below it.
func (s *stats) percentile(p float64) time.Duration {
	if s.total == 0 {
		return 0
	}
	need := int(p*float64(s.total) + 0.999999) // ceil
	seen := 0
	for ms, n := range s.latency {
		seen += n
		if seen >= need {
			return time.Duration(ms) * time.Millisecond
		}
	}
	return maxBucket * time.Millisecond
}

type pathCount struct {
	Path  string `json:"path"`
	Count int    `json:"count"`
}

// Report is what logscan prints; the struct tags define the JSON form.
type Report struct {
	Requests     int            `json:"requests"`
	InvalidLines int            `json:"invalid_lines"`
	Bytes        int64          `json:"bytes"`
	First        *time.Time     `json:"first,omitempty"`
	Last         *time.Time     `json:"last,omitempty"`
	StatusClass  map[string]int `json:"status_classes"`
	Slow         int            `json:"slow_requests"`
	P50          string         `json:"p50"`
	P95          string         `json:"p95"`
	P99          string         `json:"p99"`
	TopPaths     []pathCount    `json:"top_paths"`
	Partial      bool           `json:"partial,omitempty"`
}

func (s *stats) report(cfg config) Report {
	r := Report{
		Requests:     s.total,
		InvalidLines: s.invalid,
		Bytes:        s.bytes,
		StatusClass:  map[string]int{},
		Slow:         s.slow,
		P50:          s.percentile(0.50).String(),
		P95:          s.percentile(0.95).String(),
		P99:          s.percentile(0.99).String(),
	}
	if s.total > 0 {
		r.First, r.Last = &s.first, &s.last
	}
	for c := 1; c <= 5; c++ {
		if s.byClass[c] > 0 {
			r.StatusClass[fmt.Sprintf("%dxx", c)] = s.byClass[c]
		}
	}
	for _, p := range slices.Collect(maps.Keys(s.byPath)) {
		r.TopPaths = append(r.TopPaths, pathCount{p, s.byPath[p]})
	}
	slices.SortFunc(r.TopPaths, func(a, b pathCount) int {
		return cmp.Or(cmp.Compare(b.Count, a.Count), cmp.Compare(a.Path, b.Path))
	})
	r.TopPaths = r.TopPaths[:min(cfg.top, len(r.TopPaths))]
	return r
}

func (r Report) writeText(w io.Writer) error {
	tw := tabwriter.NewWriter(w, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "requests\t%d\n", r.Requests)
	fmt.Fprintf(tw, "invalid lines\t%d\n", r.InvalidLines)
	fmt.Fprintf(tw, "bytes sent\t%d\n", r.Bytes)
	if r.First != nil {
		fmt.Fprintf(tw, "time range\t%s – %s\n", r.First.Format(time.RFC3339), r.Last.Format(time.RFC3339))
	}
	for _, c := range slices.Sorted(maps.Keys(r.StatusClass)) {
		fmt.Fprintf(tw, "status %s\t%d\n", c, r.StatusClass[c])
	}
	fmt.Fprintf(tw, "slow requests\t%d\n", r.Slow)
	fmt.Fprintf(tw, "latency p50/p95/p99\t%s / %s / %s\n", r.P50, r.P95, r.P99)
	fmt.Fprintln(tw, "top paths\t")
	for _, p := range r.TopPaths {
		fmt.Fprintf(tw, "  %s\t%d\n", p.Path, p.Count)
	}
	if r.Partial {
		fmt.Fprintln(tw, "(partial: interrupted)\t")
	}
	return tw.Flush()
}
