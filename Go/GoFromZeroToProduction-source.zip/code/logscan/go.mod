module example.com/logscan

go 1.24
