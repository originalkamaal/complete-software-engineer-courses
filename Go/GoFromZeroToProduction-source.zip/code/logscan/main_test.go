package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const sample = `2026-11-01T10:00:00Z GET /api/users 200 120ms 512
2026-11-01T10:00:01Z GET /api/users 200 80ms 512
2026-11-01T10:00:02Z POST /api/orders 201 640ms 64
2026-11-01T10:00:03Z GET /health 200 1ms 2
this line is broken
2026-11-01T10:00:04Z GET /api/users 500 2s 0
`

func TestParseLine(t *testing.T) {
	e, err := parseLine("2026-11-01T10:00:00Z GET /x 404 1.5s 10")
	if err != nil {
		t.Fatal(err)
	}
	if e.status != 404 || e.duration != 1500*time.Millisecond || e.path != "/x" {
		t.Errorf("got %+v", e)
	}
	for _, bad := range []string{"", "a b c", "2026-11-01T10:00:00Z GET /x 999 1s 1", "2026-11-01T10:00:00Z GET /x 200 fast 1"} {
		if _, err := parseLine(bad); err == nil {
			t.Errorf("parseLine(%q) succeeded", bad)
		}
	}
}

func TestReportJSON(t *testing.T) {
	var out, errOut bytes.Buffer
	err := run(context.Background(), []string{"-json", "-top", "2"}, strings.NewReader(sample), &out, &errOut)
	if err != nil {
		t.Fatal(err)
	}
	var r Report
	if err := json.Unmarshal(out.Bytes(), &r); err != nil {
		t.Fatal(err)
	}
	if r.Requests != 5 || r.InvalidLines != 1 || r.Slow != 2 {
		t.Errorf("requests=%d invalid=%d slow=%d", r.Requests, r.InvalidLines, r.Slow)
	}
	if r.StatusClass["2xx"] != 4 || r.StatusClass["5xx"] != 1 {
		t.Errorf("status classes = %v", r.StatusClass)
	}
	if len(r.TopPaths) != 2 || r.TopPaths[0].Path != "/api/users" || r.TopPaths[0].Count != 3 {
		t.Errorf("top paths = %+v", r.TopPaths)
	}
	if r.P50 != "120ms" || r.P99 != "2s" {
		t.Errorf("p50=%s p99=%s", r.P50, r.P99)
	}
	if !strings.Contains(errOut.String(), "skipping invalid line") {
		t.Errorf("no warning logged: %q", errOut.String())
	}
}

func TestTimeFilterAndGzip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "access.log.gz")
	var buf bytes.Buffer
	zw := gzip.NewWriter(&buf)
	zw.Write([]byte(sample))
	zw.Close()
	if err := os.WriteFile(path, buf.Bytes(), 0o644); err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	args := []string{"-json", "-from", "2026-11-01T10:00:01Z", "-to", "2026-11-01T10:00:04Z", path}
	if err := run(context.Background(), args, nil, &out, new(bytes.Buffer)); err != nil {
		t.Fatal(err)
	}
	var r Report
	json.Unmarshal(out.Bytes(), &r)
	if r.Requests != 3 { // 10:00:01, :02, :03
		t.Errorf("requests = %d, want 3", r.Requests)
	}
}

func TestBadFlags(t *testing.T) {
	for _, args := range [][]string{{"-top", "0"}, {"-from", "yesterday"}, {"-nosuchflag"}} {
		if err := run(context.Background(), args, strings.NewReader(""), new(bytes.Buffer), new(bytes.Buffer)); err == nil {
			t.Errorf("run(%q) succeeded", args)
		}
	}
}

func BenchmarkScan(b *testing.B) {
	var sb strings.Builder
	for i := range 10_000 {
		fmt.Fprintf(&sb, "2026-11-01T10:%02d:%02dZ GET /p/%d 200 %dms 100\n", i/60%60, i%60, i%50, i%900)
	}
	input := sb.String()
	b.SetBytes(int64(len(input)))
	for b.Loop() {
		if err := run(context.Background(), []string{"-json"}, strings.NewReader(input), new(bytes.Buffer), new(bytes.Buffer)); err != nil {
			b.Fatal(err)
		}
	}
}
