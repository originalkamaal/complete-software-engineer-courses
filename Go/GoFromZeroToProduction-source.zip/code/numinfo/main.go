// Command numinfo prints facts about one integer: its bases, its lowest
// 8 bits read as uint8 and int8, and which integer types can hold it.
package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
)

const usage = "usage: numinfo <integer>"

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(1)
	}
	n, err := strconv.ParseInt(os.Args[1], 10, 64)
	if err != nil {
		fmt.Fprintf(os.Stderr, "numinfo: %q is not a 64-bit integer\n", os.Args[1])
		os.Exit(1)
	}

	switch {
	case n > 0:
		fmt.Printf("%-10s %s\n", "sign:", "positive")
	case n < 0:
		fmt.Printf("%-10s %s\n", "sign:", "negative")
	default:
		fmt.Printf("%-10s %s\n", "sign:", "zero")
	}

	fmt.Printf("%-10s %d\n", "decimal:", n)
	fmt.Printf("%-10s %b\n", "binary:", n)
	fmt.Printf("%-10s %O\n", "octal:", n)
	if n < 0 {
		// uint64(-n) is the correct size even for MinInt64 (DT-70).
		fmt.Printf("%-10s -0x%X\n", "hex:", uint64(-n))
	} else {
		fmt.Printf("%-10s 0x%X\n", "hex:", n)
	}

	low := uint8(n) // keeps only the lowest 8 bits (DT-41)
	fmt.Printf("%-10s %08b\n", "low 8:", low)
	fmt.Printf("%-10s %d\n", "as uint8:", low)
	fmt.Printf("%-10s %d\n", "as int8:", int8(n))

	fmt.Printf("%-10s", "fits:")
	if n >= math.MinInt8 && n <= math.MaxInt8 {
		fmt.Print(" int8")
	}
	if n >= 0 && n <= math.MaxUint8 {
		fmt.Print(" uint8")
	}
	if n >= math.MinInt16 && n <= math.MaxInt16 {
		fmt.Print(" int16")
	}
	if n >= 0 && n <= math.MaxUint16 {
		fmt.Print(" uint16")
	}
	if n >= math.MinInt32 && n <= math.MaxInt32 {
		fmt.Print(" int32")
	}
	if n >= 0 && n <= math.MaxUint32 {
		fmt.Print(" uint32")
	}
	fmt.Print(" int64")
	if n >= 0 {
		fmt.Print(" uint64")
	}
	fmt.Println()
}
