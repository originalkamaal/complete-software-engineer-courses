module numinfo

go 1.24
