package ds

import (
	"math/rand/v2"
	"slices"
	"testing"
)

func TestQueue(t *testing.T) {
	var q Queue[int]
	for i := range 10 {
		q.Push(i)
		if i%3 == 0 {
			q.Pop() // wrap around inside the ring
		}
	}
	var got []int
	for q.Len() > 0 {
		v, _ := q.Pop()
		got = append(got, v)
	}
	if want := []int{4, 5, 6, 7, 8, 9}; !slices.Equal(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
	if _, ok := q.Pop(); ok {
		t.Error("Pop on empty queue reported ok")
	}
}

func TestPQSortsLikeSlicesSort(t *testing.T) {
	r := rand.New(rand.NewPCG(1, 2))
	for trial := range 50 {
		n := r.IntN(200)
		in := make([]int, n)
		pq := NewPQ(func(a, b int) bool { return a < b })
		for i := range in {
			in[i] = r.IntN(50) // duplicates on purpose
			pq.Push(in[i])
		}
		var out []int
		for pq.Len() > 0 {
			v, _ := pq.Pop()
			out = append(out, v)
		}
		slices.Sort(in)
		if !slices.Equal(in, out) {
			t.Fatalf("trial %d: heap order %v, want %v", trial, out, in)
		}
	}
}

func TestLRU(t *testing.T) {
	c := NewLRU[string, int](2)
	c.Put("a", 1)
	c.Put("b", 2)
	c.Get("a")    // a is now most recent
	c.Put("c", 3) // evicts b
	if _, ok := c.Get("b"); ok {
		t.Error("b should have been evicted")
	}
	if v, ok := c.Get("a"); !ok || v != 1 {
		t.Errorf("Get(a) = %v, %v", v, ok)
	}
	c.Put("a", 10) // update, no eviction
	if c.Len() != 2 {
		t.Errorf("Len = %d", c.Len())
	}
	if v, _ := c.Get("a"); v != 10 {
		t.Errorf("updated a = %d", v)
	}
}

func TestUnionFind(t *testing.T) {
	u := NewUnionFind(6)
	u.Union(0, 1)
	u.Union(1, 2)
	u.Union(3, 4)
	if u.Find(0) != u.Find(2) || u.Find(0) == u.Find(3) || u.Union(2, 0) {
		t.Error("wrong partition")
	}
}

func BenchmarkPQ(b *testing.B) {
	r := rand.New(rand.NewPCG(1, 2))
	for b.Loop() {
		pq := NewPQ(func(a, b int) bool { return a < b })
		for range 10_000 {
			pq.Push(r.IntN(1_000_000))
		}
		for pq.Len() > 0 {
			pq.Pop()
		}
	}
}
