// Package ds provides small generic data structures: a ring-buffer
// queue, a binary-heap priority queue, an LRU cache, and union-find.
package ds

// Queue is a FIFO queue backed by a growable ring buffer.
// The zero value is an empty queue ready to use.
type Queue[T any] struct {
	buf        []T
	head, size int
}

func (q *Queue[T]) Len() int { return q.size }

func (q *Queue[T]) Push(v T) {
	if q.size == len(q.buf) {
		q.grow()
	}
	q.buf[(q.head+q.size)%len(q.buf)] = v
	q.size++
}

// Pop removes and returns the oldest element. ok is false if q is empty.
func (q *Queue[T]) Pop() (v T, ok bool) {
	if q.size == 0 {
		return v, false
	}
	v = q.buf[q.head]
	var zero T
	q.buf[q.head] = zero // do not keep a reference for the GC
	q.head = (q.head + 1) % len(q.buf)
	q.size--
	return v, true
}

func (q *Queue[T]) grow() {
	n := max(4, 2*len(q.buf))
	nb := make([]T, n)
	for i := range q.size {
		nb[i] = q.buf[(q.head+i)%len(q.buf)]
	}
	q.buf, q.head = nb, 0
}

// PQ is a priority queue: Pop returns the element for which less
// reports true against all others. Create it with NewPQ.
type PQ[T any] struct {
	items []T
	less  func(a, b T) bool
}

func NewPQ[T any](less func(a, b T) bool) *PQ[T] { return &PQ[T]{less: less} }

func (p *PQ[T]) Len() int { return len(p.items) }

func (p *PQ[T]) Push(v T) {
	p.items = append(p.items, v)
	p.up(len(p.items) - 1)
}

func (p *PQ[T]) Pop() (v T, ok bool) {
	n := len(p.items)
	if n == 0 {
		return v, false
	}
	v = p.items[0]
	p.items[0] = p.items[n-1]
	var zero T
	p.items[n-1] = zero
	p.items = p.items[:n-1]
	if len(p.items) > 0 {
		p.down(0)
	}
	return v, true
}

func (p *PQ[T]) up(i int) {
	for i > 0 {
		parent := (i - 1) / 2
		if !p.less(p.items[i], p.items[parent]) {
			return
		}
		p.items[i], p.items[parent] = p.items[parent], p.items[i]
		i = parent
	}
}

func (p *PQ[T]) down(i int) {
	n := len(p.items)
	for {
		smallest := i
		l, r := 2*i+1, 2*i+2
		if l < n && p.less(p.items[l], p.items[smallest]) {
			smallest = l
		}
		if r < n && p.less(p.items[r], p.items[smallest]) {
			smallest = r
		}
		if smallest == i {
			return
		}
		p.items[i], p.items[smallest] = p.items[smallest], p.items[i]
		i = smallest
	}
}

// LRU is a fixed-capacity cache that evicts the least recently used key.
// Get and Put are O(1): a map finds entries, a doubly linked list keeps
// them in recency order.
type LRU[K comparable, V any] struct {
	cap        int
	items      map[K]*lruNode[K, V]
	head, tail *lruNode[K, V] // head = most recent
}

type lruNode[K comparable, V any] struct {
	key        K
	val        V
	prev, next *lruNode[K, V]
}

func NewLRU[K comparable, V any](capacity int) *LRU[K, V] {
	if capacity < 1 {
		panic("ds: LRU capacity must be at least 1")
	}
	return &LRU[K, V]{cap: capacity, items: make(map[K]*lruNode[K, V], capacity)}
}

func (c *LRU[K, V]) Len() int { return len(c.items) }

func (c *LRU[K, V]) Get(k K) (v V, ok bool) {
	n, ok := c.items[k]
	if !ok {
		return v, false
	}
	c.moveToFront(n)
	return n.val, true
}

func (c *LRU[K, V]) Put(k K, v V) {
	if n, ok := c.items[k]; ok {
		n.val = v
		c.moveToFront(n)
		return
	}
	if len(c.items) == c.cap {
		old := c.tail
		c.unlink(old)
		delete(c.items, old.key)
	}
	n := &lruNode[K, V]{key: k, val: v}
	c.items[k] = n
	c.pushFront(n)
}

func (c *LRU[K, V]) unlink(n *lruNode[K, V]) {
	if n.prev != nil {
		n.prev.next = n.next
	} else {
		c.head = n.next
	}
	if n.next != nil {
		n.next.prev = n.prev
	} else {
		c.tail = n.prev
	}
	n.prev, n.next = nil, nil
}

func (c *LRU[K, V]) pushFront(n *lruNode[K, V]) {
	n.next = c.head
	if c.head != nil {
		c.head.prev = n
	}
	c.head = n
	if c.tail == nil {
		c.tail = n
	}
}

func (c *LRU[K, V]) moveToFront(n *lruNode[K, V]) {
	if c.head == n {
		return
	}
	c.unlink(n)
	c.pushFront(n)
}

// UnionFind tracks a partition of the integers 0..n-1 into sets.
type UnionFind struct {
	parent, size []int
}

func NewUnionFind(n int) *UnionFind {
	u := &UnionFind{parent: make([]int, n), size: make([]int, n)}
	for i := range n {
		u.parent[i], u.size[i] = i, 1
	}
	return u
}

// Find returns the representative of x's set, compressing the path.
func (u *UnionFind) Find(x int) int {
	for u.parent[x] != x {
		u.parent[x] = u.parent[u.parent[x]] // path halving
		x = u.parent[x]
	}
	return x
}

// Union merges the sets of a and b and reports whether they were separate.
func (u *UnionFind) Union(a, b int) bool {
	ra, rb := u.Find(a), u.Find(b)
	if ra == rb {
		return false
	}
	if u.size[ra] < u.size[rb] {
		ra, rb = rb, ra
	}
	u.parent[rb] = ra
	u.size[ra] += u.size[rb]
	return true
}
