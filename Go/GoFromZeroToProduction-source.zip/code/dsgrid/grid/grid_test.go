package grid

import (
	"errors"
	"testing"
)

const city = `
S.....#...
.####.#.#.
.#..9.9.#.
.#.##.#.#.
...#....#E
`

func TestBFSAndDijkstraDiffer(t *testing.T) {
	g, err := Parse(city)
	if err != nil {
		t.Fatal(err)
	}
	bp, err := g.BFS()
	if err != nil {
		t.Fatal(err)
	}
	dp, cost, err := g.Dijkstra()
	if err != nil {
		t.Fatal(err)
	}
	if steps := len(bp) - 1; steps != 17 {
		t.Errorf("BFS steps = %d, want 17", steps)
	}
	if steps := len(dp) - 1; steps != 21 || cost != 21 {
		t.Errorf("Dijkstra steps = %d cost = %d, want 21 and 21", steps, cost)
	}
	// The fewest-steps path goes through a '9' cell, so it costs more.
	if bc := pathCost(g, bp); bc != 25 {
		t.Errorf("BFS path cost = %d, want 25", bc)
	}
}

func pathCost(g *Grid, p []Point) int {
	sum := 0
	for _, pt := range p[1:] {
		sum += g.cost[pt.R*g.cols+pt.C]
	}
	return sum
}

func TestNoPath(t *testing.T) {
	g, err := Parse("S#.\n##E")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := g.BFS(); !errors.Is(err, ErrNoPath) {
		t.Errorf("BFS err = %v", err)
	}
	if _, _, err := g.Dijkstra(); !errors.Is(err, ErrNoPath) {
		t.Errorf("Dijkstra err = %v", err)
	}
}

func TestParseErrors(t *testing.T) {
	for _, bad := range []string{"", "S..\n..", "S.x\n..E", "...\n..E"} {
		if _, err := Parse(bad); err == nil {
			t.Errorf("Parse(%q) succeeded", bad)
		}
	}
}
