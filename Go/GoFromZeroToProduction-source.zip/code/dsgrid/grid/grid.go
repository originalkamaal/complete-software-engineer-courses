// Package grid finds shortest paths on a rectangular city map.
//
// The map is text: '#' is a wall, '.' costs 1 to enter, digits '1'..'9'
// cost that much to enter (slow roads), 'S' is the start and 'E' the end
// (both cost 1). Moves go up, down, left, and right.
package grid

import (
	"errors"
	"fmt"
	"strings"

	"example.com/dsgrid/ds"
)

type Point struct{ R, C int }

type Grid struct {
	rows, cols int
	cost       []int // flat row-major: cost[r*cols+c]; 0 means wall
	Start, End Point
}

var ErrNoPath = errors.New("no path")

// Parse reads a map. Every row must have the same length.
func Parse(text string) (*Grid, error) {
	lines := strings.Fields(text)
	if len(lines) == 0 {
		return nil, errors.New("empty map")
	}
	g := &Grid{rows: len(lines), cols: len(lines[0])}
	g.cost = make([]int, g.rows*g.cols)
	foundS, foundE := false, false
	for r, line := range lines {
		if len(line) != g.cols {
			return nil, fmt.Errorf("row %d has %d cells, want %d", r, len(line), g.cols)
		}
		for c := range len(line) {
			ch := line[c]
			i := r*g.cols + c
			switch {
			case ch == '#':
				g.cost[i] = 0
			case ch == '.':
				g.cost[i] = 1
			case ch >= '1' && ch <= '9':
				g.cost[i] = int(ch - '0')
			case ch == 'S':
				g.cost[i], g.Start, foundS = 1, Point{r, c}, true
			case ch == 'E':
				g.cost[i], g.End, foundE = 1, Point{r, c}, true
			default:
				return nil, fmt.Errorf("row %d col %d: unknown cell %q", r, c, ch)
			}
		}
	}
	if !foundS || !foundE {
		return nil, errors.New("map needs one S and one E")
	}
	return g, nil
}

func (g *Grid) neighbours(p Point, yield func(Point)) {
	for _, d := range [4]Point{{-1, 0}, {1, 0}, {0, -1}, {0, 1}} {
		q := Point{p.R + d.R, p.C + d.C}
		if q.R >= 0 && q.R < g.rows && q.C >= 0 && q.C < g.cols && g.cost[q.R*g.cols+q.C] > 0 {
			yield(q)
		}
	}
}

// BFS returns a path with the fewest steps, ignoring costs.
func (g *Grid) BFS() ([]Point, error) {
	prev := make(map[Point]Point)
	seen := map[Point]bool{g.Start: true}
	var q ds.Queue[Point]
	q.Push(g.Start)
	for q.Len() > 0 {
		p, _ := q.Pop()
		if p == g.End {
			return path(prev, g.Start, g.End), nil
		}
		g.neighbours(p, func(n Point) {
			if !seen[n] {
				seen[n] = true
				prev[n] = p
				q.Push(n)
			}
		})
	}
	return nil, ErrNoPath
}

// Dijkstra returns a cheapest path and its total cost (the cost of every
// cell entered after the start).
func (g *Grid) Dijkstra() ([]Point, int, error) {
	type item struct {
		p    Point
		dist int
	}
	dist := map[Point]int{g.Start: 0}
	prev := make(map[Point]Point)
	pq := ds.NewPQ(func(a, b item) bool { return a.dist < b.dist })
	pq.Push(item{g.Start, 0})
	for pq.Len() > 0 {
		it, _ := pq.Pop()
		if it.dist > dist[it.p] {
			continue // stale entry: a shorter route was found after it was pushed
		}
		if it.p == g.End {
			return path(prev, g.Start, g.End), it.dist, nil
		}
		g.neighbours(it.p, func(n Point) {
			nd := it.dist + g.cost[n.R*g.cols+n.C]
			if old, ok := dist[n]; !ok || nd < old {
				dist[n] = nd
				prev[n] = it.p
				pq.Push(item{n, nd})
			}
		})
	}
	return nil, 0, ErrNoPath
}

func path(prev map[Point]Point, start, end Point) []Point {
	var out []Point
	for p := end; p != start; p = prev[p] {
		out = append(out, p)
	}
	out = append(out, start)
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}

// Draw returns the map with the path marked by '*'.
func (g *Grid) Draw(text string, p []Point) string {
	rows := strings.Fields(text)
	b := make([][]byte, len(rows))
	for i, r := range rows {
		b[i] = []byte(r)
	}
	for _, pt := range p {
		if pt != g.Start && pt != g.End {
			b[pt.R][pt.C] = '*'
		}
	}
	var sb strings.Builder
	for _, r := range b {
		sb.Write(r)
		sb.WriteByte('\n')
	}
	return sb.String()
}
