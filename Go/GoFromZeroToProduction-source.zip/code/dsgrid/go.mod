module example.com/dsgrid

go 1.24
