// Command gridpath reads a city map on stdin and prints the fewest-steps
// path (BFS) and the cheapest path (Dijkstra).
package main

import (
	"fmt"
	"io"
	"os"

	"example.com/dsgrid/grid"
)

func main() {
	data, err := io.ReadAll(io.LimitReader(os.Stdin, 10<<20))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	g, err := grid.Parse(string(data))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	bp, err := g.BFS()
	if err != nil {
		fmt.Fprintln(os.Stderr, "gridpath:", err)
		os.Exit(1)
	}
	dp, cost, _ := g.Dijkstra()
	fmt.Printf("fewest steps (BFS): %d steps\n%s\n", len(bp)-1, g.Draw(string(data), bp))
	fmt.Printf("cheapest (Dijkstra): %d steps, cost %d\n%s", len(dp)-1, cost, g.Draw(string(data), dp))
}
