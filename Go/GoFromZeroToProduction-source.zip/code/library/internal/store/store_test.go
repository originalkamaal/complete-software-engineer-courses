package store

import (
	"os"
	"path/filepath"
	"testing"
	"time"

	"example.com/library/internal/catalog"
)

func TestFileRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "lib.json") // removed automatically after the test
	f, err := OpenFile(path)
	if err != nil {
		t.Fatal(err)
	}
	due := time.Date(2026, 5, 1, 0, 0, 0, 0, time.UTC)
	must(t, f.PutBook(catalog.Book{ID: "b1", Title: "Go", Genre: catalog.Science, Copies: 2}))
	must(t, f.PutMember(catalog.Member{ID: "m1", Name: "Asha"}))
	must(t, f.PutLoans([]catalog.Loan{{BookID: "b1", MemberID: "m1", Due: due}}))

	g, err := OpenFile(path) // a fresh load from disk
	if err != nil {
		t.Fatal(err)
	}
	b, err := g.Book("b1")
	if err != nil || b.Title != "Go" || b.Genre != catalog.Science || b.Copies != 2 {
		t.Errorf("book after reload = %+v, %v", b, err)
	}
	loans, _ := g.Loans()
	if len(loans) != 1 || !loans[0].Due.Equal(due) {
		t.Errorf("loans after reload = %+v", loans)
	}
	if _, err := os.Stat(path + ".tmp"); !os.IsNotExist(err) {
		t.Errorf("temporary file left behind: %v", err)
	}
}

func TestOpenFileCorrupt(t *testing.T) {
	path := filepath.Join(t.TempDir(), "bad.json")
	if err := os.WriteFile(path, []byte("{not json"), 0o644); err != nil {
		t.Fatal(err)
	}
	if _, err := OpenFile(path); err == nil {
		t.Fatal("expected an error for a corrupt file")
	}
}

func TestLoansAreCopies(t *testing.T) {
	m := NewMemory()
	in := []catalog.Loan{{BookID: "b1"}}
	must(t, m.PutLoans(in))
	in[0].BookID = "changed-by-caller"
	out, _ := m.Loans()
	out[0].MemberID = "changed-by-reader"
	again, _ := m.Loans()
	if again[0].BookID != "b1" || again[0].MemberID != "" {
		t.Errorf("store data was modified through a slice: %+v", again[0])
	}
}

func must(t *testing.T, err error) {
	t.Helper() // failures are reported at the caller's line
	if err != nil {
		t.Fatal(err)
	}
}
