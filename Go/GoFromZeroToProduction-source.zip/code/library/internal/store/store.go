// Package store implements catalog.Store in memory and in a JSON file.
package store

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"maps"
	"os"
	"slices"

	"example.com/library/internal/catalog"
)

// Memory keeps everything in maps. Its zero value is NOT ready to use
// (nil maps panic on write), so callers use NewMemory.
type Memory struct {
	books   map[string]catalog.Book
	members map[string]catalog.Member
	loans   []catalog.Loan
}

// Compile-time check that *Memory satisfies catalog.Store.
var _ catalog.Store = (*Memory)(nil)

func NewMemory() *Memory {
	return &Memory{
		books:   make(map[string]catalog.Book),
		members: make(map[string]catalog.Member),
	}
}

func (m *Memory) Book(id string) (catalog.Book, error) {
	b, ok := m.books[id]
	if !ok {
		return catalog.Book{}, fmt.Errorf("book %q: %w", id, catalog.ErrNotFound)
	}
	return b, nil
}

func (m *Memory) PutBook(b catalog.Book) error { m.books[b.ID] = b; return nil }

func (m *Memory) Books() ([]catalog.Book, error) {
	return slices.Collect(maps.Values(m.books)), nil
}

func (m *Memory) Member(id string) (catalog.Member, error) {
	mem, ok := m.members[id]
	if !ok {
		return catalog.Member{}, fmt.Errorf("member %q: %w", id, catalog.ErrNotFound)
	}
	return mem, nil
}

func (m *Memory) PutMember(mem catalog.Member) error { m.members[mem.ID] = mem; return nil }

func (m *Memory) Loans() ([]catalog.Loan, error) { return slices.Clone(m.loans), nil }

func (m *Memory) PutLoans(loans []catalog.Loan) error { m.loans = slices.Clone(loans); return nil }

// File is a Memory that is loaded from and saved to a JSON file.
// Embedding *Memory promotes all of its methods; File overrides the
// three that change data so it can save after each change.
type File struct {
	*Memory
	path string
}

var _ catalog.Store = (*File)(nil)

type fileData struct {
	Books   []catalog.Book   `json:"books"`
	Members []catalog.Member `json:"members"`
	Loans   []catalog.Loan   `json:"loans"`
}

// OpenFile loads path, or starts empty if the file does not exist yet.
func OpenFile(path string) (*File, error) {
	f := &File{Memory: NewMemory(), path: path}
	data, err := os.ReadFile(path)
	if errors.Is(err, fs.ErrNotExist) {
		return f, nil
	}
	if err != nil {
		return nil, err
	}
	var fd fileData
	if err := json.Unmarshal(data, &fd); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	for _, b := range fd.Books {
		f.books[b.ID] = b
	}
	for _, m := range fd.Members {
		f.members[m.ID] = m
	}
	f.loans = fd.Loans
	return f, nil
}

func (f *File) PutBook(b catalog.Book) error     { f.Memory.PutBook(b); return f.save() }
func (f *File) PutMember(m catalog.Member) error { f.Memory.PutMember(m); return f.save() }
func (f *File) PutLoans(l []catalog.Loan) error  { f.Memory.PutLoans(l); return f.save() }

func (f *File) save() error {
	fd := fileData{Loans: f.loans}
	for _, id := range slices.Sorted(maps.Keys(f.books)) {
		fd.Books = append(fd.Books, f.books[id])
	}
	for _, id := range slices.Sorted(maps.Keys(f.members)) {
		fd.Members = append(fd.Members, f.members[id])
	}
	data, err := json.MarshalIndent(fd, "", "  ")
	if err != nil {
		return err
	}
	// Write to a temporary file, then rename: a crash never leaves half a file.
	tmp := f.path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, f.path)
}
