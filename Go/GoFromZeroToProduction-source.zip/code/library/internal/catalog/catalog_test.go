package catalog_test

import (
	"errors"
	"testing"
	"time"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

func newLib(t *testing.T) *catalog.Library {
	t.Helper()
	fixed := time.Date(2026, 1, 1, 10, 0, 0, 0, time.UTC)
	lib := catalog.New(store.NewMemory()).WithClock(func() time.Time { return fixed })
	if err := lib.AddBook(catalog.Book{ID: "b1", Title: "Go", Copies: 1}); err != nil {
		t.Fatal(err)
	}
	if err := lib.AddMember(catalog.Member{ID: "m1", Name: "Asha"}); err != nil {
		t.Fatal(err)
	}
	return lib
}

func TestBorrowAndReturn(t *testing.T) {
	lib := newLib(t)
	due, err := lib.Borrow("b1", "m1")
	if err != nil {
		t.Fatal(err)
	}
	if want := time.Date(2026, 1, 15, 10, 0, 0, 0, time.UTC); !due.Equal(want) {
		t.Errorf("due = %v, want %v", due, want)
	}
	if _, err := lib.Borrow("b1", "m1"); !errors.Is(err, catalog.ErrNoCopies) {
		t.Errorf("second borrow: got %v, want ErrNoCopies", err)
	}
	if err := lib.Return("b1", "m1"); err != nil {
		t.Fatal(err)
	}
	if err := lib.Return("b1", "m1"); !errors.Is(err, catalog.ErrNotBorrowed) {
		t.Errorf("second return: got %v, want ErrNotBorrowed", err)
	}
}

func TestErrors(t *testing.T) {
	lib := newLib(t)
	if _, err := lib.Borrow("nope", "m1"); !errors.Is(err, catalog.ErrNotFound) {
		t.Errorf("unknown book: got %v", err)
	}
	if err := lib.AddBook(catalog.Book{ID: "b1", Title: "Again", Copies: 1}); !errors.Is(err, catalog.ErrAlreadyExists) {
		t.Errorf("duplicate: got %v", err)
	}
	err := lib.AddBook(catalog.Book{ID: "b2", Title: "X", Copies: 0})
	var ve *catalog.ValidationError
	if !errors.As(err, &ve) || ve.Field != "copies" {
		t.Errorf("zero copies: got %v", err)
	}
}

func TestGenre(t *testing.T) {
	if g, err := catalog.ParseGenre("Science"); err != nil || g != catalog.Science {
		t.Errorf("ParseGenre = %v, %v", g, err)
	}
	if s := catalog.Genre(42).String(); s != "Genre(42)" {
		t.Errorf("String() = %q", s)
	}
}
