// Package catalog holds the library's domain rules: books, members, and
// loans. It knows nothing about files or the command line; storage is
// reached through the small Store interface, which this package defines
// because this package is the one that uses it.
package catalog

import (
	"cmp"
	"errors"
	"fmt"
	"slices"
	"strings"
	"time"
)

// Genre is an enum: a named integer type with a fixed set of constants.
type Genre int

const (
	GenreUnknown Genre = iota // zero value means "not set"
	Fiction
	Science
	History
	Children
)

var genreNames = [...]string{"unknown", "fiction", "science", "history", "children"}

func (g Genre) String() string {
	if g < 0 || int(g) >= len(genreNames) {
		return fmt.Sprintf("Genre(%d)", int(g))
	}
	return genreNames[g]
}

// ParseGenre converts a name such as "science" to a Genre.
func ParseGenre(s string) (Genre, error) {
	for i, name := range genreNames {
		if i > 0 && strings.EqualFold(s, name) {
			return Genre(i), nil
		}
	}
	return GenreUnknown, &ValidationError{Field: "genre", Problem: fmt.Sprintf("unknown genre %q", s)}
}

type Book struct {
	ID     string
	Title  string
	Author string
	Genre  Genre
	Copies int // copies owned by the library
}

type Member struct {
	ID   string
	Name string
}

type Loan struct {
	BookID   string
	MemberID string
	Due      time.Time
}

// Sentinel errors: callers compare with errors.Is.
var (
	ErrNotFound      = errors.New("not found")
	ErrAlreadyExists = errors.New("already exists")
	ErrNoCopies      = errors.New("no copies available")
	ErrNotBorrowed   = errors.New("book is not borrowed by this member")
)

// ValidationError is a typed error: callers extract it with errors.As
// (or errors.AsType in Go 1.26+) to learn which field was wrong.
type ValidationError struct {
	Field   string
	Problem string
}

func (e *ValidationError) Error() string { return e.Field + ": " + e.Problem }

// Store is what the catalog needs from storage. Small on purpose.
type Store interface {
	Book(id string) (Book, error) // returns an error wrapping ErrNotFound if missing
	PutBook(b Book) error
	Books() ([]Book, error)
	Member(id string) (Member, error)
	PutMember(m Member) error
	Loans() ([]Loan, error)
	PutLoans(loans []Loan) error
}

// LoanPeriod is how long a member may keep a book.
const LoanPeriod = 14 * 24 * time.Hour

// Library applies the rules. Create it with New.
type Library struct {
	store Store
	now   func() time.Time // replaceable in tests
}

func New(s Store) *Library {
	return &Library{store: s, now: time.Now}
}

// WithClock returns a copy of l that uses now instead of time.Now.
func (l *Library) WithClock(now func() time.Time) *Library {
	c := *l
	c.now = now
	return &c
}

func (l *Library) AddBook(b Book) error {
	b.ID = strings.TrimSpace(b.ID)
	b.Title = strings.TrimSpace(b.Title)
	switch {
	case b.ID == "":
		return &ValidationError{Field: "id", Problem: "must not be empty"}
	case b.Title == "":
		return &ValidationError{Field: "title", Problem: "must not be empty"}
	case b.Copies < 1:
		return &ValidationError{Field: "copies", Problem: fmt.Sprintf("must be at least 1, got %d", b.Copies)}
	}
	if _, err := l.store.Book(b.ID); err == nil {
		return fmt.Errorf("book %q: %w", b.ID, ErrAlreadyExists)
	} else if !errors.Is(err, ErrNotFound) {
		return err
	}
	return l.store.PutBook(b)
}

func (l *Library) AddMember(m Member) error {
	if strings.TrimSpace(m.ID) == "" {
		return &ValidationError{Field: "id", Problem: "must not be empty"}
	}
	if _, err := l.store.Member(m.ID); err == nil {
		return fmt.Errorf("member %q: %w", m.ID, ErrAlreadyExists)
	} else if !errors.Is(err, ErrNotFound) {
		return err
	}
	return l.store.PutMember(m)
}

// Borrow lends one copy of a book to a member and returns the due date.
func (l *Library) Borrow(bookID, memberID string) (time.Time, error) {
	book, err := l.store.Book(bookID)
	if err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	if _, err := l.store.Member(memberID); err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	loans, err := l.store.Loans()
	if err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	if out := countLoans(loans, bookID); out >= book.Copies {
		return time.Time{}, fmt.Errorf("borrow %q: all %d copies are out: %w", bookID, book.Copies, ErrNoCopies)
	}
	due := l.now().Add(LoanPeriod)
	loans = append(loans, Loan{BookID: bookID, MemberID: memberID, Due: due})
	if err := l.store.PutLoans(loans); err != nil {
		return time.Time{}, fmt.Errorf("borrow: %w", err)
	}
	return due, nil
}

// Return ends a member's loan of a book.
func (l *Library) Return(bookID, memberID string) error {
	loans, err := l.store.Loans()
	if err != nil {
		return fmt.Errorf("return: %w", err)
	}
	i := slices.IndexFunc(loans, func(ln Loan) bool {
		return ln.BookID == bookID && ln.MemberID == memberID
	})
	if i < 0 {
		return fmt.Errorf("return %q by %q: %w", bookID, memberID, ErrNotBorrowed)
	}
	return l.store.PutLoans(slices.Delete(loans, i, i+1))
}

// Availability is one line of the catalogue listing.
type Availability struct {
	Book      Book
	Available int
}

// List returns every book with its number of available copies, by title.
func (l *Library) List() ([]Availability, error) {
	books, err := l.store.Books()
	if err != nil {
		return nil, err
	}
	loans, err := l.store.Loans()
	if err != nil {
		return nil, err
	}
	out := make([]Availability, 0, len(books))
	for _, b := range books {
		out = append(out, Availability{Book: b, Available: b.Copies - countLoans(loans, b.ID)})
	}
	slices.SortFunc(out, func(a, b Availability) int {
		return cmp.Or(
			strings.Compare(a.Book.Title, b.Book.Title),
			strings.Compare(a.Book.ID, b.Book.ID),
		)
	})
	return out, nil
}

// Overdue returns the loans whose due date is before now.
func (l *Library) Overdue() ([]Loan, error) {
	loans, err := l.store.Loans()
	if err != nil {
		return nil, err
	}
	now := l.now()
	return slices.DeleteFunc(loans, func(ln Loan) bool { return !ln.Due.Before(now) }), nil
}

func countLoans(loans []Loan, bookID string) int {
	n := 0
	for _, ln := range loans {
		if ln.BookID == bookID {
			n++
		}
	}
	return n
}
