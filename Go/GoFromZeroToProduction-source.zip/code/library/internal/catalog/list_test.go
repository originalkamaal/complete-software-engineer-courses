package catalog_test

import (
	"errors"
	"testing"
	"time"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

// fakeClock is a controllable clock for tests.
type fakeClock struct{ t time.Time }

func (c *fakeClock) Now() time.Time          { return c.t }
func (c *fakeClock) Advance(d time.Duration) { c.t = c.t.Add(d) }

func TestList(t *testing.T) {
	lib := catalog.New(store.NewMemory())
	books := []catalog.Book{
		{ID: "b2", Title: "Zebra", Copies: 2},
		{ID: "b1", Title: "Apple", Copies: 1},
		{ID: "b3", Title: "Apple", Copies: 3},
	}
	for _, b := range books {
		if err := lib.AddBook(b); err != nil {
			t.Fatal(err)
		}
	}
	if err := lib.AddMember(catalog.Member{ID: "m1"}); err != nil {
		t.Fatal(err)
	}
	if _, err := lib.Borrow("b3", "m1"); err != nil {
		t.Fatal(err)
	}

	got, err := lib.List()
	if err != nil {
		t.Fatal(err)
	}
	want := []struct {
		id    string
		avail int
	}{{"b1", 1}, {"b3", 2}, {"b2", 2}} // by title, then ID
	if len(got) != len(want) {
		t.Fatalf("len = %d, want %d", len(got), len(want))
	}
	for i, w := range want {
		if got[i].Book.ID != w.id || got[i].Available != w.avail {
			t.Errorf("row %d = %s/%d, want %s/%d", i, got[i].Book.ID, got[i].Available, w.id, w.avail)
		}
	}
}

func TestOverdue(t *testing.T) {
	clock := &fakeClock{t: time.Date(2026, 3, 1, 9, 0, 0, 0, time.UTC)}
	lib := catalog.New(store.NewMemory()).WithClock(clock.Now)
	for _, err := range []error{
		lib.AddBook(catalog.Book{ID: "b1", Title: "T", Copies: 2}),
		lib.AddMember(catalog.Member{ID: "m1"}),
		lib.AddMember(catalog.Member{ID: "m2"}),
	} {
		if err != nil {
			t.Fatal(err)
		}
	}
	if _, err := lib.Borrow("b1", "m1"); err != nil {
		t.Fatal(err)
	}
	clock.Advance(24 * time.Hour)
	if _, err := lib.Borrow("b1", "m2"); err != nil {
		t.Fatal(err)
	}

	tests := []struct {
		name  string
		after time.Duration // from the first loan
		want  int
	}{
		{"before any due date", 13 * 24 * time.Hour, 0},
		{"exactly at first due date", 14 * 24 * time.Hour, 0}, // due, not yet overdue
		{"just after first due date", 14*24*time.Hour + time.Second, 1},
		{"after both", 16 * 24 * time.Hour, 2},
	}
	start := time.Date(2026, 3, 1, 9, 0, 0, 0, time.UTC)
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			clock.t = start.Add(tt.after)
			got, err := lib.Overdue()
			if err != nil {
				t.Fatal(err)
			}
			if len(got) != tt.want {
				t.Errorf("Overdue() returned %d loans, want %d", len(got), tt.want)
			}
		})
	}
}

func TestAddBookValidation(t *testing.T) {
	tests := []struct {
		name      string
		book      catalog.Book
		wantField string
	}{
		{"empty id", catalog.Book{Title: "T", Copies: 1}, "id"},
		{"blank id", catalog.Book{ID: "  ", Title: "T", Copies: 1}, "id"},
		{"empty title", catalog.Book{ID: "x", Copies: 1}, "title"},
		{"zero copies", catalog.Book{ID: "x", Title: "T"}, "copies"},
		{"negative copies", catalog.Book{ID: "x", Title: "T", Copies: -2}, "copies"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			lib := catalog.New(store.NewMemory())
			err := lib.AddBook(tt.book)
			var ve *catalog.ValidationError
			if !errors.As(err, &ve) {
				t.Fatalf("got %v, want a *ValidationError", err)
			}
			if ve.Field != tt.wantField {
				t.Errorf("field = %q, want %q", ve.Field, tt.wantField)
			}
		})
	}
}

func FuzzParseGenre(f *testing.F) {
	for _, s := range []string{"fiction", "SCIENCE", "", "unknown", "hist ory"} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) {
		g, err := catalog.ParseGenre(s)
		if err != nil {
			if g != catalog.GenreUnknown {
				t.Errorf("error with non-zero genre %v", g)
			}
			return
		}
		// Round trip: the name of a parsed genre parses to the same genre.
		g2, err := catalog.ParseGenre(g.String())
		if err != nil || g2 != g {
			t.Errorf("round trip %q -> %v -> %v, %v", s, g, g2, err)
		}
	})
}

func BenchmarkList(b *testing.B) {
	lib := catalog.New(store.NewMemory())
	_ = lib.AddMember(catalog.Member{ID: "m"})
	for i := range 1000 {
		id := "b" + string(rune('a'+i%26)) + time.Duration(i).String()
		_ = lib.AddBook(catalog.Book{ID: id, Title: id, Copies: 2})
		if i%3 == 0 {
			_, _ = lib.Borrow(id, "m")
		}
	}
	b.ReportAllocs()
	for b.Loop() {
		if _, err := lib.List(); err != nil {
			b.Fatal(err)
		}
	}
}
