package catalog_test

import (
	"errors"
	"strings"
	"testing"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

// failingLoans is a stub: a real in-memory store whose Loans method fails.
// The outer Loans method shadows the promoted one (Unit 3.7).
type failingLoans struct {
	*store.Memory
}

func (failingLoans) Loans() ([]catalog.Loan, error) {
	return nil, errors.New("disk on fire")
}

func TestBorrowStorageError(t *testing.T) {
	mem := store.NewMemory()
	if err := mem.PutBook(catalog.Book{ID: "b1", Title: "T", Copies: 1}); err != nil {
		t.Fatal(err)
	}
	if err := mem.PutMember(catalog.Member{ID: "m1"}); err != nil {
		t.Fatal(err)
	}
	lib := catalog.New(failingLoans{mem})
	_, err := lib.Borrow("b1", "m1")
	if err == nil || !strings.Contains(err.Error(), "disk on fire") {
		t.Fatalf("Borrow error = %v, want the storage error", err)
	}
}
