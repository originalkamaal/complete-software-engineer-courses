package catalog_test

import (
	"testing"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

func TestReturnRemovesTheRightLoan(t *testing.T) {
	lib := catalog.New(store.NewMemory())
	for _, err := range []error{
		lib.AddBook(catalog.Book{ID: "b1", Title: "A", Copies: 1}),
		lib.AddBook(catalog.Book{ID: "b2", Title: "B", Copies: 1}),
		lib.AddMember(catalog.Member{ID: "m1"}),
	} {
		if err != nil {
			t.Fatal(err)
		}
	}
	for _, id := range []string{"b1", "b2"} {
		if _, err := lib.Borrow(id, "m1"); err != nil {
			t.Fatal(err)
		}
	}
	if err := lib.Return("b2", "m1"); err != nil { // return the SECOND loan
		t.Fatal(err)
	}
	items, err := lib.List()
	if err != nil {
		t.Fatal(err)
	}
	for _, it := range items {
		want := map[string]int{"b1": 0, "b2": 1}[it.Book.ID]
		if it.Available != want {
			t.Errorf("%s available = %d, want %d", it.Book.ID, it.Available, want)
		}
	}
}
