package main

import (
	"flag"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

var update = flag.Bool("update", false, "rewrite golden files")

func TestListGolden(t *testing.T) {
	t.Setenv("LIBRARY_DATA", filepath.Join(t.TempDir(), "lib.json"))
	steps := [][]string{
		{"add-book", "b1", "2", "science", "The Go Programming Language"},
		{"add-book", "b2", "1", "fiction", "Malgudi Days"},
		{"add-member", "m1", "Asha"},
		{"borrow", "b2", "m1"},
	}
	for _, args := range steps {
		if err := run(args, new(strings.Builder)); err != nil {
			t.Fatalf("%v: %v", args, err)
		}
	}
	var out strings.Builder
	if err := run([]string{"list"}, &out); err != nil {
		t.Fatal(err)
	}

	golden := filepath.Join("testdata", "list.golden")
	if *update {
		if err := os.WriteFile(golden, []byte(out.String()), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	want, err := os.ReadFile(golden)
	if err != nil {
		t.Fatal(err)
	}
	if out.String() != string(want) {
		t.Errorf("list output differs from %s:\n got: %q\nwant: %q", golden, out.String(), want)
	}
}

func TestUsageErrors(t *testing.T) {
	t.Setenv("LIBRARY_DATA", filepath.Join(t.TempDir(), "lib.json"))
	for _, args := range [][]string{nil, {"fly"}, {"borrow", "only-one"}} {
		err := run(args, new(strings.Builder))
		if err == nil || !strings.Contains(err.Error(), "bad usage") {
			t.Errorf("run(%q) = %v, want a usage error", args, err)
		}
	}
}
