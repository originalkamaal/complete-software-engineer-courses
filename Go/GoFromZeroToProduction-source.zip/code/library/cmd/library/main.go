// Command library manages a small lending library stored in a JSON file.
//
//	library add-book <id> <copies> <genre> <title...>
//	library add-member <id> <name...>
//	library borrow <book-id> <member-id>
//	library return <book-id> <member-id>
//	library list
//	library overdue
//
// The data file is $LIBRARY_DATA, or library.json in the current directory.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"example.com/library/internal/catalog"
	"example.com/library/internal/store"
)

const usage = `usage:
  library add-book <id> <copies> <genre> <title...>
  library add-member <id> <name...>
  library borrow <book-id> <member-id>
  library return <book-id> <member-id>
  library list
  library overdue`

// errUsage marks errors for which the usage text should be printed.
var errUsage = errors.New("bad usage")

func main() {
	err := run(os.Args[1:], os.Stdout)
	if err == nil {
		return
	}
	fmt.Fprintln(os.Stderr, "library:", err)
	if errors.Is(err, errUsage) {
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(2)
	}
	os.Exit(1)
}

func run(args []string, out io.Writer) error {
	if len(args) == 0 {
		return fmt.Errorf("no command: %w", errUsage)
	}
	path := os.Getenv("LIBRARY_DATA")
	if path == "" {
		path = "library.json"
	}
	st, err := store.OpenFile(path)
	if err != nil {
		return err
	}
	lib := catalog.New(st)

	cmd, rest := args[0], args[1:]
	switch cmd {
	case "add-book":
		if len(rest) < 4 {
			return fmt.Errorf("add-book needs 4 or more arguments: %w", errUsage)
		}
		copies, err := strconv.Atoi(rest[1])
		if err != nil {
			return fmt.Errorf("copies %q: %w", rest[1], err)
		}
		genre, err := catalog.ParseGenre(rest[2])
		if err != nil {
			return err
		}
		b := catalog.Book{ID: rest[0], Copies: copies, Genre: genre, Title: strings.Join(rest[3:], " ")}
		if err := lib.AddBook(b); err != nil {
			return err
		}
		fmt.Fprintf(out, "added %s %q\n", b.ID, b.Title)
	case "add-member":
		if len(rest) < 2 {
			return fmt.Errorf("add-member needs 2 or more arguments: %w", errUsage)
		}
		if err := lib.AddMember(catalog.Member{ID: rest[0], Name: strings.Join(rest[1:], " ")}); err != nil {
			return err
		}
		fmt.Fprintf(out, "added member %s\n", rest[0])
	case "borrow":
		if len(rest) != 2 {
			return fmt.Errorf("borrow needs 2 arguments: %w", errUsage)
		}
		due, err := lib.Borrow(rest[0], rest[1])
		if err != nil {
			return err
		}
		fmt.Fprintf(out, "due %s\n", due.Format("2006-01-02"))
	case "return":
		if len(rest) != 2 {
			return fmt.Errorf("return needs 2 arguments: %w", errUsage)
		}
		if err := lib.Return(rest[0], rest[1]); err != nil {
			return err
		}
		fmt.Fprintln(out, "returned")
	case "list":
		items, err := lib.List()
		if err != nil {
			return err
		}
		for _, it := range items {
			fmt.Fprintf(out, "%-6s %-30s %-9s %d/%d available\n",
				it.Book.ID, it.Book.Title, it.Book.Genre, it.Available, it.Book.Copies)
		}
	case "overdue":
		loans, err := lib.Overdue()
		if err != nil {
			return err
		}
		for _, ln := range loans {
			fmt.Fprintf(out, "%s borrowed by %s, due %s\n", ln.BookID, ln.MemberID, ln.Due.Format("2006-01-02"))
		}
	default:
		return fmt.Errorf("unknown command %q: %w", cmd, errUsage)
	}
	return nil
}
