package metrics

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestMiddlewareUsesRoutePattern(t *testing.T) {
	m := NewHTTP()
	mux := http.NewServeMux()
	mux.HandleFunc("GET /{code}", func(w http.ResponseWriter, r *http.Request) {
		if r.PathValue("code") == "missing" {
			http.NotFound(w, r)
		}
	})
	h := m.Middleware(mux)
	for _, path := range []string{"/a", "/b", "/missing"} {
		h.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", path, nil))
	}
	var sb strings.Builder
	m.Write(&sb)
	out := sb.String()
	for _, want := range []string{
		`http_requests_total{method="GET",route="GET /{code}",code="200"} 2`,
		`http_requests_total{method="GET",route="GET /{code}",code="404"} 1`,
		`http_request_duration_seconds_count{method="GET",route="GET /{code}"} 3`,
		`http_request_duration_seconds_bucket{method="GET",route="GET /{code}",le="+Inf"} 3`,
	} {
		if !strings.Contains(out, want) {
			t.Errorf("missing line %s\n--- output:\n%s", want, out)
		}
	}
}
