// Package metrics records HTTP request metrics and writes them in the
// Prometheus text exposition format. A real service would usually use
// github.com/prometheus/client_golang; this small version shows exactly
// what a counter, a histogram, and the format are.
package metrics

import (
	"fmt"
	"io"
	"net/http"
	"runtime/metrics"
	"slices"
	"strconv"
	"sync"
	"time"
)

// Buckets are upper bounds in seconds for request durations.
var Buckets = []float64{0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5}

type key struct{ method, route, code string }

type hist struct {
	counts []uint64 // one per bucket, cumulative at write time
	sum    float64
	count  uint64
}

type HTTP struct {
	mu        sync.Mutex
	requests  map[key]uint64
	durations map[[2]string]*hist // method, route
}

func NewHTTP() *HTTP {
	return &HTTP{requests: map[key]uint64{}, durations: map[[2]string]*hist{}}
}

type recorder struct {
	http.ResponseWriter
	code int
}

func (r *recorder) WriteHeader(c int)           { r.code = c; r.ResponseWriter.WriteHeader(c) }
func (r *recorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }

// Middleware must wrap the router directly so r.Pattern is set; it uses the
// route pattern (bounded set) rather than the raw path (unbounded) as a label.
func (m *HTTP) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &recorder{ResponseWriter: w, code: http.StatusOK}
		next.ServeHTTP(rec, r)
		route := r.Pattern // e.g. "GET /{code}"; set by ServeMux (Go 1.23+)
		if route == "" {
			route = "unmatched"
		}
		m.observe(r.Method, route, rec.code, time.Since(start))
	})
}

func (m *HTTP) observe(method, route string, code int, d time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.requests[key{method, route, strconv.Itoa(code)}]++
	h := m.durations[[2]string{method, route}]
	if h == nil {
		h = &hist{counts: make([]uint64, len(Buckets))}
		m.durations[[2]string{method, route}] = h
	}
	s := d.Seconds()
	for i, b := range Buckets {
		if s <= b {
			h.counts[i]++
		}
	}
	h.sum += s
	h.count++
}

// Write writes all metrics in Prometheus text format, sorted for stable output.
func (m *HTTP) Write(w io.Writer) {
	m.mu.Lock()
	defer m.mu.Unlock()
	fmt.Fprintln(w, "# HELP http_requests_total HTTP requests by method, route, and status code.")
	fmt.Fprintln(w, "# TYPE http_requests_total counter")
	keys := make([]key, 0, len(m.requests))
	for k := range m.requests {
		keys = append(keys, k)
	}
	slices.SortFunc(keys, func(a, b key) int {
		return cmpStr(a.method+a.route+a.code, b.method+b.route+b.code)
	})
	for _, k := range keys {
		fmt.Fprintf(w, "http_requests_total{method=%q,route=%q,code=%q} %d\n", k.method, k.route, k.code, m.requests[k])
	}
	fmt.Fprintln(w, "# HELP http_request_duration_seconds HTTP request latency.")
	fmt.Fprintln(w, "# TYPE http_request_duration_seconds histogram")
	hk := make([][2]string, 0, len(m.durations))
	for k := range m.durations {
		hk = append(hk, k)
	}
	slices.SortFunc(hk, func(a, b [2]string) int { return cmpStr(a[0]+a[1], b[0]+b[1]) })
	for _, k := range hk {
		h := m.durations[k]
		for i, b := range Buckets {
			fmt.Fprintf(w, "http_request_duration_seconds_bucket{method=%q,route=%q,le=%q} %d\n",
				k[0], k[1], strconv.FormatFloat(b, 'g', -1, 64), h.counts[i])
		}
		fmt.Fprintf(w, "http_request_duration_seconds_bucket{method=%q,route=%q,le=\"+Inf\"} %d\n", k[0], k[1], h.count)
		fmt.Fprintf(w, "http_request_duration_seconds_sum{method=%q,route=%q} %g\n", k[0], k[1], h.sum)
		fmt.Fprintf(w, "http_request_duration_seconds_count{method=%q,route=%q} %d\n", k[0], k[1], h.count)
	}
	writeRuntime(w)
}

func cmpStr(a, b string) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func writeRuntime(w io.Writer) {
	s := []metrics.Sample{
		{Name: "/sched/goroutines:goroutines"},
		{Name: "/gc/heap/live:bytes"},
		{Name: "/gc/cycles/total:gc-cycles"},
	}
	metrics.Read(s)
	fmt.Fprintf(w, "# TYPE go_goroutines gauge\ngo_goroutines %d\n", s[0].Value.Uint64())
	fmt.Fprintf(w, "# TYPE go_heap_live_bytes gauge\ngo_heap_live_bytes %d\n", s[1].Value.Uint64())
	fmt.Fprintf(w, "# TYPE go_gc_cycles_total counter\ngo_gc_cycles_total %d\n", s[2].Value.Uint64())
}

// Handler serves the metrics for a Prometheus scraper.
func (m *HTTP) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		m.Write(w)
	})
}
