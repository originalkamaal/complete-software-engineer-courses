// Package config loads the service configuration from the environment,
// validates all of it at startup, and reads secrets from files.
package config

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Addr          string   // public listener
	AdminAddr     string   // metrics, pprof, health: never exposed publicly
	DatabaseURL   string   // secret
	RedisAddr     string   // optional
	APIKeyHashes  []string // hex SHA-256 of valid API keys (secret)
	RatePerSecond float64  // per client IP
	RateBurst     int
	CacheTTL      time.Duration
	ShutdownGrace time.Duration
}

// Load reads configuration using getenv (os.Getenv in production, a map in
// tests). Every problem is reported at once, not one per restart.
func Load(getenv func(string) string) (Config, error) {
	c := Config{
		Addr:          or(getenv("ADDR"), ":8080"),
		AdminAddr:     or(getenv("ADMIN_ADDR"), "127.0.0.1:9090"),
		RedisAddr:     getenv("REDIS_ADDR"),
		RatePerSecond: 20,
		RateBurst:     40,
		CacheTTL:      10 * time.Minute,
		ShutdownGrace: 15 * time.Second,
	}
	var errs []error
	var err error
	if c.DatabaseURL, err = secret(getenv, "DATABASE_URL"); err != nil {
		errs = append(errs, err)
	} else if c.DatabaseURL == "" {
		errs = append(errs, errors.New("DATABASE_URL (or DATABASE_URL_FILE) is required"))
	}
	keys, err := secret(getenv, "API_KEY_HASHES")
	if err != nil {
		errs = append(errs, err)
	}
	for _, h := range strings.Split(keys, ",") {
		if h = strings.TrimSpace(h); h == "" {
			continue
		}
		if len(h) != 64 || strings.Trim(h, "0123456789abcdef") != "" {
			errs = append(errs, fmt.Errorf("API_KEY_HASHES: %q is not a hex SHA-256", h))
			continue
		}
		c.APIKeyHashes = append(c.APIKeyHashes, h)
	}
	if v := getenv("RATE_PER_SECOND"); v != "" {
		if c.RatePerSecond, err = strconv.ParseFloat(v, 64); err != nil || c.RatePerSecond <= 0 {
			errs = append(errs, fmt.Errorf("RATE_PER_SECOND: must be a positive number, got %q", v))
		}
	}
	if v := getenv("RATE_BURST"); v != "" {
		if c.RateBurst, err = strconv.Atoi(v); err != nil || c.RateBurst < 1 {
			errs = append(errs, fmt.Errorf("RATE_BURST: must be a positive integer, got %q", v))
		}
	}
	if v := getenv("CACHE_TTL"); v != "" {
		if c.CacheTTL, err = time.ParseDuration(v); err != nil || c.CacheTTL <= 0 {
			errs = append(errs, fmt.Errorf("CACHE_TTL: must be a positive duration, got %q", v))
		}
	}
	return c, errors.Join(errs...)
}

// secret returns NAME, or the trimmed contents of the file named by
// NAME_FILE. Files work with Docker and Kubernetes secrets and keep
// secrets out of `ps` output and crash dumps of the environment.
func secret(getenv func(string) string, name string) (string, error) {
	v, file := getenv(name), getenv(name+"_FILE")
	if v != "" && file != "" {
		return "", fmt.Errorf("set only one of %s and %s_FILE", name, name)
	}
	if file == "" {
		return v, nil
	}
	b, err := os.ReadFile(file)
	if err != nil {
		return "", fmt.Errorf("%s_FILE: %w", name, err)
	}
	return strings.TrimSpace(string(b)), nil
}

func or(v, def string) string {
	if v == "" {
		return def
	}
	return v
}

// String describes the configuration without secrets, for startup logs.
func (c Config) String() string {
	return fmt.Sprintf("addr=%s admin=%s redis=%t api_keys=%d rate=%.1f/s burst=%d cache_ttl=%s",
		c.Addr, c.AdminAddr, c.RedisAddr != "", len(c.APIKeyHashes), c.RatePerSecond, c.RateBurst, c.CacheTTL)
}
