package config

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func env(m map[string]string) func(string) string { return func(k string) string { return m[k] } }

func TestLoad(t *testing.T) {
	dir := t.TempDir()
	f := filepath.Join(dir, "db")
	os.WriteFile(f, []byte("postgres://secret@db/x\n"), 0o600)
	c, err := Load(env(map[string]string{"DATABASE_URL_FILE": f, "RATE_BURST": "5"}))
	if err != nil {
		t.Fatal(err)
	}
	if c.DatabaseURL != "postgres://secret@db/x" || c.RateBurst != 5 || c.Addr != ":8080" {
		t.Errorf("got %+v", c)
	}
	if strings.Contains(c.String(), "secret") {
		t.Error("String() leaks the database URL")
	}
}

func TestLoadReportsAllErrors(t *testing.T) {
	_, err := Load(env(map[string]string{"RATE_PER_SECOND": "-1", "API_KEY_HASHES": "nothex", "CACHE_TTL": "soon"}))
	if err == nil {
		t.Fatal("expected errors")
	}
	for _, want := range []string{"DATABASE_URL", "RATE_PER_SECOND", "API_KEY_HASHES", "CACHE_TTL"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error does not mention %s:\n%v", want, err)
		}
	}
}
