// Package guard holds HTTP middleware that protects the service:
// API-key authentication, per-client rate limiting, and security headers.
package guard

import (
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"math"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// RequireAPIKey rejects state-changing API requests (POST, PUT, PATCH,
// DELETE under /api/) unless they carry "Authorization: Bearer <key>"
// whose SHA-256 is in hashes. Only hashes are stored, so a leaked config
// does not leak usable keys; comparisons take constant time.
func RequireAPIKey(hashes []string) func(http.Handler) http.Handler {
	want := make([][]byte, 0, len(hashes))
	for _, h := range hashes {
		b, err := hex.DecodeString(h)
		if err == nil && len(b) == sha256.Size {
			want = append(want, b)
		}
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Method == http.MethodGet || r.Method == http.MethodHead || !strings.HasPrefix(r.URL.Path, "/api/") {
				next.ServeHTTP(w, r)
				return
			}
			key, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
			sum := sha256.Sum256([]byte(key))
			valid := false
			for _, h := range want {
				// ConstantTimeCompare: no timing difference reveals how many bytes matched.
				if subtle.ConstantTimeCompare(sum[:], h) == 1 {
					valid = true
				}
			}
			if !ok || !valid {
				w.Header().Set("WWW-Authenticate", `Bearer realm="shortener"`)
				http.Error(w, `{"error":"missing or invalid API key"}`, http.StatusUnauthorized)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

// HashKey returns the hex SHA-256 of an API key, for the config.
func HashKey(key string) string {
	s := sha256.Sum256([]byte(key))
	return hex.EncodeToString(s[:])
}

// Limiter is a token bucket per client: each client may make burst
// requests at once and rate requests per second on average.
type Limiter struct {
	rate    float64
	burst   float64
	now     func() time.Time
	mu      sync.Mutex
	buckets map[string]*bucket
}

type bucket struct {
	tokens float64
	last   time.Time
}

func NewLimiter(rate float64, burst int) *Limiter {
	return &Limiter{rate: rate, burst: float64(burst), now: time.Now, buckets: map[string]*bucket{}}
}

// Allow reports whether the client may make a request now, and if not,
// how long until it may.
func (l *Limiter) Allow(client string) (bool, time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := l.now()
	b, ok := l.buckets[client]
	if !ok {
		b = &bucket{tokens: l.burst, last: now}
		l.buckets[client] = b
	}
	b.tokens = math.Min(l.burst, b.tokens+now.Sub(b.last).Seconds()*l.rate) // refill
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true, 0
	}
	wait := time.Duration((1 - b.tokens) / l.rate * float64(time.Second))
	return false, wait
}

// Sweep removes buckets that are full again (idle clients), bounding memory.
func (l *Limiter) Sweep() {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := l.now()
	for k, b := range l.buckets {
		if b.tokens+now.Sub(b.last).Seconds()*l.rate >= l.burst {
			delete(l.buckets, k)
		}
	}
}

// Middleware rate-limits by client IP. It uses the connection's address:
// trusting X-Forwarded-For is only safe behind a proxy you control that
// overwrites it (see Unit 11.2).
func (l *Limiter) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil {
			ip = r.RemoteAddr
		}
		if ok, wait := l.Allow(ip); !ok {
			w.Header().Set("Retry-After", strconv.Itoa(int(math.Ceil(wait.Seconds()))))
			http.Error(w, `{"error":"too many requests"}`, http.StatusTooManyRequests)
			return
		}
		next.ServeHTTP(w, r)
	})
}

// SecurityHeaders sets conservative headers for an API.
func SecurityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
		h.Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		next.ServeHTTP(w, r)
	})
}
