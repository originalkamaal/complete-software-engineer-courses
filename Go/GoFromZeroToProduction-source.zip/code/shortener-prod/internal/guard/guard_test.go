package guard

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func ok(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) }

func TestRequireAPIKey(t *testing.T) {
	h := RequireAPIKey([]string{HashKey("s3cret-key")})(http.HandlerFunc(ok))
	tests := []struct {
		method, path, auth string
		want               int
	}{
		{"GET", "/abc", "", 204},           // redirects are public
		{"GET", "/api/links/abc", "", 204}, // reads are public
		{"POST", "/api/links", "", 401},    // writes need a key
		{"POST", "/api/links", "Bearer wrong", 401},
		{"POST", "/api/links", "s3cret-key", 401}, // missing "Bearer "
		{"POST", "/api/links", "Bearer s3cret-key", 204},
	}
	for _, tt := range tests {
		req := httptest.NewRequest(tt.method, tt.path, strings.NewReader("{}"))
		if tt.auth != "" {
			req.Header.Set("Authorization", tt.auth)
		}
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, req)
		if rec.Code != tt.want {
			t.Errorf("%s %s auth=%q: %d, want %d", tt.method, tt.path, tt.auth, rec.Code, tt.want)
		}
	}
}

func TestLimiter(t *testing.T) {
	l := NewLimiter(2, 3) // 2 per second, bursts of 3
	now := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	l.now = func() time.Time { return now }
	for i := range 3 {
		if ok, _ := l.Allow("a"); !ok {
			t.Fatalf("request %d of the burst rejected", i+1)
		}
	}
	ok, wait := l.Allow("a")
	if ok || wait != 500*time.Millisecond {
		t.Fatalf("4th request: ok=%v wait=%v, want rejected with 500ms", ok, wait)
	}
	if ok, _ := l.Allow("b"); !ok {
		t.Fatal("another client was limited")
	}
	now = now.Add(500 * time.Millisecond) // one token refilled
	if ok, _ := l.Allow("a"); !ok {
		t.Fatal("not refilled after 500ms")
	}
	now = now.Add(10 * time.Second)
	l.Sweep()
	if len(l.buckets) != 0 {
		t.Errorf("%d idle buckets left after Sweep", len(l.buckets))
	}
}

func TestMiddlewareSetsRetryAfter(t *testing.T) {
	l := NewLimiter(0.5, 1)
	h := l.Middleware(http.HandlerFunc(ok))
	for i, want := range []int{204, 429} {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest("GET", "/x", nil))
		if rec.Code != want {
			t.Fatalf("request %d: %d, want %d", i, rec.Code, want)
		}
		if want == 429 && rec.Header().Get("Retry-After") != "2" {
			t.Errorf("Retry-After = %q, want 2", rec.Header().Get("Retry-After"))
		}
	}
}
