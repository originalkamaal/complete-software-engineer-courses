// Command shortener runs the URL shortener service.
//
// Configuration: see package config. Two listeners: the public API on
// ADDR, and an admin listener on ADMIN_ADDR (metrics, health, pprof) that
// must never be exposed to the internet.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"net/http/pprof"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"

	"example.com/shortener/internal/cache"
	"example.com/shortener/internal/config"
	"example.com/shortener/internal/guard"
	"example.com/shortener/internal/httpapi"
	"example.com/shortener/internal/links"
	"example.com/shortener/internal/metrics"
	"example.com/shortener/internal/pgstore"
)

// Set at build time: go build -ldflags "-X main.version=1.4.2 -X main.commit=$(git rev-parse --short HEAD)"
var (
	version = "dev"
	commit  = "unknown"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil)).With("version", version)
	if err := run(log); err != nil {
		log.Error("shortener stopped", "err", err)
		os.Exit(1)
	}
}

func run(log *slog.Logger) error {
	cfg, err := config.Load(os.Getenv)
	if err != nil {
		return err // every configuration problem, at once
	}
	log.Info("starting", "commit", commit, "config", cfg.String())

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	startCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	db, err := pgstore.Open(startCtx, cfg.DatabaseURL)
	cancel()
	if err != nil {
		return err
	}
	defer db.Close()

	var kv cache.KV = cache.NewMemoryKV()
	if cfg.RedisAddr != "" {
		rdb := redis.NewClient(&redis.Options{Addr: cfg.RedisAddr, DialTimeout: 2 * time.Second,
			ReadTimeout: 200 * time.Millisecond, WriteTimeout: 200 * time.Millisecond})
		defer rdb.Close()
		kv = cache.RedisKV{C: rdb}
	}
	cached := cache.New(pgstore.New(db), kv, cfg.CacheTTL, log)
	bg, stopBG := context.WithCancel(context.Background())
	flushed := make(chan struct{})
	go func() {
		defer close(flushed)
		cached.Run(bg, time.Second)
	}()
	defer func() { stopBG(); <-flushed }()

	limiter := guard.NewLimiter(cfg.RatePerSecond, cfg.RateBurst)
	go func() {
		t := time.NewTicker(time.Minute)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				limiter.Sweep()
			case <-bg.Done():
				return
			}
		}
	}()

	m := metrics.NewHTTP()
	api := httpapi.New(links.NewService(cached), log,
		m.Middleware, // outermost of the extras: counts 401s and 429s too
		guard.SecurityHeaders,
		limiter.Middleware,
		guard.RequireAPIKey(cfg.APIKeyHashes),
	)
	public := &http.Server{Addr: cfg.Addr, Handler: api,
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second,
		WriteTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}

	// Readiness: false until started, and false again as soon as shutdown
	// begins, so the load balancer stops sending traffic before we stop.
	var ready atomic.Bool
	admin := http.NewServeMux()
	admin.Handle("GET /metrics", m.Handler())
	admin.HandleFunc("GET /livez", func(w http.ResponseWriter, _ *http.Request) { w.Write([]byte("ok\n")) })
	admin.HandleFunc("GET /readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), time.Second)
		defer cancel()
		if !ready.Load() {
			http.Error(w, "shutting down or starting", http.StatusServiceUnavailable)
			return
		}
		if err := db.Ping(ctx); err != nil {
			http.Error(w, "database unavailable", http.StatusServiceUnavailable)
			return
		}
		w.Write([]byte("ok\n"))
	})
	admin.HandleFunc("GET /version", func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte(version + " " + commit + "\n"))
	})
	admin.HandleFunc("/debug/pprof/", pprof.Index)
	admin.HandleFunc("/debug/pprof/profile", pprof.Profile)
	admin.HandleFunc("/debug/pprof/trace", pprof.Trace)
	adminSrv := &http.Server{Addr: cfg.AdminAddr, Handler: admin, ReadHeaderTimeout: 5 * time.Second}

	errCh := make(chan error, 2)
	go func() { errCh <- public.ListenAndServe() }()
	go func() { errCh <- adminSrv.ListenAndServe() }()
	ready.Store(true)
	log.Info("listening", "public", cfg.Addr, "admin", cfg.AdminAddr)

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}

	// Graceful shutdown (Unit 11.8): fail readiness, wait for the load
	// balancer to notice, then stop accepting and drain in-flight requests.
	ready.Store(false)
	log.Info("shutdown: readiness failing, draining", "wait", drainWait)
	time.Sleep(drainWait)
	shutCtx, cancel := context.WithTimeout(context.Background(), cfg.ShutdownGrace)
	defer cancel()
	if err := public.Shutdown(shutCtx); err != nil {
		return err
	}
	adminSrv.Shutdown(shutCtx)
	for range 2 {
		if err := <-errCh; !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	}
	log.Info("http servers stopped; flushing hits")
	return nil
}

// drainWait should exceed the load balancer's readiness probe period.
var drainWait = 5 * time.Second
