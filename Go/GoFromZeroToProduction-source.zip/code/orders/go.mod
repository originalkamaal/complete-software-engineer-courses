module example.com/orders

go 1.24

require github.com/jackc/pgx/v5 v5.7.2

require (
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	golang.org/x/crypto v0.31.0 // indirect
	golang.org/x/sync v0.10.0 // indirect
	golang.org/x/text v0.21.0 // indirect
)

replace (
	golang.org/x/crypto => /home/claude/deps/crypto
	golang.org/x/sync => /home/claude/deps/sync
	golang.org/x/text => /home/claude/deps/text
)

replace (
	gopkg.in/check.v1 => /home/claude/deps/check.v1
	gopkg.in/yaml.v3 => /home/claude/deps/yaml.v3
)
