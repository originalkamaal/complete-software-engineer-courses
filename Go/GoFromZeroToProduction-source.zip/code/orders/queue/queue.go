// Package queue is a durable message queue stored in PostgreSQL.
//
// Publishing happens inside the caller's transaction, so a message is
// stored if and only if the business change commits: the transactional
// outbox pattern, with the outbox table serving directly as the queue.
// Delivery is at least once; consumers must be idempotent.
package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand/v2"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const Schema = `
CREATE TABLE IF NOT EXISTS messages (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    topic        text        NOT NULL,
    payload      jsonb       NOT NULL,
    attempts     int         NOT NULL DEFAULT 0,
    available_at timestamptz NOT NULL DEFAULT now(),
    last_error   text
);
CREATE INDEX IF NOT EXISTS messages_ready ON messages (topic, available_at);
CREATE TABLE IF NOT EXISTS dead_letters (
    id       bigint PRIMARY KEY,
    topic    text  NOT NULL,
    payload  jsonb NOT NULL,
    attempts int   NOT NULL,
    error    text  NOT NULL,
    died_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS processed (
    consumer   text   NOT NULL,
    message_id bigint NOT NULL,
    PRIMARY KEY (consumer, message_id)
);`

// Publish stores a message in the caller's transaction.
func Publish(ctx context.Context, tx pgx.Tx, topic string, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	_, err = tx.Exec(ctx, `INSERT INTO messages (topic, payload) VALUES ($1, $2)`, topic, b)
	return err
}

// Message is one delivery. ID is stable across redeliveries.
type Message struct {
	ID       int64
	Topic    string
	Payload  []byte
	Attempts int
}

// Handler processes one message inside tx. Returning nil commits the
// message's removal together with everything the handler wrote in tx.
type Handler func(ctx context.Context, tx pgx.Tx, m Message) error

// ErrPermanent marks failures that retrying cannot fix (bad payload):
// the message goes straight to the dead-letter table.
var ErrPermanent = errors.New("permanent failure")

type Consumer struct {
	DB          *pgxpool.Pool
	Name        string // used for idempotency records
	Topic       string
	Handle      Handler
	MaxAttempts int
	BaseBackoff time.Duration
}

// Run polls for messages until ctx is done.
func (c *Consumer) Run(ctx context.Context) error {
	for {
		n, err := c.ProcessBatch(ctx, 10)
		if err != nil && ctx.Err() == nil {
			return err
		}
		if n == 0 {
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(50 * time.Millisecond):
			}
		}
	}
}

// ProcessBatch claims up to n ready messages and handles each in its own
// transaction. FOR UPDATE SKIP LOCKED lets many consumers work in parallel
// without taking the same message.
func (c *Consumer) ProcessBatch(ctx context.Context, n int) (int, error) {
	done := 0
	for range n {
		ok, err := c.processOne(ctx)
		if err != nil || !ok {
			return done, err
		}
		done++
	}
	return done, nil
}

func (c *Consumer) processOne(ctx context.Context) (bool, error) {
	tx, err := c.DB.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(context.WithoutCancel(ctx))

	var m Message
	err = tx.QueryRow(ctx, `
		SELECT id, topic, payload, attempts FROM messages
		WHERE topic = $1 AND available_at <= now()
		ORDER BY id
		LIMIT 1
		FOR UPDATE SKIP LOCKED`, c.Topic).Scan(&m.ID, &m.Topic, &m.Payload, &m.Attempts)
	if errors.Is(err, pgx.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}

	// Idempotency: if this consumer already processed this message (a
	// previous attempt committed its effects but crashed before the
	// message was deleted), skip the work.
	tag, err := tx.Exec(ctx, `INSERT INTO processed (consumer, message_id) VALUES ($1, $2)
		ON CONFLICT DO NOTHING`, c.Name, m.ID)
	if err != nil {
		return false, err
	}
	if tag.RowsAffected() == 1 {
		// Run the handler in a savepoint so a failure can be recorded
		// without losing the claim on the message.
		herr := pgx.BeginFunc(ctx, tx, func(sp pgx.Tx) error { return c.Handle(ctx, sp, m) })
		if herr != nil {
			if _, err := tx.Exec(ctx, `DELETE FROM processed WHERE consumer = $1 AND message_id = $2`, c.Name, m.ID); err != nil {
				return false, err
			}
			if err := c.fail(ctx, tx, m, herr); err != nil {
				return false, err
			}
			return true, tx.Commit(ctx)
		}
	}
	if _, err := tx.Exec(ctx, `DELETE FROM messages WHERE id = $1`, m.ID); err != nil {
		return false, err
	}
	return true, tx.Commit(ctx)
}

// fail schedules a retry with exponential backoff and full jitter, or
// moves the message to dead_letters.
func (c *Consumer) fail(ctx context.Context, tx pgx.Tx, m Message, herr error) error {
	attempts := m.Attempts + 1
	if attempts >= c.MaxAttempts || errors.Is(herr, ErrPermanent) {
		_, err := tx.Exec(ctx, `
			WITH moved AS (DELETE FROM messages WHERE id = $1 RETURNING id, topic, payload)
			INSERT INTO dead_letters (id, topic, payload, attempts, error)
			SELECT id, topic, payload, $2, $3 FROM moved`, m.ID, attempts, herr.Error())
		return err
	}
	backoff := c.BaseBackoff << (attempts - 1)              // 1x, 2x, 4x, ...
	delay := time.Duration(rand.Int64N(int64(backoff) + 1)) // full jitter: uniform in [0, backoff]
	_, err := tx.Exec(ctx, `UPDATE messages SET attempts = $2, last_error = $3,
		available_at = now() + $4 * interval '1 microsecond' WHERE id = $1`,
		m.ID, attempts, herr.Error(), delay.Microseconds())
	if err != nil {
		return fmt.Errorf("scheduling retry: %w", err)
	}
	return nil
}
