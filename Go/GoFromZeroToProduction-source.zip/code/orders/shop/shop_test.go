package shop

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	mrand "math/rand/v2"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/orders/queue"
)

func newDB(t *testing.T) *pgxpool.Pool {
	t.Helper()
	admin := os.Getenv("TEST_DATABASE_URL")
	if admin == "" {
		t.Skip("TEST_DATABASE_URL not set")
	}
	ctx := context.Background()
	conn, err := pgx.Connect(ctx, admin)
	if err != nil {
		t.Fatal(err)
	}
	name := "test_" + strings.ToLower(rand.Text()[:10])
	if _, err := conn.Exec(ctx, "CREATE DATABASE "+name); err != nil {
		t.Fatal(err)
	}
	cfg, _ := pgxpool.ParseConfig(admin)
	cfg.ConnConfig.Database = name
	cfg.MaxConns = 30
	db, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		t.Fatal(err)
	}
	for _, s := range []string{queue.Schema, Schema} {
		if _, err := db.Exec(ctx, s); err != nil {
			t.Fatal(err)
		}
	}
	t.Cleanup(func() {
		db.Close()
		conn.Exec(ctx, "DROP DATABASE "+name)
		conn.Close(ctx)
	})
	return db
}

// flakyGateway fails transiently 30% of the time, declines orders whose
// amount ends in 13, and remembers keys so a repeated key charges once.
type flakyGateway struct {
	mu      sync.Mutex
	charged map[string]int // key -> number of real charges
	calls   int
	r       *mrand.Rand
}

func (g *flakyGateway) Charge(_ context.Context, key string, amount int64) (bool, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.calls++
	if g.r.IntN(10) < 3 {
		return false, errors.New("gateway timeout")
	}
	if amount%100 == 13 {
		return false, nil
	}
	if g.charged[key] == 0 {
		g.charged[key]++ // the provider deduplicates by idempotency key
	}
	return true, nil
}

// crashAfterEffects simulates a consumer that dies after its handler's
// work but before commit, on the first attempt of every 5th message.
func crashAfterEffects(h queue.Handler) queue.Handler {
	var mu sync.Mutex
	crashed := map[int64]bool{}
	return func(ctx context.Context, tx pgx.Tx, m queue.Message) error {
		if err := h(ctx, tx, m); err != nil {
			return err
		}
		mu.Lock()
		defer mu.Unlock()
		if m.ID%5 == 0 && !crashed[m.ID] {
			crashed[m.ID] = true
			return errors.New("simulated crash before commit")
		}
		return nil
	}
}

func TestPipeline(t *testing.T) {
	db := newDB(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	const n = 100
	for i := range n {
		amount := int64(1000 + i*100)
		if i%10 == 0 {
			amount += 13 // declined
		}
		if err := Place(ctx, db, fmt.Sprintf("o%03d", i), amount); err != nil {
			t.Fatal(err)
		}
	}
	// A poison message: retrying can never fix it.
	pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
		return queue.Publish(ctx, tx, "order.placed", map[string]string{"nonsense": "x"})
	})

	gw := &flakyGateway{charged: map[string]int{}, r: mrand.New(mrand.NewPCG(1, 2))}
	consumers := []*queue.Consumer{
		{Name: "payments", Topic: "order.placed", Handle: crashAfterEffects(PaymentHandler(gw))},
		{Name: "shipping", Topic: "payment.succeeded", Handle: crashAfterEffects(ShippingHandler)},
		{Name: "cancel", Topic: "payment.failed", Handle: CancelHandler},
	}
	var wg sync.WaitGroup
	for _, c := range consumers {
		c.DB, c.MaxAttempts, c.BaseBackoff = db, 8, 5*time.Millisecond
		for range 3 { // three competing workers per topic
			wg.Add(1)
			go func() {
				defer wg.Done()
				if err := c.Run(ctx); err != nil {
					t.Error(err)
				}
			}()
		}
	}

	deadline := time.Now().Add(20 * time.Second)
	for {
		var left int
		db.QueryRow(ctx, `SELECT count(*) FROM messages`).Scan(&left)
		if left == 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("%d messages still queued", left)
		}
		time.Sleep(50 * time.Millisecond)
	}
	cancel()
	wg.Wait()

	counts := map[string]int{}
	rows, _ := db.Query(context.Background(), `SELECT status, count(*) FROM orders GROUP BY status`)
	for rows.Next() {
		var s string
		var c int
		rows.Scan(&s, &c)
		counts[s] = c
	}
	var shipments, dead int
	db.QueryRow(context.Background(), `SELECT count(*) FROM shipments`).Scan(&shipments)
	db.QueryRow(context.Background(), `SELECT count(*) FROM dead_letters`).Scan(&dead)
	t.Logf("orders by status: %v, shipments: %d, dead letters: %d, gateway calls: %d, real charges: %d",
		counts, shipments, dead, gw.calls, len(gw.charged))

	if counts["shipped"] != 90 || counts["cancelled"] != 10 || shipments != 90 {
		t.Errorf("want 90 shipped and 10 cancelled, got %v and %d shipments", counts, shipments)
	}
	for k, c := range gw.charged {
		if c != 1 {
			t.Errorf("%s charged %d times", k, c)
		}
	}
	if len(gw.charged) != 90 || dead != 1 {
		t.Errorf("real charges = %d (want 90), dead letters = %d (want 1)", len(gw.charged), dead)
	}
}
