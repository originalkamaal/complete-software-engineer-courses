// Package shop is a small event-driven order pipeline:
//
//	Place ──order.placed──▶ payment consumer ──payment.succeeded──▶ shipping consumer
//	                                          └─payment.failed────▶ order cancelled (compensation)
package shop

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/orders/queue"
)

const Schema = `
CREATE TABLE IF NOT EXISTS orders (
    id           text PRIMARY KEY,
    amount_paise bigint NOT NULL CHECK (amount_paise > 0),
    status       text   NOT NULL DEFAULT 'placed'
                 CHECK (status IN ('placed', 'paid', 'cancelled', 'shipped'))
);
CREATE TABLE IF NOT EXISTS shipments (
    order_id text PRIMARY KEY REFERENCES orders (id)
);`

type OrderEvent struct {
	OrderID string `json:"order_id"`
	Amount  int64  `json:"amount_paise"`
}

// Place stores the order and its event in ONE transaction: either both
// exist or neither does. No "saved the order but lost the event".
func Place(ctx context.Context, db *pgxpool.Pool, id string, amount int64) error {
	return pgx.BeginFunc(ctx, db, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO orders (id, amount_paise) VALUES ($1, $2)`, id, amount); err != nil {
			return err
		}
		return queue.Publish(ctx, tx, "order.placed", OrderEvent{id, amount})
	})
}

// Gateway is an external payment provider. Charge must be idempotent per
// key: calling it twice with the same key charges once (real providers
// support idempotency keys for exactly this reason).
type Gateway interface {
	Charge(ctx context.Context, idempotencyKey string, amount int64) (approved bool, err error)
}

var ErrDeclined = errors.New("payment declined")

// PaymentHandler charges for an order and publishes the outcome.
func PaymentHandler(gw Gateway) queue.Handler {
	return func(ctx context.Context, tx pgx.Tx, m queue.Message) error {
		var ev OrderEvent
		if err := json.Unmarshal(m.Payload, &ev); err != nil || ev.OrderID == "" {
			return fmt.Errorf("%w: bad payload: %v", queue.ErrPermanent, err)
		}
		// The order ID is the idempotency key: a redelivered message cannot
		// charge the customer twice, even though the gateway is outside our
		// database transaction.
		approved, err := gw.Charge(ctx, "order-"+ev.OrderID, ev.Amount)
		if err != nil {
			return err // transient: retried with backoff
		}
		if !approved {
			return queue.Publish(ctx, tx, "payment.failed", ev)
		}
		if _, err := tx.Exec(ctx, `UPDATE orders SET status = 'paid' WHERE id = $1 AND status = 'placed'`, ev.OrderID); err != nil {
			return err
		}
		return queue.Publish(ctx, tx, "payment.succeeded", ev)
	}
}

// ShippingHandler creates exactly one shipment per paid order.
func ShippingHandler(ctx context.Context, tx pgx.Tx, m queue.Message) error {
	var ev OrderEvent
	if err := json.Unmarshal(m.Payload, &ev); err != nil {
		return fmt.Errorf("%w: %v", queue.ErrPermanent, err)
	}
	if _, err := tx.Exec(ctx, `INSERT INTO shipments (order_id) VALUES ($1) ON CONFLICT DO NOTHING`, ev.OrderID); err != nil {
		return err
	}
	_, err := tx.Exec(ctx, `UPDATE orders SET status = 'shipped' WHERE id = $1 AND status = 'paid'`, ev.OrderID)
	return err
}

// CancelHandler is the saga's compensating action for a failed payment.
func CancelHandler(ctx context.Context, tx pgx.Tx, m queue.Message) error {
	var ev OrderEvent
	if err := json.Unmarshal(m.Payload, &ev); err != nil {
		return fmt.Errorf("%w: %v", queue.ErrPermanent, err)
	}
	_, err := tx.Exec(ctx, `UPDATE orders SET status = 'cancelled' WHERE id = $1 AND status = 'placed'`, ev.OrderID)
	return err
}
