// Command shortener runs the URL shortener HTTP service.
//
// Configuration comes from the environment:
//
//	DATABASE_URL  PostgreSQL connection string (required)
//	REDIS_ADDR    Redis address, e.g. localhost:6379 (optional; in-process cache if empty)
//	ADDR          listen address (default :8080)
package main

import (
	"cmp"
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"

	"example.com/shortener/internal/cache"
	"example.com/shortener/internal/httpapi"
	"example.com/shortener/internal/links"
	"example.com/shortener/internal/pgstore"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stderr, nil))
	if err := run(log); err != nil {
		log.Error("shortener stopped", "err", err)
		os.Exit(1)
	}
}

func run(log *slog.Logger) error {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		return errors.New("DATABASE_URL is required")
	}
	startCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	db, err := pgstore.Open(startCtx, dsn)
	cancel()
	if err != nil {
		return err
	}
	defer db.Close()

	var kv cache.KV = cache.NewMemoryKV()
	if addr := os.Getenv("REDIS_ADDR"); addr != "" {
		rdb := redis.NewClient(&redis.Options{Addr: addr, DialTimeout: 2 * time.Second,
			ReadTimeout: 200 * time.Millisecond, WriteTimeout: 200 * time.Millisecond})
		defer rdb.Close()
		kv = cache.RedisKV{C: rdb}
	}
	cached := cache.New(pgstore.New(db), kv, 10*time.Minute, log)
	flushCtx, stopFlush := context.WithCancel(context.Background())
	flushed := make(chan struct{})
	go func() {
		defer close(flushed)
		cached.Run(flushCtx, time.Second)
	}()
	// Runs last (defers are LIFO): after the HTTP server has stopped, stop the
	// flusher, which writes the remaining hits, and wait for it.
	defer func() {
		stopFlush()
		<-flushed
	}()

	srv := &http.Server{
		Addr:              cmp.Or(os.Getenv("ADDR"), ":8080"),
		Handler:           httpapi.New(links.NewService(cached), log),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() {
		log.Info("listening", "addr", srv.Addr)
		errCh <- srv.ListenAndServe()
	}()
	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}
	log.Info("shutting down")
	shutdownCtx, cancel2 := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel2()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		return err
	}
	log.Info("http server stopped; flushing hits")
	return nil
}
