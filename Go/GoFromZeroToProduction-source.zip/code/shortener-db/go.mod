module example.com/shortener

go 1.24

require (
	github.com/jackc/pgx/v5 v5.7.2
	github.com/redis/go-redis/v9 v9.7.0
	golang.org/x/sync v0.10.0
)

require (
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	golang.org/x/crypto v0.31.0 // indirect
	golang.org/x/text v0.21.0 // indirect
)

replace (
	golang.org/x/crypto => /home/claude/deps/crypto
	golang.org/x/sync => /home/claude/deps/sync
	golang.org/x/text => /home/claude/deps/text
)

replace (
	gopkg.in/check.v1 => /home/claude/deps/check.v1
	gopkg.in/yaml.v3 => /home/claude/deps/yaml.v3
)
