package pgstore

import (
	"context"
	"crypto/rand"
	"errors"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/shortener/internal/links"
)

// newDB creates a fresh, migrated database for one test and drops it after.
// It needs TEST_DATABASE_URL pointing at a server where the user may create
// databases, e.g. postgres://postgres@localhost/postgres.
func newDB(t *testing.T) *pgxpool.Pool {
	t.Helper()
	admin := os.Getenv("TEST_DATABASE_URL")
	if admin == "" {
		t.Skip("TEST_DATABASE_URL not set; skipping PostgreSQL integration test")
	}
	ctx := context.Background()
	conn, err := pgx.Connect(ctx, admin)
	if err != nil {
		t.Fatal(err)
	}
	name := "test_" + strings.ToLower(rand.Text()[:10])
	if _, err := conn.Exec(ctx, "CREATE DATABASE "+name); err != nil {
		t.Fatal(err)
	}
	cfg, _ := pgx.ParseConfig(admin)
	cfg.Database = name
	db, err := Open(ctx, cfg.ConnString())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		db.Close()
		conn.Exec(ctx, "DROP DATABASE "+name)
		conn.Close(ctx)
	})
	return db
}

func TestStore(t *testing.T) {
	db := newDB(t)
	s := New(db)
	s.now = func() time.Time { return time.Date(2026, 11, 15, 10, 0, 0, 0, time.UTC) }
	ctx := context.Background()

	l := links.Link{Code: "godocs", URL: "https://go.dev/doc/", CreatedAt: s.now()}
	if err := s.Create(ctx, l); err != nil {
		t.Fatal(err)
	}
	if err := s.Create(ctx, l); !errors.Is(err, links.ErrCodeTaken) {
		t.Fatalf("duplicate: %v", err)
	}
	for range 3 {
		if url, err := s.Hit(ctx, "godocs"); err != nil || url != l.URL {
			t.Fatalf("Hit = %q, %v", url, err)
		}
	}
	if _, err := s.Hit(ctx, "nope"); !errors.Is(err, links.ErrNotFound) {
		t.Fatalf("unknown: %v", err)
	}
	if err := s.AddHits(ctx, map[string]int64{"godocs": 10, "ghost": 5}); err != nil {
		t.Fatal(err)
	}
	got, err := s.Get(ctx, "godocs")
	if err != nil || got.Hits != 13 {
		t.Fatalf("Get = %+v, %v; want 13 hits", got, err)
	}
	days, err := s.Daily(ctx, "godocs", 3)
	if err != nil {
		t.Fatal(err)
	}
	want := []links.DayCount{{Day: "2026-11-13"}, {Day: "2026-11-14"}, {Day: "2026-11-15", Hits: 13}}
	if len(days) != 3 || days[0] != want[0] || days[2] != want[2] {
		t.Errorf("Daily = %+v, want %+v", days, want)
	}
}

func TestMigrateIsIdempotent(t *testing.T) {
	db := newDB(t) // already migrated once by Open
	if err := Migrate(context.Background(), db); err != nil {
		t.Fatalf("second migration run: %v", err)
	}
}
