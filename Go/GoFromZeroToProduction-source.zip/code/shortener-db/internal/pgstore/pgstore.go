// Package pgstore stores links in PostgreSQL.
package pgstore

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"example.com/shortener/internal/links"
)

type Store struct {
	db  *pgxpool.Pool
	now func() time.Time
}

var (
	_ links.Store        = (*Store)(nil)
	_ links.DailyCounter = (*Store)(nil)
)

func New(db *pgxpool.Pool) *Store { return &Store{db: db, now: time.Now} }

// Open connects, checks the connection, and applies migrations.
func Open(ctx context.Context, dsn string) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, err
	}
	cfg.MaxConns = 20
	cfg.MaxConnIdleTime = 5 * time.Minute
	db, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, err
	}
	if err := db.Ping(ctx); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping database: %w", err)
	}
	if err := Migrate(ctx, db); err != nil {
		db.Close()
		return nil, err
	}
	return db, nil
}

const uniqueViolation = "23505"

func (s *Store) Create(ctx context.Context, l links.Link) error {
	_, err := s.db.Exec(ctx,
		`INSERT INTO links (code, url, created_at) VALUES ($1, $2, $3)`,
		l.Code, l.URL, l.CreatedAt)
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == uniqueViolation {
		return links.ErrCodeTaken // the database enforces uniqueness, even across instances
	}
	return err
}

func (s *Store) Get(ctx context.Context, code string) (links.Link, error) {
	var l links.Link
	err := s.db.QueryRow(ctx,
		`SELECT code, url, created_at, hits FROM links WHERE code = $1`, code,
	).Scan(&l.Code, &l.URL, &l.CreatedAt, &l.Hits)
	if errors.Is(err, pgx.ErrNoRows) {
		return links.Link{}, links.ErrNotFound
	}
	return l, err
}

// Hit counts one visit and returns the URL: two writes in one transaction.
func (s *Store) Hit(ctx context.Context, code string) (string, error) {
	var url string
	err := pgx.BeginFunc(ctx, s.db, func(tx pgx.Tx) error {
		err := tx.QueryRow(ctx,
			`UPDATE links SET hits = hits + 1 WHERE code = $1 RETURNING url`, code).Scan(&url)
		if errors.Is(err, pgx.ErrNoRows) {
			return links.ErrNotFound
		}
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `
			INSERT INTO daily_hits (code, day, hits) VALUES ($1, $2, 1)
			ON CONFLICT (code, day) DO UPDATE SET hits = daily_hits.hits + 1`,
			code, s.now().UTC().Format(time.DateOnly))
		return err
	})
	return url, err
}

// AddHits applies many counted hits at once: one round trip and one
// transaction for a whole batch (used by the cache's flusher).
func (s *Store) AddHits(ctx context.Context, hits map[string]int64) error {
	if len(hits) == 0 {
		return nil
	}
	codes := make([]string, 0, len(hits))
	counts := make([]int64, 0, len(hits))
	for c, n := range hits {
		codes = append(codes, c)
		counts = append(counts, n)
	}
	day := s.now().UTC().Format(time.DateOnly)
	return pgx.BeginFunc(ctx, s.db, func(tx pgx.Tx) error {
		_, err := tx.Exec(ctx, `
			UPDATE links SET hits = links.hits + b.n
			FROM unnest($1::text[], $2::bigint[]) AS b(code, n)
			WHERE links.code = b.code`, codes, counts)
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `
			INSERT INTO daily_hits (code, day, hits)
			SELECT b.code, $3::date, b.n
			FROM unnest($1::text[], $2::bigint[]) AS b(code, n)
			WHERE EXISTS (SELECT 1 FROM links WHERE links.code = b.code)
			ON CONFLICT (code, day) DO UPDATE SET hits = daily_hits.hits + EXCLUDED.hits`,
			codes, counts, day)
		return err
	})
}

// Daily returns hits per day for the last `days` days, oldest first,
// including days with zero hits.
func (s *Store) Daily(ctx context.Context, code string, days int) ([]links.DayCount, error) {
	if _, err := s.Get(ctx, code); err != nil {
		return nil, err
	}
	today := s.now().UTC().Truncate(24 * time.Hour)
	rows, err := s.db.Query(ctx, `
		SELECT d::date, coalesce(h.hits, 0)
		FROM generate_series($2::date - ($3::int - 1), $2::date, interval '1 day') AS d
		LEFT JOIN daily_hits h ON h.code = $1 AND h.day = d::date
		ORDER BY d`, code, today, days)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, func(r pgx.CollectableRow) (links.DayCount, error) {
		var dc links.DayCount
		var day time.Time
		err := r.Scan(&day, &dc.Hits)
		dc.Day = day.Format(time.DateOnly)
		return dc, err
	})
}
