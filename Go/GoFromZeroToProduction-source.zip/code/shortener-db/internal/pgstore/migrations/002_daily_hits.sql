-- One row per link per day: small, and fast to aggregate.
CREATE TABLE daily_hits (
    code text   NOT NULL REFERENCES links (code) ON DELETE CASCADE,
    day  date   NOT NULL,
    hits bigint NOT NULL CHECK (hits > 0),
    PRIMARY KEY (code, day)
);
