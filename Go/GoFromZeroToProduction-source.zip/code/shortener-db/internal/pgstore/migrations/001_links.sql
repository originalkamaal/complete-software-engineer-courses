CREATE TABLE links (
    code       text        PRIMARY KEY,
    url        text        NOT NULL CHECK (length(url) <= 2048),
    created_at timestamptz NOT NULL DEFAULT now(),
    hits       bigint      NOT NULL DEFAULT 0 CHECK (hits >= 0)
);
