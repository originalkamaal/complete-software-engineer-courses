package cache

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"example.com/shortener/internal/links"
)

// slowBackend is an in-memory backend whose Get is slow and counted.
type slowBackend struct {
	*links.Memory
	gets  atomic.Int64
	mu    sync.Mutex
	added map[string]int64
	fail  bool
}

func (b *slowBackend) Get(ctx context.Context, code string) (links.Link, error) {
	b.gets.Add(1)
	time.Sleep(20 * time.Millisecond)
	return b.Memory.Get(ctx, code)
}

func (b *slowBackend) AddHits(_ context.Context, hits map[string]int64) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.fail {
		return errors.New("database down")
	}
	for k, n := range hits {
		b.added[k] += n
	}
	return nil
}

func setup(t *testing.T) (*Links, *slowBackend) {
	t.Helper()
	b := &slowBackend{Memory: links.NewMemory(), added: map[string]int64{}}
	if err := b.Memory.Create(context.Background(), links.Link{Code: "go", URL: "https://go.dev"}); err != nil {
		t.Fatal(err)
	}
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	return New(b, NewMemoryKV(), time.Minute, log), b
}

func TestStampedeProtectionAndBatching(t *testing.T) {
	c, b := setup(t)
	ctx := context.Background()
	var wg sync.WaitGroup
	for range 100 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if url, err := c.Hit(ctx, "go"); err != nil || url != "https://go.dev" {
				t.Errorf("Hit = %q, %v", url, err)
			}
		}()
	}
	wg.Wait()
	if n := b.gets.Load(); n != 1 {
		t.Errorf("100 concurrent cold hits caused %d backend reads, want 1", n)
	}
	if err := c.Flush(ctx); err != nil {
		t.Fatal(err)
	}
	if b.added["go"] != 100 {
		t.Errorf("flushed %d hits, want 100", b.added["go"])
	}
}

func TestNegativeCaching(t *testing.T) {
	c, b := setup(t)
	for range 5 {
		if _, err := c.Hit(context.Background(), "nope"); !errors.Is(err, links.ErrNotFound) {
			t.Fatalf("err = %v", err)
		}
	}
	if n := b.gets.Load(); n != 1 {
		t.Errorf("5 misses for an unknown code caused %d backend reads, want 1", n)
	}
}

func TestFailedFlushKeepsHits(t *testing.T) {
	c, b := setup(t)
	ctx := context.Background()
	c.Hit(ctx, "go")
	c.Hit(ctx, "go")
	b.fail = true
	if err := c.Flush(ctx); err == nil {
		t.Fatal("expected flush error")
	}
	b.fail = false
	c.Hit(ctx, "go")
	if err := c.Flush(ctx); err != nil {
		t.Fatal(err)
	}
	if b.added["go"] != 3 {
		t.Errorf("hits after retry = %d, want 3", b.added["go"])
	}
}
