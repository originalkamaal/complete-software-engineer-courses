package cache

import (
	"context"
	"errors"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"
)

// RedisKV adapts a go-redis client to KV.
type RedisKV struct{ C *redis.Client }

func (r RedisKV) Get(ctx context.Context, key string) (string, bool, error) {
	v, err := r.C.Get(ctx, key).Result()
	if errors.Is(err, redis.Nil) {
		return "", false, nil
	}
	if err != nil {
		return "", false, err
	}
	return v, true, nil
}

func (r RedisKV) Set(ctx context.Context, key, value string, ttl time.Duration) error {
	return r.C.Set(ctx, key, value, ttl).Err()
}

// MemoryKV is an in-process KV with expiry, for tests and single-instance use.
type MemoryKV struct {
	mu  sync.Mutex
	m   map[string]memEntry
	now func() time.Time
}

type memEntry struct {
	v   string
	exp time.Time
}

func NewMemoryKV() *MemoryKV { return &MemoryKV{m: map[string]memEntry{}, now: time.Now} }

func (k *MemoryKV) Get(_ context.Context, key string) (string, bool, error) {
	k.mu.Lock()
	defer k.mu.Unlock()
	e, ok := k.m[key]
	if !ok || k.now().After(e.exp) {
		return "", false, nil
	}
	return e.v, true, nil
}

func (k *MemoryKV) Set(_ context.Context, key, value string, ttl time.Duration) error {
	k.mu.Lock()
	defer k.mu.Unlock()
	k.m[key] = memEntry{value, k.now().Add(ttl)}
	return nil
}
