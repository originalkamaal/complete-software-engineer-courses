// Package cache puts a cache-aside layer in front of a links.Store.
//
// Redirects are the hot path. Cached links skip the database read, and
// hits are counted in memory and written to the store in batches, so a
// redirect usually costs one cache lookup and no database work at all.
// The price: hit counts reach the database up to one flush interval late,
// and a crash loses at most that interval's counts.
package cache

import (
	"context"
	"errors"
	"log/slog"
	"sync"
	"time"

	"golang.org/x/sync/singleflight"

	"example.com/shortener/internal/links"
)

// KV is the small part of a key-value cache (such as Redis) that we use.
type KV interface {
	Get(ctx context.Context, key string) (value string, found bool, err error)
	Set(ctx context.Context, key, value string, ttl time.Duration) error
}

// Backend is a store that can also apply hits in batches.
type Backend interface {
	links.Store
	AddHits(ctx context.Context, hits map[string]int64) error
}

const notFound = "\x00" // cached marker for "no such code" (negative caching)

type Links struct {
	backend Backend
	kv      KV
	ttl     time.Duration
	negTTL  time.Duration
	log     *slog.Logger
	group   singleflight.Group
	mu      sync.Mutex
	pending map[string]int64 // hits not yet written to the backend
}

func New(backend Backend, kv KV, ttl time.Duration, log *slog.Logger) *Links {
	return &Links{backend: backend, kv: kv, ttl: ttl, negTTL: 30 * time.Second,
		log: log, pending: make(map[string]int64)}
}

var _ links.Store = (*Links)(nil)

func key(code string) string { return "link:" + code }

func (c *Links) Create(ctx context.Context, l links.Link) error {
	if err := c.backend.Create(ctx, l); err != nil {
		return err
	}
	// Overwrite any cached "not found" marker for this code.
	if err := c.kv.Set(ctx, key(l.Code), l.URL, c.ttl); err != nil {
		c.log.WarnContext(ctx, "cache set failed", "err", err)
	}
	return nil
}

// Get is not cached: stats should be as fresh as the database, plus the
// hits still waiting in memory.
func (c *Links) Get(ctx context.Context, code string) (links.Link, error) {
	l, err := c.backend.Get(ctx, code)
	if err != nil {
		return l, err
	}
	c.mu.Lock()
	l.Hits += c.pending[code]
	c.mu.Unlock()
	return l, nil
}

// Daily passes the optional capability through. Without this method the
// decorator would hide it (P-24's trade-off) and the endpoint would 501.
func (c *Links) Daily(ctx context.Context, code string, days int) ([]links.DayCount, error) {
	dc, ok := c.backend.(links.DailyCounter)
	if !ok {
		return nil, links.ErrUnsupported
	}
	if err := c.Flush(ctx); err != nil { // include recent hits
		return nil, err
	}
	return dc.Daily(ctx, code, days)
}

func (c *Links) Hit(ctx context.Context, code string) (string, error) {
	url, err := c.lookup(ctx, code)
	if err != nil {
		return "", err
	}
	c.mu.Lock()
	c.pending[code]++
	c.mu.Unlock()
	return url, nil
}

// lookup is cache-aside: try the cache, else load from the backend and fill
// the cache. singleflight makes concurrent misses for one code share a single
// backend call, so a popular link expiring cannot stampede the database.
func (c *Links) lookup(ctx context.Context, code string) (string, error) {
	v, found, err := c.kv.Get(ctx, key(code))
	if err != nil {
		c.log.WarnContext(ctx, "cache get failed; using database", "err", err)
	} else if found {
		if v == notFound {
			return "", links.ErrNotFound
		}
		return v, nil
	}
	res, err, _ := c.group.Do(code, func() (any, error) {
		l, err := c.backend.Get(ctx, code)
		switch {
		case errors.Is(err, links.ErrNotFound):
			c.kv.Set(ctx, key(code), notFound, c.negTTL)
			return "", err
		case err != nil:
			return "", err
		}
		if err := c.kv.Set(ctx, key(code), l.URL, c.ttl); err != nil {
			c.log.WarnContext(ctx, "cache set failed", "err", err)
		}
		return l.URL, nil
	})
	if err != nil {
		return "", err
	}
	return res.(string), nil
}

// Flush writes pending hits to the backend. On failure the hits are put
// back, so they are retried at the next flush.
func (c *Links) Flush(ctx context.Context) error {
	c.mu.Lock()
	batch := c.pending
	c.pending = make(map[string]int64)
	c.mu.Unlock()
	if len(batch) == 0 {
		return nil
	}
	if err := c.backend.AddHits(ctx, batch); err != nil {
		c.mu.Lock()
		for k, n := range batch {
			c.pending[k] += n
		}
		c.mu.Unlock()
		return err
	}
	return nil
}

// Run flushes every interval until ctx is done, then flushes once more.
func (c *Links) Run(ctx context.Context, interval time.Duration) {
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			if err := c.Flush(ctx); err != nil {
				c.log.ErrorContext(ctx, "flushing hits", "err", err)
			}
		case <-ctx.Done():
			final, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
			if err := c.Flush(final); err != nil {
				c.log.Error("final flush", "err", err)
			}
			cancel()
			return
		}
	}
}
