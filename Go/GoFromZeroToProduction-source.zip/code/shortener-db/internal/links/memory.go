package links

import (
	"context"
	"sync"
)

// Memory is an in-memory Store, safe for concurrent use.
type Memory struct {
	mu    sync.RWMutex
	links map[string]Link
}

var _ Store = (*Memory)(nil)

func NewMemory() *Memory { return &Memory{links: make(map[string]Link)} }

func (m *Memory) Create(_ context.Context, l Link) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.links[l.Code]; ok {
		return ErrCodeTaken
	}
	m.links[l.Code] = l
	return nil
}

func (m *Memory) Get(_ context.Context, code string) (Link, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	l, ok := m.links[code]
	if !ok {
		return Link{}, ErrNotFound
	}
	return l, nil
}

func (m *Memory) Hit(_ context.Context, code string) (string, error) {
	m.mu.Lock() // a write: the hit counter changes
	defer m.mu.Unlock()
	l, ok := m.links[code]
	if !ok {
		return "", ErrNotFound
	}
	l.Hits++
	m.links[code] = l
	return l.URL, nil
}
