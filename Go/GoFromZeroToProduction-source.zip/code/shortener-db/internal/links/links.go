// Package links holds the URL shortener's rules: validating URLs,
// generating short codes, and resolving them. Storage is behind Store.
package links

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"time"
)

type Link struct {
	Code      string    `json:"code"`
	URL       string    `json:"url"`
	CreatedAt time.Time `json:"created_at"`
	Hits      int64     `json:"hits"`
}

var (
	ErrNotFound  = errors.New("link not found")
	ErrCodeTaken = errors.New("code already in use")
)

// InvalidError reports bad input; the HTTP layer maps it to 400.
type InvalidError struct{ Reason string }

func (e *InvalidError) Error() string { return "invalid input: " + e.Reason }

// Store is what the service needs from storage.
type Store interface {
	// Create saves l, or returns ErrCodeTaken if l.Code exists.
	Create(ctx context.Context, l Link) error
	// Get returns the link, or ErrNotFound.
	Get(ctx context.Context, code string) (Link, error)
	// Hit increments the hit counter and returns the target URL, or ErrNotFound.
	Hit(ctx context.Context, code string) (string, error)
}

type Service struct {
	store Store
	now   func() time.Time
}

func NewService(s Store) *Service { return &Service{store: s, now: time.Now} }

var codeRE = regexp.MustCompile(`^[A-Za-z0-9_-]{3,32}$`)

const (
	alphabet  = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O, 1/l/I
	genLength = 7
	maxURLLen = 2048
)

// Shorten stores rawURL under code, or under a generated code if code is "".
func (s *Service) Shorten(ctx context.Context, rawURL, code string) (Link, error) {
	if err := validateURL(rawURL); err != nil {
		return Link{}, err
	}
	if code != "" {
		if !codeRE.MatchString(code) {
			return Link{}, &InvalidError{"code must be 3-32 letters, digits, '-' or '_'"}
		}
		l := Link{Code: code, URL: rawURL, CreatedAt: s.now().UTC()}
		return l, s.store.Create(ctx, l)
	}
	// Random codes can collide; with 56^7 ≈ 1.7e12 codes it is rare, but retry.
	for range 5 {
		l := Link{Code: randomCode(), URL: rawURL, CreatedAt: s.now().UTC()}
		err := s.store.Create(ctx, l)
		if errors.Is(err, ErrCodeTaken) {
			continue
		}
		return l, err
	}
	return Link{}, fmt.Errorf("could not find a free code: %w", ErrCodeTaken)
}

// Resolve returns the target URL for code and counts the hit.
func (s *Service) Resolve(ctx context.Context, code string) (string, error) {
	return s.store.Hit(ctx, code)
}

// Stats returns the link with its hit count.
func (s *Service) Stats(ctx context.Context, code string) (Link, error) {
	return s.store.Get(ctx, code)
}

func validateURL(raw string) error {
	if len(raw) > maxURLLen {
		return &InvalidError{fmt.Sprintf("url longer than %d bytes", maxURLLen)}
	}
	u, err := url.Parse(raw)
	if err != nil {
		return &InvalidError{"url does not parse"}
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return &InvalidError{"url must start with http:// or https://"}
	}
	if u.Host == "" {
		return &InvalidError{"url has no host"}
	}
	return nil
}

func randomCode() string {
	b := make([]byte, genLength)
	rand.Read(b) // crypto/rand: codes must not be guessable (P-15)
	for i := range b {
		b[i] = alphabet[int(b[i])%len(alphabet)] // tiny modulo bias (DT-96) is acceptable here
	}
	return string(b)
}

// DayCount is the number of hits on one day (YYYY-MM-DD, UTC).
type DayCount struct {
	Day  string `json:"day"`
	Hits int64  `json:"hits"`
}

// DailyCounter is an optional Store capability (Unit 3.6).
type DailyCounter interface {
	Daily(ctx context.Context, code string, days int) ([]DayCount, error)
}

var ErrUnsupported = errors.New("not supported by this store")

// Daily returns per-day hits for the last days (1-366).
func (s *Service) Daily(ctx context.Context, code string, days int) ([]DayCount, error) {
	if days < 1 || days > 366 {
		return nil, &InvalidError{"days must be between 1 and 366"}
	}
	dc, ok := s.store.(DailyCounter)
	if !ok {
		return nil, ErrUnsupported
	}
	return dc.Daily(ctx, code, days)
}
