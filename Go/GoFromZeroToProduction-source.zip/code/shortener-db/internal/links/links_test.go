package links

import (
	"context"
	"errors"
	"testing"
)

// collidingStore reports ErrCodeTaken for the first n creates.
type collidingStore struct {
	*Memory
	n int
}

func (c *collidingStore) Create(ctx context.Context, l Link) error {
	if c.n > 0 {
		c.n--
		return ErrCodeTaken
	}
	return c.Memory.Create(ctx, l)
}

func TestShortenGeneratesCodes(t *testing.T) {
	svc := NewService(NewMemory())
	seen := map[string]bool{}
	for range 1000 {
		l, err := svc.Shorten(context.Background(), "https://example.com/x", "")
		if err != nil {
			t.Fatal(err)
		}
		if !codeRE.MatchString(l.Code) || len(l.Code) != genLength || seen[l.Code] {
			t.Fatalf("bad or repeated code %q", l.Code)
		}
		seen[l.Code] = true
	}
}

func TestShortenRetriesCollisions(t *testing.T) {
	svc := NewService(&collidingStore{Memory: NewMemory(), n: 3})
	if _, err := svc.Shorten(context.Background(), "https://a.com", ""); err != nil {
		t.Fatalf("3 collisions should be retried: %v", err)
	}
	svc = NewService(&collidingStore{Memory: NewMemory(), n: 100})
	if _, err := svc.Shorten(context.Background(), "https://a.com", ""); !errors.Is(err, ErrCodeTaken) {
		t.Fatalf("want ErrCodeTaken after 5 attempts, got %v", err)
	}
}
