// Package httpapi exposes the shortener over HTTP.
//
//	POST /api/links          {"url": "...", "code": "optional"} -> 201 + link
//	GET  /api/links/{code}   -> 200 + link with hit count
//	GET  /api/links/{code}/daily?days=7 -> 200 + hits per day
//	GET  /{code}             -> 302 redirect to the target URL
//	GET  /healthz            -> 200 "ok"
package httpapi

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"example.com/shortener/internal/links"
)

const maxBodyBytes = 16 << 10

type API struct {
	svc *links.Service
	log *slog.Logger
}

// New returns the complete handler, with middleware applied.
func New(svc *links.Service, log *slog.Logger) http.Handler {
	a := &API{svc: svc, log: log}
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/links", a.create)
	mux.HandleFunc("GET /api/links/{code}", a.stats)
	mux.HandleFunc("GET /api/links/{code}/daily", a.daily)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("GET /{code}", a.redirect)
	// Middleware is applied outside-in: requestID runs first.
	return requestID(logRequests(log, recoverPanics(log, mux)))
}

type createRequest struct {
	URL  string `json:"url"`
	Code string `json:"code"`
}

func (a *API) create(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	var req createRequest
	if err := dec.Decode(&req); err != nil {
		a.writeError(w, r, http.StatusBadRequest, "body must be JSON like {\"url\": \"https://...\"}: "+err.Error())
		return
	}
	l, err := a.svc.Shorten(r.Context(), req.URL, req.Code)
	if err != nil {
		a.fail(w, r, err)
		return
	}
	w.Header().Set("Location", "/api/links/"+l.Code)
	writeJSON(w, http.StatusCreated, l)
}

func (a *API) stats(w http.ResponseWriter, r *http.Request) {
	l, err := a.svc.Stats(r.Context(), r.PathValue("code"))
	if err != nil {
		a.fail(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, l)
}

func (a *API) daily(w http.ResponseWriter, r *http.Request) {
	days := 7
	if v := r.URL.Query().Get("days"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			a.writeError(w, r, http.StatusBadRequest, "days must be a number")
			return
		}
		days = n
	}
	counts, err := a.svc.Daily(r.Context(), r.PathValue("code"), days)
	if err != nil {
		a.fail(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, counts)
}

func (a *API) redirect(w http.ResponseWriter, r *http.Request) {
	target, err := a.svc.Resolve(r.Context(), r.PathValue("code"))
	if err != nil {
		a.fail(w, r, err)
		return
	}
	http.Redirect(w, r, target, http.StatusFound)
}

// fail maps domain errors to HTTP status codes in one place.
func (a *API) fail(w http.ResponseWriter, r *http.Request, err error) {
	var inv *links.InvalidError
	switch {
	case errors.As(err, &inv):
		a.writeError(w, r, http.StatusBadRequest, inv.Reason)
	case errors.Is(err, links.ErrNotFound):
		a.writeError(w, r, http.StatusNotFound, "no such link")
	case errors.Is(err, links.ErrCodeTaken):
		a.writeError(w, r, http.StatusConflict, "code already in use")
	case errors.Is(err, links.ErrUnsupported):
		a.writeError(w, r, http.StatusNotImplemented, "not available")
	case errors.Is(err, context.Canceled):
		// the client went away; nobody will read a response
	default:
		a.log.ErrorContext(r.Context(), "internal error", "err", err, "request_id", RequestID(r.Context()))
		a.writeError(w, r, http.StatusInternalServerError, "internal error") // never leak details
	}
}

type errorBody struct {
	Error     string `json:"error"`
	RequestID string `json:"request_id"`
}

func (a *API) writeError(w http.ResponseWriter, r *http.Request, status int, msg string) {
	writeJSON(w, status, errorBody{Error: msg, RequestID: RequestID(r.Context())})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// ---- middleware ----

type ctxKey struct{}

// RequestID returns the request's ID, or "" outside a request.
func RequestID(ctx context.Context) string {
	id, _ := ctx.Value(ctxKey{}).(string)
	return id
}

func requestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get("X-Request-ID")
		if id == "" || len(id) > 64 {
			id = rand.Text()[:12]
		}
		w.Header().Set("X-Request-ID", id)
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), ctxKey{}, id)))
	})
}

// statusRecorder remembers the status code a handler wrote.
type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (s *statusRecorder) WriteHeader(code int) {
	s.status = code
	s.ResponseWriter.WriteHeader(code)
}

func (s *statusRecorder) Unwrap() http.ResponseWriter { return s.ResponseWriter } // for http.ResponseController

func logRequests(log *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(rec, r)
		log.InfoContext(r.Context(), "request",
			"method", r.Method, "path", r.URL.Path, "status", rec.status,
			"duration", time.Since(start), "request_id", RequestID(r.Context()))
	})
}

func recoverPanics(log *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if v := recover(); v != nil {
				if v == http.ErrAbortHandler { // deliberate abort: let net/http handle it
					panic(v)
				}
				log.ErrorContext(r.Context(), "panic", "value", fmt.Sprint(v), "request_id", RequestID(r.Context()))
				http.Error(w, "internal error", http.StatusInternalServerError)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
