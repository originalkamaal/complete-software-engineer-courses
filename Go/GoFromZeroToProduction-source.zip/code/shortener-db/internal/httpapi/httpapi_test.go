package httpapi

import (
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"example.com/shortener/internal/links"
)

func newServer(t *testing.T) *httptest.Server {
	t.Helper()
	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	srv := httptest.NewServer(New(links.NewService(links.NewMemory()), log))
	t.Cleanup(srv.Close)
	return srv
}

// noRedirect makes the client return 3xx responses instead of following them.
var noRedirect = &http.Client{CheckRedirect: func(*http.Request, []*http.Request) error {
	return http.ErrUseLastResponse
}}

func post(t *testing.T, srv *httptest.Server, body string) (*http.Response, map[string]any) {
	t.Helper()
	resp, err := http.Post(srv.URL+"/api/links", "application/json", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var m map[string]any
	json.NewDecoder(resp.Body).Decode(&m)
	return resp, m
}

func TestCreateRedirectStats(t *testing.T) {
	srv := newServer(t)
	resp, body := post(t, srv, `{"url": "https://go.dev/doc/", "code": "godocs"}`)
	if resp.StatusCode != http.StatusCreated || body["code"] != "godocs" {
		t.Fatalf("create: %d %v", resp.StatusCode, body)
	}
	if resp.Header.Get("X-Request-ID") == "" {
		t.Error("no request ID header")
	}

	for range 3 {
		r, err := noRedirect.Get(srv.URL + "/godocs")
		if err != nil {
			t.Fatal(err)
		}
		r.Body.Close()
		if r.StatusCode != http.StatusFound || r.Header.Get("Location") != "https://go.dev/doc/" {
			t.Fatalf("redirect: %d %q", r.StatusCode, r.Header.Get("Location"))
		}
	}

	r, err := http.Get(srv.URL + "/api/links/godocs")
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	var l links.Link
	json.NewDecoder(r.Body).Decode(&l)
	if l.Hits != 3 {
		t.Errorf("hits = %d, want 3", l.Hits)
	}
}

func TestErrors(t *testing.T) {
	srv := newServer(t)
	post(t, srv, `{"url": "https://example.com", "code": "taken"}`)
	tests := []struct {
		name, body string
		want       int
	}{
		{"not json", `hello`, 400},
		{"unknown field", `{"url": "https://x.com", "colour": "red"}`, 400},
		{"bad scheme", `{"url": "ftp://x.com"}`, 400},
		{"no host", `{"url": "https://"}`, 400},
		{"bad code", `{"url": "https://x.com", "code": "a b"}`, 400},
		{"duplicate code", `{"url": "https://x.com", "code": "taken"}`, 409},
		{"too big", `{"url": "https://x.com/` + strings.Repeat("a", 20000) + `"}`, 400},
		{"generated code", `{"url": "https://x.com"}`, 201},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			resp, body := post(t, srv, tt.body)
			if resp.StatusCode != tt.want {
				t.Errorf("status %d, want %d (%v)", resp.StatusCode, tt.want, body)
			}
			if tt.want >= 400 && body["request_id"] == "" {
				t.Error("error body has no request_id")
			}
		})
	}
	r, _ := http.Get(srv.URL + "/nope")
	if r.StatusCode != 404 {
		t.Errorf("unknown code: %d", r.StatusCode)
	}
	req, _ := http.NewRequest(http.MethodDelete, srv.URL+"/api/links/taken", nil)
	r, _ = http.DefaultClient.Do(req)
	if r.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("DELETE: %d, want 405", r.StatusCode)
	}
}
