// Command playtool is a number-guessing game and a unit converter.
//
//	playtool guess [seed]   guess a number from 1 to 100 in at most 7 attempts
//	playtool convert        convert lines like "10 km mi" until "quit" or EOF
package main

import (
	"bufio"
	"errors"
	"fmt"
	"math/rand/v2"
	"os"
	"strconv"
	"strings"
)

const usage = "usage: playtool guess [seed] | playtool convert"

const (
	minNumber   = 1
	maxNumber   = 100
	maxAttempts = 7
)

const (
	kmPerMi = 1.609344
	kgPerLb = 0.45359237
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

// run checks the arguments and dispatches to a mode. It never calls os.Exit,
// so every deferred call inside it runs (P-14).
func run(args []string) error {
	if len(args) == 0 {
		return errors.New(usage)
	}
	switch args[0] {
	case "guess":
		if len(args) > 2 {
			return errors.New(usage)
		}
		seedArg := ""
		if len(args) == 2 {
			seedArg = args[1]
		}
		secret, err := newSecret(seedArg)
		if err != nil {
			return err
		}
		return playGuess(bufio.NewScanner(os.Stdin), secret)
	case "convert":
		if len(args) != 1 {
			return errors.New(usage)
		}
		return runConvert(bufio.NewScanner(os.Stdin))
	default:
		return fmt.Errorf("unknown mode %q\n%s", args[0], usage)
	}
}

// newSecret returns a random number in [minNumber, maxNumber]. With a seed,
// the number is the same on every run, which makes the game testable.
func newSecret(seedArg string) (int, error) {
	span := maxNumber - minNumber + 1
	if seedArg == "" {
		return minNumber + rand.IntN(span), nil
	}
	seed, err := strconv.ParseUint(seedArg, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid seed %q: %w", seedArg, err)
	}
	r := rand.New(rand.NewPCG(seed, seed))
	return minNumber + r.IntN(span), nil
}

func playGuess(sc *bufio.Scanner, secret int) error {
	fmt.Printf("I picked a number from %d to %d. You have %d attempts.\n",
		minNumber, maxNumber, maxAttempts)
	attempt := 1
	for attempt <= maxAttempts {
		fmt.Printf("attempt %d/%d: ", attempt, maxAttempts)
		if !sc.Scan() {
			if err := sc.Err(); err != nil {
				return fmt.Errorf("reading input: %w", err)
			}
			return errors.New("game aborted: input ended")
		}
		text := strings.TrimSpace(sc.Text())
		guess, err := strconv.Atoi(text)
		if err != nil || guess < minNumber || guess > maxNumber {
			// A rejected line does not use up an attempt.
			fmt.Fprintf(os.Stderr, "please enter a whole number from %d to %d (got %q)\n",
				minNumber, maxNumber, text)
			continue
		}
		switch {
		case guess < secret:
			fmt.Println("too low")
		case guess > secret:
			fmt.Println("too high")
		default:
			fmt.Printf("correct! %d attempt(s): %s\n", attempt, rating(attempt))
			return nil
		}
		attempt++
	}
	return fmt.Errorf("out of attempts, the number was %d", secret)
}

func rating(attempts int) string {
	switch {
	case attempts <= 3:
		return "well played"
	case attempts <= 5:
		return "good"
	default:
		return "just made it"
	}
}

func runConvert(sc *bufio.Scanner) error {
	fmt.Println(`enter "<value> <from> <to>" (km mi kg lb c f), or "quit"`)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		if line == "quit" {
			break
		}
		fields := strings.Fields(line)
		if len(fields) != 3 {
			fmt.Fprintf(os.Stderr, "need 3 words, got %d: %q\n", len(fields), line)
			continue
		}
		v, err := strconv.ParseFloat(fields[0], 64)
		if err != nil {
			fmt.Fprintf(os.Stderr, "not a number: %q\n", fields[0])
			continue
		}
		out, ok := convert(v, fields[1], fields[2])
		if !ok {
			fmt.Fprintf(os.Stderr, "unknown conversion %s -> %s\n", fields[1], fields[2])
			continue
		}
		fmt.Printf("%g %s = %.4f %s\n", v, fields[1], out, fields[2])
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("reading input: %w", err)
	}
	fmt.Println("bye")
	return nil
}

// convert reports ok == false for an unknown pair of units.
func convert(v float64, from, to string) (float64, bool) {
	switch from + ">" + to {
	case "km>mi":
		return v / kmPerMi, true
	case "mi>km":
		return v * kmPerMi, true
	case "kg>lb":
		return v / kgPerLb, true
	case "lb>kg":
		return v * kgPerLb, true
	case "c>f":
		return v*9/5 + 32, true
	case "f>c":
		return (v - 32) * 5 / 9, true
	}
	return 0, false
}
