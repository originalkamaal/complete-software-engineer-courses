module playtool

go 1.24
