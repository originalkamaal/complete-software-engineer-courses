# Appendix C — Go versions and features

Go releases a new version every six months (February and August) and supports the two most recent. Go 1 code keeps compiling on every later 1.x release. The `go` line in `go.mod` sets the minimum language version a module needs, and since Go 1.21 it also controls version-dependent behaviour such as loop-variable semantics (Unit 3.13).

This table lists the features this book relies on, and the version that introduced each one. Features from **Go 1.25 onwards** are marked in the text, and the book's code examples for them were not compiled (see *Toolchain and versions* in the front matter).

| Version | Released | Features used or discussed in this book |
| --- | --- | --- |
| 1.13 | 2019 | `0o` octal and `0b` binary literals, digit separators `1_000`; error wrapping with `%w`, `errors.Is`, `errors.As` |
| 1.16 | 2021 | `embed` package; `io/fs`; `os.ReadFile` / `os.WriteFile` |
| 1.18 | 2022 | **Generics** (type parameters, constraints); fuzzing in `go test`; workspaces (`go.work`) |
| 1.20 | 2023 | `errors.Join` and multiple `%w`; profile-guided optimisation (preview); `context.WithCancelCause` |
| 1.21 | 2023 | `min`, `max`, `clear` built-ins; `slices`, `maps`, `cmp` packages; `log/slog`; PGO generally available; toolchain management (`toolchain` line) |
| 1.22 | 2024 | **Per-iteration loop variables**; `range` over integers; `net/http.ServeMux` method and wildcard patterns; `math/rand/v2` |
| 1.23 | 2024 | **Range-over-func iterators** (`iter.Seq`, `iter.Seq2`); iterator functions in `slices` and `maps`; `unique` package; timer and ticker changes (unbuffered, collectable) |
| 1.24 | 2025 | Generic type aliases; `testing.B.Loop`; `os.Root`; `weak` package; Swiss-table map implementation; `omitzero` JSON tag; `tool` directives in `go.mod`; `crypto/mlkem` — **the version used to verify this book** |
| 1.25 | 2025 | Container-aware `GOMAXPROCS`; `testing/synctest`; `sync.WaitGroup.Go`; `encoding/json/v2` experiment; trace flight recorder; Green Tea GC experiment |
| 1.26 | 2026 | `new(expr)`; `errors.AsType`; Green Tea garbage collector by default; `crypto/hpke`; `go fix` modernisers |
| 1.27 | 2026 | Generic methods (not allowed in interfaces, and cannot satisfy interfaces); promoted-field keys in struct literals; `encoding/json` backed by the v2 engine, plus `encoding/json/v2`; `uuid` package; `crypto/mldsa`; goroutine-leak profile; `synctest.Sleep`; `httptest.NewTestServer`; `strings.CutLast` / `bytes.CutLast`; `Rand.N` |

To learn what a new release changes, read its release notes at **go.dev/doc/devel/release** and run `go fix ./...` — since Go 1.26 it applies the modernisers that rewrite old idioms into new ones.
