---
title: "Go from Zero to Production"
subtitle: "A complete apprenticeship in the Go programming language — from bits and bytes to a production routing backend"
lang: en
---

# Preface

This book teaches Go the way an apprenticeship teaches a craft: one small, precise step at a time, each step checked before the next, until you can do the work of a senior engineer on your own.

It begins below the language — with what a running program physically is, how numbers live in memory, and why integers overflow silently — because almost every confusing Go behaviour you will meet later is explained by the machine. It then covers the language itself rule by rule, the standard library, testing, data structures and algorithms, concurrency, networking, databases, performance engineering, production operations, and distributed systems. It ends with two chapters in which you build, prove, and operate a real system: a road-routing service that reads OpenStreetMap data and answers fastest-route queries under load.

Three promises shape every page:

1. **Precision.** Each claim about Go is labelled with how strong it is (see *How to read the labels* below). Where the language specification guarantees something, the book says so; where a behaviour is only how today's compiler or runtime happens to work, the book says that instead.
2. **Evidence.** Code in this book was compiled and run. Test output, benchmark numbers, profiles, race-detector reports, and load-test results are real, from the machines described in the text. When a measurement showed *no* improvement, the book reports that too, because learning to accept evidence you did not want is part of the craft.
3. **Order.** Nothing is used before it is taught. Each unit lists what it builds on; each chapter ends with a project that combines its units; later chapters refer back by unit number so you can revisit exactly what you need.

# How to use this book

## Who it is for

- **Complete beginners** to programming who are willing to work carefully: start at Chapter 0 and read in order.
- **Programmers coming from other languages**: read Chapter 0 quickly (it still contains things most programmers never learned), then work through every *Deep & Tricky* entry and *Mastery check* — that is where Go differs from what you know.
- **Working Go developers** aiming for senior level: use Appendix A to test yourself on every *Deep & Tricky* entry, then focus on Chapters 6–14.

## The shape of a unit

Every unit has the same structure, so you always know where you are:

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. If you remember nothing else, remember this. |
| **Mental model** | An analogy or picture to hang the details on (where useful). |
| **Lesson** | The rules, with small runnable programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise even experienced developers, each labelled with its source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Common mistakes** | What learners and professionals actually get wrong. |
| **Mastery check** | *Explain* (say it in your own words), *Predict* (decide the output before running), *Write* (code it). Answers to the prediction questions are at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a specification, requirements, a complete reference solution with real output, and a review checklist. Try the project yourself before reading the solution. Your version will differ; compare the decisions, not the lines.

## How to study

1. **Type the code; do not paste it.** Typing forces you to read every character, and the mistakes you make while typing are exactly the ones you need to learn from.
2. **Predict before you run.** Write down what you expect a program to print. When you are wrong, find out why before moving on — that is where learning happens.
3. **Do the mastery checks.** If you cannot explain a unit's one-line summary to someone else, re-read the unit.
4. **Revise with Appendix A.** It lists every DT and P entry by title. Cover the right-hand column, read a title, and explain the entry from memory.
5. **Expect to take months, not weeks.** The book covers what professional Go developers learn over several years. A unit a day is a good pace.

## How to read the labels

*Deep & Tricky* entries carry a label in italics saying how far you can rely on them:

| Label | Meaning |
| --- | --- |
| *Guarantee* / *Guarantee: Go specification* | Required by the Go language specification or the documented API contract. True on every conforming implementation and every future Go 1.x version. |
| *Library behaviour*, *Standard-library behaviour*, *fmt behaviour* | Documented behaviour of a standard-library package. Stable, but defined by the package documentation rather than the language. |
| *Toolchain behaviour*, *Compiler behaviour* | What the `go` command or the gc compiler does. Stable in practice; occasionally changed between releases. |
| *Implementation detail*, *Runtime behaviour* | How the current runtime or compiler works internally (map layout, GC pacing, escape analysis). Useful for understanding performance; never write code that depends on it for correctness. |
| *Version-dependent* | Changed in a specific Go release; the entry names the version. |
| *Practice*, *Go convention*, *Design rule* | Community and professional practice, not a rule of the language. |
| *Hardware fact*, *OS behaviour*, *IEEE 754 behaviour*, *Algorithmic fact* | True because of the machine, operating system, floating-point standard, or mathematics — not because of Go. |

## Toolchain and versions

All code in this book was compiled and tested with **Go 1.24** on Linux (amd64). Programs that use databases were run against **PostgreSQL 16** and **Redis 7**.

Go is backwards compatible: everything here works on Go 1.24 and every later Go 1.x release. Features introduced in **Go 1.25, 1.26, and 1.27** are taught where they belong and clearly marked with their version — for example generic methods (Go 1.27), `errors.AsType` and `new(expr)` (Go 1.26), and `sync.WaitGroup.Go` (Go 1.25). Those examples follow the official release notes but could not be compiled with the Go 1.24 toolchain used to verify this book; check them against your own installation. Appendix C lists which version introduced which feature.

A few artefacts were written to production standard but **not executed** while the book was verified, and the text says so where they appear: PostGIS SQL (Unit 9.6), the Dockerfile, CI workflow, and Kubernetes manifests (Chapter 11), and gRPC code (Unit 8.8). Everything else — every test, benchmark, profile, race report, and load test — was run.

## Setting up

1. Install Go from **go.dev/dl** (any version from 1.24 on; the newest is best). Check with `go version`.
2. Install an editor with the official Go language server, **gopls** (VS Code with the Go extension, GoLand, Neovim, Zed, or Emacs all work).
3. Create a folder for your work and, inside it, one module per project: `go mod init example.com/numinfo` (Unit 3.13 explains modules properly; until then, follow the steps in each project).
4. For Chapters 9 onwards, install **PostgreSQL** and **Redis** locally (or run them in containers).
5. Keep a learning journal: the predictions you got wrong and why. It will become your most valuable revision tool.

# Roadmap

| Chapter | Title | You will be able to… |
| --- | --- | --- |
| 0 | Computing Foundations & Toolchain | explain what a running program physically is: compilation, binary numbers, two's complement, floats, memory, the stack and heap |
| 1 | Core Language Fundamentals | use Go's types, constants, operators, control flow, functions, and closures with exact knowledge of the rules |
| 2 | Composite Data & Memory | master arrays, slices, strings, maps, structs, and pointers — where most real Go bugs live |
| 3 | Types, Methods, Interfaces, Errors, Packages, Generics | organise programs with clean abstractions, handle errors properly, and write generic code |
| 4 | Testing, Tooling & Debugging | test with tables, fakes, golden files, fuzzing, and benchmarks; debug with Delve and the race detector |
| 5 | Standard Library & I/O | stream data with `io`, process text, JSON, and binary formats, and work with files, time, and the command line |
| 6 | Data Structures, Algorithms & Complexity | analyse complexity and implement the structures and graph algorithms behind fast software |
| 7 | Concurrency | write correct, leak-free concurrent programs with goroutines, channels, `context`, and `sync` |
| 8 | Networking, HTTP & RPC | build production-shaped HTTP services and clients, WebSockets, and RPC |
| 9 | Databases, Persistence & Caching | use SQL and PostgreSQL correctly — transactions, migrations, indexes — and cache safely with Redis |
| 10 | Performance Engineering & Runtime Internals | benchmark and profile rigorously, understand the scheduler and GC, and prove optimisations |
| 11 | Production Engineering | configure, secure, observe, containerise, and deploy services that can be operated |
| 12 | Distributed Systems & System Design | design systems that survive failures: consistency, queues, idempotency, sagas, and consensus |
| 13 | Geospatial Computing & Routing Algorithms | work with coordinates, spatial indexes, OpenStreetMap data, and fast routing algorithms |
| 14 | Capstone: Production Routing Backend | design, build, prove, operate, and defend a production routing service |
| A | Index of Deep & Tricky entries and Patterns | revise every entry by title |
| B | Glossary | look up any term used in the book |
| C | Go versions and features | see which Go release introduced each modern feature |

Chapters 0–5 are the **foundation**: read them in order. Chapters 6–9 can be read in order or, if you need networking sooner, as 6, 7, 8, 9. Chapters 10–12 assume everything before them. Chapters 13–14 use the whole book.
