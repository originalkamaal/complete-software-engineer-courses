# Appendix A — Index of Deep & Tricky entries and Patterns

Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, with the unit where it is explained. Use it for revision: read each title and try to explain the entry before looking it up.

## Deep & Tricky Go Knowledge

| # | Entry | Where |
| --- | --- | --- |
| DT-1 | `go run` still compiles, and Go caches builds. | Unit 0.1 |
| DT-2 | Your binary carries the Go runtime inside it. | Unit 0.1 |
| DT-3 | Cross-compilation is built in. | Unit 0.1 |
| DT-4 | Pure Go programs are usually statically linked. | Unit 0.1 |
| DT-5 | Unused imports vs unused variables — two different rules. | Unit 0.1 |
| DT-6 | Division by zero: compile time, run time, and floats all differ. | Unit 0.1 |
| DT-7 | `NaN` is not equal to itself. | Unit 0.1 |
| DT-8 | Same zero, different verdict: int variable vs float variable. | Unit 0.1 |
| DT-9 | `go run` hides the real exit code. | Unit 0.1 |
| DT-10 | Go constants are exact numbers, not IEEE floats. | Unit 0.1 |
| DT-11 | `$?` remembers only the last command. | Unit 0.1 |
| DT-12 | A Go binary carries debug information too. | Unit 0.1 |
| DT-13 | A leading zero makes a number octal. | Unit 0.2 |
| DT-14 | The size of `int` is not fixed by the language. | Unit 0.2 |
| DT-15 | `byte` is just another name for `uint8`. | Unit 0.2 |
| DT-16 | Byte order (endianness) — the `LSB` in `file` output. | Unit 0.2 |
| DT-17 | Why `{` must be on the same line: automatic semicolons. | Unit 0.2 |
| DT-18 | `%x` vs `%X` bugs hide when there are no letters. | Unit 0.2 |
| DT-19 | Integer overflow never panics in Go, and the result is defined. | Unit 0.3 |
| DT-20 | `fmt.Println(math.MaxUint64)` does not compile. | Unit 0.3 |
| DT-21 | "Underflow" is used loosely. | Unit 0.3 |
| DT-22 | A countdown with an unsigned counter never ends. | Unit 0.3 |
| DT-23 | Same bits, different number — the type decides. | Unit 0.4 |
| DT-24 | Negating the minimum value gives itself. | Unit 0.4 |
| DT-25 | `math.MinInt64 / -1` does not crash in Go. | Unit 0.4 |
| DT-26 | The compiler may NOT assume `x < x + 1`. | Unit 0.4 |
| DT-27 | `uint8(-5)` vs `uint8(x)` — "who calculates?" once more. | Unit 0.4 |
| DT-28 | Who really drops the 9th bit? The compiler plans it, the CPU does it. | Unit 0.4 |
| DT-29 | Same size, different type: `int` vs `int64`. | Unit 0.4 |
| DT-30 | Constant folding: `c := 2 + 3` has no ADD at run time. | Unit 0.5 |
| DT-31 | Same ADD, different compare and divide. | Unit 0.5 |
| DT-32 | Apple Silicon uses bigger cache lines. | Unit 0.5 |
| DT-33 | Cache lines are aligned blocks. | Unit 0.5 |
| DT-34 | The Go specification never mentions "stack" or "heap". | Unit 0.6 |
| DT-35 | Goroutine stacks grow by copying. | Unit 0.6 |
| DT-36 | Apple Silicon pages are 16 KB. | Unit 0.6 |
| DT-37 | Goroutine stacks live in runtime-managed memory. | Unit 0.6 |
| DT-38 | Go passes arguments and return values in registers. | Unit 0.6 |
| DT-39 | Stack overflow is a fatal error, not a panic. | Unit 0.6 |
| DT-40 | Inlined functions show `(...)` in stack traces. | Unit 0.6 |
| DT-41 | Converting to a smaller integer type keeps only the lowest bits. | Unit 0.6 |
| DT-42 | Even a local that never escapes may go to the heap. | Unit 0.6 |
| DT-43 | Every variable starts at its zero value — a spec guarantee, implemented cleverly. | Unit 0.6 |
| DT-44 | Hex formatting of negative numbers. | Unit 0.6 |
| DT-45 | `:=` with existing variables: the `err` idiom. | Unit 1.1 |
| DT-46 | Multiple assignment evaluates the right side first. | Unit 1.1 |
| DT-47 | `1e3` is a float, even though 1000 is a whole number. | Unit 1.1 |
| DT-48 | "Make the zero value useful." | Unit 1.1 |
| DT-49 | Your editor and the compiler can word the same error differently. | Unit 1.1 |
| DT-50 | `var i int = 2.0` compiles. | Unit 1.2 |
| DT-51 | Compilers must handle very large constants. | Unit 1.2 |
| DT-52 | iota counts lines, not uses. | Unit 1.2 |
| DT-53 | `'a' + 1` prints 98. | Unit 1.2 |
| DT-54 | `var f float64 = 7 / 2` gives 3, not 3.5. | Unit 1.3 |
| DT-55 | Go truncates towards zero; Python floors. | Unit 1.3 |
| DT-56 | `x++` is a statement on purpose. | Unit 1.3 |
| DT-57 | `fmt.Println` prints `4.0` as `4`, and `1000000.0` as `1e+06`. | Unit 1.3 |
| DT-58 | `-7 >> 1` is −4, but `-7 / 2` is −3. | Unit 1.4 |
| DT-59 | Shifts are fully defined in Go. | Unit 1.4 |
| DT-60 | Untyped constants in non-constant shifts. | Unit 1.4 |
| DT-61 | Go has no power operator. | Unit 1.4 |
| DT-62 | `0.1 + 0.2 == 0.3` is TRUE in Go when written as constants. | Unit 1.5 |
| DT-63 | float32 → float64 shows the hidden error. | Unit 1.5 |
| DT-64 | Out-of-range float → int conversion does not panic. | Unit 1.5 |
| DT-65 | Negative zero. | Unit 1.5 |
| DT-66 | Integers above 2^53 lose exactness in float64. | Unit 1.5 |
| DT-67 | `fallthrough` ignores the next case's condition. | Unit 1.6 |
| DT-68 | `break` inside a switch only leaves the switch. | Unit 1.6 |
| DT-69 | Switch cases can be any expressions, evaluated in order. | Unit 1.6 |
| DT-70 | Safe absolute value for printing: `uint64(-n)`. | Unit 1.6 |
| DT-71 | Changing the loop variable: three-part loop vs range. | Unit 1.7 |
| DT-72 | Since Go 1.22, each loop round gets a NEW variable. | Unit 1.7 |
| DT-73 | Labels are only for break, continue, and goto. | Unit 1.7 |
| DT-74 | Adding 0.1 ten times gives 0.9999999999999999. | Unit 1.7 |
| DT-75 | Go is ALWAYS pass-by-value. | Unit 1.8 |
| DT-76 | Go does not optimise tail calls. | Unit 1.8 |
| DT-77 | Calling a nil function value panics. | Unit 1.8 |
| DT-78 | Function values cannot be compared, except with nil. | Unit 1.8 |
| DT-79 | Multiple results are not tuples. | Unit 1.8 |
| DT-80 | Go has only 25 keywords; `true`, `nil`, `int`, `len` are NOT keywords. | Unit 1.9 |
| DT-81 | Imports belong to the file, not the package. | Unit 1.9 |
| DT-82 | The compiler only catches shadowing when the inner variable is unused. | Unit 1.9 |
| DT-83 | A new variable's scope starts AFTER its declaration. | Unit 1.9 |
| DT-84 | Why calling nil crashes: page zero is never mapped. | Unit 1.9 |
| DT-85 | Closures capture variables, not values. | Unit 1.10 |
| DT-86 | Captured variables that outlive their function move to the heap. | Unit 1.10 |
| DT-87 | The loop-variable change is per module, controlled by go.mod. | Unit 1.10 |
| DT-88 | `defer` takes a photo of the arguments, and of the function value. | Unit 1.11 |
| DT-89 | Deferring a nil function panics LATER, not at the defer line. | Unit 1.11 |
| DT-90 | Deferred calls run before the panic message is printed. | Unit 1.11 |
| DT-91 | Defer is almost free now (usually). | Unit 1.11 |
| DT-92 | bufio.Scanner has a 64 KB line limit by default. | Unit 1.12 |
| DT-93 | Scanner removes Windows line endings for you. | Unit 1.12 |
| DT-94 | fmt.Scan treats newlines as spaces; fmt.Scanln does not. | Unit 1.12 |
| DT-95 | Old math/rand gave the SAME numbers every run (before Go 1.20). | Unit 1.13 |
| DT-96 | Modulo bias: why `rand.IntN` exists. | Unit 1.13 |
| DT-97 | crypto/rand.Read no longer returns an error (Go 1.24+). | Unit 1.13 |
| DT-98 | `range` over an array iterates over a COPY of the array. | Unit 2.1 |
| DT-99 | Constant indexes are checked at compile time. | Unit 2.1 |
| DT-100 | Arrays are comparable and can be map keys; slices cannot. | Unit 2.1 |
| DT-101 | A slice expression on an array makes the array escape — or not. | Unit 2.2 |
| DT-102 | `len` and `cap` of a nil slice are 0, and you can range over it, append to it, and slice it with `[:0]`. | Unit 2.2 |
| DT-103 | Re-slicing up to capacity can expose "deleted" data. | Unit 2.2 |
| DT-104 | Indexing is checked against `len`, slicing against `cap`. | Unit 2.2 |
| DT-105 | Growth rounds up to size classes. | Unit 2.3 |
| DT-106 | `append` to a nil slice works; there is no need to `make` first. | Unit 2.3 |
| DT-107 | A function that appends to a shared slice can corrupt the caller's other data. | Unit 2.3 |
| DT-108 | `copy` copies by length, not capacity. | Unit 2.3 |
| DT-109 | `slices.Delete` and friends zero the tail (Go 1.22+). | Unit 2.4 |
| DT-110 | `range` over a slice sees writes; over an array it does not. | Unit 2.4 |
| DT-111 | `slices.Sort` is not stable; `slices.SortStableFunc` is. | Unit 2.4 |
| DT-112 | Strings may contain any bytes, not only valid UTF-8. | Unit 2.5 |
| DT-113 | `string(i)` for an integer `i` is a rune conversion. | Unit 2.5 |
| DT-114 | The compiler avoids some `[]byte` ↔ `string` copies. | Unit 2.5 |
| DT-115 | Comparing strings is byte-wise, so "é" may not equal "é". | Unit 2.5 |
| DT-116 | `strings.ToUpper` can change the length of a string. | Unit 2.6 |
| DT-117 | Simple case mapping is not full case mapping. | Unit 2.6 |
| DT-118 | A `strings.Builder` panics if copied after use. | Unit 2.6 |
| DT-119 | Go 1.24 rewrote maps as "Swiss tables". | Unit 2.7 |
| DT-120 | A map with NaN keys can hold "the same" key many times. | Unit 2.7 |
| DT-121 | Iteration order is randomised per iteration, not just per run. | Unit 2.7 |
| DT-122 | Adding to a map during `range` may or may not show up in the same loop. | Unit 2.7 |
| DT-123 | `clear(m)` is not the same as `m = make(...)`. | Unit 2.8 |
| DT-124 | `fatal error: concurrent map writes` is best-effort detection. | Unit 2.8 |
| DT-125 | Zero-size types share an address. | Unit 2.8 |
| DT-126 | Struct literals of pointer type: `&T{...}` is fine, and Go allows `{...}` shorthand inside composite literals. | Unit 2.9 |
| DT-127 | Field order and names are part of the type. | Unit 2.9 |
| DT-128 | Comparing structs with `==` compares padding-free field values, not memory. | Unit 2.9 |
| DT-129 | A zero-size field at the end of a struct adds padding. | Unit 2.10 |
| DT-130 | 64-bit atomic operations need 8-byte alignment, which 32-bit platforms do not give automatically. | Unit 2.10 |
| DT-131 | Go does not reorder struct fields. | Unit 2.10 |
| DT-132 | A pointer into a slice's backing array goes stale after a growing append. | Unit 2.11 |
| DT-133 | Pointers are comparable; equal pointers point to the same variable. | Unit 2.11 |
| DT-134 | Taking the address of a local is always safe in Go. | Unit 2.11 |
| DT-135 | "Pass a pointer to avoid copying" can make code slower. | Unit 2.12 |
| DT-136 | `go vet` reports copied locks. | Unit 2.12 |
| DT-137 | A named type does not inherit the methods of its underlying named type. | Unit 3.1 |
| DT-138 | Typed constants of a named type give you compile-time checked "units". | Unit 3.1 |
| DT-139 | `%v` on a type with a `String()` method that formats itself with `%v` recurses forever. | Unit 3.2 |
| DT-140 | Untyped constants still sneak through. | Unit 3.2 |
| DT-141 | A method value evaluates (copies) its receiver immediately. | Unit 3.3 |
| DT-142 | Map elements and return values are not addressable, so they cannot call pointer methods. | Unit 3.3 |
| DT-143 | Mixing value and pointer receivers creates "lost update" bugs. | Unit 3.3 |
| DT-144 | Value vs pointer receivers decide which types satisfy an interface. | Unit 3.4 |
| DT-145 | `fmt` checks for `error` before `Stringer`. | Unit 3.4 |
| DT-146 | Interfaces are satisfied by method *names and signatures*, not meaning. | Unit 3.4 |
| DT-147 | A nil pointer inside an interface is not a nil interface. | Unit 3.5 |
| DT-148 | Interface comparison can panic. | Unit 3.5 |
| DT-149 | Method calls through interfaces cost an indirect call and block some optimisations. | Unit 3.5 |
| DT-150 | Errors should be inspected with `errors.As`, not type assertions. | Unit 3.6 |
| DT-151 | A failed assertion to an interface type and to a concrete type panic differently. | Unit 3.6 |
| DT-152 | Embedding a type with a `sync.Mutex` promotes `Lock` and `Unlock` — publicly. | Unit 3.7 |
| DT-153 | Embedding a type promotes its `String()` or `Error()`, which can hijack printing. | Unit 3.7 |
| DT-154 | Promoted fields in composite literals are a Go 1.27 feature. | Unit 3.7 |
| DT-155 | Returning an internal slice leaks write access. | Unit 3.8 |
| DT-156 | Options structs make "zero" and "unset" the same. | Unit 3.8 |
| DT-157 | A function returning `(T, error)` usually leaves T unspecified on error. | Unit 3.9 |
| DT-158 | `errors.New` creates a distinct value each call. | Unit 3.9 |
| DT-159 | `errors.As` panics if the target is not a non-nil pointer to an error type or interface. | Unit 3.10 |
| DT-160 | A type can customise matching with `Is(target error) bool` and `As(target any) bool` methods. | Unit 3.10 |
| DT-161 | `go vet` (Go 1.27) flags `%w` with a pointer to a value-receiver error type. | Unit 3.10 |
| DT-162 | Wrapping `io.EOF` breaks callers that check `err == io.EOF`. | Unit 3.10 |
| DT-163 | `panic(nil)` became a real panic in Go 1.21. | Unit 3.11 |
| DT-164 | Re-panicking keeps the original stack in the message. | Unit 3.11 |
| DT-165 | `runtime.Goexit` runs defers but is not a panic. | Unit 3.11 |
| DT-166 | A test file can be in the same package or in `pkg_test`. | Unit 3.12 |
| DT-167 | Unexported fields are invisible to reflection-based encoders. | Unit 3.12 |
| DT-168 | Dot imports and package-name shadowing hurt readability. | Unit 3.12 |
| DT-169 | The `go` line can trigger a toolchain download. | Unit 3.13 |
| DT-170 | Language changes are gated by each module's `go` line. | Unit 3.13 |
| DT-171 | Never edit `go.sum` by hand, and commit it. | Unit 3.13 |
| DT-172 | `comparable` admits interface types, whose `==` can panic. | Unit 3.14 |
| DT-173 | Type inference never uses the result type of a call alone. | Unit 3.14 |
| DT-174 | A type parameter's methods are only those in its constraint. | Unit 3.15 |
| DT-175 | Generic code that calls methods through a type parameter may be slower than an interface call. | Unit 3.15 |
| DT-176 | An iterator that ignores `yield`'s false result panics. | Unit 3.16 |
| DT-177 | `defer` inside an iterator runs when the iterator function returns — after the loop ends or breaks. | Unit 3.16 |
| DT-178 | Single-use vs reusable iterators. | Unit 3.16 |
| DT-179 | `t.Fatal` must be called from the test's own goroutine. | Unit 4.1 |
| DT-180 | Test results are cached. | Unit 4.1 |
| DT-181 | Since Go 1.27, `go test` runs the `stdversion` vet check by default. | Unit 4.1 |
| DT-182 | `TestMain` controls the whole package's test run. | Unit 4.2 |
| DT-183 | Parallel subtests run after the parent function returns. | Unit 4.2 |
| DT-184 | Coverage counts statements, not branches or conditions. | Unit 4.3 |
| DT-185 | A benchmark is a hypothesis test, not a speed reading. | Unit 4.5 |
| DT-186 | The library project's `List` benchmark reveals an O(books × loans) loop. | Unit 4.5 |
| DT-187 | Fuzzing uses all CPU cores and grows the cache. | Unit 4.6 |
| DT-188 | Linters can be silenced line by line, and that should be rare and explained. | Unit 4.7 |
| DT-189 | Stack traces show argument words, not argument values. | Unit 4.8 |
| DT-190 | `Read` can return data and `io.EOF` at the same time. | Unit 5.1 |
| DT-191 | `io.ReadAll` on untrusted input is a denial-of-service bug. | Unit 5.1 |
| DT-192 | `defer f.Close()` on a file you wrote can lose errors — and data. | Unit 5.2 |
| DT-193 | Checking whether a file exists before opening it is a race. | Unit 5.2 |
| DT-194 | `path` and `path/filepath` are different on Windows. | Unit 5.3 |
| DT-195 | Unmarshalling into a non-empty value merges. | Unit 5.4 |
| DT-196 | Duplicate keys: v1 takes the last, v2 rejects. | Unit 5.4 |
| DT-197 | HTML characters are escaped by default. | Unit 5.4 |
| DT-198 | `binary.Read` with a struct is reflection-based and slow. | Unit 5.5 |
| DT-199 | A UTF-8 byte-order mark can hide in CSV files from Excel. | Unit 5.5 |
| DT-200 | Never compare `time.Time` with `==`, and never use it as a map key without normalising. | Unit 5.6 |
| DT-201 | `time.Duration(n) * time.Second` vs `time.Duration(n * time.Second)`. | Unit 5.6 |
| DT-202 | Layout mistakes compile and fail silently. | Unit 5.6 |
| DT-203 | Child processes do not die automatically when your program is killed. | Unit 5.7 |
| DT-204 | `cmd.Output()` with a huge output buffers it all in memory. | Unit 5.7 |
| DT-205 | A mismatched key–value list produces `!BADKEY`. | Unit 5.8 |
| DT-206 | Arguments are evaluated even when the level is disabled. | Unit 5.8 |
| DT-207 | `regexp` matches are leftmost-first, like Perl — not longest. | Unit 5.9 |
| DT-208 | Templates fail at execution, not only at parse. | Unit 5.9 |
| DT-209 | Amortised O(1) still has O(n) spikes. | Unit 6.1 |
| DT-210 | Hash maps are O(1) only on average. | Unit 6.1 |
| DT-211 | Recursive closures must be declared before they are assigned. | Unit 6.2 |
| DT-212 | A slice-based queue that pops with `q = q[1:]` can leak memory. | Unit 6.3 |
| DT-213 | A good hash for a composite key combines all its parts. | Unit 6.4 |
| DT-214 | `(lo + hi) / 2` can overflow. | Unit 6.5 |
| DT-215 | Comparison-based sorting cannot beat O(n log n). | Unit 6.6 |
| DT-216 | Sorting floats with NaN using `<` breaks. | Unit 6.6 |
| DT-217 | Sorted slices beat trees for read-mostly data. | Unit 6.7 |
| DT-218 | Building a heap from n elements is O(n), not O(n log n). | Unit 6.8 |
| DT-219 | Recursive DFS on large graphs can overflow the stack — or just be slow. | Unit 6.10 |
| DT-220 | Dijkstra's correctness depends on non-negative weights — and so does your early exit. | Unit 6.11 |
| DT-221 | The same algorithm can be 100× apart depending on allocation order. | Unit 6.13 |
| DT-222 | An unrecovered panic in any goroutine kills the whole program. | Unit 7.2 |
| DT-223 | Goroutines have no identity you can use. | Unit 7.2 |
| DT-224 | A buffered channel is not a queue you should inspect. | Unit 7.3 |
| DT-225 | Races on multi-word values can crash, not just give wrong numbers. | Unit 7.3 |
| DT-226 | Before Go 1.23, `time.After` in a loop leaked timers until they fired. | Unit 7.4 |
| DT-227 | An empty `select {}` blocks forever. | Unit 7.4 |
| DT-228 | `wg.Add` inside the goroutine is a race with `Wait`. | Unit 7.5 |
| DT-229 | A mutex protects data, not code. | Unit 7.5 |
| DT-230 | Go's `Mutex` can be unlocked by a different goroutine than the one that locked it. | Unit 7.5 |
| DT-231 | Atomics are not free under contention. | Unit 7.6 |
| DT-232 | "Benign" races do not exist in Go. | Unit 7.7 |
| DT-233 | Double-checked locking without atomics is broken. | Unit 7.7 |
| DT-234 | The race detector cannot prove absence of races. | Unit 7.8 |
| DT-235 | Every goroutine needs an owner and an exit path. | Unit 7.8 |
| DT-236 | Forgetting `cancel()` leaks until the parent is cancelled. | Unit 7.9 |
| DT-237 | Cancellation is cooperative. | Unit 7.9 |
| DT-238 | Unbounded goroutine creation is a bug waiting for a big input. | Unit 7.10 |
| DT-239 | Results from a worker pool arrive in completion order. | Unit 7.10 |
| DT-240 | A test that passes with `-count=1` can fail with `-count=1000`. | Unit 7.12 |
| DT-241 | "It works on localhost" hides latency and loss. | Unit 8.1 |
| DT-242 | A write that succeeded does not mean the peer received it. | Unit 8.2 |
| DT-243 | Each connection uses a file descriptor, and the limit is finite. | Unit 8.2 |
| DT-244 | `http.ListenAndServe` with no timeouts is vulnerable to slow clients. | Unit 8.4 |
| DT-245 | `WriteTimeout` covers the whole handler. | Unit 8.4 |
| DT-246 | Creating a new `http.Client` (or `Transport`) per request defeats pooling. | Unit 8.5 |
| DT-247 | `Client.Timeout` includes reading the body. | Unit 8.5 |
| DT-248 | Shutdown and readiness must be coordinated with the load balancer. | Unit 8.7 |
| DT-249 | Protobuf zero values are indistinguishable from "unset" for scalars in proto3. | Unit 8.8 |
| DT-250 | PostgreSQL stores timestamps with microsecond precision; Go has nanoseconds. | Unit 9.1 |
| DT-251 | `NOT IN` with a NULL in the list returns nothing. | Unit 9.1 |
| DT-252 | A query on a nullable or low-selectivity column may ignore your index — correctly. | Unit 9.2 |
| DT-253 | `LIKE 'abc%'` can use a B-tree index; `LIKE '%abc'` cannot. | Unit 9.2 |
| DT-254 | A bigger connection pool can make a database slower. | Unit 9.3 |
| DT-255 | A query that is waiting for a pool connection is not yet running. | Unit 9.3 |
| DT-256 | Holding a transaction or an unclosed `rows` while calling another service ties up a connection. | Unit 9.3 |
| DT-257 | Isolation anomalies produce no errors at READ COMMITTED. | Unit 9.4 |
| DT-258 | Retrying requires the whole transaction to be re-run, including the reads. | Unit 9.4 |
| DT-259 | A migration waiting for a lock blocks everything behind it. | Unit 9.5 |
| DT-260 | Caches hide capacity problems until they fail. | Unit 9.7 |
| DT-261 | A decorator hides optional interfaces unless it forwards them. | Unit 9.7 |
| DT-262 | Microbenchmarks can mislead about whole programs. | Unit 10.1 |
| DT-263 | CPU profiles miss time spent waiting. | Unit 10.2 |
| DT-264 | Profile labels attribute samples to requests or tenants. | Unit 10.2 |
| DT-265 | Tracing is more expensive than profiling, but cheaper than it used to be. | Unit 10.3 |
| DT-266 | Inlining changes escape decisions. | Unit 10.4 |
| DT-267 | Go 1.26 can put more slice backing arrays on the stack. | Unit 10.4 |
| DT-268 | Finalizers and `runtime.AddCleanup` are not destructors. | Unit 10.6 |
| DT-269 | A large live heap of pointer-free data is nearly free for the GC. | Unit 10.6 |
| DT-270 | `runtime.LockOSThread` pins a goroutine to its thread. | Unit 10.7 |
| DT-271 | Too many runnable goroutines raise latency, not throughput. | Unit 10.7 |
| DT-272 | A channel operation costs tens of nanoseconds; a mutex lock/unlock costs about ten when uncontended. | Unit 10.8 |
| DT-273 | `unsafe` conversions can outlive their safety. | Unit 10.10 |
| DT-274 | Error messages are an information leak. | Unit 11.2 |
| DT-275 | Timing can leak secrets. | Unit 11.2 |
| DT-276 | "Logged in" must be re-checked on every request. | Unit 11.3 |
| DT-277 | Requests rejected by outer middleware have no route. | Unit 11.5 |
| DT-278 | Averages hide the users who suffer. | Unit 11.5 |
| DT-279 | A static Go binary in `scratch` has no CA certificates or time zones. | Unit 11.6 |
| DT-280 | A failing liveness probe during load turns slowness into an outage. | Unit 11.8 |
| DT-281 | Exactly-once *delivery* is impossible; exactly-once *effects* are not. | Unit 12.1 |
| DT-282 | Database-generated IDs and timestamps do not order events across services. | Unit 12.2 |
| DT-283 | A distributed lock needs a fencing token. | Unit 12.5 |
| DT-284 | Ordering and parallelism pull in opposite directions. | Unit 12.6 |
| DT-285 | A retry is a new request to a system that may already be overloaded. | Unit 12.7 |
| DT-286 | Long-lived connections defeat connection-level load balancing. | Unit 12.8 |
| DT-287 | The antimeridian and the poles break naive code. | Unit 13.1 |
| DT-288 | Most OSM nodes are not intersections. | Unit 13.3 |
| DT-289 | Round edge times up, never down. | Unit 13.4 |
| DT-290 | Resetting O(n) arrays per query can cost more than the query. | Unit 13.6 |
| DT-291 | Bidirectional search must not stop at the first meeting node. | Unit 13.6 |
| DT-292 | Rounding in polyline encoding accumulates if you encode absolute values carelessly. | Unit 13.9 |
| DT-293 | Location data is personal data. | Unit 14.7 |

## Go Patterns & Engineering Practices

| # | Pattern | Where |
| --- | --- | --- |
| P-0 | Fail early (engineering principle, not yet a code pattern). | Unit 0.1 |
| P-1 | Use `int` for counts and sizes; keep unsigned types for bits and bytes. | Unit 0.3 |
| P-2 | Check before you calculate, when overflow matters. | Unit 0.3 |
| P-3 | CLI convention: results to stdout, errors to stderr, non-zero exit code on failure. | Chapter 0 Project |
| P-4 | Validate input at the edge. | Chapter 0 Project |
| P-5 | Always format with `gofmt`. | Chapter 0 Project |
| P-6 | Name constants in MixedCaps, never ALL\_CAPS. | Unit 1.2 |
| P-7 | Bit flags for small sets of on/off options. | Unit 1.4 |
| P-8 | Never use floats for money; use integer minor units. | Unit 1.5 |
| P-9 | Guard clauses: handle problems first, keep the happy path un-indented. | Unit 1.6 |
| P-10 | `(result, error)` with the error last. | Unit 1.8 |
| P-11 | Keep scopes small, but watch your `:=`. | Unit 1.9 |
| P-12 | Closures for small, local behaviour; structs for real state. | Unit 1.10 |
| P-13 | Acquire, check, then defer the cleanup. | Unit 1.11 |
| P-14 | Keep `main` tiny: `func run() error` + one `os.Exit`. | Unit 1.12 |
| P-15 | Secrets come from crypto/rand, always. | Unit 1.13 |
| P-16 | Arrays for fixed-size values, slices for lists. | Unit 2.1 |
| P-17 | Pre-size slices with `make([]T, 0, n)` when n is known or estimable. | Unit 2.3 |
| P-18 | Functions that may grow a slice return it. | Unit 2.3 |
| P-19 | Copy out small pieces of large buffers. | Unit 2.4 |
| P-20 | Parse with `strconv`, not `fmt.Sscan`, for single values; always keep the error. | Unit 2.6 |
| P-21 | Sort keys for any output a human or a test reads. | Unit 2.8 |
| P-22 | Pick value or pointer semantics per type, and stay consistent. | Unit 2.12 |
| P-23 | Consumer-defined, minimal interfaces. | Unit 3.4 |
| P-24 | Decorate with embedded interfaces. | Unit 3.7 |
| P-25 | Constructors that validate; unexported fields that protect invariants. | Unit 3.8 |
| P-26 | Wrap with context at every layer boundary; inspect only with `errors.Is`/`As`. | Unit 3.10 |
| P-27 | Generics for algorithms and containers; interfaces for behaviour. | Unit 3.15 |
| P-28 | Inject time, randomness, and I/O; keep the core pure. | Unit 4.4 |
| P-29 | Write functions against `io.Reader`/`io.Writer`, not file names. | Unit 5.1 |
| P-30 | Separate wire types from domain types. | Unit 5.4 |
| P-31 | Pick data structures by access pattern, then verify by measurement. | Unit 6.13 |
| P-32 | Confine state to one goroutine, or guard it with a documented mutex. | Unit 7.5 |
| P-33 | Context first, everywhere work can block. | Unit 7.9 |
| P-34 | One error-to-status mapping per service. | Unit 8.4 |
| P-35 | Prefer one atomic statement; otherwise lock or serialize — and retry. | Unit 9.4 |
| P-36 | Cache-aside with TTL, negative caching, and singleflight; the cache is never required. | Unit 9.7 |
| P-37 | Instrument RED for every endpoint and USE for every resource, from day one. | Unit 11.5 |
| P-38 | At-least-once delivery + idempotent handlers + bounded retries with jittered backoff + a dead-letter queue. | Unit 12.7 |
