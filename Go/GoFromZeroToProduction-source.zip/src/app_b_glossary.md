# Appendix B — Glossary

Short, plain definitions of the terms used in this book. The unit where a term is taught explains it fully.

| Term | Meaning |
| --- | --- |
| A* (A-star) | Shortest-path search that adds a lower-bound estimate of the remaining cost to Dijkstra's priority, steering the search towards the target (Unit 13.6) |
| Address | The number of one byte-sized box in memory |
| Admissible heuristic | An estimate that never overestimates the true remaining cost; keeps A* optimal |
| Allocation | Reserving memory for a value, usually on the heap; measured by benchmarks with -benchmem |
| ALT | A*, Landmarks, Triangle inequality: A* with precomputed landmark distances as a tighter heuristic (Unit 13.7) |
| Amortised cost | Average cost per operation over a long sequence, e.g. append is O(1) amortised although it sometimes copies |
| API | Application Programming Interface: the operations a package or service offers to its users |
| Atomic operation | A memory operation that happens indivisibly, with no data race (sync/atomic) |
| Backpressure | Slowing producers down when consumers cannot keep up, instead of buffering without limit |
| Benchmark | A function BenchmarkXxx(b *testing.B) that measures the time and allocations of code |
| Big-O notation | Describes how cost grows with input size, ignoring constants: O(1), O(log n), O(n), O(n log n), O(n²) |
| Binary | Base-2 number system; only digits 0 and 1 |
| Binary / executable | A file containing machine code that the computer can run directly |
| Binary search | Finding a value in sorted data by repeatedly halving the range; O(log n) |
| Bit | One 0-or-1 value; the smallest unit of data |
| Blank identifier | The name _, used to ignore a value |
| Buffered channel | A channel with capacity; sends block only when the buffer is full |
| Build tag (build constraint) | A //go:build line that includes a file only for certain OSes, architectures, or tags |
| Byte | 8 bits; can hold 256 different values (0 to 255) |
| Byte slice ([]byte) | A mutable sequence of bytes; the usual type for I/O buffers |
| Cache (CPU) | Small, fast memory near the CPU core holding recently used data in 64-byte lines |
| Cache-aside | Read from the cache, on a miss read the database and fill the cache (P-36) |
| CAP theorem | During a network partition a distributed system must choose between consistency and availability |
| Capacity (cap) | How many elements a slice's backing array can hold from the slice's start |
| Channel | A typed conduit for sending values between goroutines, with optional buffering |
| Circuit breaker | Stops calling a failing dependency for a while so it can recover and callers fail fast |
| Closure | A function value that refers to variables from the scope where it was created |
| Compile error | ANY reason the compiler refuses to build; no program is produced |
| Compile time | The moment the compiler checks and translates code, before running |
| Compiler | A program that translates your whole source code into machine code before it runs |
| Composite literal | A literal that builds a struct, array, slice, or map value: Point{X: 1} |
| Concurrency | Structuring a program as independently executing tasks; not necessarily simultaneous |
| Connection pool | A set of reusable open connections (database/sql and http.Transport keep one) |
| Consensus | Agreement among distributed nodes on a value despite failures (Raft, Paxos) |
| Context (context.Context) | Carries cancellation, deadlines, and request-scoped values across API boundaries |
| Contraction hierarchies (CH) | Routing preprocessing that adds shortcut edges so queries search only upwards in a node ordering |
| CPU | The chip that executes instructions, one tiny step at a time, very fast |
| CSR (compressed sparse row) | Graph storage as flat arrays: First[v]..First[v+1] index the edges of node v |
| Data race | Two goroutines access the same memory concurrently, at least one writes, without synchronisation; undefined behaviour |
| Deadlock | Goroutines waiting for each other forever; Go reports it when all goroutines are blocked |
| Defer | Schedules a function call to run when the surrounding function returns |
| Dependency injection | Passing a component its dependencies (often as interfaces) instead of creating them inside |
| Differential testing | Comparing a fast implementation's results with a simple, trusted one on many inputs |
| Dijkstra's algorithm | Shortest paths with non-negative edge weights by settling nodes in order of distance |
| ELF / PE / Mach-O | Executable file formats: ELF for Linux, PE (.exe) for Windows, Mach-O for macOS |
| Embedding | Including a type in a struct without a field name, promoting its fields and methods |
| Endianness | The order in which the bytes of a multi-byte number are stored |
| Error wrapping | Adding context to an error while keeping the original inspectable with errors.Is/As (%w) |
| Escape analysis | The compiler's decision whether a value can live on the stack or must move to the heap |
| Eventual consistency | Replicas may differ temporarily but converge when updates stop |
| Exactly-once (effectively) | At-least-once delivery combined with idempotent processing |
| Exit code | A number a finished process gives to the OS; 0 = success |
| Fan-in / fan-out | Merging several channels into one / distributing work from one source to many workers |
| Fuzzing | Automatically generating inputs to find crashes or broken properties (go test -fuzz) |
| Garbage collector (GC) | Runtime component that frees heap memory no longer reachable; Go's is concurrent mark-sweep |
| Generics | Functions and types with type parameters, constrained by interfaces (Go 1.18+) |
| Geohash | A string encoding of a lat/lon cell; nearby points usually share a prefix |
| GOARCH | Go setting that picks the target CPU type, e.g. amd64, arm64 |
| GOGC | Percentage of heap growth that triggers the next GC cycle (default 100) |
| GOMAXPROCS | Number of OS threads that can execute Go code simultaneously |
| GOMEMLIMIT | Soft memory limit for the Go runtime; the GC works harder as it is approached |
| GOOS | Go setting that picks the target operating system, e.g. linux, windows, darwin |
| Goroutine | A lightweight function execution managed by the Go scheduler; starts with a small stack |
| Goroutine leak | A goroutine blocked forever, holding its memory; usually a channel nobody will send to or receive from |
| gRPC | An RPC framework using HTTP/2 and Protocol Buffers |
| Haversine formula | Great-circle distance between two lat/lon points on a sphere |
| Heap (data structure) | A tree in an array where each parent is ≤ its children; gives a priority queue |
| Heap (memory) | Memory for values whose lifetime is not tied to one function call; managed by the GC |
| Hexadecimal (hex) | Base-16 system, digits 0-9 and A-F; one hex digit = 4 bits |
| Hot reload | Replacing data or configuration in a running service without downtime |
| Idempotency | Doing an operation twice has the same effect as doing it once |
| Idempotency key | A client-supplied ID letting a server recognise and deduplicate retried requests |
| IEEE 754 | The worldwide standard for how float numbers are stored and calculated |
| Inf | Special float value meaning infinity (+Inf or -Inf) |
| Interface | A type defined by a method set; any type with those methods satisfies it implicitly |
| Interpreter | A program that reads and runs source code directly, step by step, while running |
| Iterator (range-over-func) | A function of type iter.Seq or iter.Seq2 that a for-range loop can consume (Go 1.23+) |
| Latency percentile (p50, p99) | The latency below which 50% or 99% of requests complete |
| Literal | A value written directly in code, like `42`, `0xFF`, or `"hi"` |
| Load shedding | Rejecting some requests early under overload to keep serving the rest well |
| Machine code | Instructions in the CPU's own language (just bytes) |
| Map (Go) | A built-in hash table from keys to values; iteration order is unspecified |
| Memory model | The rules for when a write in one goroutine is guaranteed visible to a read in another |
| Method set | The methods callable on a type; decides which interfaces it satisfies |
| Migration (database) | A versioned, ordered change to a database schema |
| Module | A versioned collection of packages defined by a go.mod file |
| Mutex | A lock giving one goroutine at a time exclusive access (sync.Mutex) |
| NaN | "Not a Number": special float value for undefined results like 0.0/0.0 |
| Nil | The zero value for pointers, slices, maps, channels, functions, and interfaces |
| Nil interface vs interface holding nil | An interface is nil only if both its type and value are nil |
| Observability | Understanding a system's internal state from logs, metrics, and traces |
| Octal | Base-8 system; Go literals start with `0o` (or an old-style leading `0`) |
| OpenStreetMap (OSM) | A free, editable world map; data as nodes, ways, relations, and tags |
| Outbox pattern | Writing an event to a database table in the same transaction as the change, then publishing it |
| Package | A directory of Go files compiled together; the unit of encapsulation |
| Panic | Go's name for a serious run-time error that stops the program unless handled |
| Parallelism | Actually executing multiple tasks at the same instant on multiple cores |
| PGO (profile-guided optimisation) | Compiling with a CPU profile so the compiler optimises hot paths |
| Pointer | A value holding the address of another value |
| Polyline (encoded) | Google's compact string encoding of a sequence of coordinates |
| pprof | Go's profiler and its tools for CPU, memory, goroutine, block, and mutex profiles |
| Priority queue | A collection that always yields its smallest (or largest) element next |
| Process | A program that is currently running, with its own memory given by the OS |
| Projection (map) | A mapping from the sphere to a plane, e.g. Web Mercator; always distorts something |
| R-tree | A balanced tree of bounding rectangles for indexing spatial objects |
| Race detector | Tool enabled by -race that reports data races observed at run time |
| RAM | The computer's main working memory; fast, and cleared when power goes off |
| Read replica | A database copy that serves reads; may lag behind the primary |
| Receiver | The value a method is called on; value or pointer receiver |
| Reflection | Inspecting and manipulating types and values at run time (package reflect) |
| Run time | The period when the program is actually executing |
| Rune | An int32 holding a Unicode code point |
| Saga | A sequence of local transactions with compensating actions instead of one distributed transaction |
| Scheduler (Go) | Runtime component that multiplexes goroutines onto OS threads (the G-M-P model) |
| Select | Statement waiting on several channel operations, proceeding with one that is ready |
| Semaphore | Limits how many goroutines may do something at once; often a buffered channel |
| Sharding | Splitting data across several machines by key |
| singleflight | Collapsing concurrent identical calls into one execution (golang.org/x/sync/singleflight) |
| SKIP LOCKED | PostgreSQL row-locking option that lets many workers claim different queue rows |
| Slice | A view (pointer, length, capacity) onto a backing array |
| SLO / SLI | Service level objective (target) and indicator (the measured quantity), e.g. p99 < 50 ms |
| Snapping (map matching) | Moving a coordinate to the nearest point on the road network |
| Source code | The human-readable text you write, e.g. main.go |
| SQL injection | An attack where input is executed as SQL; prevented by parameterised queries |
| Stack (memory) | Per-goroutine memory for function calls' local values; grows automatically |
| Stack trace | The list of function calls printed when a panic happens, showing where it failed |
| Struct | A composite type grouping named fields |
| Struct tag | A string attached to a struct field read by packages like encoding/json |
| Syntax error | Grammar of the code is broken (missing bracket, brace, etc.); one kind of compile error |
| System call | A request from a program to the OS, e.g. "write this text to the screen" |
| Table-driven test | A test that loops over a slice of cases with inputs and expected outputs |
| Transaction | A group of database operations that commit or roll back together (ACID) |
| Transaction isolation level | How much concurrent transactions can see of each other: read committed, repeatable read, serializable |
| Type assertion | x.(T): extracts the concrete type T from an interface value |
| Type error | Code has correct grammar but mixes types wrongly, e.g. string + int |
| Type parameter | A placeholder type in a generic function or type, e.g. [T any] |
| Type switch | A switch on an interface value's dynamic type |
| UTF-8 | Variable-length encoding of Unicode in 1–4 bytes; Go source and strings use it |
| Variadic function | A function whose last parameter accepts any number of arguments (...T) |
| WaitGroup | Waits for a collection of goroutines to finish (sync.WaitGroup) |
| WGS84 | The world geodetic system used by GPS; standard lat/lon coordinates |
| Worker pool | A fixed number of goroutines processing jobs from a channel |
| Zero value | The value a variable has when declared without initialisation: 0, "", false, nil, … |
