import re, sys
from pathlib import Path
book = Path("build/GoApprenticeship.md").read_text()
defs = {}
for kind in ("DT", "P"):
    nums = [int(n) for n in re.findall(rf"^\*\*{kind}-(\d+)\.", book, re.M)]
    dup = {n for n in nums if nums.count(n) > 1}
    missing = set(range(min(nums), max(nums)+1)) - set(nums)
    print(kind, "count", len(nums), "range", min(nums), max(nums), "dups", sorted(dup), "missing", sorted(missing))
    defs[kind] = set(nums)
    refs = {int(n) for n in re.findall(rf"\b{kind}-(\d+)\b", book)}
    print(kind, "dangling refs", sorted(refs - defs[kind]))
units = set(re.findall(r"^## Unit (\d+\.\d+)", book, re.M))
refs = set(re.findall(r"\bUnits? (\d+\.\d+)", book)) | set(re.findall(r"\bUnits? \d+\.\d+(?:,| and| or) (\d+\.\d+)", book))
print("units", len(units), "dangling unit refs", sorted(refs - units, key=lambda s: tuple(map(int, s.split(".")))))
for pat in ["you asked", "your question", "earlier you", "in our session", "last session", "you told me", "Stage [0-9]", "Kamaal", "whyminds", "TODO", "FIXME", "@@"]:
    hits = [l for l in book.splitlines() if re.search(pat, l, re.I)]
    if hits: print("PATTERN", pat, len(hits), hits[:3])
