---
title: "Rust from Zero to Expert"
subtitle: "A complete course in Rust (2024 edition) — from ownership to a crash-tested, persistent network server"
lang: en
---

# Preface

Rust is a systems programming language with the performance of C and C++ and a compiler that rules out, before the program runs, the memory-safety bugs and data races that cause most security vulnerabilities and many crashes in systems software. It is used in operating-system kernels (Linux and Windows), browsers, databases, cloud infrastructure, command-line tools, embedded devices, and WebAssembly.

Rust's reputation for difficulty comes almost entirely from one idea: **ownership** — who owns each value, who may look at it, and who may change it. This book puts that idea at the centre, explains the rules precisely, and shows what the compiler does with them. After Chapter 2, the rest of the language is built on what you already know.

The book begins with the toolchain and how Rust compiles, then covers core syntax and types, ownership and borrowing, structs and enums, error handling, traits and generics, collections and iterators, crates and testing, smart pointers, threads, async Rust with Tokio, unsafe code and FFI, macros, and performance. It ends with a capstone: a networked key-value store with a write-ahead log, group commit, snapshots, and crash recovery, tested by killing it in the middle of writes.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the language's guarantees, the standard library's documented behaviour, Cargo, the compiler, the operating system, or established practice.
2. **Evidence.** Every program in this book was compiled and run with Rust 1.97, and every output shown is real — including compiler errors, which are part of how Rust teaches. When an example's first version was wrong, or an expected speed-up did not happen (several did not), the book shows that too.
3. **Order.** Nothing is used before it is taught, and later chapters refer back by unit number.

This book is the third in a series with *C from Zero to Systems* and *C++ from Zero to Expert*. You do not need them — no previous language is assumed — but where Rust's choice is easiest to understand by contrast (move semantics, undefined behaviour, data races, iterator invalidation), the book shows the C or C++ program that compiles and fails, and the Rust program that does not compile.

# How to use this book

## Who it is for

- **Beginners** who are willing to work carefully: start at Chapter 0 and read in order.
- **Programmers from garbage-collected languages** (Python, Java, Go, JavaScript): read Chapter 1 quickly; spend real time on Chapters 2, 5, and 8.
- **C and C++ programmers:** Chapter 2 will feel both familiar and strict; the *Deep & Tricky* entries compare Rust's rules with C's and C++'s throughout. Chapters 9, 11, and 13 are where your experience pays off most.
- **Working Rust programmers:** use Appendix A to test yourself, then focus on Chapters 10–14.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | The rules, with small complete programs and their real output — including compiler errors. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, each labelled with its source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions: decide the answer before running the code. Answers are at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a specification, a complete reference solution with real output, and a review checklist. Try the project yourself first.

## How to study

1. **Type the programs and run them.** Compare your output with the book's.
2. **Read every compiler error to the end.** Rust's errors usually explain the rule you broke and suggest the fix; `rustc --explain E0502` gives the full story.
3. **Predict before you run,** especially whether code compiles. When you are wrong, find out why.
4. **Break things on purpose:** remove a `move`, add a second `&mut`, drop a value too early — and read what the compiler says.
5. **Use the tools from day one:** `cargo check`, `cargo clippy`, `cargo fmt`, `cargo test` (Chapter 0).
6. **Revise with Appendix A,** which lists every DT and P entry by title.

## How to read the labels

| Label | Meaning |
| --- | --- |
| *Guarantee: Rust language* | What the language guarantees (the Rust Reference); holds for every conforming compiler and future versions within an edition. |
| *Guarantee: Rust standard library* | Documented, stable behaviour of `std`. |
| *Library behaviour* | How a library (`std`, Tokio) behaves where its documentation describes the behaviour but it is not a language rule. |
| *Compiler behaviour*, *Toolchain behaviour*, *Cargo behaviour* | What rustc, the linker, or Cargo do. Stable in practice; may change between versions. |
| *OS behaviour*, *Runtime behaviour* | Properties of the operating system or of an async runtime. |
| *Design fact*, *Practice* | Engineering consequences and professional practice — experience, not language rules. |

## Toolchain and versions

All code was compiled and run on **Linux x86-64 (Ubuntu 24.04)** with:

- **Rust 1.97** (stable, July 2026), **edition 2024**, with Cargo, rustfmt, and Clippy;
- crates from crates.io, at the versions recorded in each project's `Cargo.lock` (Tokio 1, Rayon 1, Criterion 0.5, syn 2, anyhow 1, thiserror 2, memmap2 0.9, rustc-hash 2, crc32fast 1);
- **GCC 13** for the C side of FFI, **Valgrind 3.22**, **strace**, and **perf** (software clock sampling; hardware counters were not available in the virtual machine), and the system **zlib** (zlib-ng 1.3.1 in compatibility mode).

Two tools could not be used and the text says so where they matter: **Miri**, the undefined-behaviour interpreter, and Rust's sanitizers both require a nightly toolchain, which could not be installed in the build environment. Chapter 11 uses Valgrind instead and shows how to run Miri.

Measurements (Chapters 5, 6, 7, 9, 10, 13, 14) were taken on a 2-core virtual machine. Your numbers will differ; compare ratios and shapes, and expect run-to-run variation, which the text reports where it is large.

## Setting up

1. Install Rust with **rustup** from rust-lang.org: `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh` on Linux and macOS, or the installer on Windows. It installs `rustc`, `cargo`, `rustfmt`, and `clippy`, and keeps them updated (`rustup update`).
2. Check: `rustc --version`, `cargo --version`. For Chapter 11's Miri: `rustup toolchain install nightly --component miri`.
3. Use an editor with **rust-analyzer** (VS Code, RustRover, Neovim, Emacs, Zed, Helix). It shows types, errors, and inlay hints as you type, and runs Clippy on save.
4. On Windows, everything except the Unix-specific parts of Chapters 11 and 13 (Valgrind, `perf`, `strace`) works natively; use WSL2 for those.

# Roadmap

| Chapter | Title | You will be able to… |
| --- | --- | --- |
| 0 | The Rust Toolchain and How Rust Compiles | build with rustc and Cargo; explain crates, monomorphisation, and profiles; use fmt, clippy, test, doc |
| 1 | Core Syntax and Types | use variables, scalar and compound types, strings, functions, control flow, formatting, and input |
| 2 | Ownership, Borrowing, and Lifetimes | predict moves, copies, and drops; borrow within the rules; write lifetime annotations |
| 3 | Structs, Enums, and Pattern Matching | model data so invalid states are unrepresentable; match exhaustively |
| 4 | Error Handling | separate bugs (panic) from failures (`Result`); design error types; use `?`, anyhow, thiserror |
| 5 | Traits and Generics | write generic code with trait bounds; use trait objects; implement standard traits |
| 6 | Collections, Closures, and Iterators | use the standard collections; write closures; build zero-cost iterator pipelines |
| 7 | Modules, Crates, Workspaces, Testing, Docs | organise code and crates; manage dependencies and features; test and document |
| 8 | Smart Pointers and Interior Mutability | use `Box`, `Rc`, `Weak`, `Cell`, `RefCell`, `Cow`; choose arenas over pointer graphs |
| 9 | Concurrency | use threads, `Send`/`Sync`, channels, locks, atomics, and Rayon; design for independence |
| 10 | Async Rust | explain futures and executors; write Tokio servers; handle timeouts and cancellation |
| 11 | Unsafe Rust, FFI, and the Memory Model | write sound unsafe code; call C and be called from C; wrap a C library safely |
| 12 | Macros | write declarative and procedural macros with good errors |
| 13 | Performance and Systems Programming | benchmark, profile, remove allocations, read assembly; do efficient I/O and process control |
| 14 | Capstone: A Persistent Key-Value Store | design, build, crash-test, and load-test a durable network server |
| A | Index of Deep & Tricky entries and Patterns | revise every entry by title |
| B | Glossary | look up any term |
| C | Editions, versions, and toolchain | see what each edition changed and which features need which Rust version |

Chapters 0–6 are the **foundation**; read them in order. Chapter 7 can be read at any point after Chapter 4. Chapters 8–13 can be read in any order after Chapter 7, except that Chapter 10 builds on Chapter 9. Chapter 14 uses the whole book.
