# Appendix A — Index of Deep & Tricky entries and Patterns

Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, with the unit where it is explained. Use it for revision: read each title and explain the entry before looking it up.

## Deep & Tricky

| # | Entry | Where |
| --- | --- | --- |
| DT-1 | Safe Rust guarantees no undefined behaviour — but the guarantee is only as strong as the `unsafe` code underneath it. | Unit 0.1 |
| DT-2 | Integer overflow panics in debug builds and wraps in release builds — and neither is undefined behaviour. | Unit 0.3 |
| DT-3 | The crate, not the file, is the unit of compilation — so a large crate rebuilds as a whole. | Unit 0.4 |
| DT-4 | `as` from a float to an integer saturates, and NaN becomes 0 — it is never undefined behaviour. | Unit 1.2 |
| DT-5 | Arrays are `Copy` when their elements are, so passing `[i32; 1000]` to a function or assigning it copies 4000 bytes — and a large array declared as a local lives on the stack, where `[0u8; 16 * 1024 * 1024]` overflows the main thread's 8 MiB stack. | Unit 1.3 |
| DT-6 | `len()` on a string counts bytes, and slicing in the middle of a character panics. | Unit 1.4 |
| DT-7 | `f64` does not implement `Ord`, so `sort()` and `max()` do not compile on floats. | Unit 1.8 |
| DT-8 | A move is a bitwise copy of the value's bytes — the compiler then forbids using the source. | Unit 2.1 |
| DT-9 | `&mut` means *exclusive*, not just *mutable* — and the compiler optimises on that guarantee. | Unit 2.3 |
| DT-10 | Returning a reference into a value you create inside the function is always an error — but the fix depends on *why* you wanted a reference. If the caller needs the data, return the owned value (`String`, not `&str`); if the data is constant, return `&'static str`; if it is a view of an argument, tie the lifetimes together. | Unit 2.4 |
| DT-11 | `T: 'static` does not mean "lives forever"; it means "contains no borrows shorter than the whole program". | Unit 2.6 |
| DT-12 | Struct update syntax moves the fields it copies — which can make the source partially moved. | Unit 3.1 |
| DT-13 | Derived `PartialOrd`/`Ord` compare fields in declaration order, so reordering fields silently changes sorting. | Unit 3.3 |
| DT-14 | `Option<&T>`, `Option<Box<T>>`, and `Option<NonZeroU32>` cost nothing extra: the compiler stores `None` in an impossible value (a "niche"). | Unit 3.4 |
| DT-15 | A temporary created in the scrutinee of `if let` / `while let` / `match` lives until the end of the whole statement — so `if let Some(x) = mutex.lock().unwrap().get(0) { ... }` holds the lock for the entire `if let` body *and* its `else` branch. Edition 2024 shortened this for `if let` (the temporary is dropped before `else`), but `match` and `while let` keep the old rule. | Unit 3.6 |
| DT-16 | `?` converts the error with `From::from`, so a function can use `?` on several different error types only if its own error type has a `From` impl for each. | Unit 4.2 |
| DT-17 | `Box<dyn Error>` is not `Send + Sync`, so it cannot be sent across threads or held across an `.await` in a spawned Tokio task; library code that returns `Box<dyn Error>` forces that limit on every caller. Use `Box<dyn Error + Send + Sync + 'static>` (what `anyhow::Error` wraps), or a concrete error enum. | Unit 4.4 |
| DT-18 | A panic while already unwinding aborts the process — so `Drop` implementations must not panic. | Unit 4.5 |
| DT-19 | The orphan rule: you may implement a trait for a type only if your crate defines the trait or the type. | Unit 5.1 |
| DT-20 | Only *dyn-compatible* traits can be used as `dyn Trait`: no generic methods, no methods returning `Self`, no associated constants. | Unit 5.4 |
| DT-21 | `HashMap`'s default hasher is SipHash-1-3 with a random key — chosen for resistance to hash-flooding attacks, not for speed. | Unit 6.2 |
| DT-22 | Since Rust 2021, closures capture *disjoint fields*, not whole variables. | Unit 6.3 |
| DT-23 | Each closure has its own unique, unnameable type — even two closures with identical code — so `vec![¦x¦ x + 1, ¦x¦ x + 2]` does not compile, and `if c { ¦x¦ x + 1 } else { ¦x¦ x * 2 }` does not either. Store them as `Box<dyn Fn(i32) -> i32>` (or `fn(i32) -> i32` when they capture nothing: non-capturing closures coerce to function pointers). | Unit 6.3 |
| DT-24 | Iterator adaptors are lazy: an adaptor chain that is never consumed does nothing, and side effects inside it run in an interleaved order. | Unit 6.5 |
| DT-25 | Features are unified across the whole dependency graph: if any crate enables a feature of a dependency, every user of that dependency gets it. | Unit 7.2 |
| DT-26 | Cargo picks the newest compatible version of each dependency, and `Cargo.lock` freezes that choice. | Unit 7.2 |
| DT-27 | Integration tests in `tests/` can only test a library crate — a binary-only package has nothing for them to import. | Unit 7.4 |
| DT-28 | By default, serde *ignores* unknown fields when deserialising, so a misspelt key in a config file (`"replica": 3` for `replicas`) is silently dropped and the default is used. Add `#[serde(deny_unknown_fields)]` to configuration types, where a typo should be an error. | Unit 7.6 |
| DT-29 | `let _ = value;` drops immediately; `let _guard = value;` lives to the end of the scope. | Unit 8.2 |
| DT-30 | A `RefCell` borrow held across a call can panic far from the bug — keep borrows in the narrowest scope. | Unit 8.4 |
| DT-31 | `Send` and `Sync` are checked only at thread boundaries — but they are inferred from every field, so one non-`Sync` field anywhere makes the whole type non-`Sync`. | Unit 9.2 |
| DT-32 | Rust prevents data races, not deadlocks — and a `MutexGuard` held across an `await` or a long call is the usual way to create one. | Unit 9.4 |
| DT-33 | A thread that panics while holding a `Mutex` *poisons* it: every later `lock()` returns `Err(PoisonError)`, so the common `lock().unwrap()` turns one thread's panic into a panic in every thread that touches the lock. The data may be half-updated; if you know it is still consistent, `into_inner()` on the error recovers the guard. | Unit 9.4 |
| DT-34 | Futures are lazy: calling an `async fn` does nothing until the future is polled — and a future that is never awaited never runs. | Unit 10.1 |
| DT-35 | A future may be moved before it is first polled but not after — which is what `Pin` expresses. | Unit 10.1 |
| DT-36 | Blocking inside an async task stalls every task scheduled on that worker thread. | Unit 10.3 |
| DT-37 | In `select!`, a branch's future is dropped when another wins — so a future that has partly completed its work loses that work. | Unit 10.5 |
| DT-38 | Creating a `&mut` that aliases another live reference is undefined behaviour even if neither is ever used to write. | Unit 11.2 |
| DT-39 | C macros and inline functions are not symbols, so FFI cannot call them — find the function the macro expands to. | Unit 11.5 |
| DT-40 | Macro hygiene: identifiers created inside a macro cannot see or shadow the caller's — but items (functions, types, statics) are not hygienic. | Unit 12.2 |
| DT-41 | Procedural macros are compiled for and run on the build machine, inside the compiler — and they can run arbitrary code. | Unit 12.3 |
| DT-42 | Rust reorders struct fields to minimise padding, unless you ask it not to. | Unit 13.4 |
| DT-43 | `write` and `flush` do not make data durable, and dropping a `File` does not `fsync` it. | Unit 14.2 |
| DT-44 | Recovery must be idempotent: replaying a log onto the state it already produced must change nothing. | Unit 14.3 |

## Patterns

| # | Pattern | Where |
| --- | --- | --- |
| P-1 | Make `cargo fmt --check`, `cargo clippy -- -D warnings`, and `cargo test` the gate for every change. | Unit 0.5 |
| P-2 | Take parameters by reference unless the function needs to own the value. | Unit 2.5 |
| P-3 | Make invalid states unrepresentable. | Unit 3.6 |
| P-4 | Libraries return typed errors; applications use `anyhow` with context. | Unit 4.4 |
| P-5 | Prefer generics for performance and for single-type call sites; prefer trait objects for heterogeneous collections, plugin boundaries, and keeping compile times and binary size down. | Unit 5.5 |
| P-6 | Write data processing as iterator pipelines; fall back to a `for` loop when the logic has early exits across several collections or complex state. | Unit 6.5 |
| P-7 | Keep `main.rs` thin and put logic in a library; give each public item a doc comment with a tested example. | Unit 7.5 |
| P-8 | For graphs and trees with back-links, prefer an arena with indices over `Rc<RefCell<T>>`. | Unit 8.5 |
| P-9 | Prefer, in order: no sharing (move data to threads, collect results), message passing, then shared state behind a lock — and reach for atomics only for simple counters and flags, or with a proven algorithm. | Unit 9.6 |
| P-10 | Use async for many concurrent waits; use threads (or `spawn_blocking`/Rayon) for computation; and give each piece of shared state one owner task. | Unit 10.5 |
| P-11 | Wrap every C library in two layers: a raw `-sys` layer of exact declarations, and a safe layer that owns resources with RAII and turns error codes into `Result`. | Unit 11.5 |
| P-12 | Use a function first, generics second, a declarative macro third, and a procedural macro last. | Unit 12.4 |
| P-13 | Before optimising Rust code, check the four usual suspects: a debug build, unbuffered I/O, per-item allocation, and SipHash on hot maps. | Unit 13.5 |
| P-14 | Give mutable state a single owner thread, and let everything else send it messages. | Unit 14.4 |
