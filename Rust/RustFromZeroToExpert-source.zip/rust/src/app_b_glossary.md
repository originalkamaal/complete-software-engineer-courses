# Appendix B — Glossary

Short definitions of the terms used in this book. The unit given (where there is one) explains the term fully.

| Term | Meaning |
| --- | --- |
| Actor | A task or thread that exclusively owns some state and receives commands as messages (Units 10.4, 14.4) |
| Arc | Atomically reference-counted shared pointer; the thread-safe `Rc` (Unit 9.4) |
| Arena | A collection that owns many objects, referred to by index rather than by pointer (P-8) |
| Associated type | A type named inside a trait and fixed by each implementation, e.g. `Iterator::Item` (Unit 5.5) |
| `async` / `.await` | Syntax that turns a function or block into a future, and waits for a future without blocking the thread (Unit 10.1) |
| Auto trait | A trait the compiler implements automatically from a type's fields: `Send`, `Sync`, `Unpin` (Unit 9.2) |
| Blanket implementation | `impl<T: Bound> Trait for T`: implements a trait for every type meeting a bound (Unit 5.5) |
| Borrow checker | The compiler pass that enforces the borrowing and lifetime rules on MIR (Units 0.4, 2.3) |
| Borrowing | Accessing a value through a reference without taking ownership (Unit 2.3) |
| `Box<T>` | An owning pointer to a heap value (Unit 8.1) |
| Cargo | Rust's build tool and package manager (Unit 0.3) |
| Clippy | The official linter: hundreds of checks for bugs, performance, and style (Unit 0.5) |
| Closure | An anonymous function that can capture variables from its environment (Unit 6.3) |
| Coherence | The guarantee that at most one implementation of a trait exists for a type, enforced by the orphan rule (DT-19) |
| `Copy` | A marker trait for types duplicated by a plain bit copy instead of being moved (Unit 2.1) |
| `Cow` | Clone-on-write: either borrowed or owned data (Unit 8.6) |
| Crate | The unit of compilation: a library or a binary (Units 0.4, 7.2) |
| Data race | Unsynchronised concurrent access to memory, at least one a write; impossible in safe Rust (Chapter 9) |
| Deref coercion | Automatic conversion of `&Wrapper` to `&Target` through `Deref`, e.g. `&String` to `&str` (Unit 8.2) |
| Derive | `#[derive(...)]`: generates trait implementations from a type's definition (Unit 3.3) |
| Doctest | A code example in a documentation comment, compiled and run by `cargo test` (Unit 7.4) |
| `Drop` | The trait whose method runs when a value goes out of scope (Units 2.1, 8.2) |
| `dyn Trait` | A trait object: a value of some type implementing the trait, dispatched through a vtable (Unit 5.4) |
| Edition | A versioned set of language rules chosen per crate (2015, 2018, 2021, 2024) (Unit 0.1, Appendix C) |
| Enum | A type whose value is one of several variants, each of which may carry data (Unit 3.4) |
| Executor | The part of an async runtime that polls futures when they can make progress (Unit 10.1) |
| Fat pointer | A pointer plus extra data: a length for slices and `str`, a vtable for trait objects (Unit 5.4) |
| Feature (Cargo) | A named, additive switch that enables optional code and dependencies (Unit 7.2) |
| FFI | Foreign function interface: calling C from Rust and Rust from C (Units 11.4, 11.5) |
| `Fn` / `FnMut` / `FnOnce` | The traits of closures that read, modify, or consume their captures (Unit 6.3) |
| Future | A value representing a computation that may not have finished; polled to completion (Unit 10.1) |
| Generic | Code parameterised over types, specialised by monomorphisation (Unit 5.2) |
| Group commit | Making a batch of writes durable with one disk sync (Unit 14.4) |
| Hygiene | The property that identifiers introduced by a macro cannot clash with the caller's (DT-40) |
| Interior mutability | Mutation through a shared reference, made safe by `Cell`, `RefCell`, `Mutex`, atomics (Unit 8.4) |
| Iterator | A type with a `next` method returning `Option<Item>`; the basis of `for` loops and adaptor chains (Unit 6.4) |
| Lifetime | The region of code in which a reference is valid; written `'a` (Unit 2.6) |
| Lifetime elision | Rules that let the compiler infer lifetime annotations in common function signatures (Unit 2.6) |
| MIR | Mid-level intermediate representation, where borrow checking runs (Unit 0.4) |
| Miri | An interpreter for Rust's MIR that detects undefined behaviour in unsafe code (Unit 11.2) |
| Monomorphisation | Generating a separate copy of generic code for each set of concrete type arguments (Unit 0.4) |
| Move | Transferring ownership; the source can no longer be used (Unit 2.1) |
| Niche | An impossible bit pattern of a type that the compiler uses to store an enum's tag (DT-14) |
| `Option<T>` | `Some(T)` or `None`; Rust's replacement for null (Unit 3.4) |
| Orphan rule | You may implement a trait for a type only if your crate defines one of them (DT-19) |
| Ownership | Each value has one owner, which drops it when it goes out of scope (Unit 2.1) |
| Panic | An unrecoverable error that unwinds (or aborts) the current thread (Unit 4.1) |
| `PhantomData` | A zero-sized marker that makes a type "use" a type parameter it does not store (Chapter 5 project) |
| `Pin` | A pointer wrapper guaranteeing the pointee will not move; needed for self-referential futures (DT-35) |
| Poisoning | A `Mutex` marking its data as possibly inconsistent after a panic while locked (Unit 9.4) |
| Procedural macro | A Rust function, run by the compiler, that transforms token streams (Unit 12.3) |
| `Rc` / `Weak` | A reference-counted shared pointer, and its non-owning counterpart (Units 8.3, 8.5) |
| `RefCell` | Interior mutability with borrowing rules checked at run time (Unit 8.4) |
| `Result<T, E>` | `Ok(T)` or `Err(E)`: the type of fallible operations (Unit 4.2) |
| Scoped thread | A thread that may borrow from its parent, joined before the scope ends (Unit 9.1) |
| `Send` / `Sync` | Marker traits: safe to move to / share with another thread (Unit 9.2) |
| Shadowing | Declaring a new variable with the name of an existing one (Unit 1.1) |
| Slice | A view `&[T]` or `&str` of a contiguous sequence: pointer plus length (Units 1.3, 2.5) |
| Soundness | The property that no safe code can cause undefined behaviour through an API (DT-1, Unit 11.3) |
| `'static` | The lifetime of the whole program; as a bound, "contains no shorter borrows" (DT-11) |
| Tokio | The most widely used async runtime (Unit 10.2) |
| Trait | A named set of methods a type can implement; Rust's mechanism for shared behaviour (Unit 5.1) |
| Undefined behaviour | Behaviour for which the language imposes no requirements; possible only through `unsafe` (Unit 11.1) |
| `unsafe` | A block, function, or trait whose correctness the programmer, not the compiler, guarantees (Unit 11.1) |
| Unwinding | Running destructors up the stack after a panic (Unit 4.1) |
| Vtable | A table of function pointers for one type's implementation of a trait (Unit 5.4) |
| WAL | Write-ahead log: changes are recorded durably before they are acknowledged (Unit 14.2) |
| Workspace | A set of packages sharing one `Cargo.lock` and `target/` directory (Unit 7.3) |
| Zero-cost abstraction | An abstraction that compiles to code as fast as the hand-written equivalent (Unit 6.4) |
