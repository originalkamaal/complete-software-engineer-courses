# Appendix C — Editions, Versions, and Toolchain

## Release model

A new stable Rust compiler is released **every six weeks**, and each release is backwards compatible with code written for earlier stable releases of the same edition. A crate declares a **minimum supported Rust version** with `rust-version = "1.85"` in `Cargo.toml`; Cargo refuses to build it with an older compiler, and its resolver can prefer dependency versions compatible with it.

Changes that would break existing code are grouped into **editions**. Each crate chooses one in `Cargo.toml`, crates of different editions link together freely, and `cargo fix --edition` migrates code mechanically.

| Edition | Stable in | Main changes |
| --- | --- | --- |
| 2015 | Rust 1.0 (May 2015) | the original language |
| 2018 | Rust 1.31 | the module system as it is today (`crate::`, no `extern crate`); `dyn Trait` syntax; non-lexical lifetimes; `async`/`await` became reserved keywords |
| 2021 | Rust 1.56 | disjoint closure captures (DT-22); `IntoIterator` for arrays by value; Cargo feature resolver 2; panic macro consistency; reserved prefixes (`k#`, `f"..."`) |
| 2024 | Rust 1.85 (February 2025) | **the edition of this book.** `unsafe extern` blocks and `safe` items (Unit 11.4); unsafe operations inside `unsafe fn` need their own `unsafe` blocks (Unit 11.1); `unsafe(no_mangle)` and other unsafe attributes (Unit 11.5); `std::env::set_var` is `unsafe` (Unit 7.4); `static mut` references denied (use `&raw const`/`&raw mut`, Unit 9.5); temporary lifetimes shortened in `if let` and block tails (DT-30); RPIT lifetime capture rules; `gen` reserved; Cargo resolver 3 (MSRV-aware); `Future` and `IntoFuture` in the prelude |

## Language and library features by version

Features used in this book and the Rust version that stabilised them:

| Version | Features |
| --- | --- |
| 1.39 (2019) | `async`/`.await` |
| 1.45 | `as` from float to int saturates (DT-4) |
| 1.51 | const generics (`[T; N]` with generic `N`) |
| 1.53 | arrays implement `IntoIterator` |
| 1.58 | captured identifiers in format strings (`println!("{x}")`) |
| 1.63 | scoped threads (`std::thread::scope`) |
| 1.65 | `let`-`else`; generic associated types |
| 1.70 | `OnceCell`, `OnceLock`; `is_some_and` |
| 1.75 | `async fn` and `impl Trait` return types in traits |
| 1.77 | `offset_of!`; C-string literals `c"..."` |
| 1.80 | `LazyLock`, `LazyCell`; exclusive range patterns (`a..b` in `match`) |
| 1.81 | `#[expect(lint)]`; unwinding out of `extern "C"` functions aborts |
| 1.82 | `&raw const` / `&raw mut`; `unsafe extern` blocks; `Option::is_none_or` |
| 1.85 | edition 2024; async closures |
| 1.88 | `let` chains in `if` and `while` (edition 2024) |

Before using a newer feature in a library, check its `rust-version` and your users' compilers.

## Toolchain components

| Tool | Purpose | Chapter |
| --- | --- | --- |
| `rustup` | installs and updates toolchains (stable, beta, nightly) and components | 0 |
| `rustc` | the compiler | 0 |
| `cargo` | build, dependencies, test, bench, doc, publish | 0, 7 |
| `rustfmt` / `cargo fmt` | formatter | 0 |
| `clippy` / `cargo clippy` | linter | 0 |
| `rustdoc` / `cargo doc` | documentation generator | 7 |
| `rust-analyzer` | language server for editors | 0 |
| `miri` (nightly) | undefined-behaviour interpreter | 11 |
| `cargo bench` + Criterion | benchmarking | 13 |
| `cargo-expand`, `cargo-flamegraph`, `cargo-fuzz`, `cargo-udeps`, `cargo-deny`, `cargo-audit` | popular third-party Cargo subcommands: macro expansion, profiling, fuzzing, unused dependencies, licence and security policy | 12, 13 |
