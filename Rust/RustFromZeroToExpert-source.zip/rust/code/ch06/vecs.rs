// file: vecs.rs
fn main() {
    let mut v: Vec<i32> = Vec::new();
    let mut last_cap = v.capacity();
    for i in 0..100 {
        v.push(i);
        if v.capacity() != last_cap {
            print!("{} ", v.capacity());
            last_cap = v.capacity();
        }
    }
    println!("<- capacities while pushing 100 elements");

    let mut scores = vec![72, 95, 61, 88, 95, 40, 73, 88];
    scores.sort_unstable();
    scores.dedup();                                    // removes consecutive duplicates
    println!("sorted unique {scores:?}, has 88 at {:?}, 90 would go at {:?}",
             scores.binary_search(&88), scores.binary_search(&90));
    scores.retain(|&s| s >= 60);                       // keep passing scores
    let windows: Vec<i32> = scores.windows(2).map(|w| w[1] - w[0]).collect();
    println!("passing {scores:?}, gaps {windows:?}");
    for chunk in scores.chunks(2) {
        print!("{chunk:?} ");
    }
    println!();
    let drained: Vec<i32> = scores.drain(1..3).collect();
    println!("drained {drained:?}, left {scores:?}");
    let mut words = vec!["pear", "Fig", "apple", "banana"];
    words.sort_by_key(|w| w.to_lowercase());           // stable sort by a derived key
    println!("{words:?}");
}
