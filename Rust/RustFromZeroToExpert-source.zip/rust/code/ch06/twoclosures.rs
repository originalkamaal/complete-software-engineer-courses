fn main() { let k = 1; let v = vec![move |x: i32| x + k, move |x: i32| x + k]; }
