// file: iterators.rs
/// An iterator over the Fibonacci numbers that stops before overflow.
struct Fib {
    a: u64,
    b: u64,
    done: bool,
}

impl Iterator for Fib {
    type Item = u64;
    fn next(&mut self) -> Option<u64> {
        if self.done {
            return None;
        }
        let out = self.a;
        match self.a.checked_add(self.b) {
            Some(next) => (self.a, self.b) = (self.b, next),
            None => self.done = true,
        }
        Some(out)
    }
}

fn fib() -> Fib {
    Fib { a: 0, b: 1, done: false }
}

fn main() {
    let lazy = (1..).map(|x| x * x).filter(|x| x % 3 == 1);   // nothing has run yet
    let first: Vec<u64> = lazy.take(5).collect();               // now it runs: just enough
    println!("squares ≡ 1 mod 3: {first:?}");
    println!("even Fibonacci below 4 million sum to {}", fib().take_while(|&f| f < 4_000_000).filter(|f| f % 2 == 0).sum::<u64>());
    println!("u64 holds {} Fibonacci numbers; the last is {}", fib().count(), fib().last().unwrap());

    let mut v = vec![1, 2, 3];
    for x in v.iter_mut() {
        *x *= 10;
    }
    let total: i32 = v.iter().sum();                             // borrows
    let strings: Vec<String> = v.into_iter().map(|x| x.to_string()).collect();   // consumes v
    println!("total {total}, strings {strings:?}");

    let names = ["ada", "grace", "linus"];
    let years = [1815, 1906, 1969];
    for (i, (n, y)) in names.iter().zip(years).enumerate() {
        print!("{i}:{n}/{y} ");
    }
    println!();
}
