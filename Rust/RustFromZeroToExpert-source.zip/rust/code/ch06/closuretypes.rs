// file: closuretypes.rs
fn main() {
    let ops: Vec<fn(i32) -> i32> = vec![|x| x + 1, |x| x * 2, |x| -x];      // no captures: fn pointers
    println!("{:?}", ops.iter().map(|f| f(10)).collect::<Vec<_>>());

    let k = 5;
    let capturing: Vec<Box<dyn Fn(i32) -> i32>> = vec![Box::new(move |x| x + k), Box::new(|x| x - 1)];
    println!("{:?}", capturing.iter().map(|f| f(10)).collect::<Vec<_>>());
    println!("sizes: fn pointer {}, Box<dyn Fn> {}", std::mem::size_of::<fn(i32) -> i32>(), std::mem::size_of::<Box<dyn Fn(i32) -> i32>>());
}
