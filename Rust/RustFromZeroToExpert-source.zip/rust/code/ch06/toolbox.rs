// file: toolbox.rs
use std::collections::HashMap;

fn main() {
    let lines = ["alice,34,paris", "bob,x,rome", "carol,29,paris", "", "dave,41,oslo"];

    // filter_map: parse what parses, skip the rest
    let ages: Vec<u32> = lines.iter().filter_map(|l| l.split(',').nth(1)?.parse().ok()).collect();
    println!("ages {ages:?}");

    // collect into Result: stops at the first error
    let strict: Result<Vec<u32>, _> = lines.iter().filter(|l| !l.is_empty()).map(|l| l.split(',').nth(1).unwrap_or("").parse::<u32>()).collect();
    println!("strict parse: {strict:?}");

    // group into a map
    let mut by_city: HashMap<&str, Vec<&str>> = HashMap::new();
    for (name, city) in lines.iter().filter_map(|l| { let f: Vec<&str> = l.split(',').collect(); (f.len() == 3).then(|| (f[0], f[2])) }) {
        by_city.entry(city).or_default().push(name);
    }
    let mut cities: Vec<_> = by_city.into_iter().collect();
    cities.sort();
    println!("{cities:?}");

    // partition, unzip, fold, scan, flat_map, peekable
    let (even, odd): (Vec<i32>, Vec<i32>) = (1..=10).partition(|n| n % 2 == 0);
    let (xs, ys): (Vec<i32>, Vec<char>) = [(1, 'a'), (2, 'b')].into_iter().unzip();
    let running: Vec<i32> = [3, 1, 4, 1, 5].iter().scan(0, |acc, &x| { *acc += x; Some(*acc) }).collect();
    let csv = ["a b", "c", "d e f"].iter().flat_map(|s| s.split(' ')).collect::<Vec<_>>().join(",");
    let longest = ["fig", "banana", "kiwi"].iter().max_by_key(|s| s.len()).unwrap();
    let product = (1..=10u64).fold(1, |acc, n| acc * n);
    println!("even {even:?} odd {odd:?} | {xs:?} {ys:?} | running {running:?} | {csv} | {longest} | 10! = {product}");

    // peekable: group consecutive runs
    let data = [1, 1, 2, 2, 2, 3, 1];
    let mut it = data.iter().peekable();
    let mut runs = Vec::new();
    while let Some(&x) = it.next() {
        let mut n = 1;
        while it.next_if(|&&y| y == x).is_some() {
            n += 1;
        }
        runs.push((x, n));
    }
    println!("runs {runs:?}");
}
