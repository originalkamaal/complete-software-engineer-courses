// file: entry.rs
use std::collections::{BTreeMap, HashMap};

fn main() {
    let text = "the cat and the dog and the bird";
    let mut counts: BTreeMap<&str, usize> = BTreeMap::new();
    for w in text.split(' ') { *counts.entry(w).or_insert(0) += 1; }
    println!("{counts:?}");

    let mut groups: HashMap<usize, Vec<&str>> = HashMap::new();
    for w in text.split(' ') { groups.entry(w.len()).or_default().push(w); }
    let mut keys: Vec<_> = groups.keys().copied().collect();
    keys.sort();
    for k in keys { println!("length {k}: {:?}", groups[&k]); }

    let mut cache: HashMap<u64, u64> = HashMap::new();
    let mut computed = 0;
    for n in [10, 20, 10, 10] {
        let v = *cache.entry(n).or_insert_with(|| { computed += 1; n * n });   // closure runs only when vacant
        print!("{v} ");
    }
    println!("\ncomputed {computed} times");
    let first_two: Vec<_> = counts.range("b".."d").collect();
    println!("BTreeMap range b..d: {first_two:?}");
}
