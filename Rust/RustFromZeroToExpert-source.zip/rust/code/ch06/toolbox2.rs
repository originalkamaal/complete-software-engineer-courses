// file: toolbox2.rs
fn main() {
    let prices = [100.0, 102.0, 99.0, 105.0, 110.0];
    let moving_avg: Vec<f64> = prices.windows(3).map(|w| w.iter().sum::<f64>() / 3.0).collect();
    let running_max: Vec<f64> = prices.iter().scan(f64::MIN, |m, &p| { *m = m.max(p); Some(*m) }).collect();
    let changes: Vec<f64> = prices.iter().zip(prices.iter().skip(1)).map(|(a, b)| b - a).collect();
    let product = (1..=10u64).fold(1, |acc, n| acc * n);
    println!("moving average: {moving_avg:?}");
    println!("running max: {running_max:?}");
    println!("changes: {changes:?}");
    println!("10! = {product}, chunks of 2: {:?}", [1, 2, 3, 4, 5].chunks(2).collect::<Vec<_>>());

    let mut it = "aaabccdd".chars().peekable();                    // run-length encoding with peek
    let mut rle = String::new();
    while let Some(c) = it.next() {
        let mut n = 1;
        while it.peek() == Some(&c) { it.next(); n += 1; }
        rle.push_str(&format!("{c}{n}"));
    }
    println!("rle: {rle}");
    let (small, large): (Vec<i32>, Vec<i32>) = [5, 50, 3, 30].into_iter().partition(|&x| x < 10);
    println!("partition: {small:?} {large:?}, position of 30: {:?}", large.iter().position(|&x| x == 30));
}
