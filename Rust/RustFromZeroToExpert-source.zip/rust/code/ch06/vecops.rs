// file: vecops.rs
fn main() {
    let mut v: Vec<u32> = Vec::new();
    let mut caps = vec![];
    for i in 0..100 {
        v.push(i);
        if caps.last() != Some(&v.capacity()) { caps.push(v.capacity()); }
    }
    println!("capacities while pushing 100: {caps:?}");
    let w: Vec<u32> = Vec::with_capacity(100);
    println!("with_capacity(100): len {}, capacity {}", w.len(), w.capacity());

    v.retain(|x| x % 10 == 0);
    println!("retain multiples of 10: {v:?}");
    let removed: Vec<u32> = v.drain(1..4).collect();
    println!("drained {removed:?}, left {v:?}");
    let mut d = vec![1, 1, 2, 2, 2, 1, 3, 3];
    d.dedup();
    println!("dedup: {d:?} (the second 1 survives: not adjacent)");
    d.sort_unstable();
    d.dedup();
    println!("sort + dedup: {d:?}");
    println!("size_of::<Vec<u8>>() = {}", std::mem::size_of::<Vec<u8>>());
}
