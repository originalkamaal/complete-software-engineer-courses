// file: zerocost.rs
use std::hint::black_box;
use std::time::Instant;

fn loop_version(v: &[u32]) -> u64 {
    let mut total = 0u64;
    let mut i = 0;
    while i < v.len() {
        if v[i] % 3 == 0 {
            total += (v[i] as u64) * (v[i] as u64);
        }
        i += 1;
    }
    total
}

fn iter_version(v: &[u32]) -> u64 {
    v.iter().filter(|&&x| x % 3 == 0).map(|&x| x as u64 * x as u64).sum()
}

fn main() {
    let v: Vec<u32> = (0..50_000_000).map(|i: u32| i.wrapping_mul(2_654_435_761) % 1000).collect();
    for _ in 0..2 {
        let t = Instant::now();
        let a = loop_version(black_box(&v));
        let t1 = t.elapsed();
        let t = Instant::now();
        let b = iter_version(black_box(&v));
        let t2 = t.elapsed();
        println!("index loop {t1:.1?}, iterator chain {t2:.1?}, same result: {}", a == b);
    }
}
