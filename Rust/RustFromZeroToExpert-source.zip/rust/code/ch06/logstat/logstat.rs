// file: logstat/logstat.rs
use std::collections::{BTreeMap, HashMap};
use std::time::Instant;

struct Entry<'a> {
    minute: &'a str,            // "10:04": borrowed from the input, no allocation
    path: &'a str,
    status: u16,
    ms: u32,
}

fn parse(line: &str) -> Option<Entry<'_>> {
    let mut f = line.split(' ');
    let ts = f.next()?;
    let _method = f.next()?;
    let path = f.next()?;
    let status = f.next()?.parse().ok()?;
    let ms = f.next()?.parse().ok()?;
    let minute = ts.get(11..16)?;
    Some(Entry { minute, path, status, ms })
}

fn percentile(sorted: &[u32], p: f64) -> u32 {
    sorted[((sorted.len() - 1) as f64 * p).round() as usize]
}

fn main() {
    let path = std::env::args().nth(1).expect("usage: logstat FILE");
    let text = std::fs::read_to_string(&path).expect("readable log");
    let start = Instant::now();

    let (entries, bad): (Vec<Option<Entry>>, Vec<Option<Entry>>) = text.lines().map(parse).partition(Option::is_some);
    let entries: Vec<Entry> = entries.into_iter().flatten().collect();

    let mut by_class: BTreeMap<u16, usize> = BTreeMap::new();
    let mut by_path: HashMap<&str, Vec<u32>> = HashMap::new();
    let mut per_minute: BTreeMap<&str, usize> = BTreeMap::new();
    for e in &entries {
        *by_class.entry(e.status / 100 * 100).or_default() += 1;
        by_path.entry(e.path).or_default().push(e.ms);
        *per_minute.entry(e.minute).or_default() += 1;
    }
    let mut paths: Vec<(&str, Vec<u32>)> = by_path.into_iter().collect();
    for (_, ms) in paths.iter_mut() {
        ms.sort_unstable();
    }
    paths.sort_by(|a, b| b.1.len().cmp(&a.1.len()).then(a.0.cmp(b.0)));
    let busiest = per_minute.iter().max_by_key(|&(m, n)| (*n, std::cmp::Reverse(*m))).unwrap();
    let quietest = per_minute.iter().min_by_key(|&(m, n)| (*n, *m)).unwrap();
    let elapsed = start.elapsed();

    println!("{} requests, {} malformed lines", entries.len(), bad.len());
    for (class, n) in &by_class {
        println!("  {}xx {:>8}  {:5.2}%", class / 100, n, 100.0 * *n as f64 / entries.len() as f64);
    }
    println!("{:<16} {:>8} {:>6} {:>6} {:>6} {:>6}", "path", "count", "p50", "p95", "p99", "max");
    for (p, ms) in &paths {
        println!("{:<16} {:>8} {:>6} {:>6} {:>6} {:>6}", p, ms.len(), percentile(ms, 0.50), percentile(ms, 0.95), percentile(ms, 0.99), ms[ms.len() - 1]);
    }
    println!("busiest minute {} ({} req), quietest {} ({} req), {} minutes", busiest.0, busiest.1, quietest.0, quietest.1, per_minute.len());
    eprintln!("analysed in {elapsed:.0?}");
}
