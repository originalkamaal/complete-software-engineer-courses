// file: logstat/gen.rs
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(1_000_000);
    let paths = ["/", "/api/users", "/api/orders", "/static/app.js", "/login", "/api/search", "/health"];
    let weights = [20u64, 25, 15, 25, 5, 8, 2];
    let mut x: u64 = 0x2545F4914F6CDD1D;                         // xorshift64: reproducible, no crates
    let mut rand = move || { x ^= x << 13; x ^= x >> 7; x ^= x << 17; x };
    let total: u64 = weights.iter().sum();
    let mut out = String::with_capacity(48 * n as usize);
    for i in 0..n {
        if rand() % 5000 == 0 {
            out.push_str("garbage line\n");
            continue;
        }
        let mut pick = rand() % total;
        let p = weights.iter().position(|&w| if pick < w { true } else { pick -= w; false }).unwrap();
        let status = match rand() % 100 { 0..=1 => 500, 2..=6 => 404, 7..=9 => 302, _ => 200 };
        let base = [5, 40, 60, 2, 80, 120, 1][p];
        let ms = base + rand() % (base * 2 + 1) + if rand() % 100 == 0 { 2000 } else { 0 };   // 1% slow outliers
        let secs = i * 3600 / n;                                  // one hour of traffic
        let method = if p == 2 && rand() % 3 == 0 { "POST" } else { "GET" };
        out.push_str(&format!("2026-11-15T10:{:02}:{:02} {method} {} {status} {ms}\n", secs / 60, secs % 60, paths[p]));
    }
    print!("{out}");
}
