// file: closures.rs
fn apply_twice<F: Fn(i32) -> i32>(f: F, x: i32) -> i32 {
    f(f(x))
}

fn call_n<F: FnMut()>(mut f: F, n: usize) {
    for _ in 0..n {
        f();
    }
}

fn consume<F: FnOnce() -> String>(f: F) -> String {
    f()
}

fn make_adder(k: i32) -> impl Fn(i32) -> i32 {
    move |x| x + k                                  // k is copied into the closure
}

fn make_counter() -> impl FnMut() -> u32 {
    let mut count = 0;
    move || {
        count += 1;                                 // the closure owns and mutates its own count
        count
    }
}

fn main() {
    let offset = 10;
    let add = |x| x + offset;                       // captures offset by reference: Fn
    println!("apply_twice: {}", apply_twice(add, 1));

    let mut log = Vec::new();
    call_n(|| log.push(log.len()), 3);              // captures log by &mut: FnMut
    println!("log: {log:?}");

    let name = String::from("Ferris");
    let greeting = move || format!("hello, {name}"); // name moved into the closure
    println!("{}", consume(greeting));              // FnOnce would also accept Fn closures

    let add5 = make_adder(5);
    let mut next = make_counter();
    println!("add5(1) = {}, counter: {} {} {}", add5(1), next(), next(), next());

    let ops: Vec<(&str, Box<dyn Fn(f64) -> f64>)> = vec![
        ("double", Box::new(|x| x * 2.0)),
        ("square", Box::new(|x| x * x)),
        ("plus offset", Box::new(move |x| x + offset as f64)),
    ];
    for (label, op) in &ops {
        println!("{label}(3) = {}", op(3.0));
    }
    println!("size of add5 closure: {} bytes, of a capture-free closure: {}", size_of_val(&add5), size_of_val(&|x: i32| x));
}
