// file: maps.rs
use std::collections::{BTreeMap, HashMap, HashSet};

fn main() {
    let text = "the quick brown fox jumps over the lazy dog the end";
    let mut counts: HashMap<&str, usize> = HashMap::new();
    for word in text.split_whitespace() {
        *counts.entry(word).or_insert(0) += 1;         // one lookup per word
    }
    println!("the={} fox={} cat={:?}", counts["the"], counts["fox"], counts.get("cat"));

    let mut by_len: BTreeMap<usize, Vec<&str>> = BTreeMap::new();   // sorted by key
    for word in counts.keys() {
        by_len.entry(word.len()).or_default().push(word);
    }
    for words in by_len.values_mut() {
        words.sort();
    }
    println!("{by_len:?}");
    println!("words of length 4..=5: {:?}", by_len.range(4..=5).collect::<Vec<_>>());

    let a: HashSet<char> = "hello".chars().collect();
    let b: HashSet<char> = "world".chars().collect();
    let mut common: Vec<&char> = a.intersection(&b).collect();
    common.sort();
    println!("common letters {common:?}, a has {} distinct", a.len());

    // HashMap iteration order is unspecified (and randomised per process):
    let keys: Vec<&&str> = counts.keys().take(3).collect();
    println!("first three keys this run: {keys:?}");
}
