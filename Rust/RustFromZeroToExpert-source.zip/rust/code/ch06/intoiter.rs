// file: intoiter.rs
struct Playlist { songs: Vec<String> }

impl<'a> IntoIterator for &'a Playlist {
    type Item = &'a String;
    type IntoIter = std::slice::Iter<'a, String>;
    fn into_iter(self) -> Self::IntoIter { self.songs.iter() }
}
impl IntoIterator for Playlist {
    type Item = String;
    type IntoIter = std::vec::IntoIter<String>;
    fn into_iter(self) -> Self::IntoIter { self.songs.into_iter() }
}

fn main() {
    let p = Playlist { songs: vec!["one".into(), "two".into()] };
    for s in &p { print!("borrowed {s}; "); }          // p is still usable
    println!();
    for s in p { print!("owned {s}; "); }              // p is consumed
    println!();
}
