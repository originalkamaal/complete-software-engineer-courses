// file: hygiene.rs
macro_rules! double_it {
    ($e:expr) => {{
        let x = $e;                                     // this x is the macro's own...
        x * 2
    }};
}

macro_rules! square_twice_bad {
    ($e:expr) => { $e * $e };                           // evaluates $e twice!
}

macro_rules! square_once {
    ($e:expr) => {{ let v = $e; v * v }};               // evaluates $e once
}

fn next(counter: &mut i32) -> i32 {
    *counter += 1;
    *counter
}

fn main() {
    let x = 10;
    println!("double_it!(x + 1) = {}, caller's x still {x}", double_it!(x + 1));   // ...not the caller's x
    let mut c = 0;
    let bad = square_twice_bad!(next(&mut c));          // next() called twice: 1 * 2
    let mut d = 0;
    let good = square_once!(next(&mut d));              // next() called once: 1 * 1
    println!("square_twice_bad = {bad} (counter {c}), square_once = {good} (counter {d})");
}
