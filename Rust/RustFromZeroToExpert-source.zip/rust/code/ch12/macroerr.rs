// file: macroerr.rs
macro_rules! percent {
    ($v:literal %) => { ($v as f64) / 100.0 };
    ($v:literal) => { compile_error!("percent! needs a % sign, like percent!(15 %)") };
}

fn main() {
    let tax = percent!(18 %);
    println!("18% of 250 = {}", 250.0 * tax);
    #[cfg(feature_missing_sign)]
    let _ = percent!(18);
}
