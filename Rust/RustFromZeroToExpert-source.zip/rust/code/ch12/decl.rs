// file: decl.rs
use std::collections::HashMap;

/// hashmap!{ "a" => 1, "b" => 2 } — like vec! for maps
macro_rules! hashmap {
    () => { HashMap::new() };
    ( $( $k:expr => $v:expr ),+ $(,)? ) => {{                // optional trailing comma
        let mut m = HashMap::with_capacity([$( stringify!($k) ),+].len());
        $( m.insert($k, $v); )+
        m
    }};
}

/// Generates a newtype with Display and From, for each name given.
macro_rules! newtypes {
    ( $( $name:ident($inner:ty) ),* ) => {
        $(
            #[derive(Debug, Clone, Copy, PartialEq)]
            struct $name($inner);
            impl std::fmt::Display for $name {
                fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                    write!(f, "{}({})", stringify!($name), self.0)
                }
            }
            impl From<$inner> for $name {
                fn from(v: $inner) -> Self { $name(v) }
            }
        )*
    };
}

newtypes!(UserId(u64), Celsius(f64));

/// A tiny assertion macro that reports the expression text.
macro_rules! check {
    ($cond:expr) => {
        if !$cond {
            println!("check failed: {}  (at {}:{})", stringify!($cond), file!(), line!());
        }
    };
    ($cond:expr, $($fmt:tt)+) => {
        if !$cond {
            println!("check failed: {}: {}", stringify!($cond), format!($($fmt)+));
        }
    };
}

fn main() {
    let ages: HashMap<&str, u32> = hashmap! { "ada" => 36, "alan" => 41, };
    let empty: HashMap<u8, u8> = hashmap!();
    let mut names: Vec<_> = ages.keys().collect();
    names.sort();
    println!("{names:?}, empty has {}", empty.len());
    let id: UserId = 42.into();
    println!("{id} {}", Celsius(21.5));
    check!(ages["ada"] > 40);
    check!(ages.len() == 3, "expected 3 people, got {}", ages.len());
}
