// file: pm/app/src/main.rs
use timed::timed;

#[timed]
fn slow_sum(n: u64) -> u64 {
    (0..n).map(|i| i % 7).sum()
}

#[timed]
fn greet(name: &str) -> String {
    format!("hello, {name}")
}

fn main() {
    println!("{}", slow_sum(std::hint::black_box(30_000_000)));
    println!("{}", greet("macros"));
}
