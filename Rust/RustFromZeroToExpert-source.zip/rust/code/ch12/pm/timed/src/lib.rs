// file: pm/timed/src/lib.rs
use proc_macro::TokenStream;
use quote::quote;
use syn::{ItemFn, parse_macro_input};

/// Prints the wall-clock time of every call to the annotated function.
#[proc_macro_attribute]
pub fn timed(_args: TokenStream, item: TokenStream) -> TokenStream {
    let ItemFn { attrs, vis, sig, block } = parse_macro_input!(item as ItemFn);
    let name = sig.ident.to_string();
    quote! {
        #(#attrs)* #vis #sig {
            let __start = ::std::time::Instant::now();
            let __result = (move || #block)();
            eprintln!("[timed] {} took {:.1?}", #name, __start.elapsed());
            __result
        }
    }
    .into()
}
