// file: recursive.rs
/// Counts its arguments at compile time.
macro_rules! count {
    () => { 0usize };
    ($head:tt $($tail:tt)*) => { 1usize + count!($($tail)*) };
}

/// Builds a nested max: max!(a, b, c) => a.max(b.max(c))
macro_rules! max {
    ($x:expr) => { $x };
    ($x:expr, $($rest:expr),+) => { std::cmp::max($x, max!($($rest),+)) };
}

/// A mini-language: `bits! { flag_a = 0, flag_b = 3 }` makes constants and a describe() fn.
macro_rules! bits {
    ( $( $name:ident = $bit:literal ),* $(,)? ) => {
        $( #[allow(non_upper_case_globals)] const $name: u32 = 1 << $bit; )*
        fn describe(v: u32) -> Vec<&'static str> {
            let mut out = Vec::new();
            $( if v & $name != 0 { out.push(stringify!($name)); } )*
            out
        }
    };
}

bits! { readable = 0, writable = 1, executable = 2, hidden = 7 }

fn main() {
    const N: usize = count!(a b c d e);                 // evaluated at compile time
    println!("count = {N}, max = {}", max!(3, 9, 4, 7));
    let perms = readable | executable | hidden;
    println!("{perms:#010b} = {:?}", describe(perms));
}
