// file: macrogen.rs
trait Describe { fn describe() -> String; }

macro_rules! impl_describe {
    ($($t:ty => $desc:literal),* $(,)?) => {
        $( impl Describe for $t { fn describe() -> String { format!("{} ({} bytes)", $desc, std::mem::size_of::<$t>()) } } )*
    };
}
impl_describe!(u8 => "byte", u32 => "word", f64 => "double", (u8, u32) => "pair",);

macro_rules! newtype {
    ($name:ident($inner:ty)) => {
        #[derive(Debug, Clone, Copy, PartialEq)]
        struct $name($inner);
        impl From<$inner> for $name { fn from(v: $inner) -> Self { $name(v) } }
    };
}
newtype!(Celsius(f64));
newtype!(Port(u16));

fn main() {
    println!("{}\n{}\n{}\n{}", u8::describe(), u32::describe(), f64::describe(), <(u8, u32)>::describe());
    let c: Celsius = 21.5.into();
    let p = Port::from(8080);
    println!("{c:?} {p:?}");
}
