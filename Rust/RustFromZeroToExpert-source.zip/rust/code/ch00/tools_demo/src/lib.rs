// file: tools_demo/src/lib.rs
/// Returns the mean of the values, or `None` for an empty slice.
///
/// ```
/// assert_eq!(tools_demo::mean(&[1.0, 2.0, 6.0]), Some(3.0));
/// assert_eq!(tools_demo::mean(&[]), None);
/// ```
pub fn mean(values: &[f64]) -> Option<f64> {
    if values.len() == 0 {
        return None;
    }
    let mut total = 0.0;
    for i in 0..values.len() {
        total = total + values[i];
    }
    Some(total / values.len() as f64)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mean_of_one_value_is_that_value() {
        assert_eq!(mean(&[4.5]), Some(4.5));
    }
}
