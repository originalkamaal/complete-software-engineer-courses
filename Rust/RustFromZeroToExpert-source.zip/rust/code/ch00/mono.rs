// file: mono.rs
fn largest<T: PartialOrd + Copy>(items: &[T]) -> T {
    let mut best = items[0];
    for &x in items {
        if x > best {
            best = x;
        }
    }
    best
}

fn main() {
    println!("{} {}", largest(&[3, 9, 2]), largest(&[1.5, -2.0]));
}
