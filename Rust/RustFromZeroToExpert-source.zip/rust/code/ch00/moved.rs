// file: moved.rs
fn main() {
    let v = vec![1, 2, 3];
    let w = v;                     // ownership of the vector moves to w
    println!("{v:?} {w:?}");       // v can no longer be used
}
