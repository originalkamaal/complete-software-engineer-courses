// file: overflow.rs
fn main() {
    let x: u8 = std::env::args().count() as u8 + 254;    // 255 when run without arguments
    println!("checked: {:?}, wrapping: {}, saturating: {}", x.checked_add(1), x.wrapping_add(1), x.saturating_add(1));
    let y = x + 1;                                          // overflow!
    println!("x + 1 = {y}");
}
