// file: primes/src/lib.rs
/// Counts the primes strictly below `limit` with the sieve of Eratosthenes.
pub fn count_primes(limit: usize) -> usize {
    if limit < 3 {
        return 0;
    }
    let mut composite = vec![false; limit];
    let mut count = 0;
    for n in 2..limit {
        if !composite[n] {
            count += 1;
            let mut multiple = n * n;
            while multiple < limit {
                composite[multiple] = true;
                multiple += n;
            }
        }
    }
    count
}

#[cfg(test)]
mod tests {
    use super::count_primes;

    #[test]
    fn known_counts() {
        assert_eq!(count_primes(0), 0);
        assert_eq!(count_primes(10), 4);        // 2 3 5 7
        assert_eq!(count_primes(100), 25);
        assert_eq!(count_primes(1_000_000), 78_498);
    }
}
