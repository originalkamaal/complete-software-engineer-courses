// file: primes/src/main.rs
use std::time::Instant;

fn main() {
    let limit: usize = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(10_000_000);
    let start = Instant::now();
    let n = primes::count_primes(limit);
    let elapsed = start.elapsed();
    let mut buf = itoa::Buffer::new();
    println!("{} primes below {limit} in {elapsed:.1?}", buf.format(n));
}
