// file: hello.rs
fn main() {
    let name = "Rust";
    let year = 2015;
    println!("Hello from {name}, stable since {year}.");
    let squares: Vec<u64> = (1..=5).map(|n| n * n).collect();
    println!("squares: {squares:?}, sum = {}", squares.iter().sum::<u64>());
}
