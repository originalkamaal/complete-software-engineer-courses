// file: bounds.rs
use std::hint::black_box;
use std::time::Instant;

#[inline(never)]
pub fn dot_indexed(a: &[f32], b: &[f32], idx: &[usize]) -> f32 {
    let mut s = 0.0;
    for &i in idx {
        s += a[i] * b[i];                          // data-dependent index: checks cannot be removed
    }
    s
}

#[inline(never)]
pub fn sum_pairs_indexed(a: &[u32], b: &[u32]) -> u32 {
    let mut s = 0u32;
    for i in 0..a.len() {
        s = s.wrapping_add(a[i].wrapping_mul(b[i]));   // b[i] may be out of range: checked every time
    }
    s
}

#[inline(never)]
pub fn sum_pairs_zip(a: &[u32], b: &[u32]) -> u32 {
    a.iter().zip(b).fold(0u32, |s, (x, y)| s.wrapping_add(x.wrapping_mul(*y)))   // no checks: vectorised
}

#[inline(never)]
pub fn sum_pairs_presliced(a: &[u32], b: &[u32]) -> u32 {
    let b = &b[..a.len()];                         // one check up front; the loop is then provably in bounds
    let mut s = 0u32;
    for i in 0..a.len() {
        s = s.wrapping_add(a[i].wrapping_mul(b[i]));
    }
    s
}

fn time(label: &str, f: impl Fn() -> u32) {
    let t = Instant::now();
    let mut r = 0;
    for _ in 0..20 {
        r = f();
    }
    println!("{label:<22} {:>6.1?}  (result {r})", t.elapsed() / 20);
}

fn main() {
    let n = 10_000_000;
    let a: Vec<u32> = (0..n).map(|i| i as u32).collect();
    let b: Vec<u32> = (0..n).map(|i| (i * 7) as u32).collect();
    time("indexed loop", || sum_pairs_indexed(black_box(&a), black_box(&b)));
    time("zip", || sum_pairs_zip(black_box(&a), black_box(&b)));
    time("pre-sliced index loop", || sum_pairs_presliced(black_box(&a), black_box(&b)));
    let idx: Vec<usize> = (0..1000).collect();
    let f: Vec<f32> = vec![1.0; 1000];
    println!("dot_indexed = {}", dot_indexed(&f, &f, &idx));
}
