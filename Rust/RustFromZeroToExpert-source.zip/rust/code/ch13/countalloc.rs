// file: countalloc.rs
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};

struct Counting;
static ALLOCS: AtomicUsize = AtomicUsize::new(0);

unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 { ALLOCS.fetch_add(1, Relaxed); unsafe { System.alloc(l) } }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) { unsafe { System.dealloc(p, l) } }
}
#[global_allocator]
static GLOBAL: Counting = Counting;

fn count<R>(label: &str, f: impl FnOnce() -> R) -> R {
    let before = ALLOCS.load(Relaxed);
    let r = f();
    println!("{label:36} {} allocations", ALLOCS.load(Relaxed) - before);
    r
}

fn main() {
    let words: Vec<String> = (0..1000).map(|i| format!("w{i}")).collect();
    count("join via format! in a loop", || { let mut s = String::new(); for w in &words { s = format!("{s}{w},"); } s.len() });
    count("push_str into one String", || { let mut s = String::new(); for w in &words { s.push_str(w); s.push(','); } s.len() });
    count("push_str with_capacity", || { let mut s = String::with_capacity(6000); for w in &words { s.push_str(w); s.push(','); } s.len() });
    count("collect into Vec without size hint", || (0..1000).filter(|x| x % 3 == 0).collect::<Vec<u32>>().len());
    count("collect from exact-size iterator", || (0..1000u32).map(|x| x * 3).collect::<Vec<u32>>().len());
}
