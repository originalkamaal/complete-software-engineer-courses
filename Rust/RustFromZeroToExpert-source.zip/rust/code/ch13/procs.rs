// file: procs.rs
use std::io::Write;
use std::process::{Command, Stdio};

fn main() -> std::io::Result<()> {
    let out = Command::new("uname").arg("-sr").output()?;
    print!("uname: {}", String::from_utf8_lossy(&out.stdout));

    // pipe data through `sort -n` and read the result
    let mut child = Command::new("sort").arg("-n").stdin(Stdio::piped()).stdout(Stdio::piped()).spawn()?;
    child.stdin.take().unwrap().write_all(b"10\n9\n100\n1\n")?;   // dropping stdin closes the pipe
    let sorted = child.wait_with_output()?;
    println!("sorted: {:?}", String::from_utf8_lossy(&sorted.stdout).lines().collect::<Vec<_>>());

    // arguments are passed as-is, never through a shell: this file name is harmless
    let status = Command::new("ls").arg("no such file; rm -rf /").stderr(Stdio::null()).status()?;
    println!("ls exited with {status} (code {:?})", status.code());

    println!("pid {}, parent pid {}", std::process::id(), std::os::unix::process::parent_id());
    Ok(())
}
