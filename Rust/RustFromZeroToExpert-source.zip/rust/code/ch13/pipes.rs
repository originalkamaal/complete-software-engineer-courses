// file: pipes.rs
use std::io::Write;
use std::process::{Command, Stdio};

fn main() -> std::io::Result<()> {
    let out = Command::new("ls").arg("-1").arg("/").output()?;
    println!("ls succeeded: {}, listed bin/: {}", out.status.success(), String::from_utf8_lossy(&out.stdout).lines().any(|l| l == "bin"));

    let mut child = Command::new("sort")
        .arg("-r")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .spawn()?;
    child.stdin.take().unwrap().write_all(b"pear\napple\nmango\n")?;   // dropping stdin sends EOF
    let sorted = child.wait_with_output()?;
    print!("sorted -r:\n{}", String::from_utf8_lossy(&sorted.stdout));

    let missing = Command::new("definitely-not-a-command").output();
    println!("missing program: {}", missing.unwrap_err().kind());
    let failing = Command::new("sh").args(["-c", "echo oops >&2; exit 3"]).output()?;
    println!("exit code {:?}, stderr {:?}", failing.status.code(), String::from_utf8_lossy(&failing.stderr).trim());
    Ok(())
}
