// file: brc/src/main.rs
use rayon::prelude::*;
use rustc_hash::FxHashMap;
use std::collections::{BTreeMap, HashMap};
use std::io::{BufRead, BufReader, Write};
use std::time::Instant;

#[derive(Clone, Copy)]
struct Stats { min: i32, max: i32, sum: i64, count: u64 }        // temperatures in tenths of a degree

impl Stats {
    fn new(t: i32) -> Self { Stats { min: t, max: t, sum: t as i64, count: 1 } }
    fn add(&mut self, t: i32) { self.min = self.min.min(t); self.max = self.max.max(t); self.sum += t as i64; self.count += 1; }
    fn merge(&mut self, o: &Stats) { self.min = self.min.min(o.min); self.max = self.max.max(o.max); self.sum += o.sum; self.count += o.count; }
}

/// Formats the result identically for every version: {name=min/mean/max, ...}
fn report(stats: BTreeMap<String, Stats>) -> String {
    let parts: Vec<String> = stats.iter().map(|(name, s)| {
        let mean = (s.sum as f64 / s.count as f64 / 10.0 * 10.0).round() / 10.0;
        format!("{name}={:.1}/{:.1}/{:.1}", s.min as f64 / 10.0, mean, s.max as f64 / 10.0)
    }).collect();
    format!("{{{}}}", parts.join(", "))
}

/// Parses "-12.3" or "4.5" (always one decimal) into tenths, without floating point.
fn parse_tenths(b: &[u8]) -> i32 {
    let (neg, digits) = if b[0] == b'-' { (true, &b[1..]) } else { (false, b) };
    let mut v = 0i32;
    for &c in digits {
        if c != b'.' { v = v * 10 + (c - b'0') as i32; }
    }
    if neg { -v } else { v }
}

// v1: the obvious version — read_to_string, lines, split, f64, String keys, std HashMap
fn v1(path: &str) -> String {
    let text = std::fs::read_to_string(path).unwrap();
    let mut map: HashMap<String, Stats> = HashMap::new();
    for line in text.lines() {
        let (name, temp) = line.split_once(';').unwrap();
        let t = (temp.parse::<f64>().unwrap() * 10.0).round() as i32;
        map.entry(name.to_string()).and_modify(|s| s.add(t)).or_insert(Stats::new(t));
    }
    report(map.into_iter().collect())
}

// v2: streaming with BufRead::read_line into one reused String — less memory, same per-line work
fn v2(path: &str) -> String {
    let mut reader = BufReader::with_capacity(1 << 20, std::fs::File::open(path).unwrap());
    let mut line = String::new();
    let mut map: HashMap<String, Stats> = HashMap::new();
    while reader.read_line(&mut line).unwrap() > 0 {
        let (name, temp) = line.trim_end().split_once(';').unwrap();
        let t = (temp.parse::<f64>().unwrap() * 10.0).round() as i32;
        match map.get_mut(name) {                                    // allocate a key only for new stations
            Some(s) => s.add(t),
            None => { map.insert(name.to_string(), Stats::new(t)); }
        }
        line.clear();
    }
    report(map.into_iter().collect())
}

// v3: bytes instead of UTF-8 text, integer parsing, FxHash with &[u8] keys borrowed from the buffer
fn v3_chunk(data: &[u8]) -> FxHashMap<&[u8], Stats> {
    let mut map: FxHashMap<&[u8], Stats> = FxHashMap::default();
    for line in data.split(|&b| b == b'\n').filter(|l| !l.is_empty()) {
        let semi = line.iter().rposition(|&b| b == b';').unwrap();   // temperatures are short: search from the end
        let (name, temp) = (&line[..semi], &line[semi + 1..]);
        let t = parse_tenths(temp);
        match map.get_mut(name) {
            Some(s) => s.add(t),
            None => { map.insert(name, Stats::new(t)); }
        }
    }
    map
}

fn to_report(map: FxHashMap<&[u8], Stats>) -> String {
    report(map.into_iter().map(|(k, v)| (String::from_utf8(k.to_vec()).unwrap(), v)).collect())
}

fn v3(path: &str) -> String {
    let data = std::fs::read(path).unwrap();
    to_report(v3_chunk(&data))
}

// v4: memory-map the file and process chunks in parallel, splitting at line boundaries, then merge
fn v4(path: &str) -> String {
    let file = std::fs::File::open(path).unwrap();
    // SAFETY: the file is not modified while mapped (we created it and nothing else writes it).
    let data = unsafe { memmap2::Mmap::map(&file).unwrap() };
    let pieces = rayon::current_num_threads() * 4;
    let mut bounds = vec![0];
    for i in 1..pieces {
        let mut p = data.len() * i / pieces;
        while p < data.len() && data[p - 1] != b'\n' { p += 1; }    // move to the start of a line
        bounds.push(p);
    }
    bounds.push(data.len());
    let merged = bounds.windows(2).collect::<Vec<_>>().par_iter()
        .map(|w| v3_chunk(&data[w[0]..w[1]]))
        .reduce(FxHashMap::default, |mut a, b| {
            for (k, s) in b { a.entry(k).and_modify(|x| x.merge(&s)).or_insert(s); }
            a
        });
    to_report(merged)
}

fn main() {
    let path = std::env::args().nth(1).expect("usage: brc FILE");
    let versions: [(&str, fn(&str) -> String); 4] = [
        ("v1 read_to_string, lines, f64, String keys", v1),
        ("v2 BufRead, reused line buffer", v2),
        ("v3 bytes, integer parse, FxHash, &[u8] keys", v3),
        ("v4 mmap + rayon on 2 cores", v4),
    ];
    let mut outputs = Vec::new();
    let mut base = 0.0;
    for (name, f) in versions {
        let t = Instant::now();
        let out = f(&path);
        let secs = t.elapsed().as_secs_f64();
        if base == 0.0 { base = secs; }
        println!("{name:<46} {:>6.0} ms  {:>5.1}x", secs * 1e3, base / secs);
        outputs.push(out);
    }
    println!("all versions identical: {}", outputs.iter().all(|o| *o == outputs[0]));
    let mut stdout = std::io::stdout().lock();
    writeln!(stdout, "{}…", &outputs[0][..outputs[0].char_indices().nth(150).unwrap().0]).unwrap();
}
