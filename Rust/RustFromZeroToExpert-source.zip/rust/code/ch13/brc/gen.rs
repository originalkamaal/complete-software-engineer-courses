// file: brc/gen.rs
use std::io::{BufWriter, Write};

fn main() -> std::io::Result<()> {
    let n: usize = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(10_000_000);
    let stations: [(&str, f64); 24] = [
        ("Abha", 18.0), ("Accra", 26.4), ("Bergen", 7.7), ("Bulawayo", 18.9), ("Cairo", 21.4), ("Dakar", 24.0),
        ("Edmonton", 4.2), ("Fukuoka", 17.0), ("Hanoi", 23.6), ("Ho Chi Minh City", 27.4), ("Istanbul", 13.9),
        ("Jakarta", 26.7), ("Kraków", 8.3), ("Lagos", 26.8), ("Lima", 19.0), ("Montréal", 6.8), ("Nouméa", 23.0),
        ("Oslo", 5.7), ("Reykjavík", 4.3), ("São Paulo", 19.6), ("Tromsø", 2.9), ("Ürümqi", 7.4), ("Zürich", 9.3), ("İzmir", 17.9),
    ];
    let mut x: u64 = 0x853C49E6748FEA9B;
    let mut out = BufWriter::with_capacity(1 << 20, std::io::stdout().lock());
    for _ in 0..n {
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        let (name, mean) = stations[(x % 24) as usize];
        let noise = ((x >> 20) % 2001) as f64 / 100.0 - 10.0;          // -10.00 ..= +10.00
        writeln!(out, "{name};{:.1}", mean + noise)?;
    }
    Ok(())
}
