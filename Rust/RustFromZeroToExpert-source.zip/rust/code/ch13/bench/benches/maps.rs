// file: bench/benches/maps.rs
use bench::count;
use criterion::{Criterion, criterion_group, criterion_main};
use std::collections::hash_map::RandomState;
use std::hint::black_box;

fn maps(c: &mut Criterion) {
    let keys: Vec<u64> = (0..100_000u64).map(|i| i.wrapping_mul(0x9E37_79B9_7F4A_7C15) % 10_000).collect();
    let mut g = c.benchmark_group("count 100k u64 keys");
    g.bench_function("std SipHash", |b| b.iter(|| count::<RandomState>(black_box(&keys))));
    g.bench_function("FxHash", |b| b.iter(|| count::<rustc_hash::FxBuildHasher>(black_box(&keys))));
    g.finish();
}

criterion_group!(benches, maps);
criterion_main!(benches);
