// file: bench/src/lib.rs
use std::collections::HashMap;
use std::hash::BuildHasher;

/// Counts occurrences of each key using a map with hasher `S`.
pub fn count<S: BuildHasher + Default>(keys: &[u64]) -> HashMap<u64, u32, S> {
    let mut m: HashMap<u64, u32, S> = HashMap::default();
    for &k in keys {
        *m.entry(k).or_insert(0) += 1;
    }
    m
}
