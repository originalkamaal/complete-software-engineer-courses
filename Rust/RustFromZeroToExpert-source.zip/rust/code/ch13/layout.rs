// file: layout.rs
#[allow(dead_code)]
struct RustOrder { a: u8, b: u64, c: u8 }
#[allow(dead_code)]
#[repr(C)]
struct COrder { a: u8, b: u64, c: u8 }
#[allow(dead_code)]
enum Small { A(u8), B(u16), C }

fn main() {
    println!("repr(Rust) {} bytes, repr(C) {} bytes, enum Small {} bytes, Option<Box<u8>> {} bytes",
             size_of::<RustOrder>(), size_of::<COrder>(), size_of::<Small>(), size_of::<Option<Box<u8>>>());
    println!("offsets (Rust): a={} b={} c={}", std::mem::offset_of!(RustOrder, a), std::mem::offset_of!(RustOrder, b), std::mem::offset_of!(RustOrder, c));
}
