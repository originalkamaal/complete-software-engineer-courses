	.file	"bounds.13e65fac287b5296-cgu.0"
	.section	.text._RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds,"ax",@progbits
	.hidden	_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds
	.globl	_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds
	.p2align	4
	.type	_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds,@function
_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCsgczF5crJ4sT_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds, .Lfunc_end0-_RINvNtCsgczF5crJ4sT_3std2rt10lang_startuECs1HVsbmUPzBG_6bounds
	.cfi_endproc

	.section	.text._RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds,@function
_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds, .Lfunc_end1-_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds
	.cfi_endproc

	.section	.text._RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds,"ax",@progbits
	.p2align	4
	.type	_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds,@function
_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds, .Lfunc_end2-_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds,@function
_RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCsgczF5crJ4sT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1HVsbmUPzBG_6bounds
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds, .Lfunc_end3-_RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds
	.cfi_endproc

	.section	.text._RNvCs1HVsbmUPzBG_6bounds11dot_indexed,"ax",@progbits
	.p2align	4
	.type	_RNvCs1HVsbmUPzBG_6bounds11dot_indexed,@function
_RNvCs1HVsbmUPzBG_6bounds11dot_indexed:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	testq	%r9, %r9
	je	.LBB4_1
	shlq	$3, %r9
	xorps	%xmm0, %xmm0
	xorl	%r10d, %r10d
	.p2align	4
.LBB4_3:
	movq	(%r8,%r10), %rax
	cmpq	%rsi, %rax
	jae	.LBB4_8
	cmpq	%rcx, %rax
	jae	.LBB4_7
	movss	(%rdi,%rax,4), %xmm1
	mulss	(%rdx,%rax,4), %xmm1
	addss	%xmm1, %xmm0
	addq	$8, %r10
	cmpq	%r10, %r9
	jne	.LBB4_3
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB4_1:
	.cfi_def_cfa_offset 16
	xorps	%xmm0, %xmm0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB4_7:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.4(%rip), %rdx
	movq	%rax, %rdi
	movq	%rcx, %rsi
	callq	*_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB4_8:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.3(%rip), %rdx
	movq	%rax, %rdi
	callq	*_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end4:
	.size	_RNvCs1HVsbmUPzBG_6bounds11dot_indexed, .Lfunc_end4-_RNvCs1HVsbmUPzBG_6bounds11dot_indexed
	.cfi_endproc

	.section	.text._RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip,"ax",@progbits
	.p2align	4
	.type	_RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip,@function
_RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip:
	.cfi_startproc
	cmpq	%rsi, %rcx
	cmovbq	%rcx, %rsi
	testq	%rsi, %rsi
	je	.LBB5_1
	cmpq	$8, %rsi
	jae	.LBB5_5
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB5_4
.LBB5_1:
	xorl	%eax, %eax
	retq
.LBB5_5:
	movabsq	$2305843009213693944, %rcx
	andq	%rsi, %rcx
	leaq	(,%rsi,4), %rax
	andq	$-32, %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	pxor	%xmm1, %xmm1
	.p2align	4
.LBB5_6:
	movdqu	(%rdi,%r8), %xmm2
	movdqu	16(%rdi,%r8), %xmm3
	movdqu	(%rdx,%r8), %xmm4
	movdqu	16(%rdx,%r8), %xmm5
	pshufd	$245, %xmm4, %xmm6
	pmuludq	%xmm2, %xmm4
	pshufd	$232, %xmm4, %xmm4
	pshufd	$245, %xmm2, %xmm2
	pmuludq	%xmm6, %xmm2
	pshufd	$232, %xmm2, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm1
	pshufd	$245, %xmm5, %xmm2
	pmuludq	%xmm3, %xmm5
	pshufd	$232, %xmm5, %xmm4
	pshufd	$245, %xmm3, %xmm3
	pmuludq	%xmm2, %xmm3
	pshufd	$232, %xmm3, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm0
	addq	$32, %r8
	cmpq	%r8, %rax
	jne	.LBB5_6
	paddd	%xmm1, %xmm0
	pshufd	$238, %xmm0, %xmm1
	paddd	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0
	paddd	%xmm1, %xmm0
	movd	%xmm0, %eax
	jmp	.LBB5_8
.LBB5_4:
	movl	(%rdx,%rcx,4), %r8d
	imull	(%rdi,%rcx,4), %r8d
	incq	%rcx
	addl	%r8d, %eax
.LBB5_8:
	cmpq	%rcx, %rsi
	jne	.LBB5_4
	retq
.Lfunc_end5:
	.size	_RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip, .Lfunc_end5-_RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip
	.cfi_endproc

	.section	.text._RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed,"ax",@progbits
	.p2align	4
	.type	_RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed,@function
_RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed:
	.cfi_startproc
	testq	%rsi, %rsi
	je	.LBB6_1
	leaq	-1(%rsi), %rax
	cmpq	%rax, %rcx
	jbe	.LBB6_11
	cmpq	$8, %rsi
	jae	.LBB6_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB6_5
.LBB6_1:
	xorl	%eax, %eax
	retq
.LBB6_6:
	movabsq	$2305843009213693944, %rcx
	andq	%rsi, %rcx
	leaq	(,%rsi,4), %rax
	andq	$-32, %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	pxor	%xmm1, %xmm1
	.p2align	4
.LBB6_7:
	movdqu	(%rdi,%r8), %xmm2
	movdqu	16(%rdi,%r8), %xmm3
	movdqu	(%rdx,%r8), %xmm4
	movdqu	16(%rdx,%r8), %xmm5
	pshufd	$245, %xmm4, %xmm6
	pmuludq	%xmm2, %xmm4
	pshufd	$232, %xmm4, %xmm4
	pshufd	$245, %xmm2, %xmm2
	pmuludq	%xmm6, %xmm2
	pshufd	$232, %xmm2, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm1
	pshufd	$245, %xmm5, %xmm2
	pmuludq	%xmm3, %xmm5
	pshufd	$232, %xmm5, %xmm4
	pshufd	$245, %xmm3, %xmm3
	pmuludq	%xmm2, %xmm3
	pshufd	$232, %xmm3, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm0
	addq	$32, %r8
	cmpq	%r8, %rax
	jne	.LBB6_7
	paddd	%xmm1, %xmm0
	pshufd	$238, %xmm0, %xmm1
	paddd	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0
	paddd	%xmm1, %xmm0
	movd	%xmm0, %eax
	jmp	.LBB6_9
.LBB6_11:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.5(%rip), %rdx
	movq	%rcx, %rdi
	movq	%rcx, %rsi
	callq	*_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB6_5:
	.cfi_def_cfa_offset 8
	movl	(%rdx,%rcx,4), %r8d
	imull	(%rdi,%rcx,4), %r8d
	incq	%rcx
	addl	%r8d, %eax
.LBB6_9:
	cmpq	%rcx, %rsi
	jne	.LBB6_5
	retq
.Lfunc_end6:
	.size	_RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed, .Lfunc_end6-_RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed
	.cfi_endproc

	.section	.text._RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced,"ax",@progbits
	.p2align	4
	.type	_RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced,@function
_RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced:
	.cfi_startproc
	cmpq	%rcx, %rsi
	ja	.LBB7_11
	testq	%rsi, %rsi
	je	.LBB7_2
	cmpq	$8, %rsi
	jae	.LBB7_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB7_5
.LBB7_2:
	xorl	%eax, %eax
	retq
.LBB7_6:
	movabsq	$2305843009213693944, %rcx
	andq	%rsi, %rcx
	leaq	(,%rsi,4), %rax
	andq	$-32, %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	pxor	%xmm1, %xmm1
	.p2align	4
.LBB7_7:
	movdqu	(%rdi,%r8), %xmm2
	movdqu	16(%rdi,%r8), %xmm3
	movdqu	(%rdx,%r8), %xmm4
	movdqu	16(%rdx,%r8), %xmm5
	pshufd	$245, %xmm4, %xmm6
	pmuludq	%xmm2, %xmm4
	pshufd	$232, %xmm4, %xmm4
	pshufd	$245, %xmm2, %xmm2
	pmuludq	%xmm6, %xmm2
	pshufd	$232, %xmm2, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm1
	pshufd	$245, %xmm5, %xmm2
	pmuludq	%xmm3, %xmm5
	pshufd	$232, %xmm5, %xmm4
	pshufd	$245, %xmm3, %xmm3
	pmuludq	%xmm2, %xmm3
	pshufd	$232, %xmm3, %xmm2
	punpckldq	%xmm2, %xmm4
	paddd	%xmm4, %xmm0
	addq	$32, %r8
	cmpq	%r8, %rax
	jne	.LBB7_7
	paddd	%xmm1, %xmm0
	pshufd	$238, %xmm0, %xmm1
	paddd	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0
	paddd	%xmm1, %xmm0
	movd	%xmm0, %eax
	jmp	.LBB7_9
.LBB7_11:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.6(%rip), %rax
	xorl	%edi, %edi
	movq	%rcx, %rdx
	movq	%rax, %rcx
	callq	*_RNvNtNtCscI6d9CVNmLh_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB7_5:
	.cfi_def_cfa_offset 8
	movl	(%rdx,%rcx,4), %r8d
	imull	(%rdi,%rcx,4), %r8d
	incq	%rcx
	addl	%r8d, %eax
.LBB7_9:
	cmpq	%rcx, %rsi
	jne	.LBB7_5
	retq
.Lfunc_end7:
	.size	_RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced, .Lfunc_end7-_RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI8_0:
	.long	0
	.long	1
	.long	2
	.long	3
.LCPI8_1:
	.long	4
	.long	4
	.long	4
	.long	4
.LCPI8_2:
	.long	8
	.long	8
	.long	8
	.long	8
.LCPI8_3:
	.long	12
	.long	12
	.long	12
	.long	12
.LCPI8_4:
	.long	16
	.long	16
	.long	16
	.long	16
.LCPI8_5:
	.long	20
	.long	20
	.long	20
	.long	20
.LCPI8_6:
	.long	24
	.long	24
	.long	24
	.long	24
.LCPI8_7:
	.long	28
	.long	28
	.long	28
	.long	28
.LCPI8_8:
	.long	32
	.long	32
	.long	32
	.long	32
.LCPI8_9:
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.LCPI8_10:
	.quad	2
	.quad	2
.LCPI8_11:
	.quad	4
	.quad	4
.LCPI8_12:
	.quad	6
	.quad	6
.LCPI8_13:
	.quad	8
	.quad	8
.LCPI8_14:
	.long	0x3f800000
	.long	0x3f800000
	.long	0x3f800000
	.long	0x3f800000
	.section	.text._RNvCs1HVsbmUPzBG_6bounds4main,"ax",@progbits
	.hidden	_RNvCs1HVsbmUPzBG_6bounds4main
	.globl	_RNvCs1HVsbmUPzBG_6bounds4main
	.p2align	4
	.type	_RNvCs1HVsbmUPzBG_6bounds4main,@function
_RNvCs1HVsbmUPzBG_6bounds4main:
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception0
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	callq	*_RNvCs9hJ03s5DiqP_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$40000000, %edi
	movl	$4, %esi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB8_46
	movq	%rax, %rbx
	movdqa	.LCPI8_0(%rip), %xmm0
	movl	$28, %eax
	movdqa	.LCPI8_1(%rip), %xmm1
	movdqa	.LCPI8_3(%rip), %xmm2
	movdqa	.LCPI8_4(%rip), %xmm3
	movdqa	.LCPI8_5(%rip), %xmm4
	movdqa	.LCPI8_6(%rip), %xmm5
	movdqa	.LCPI8_8(%rip), %xmm6
	.p2align	4
.LBB8_2:
	movdqa	%xmm0, %xmm7
	paddd	%xmm1, %xmm7
	movdqu	%xmm0, -112(%rbx,%rax,4)
	movdqu	%xmm7, -96(%rbx,%rax,4)
	movdqa	%xmm0, %xmm7
	paddd	.LCPI8_2(%rip), %xmm7
	movdqa	%xmm0, %xmm8
	paddd	%xmm2, %xmm8
	movdqu	%xmm7, -80(%rbx,%rax,4)
	movdqu	%xmm8, -64(%rbx,%rax,4)
	movdqa	%xmm0, %xmm7
	paddd	%xmm3, %xmm7
	movdqa	%xmm0, %xmm8
	paddd	%xmm4, %xmm8
	movdqu	%xmm7, -48(%rbx,%rax,4)
	movdqu	%xmm8, -32(%rbx,%rax,4)
	movdqa	%xmm0, %xmm7
	paddd	%xmm5, %xmm7
	movdqa	%xmm0, %xmm8
	paddd	.LCPI8_7(%rip), %xmm8
	movdqu	%xmm7, -16(%rbx,%rax,4)
	movdqu	%xmm8, (%rbx,%rax,4)
	paddd	%xmm6, %xmm0
	addq	$32, %rax
	cmpq	$10000028, %rax
	jne	.LBB8_2
	callq	*_RNvCs9hJ03s5DiqP_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4, %r15d
	movl	$40000000, %edi
	movl	$4, %esi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB8_32
	movq	%rax, %r14
	movdqa	.LCPI8_0(%rip), %xmm0
	movdqa	.LCPI8_2(%rip), %xmm2
	movdqa	.LCPI8_7(%rip), %xmm3
	.p2align	4
.LBB8_5:
	movdqa	%xmm0, %xmm1
	pslld	$3, %xmm1
	psubd	%xmm0, %xmm1
	movdqu	%xmm1, -16(%r14,%r15,4)
	paddd	%xmm3, %xmm1
	movdqu	%xmm1, (%r14,%r15,4)
	paddd	%xmm2, %xmm0
	addq	$8, %r15
	cmpq	$10000004, %r15
	jne	.LBB8_5
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.7(%rip), %rax
	movq	%rax, 72(%rsp)
	movq	$12, 80(%rsp)
.Ltmp0:
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant3now@GOTPCREL(%rip)
.Ltmp1:
	movq	%rax, 88(%rsp)
	movl	%edx, 96(%rsp)
	movl	$20, %ebp
	movq	%rsp, %r15
	.p2align	4
.LBB8_8:
	movq	%rbx, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdi
	movq	8(%rsp), %rsi
	movq	%r14, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdx
	movq	8(%rsp), %rcx
.Ltmp2:
	callq	_RNvCs1HVsbmUPzBG_6bounds17sum_pairs_indexed
.Ltmp3:
	movl	%eax, 52(%rsp)
	decl	%ebp
	jne	.LBB8_8
.Ltmp5:
	leaq	88(%rsp), %rdi
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant7elapsed@GOTPCREL(%rip)
.Ltmp6:
	movq	%rax, %rdi
	movl	%edx, %ecx
	movabsq	$-3689348814741910323, %rdx
	mulq	%rdx
	movq	%rdx, %rsi
	shrq	$4, %rsi
	leaq	(,%rsi,4), %rax
	leaq	(%rax,%rax,4), %rax
	subq	%rax, %rdi
	imulq	$1000000000, %rdi, %rax
	movl	%ecx, %edx
	movl	$3435973837, %edi
	imulq	%rdx, %rdi
	shrq	$36, %rdi
	leal	(,%rdi,4), %edx
	leal	(%rdx,%rdx,4), %edx
	subl	%edx, %ecx
	orq	%rax, %rcx
	movabsq	$922337203685477581, %rdx
	movq	%rcx, %rax
	mulq	%rdx
	addl	%edi, %edx
	movq	%rsi, 56(%rsp)
	movl	%edx, 64(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, (%rsp)
	leaq	_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	_RNvXsa_NtCscI6d9CVNmLh_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 24(%rsp)
	leaq	52(%rsp), %r12
	movq	%r12, 32(%rsp)
	movq	_RNvXs8_NtNtNtCscI6d9CVNmLh_4core3fmt3num3impmNtB9_7Display3fmt@GOTPCREL(%rip), %rbp
	movq	%rbp, 40(%rsp)
.Ltmp7:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1(%rip), %rdi
	movq	%rsp, %rsi
	callq	*_RNvNtNtCsgczF5crJ4sT_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp8:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.8(%rip), %rax
	movq	%rax, 72(%rsp)
	movq	$3, 80(%rsp)
.Ltmp9:
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant3now@GOTPCREL(%rip)
.Ltmp10:
	movq	%rax, 88(%rsp)
	movl	%edx, 96(%rsp)
	movl	$20, %r15d
	movq	%rsp, %r13
	.p2align	4
.LBB8_14:
	movq	%rbx, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdi
	movq	8(%rsp), %rsi
	movq	%r14, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdx
	movq	8(%rsp), %rcx
	callq	_RNvCs1HVsbmUPzBG_6bounds13sum_pairs_zip
	movl	%eax, 52(%rsp)
	decl	%r15d
	jne	.LBB8_14
.Ltmp11:
	leaq	88(%rsp), %rdi
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant7elapsed@GOTPCREL(%rip)
.Ltmp12:
	movq	%rax, %rdi
	movl	%edx, %esi
	movabsq	$-3689348814741910323, %rcx
	mulq	%rcx
	movq	%rdx, %rcx
	shrq	$4, %rcx
	leaq	(,%rcx,4), %rax
	leaq	(%rax,%rax,4), %rax
	subq	%rax, %rdi
	imulq	$1000000000, %rdi, %rax
	movl	%esi, %edx
	movl	$3435973837, %edi
	imulq	%rdx, %rdi
	shrq	$36, %rdi
	leal	(,%rdi,4), %edx
	leal	(%rdx,%rdx,4), %edx
	subl	%edx, %esi
	orq	%rax, %rsi
	movq	%rsi, %rax
	movabsq	$922337203685477581, %rdx
	mulq	%rdx
	addl	%edi, %edx
	movq	%rcx, 56(%rsp)
	movl	%edx, 64(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, (%rsp)
	leaq	_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	_RNvXsa_NtCscI6d9CVNmLh_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 24(%rsp)
	movq	%r12, 32(%rsp)
	movq	%rbp, 40(%rsp)
.Ltmp13:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1(%rip), %rdi
	movq	%rsp, %rsi
	callq	*_RNvNtNtCsgczF5crJ4sT_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp14:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.9(%rip), %rax
	movq	%rax, 72(%rsp)
	movq	$21, 80(%rsp)
.Ltmp15:
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant3now@GOTPCREL(%rip)
.Ltmp16:
	movq	%rax, 88(%rsp)
	movl	%edx, 96(%rsp)
	movl	$20, %r13d
	movq	%rsp, %r15
	.p2align	4
.LBB8_19:
	movq	%rbx, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdi
	movq	8(%rsp), %rsi
	movq	%r14, (%rsp)
	movq	$10000000, 8(%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdx
	movq	8(%rsp), %rcx
.Ltmp17:
	callq	_RNvCs1HVsbmUPzBG_6bounds19sum_pairs_presliced
.Ltmp18:
	movl	%eax, 52(%rsp)
	decl	%r13d
	jne	.LBB8_19
.Ltmp20:
	leaq	88(%rsp), %rdi
	callq	*_RNvMNtCsgczF5crJ4sT_3std4timeNtB2_7Instant7elapsed@GOTPCREL(%rip)
.Ltmp21:
	movq	%rax, %rdi
	movl	%edx, %esi
	movabsq	$-3689348814741910323, %rcx
	mulq	%rcx
	movq	%rdx, %rcx
	shrq	$4, %rcx
	leaq	(,%rcx,4), %rax
	leaq	(%rax,%rax,4), %rax
	subq	%rax, %rdi
	imulq	$1000000000, %rdi, %rax
	movl	%esi, %edx
	movl	$3435973837, %edi
	imulq	%rdx, %rdi
	shrq	$36, %rdi
	leal	(,%rdi,4), %edx
	leal	(%rdx,%rdx,4), %edx
	subl	%edx, %esi
	orq	%rax, %rsi
	movq	%rsi, %rax
	movabsq	$922337203685477581, %rdx
	mulq	%rdx
	addl	%edi, %edx
	movq	%rcx, 56(%rsp)
	movl	%edx, 64(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, (%rsp)
	leaq	_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	_RNvXsa_NtCscI6d9CVNmLh_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 24(%rsp)
	movq	%r12, 32(%rsp)
	movq	%rbp, 40(%rsp)
.Ltmp22:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1(%rip), %rdi
	movq	%rsp, %rsi
	callq	*_RNvNtNtCsgczF5crJ4sT_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp23:
	callq	*_RNvCs9hJ03s5DiqP_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8000, %edi
	movl	$8, %esi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB8_39
	movq	%rax, %r15
	movdqa	.LCPI8_9(%rip), %xmm0
	movl	$6, %eax
	movdqa	.LCPI8_10(%rip), %xmm1
	movdqa	.LCPI8_11(%rip), %xmm2
	movdqa	.LCPI8_12(%rip), %xmm3
	movdqa	.LCPI8_13(%rip), %xmm4
	.p2align	4
.LBB8_25:
	movdqa	%xmm0, %xmm5
	paddq	%xmm1, %xmm5
	movdqu	%xmm0, -48(%r15,%rax,8)
	movdqu	%xmm5, -32(%r15,%rax,8)
	movdqa	%xmm0, %xmm5
	paddq	%xmm2, %xmm5
	movdqa	%xmm0, %xmm6
	paddq	%xmm3, %xmm6
	movdqu	%xmm5, -16(%r15,%rax,8)
	movdqu	%xmm6, (%r15,%rax,8)
	paddq	%xmm4, %xmm0
	addq	$8, %rax
	cmpq	$1006, %rax
	jne	.LBB8_25
	callq	*_RNvCs9hJ03s5DiqP_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4000, %edi
	movl	$4, %esi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB8_40
	movq	%rax, %r12
	movl	$28, %eax
	movdqa	.LCPI8_14(%rip), %xmm0
	.p2align	4
.LBB8_28:
	movdqu	%xmm0, -112(%r12,%rax,4)
	movdqu	%xmm0, -96(%r12,%rax,4)
	movdqu	%xmm0, -80(%r12,%rax,4)
	movdqu	%xmm0, -64(%r12,%rax,4)
	movdqu	%xmm0, -48(%r12,%rax,4)
	movdqu	%xmm0, -32(%r12,%rax,4)
	movdqu	%xmm0, -16(%r12,%rax,4)
	movdqu	%xmm0, (%r12,%rax,4)
	addq	$32, %rax
	cmpq	$1020, %rax
	jne	.LBB8_28
	movdqu	%xmm0, 3968(%r12)
	movdqu	%xmm0, 3984(%r12)
.Ltmp24:
	movl	$1000, %esi
	movl	$1000, %ecx
	movl	$1000, %r9d
	movq	%r12, %rdi
	movq	%r12, %rdx
	movq	%r15, %r8
	callq	_RNvCs1HVsbmUPzBG_6bounds11dot_indexed
.Ltmp25:
	movd	%xmm0, 56(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, (%rsp)
	movq	_RNvXs3_NtNtCscI6d9CVNmLh_4core3fmt5floatfNtB7_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 8(%rsp)
.Ltmp26:
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.10(%rip), %rdi
	movq	%rsp, %rsi
	callq	*_RNvNtNtCsgczF5crJ4sT_3std2io5stdio6__print@GOTPCREL(%rip)
.Ltmp27:
	movq	_RNvCs9hJ03s5DiqP_7___rustc14___rust_dealloc@GOTPCREL(%rip), %r13
	movl	$4000, %esi
	movl	$4, %edx
	movq	%r12, %rdi
	callq	*%r13
	movl	$8000, %esi
	movl	$8, %edx
	movq	%r15, %rdi
	callq	*%r13
	movl	$40000000, %esi
	movl	$4, %edx
	movq	%r14, %rdi
	callq	*%r13
	movl	$40000000, %esi
	movl	$4, %edx
	movq	%rbx, %rdi
	callq	*%r13
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB8_46:
	.cfi_def_cfa_offset 160
	movl	$4, %edi
	movl	$40000000, %esi
	callq	*_RNvNtCs40k4W9msRzi_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB8_32:
.Ltmp35:
	movl	$4, %edi
	movl	$40000000, %esi
	callq	*_RNvNtCs40k4W9msRzi_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp36:
	jmp	.LBB8_33
.LBB8_39:
.Ltmp32:
	movl	$8, %edi
	movl	$8000, %esi
	callq	*_RNvNtCs40k4W9msRzi_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp33:
	jmp	.LBB8_33
.LBB8_40:
.Ltmp29:
	movl	$4, %edi
	movl	$4000, %esi
	callq	*_RNvNtCs40k4W9msRzi_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp30:
.LBB8_33:
	ud2
.LBB8_41:
.Ltmp31:
	movq	%rax, %r13
	jmp	.LBB8_43
.LBB8_44:
.Ltmp37:
	movq	%rax, %r13
	jmp	.LBB8_45
.LBB8_42:
.Ltmp28:
	movq	%rax, %r13
	movl	$4000, %esi
	movl	$4, %edx
	movq	%r12, %rdi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB8_43:
	movl	$8000, %esi
	movl	$8, %edx
	movq	%r15, %rdi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB8_37
.LBB8_38:
.Ltmp34:
	jmp	.LBB8_36
.LBB8_34:
.Ltmp19:
	jmp	.LBB8_36
.LBB8_35:
.Ltmp4:
.LBB8_36:
	movq	%rax, %r13
.LBB8_37:
	movl	$40000000, %esi
	movl	$4, %edx
	movq	%r14, %rdi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB8_45:
	movl	$40000000, %esi
	movl	$4, %edx
	movq	%rbx, %rdi
	callq	*_RNvCs9hJ03s5DiqP_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r13, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end8:
	.size	_RNvCs1HVsbmUPzBG_6bounds4main, .Lfunc_end8-_RNvCs1HVsbmUPzBG_6bounds4main
	.cfi_endproc
	.section	.gcc_except_table._RNvCs1HVsbmUPzBG_6bounds4main,"a",@progbits
	.p2align	2, 0x0
GCC_except_table8:
.Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp0-.Lfunc_begin0
	.uleb128 .Ltmp1-.Ltmp0
	.uleb128 .Ltmp34-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp2-.Lfunc_begin0
	.uleb128 .Ltmp3-.Ltmp2
	.uleb128 .Ltmp4-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp5-.Lfunc_begin0
	.uleb128 .Ltmp16-.Ltmp5
	.uleb128 .Ltmp34-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp17-.Lfunc_begin0
	.uleb128 .Ltmp18-.Ltmp17
	.uleb128 .Ltmp19-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp20-.Lfunc_begin0
	.uleb128 .Ltmp23-.Ltmp20
	.uleb128 .Ltmp34-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp24-.Lfunc_begin0
	.uleb128 .Ltmp27-.Ltmp24
	.uleb128 .Ltmp28-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp27-.Lfunc_begin0
	.uleb128 .Ltmp35-.Ltmp27
	.byte	0
	.byte	0
	.uleb128 .Ltmp35-.Lfunc_begin0
	.uleb128 .Ltmp36-.Ltmp35
	.uleb128 .Ltmp37-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp32-.Lfunc_begin0
	.uleb128 .Ltmp33-.Ltmp32
	.uleb128 .Ltmp34-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp29-.Lfunc_begin0
	.uleb128 .Ltmp30-.Ltmp29
	.uleb128 .Ltmp31-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp30-.Lfunc_begin0
	.uleb128 .Lfunc_end8-.Ltmp30
	.byte	0
	.byte	0
.Lcst_end0:
	.p2align	2, 0x0

	.section	.text._RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds,"ax",@progbits
	.p2align	4
	.type	_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds,@function
_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds:
	.cfi_startproc
	movq	%rsi, %rdx
	movq	(%rdi), %rax
	movq	8(%rdi), %rsi
	movq	%rax, %rdi
	jmpq	*_RNvXsi_NtCscI6d9CVNmLh_4core3fmteNtB5_7Display3fmt@GOTPCREL(%rip)
.Lfunc_end9:
	.size	_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds, .Lfunc_end9-_RNvXs1i_NtCscI6d9CVNmLh_4core3fmtReNtB6_7Display3fmtCs1HVsbmUPzBG_6bounds
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCs1HVsbmUPzBG_6bounds4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCsgczF5crJ4sT_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end10:
	.size	main, .Lfunc_end10-main
	.cfi_endproc

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0:
	.asciz	"bounds.rs"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0, 10

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1,@object
	.section	.rodata..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1,"a",@progbits
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1:
	.asciz	"\303 \000\000\b\026\000\001 \307 \000\0008\006\000\001\000\n  (result \300\002)\n"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.1, 34

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2,@object
	.section	.data.rel.ro..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0INtNtNtCscI6d9CVNmLh_4core3ops8function6FnOnceuE9call_once6vtableCs1HVsbmUPzBG_6bounds
	.quad	_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds
	.quad	_RNCINvNtCsgczF5crJ4sT_3std2rt10lang_startuE0Cs1HVsbmUPzBG_6bounds
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.2, 48

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.3,@object
	.section	.data.rel.ro..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.3,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.3:
	.quad	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0
	.asciz	"\t\000\000\000\000\000\000\000\t\000\000\000\016\000\000"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.3, 24

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.4,@object
	.section	.data.rel.ro..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.4,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.4:
	.quad	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0
	.asciz	"\t\000\000\000\000\000\000\000\t\000\000\000\025\000\000"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.4, 24

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.5,@object
	.section	.data.rel.ro..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.5,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.5:
	.quad	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0
	.asciz	"\t\000\000\000\000\000\000\000\022\000\000\000.\000\000"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.5, 24

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.6,@object
	.section	.data.rel.ro..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.6:
	.quad	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.0
	.asciz	"\t\000\000\000\000\000\000\000\036\000\000\000\017\000\000"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.6, 24

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.7,@object
	.section	.rodata..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.7,"a",@progbits
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.7:
	.ascii	"indexed loop"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.7, 12

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.8,@object
	.section	.rodata..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.8,"a",@progbits
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.8:
	.ascii	"zip"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.8, 3

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.9,@object
	.section	.rodata..Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.9,"a",@progbits
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.9:
	.ascii	"pre-sliced index loop"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.9, 21

	.type	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.10,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.10:
	.asciz	"\016dot_indexed = \300\001\n"
	.size	.Lanon.e2fd577cd1c4b16c5c9c9fddb6535c0b.10, 19

	.hidden	DW.ref.rust_eh_personality
	.weak	DW.ref.rust_eh_personality
	.section	.data.DW.ref.rust_eh_personality,"awG",@progbits,DW.ref.rust_eh_personality,comdat
	.p2align	3, 0x0
	.type	DW.ref.rust_eh_personality,@object
	.size	DW.ref.rust_eh_personality, 8
DW.ref.rust_eh_personality:
	.quad	rust_eh_personality
	.ident	"rustc version 1.97.0 (2d8144b78 2026-07-07)"
	.section	".note.GNU-stack","",@progbits
