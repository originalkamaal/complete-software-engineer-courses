// file: allocs.rs
use std::alloc::{GlobalAlloc, Layout, System};
use std::fmt::Write;
use std::sync::atomic::{AtomicUsize, Ordering};

struct Counting;
static ALLOCS: AtomicUsize = AtomicUsize::new(0);

// SAFETY: forwards every call to the system allocator unchanged.
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        ALLOCS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.alloc(l) }
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        unsafe { System.dealloc(p, l) }
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        ALLOCS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.realloc(p, l, n) }
    }
}

#[global_allocator]
static GLOBAL: Counting = Counting;

fn measure(label: &str, f: impl FnOnce() -> usize) {
    let before = ALLOCS.load(Ordering::Relaxed);
    let result = f();
    println!("{label:<50} {:>6} allocations (result {result})", ALLOCS.load(Ordering::Relaxed) - before);
}

fn main() {
    let words: Vec<&str> = "the quick brown fox jumps over the lazy dog".split(' ').collect();
    measure("format! per item, collect, join", || {
        let parts: Vec<String> = (0..10_000).map(|i| format!("{}-{}", words[i % 9], i)).collect();
        parts.join(",").len()
    });
    measure("one String, write! into it", || {
        let mut s = String::new();
        for i in 0..10_000 {
            if i > 0 { s.push(','); }
            write!(s, "{}-{}", words[i % 9], i).unwrap();
        }
        s.len()
    });
    measure("same, with_capacity first", || {
        let mut s = String::with_capacity(10_000 * 10);
        for i in 0..10_000 {
            if i > 0 { s.push(','); }
            write!(s, "{}-{}", words[i % 9], i).unwrap();
        }
        s.len()
    });
    measure("to_uppercase per word, new Vec each round", || {
        (0..1000).map(|_| words.iter().map(|w| w.to_uppercase()).collect::<Vec<_>>().len()).sum()
    });
    measure("reuse one buffer per word (clear keeps capacity)", || {
        let mut buf = String::new();
        let mut total = 0;
        for _ in 0..1000 {
            for w in &words {
                buf.clear();
                buf.extend(w.chars().flat_map(char::to_uppercase));
                total += buf.len();
            }
        }
        total
    });
}
