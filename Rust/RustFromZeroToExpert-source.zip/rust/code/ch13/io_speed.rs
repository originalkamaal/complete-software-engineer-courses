// file: io_speed.rs
use std::fs::File;
use std::io::{BufWriter, Write};
use std::time::Instant;

fn main() -> std::io::Result<()> {
    let n = 200_000;
    let mode = std::env::args().nth(1).unwrap_or_default();     // "unbuffered", "buffered", or both
    let t = Instant::now();
    if mode != "buffered" {
        let mut f = File::create("unbuffered.txt")?;
        for i in 0..n {
            writeln!(f, "line {i}")?;                   // write(2) system calls for every line
        }
    }
    let unbuffered = t.elapsed();
    if mode == "unbuffered" {
        return Ok(());
    }

    let t = Instant::now();
    let mut f = BufWriter::new(File::create("buffered.txt")?);   // 8 KiB buffer
    for i in 0..n {
        writeln!(f, "line {i}")?;
    }
    f.flush()?;                                         // flush explicitly: errors in drop are ignored (DT-14)
    let buffered = t.elapsed();
    println!("{n} lines: unbuffered {unbuffered:.0?}, BufWriter {buffered:.1?} ({:.0}x)", unbuffered.as_secs_f64() / buffered.as_secs_f64());
    Ok(())
}
