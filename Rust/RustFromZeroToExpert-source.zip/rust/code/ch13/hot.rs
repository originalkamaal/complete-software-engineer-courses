// file: hot.rs
#[inline(never)]
fn slow_part(n: u64) -> u64 { (0..n).map(|i| i.wrapping_mul(i) % 7).sum() }
#[inline(never)]
fn fast_part(n: u64) -> u64 { (0..n).sum() }

fn main() {
    let mut total = 0;
    for _ in 0..500 {
        total += std::hint::black_box(slow_part(2_000_000));
        total += std::hint::black_box(fast_part(2_000_000));
    }
    println!("{total}");
}
