// file: kvr/src/lib.rs
//! kvr: a small persistent key-value server. See Chapter 14.
pub mod server;
pub mod store;
pub mod wal;
