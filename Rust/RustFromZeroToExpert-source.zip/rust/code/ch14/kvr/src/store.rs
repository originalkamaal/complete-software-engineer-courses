// file: kvr/src/store.rs
use crate::wal::{self, Op, Wal};
use std::collections::HashMap;
use std::io;
use std::path::{Path, PathBuf};

/// When a commit waits for the disk.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum SyncPolicy {
    /// fdatasync before acknowledging: survives power loss.
    Always,
    /// hand to the OS before acknowledging: survives a process crash, not power loss.
    Never,
}

#[derive(Default, Debug)]
pub struct Stats {
    pub sets: u64,
    pub dels: u64,
    pub gets: u64,
    pub commits: u64,
    pub compactions: u64,
}

pub struct Store {
    map: HashMap<Vec<u8>, Vec<u8>>,
    wal: Wal,
    dir: PathBuf,
    sync: SyncPolicy,
    pending: bool,
    pub stats: Stats,
}

fn apply(map: &mut HashMap<Vec<u8>, Vec<u8>>, op: Op) {
    match op {
        Op::Set(k, v) => {
            map.insert(k, v);
        }
        Op::Del(k) => {
            map.remove(&k);
        }
    }
}

impl Store {
    /// Opens (or creates) a store in `dir`: snapshot, then log replay. Returns a recovery report.
    pub fn open(dir: &Path, sync: SyncPolicy) -> io::Result<(Store, String)> {
        std::fs::create_dir_all(dir)?;
        let mut map = HashMap::new();
        let mut from_snapshot = 0;
        let snap = dir.join("snapshot.db");
        if snap.exists() {
            let data = std::fs::read(&snap)?;
            let (ops, valid) = wal::decode_all(&data);
            if valid != data.len() {
                return Err(io::Error::new(io::ErrorKind::InvalidData, "snapshot.db is corrupt"));
            }
            from_snapshot = ops.len();
            ops.into_iter().for_each(|op| apply(&mut map, op));
        }
        let log = dir.join("wal.log");
        let rec = wal::recover(&log)?;
        let replayed = rec.ops.len();
        rec.ops.into_iter().for_each(|op| apply(&mut map, op));
        let report = format!(
            "recovered {} keys: {from_snapshot} from snapshot, {replayed} log records replayed, {} bytes of torn/corrupt tail discarded",
            map.len(), rec.truncated
        );
        let wal = Wal::open_append(&log)?;
        Ok((Store { map, wal, dir: dir.to_path_buf(), sync, pending: false, stats: Stats::default() }, report))
    }

    pub fn get(&mut self, key: &[u8]) -> Option<&Vec<u8>> {
        self.stats.gets += 1;
        self.map.get(key)
    }

    /// Logs and applies a set. Not durable until `commit`.
    pub fn set(&mut self, key: Vec<u8>, value: Vec<u8>) -> io::Result<()> {
        let op = Op::Set(key, value);
        self.wal.append(&op)?;                                 // log first...
        apply(&mut self.map, op);                              // ...then apply
        self.pending = true;
        self.stats.sets += 1;
        Ok(())
    }

    pub fn del(&mut self, key: &[u8]) -> io::Result<bool> {
        if !self.map.contains_key(key) {
            return Ok(false);
        }
        self.wal.append(&Op::Del(key.to_vec()))?;
        self.map.remove(key);
        self.pending = true;
        self.stats.dels += 1;
        Ok(true)
    }

    /// Makes all writes so far durable according to the policy. Called once per batch.
    pub fn commit(&mut self) -> io::Result<()> {
        if self.pending {
            self.wal.commit(self.sync == SyncPolicy::Always)?;
            self.pending = false;
            self.stats.commits += 1;
        }
        Ok(())
    }

    pub fn keys(&self, prefix: &[u8]) -> Vec<&Vec<u8>> {
        let mut keys: Vec<&Vec<u8>> = self.map.keys().filter(|k| k.starts_with(prefix)).collect();
        keys.sort();
        keys
    }

    /// Writes a snapshot and empties the log. Returns (log bytes before, snapshot bytes).
    pub fn compact(&mut self) -> io::Result<(u64, u64)> {
        self.commit()?;
        let before = self.wal.bytes;
        let snapshot = wal::write_snapshot(&self.dir, self.map.iter())?;
        self.wal.reset()?;                                     // a crash before this line is harmless (DT-37)
        self.stats.compactions += 1;
        Ok((before, snapshot))
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn log_bytes(&self) -> u64 {
        self.wal.bytes
    }
}
