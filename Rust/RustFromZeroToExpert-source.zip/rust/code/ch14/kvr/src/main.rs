// file: kvr/src/main.rs
use kvr::store::{Store, SyncPolicy};
use std::io;
use std::time::{Duration, Instant};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader, Lines};
use tokio::net::TcpStream;
use tokio::net::tcp::{OwnedReadHalf, OwnedWriteHalf};

struct Client {
    lines: Lines<BufReader<OwnedReadHalf>>,
    writer: OwnedWriteHalf,
}

impl Client {
    async fn connect(port: u16) -> io::Result<Client> {
        let stream = TcpStream::connect(("127.0.0.1", port)).await?;
        stream.set_nodelay(true)?;
        let (r, writer) = stream.into_split();
        Ok(Client { lines: BufReader::new(r).lines(), writer })
    }
    async fn call(&mut self, request: &str) -> io::Result<String> {
        self.writer.write_all(format!("{request}\n").as_bytes()).await?;
        self.lines.next_line().await?.ok_or_else(|| io::Error::new(io::ErrorKind::UnexpectedEof, "server closed"))
    }
}

fn opt(args: &[String], name: &str, default: &str) -> String {
    args.windows(2).find(|w| w[0] == name).map(|w| w[1].clone()).unwrap_or_else(|| default.to_string())
}

async fn load(port: u16, conns: usize, ops: usize, keyspace: u64) -> io::Result<()> {
    let start = Instant::now();
    let mut tasks = Vec::new();
    for c in 0..conns {
        tasks.push(tokio::spawn(async move {
            let mut client = Client::connect(port).await?;
            let mut lat = Vec::with_capacity(ops);
            let mut x = 0x9E37_79B9_7F4A_7C15u64 ^ c as u64;
            for _ in 0..ops {
                x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                let key = x % keyspace;
                let req = if x % 2 == 0 { format!("SET k{key} v{x}") } else { format!("GET k{key}") };
                let t = Instant::now();
                client.call(&req).await?;
                lat.push(t.elapsed());
            }
            Ok::<_, io::Error>(lat)
        }));
    }
    let mut all = Vec::new();
    for t in tasks {
        all.extend(t.await.unwrap()?);
    }
    let elapsed = start.elapsed();
    all.sort();
    let pct = |p: f64| all[((all.len() - 1) as f64 * p) as usize];
    println!("{conns} conns x {ops} ops: {:.0} ops/s, latency p50 {:.2?} p99 {:.2?} max {:.2?}",
             all.len() as f64 / elapsed.as_secs_f64(), pct(0.5), pct(0.99), all[all.len() - 1]);
    Ok(())
}

#[tokio::main]
async fn main() -> io::Result<()> {
    let args: Vec<String> = std::env::args().collect();
    let port: u16 = opt(&args, "--port", "7400").parse().expect("port");
    match args.get(1).map(String::as_str) {
        Some("serve") => {
            let dir = opt(&args, "--dir", "data");
            let sync = if opt(&args, "--sync", "always") == "never" { SyncPolicy::Never } else { SyncPolicy::Always };
            let (store, report) = Store::open(dir.as_ref(), sync)?;
            eprintln!("{report}");
            let listener = tokio::net::TcpListener::bind(("127.0.0.1", port)).await?;
            eprintln!("kvr listening on 127.0.0.1:{port}, sync {sync:?}");
            kvr::server::run(listener, store).await
        }
        Some("writer") => {
            let mut client = Client::connect(port).await?;
            for i in 0u64.. {
                match client.call(&format!("SET key{i} value-{i}")).await {
                    Ok(r) if r == "OK" => println!("{i}"),           // printed only after the ack
                    _ => break,
                }
            }
            Ok(())
        }
        Some("check") => {
            let upto: u64 = opt(&args, "--upto", "0").parse().expect("number");
            let mut client = Client::connect(port).await?;
            let mut missing = 0;
            for i in 0..=upto {
                if client.call(&format!("GET key{i}")).await? != format!("VALUE value-{i}") {
                    missing += 1;
                }
            }
            println!("checked key0..=key{upto}: {missing} missing");
            Ok(())
        }
        Some("load") => {
            let conns = opt(&args, "--conns", "50").parse().unwrap();
            let ops = opt(&args, "--ops", "1000").parse().unwrap();
            load(port, conns, ops, 10_000).await
        }
        _ => {
            eprintln!("usage: kvr serve|writer|check|load [--port P] [--dir D] [--sync always|never] [--upto N] [--conns C --ops N]");
            tokio::time::sleep(Duration::from_millis(1)).await;
            Ok(())
        }
    }
}
