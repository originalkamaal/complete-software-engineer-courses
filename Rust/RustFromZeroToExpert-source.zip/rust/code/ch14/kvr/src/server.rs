// file: kvr/src/server.rs
use crate::store::Store;
use std::io;
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{mpsc, oneshot};

#[derive(Debug, PartialEq)]
pub enum Cmd {
    Get(Vec<u8>),
    Set(Vec<u8>, Vec<u8>),
    Del(Vec<u8>),
    Keys(Vec<u8>),
    Stats,
    Compact,
}

type Job = (Cmd, oneshot::Sender<String>);
const MAX_BATCH: usize = 256;

/// Parses one request line.
pub fn parse(line: &str) -> Result<Cmd, String> {
    let mut parts = line.splitn(3, ' ');
    let verb = parts.next().unwrap_or("").to_ascii_uppercase();
    match (verb.as_str(), parts.next(), parts.next()) {
        ("GET", Some(k), None) => Ok(Cmd::Get(k.into())),
        ("SET", Some(k), Some(v)) => Ok(Cmd::Set(k.into(), v.into())),
        ("DEL", Some(k), None) => Ok(Cmd::Del(k.into())),
        ("KEYS", prefix, None) => Ok(Cmd::Keys(prefix.unwrap_or("").into())),
        ("STATS", None, None) => Ok(Cmd::Stats),
        ("COMPACT", None, None) => Ok(Cmd::Compact),
        _ => Err(format!("ERR cannot parse {line:?}")),
    }
}

fn execute(store: &mut Store, cmd: Cmd) -> io::Result<String> {
    Ok(match cmd {
        Cmd::Get(k) => match store.get(&k) {
            Some(v) => format!("VALUE {}", String::from_utf8_lossy(v)),
            None => "NIL".to_string(),
        },
        Cmd::Set(k, v) => {
            store.set(k, v)?;
            "OK".to_string()
        }
        Cmd::Del(k) => format!("OK {}", u8::from(store.del(&k)?)),
        Cmd::Keys(prefix) => {
            let keys = store.keys(&prefix);
            let shown: Vec<String> = keys.iter().take(20).map(|k| String::from_utf8_lossy(k).into_owned()).collect();
            format!("KEYS {} {}", keys.len(), shown.join(" "))
        }
        Cmd::Stats => format!("STATS keys={} log_bytes={} {:?}", store.len(), store.log_bytes(), store.stats),
        Cmd::Compact => {
            let (log, snap) = store.compact()?;
            format!("OK compacted {log} log bytes into a {snap}-byte snapshot")
        }
    })
}

/// The storage thread owns the Store. It executes commands in batches and commits once per batch
/// (group commit), replying only after the commit — so an acknowledged write is durable.
fn storage_thread(mut store: Store, mut jobs: mpsc::Receiver<Job>) {
    let mut batch: Vec<Job> = Vec::with_capacity(MAX_BATCH);
    let mut replies: Vec<(oneshot::Sender<String>, String)> = Vec::with_capacity(MAX_BATCH);
    while let Some(first) = jobs.blocking_recv() {
        batch.push(first);
        while batch.len() < MAX_BATCH {
            match jobs.try_recv() {
                Ok(job) => batch.push(job),
                Err(_) => break,
            }
        }
        for (cmd, reply) in batch.drain(..) {
            let answer = execute(&mut store, cmd).unwrap_or_else(|e| format!("ERR {e}"));
            replies.push((reply, answer));
        }
        let committed = store.commit();
        for (reply, answer) in replies.drain(..) {
            let _ = reply.send(match &committed {
                Ok(()) => answer,
                Err(e) => format!("ERR commit failed: {e}"),
            });
        }
    }
}

async fn connection(stream: TcpStream, jobs: mpsc::Sender<Job>) -> io::Result<()> {
    stream.set_nodelay(true)?;
    let (reader, mut writer) = stream.into_split();
    let mut lines = BufReader::new(reader).lines();
    while let Some(line) = lines.next_line().await? {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if line.eq_ignore_ascii_case("QUIT") {
            break;
        }
        let answer = match parse(line) {
            Ok(cmd) => {
                let (tx, rx) = oneshot::channel();
                if jobs.send((cmd, tx)).await.is_err() {
                    break;
                }
                rx.await.unwrap_or_else(|_| "ERR storage thread stopped".to_string())
            }
            Err(e) => e,
        };
        writer.write_all(answer.as_bytes()).await?;
        writer.write_all(b"\n").await?;
    }
    Ok(())
}

/// Serves connections from `listener` until the process ends.
pub async fn run(listener: TcpListener, store: Store) -> io::Result<()> {
    let (tx, rx) = mpsc::channel::<Job>(4096);
    std::thread::Builder::new().name("storage".into()).spawn(move || storage_thread(store, rx))?;
    loop {
        let (stream, _) = listener.accept().await?;
        let jobs = tx.clone();
        tokio::spawn(async move {
            let _ = connection(stream, jobs).await;
        });
    }
}
