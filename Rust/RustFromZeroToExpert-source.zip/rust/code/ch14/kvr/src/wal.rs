// file: kvr/src/wal.rs
//! The write-ahead log and snapshot format.
//!
//! Record: `len: u32 LE | crc32(payload): u32 LE | payload`
//! Payload: `tag: u8 (1 = set, 2 = delete) | key_len: u32 LE | key | value`
use std::fs::{File, OpenOptions};
use std::io::{self, BufWriter, Write};
use std::path::Path;

#[derive(Debug, Clone, PartialEq)]
pub enum Op {
    Set(Vec<u8>, Vec<u8>),
    Del(Vec<u8>),
}

fn encode_parts(tag: u8, key: &[u8], value: &[u8], out: &mut Vec<u8>) {
    let start = out.len();
    out.extend_from_slice(&((1 + 4 + key.len() + value.len()) as u32).to_le_bytes());
    out.extend_from_slice(&[0; 4]);                                // CRC placeholder
    out.push(tag);
    out.extend_from_slice(&(key.len() as u32).to_le_bytes());
    out.extend_from_slice(key);
    out.extend_from_slice(value);
    let crc = crc32fast::hash(&out[start + 8..]);
    out[start + 4..start + 8].copy_from_slice(&crc.to_le_bytes());
}

/// Appends the encoded record for `op` to `out`.
pub fn encode(op: &Op, out: &mut Vec<u8>) {
    match op {
        Op::Set(k, v) => encode_parts(1, k, v, out),
        Op::Del(k) => encode_parts(2, k, &[], out),
    }
}

fn decode_one(d: &[u8]) -> Option<(Op, usize)> {
    let len = u32::from_le_bytes(d.get(0..4)?.try_into().ok()?) as usize;
    let crc = u32::from_le_bytes(d.get(4..8)?.try_into().ok()?);
    let payload = d.get(8..8usize.checked_add(len)?)?;             // a truncated record ends here
    if payload.len() < 5 || crc32fast::hash(payload) != crc {      // a corrupt one here
        return None;
    }
    let key_len = u32::from_le_bytes(payload[1..5].try_into().ok()?) as usize;
    let key = payload.get(5..5usize.checked_add(key_len)?)?.to_vec();
    let value = payload[5 + key_len..].to_vec();
    let op = match payload[0] {
        1 => Op::Set(key, value),
        2 if value.is_empty() => Op::Del(key),
        _ => return None,
    };
    Some((op, 8 + len))
}

/// Decodes records until the end of `data` or the first invalid record.
/// Returns the operations and the number of bytes that were valid.
pub fn decode_all(data: &[u8]) -> (Vec<Op>, usize) {
    let mut ops = Vec::new();
    let mut pos = 0;
    while let Some((op, used)) = decode_one(&data[pos..]) {
        ops.push(op);
        pos += used;
    }
    (ops, pos)
}

/// What recovery found in the log.
pub struct Recovered {
    pub ops: Vec<Op>,
    pub truncated: u64,
}

/// Reads the log, and truncates an invalid tail (a torn or corrupt last write) so appends continue after valid data.
pub fn recover(path: &Path) -> io::Result<Recovered> {
    let data = match std::fs::read(path) {
        Ok(d) => d,
        Err(e) if e.kind() == io::ErrorKind::NotFound => Vec::new(),
        Err(e) => return Err(e),
    };
    let (ops, valid) = decode_all(&data);
    let truncated = (data.len() - valid) as u64;
    if truncated > 0 {
        let f = OpenOptions::new().write(true).open(path)?;
        f.set_len(valid as u64)?;
        f.sync_all()?;
    }
    Ok(Recovered { ops, truncated })
}

/// An open log, appending through a buffer.
pub struct Wal {
    out: BufWriter<File>,
    pub bytes: u64,
    scratch: Vec<u8>,
}

impl Wal {
    pub fn open_append(path: &Path) -> io::Result<Wal> {
        let f = OpenOptions::new().create(true).append(true).open(path)?;
        let bytes = f.metadata()?.len();
        Ok(Wal { out: BufWriter::with_capacity(1 << 16, f), bytes, scratch: Vec::new() })
    }

    pub fn append(&mut self, op: &Op) -> io::Result<()> {
        self.scratch.clear();
        encode(op, &mut self.scratch);
        self.out.write_all(&self.scratch)?;
        self.bytes += self.scratch.len() as u64;
        Ok(())
    }

    /// Hands buffered records to the OS; with `sync`, waits until they are on disk.
    pub fn commit(&mut self, sync: bool) -> io::Result<()> {
        self.out.flush()?;
        if sync {
            self.out.get_ref().sync_data()?;
        }
        Ok(())
    }

    /// Empties the log (after a snapshot has made its contents redundant).
    pub fn reset(&mut self) -> io::Result<()> {
        self.out.flush()?;
        self.out.get_ref().set_len(0)?;
        self.out.get_ref().sync_all()?;
        self.bytes = 0;
        Ok(())
    }
}

/// Writes all entries as a snapshot, atomically: temporary file, fsync, rename, fsync the directory.
pub fn write_snapshot<'a>(dir: &Path, entries: impl Iterator<Item = (&'a Vec<u8>, &'a Vec<u8>)>) -> io::Result<u64> {
    let tmp = dir.join("snapshot.tmp");
    let mut out = BufWriter::new(File::create(&tmp)?);
    let mut buf = Vec::new();
    let mut written = 0;
    for (k, v) in entries {
        buf.clear();
        encode_parts(1, k, v, &mut buf);
        out.write_all(&buf)?;
        written += buf.len() as u64;
    }
    let file = out.into_inner().map_err(|e| e.into_error())?;
    file.sync_all()?;                                              // the data is on disk...
    std::fs::rename(&tmp, dir.join("snapshot.db"))?;               // ...before the name points to it
    File::open(dir)?.sync_all()?;                                  // and the rename itself is durable
    Ok(written)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> Vec<Op> {
        vec![Op::Set(b"a".to_vec(), b"1".to_vec()), Op::Del(b"a".to_vec()), Op::Set(b"key".to_vec(), vec![0, 255, 10])]
    }

    #[test]
    fn round_trip() {
        let mut buf = Vec::new();
        for op in sample() {
            encode(&op, &mut buf);
        }
        assert_eq!(decode_all(&buf), (sample(), buf.len()));
    }

    #[test]
    fn every_torn_tail_is_detected() {
        let mut buf = Vec::new();
        for op in sample() {
            encode(&op, &mut buf);
        }
        let mut first_two = Vec::new();
        encode(&sample()[0], &mut first_two);
        encode(&sample()[1], &mut first_two);
        for cut in first_two.len()..buf.len() {                     // cut the last record at every byte
            let (ops, valid) = decode_all(&buf[..cut]);
            assert_eq!((ops.len(), valid), (2, first_two.len()), "cut at {cut}");
        }
    }

    #[test]
    fn corruption_stops_replay_at_the_bad_record() {
        let mut buf = Vec::new();
        for op in sample() {
            encode(&op, &mut buf);
        }
        let mut first = Vec::new();
        encode(&sample()[0], &mut first);
        buf[first.len() + 9] ^= 0x40;                               // flip a bit inside record 2
        assert_eq!(decode_all(&buf).0, vec![sample()[0].clone()]);
    }
}
