// file: kvr/tests/protocol.rs
use kvr::store::{Store, SyncPolicy};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};

#[tokio::test]
async fn protocol_and_persistence() {
    let dir = std::env::temp_dir().join(format!("kvr-test-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let (store, report) = Store::open(&dir, SyncPolicy::Always).unwrap();
    assert!(report.starts_with("recovered 0 keys"), "{report}");
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    tokio::spawn(kvr::server::run(listener, store));

    let stream = TcpStream::connect(("127.0.0.1", port)).await.unwrap();
    let (r, mut w) = stream.into_split();
    let mut lines = BufReader::new(r).lines();
    let script = [
        ("SET user:1 Ada Lovelace", "OK"),
        ("SET user:2 Alan Turing", "OK"),
        ("GET user:1", "VALUE Ada Lovelace"),
        ("GET nobody", "NIL"),
        ("DEL user:2", "OK 1"),
        ("DEL user:2", "OK 0"),
        ("SET counter 1", "OK"),
        ("KEYS user:", "KEYS 1 user:1"),
        ("FROB x", "ERR cannot parse \"FROB x\""),
        ("set lower case", "OK"),
    ];
    for (request, expected) in script {
        w.write_all(format!("{request}\n").as_bytes()).await.unwrap();
        assert_eq!(lines.next_line().await.unwrap().unwrap(), expected, "request {request:?}");
    }

    // Everything acknowledged is in the log: a second Store sees it (as recovery would).
    let (mut reopened, report) = Store::open(&dir, SyncPolicy::Always).unwrap();
    assert!(report.starts_with("recovered 3 keys"), "{report}");
    assert_eq!(reopened.get(b"user:1").map(|v| v.as_slice()), Some(&b"Ada Lovelace"[..]));
    assert_eq!(reopened.get(b"user:2"), None);
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn compaction_preserves_state_across_restarts() {
    let dir = std::env::temp_dir().join(format!("kvr-compact-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    {
        let (mut s, _) = Store::open(&dir, SyncPolicy::Never).unwrap();
        for i in 0..1000 {
            s.set(format!("k{}", i % 100).into_bytes(), format!("v{i}").into_bytes()).unwrap();
        }
        s.commit().unwrap();
        let (log, snap) = s.compact().unwrap();
        assert!(snap < log / 5, "snapshot {snap} should be much smaller than log {log}");
        s.set(b"after".to_vec(), b"compaction".to_vec()).unwrap();
        s.commit().unwrap();
    }
    let (mut s, report) = Store::open(&dir, SyncPolicy::Never).unwrap();
    assert_eq!(report, "recovered 101 keys: 100 from snapshot, 1 log records replayed, 0 bytes of torn/corrupt tail discarded");
    assert_eq!(s.get(b"k7").unwrap(), b"v907");
    let _ = std::fs::remove_dir_all(&dir);
}
