// file: units/units.rs
use std::fmt;
use std::marker::PhantomData;
use std::ops::{Add, Div, Mul, Sub};

/// A unit belongs to a dimension and has a factor to the dimension's base unit.
trait Unit {
    type Dim;
    const SYMBOL: &'static str;
    const TO_BASE: f64;
}

// Dimensions are zero-sized marker types.
struct LengthDim;
struct TimeDim;
struct SpeedDim;

struct Meter;
struct Kilometer;
struct Mile;
struct Second;
struct Hour;
struct MeterPerSecond;
struct KmPerHour;

macro_rules! unit {
    ($name:ident, $dim:ident, $sym:expr, $f:expr) => {
        impl Unit for $name {
            type Dim = $dim;
            const SYMBOL: &'static str = $sym;
            const TO_BASE: f64 = $f;
        }
    };
}
unit!(Meter, LengthDim, "m", 1.0);
unit!(Kilometer, LengthDim, "km", 1000.0);
unit!(Mile, LengthDim, "mi", 1609.344);
unit!(Second, TimeDim, "s", 1.0);
unit!(Hour, TimeDim, "h", 3600.0);
unit!(MeterPerSecond, SpeedDim, "m/s", 1.0);
unit!(KmPerHour, SpeedDim, "km/h", 1000.0 / 3600.0);

/// A value tagged with its unit. PhantomData<U> uses U in the type without storing anything.
struct Q<U: Unit> {
    value: f64,
    unit: PhantomData<U>,
}

// Derives would require U: Clone etc., so implement Clone/Copy by hand for any U.
impl<U: Unit> Clone for Q<U> {
    fn clone(&self) -> Self { *self }
}
impl<U: Unit> Copy for Q<U> {}

impl<U: Unit> Q<U> {
    fn new(value: f64) -> Self { Q { value, unit: PhantomData } }
    /// Converts to another unit of the same dimension; other dimensions do not compile.
    fn to<V: Unit<Dim = U::Dim>>(self) -> Q<V> {
        Q::new(self.value * U::TO_BASE / V::TO_BASE)
    }
}

impl<U: Unit> fmt::Display for Q<U> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let p = f.precision().unwrap_or(2);
        write!(f, "{:.*} {}", p, self.value, U::SYMBOL)
    }
}

impl<U: Unit> Add for Q<U> {                            // same unit only
    type Output = Q<U>;
    fn add(self, o: Q<U>) -> Q<U> { Q::new(self.value + o.value) }
}
impl<U: Unit> Sub for Q<U> {
    type Output = Q<U>;
    fn sub(self, o: Q<U>) -> Q<U> { Q::new(self.value - o.value) }
}
impl<U: Unit> Mul<f64> for Q<U> {                       // scaling by a plain number
    type Output = Q<U>;
    fn mul(self, k: f64) -> Q<U> { Q::new(self.value * k) }
}

/// length / time = speed, in base units, for any length and time units.
impl<L, T> Div<Q<T>> for Q<L>
where
    L: Unit<Dim = LengthDim>,
    T: Unit<Dim = TimeDim>,
{
    type Output = Q<MeterPerSecond>;
    fn div(self, t: Q<T>) -> Q<MeterPerSecond> {
        Q::new(self.value * L::TO_BASE / (t.value * T::TO_BASE))
    }
}

/// speed * time = length (in metres)
impl<S, T> Mul<Q<T>> for Q<S>
where
    S: Unit<Dim = SpeedDim>,
    T: Unit<Dim = TimeDim>,
{
    type Output = Q<Meter>;
    fn mul(self, t: Q<T>) -> Q<Meter> {
        Q::new(self.value * S::TO_BASE * t.value * T::TO_BASE)
    }
}

