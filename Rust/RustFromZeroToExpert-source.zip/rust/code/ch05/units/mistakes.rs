// file: units/mistakes.rs
include!("units_lib.rs");

fn main() {
    let d = Q::<Meter>::new(100.0);
    let t = Q::<Second>::new(9.58);
    let _a = d + t;                         // metres + seconds
    let _b = d + Q::<Kilometer>::new(1.0);  // different units: convert first
    let _c = t.to::<Mile>();                // a time is not a length
}
