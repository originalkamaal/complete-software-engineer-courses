// file: generics.rs
use std::fmt::Display;

fn largest<T: PartialOrd + Copy>(items: &[T]) -> Option<T> {
    let mut iter = items.iter().copied();
    let mut best = iter.next()?;
    for x in iter {
        if x > best {
            best = x;
        }
    }
    Some(best)
}

fn show_all<T>(label: &str, items: &[T]) -> String
where
    T: Display,
{
    let parts: Vec<String> = items.iter().map(|x| x.to_string()).collect();
    format!("{label}: {}", parts.join(", "))
}

fn print_twice(x: impl Display) {                    // same as fn print_twice<T: Display>(x: T)
    println!("{x} {x}");
}

fn evens(limit: u32) -> impl Iterator<Item = u32> {  // the concrete iterator type stays hidden
    (0..limit).filter(|n| n % 2 == 0)
}

#[derive(Debug)]
struct Pair<T> {
    a: T,
    b: T,
}

impl<T: PartialOrd + Display> Pair<T> {              // methods only when T supports them
    fn larger(&self) -> &T {
        if self.a >= self.b { &self.a } else { &self.b }
    }
}

fn main() {
    println!("{:?} {:?} {:?}", largest(&[3, 8, 1]), largest(&[0.5, -1.0]), largest::<char>(&[]));
    println!("{}", show_all("primes", &[2, 3, 5, 7]));
    print_twice("hi");
    println!("{:?}", evens(10).collect::<Vec<_>>());
    let p = Pair { a: "pear", b: "apple" };
    println!("{p:?} larger: {}", p.larger());
}
