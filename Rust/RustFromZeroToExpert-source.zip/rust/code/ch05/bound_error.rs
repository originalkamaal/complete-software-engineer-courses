// file: bound_error.rs
fn largest<T: PartialOrd + Copy>(items: &[T]) -> T {
    let mut best = items[0];
    for &x in items {
        if x > best {
            best = x;
        }
    }
    best
}

fn main() {
    let names = vec![String::from("b"), String::from("a")];
    println!("{}", largest(&names));
}
