// file: traits.rs
trait Describe {
    fn name(&self) -> String;                         // required
    fn describe(&self) -> String {                    // default, may be overridden
        format!("<{}>", self.name())
    }
}

struct Dog { name: String }
struct Robot { serial: u32 }

impl Describe for Dog {
    fn name(&self) -> String { self.name.clone() }
    fn describe(&self) -> String { format!("{} the dog", self.name) }
}

impl Describe for Robot {
    fn name(&self) -> String { format!("unit-{}", self.serial) }    // uses the default describe
}

impl Describe for i32 {                               // our trait on a foreign type: allowed
    fn name(&self) -> String { format!("the number {self}") }
}

fn main() {
    let d = Dog { name: "Rex".into() };
    let r = Robot { serial: 7 };
    println!("{} | {} | {}", d.describe(), r.describe(), 42.describe());
}
