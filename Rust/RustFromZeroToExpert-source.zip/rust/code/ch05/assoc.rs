// file: assoc.rs
use std::fmt::Display;

trait Container {
    type Item;                                         // chosen by each implementation
    const KIND: &'static str;
    fn items(&self) -> Vec<&Self::Item>;
    fn first(&self) -> Option<&Self::Item> {
        self.items().into_iter().next()
    }
}

struct Shelf { books: Vec<String> }

impl Container for Shelf {
    type Item = String;
    const KIND: &'static str = "shelf";
    fn items(&self) -> Vec<&String> { self.books.iter().collect() }
}

trait Labelled: Display {                              // supertrait: every Labelled is Display
    fn label(&self) -> String { format!("[{self}]") }
}
impl<T: Display> Labelled for T {}                     // blanket impl: every Display type is Labelled

fn summary<C>(c: &C) -> String
where
    C: Container,
    C::Item: Display,
{
    format!("{} with {} items, first = {}", C::KIND, c.items().len(), c.first().map(|x| x.to_string()).unwrap_or_default())
}

fn main() {
    let s = Shelf { books: vec!["Dune".into(), "Emma".into()] };
    println!("{}", summary(&s));
    println!("{} {} {}", 42.label(), "text".label(), 2.5.label());
}
