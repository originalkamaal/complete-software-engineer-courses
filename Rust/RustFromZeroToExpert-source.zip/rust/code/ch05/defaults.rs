// file: defaults.rs
trait Shape {
    fn area(&self) -> f64;                                   // required
    fn name(&self) -> String { "shape".into() }              // default
    fn describe(&self) -> String {                           // default, built on the others
        format!("{} with area {:.2}", self.name(), self.area())
    }
}

struct Circle(f64);
struct Square(f64);

impl Shape for Circle {
    fn area(&self) -> f64 { std::f64::consts::PI * self.0 * self.0 }
    fn name(&self) -> String { "circle".into() }             // overrides the default
}
impl Shape for Square {
    fn area(&self) -> f64 { self.0 * self.0 }                // keeps the default name
}

fn main() {
    println!("{}", Circle(1.0).describe());
    println!("{}", Square(2.0).describe());
}
