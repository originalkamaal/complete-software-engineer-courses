// file: impltrait.rs
use std::fmt::Display;

fn show_all(items: &[impl Display]) -> String {
    items.iter().map(|i| i.to_string()).collect::<Vec<_>>().join(", ")
}

fn evens(limit: u32) -> impl Iterator<Item = u32> { (0..limit).filter(|n| n % 2 == 0) }

fn make_adder(k: i32) -> impl Fn(i32) -> i32 { move |x| x + k }

fn numbers(desc: bool) -> Box<dyn Iterator<Item = u32>> {
    if desc { Box::new((1..=3).rev()) } else { Box::new(1..=3) }   // two different types: needs Box<dyn>
}

fn main() {
    println!("{}", show_all(&[1.5, 2.0]));
    println!("{:?}", evens(10).collect::<Vec<_>>());
    println!("{}", make_adder(10)(5));
    println!("{:?} {:?}", numbers(true).collect::<Vec<_>>(), numbers(false).collect::<Vec<_>>());
}
