// file: convtraits.rs
use std::fmt;
use std::path::Path;

struct Rgb(u8, u8, u8);

impl From<u32> for Rgb {
    fn from(hex: u32) -> Self { Rgb((hex >> 16) as u8, (hex >> 8) as u8, hex as u8) }
}
impl fmt::Display for Rgb {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result { write!(f, "#{:02x}{:02x}{:02x}", self.0, self.1, self.2) }
}

fn shout(s: impl AsRef<str>) -> String { s.as_ref().to_uppercase() }
fn extension(p: impl AsRef<Path>) -> Option<String> {
    p.as_ref().extension().map(|e| e.to_string_lossy().into_owned())
}

fn main() {
    let c: Rgb = 0x1e90ff.into();                                // Into comes from From
    println!("{c} {}", Rgb::from(0xff8800).to_string());
    println!("{} {}", shout("hi"), shout(String::from("there")));
    println!("{:?} {:?}", extension("notes.txt"), extension(std::path::PathBuf::from("/tmp/a.tar.gz")));
}
