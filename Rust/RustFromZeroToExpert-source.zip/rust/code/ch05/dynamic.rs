// file: dynamic.rs
trait Shape {
    fn area(&self) -> f64;
    fn name(&self) -> &'static str;
}

struct Circle(f64);
struct Square(f64);

impl Shape for Circle {
    fn area(&self) -> f64 { std::f64::consts::PI * self.0 * self.0 }
    fn name(&self) -> &'static str { "circle" }
}
impl Shape for Square {
    fn area(&self) -> f64 { self.0 * self.0 }
    fn name(&self) -> &'static str { "square" }
}

fn total_static<S: Shape>(shapes: &[S]) -> f64 {          // one type per call, inlined
    shapes.iter().map(|s| s.area()).sum()
}

fn total_dynamic(shapes: &[Box<dyn Shape>]) -> f64 {      // any mix of types, via the vtable
    shapes.iter().map(|s| s.area()).sum()
}

fn main() {
    let mixed: Vec<Box<dyn Shape>> = vec![Box::new(Circle(1.0)), Box::new(Square(2.0)), Box::new(Circle(0.5))];
    for s in &mixed {
        println!("{:<7} {:.3}", s.name(), s.area());
    }
    println!("dynamic total {:.3}, static total of squares {:.1}", total_dynamic(&mixed), total_static(&[Square(1.0), Square(3.0)]));
    println!("size_of: &Circle {}, &dyn Shape {}, Box<dyn Shape> {}", size_of::<&Circle>(), size_of::<&dyn Shape>(), size_of::<Box<dyn Shape>>());

    // the cost: 10 million area() calls each way
    let n = 10_000_000;
    let squares: Vec<Square> = (0..n).map(|i| Square((i % 7) as f64)).collect();
    let boxed: Vec<Box<dyn Shape>> = (0..n).map(|i| Box::new(Square((i % 7) as f64)) as Box<dyn Shape>).collect();
    let t = std::time::Instant::now();
    let s1 = total_static(&squares);
    let t_static = t.elapsed();
    let t = std::time::Instant::now();
    let s2 = total_dynamic(&boxed);
    let t_dyn = t.elapsed();
    println!("static {t_static:.1?} vs dynamic {t_dyn:.1?} (sums equal: {})", s1 == s2);
}
