// file: extension.rs
trait StrExt {
    fn word_count(&self) -> usize;
    fn title_case(&self) -> String;
}

impl StrExt for str {
    fn word_count(&self) -> usize { self.split_whitespace().count() }
    fn title_case(&self) -> String {
        self.split_whitespace()
            .map(|w| {
                let mut c = w.chars();
                c.next().map(|f| f.to_uppercase().chain(c.flat_map(|x| x.to_lowercase())).collect::<String>()).unwrap_or_default()
            })
            .collect::<Vec<_>>()
            .join(" ")
    }
}

trait IterSumSq: Iterator<Item = f64> + Sized {
    fn sum_of_squares(self) -> f64 { self.map(|x| x * x).sum() }
}
impl<I: Iterator<Item = f64>> IterSumSq for I {}                 // blanket impl: every f64 iterator

fn main() {
    let s = "the QUICK brown fox";
    println!("{} words, {:?}", s.word_count(), s.title_case());
    println!("{}", [1.0, 2.0, 3.0].into_iter().sum_of_squares());
}
