// file: stdtraits.rs
use std::fmt;
use std::ops::{Add, Mul, Neg};

#[derive(Debug, Clone, Copy, PartialEq, Default)]
struct V2 {
    x: f64,
    y: f64,
}

impl fmt::Display for V2 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match f.precision() {                                 // honour {:.N} from the caller
            Some(p) => write!(f, "({:.*}, {:.*})", p, self.x, p, self.y),
            None => write!(f, "({}, {})", self.x, self.y),
        }
    }
}

impl Add for V2 {
    type Output = V2;
    fn add(self, o: V2) -> V2 { V2 { x: self.x + o.x, y: self.y + o.y } }
}

impl Mul<f64> for V2 {                                        // V2 * f64
    type Output = V2;
    fn mul(self, k: f64) -> V2 { V2 { x: self.x * k, y: self.y * k } }
}

impl Mul<V2> for f64 {                                        // f64 * V2: our trait impl on a foreign type
    type Output = V2;
    fn mul(self, v: V2) -> V2 { v * self }
}

impl Neg for V2 {
    type Output = V2;
    fn neg(self) -> V2 { V2 { x: -self.x, y: -self.y } }
}

impl From<(f64, f64)> for V2 {
    fn from((x, y): (f64, f64)) -> V2 { V2 { x, y } }
}

fn main() {
    let a = V2 { x: 1.0, y: 2.0 };
    let b: V2 = (0.5, -1.0).into();                          // Into comes free with From
    let c = a + b * 2.0 + 0.5 * -a;
    println!("{a} + {b}*2 + 0.5*-a = {c:.2}; default {}; c as text has {} chars", V2::default(), c.to_string().len());
}
