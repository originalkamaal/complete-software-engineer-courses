// file: fatptr.rs
use std::mem::size_of;

trait Speak { fn speak(&self) -> String; }
struct Dog;
impl Speak for Dog { fn speak(&self) -> String { "woof".into() } }

fn main() {
    println!("&Dog: {} bytes, &dyn Speak: {} bytes, Box<dyn Speak>: {} bytes",
             size_of::<&Dog>(), size_of::<&dyn Speak>(), size_of::<Box<dyn Speak>>());
    println!("&[u8]: {} bytes, &str: {} bytes (pointer + length)", size_of::<&[u8]>(), size_of::<&str>());
    let d: &dyn Speak = &Dog;
    let (data, vtable): (*const (), *const ()) = unsafe { std::mem::transmute(d) };
    println!("data pointer and vtable pointer differ: {}", data != vtable);
    println!("{}", d.speak());
}
