// file: vars.rs
const MAX_USERS: u32 = 100_000;          // type required; underscores are digit separators
static GREETING: &str = "hello";         // a single location in the binary

fn main() {
    let x = 5;
    // x = 6;                            // error[E0384]: cannot assign twice to immutable variable
    let mut count = 0;
    count += x;
    let spaces = "   ";                  // a &str ...
    let spaces = spaces.len();           // ... shadowed by a usize: a new variable, same name
    let x = x * 2;                       // shadowing again: x is still immutable
    println!("{GREETING}: count={count}, spaces={spaces}, x={x}, max={MAX_USERS}");

    let shadowed = 1;
    {
        let shadowed = "inner";          // shadows only inside this block
        println!("inner: {shadowed}");
    }
    println!("outer: {shadowed}");
}
