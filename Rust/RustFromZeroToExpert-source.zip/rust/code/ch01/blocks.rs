// file: blocks.rs
fn classify(n: i32) -> &'static str {
    if n < 0 { "negative" } else if n == 0 { "zero" } else { "positive" }   // the if is the return value
}

fn main() {
    let area = {
        let w = 3;
        let h = 4;
        w * h                                     // no semicolon: the block's value
    };
    let first_square_over_50 = {
        let mut i = 1;
        loop {
            if i * i > 50 { break i; }            // loop returns a value through break
            i += 1;
        }
    };
    let parity = match area % 2 { 0 => "even", _ => "odd" };
    let unit = { area; };                         // a trailing semicolon makes the value ()
    println!("{area} {first_square_over_50} {parity} {} {unit:?}", classify(-5));
}
