// file: input.rs
use std::io;

fn main() {
    let mut total: i64 = 0;
    for (i, line) in io::stdin().lines().enumerate() {
        let line = line.expect("stdin should be readable");   // an I/O error would panic with this message
        match line.trim().parse::<i64>() {
            Ok(n) => total += n,
            Err(e) => eprintln!("line {}: {:?} is not a number ({e})", i + 1, line),
        }
    }
    println!("total = {total}");
}
