// file: loops.rs
fn main() {
    let grid = [[1, 2, 3], [4, 99, 6], [7, 8, 9]];
    let mut found = None;
    'rows: for (r, row) in grid.iter().enumerate() {
        for (c, &v) in row.iter().enumerate() {
            if v == 99 {
                found = Some((r, c));
                break 'rows;                       // leaves both loops
            }
        }
    }
    println!("found 99 at {found:?}");

    let evens: Vec<u32> = (0..=10).step_by(2).collect();
    let countdown: Vec<u32> = (1..4).rev().collect();
    println!("{evens:?} {countdown:?}");

    let mut n = 27u64;
    let mut steps = 0;
    while n != 1 {                                 // the Collatz sequence
        n = if n % 2 == 0 { n / 2 } else { 3 * n + 1 };
        steps += 1;
    }
    println!("27 reaches 1 in {steps} steps");
}
