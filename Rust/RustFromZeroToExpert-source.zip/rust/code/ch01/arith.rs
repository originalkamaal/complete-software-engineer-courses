// file: arith.rs
fn main() {
    let a: u8 = 250;
    println!("checked_add(10):     {:?}", a.checked_add(10));      // None on overflow
    println!("checked_add(5):      {:?}", a.checked_add(5));
    println!("wrapping_add(10):    {}", a.wrapping_add(10));        // modulo 256
    println!("saturating_add(10):  {}", a.saturating_add(10));      // clamps at 255
    println!("overflowing_add(10): {:?}", a.overflowing_add(10));   // (result, did it overflow)

    let b: i32 = i32::MIN;
    println!("i32::MIN.checked_abs(): {:?}", b.checked_abs());     // |MIN| does not fit
    println!("-7 / 2 = {}, -7 % 2 = {}", -7 / 2, -7 % 2);          // truncates toward zero
    println!("(-7i32).div_euclid(2) = {}, rem_euclid = {}", (-7i32).div_euclid(2), (-7i32).rem_euclid(2));

    let big: u64 = 300;
    println!("300 as u8 = {}, u8::try_from(300) = {:?}", big as u8, u8::try_from(big));
}
