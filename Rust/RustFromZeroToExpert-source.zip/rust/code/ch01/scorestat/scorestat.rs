// file: scorestat/scorestat.rs
use std::io;

fn parse_line(line: &str) -> Result<f64, String> {
    let field = line.split_whitespace().last().ok_or("empty line")?;   // the score is the last field
    let value: f64 = field.parse().map_err(|_| format!("{field:?} is not a number"))?;
    if !(0.0..=100.0).contains(&value) {
        return Err(format!("{value} is outside 0..=100"));
    }
    Ok(value)
}

fn median(sorted: &[f64]) -> f64 {
    let n = sorted.len();
    if n % 2 == 1 { sorted[n / 2] } else { (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0 }
}

fn main() {
    let mut scores: Vec<f64> = Vec::new();
    let mut bad = 0;
    for (number, line) in io::stdin().lines().enumerate() {
        let line = line.expect("stdin should be readable");
        if line.trim().is_empty() {
            continue;
        }
        match parse_line(&line) {
            Ok(v) => scores.push(v),
            Err(why) => {
                bad += 1;
                eprintln!("skipping line {}: {why}", number + 1);
            }
        }
    }
    if scores.is_empty() {
        println!("no valid scores ({bad} bad lines)");
        return;
    }
    scores.sort_by(f64::total_cmp);                       // DT-6: f64 has no total order
    let n = scores.len() as f64;
    let mean = scores.iter().sum::<f64>() / n;
    let variance = scores.iter().map(|s| (s - mean) * (s - mean)).sum::<f64>() / n;
    println!("count  {:>7}   (skipped {bad})", scores.len());
    println!("mean   {mean:>7.2}");
    println!("median {:>7.2}", median(&scores));
    println!("min    {:>7.2}   max {:.2}", scores[0], scores[scores.len() - 1]);
    println!("stddev {:>7.2}", variance.sqrt());

    let mut buckets = [0usize; 10];                       // 0-9, 10-19, ..., 90-100
    for &s in &scores {
        let b = ((s / 10.0) as usize).min(9);             // 100 goes in the last bucket
        buckets[b] += 1;
    }
    let widest = *buckets.iter().max().unwrap_or(&1);
    for (i, &count) in buckets.iter().enumerate() {
        let bar = "#".repeat((count * 40).div_ceil(widest.max(1)));
        let range = if i == 9 { "90-100".to_string() } else { format!("{}-{}", i * 10, i * 10 + 9) };
        println!("{range:>6} | {bar} {count}");
    }
}
