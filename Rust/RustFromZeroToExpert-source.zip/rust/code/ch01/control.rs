// file: control.rs
fn main() {
    // loop with a value: find the first power of 3 above 1000
    let mut p = 1u32;
    let first = loop {
        p *= 3;
        if p > 1000 {
            break p;
        }
    };
    // while
    let mut n = 27u64;
    let mut steps = 0;
    while n != 1 {
        n = if n % 2 == 0 { n / 2 } else { 3 * n + 1 };
        steps += 1;
    }
    // for over ranges, reversed, stepped
    let evens: Vec<i32> = (0..=10).step_by(2).collect();
    let countdown: Vec<i32> = (1..=5).rev().collect();
    // labelled break out of nested loops
    let mut found = None;
    'search: for a in 1..20 {
        for b in a..20 {
            if a * a + b * b == 13 * 13 {
                found = Some((a, b));
                break 'search;
            }
        }
    }
    println!("first power of 3 above 1000: {first}; Collatz(27) takes {steps} steps");
    println!("evens {evens:?}, countdown {countdown:?}, 5-12-13 search: {found:?}");
}
