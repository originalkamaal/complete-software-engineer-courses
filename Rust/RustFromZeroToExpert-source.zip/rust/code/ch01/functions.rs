// file: functions.rs
fn area(width: f64, height: f64) -> f64 {
    width * height                       // no semicolon: this is the return value
}

fn classify(n: i32) -> &'static str {
    if n < 0 {
        return "negative";               // early return uses `return`
    }
    if n % 2 == 0 { "even" } else { "odd" }   // if is an expression
}

fn gcd(a: u64, b: u64) -> u64 {
    if b == 0 { a } else { gcd(b, a % b) }
}

fn main() {
    let a = area(3.0, 4.5);
    let label = {
        let doubled = a * 2.0;
        if doubled > 20.0 { "big" } else { "small" }   // the block's value
    };
    println!("area {a}, {label}; 7 is {}, -2 is {}; gcd(84, 36) = {}", classify(7), classify(-2), gcd(84, 36));
}
