// file: strings.rs
fn main() {
    let literal: &str = "naïve café";                  // borrowed from the binary
    let mut owned = String::from("crab");               // owned, on the heap
    owned.push_str(" 🦀");
    owned.push('!');
    let joined = format!("{literal} + {owned}");       // format! builds a new String

    println!("{joined}");
    println!("bytes: {}, chars: {}", literal.len(), literal.chars().count());
    println!("uppercase: {}, contains 'café': {}", literal.to_uppercase(), literal.contains("café"));
    println!("first 5 bytes: {:?}", &literal[0..5]);    // 'n','a','ï' (2 bytes),'v' — on boundaries
    for (i, ch) in "aï🦀".char_indices() {
        println!("  byte {i}: {ch:?} ({} bytes)", ch.len_utf8());
    }
    let words: Vec<&str> = "  split   these words ".split_whitespace().collect();
    println!("{words:?}");
    let maybe: Option<char> = literal.chars().nth(2);  // the third character, by walking
    println!("third char: {maybe:?}");
    println!("{}", &literal[0..3]);                      // byte 3 is inside 'ï': panic
}
