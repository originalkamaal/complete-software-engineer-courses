// file: bigarray.rs
fn sum(a: [u64; 4]) -> u64 { a.iter().sum() }      // receives a copy

#[inline(never)]
fn big_local(i: usize) -> u8 {
    let on_stack = [0u8; 16 * 1024 * 1024];        // 16 MiB on the stack
    std::hint::black_box(&on_stack)[i]
}

fn main() {
    let mut a = [1u64, 2, 3, 4];
    let total = sum(a);
    a[0] = 100;                                    // the caller's array is unaffected by the call
    println!("sum {total}, a[0] now {}", a[0]);

    let on_heap = vec![0u8; 16 * 1024 * 1024];     // 16 MiB on the heap: fine
    println!("heap buffer of {} bytes", on_heap.len());
    if std::env::args().count() > 1 {
        println!("{}", big_local(std::env::args().count()));
    }
}
