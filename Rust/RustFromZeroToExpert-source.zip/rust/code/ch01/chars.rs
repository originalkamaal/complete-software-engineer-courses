// file: chars.rs
fn main() {
    let s = "naïve café 🇮🇳";
    println!("bytes: {}, chars: {}", s.len(), s.chars().count());
    for (i, c) in s.char_indices().filter(|(_, c)| !c.is_ascii()) {
        println!("  byte {i:2}: {c:?} is {} bytes (U+{:04X})", c.len_utf8(), c as u32);
    }
    let first_word_end = s.find(' ').unwrap();           // byte index of the first space
    println!("first word: {}", &s[..first_word_end]);
    println!("safe to cut at byte 3? {}", s.is_char_boundary(3));
    println!("uppercase: {}", s.to_uppercase());
    let reversed: String = s.chars().rev().collect();
    println!("chars reversed: {reversed}");
}
