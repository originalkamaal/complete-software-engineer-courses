// file: shadow.rs
const MAX_USERS: u32 = 10 * 1000;           // evaluated at compile time, inlined where used
static GREETING: &str = "hello";            // one location, lives for the whole program

fn main() {
    let input = "  42  ";                   // &str
    let input = input.trim();               // still &str, a narrower slice
    let input: u32 = input.parse().unwrap(); // now a u32: a different type, same name
    println!("input + 1 = {}", input + 1);

    let x = 5;
    {
        let x = x * 2;                      // shadows only inside this block
        println!("inner x = {x}");
    }
    println!("outer x = {x}");

    let mut count = 0;
    count += 1;                             // mut: same variable, same type, new value
    // count = "one";                       // error: expected integer, found &str
    println!("count = {count}, MAX_USERS = {MAX_USERS}, {GREETING}");
}
