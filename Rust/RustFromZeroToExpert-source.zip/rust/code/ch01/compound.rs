// file: compound.rs
fn sum(values: &[i64]) -> i64 {          // accepts arrays, vectors, and sub-slices
    let mut total = 0;
    for v in values {
        total += v;
    }
    total
}

fn main() {
    let pair: (i32, &str) = (7, "seven");
    let (n, name) = pair;                                  // destructuring
    println!("{} {} / {n} {name}", pair.0, pair.1);

    let days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];   // [i64; 12] (from sum's parameter type)
    let zeros = [0u8; 5];                                  // five zeros
    println!("year: {}, first quarter: {}, zeros: {zeros:?}", sum(&days), sum(&days[0..3]));
    let v = vec![10, 20, 30];
    println!("vector: {}, len {}", sum(&v), v.len());

    let index = days.len() + std::env::args().count();   // not known at compile time
    match days.get(index) {                                // checked access returns Option
        Some(d) => println!("day count {d}"),
        None => println!("no month at index {index}"),
    }
    println!("{}", days[index]);                           // panics: index out of bounds
}
