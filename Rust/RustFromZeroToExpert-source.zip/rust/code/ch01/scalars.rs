// file: scalars.rs
fn main() {
    let a: i32 = -17;
    let b = 3;                                     // inferred i32 from use below
    println!("{} {} {} {}", a / b, a % b, a.div_euclid(b), a.rem_euclid(b));   // truncating vs Euclidean
    println!("sizes: i8={} i64={} i128={} usize={} char={} bool={}",
             size_of::<i8>(), size_of::<i64>(), size_of::<i128>(), size_of::<usize>(), size_of::<char>(), size_of::<bool>());

    // `as` between integers: truncates or sign-extends, never fails
    println!("300 as u8 = {}, -1i32 as u32 = {}, 200u8 as i8 = {}", 300i32 as u8, -1i32 as u32, 200u8 as i8);
    // `as` from float to integer: rounds toward zero and SATURATES; NaN becomes 0
    println!("2.9 as i32 = {}, -1.5 as u8 = {}, 1e10 as i32 = {}, NaN as i32 = {}", 2.9f64 as i32, -1.5f64 as u8, 1e10f64 as i32, f64::NAN as i32);

    // lossless conversions with From; checked ones with TryFrom
    let small: u8 = 200;
    let wide = u32::from(small);
    let back = u8::try_from(wide + 100);
    println!("u32::from(200u8) = {wide}, u8::try_from(300) = {back:?}");

    let c = 'é';
    let crab = '🦀';
    println!("'{c}' is U+{:04X}, '{crab}' is U+{:X}, as u32 = {}", c as u32, crab as u32, crab as u32);
    println!("0.1 + 0.2 = {}, == 0.3? {}", 0.1 + 0.2, 0.1 + 0.2 == 0.3);
}
