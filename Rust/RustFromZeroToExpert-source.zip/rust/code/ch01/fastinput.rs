// file: fastinput.rs
use std::io::{self, BufRead, Read};

fn main() -> io::Result<()> {
    let mode = std::env::args().nth(1).unwrap_or_default();
    let mut sum: i64 = 0;
    if mode == "all" {
        let mut text = String::new();
        io::stdin().lock().read_to_string(&mut text)?;          // one read of everything
        for tok in text.split_ascii_whitespace() { sum += tok.parse::<i64>().unwrap(); }
    } else {
        for line in io::stdin().lock().lines() {                // one lock, line by line
            for tok in line?.split_ascii_whitespace() { sum += tok.parse::<i64>().unwrap(); }
        }
    }
    println!("sum = {sum}");
    Ok(())
}
