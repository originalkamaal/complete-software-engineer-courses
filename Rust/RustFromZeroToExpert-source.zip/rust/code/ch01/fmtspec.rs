// file: fmtspec.rs
fn main() {
    let items = [("apples", 3, 0.5), ("kiwis", 12, 0.25), ("watermelon", 1, 3.0)];
    println!("{:<12}|{:>5}|{:>8}", "item", "qty", "cost");
    for (name, qty, price) in items {
        println!("{name:<12}|{qty:>5}|{:>8.2}", qty as f64 * price);
    }
    let width = 10;
    println!("[{:^width$}] [{:>1$}] [{:.*}]", "mid", 6, 3, std::f64::consts::PI);
    println!("{:#x} {:#b} {:#o} {:08.3} {:e}", 255, 5, 8, -3.14159, 1234.5);
    println!("{{literal braces}} and {0} {0} {1}", "repeat", "once");
}
