// file: format.rs
fn main() {
    let pi = std::f64::consts::PI;
    let name = "Ada";
    let items = vec![("tea", 3.5), ("cake", 4.25)];
    println!("[{name:>8}] [{name:<8}] [{name:^8}] [{name:*^9}]");
    println!("{pi:.3} {pi:10.2} {pi:<10.4}| {:e}", 1234.5);
    println!("{0} {1} {0} / {x}", "a", "b", x = 42);
    println!("hex {:x} {:#x} {:08b} octal {:o}", 255, 255, 5u8, 8);
    println!("{:+} {:+}", 5, -5);
    println!("debug: {items:?}");
    println!("pretty: {items:#?}");
    let width = 12;
    println!("[{:>width$.2}]", pi);
    let total = dbg!(items.iter().map(|(_, price)| price).sum::<f64>()) * 2.0;
    eprintln!("this line goes to stderr; total x2 = {total}");
}
