// file: newtype.rs
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
struct Meters(f64);
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
struct Feet(f64);

impl From<Feet> for Meters { fn from(f: Feet) -> Meters { Meters(f.0 * 0.3048) } }

fn clearance_ok(height: Meters) -> bool { height >= Meters(2.5) }

#[allow(dead_code)]
struct UserId(u64);
struct OrderId(u64);
fn cancel(_user: UserId, order: OrderId) -> u64 { order.0 }

fn main() {
    let door = Feet(9.0);
    // clearance_ok(door);                         // error: expected Meters, found Feet
    println!("9 ft = {:?}, ok: {}", Meters::from(door), clearance_ok(door.into()));
    println!("cancelled order {}", cancel(UserId(7), OrderId(42)));
    // cancel(OrderId(42), UserId(7));             // error: arguments swapped
    println!("size of Meters = {}", std::mem::size_of::<Meters>());
}
