// file: patterns2.rs
fn describe(xs: &[i32]) -> String {
    match xs {
        [] => "empty".into(),
        [one] => format!("just {one}"),
        [first, .., last] if first == last => format!("starts and ends with {first}"),
        [first, rest @ ..] => format!("{first} then {} more", rest.len()),
    }
}

fn grade(score: u32) -> &'static str {
    match score {
        90..=100 => "A",
        75..90 => "B",
        n @ 50..75 if n % 2 == 0 => "C (even)",
        50..75 => "C",
        0..50 => "F",
        _ => "invalid",
    }
}

fn main() {
    for xs in [&[][..], &[7], &[3, 1, 3], &[1, 2, 3, 4]] { println!("{}", describe(xs)); }
    for s in [95, 80, 62, 63, 10, 150] { print!("{} ", grade(s)); }
    println!();
    let msg = Some(42);
    if let Some(n @ 40..=50) = msg { println!("in range: {n}"); }
}
