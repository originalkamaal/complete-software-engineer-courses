// file: enums.rs
#[derive(Debug)]
enum Shape {
    Circle { r: f64 },
    Rect { w: f64, h: f64 },
    Triangle(f64, f64, f64),                    // three sides
    Empty,
}

impl Shape {
    fn area(&self) -> f64 {
        match self {
            Shape::Circle { r } => std::f64::consts::PI * r * r,
            Shape::Rect { w, h } => w * h,
            Shape::Triangle(a, b, c) => {
                let s = (a + b + c) / 2.0;      // Heron's formula
                (s * (s - a) * (s - b) * (s - c)).sqrt()
            }
            Shape::Empty => 0.0,
        }
    }
}

fn find_big(shapes: &[Shape], min_area: f64) -> Option<&Shape> {
    for s in shapes {
        if s.area() >= min_area {
            return Some(s);
        }
    }
    None
}

fn main() {
    let shapes = vec![Shape::Empty, Shape::Triangle(3.0, 4.0, 5.0), Shape::Circle { r: 2.0 }, Shape::Rect { w: 2.0, h: 8.0 }];
    for s in &shapes {
        println!("{:<40} area {:>6.2}", format!("{s:?}"), s.area());
    }
    println!("first with area >= 10: {:?}", find_big(&shapes, 10.0));
    println!("first with area >= 100: {:?}", find_big(&shapes, 100.0));
    println!("sizes: Shape {}, Option<&Shape> {}, &Shape {}, Option<u32> {}, Option<Box<u8>> {}",
             size_of::<Shape>(), size_of::<Option<&Shape>>(), size_of::<&Shape>(), size_of::<Option<u32>>(), size_of::<Option<Box<u8>>>());
}
