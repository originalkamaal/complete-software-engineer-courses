// file: tempscope.rs
use std::sync::Mutex;

fn main() {
    let m = Mutex::new(vec![1, 2, 3]);
    match m.lock().unwrap().first() {
        Some(x) => println!("match arm sees {x}; lock still held: {}", m.try_lock().is_err()),
        None => {}
    }
    if let Some(x) = m.lock().unwrap().first() {
        println!("if let body sees {x}; lock still held: {}", m.try_lock().is_err());
    } else {
        unreachable!();
    }
    let first = m.lock().unwrap().first().copied();      // guard dropped at the end of this statement
    println!("copied {first:?}; lock free afterwards: {}", m.try_lock().is_ok());
}
