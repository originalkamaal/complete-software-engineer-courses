// file: conn/conn.rs
#[derive(Debug, Clone, PartialEq)]
enum State {
    Closed,
    Listening { port: u16 },
    SynReceived { port: u16, peer_seq: u32 },
    Established { port: u16, sent: u64, received: u64 },
    Closing { reason: String },
}

#[derive(Debug, Clone)]
enum Event {
    Listen(u16),
    Syn { seq: u32 },
    Ack { ack: u32 },
    Data(Vec<u8>),
    Send(usize),
    Close,
    Reset(String),
}

#[derive(Debug)]
struct Rejected {
    state: State,
    event: Event,
}

impl State {
    /// Consumes the current state and the event; returns the next state or a rejection.
    fn on(self, event: Event) -> Result<State, Rejected> {
        use Event as E;
        use State as S;
        match (self, event) {
            (S::Closed, E::Listen(port)) if port != 0 => Ok(S::Listening { port }),
            (S::Listening { port }, E::Syn { seq }) => Ok(S::SynReceived { port, peer_seq: seq }),
            (S::SynReceived { port, peer_seq }, E::Ack { ack }) if ack == peer_seq.wrapping_add(1) => {
                Ok(S::Established { port, sent: 0, received: 0 })
            }
            (S::Established { port, sent, received }, E::Data(bytes)) => {
                Ok(S::Established { port, sent, received: received + bytes.len() as u64 })
            }
            (S::Established { port, sent, received }, E::Send(n)) => {
                Ok(S::Established { port, sent: sent + n as u64, received })
            }
            (S::Established { sent, received, .. }, E::Close) => {
                Ok(S::Closing { reason: format!("normal close after {sent} bytes out, {received} in") })
            }
            (S::Closing { .. }, E::Close) => Ok(S::Closed),
            (state, E::Reset(why)) if state != S::Closed => Ok(S::Closing { reason: format!("reset: {why}") }),
            (state, event) => Err(Rejected { state, event }),
        }
    }
}

fn main() {
    let script = vec![
        Event::Syn { seq: 1 },                       // not listening yet: rejected
        Event::Listen(0),                            // port 0 is invalid: rejected by the guard
        Event::Listen(8080),
        Event::Syn { seq: 41 },
        Event::Ack { ack: 7 },                       // wrong ack number: rejected
        Event::Ack { ack: 42 },
        Event::Data(b"GET /".to_vec()),
        Event::Send(512),
        Event::Data(vec![0; 7]),
        Event::Close,
        Event::Close,
        Event::Listen(9090),
        Event::Syn { seq: u32::MAX },
        Event::Ack { ack: 0 },                       // u32::MAX + 1 wraps to 0
        Event::Reset("peer vanished".to_string()),
        Event::Close,
        Event::Reset("too late".to_string()),        // reset while closed: rejected
    ];
    let mut state = State::Closed;
    for event in script {
        let shown = format!("{event:?}");
        match state.on(event) {
            Ok(next) => {
                println!("{shown:<40} => {next:?}");
                state = next;
            }
            Err(Rejected { state: unchanged, event }) => {
                println!("{:<40} !! rejected in {unchanged:?}", format!("{event:?}"));   // the event comes back too
                state = unchanged;
            }
        }
    }
}
