// file: patterns.rs
#[derive(Debug)]
enum Event {
    Key { code: u32, shift: bool },
    Click { x: i32, y: i32 },
    Scroll(i32),
    Quit,
}

fn describe(e: &Event) -> String {
    match e {
        Event::Key { code: 27, .. } => "escape".to_string(),
        Event::Key { code: c @ 65..=90, shift: true } => format!("capital {}", char::from_u32(*c).unwrap()),
        Event::Key { code, .. } => format!("key {code}"),
        Event::Click { x: 0, y: 0 } => "click at origin".to_string(),
        Event::Click { x, y } if x == y => format!("click on the diagonal at {x}"),
        Event::Click { x, y } => format!("click at ({x}, {y})"),
        Event::Scroll(d) if *d < 0 => format!("scroll up {}", -d),
        Event::Scroll(d) => format!("scroll down {d}"),
        Event::Quit => "quit".to_string(),
    }
}

fn classify(values: &[i32]) -> &'static str {
    match values {
        [] => "empty",
        [_] => "one element",
        [first, .., last] if first == last => "same at both ends",
        [0, ..] => "starts with zero",
        [.., 0] => "ends with zero",
        _ => "something else",
    }
}

fn main() {
    let events = [Event::Key { code: 27, shift: false }, Event::Key { code: 72, shift: true }, Event::Key { code: 72, shift: false },
                  Event::Click { x: 0, y: 0 }, Event::Click { x: 5, y: 5 }, Event::Click { x: 1, y: 2 },
                  Event::Scroll(-3), Event::Scroll(2), Event::Quit];
    for e in &events {
        println!("{:<36} -> {}", format!("{e:?}"), describe(e));
    }
    for v in [&[][..], &[4], &[7, 1, 7], &[0, 3], &[3, 0], &[1, 2]] {
        println!("{v:?}: {}", classify(v));
    }
    let n = 42;
    let size = match n {
        0 => "zero",
        1..=9 => "small",
        10 | 20 | 30 => "round",
        _ if n % 2 == 0 => "even and big",
        _ => "odd and big",
    };
    println!("{n} is {size}");
}
