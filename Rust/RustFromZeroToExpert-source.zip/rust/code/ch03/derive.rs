// file: derive.rs
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
struct Version {
    major: u32,
    minor: u32,
    patch: u32,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Level {
    Low,                                        // variants compare in declaration order
    Medium,
    High,
}

fn main() {
    let mut versions = vec![
        Version { major: 1, minor: 10, patch: 0 },
        Version { major: 1, minor: 2, patch: 7 },
        Version { major: 0, minor: 99, patch: 1 },
    ];
    versions.sort();                            // derived Ord: major, then minor, then patch
    println!("{versions:?}");
    let v = versions[0];                        // Copy: versions still usable
    println!("default {:?}, equal: {}, max: {:?}", Version::default(), v == versions[0], versions.iter().max());
    println!("{:?} < {:?} < {:?}: {}", Level::Low, Level::Medium, Level::High, Level::Low < Level::Medium && Level::Medium < Level::High);
}
