// file: structs.rs
#[derive(Debug)]
struct User {
    name: String,
    email: String,
    active: bool,
    logins: u64,
}

#[derive(Debug)]
struct Rgb(u8, u8, u8);          // tuple struct

#[derive(Debug)]
struct Marker;                   // unit struct: no data, size 0

fn new_user(name: &str, email: &str) -> User {
    User { name: name.to_string(), email: email.to_string(), active: true, logins: 0 }
}

fn main() {
    let mut ada = new_user("Ada", "ada@example.com");
    ada.logins += 1;
    let email = String::from("grace@example.com");
    let grace = User { email, name: String::from("Grace"), ..ada };   // shorthand + update syntax
    println!("{grace:?}");
    println!("ada still has: active={} logins={}", ada.active, ada.logins);
    println!("ada is still whole: {} <{}>", ada.name, ada.email);   // name and email were not taken
    let teal = Rgb(0, 128, 128);
    println!("{teal:?} r={} g={} b={} {:?} size_of Marker = {}", teal.0, teal.1, teal.2, Marker, size_of::<Marker>());
}
