// file: methods.rs
#[derive(Debug, Clone, PartialEq)]
struct Rect {
    w: f64,
    h: f64,
}

impl Rect {
    fn new(w: f64, h: f64) -> Self {            // associated function (constructor)
        Self { w, h }
    }
    fn square(side: f64) -> Self {
        Self::new(side, side)
    }
    fn area(&self) -> f64 {                     // borrows immutably
        self.w * self.h
    }
    fn scale(&mut self, k: f64) {               // borrows mutably
        self.w *= k;
        self.h *= k;
    }
    fn can_hold(&self, other: &Rect) -> bool {
        self.w >= other.w && self.h >= other.h
    }
    fn into_square(self) -> Rect {              // consumes self
        let side = self.w.max(self.h);
        Rect::square(side)
    }
}

fn main() {
    let mut r = Rect::new(3.0, 4.0);
    println!("area {}", r.area());              // auto-borrow: (&r).area()
    r.scale(2.0);                               // auto-borrow: (&mut r).scale(2.0)
    println!("{r:?} holds a 5x5 square: {}", r.can_hold(&Rect::square(5.0)));
    let s = r.into_square();                    // r is moved
    println!("{s:?}");
}
