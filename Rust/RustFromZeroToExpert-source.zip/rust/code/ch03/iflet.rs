// file: iflet.rs
fn parse_kv(line: &str) -> Option<(&str, i64)> {
    let Some((key, value)) = line.split_once('=') else {
        return None;                            // no '=': give up early
    };
    let Ok(number) = value.trim().parse::<i64>() else {
        return None;
    };
    Some((key.trim(), number))
}

fn main() {
    for line in ["width = 80", "height=24", "title: none", "depth = deep"] {
        if let Some((k, v)) = parse_kv(line) {
            println!("{k} -> {v}");
        } else {
            println!("ignored {line:?}");
        }
    }
    let mut stack = vec![1, 2, 3];
    while let Some(top) = stack.pop() {
        print!("{top} ");
    }
    println!();
    let c = 'q';
    println!("lowercase letter: {}", matches!(c, 'a'..='z'));
}
