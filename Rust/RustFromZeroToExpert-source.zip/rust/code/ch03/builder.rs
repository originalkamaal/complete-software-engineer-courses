// file: builder.rs
#[allow(dead_code)]                    // the fields are only read through Debug here
#[derive(Debug)]
struct Request { url: String, method: String, timeout_ms: u64, retries: u32, headers: Vec<(String, String)> }

struct RequestBuilder { url: String, method: String, timeout_ms: u64, retries: u32, headers: Vec<(String, String)> }

impl RequestBuilder {
    fn new(url: &str) -> Self {
        RequestBuilder { url: url.into(), method: "GET".into(), timeout_ms: 30_000, retries: 0, headers: vec![] }
    }
    fn method(mut self, m: &str) -> Self { self.method = m.into(); self }
    fn timeout_ms(mut self, t: u64) -> Self { self.timeout_ms = t; self }
    fn retries(mut self, r: u32) -> Self { self.retries = r; self }
    fn header(mut self, k: &str, v: &str) -> Self { self.headers.push((k.into(), v.into())); self }
    fn build(self) -> Result<Request, String> {
        if !self.url.starts_with("http") { return Err(format!("bad url {:?}", self.url)); }
        if self.method == "POST" && self.retries > 0 { return Err("refusing to retry a POST".into()); }
        Ok(Request { url: self.url, method: self.method, timeout_ms: self.timeout_ms, retries: self.retries, headers: self.headers })
    }
}

fn main() {
    let r = RequestBuilder::new("https://example.org").timeout_ms(500).retries(2).header("Accept", "text/plain").build();
    println!("{r:#?}");
    println!("{:?}", RequestBuilder::new("https://example.org").method("POST").retries(3).build().unwrap_err());
}
