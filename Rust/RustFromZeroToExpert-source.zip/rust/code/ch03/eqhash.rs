// file: eqhash.rs
use std::collections::HashMap;

#[derive(Debug, PartialEq, Eq, Hash)]
struct Cell { row: i32, col: i32 }

#[derive(Debug, PartialEq)]
struct Reading { sensor: u32, value: f64 }

fn main() {
    let mut grid = HashMap::new();
    grid.insert(Cell { row: 1, col: 2 }, "wall");
    println!("{:?}", grid.get(&Cell { row: 1, col: 2 }));

    let nan = f64::NAN;
    println!("NaN == NaN: {}", nan == nan);
    let r = Reading { sensor: 1, value: nan };
    println!("reading equals itself: {}", r == r);
    // let mut m = HashMap::new(); m.insert(r, 1);   // error: Reading does not implement Eq or Hash
    let mut by_bits = HashMap::new();                 // a common workaround: key on the bit pattern
    by_bits.insert(nan.to_bits(), "nan bucket");
    println!("{:?}", by_bits.get(&f64::NAN.to_bits()));
}
