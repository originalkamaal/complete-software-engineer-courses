// file: rawvec.rs
use std::alloc::{Layout, alloc, dealloc, realloc};
use std::ptr::NonNull;

fn split_at_mut<T>(s: &mut [T], mid: usize) -> (&mut [T], &mut [T]) {
    let len = s.len();
    assert!(mid <= len, "mid out of range");              // the check that makes this sound
    let p = s.as_mut_ptr();
    // SAFETY: [0, mid) and [mid, len) are disjoint and within the original slice, which is
    // exclusively borrowed for the lifetime of both results.
    unsafe { (std::slice::from_raw_parts_mut(p, mid), std::slice::from_raw_parts_mut(p.add(mid), len - mid)) }
}

/// A minimal growable vector. Invariants: `ptr` points to an allocation of `cap` Ts
/// (dangling when cap == 0), and the first `len` of them are initialised.
pub struct MyVec<T> {
    ptr: NonNull<T>,
    cap: usize,
    len: usize,
}

// SAFETY: MyVec owns its Ts exactly like Vec does; sending it sends the Ts.
unsafe impl<T: Send> Send for MyVec<T> {}
// SAFETY: &MyVec only gives out &T.
unsafe impl<T: Sync> Sync for MyVec<T> {}

impl<T> MyVec<T> {
    pub fn new() -> Self {
        assert!(size_of::<T>() != 0, "zero-sized types not supported in this sketch");
        MyVec { ptr: NonNull::dangling(), cap: 0, len: 0 }
    }

    fn grow(&mut self) {
        let new_cap = if self.cap == 0 { 4 } else { self.cap * 2 };
        let new_layout = Layout::array::<T>(new_cap).expect("capacity overflow");
        let new_ptr = if self.cap == 0 {
            // SAFETY: new_layout has non-zero size (T is not zero-sized, new_cap > 0).
            unsafe { alloc(new_layout) }
        } else {
            let old_layout = Layout::array::<T>(self.cap).unwrap();
            // SAFETY: ptr was allocated with old_layout by this allocator; new size is non-zero.
            unsafe { realloc(self.ptr.as_ptr() as *mut u8, old_layout, new_layout.size()) }
        };
        self.ptr = NonNull::new(new_ptr as *mut T).unwrap_or_else(|| std::alloc::handle_alloc_error(new_layout));
        self.cap = new_cap;
    }

    pub fn push(&mut self, value: T) {
        if self.len == self.cap {
            self.grow();
        }
        // SAFETY: len < cap, so the slot is inside the allocation and uninitialised.
        unsafe { self.ptr.as_ptr().add(self.len).write(value) };
        self.len += 1;
    }

    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            return None;
        }
        self.len -= 1;
        // SAFETY: the slot at the old len-1 was initialised; after decrementing len it is
        // logically uninitialised, so reading it out moves the value exactly once.
        Some(unsafe { self.ptr.as_ptr().add(self.len).read() })
    }

    pub fn as_slice(&self) -> &[T] {
        // SAFETY: the first len elements are initialised and the pointer is valid and aligned
        // (dangling-but-aligned is fine for len == 0).
        unsafe { std::slice::from_raw_parts(self.ptr.as_ptr(), self.len) }
    }
}

impl<T> Drop for MyVec<T> {
    fn drop(&mut self) {
        while self.pop().is_some() {}                     // drop each element
        if self.cap > 0 {
            // SAFETY: allocated with exactly this layout in grow().
            unsafe { dealloc(self.ptr.as_ptr() as *mut u8, Layout::array::<T>(self.cap).unwrap()) };
        }
    }
}

fn main() {
    let mut v = [1, 2, 3, 4, 5];
    let (a, b) = split_at_mut(&mut v, 2);
    a[0] = 10;
    b[0] = 30;
    println!("{v:?}");

    let mut mv = MyVec::new();
    for i in 0..10 {
        mv.push(format!("item-{i}"));                     // heap-owning elements test Drop
    }
    println!("popped {:?}; len {} cap {}; first three {:?}", mv.pop(), mv.len, mv.cap, &mv.as_slice()[..3]);
    let moved = std::thread::spawn(move || mv.as_slice().len()).join().unwrap();   // Send in action
    println!("length seen by another thread: {moved}");
}
