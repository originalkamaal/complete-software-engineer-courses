// file: dangling.rs
fn make_pointer() -> *const String {
    let s = String::from("I live on the heap");
    &raw const s                                  // pointer to a local that is about to die
}

fn main() {
    let p = make_pointer();
    // SAFETY: none — this is a use-after-free, shown on purpose.
    unsafe {
        println!("length of dead string: {}", (*p).len());
    }
}
