// file: dangling2.rs
fn main() {
    let v = vec![1u64, 2, 3];
    let first = v.as_ptr();
    drop(v);                                      // the buffer is freed
    // SAFETY: none — use-after-free, shown on purpose.
    let value = unsafe { first.read() };
    println!("first element after free: {value}");
}
