// file: cstrings.rs
use std::ffi::{CStr, CString, c_char};

unsafe extern "C" {
    fn strlen(s: *const c_char) -> usize;
    fn getenv(name: *const c_char) -> *const c_char;
}

fn main() {
    let owned = CString::new("hello").unwrap();                       // adds the trailing NUL
    println!("strlen = {}", unsafe { strlen(owned.as_ptr()) });
    println!("interior NUL rejected: {}", CString::new("a\0b").is_err());

    let key = c"HOME";                                                 // a C string literal (Rust 1.77+)
    let p = unsafe { getenv(key.as_ptr()) };
    if !p.is_null() {
        let home: &CStr = unsafe { CStr::from_ptr(p) };               // borrowed from C's memory
        println!("HOME is {} bytes, valid UTF-8: {}", home.to_bytes().len(), home.to_str().is_ok());
    }
    // let dangling = CString::new("x").unwrap().as_ptr();            // pointer to a freed temporary!
}
