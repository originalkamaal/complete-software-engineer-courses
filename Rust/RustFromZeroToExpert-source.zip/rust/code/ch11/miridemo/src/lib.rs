// file: miridemo/src/lib.rs
/// Returns the first element, using a raw pointer.
pub fn first(v: &[u32]) -> Option<u32> {
    if v.is_empty() { return None; }
    Some(unsafe { *v.as_ptr() })
}

/// Bug: reads one past the end.
pub fn last_buggy(v: &[u32]) -> u32 {
    unsafe { *v.as_ptr().add(v.len()) }
}

#[cfg(test)]
mod tests {
    #[test]
    fn first_works() { assert_eq!(super::first(&[7, 8]), Some(7)); }
    #[test]
    fn last_buggy_reads_past_the_end() {
        let v = vec![1u32, 2, 3];
        let _ = super::last_buggy(&v);          // passes under plain cargo test
    }
}
