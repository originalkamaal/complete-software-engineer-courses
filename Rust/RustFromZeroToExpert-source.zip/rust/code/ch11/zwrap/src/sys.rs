// file: zwrap/src/sys.rs
//! Raw declarations matching zlib.h (zlib 1.2/1.3, 64-bit Linux). Every item here is unsafe to use.
#![allow(non_camel_case_types)]
use std::ffi::{c_char, c_int, c_uint, c_ulong, c_void};

#[repr(C)]
pub struct z_stream {
    pub next_in: *const u8,
    pub avail_in: c_uint,
    pub total_in: c_ulong,
    pub next_out: *mut u8,
    pub avail_out: c_uint,
    pub total_out: c_ulong,
    pub msg: *const c_char,
    pub state: *mut c_void,
    pub zalloc: Option<unsafe extern "C" fn(*mut c_void, c_uint, c_uint) -> *mut c_void>,
    pub zfree: Option<unsafe extern "C" fn(*mut c_void, *mut c_void)>,
    pub opaque: *mut c_void,
    pub data_type: c_int,
    pub adler: c_ulong,
    pub reserved: c_ulong,
}

pub const Z_OK: c_int = 0;
pub const Z_STREAM_END: c_int = 1;
pub const Z_BUF_ERROR: c_int = -5;
pub const Z_NO_FLUSH: c_int = 0;
pub const Z_FINISH: c_int = 4;

#[link(name = "z")]
unsafe extern "C" {
    pub fn zlibVersion() -> *const c_char;
    pub fn compressBound(source_len: c_ulong) -> c_ulong;
    pub fn compress2(dest: *mut u8, dest_len: *mut c_ulong, source: *const u8, source_len: c_ulong, level: c_int) -> c_int;
    pub fn uncompress(dest: *mut u8, dest_len: *mut c_ulong, source: *const u8, source_len: c_ulong) -> c_int;
    pub fn crc32(crc: c_ulong, buf: *const u8, len: c_uint) -> c_ulong;
    pub fn deflateInit2_(strm: *mut z_stream, level: c_int, method: c_int, window_bits: c_int, mem_level: c_int,
                         strategy: c_int, version: *const c_char, stream_size: c_int) -> c_int;
    pub fn deflate(strm: *mut z_stream, flush: c_int) -> c_int;
    pub fn deflateEnd(strm: *mut z_stream) -> c_int;
}
