// file: zwrap/src/main.rs
use std::io::Write;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("zlib version {}", zwrap::version());
    let text: Vec<u8> = (0..20_000).flat_map(|i| format!("line {i}: the quick brown fox\n").into_bytes()).collect();
    for level in [1, 6, 9] {
        let z = zwrap::compress(&text, level)?;
        println!("level {level}: {} -> {} bytes ({:.1}%)", text.len(), z.len(), 100.0 * z.len() as f64 / text.len() as f64);
    }
    let z = zwrap::compress(&text, 6)?;
    let back = zwrap::decompress(&z, text.len())?;
    println!("round trip identical: {}, crc32 {:08x} == {:08x}", back == text, zwrap::crc32(&text), zwrap::crc32(&back));

    let mut enc = zwrap::GzipEncoder::new(6)?;
    for chunk in text.chunks(1000) {                       // stream it in pieces
        enc.write(chunk)?;
    }
    let gz = enc.finish()?;
    std::fs::File::create("out.txt.gz")?.write_all(&gz)?;
    std::fs::write("out.txt", &text)?;
    println!("wrote out.txt.gz ({} bytes)", gz.len());
    let dropped_early = zwrap::GzipEncoder::new(9)?;      // never finished: Drop must still free it
    drop(dropped_early);
    Ok(())
}
