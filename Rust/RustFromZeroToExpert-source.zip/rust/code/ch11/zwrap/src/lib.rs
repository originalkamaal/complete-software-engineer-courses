// file: zwrap/src/lib.rs
//! A safe wrapper over the system zlib. No `unsafe` is needed to use it.
mod sys;

use std::ffi::{CStr, c_int, c_uint, c_ulong};
use std::mem::MaybeUninit;

/// An error code returned by zlib.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ZError(pub i32);

impl std::fmt::Display for ZError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let what = match self.0 { -2 => "stream error", -3 => "data error", -4 => "out of memory", -5 => "buffer error", _ => "zlib error" };
        write!(f, "{what} ({})", self.0)
    }
}
impl std::error::Error for ZError {}

/// The version string of the zlib library actually loaded.
pub fn version() -> String {
    // SAFETY: zlibVersion returns a pointer to a static NUL-terminated string.
    unsafe { CStr::from_ptr(sys::zlibVersion()) }.to_string_lossy().into_owned()
}

/// CRC-32 (as used by gzip, PNG, and ZIP) of `data`.
pub fn crc32(data: &[u8]) -> u32 {
    let mut crc: c_ulong = 0;
    for chunk in data.chunks(c_uint::MAX as usize) {       // zlib takes a 32-bit length
        // SAFETY: chunk is a valid readable buffer of chunk.len() bytes.
        crc = unsafe { sys::crc32(crc, chunk.as_ptr(), chunk.len() as c_uint) };
    }
    crc as u32
}

/// Compresses `data` into the zlib format at `level` (0-9).
pub fn compress(data: &[u8], level: i32) -> Result<Vec<u8>, ZError> {
    // SAFETY: compressBound is a pure function of its argument.
    let bound = unsafe { sys::compressBound(data.len() as c_ulong) } as usize;
    let mut out = Vec::with_capacity(bound);
    let mut out_len = bound as c_ulong;
    // SAFETY: out has capacity `bound` writable bytes and out_len says so; data is readable.
    let rc = unsafe { sys::compress2(out.as_mut_ptr(), &mut out_len, data.as_ptr(), data.len() as c_ulong, level) };
    if rc != sys::Z_OK {
        return Err(ZError(rc));
    }
    // SAFETY: zlib wrote exactly out_len (<= bound) initialised bytes.
    unsafe { out.set_len(out_len as usize) };
    Ok(out)
}

/// Decompresses zlib data whose decompressed size is at most `max_len`.
pub fn decompress(data: &[u8], max_len: usize) -> Result<Vec<u8>, ZError> {
    let mut out = Vec::with_capacity(max_len);
    let mut out_len = max_len as c_ulong;
    // SAFETY: as in compress: out has max_len writable bytes.
    let rc = unsafe { sys::uncompress(out.as_mut_ptr(), &mut out_len, data.as_ptr(), data.len() as c_ulong) };
    if rc != sys::Z_OK {
        return Err(ZError(rc));
    }
    // SAFETY: zlib reports how many bytes it wrote.
    unsafe { out.set_len(out_len as usize) };
    Ok(out)
}

/// A streaming compressor producing gzip format. Owns a z_stream; freed on drop.
pub struct GzipEncoder {
    strm: Box<sys::z_stream>,          // boxed: zlib keeps a pointer back to the stream, so it must not move
    out: Vec<u8>,
}

impl GzipEncoder {
    pub fn new(level: i32) -> Result<Self, ZError> {
        // SAFETY: an all-zero z_stream is the documented initial state (NULL zalloc/zfree/opaque = defaults).
        let mut strm: Box<sys::z_stream> = Box::new(unsafe { MaybeUninit::zeroed().assume_init() });
        // windowBits 15 + 16 selects the gzip wrapper; memLevel 8 and strategy 0 are zlib's defaults.
        // SAFETY: strm is valid and zeroed; version and size match the header we were written against (DT-32).
        let rc = unsafe {
            sys::deflateInit2_(&mut *strm, level, 8, 15 + 16, 8, 0, sys::zlibVersion(), size_of::<sys::z_stream>() as c_int)
        };
        if rc != sys::Z_OK {
            return Err(ZError(rc));                        // nothing allocated: no deflateEnd needed
        }
        Ok(GzipEncoder { strm, out: Vec::new() })
    }

    fn run(&mut self, input: &[u8], flush: c_int) -> Result<(), ZError> {
        self.strm.next_in = input.as_ptr();
        self.strm.avail_in = input.len() as c_uint;
        loop {
            self.out.reserve(64 * 1024);
            let spare = self.out.capacity() - self.out.len();
            // SAFETY: the pointer is just past the initialised part of `out`, with `spare` bytes of capacity.
            self.strm.next_out = unsafe { self.out.as_mut_ptr().add(self.out.len()) };
            self.strm.avail_out = spare as c_uint;
            // SAFETY: strm was initialised by deflateInit2_ and its in/out pointers are valid right now.
            let rc = unsafe { sys::deflate(&mut *self.strm, flush) };
            let written = spare - self.strm.avail_out as usize;
            // SAFETY: deflate initialised `written` bytes after the old length.
            unsafe { self.out.set_len(self.out.len() + written) };
            match rc {
                sys::Z_STREAM_END => return Ok(()),
                sys::Z_OK | sys::Z_BUF_ERROR if self.strm.avail_in == 0 && flush == sys::Z_NO_FLUSH => return Ok(()),
                sys::Z_OK | sys::Z_BUF_ERROR => continue,           // more output to produce
                e => return Err(ZError(e)),
            }
        }
    }

    /// Feeds more input.
    pub fn write(&mut self, input: &[u8]) -> Result<(), ZError> {
        self.run(input, sys::Z_NO_FLUSH)
    }

    /// Finishes the stream and returns the gzip bytes.
    pub fn finish(mut self) -> Result<Vec<u8>, ZError> {
        self.run(&[], sys::Z_FINISH)?;
        Ok(std::mem::take(&mut self.out))                  // Drop still runs and frees the stream
    }
}

impl Drop for GzipEncoder {
    fn drop(&mut self) {
        // SAFETY: strm was successfully initialised in new() and is ended exactly once, here.
        unsafe { sys::deflateEnd(&mut *self.strm) };
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crc32_known_value() {
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);       // the standard CRC-32 check value
    }

    #[test]
    fn round_trip_and_errors() {
        let data = b"hello hello hello hello zlib".repeat(100);
        let z = compress(&data, 9).unwrap();
        assert!(z.len() < data.len() / 10);
        assert_eq!(decompress(&z, data.len()).unwrap(), data);
        assert_eq!(decompress(&z, 10), Err(ZError(-5)));         // output buffer too small
        assert_eq!(decompress(b"not zlib", 100), Err(ZError(-3)));  // corrupt input
    }
}
