// file: callc.rs
use std::ffi::{CStr, CString, c_char, c_int, c_void};

unsafe extern "C" {
    fn strlen(s: *const c_char) -> usize;
    fn qsort(base: *mut c_void, n: usize, size: usize, cmp: extern "C" fn(*const c_void, *const c_void) -> c_int);
    fn getenv(name: *const c_char) -> *const c_char;
    safe fn abs(x: c_int) -> c_int;                // edition 2024: declare a foreign fn as safe to call
}

extern "C" fn compare_i32(a: *const c_void, b: *const c_void) -> c_int {
    // SAFETY: qsort passes pointers to elements of the i32 array we gave it.
    let (x, y) = unsafe { (*(a as *const i32), *(b as *const i32)) };
    x.cmp(&y) as c_int
}

fn main() {
    let s = CString::new("hello, C").unwrap();     // adds the NUL terminator; rejects interior NULs
    // SAFETY: s is a valid NUL-terminated string that outlives the call.
    println!("strlen = {}", unsafe { strlen(s.as_ptr()) });

    let mut v = [42, -7, 19, 0, 3];
    // SAFETY: base/len/size describe our array exactly, and compare_i32 matches the element type.
    unsafe { qsort(v.as_mut_ptr() as *mut c_void, v.len(), size_of::<i32>(), compare_i32) };
    println!("qsorted by C: {v:?}, abs(-5) = {}", abs(-5));

    let name = CString::new("HOME").unwrap();
    // SAFETY: getenv returns NULL or a pointer to a NUL-terminated string owned by the C library.
    let home = unsafe { getenv(name.as_ptr()) };
    if !home.is_null() {
        // SAFETY: non-null, NUL-terminated, and not modified while we read it.
        println!("HOME = {}", unsafe { CStr::from_ptr(home) }.to_string_lossy());
    }
    println!("CString::new with interior NUL: {:?}", CString::new("a\0b").map(|_| ()));
}
