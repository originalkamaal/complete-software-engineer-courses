// file: rustlib/src/lib.rs
use std::ffi::{CStr, CString, c_char};

/// Returns the number of words in a NUL-terminated UTF-8 string, or -1 if it is not valid UTF-8.
///
/// # Safety
/// `text` must be a valid pointer to a NUL-terminated string.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rl_word_count(text: *const c_char) -> i64 {
    // SAFETY: guaranteed by the caller per the contract above.
    let s = unsafe { CStr::from_ptr(text) };
    match s.to_str() {
        Ok(t) => t.split_whitespace().count() as i64,
        Err(_) => -1,
    }
}

/// Returns a newly allocated upper-case copy; free it with `rl_free`.
///
/// # Safety
/// `text` must be a valid pointer to a NUL-terminated string.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rl_upper(text: *const c_char) -> *mut c_char {
    // SAFETY: guaranteed by the caller.
    let s = unsafe { CStr::from_ptr(text) }.to_string_lossy().to_uppercase();
    CString::new(s).map(CString::into_raw).unwrap_or(std::ptr::null_mut())
}

/// Frees a string returned by `rl_upper`. Passing NULL is allowed.
///
/// # Safety
/// `p` must be NULL or a pointer returned by `rl_upper` that has not been freed.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rl_free(p: *mut c_char) {
    if !p.is_null() {
        // SAFETY: p came from CString::into_raw in rl_upper and is freed exactly once.
        drop(unsafe { CString::from_raw(p) });
    }
}
