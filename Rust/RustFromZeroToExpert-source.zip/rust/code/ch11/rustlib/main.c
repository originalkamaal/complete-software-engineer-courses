// file: rustlib/main.c
#include <stdint.h>
#include <stdio.h>

int64_t rl_word_count(const char *text);
char *rl_upper(const char *text);
void rl_free(char *p);

int main(void) {
    const char *msg = "Rust functions, called from C";
    char *up = rl_upper(msg);
    printf("%lld words; upper: %s\n", (long long)rl_word_count(msg), up);
    rl_free(up);                       /* Rust allocated it, so Rust frees it */
    printf("invalid UTF-8 -> %lld\n", (long long)rl_word_count("\xff\xfe"));
    return 0;
}
