// file: maybeuninit.rs
use std::mem::MaybeUninit;

fn squares<const N: usize>() -> [u64; N] {
    let mut arr: [MaybeUninit<u64>; N] = [const { MaybeUninit::uninit() }; N];
    for (i, slot) in arr.iter_mut().enumerate() {
        slot.write((i * i) as u64);                         // initialise every element
    }
    // SAFETY: every element was written in the loop above.
    unsafe { std::mem::transmute_copy::<_, [u64; N]>(&arr) }
}

fn main() {
    println!("{:?}", squares::<6>());
    let arr2: [String; 3] = std::array::from_fn(|i| format!("item {i}"));   // the safe way, when it fits
    println!("{arr2:?}");
}
