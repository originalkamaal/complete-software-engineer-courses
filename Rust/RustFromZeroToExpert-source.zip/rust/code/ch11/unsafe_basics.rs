// file: unsafe_basics.rs
/// Returns the element at `index` without a bounds check.
///
/// # Safety
/// `index` must be less than `slice.len()`.
unsafe fn get_unchecked_demo(slice: &[u32], index: usize) -> u32 {
    // SAFETY: the caller guarantees index < len, so the pointer is in bounds and aligned.
    unsafe { *slice.as_ptr().add(index) }
}

static mut EVENTS: u32 = 0;

fn main() {
    let mut x = 10;
    let p = &raw mut x;                           // creating raw pointers is safe...
    let q = &raw const x;
    unsafe {
        *p += 1;                                  // ...dereferencing them is not
        println!("x = {}, read through q = {}", *p, *q);
    }

    let data = [3, 1, 4, 1, 5];
    // SAFETY: 2 < data.len() == 5.
    let third = unsafe { get_unchecked_demo(&data, 2) };
    println!("third = {third}");

    // SAFETY: single-threaded program; no other reference to EVENTS exists.
    unsafe {
        EVENTS += 1;
        println!("events = {}", *(&raw const EVENTS));
    }

    let n: u8 = 1;
    // SAFETY: 1 is a valid bool representation (0 or 1 only).
    let b: bool = unsafe { std::mem::transmute(n) };
    println!("transmuted bool = {b}");
}
