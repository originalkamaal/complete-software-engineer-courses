// file: ws/geom/src/lib.rs
/// Area of a triangle from its three side lengths (Heron's formula).
pub fn heron(a: f64, b: f64, c: f64) -> Option<f64> {
    let s = (a + b + c) / 2.0;
    let sq = s * (s - a) * (s - b) * (s - c);
    (sq >= 0.0).then(|| sq.sqrt())
}

#[cfg(test)]
mod tests {
    #[test]
    fn right_triangle() { assert_eq!(super::heron(3.0, 4.0, 5.0), Some(6.0)); }
    #[test]
    fn impossible() { assert_eq!(super::heron(1.0, 1.0, 5.0), None); }
}
