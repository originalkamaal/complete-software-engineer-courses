// file: ws/app/src/main.rs
fn main() {
    match geom::heron(5.0, 5.0, 6.0) {
        Some(a) => println!("area = {a}"),
        None => println!("not a triangle"),
    }
}
