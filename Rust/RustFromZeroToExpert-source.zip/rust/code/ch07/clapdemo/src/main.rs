// file: clapdemo/src/main.rs
use clap::{Parser, Subcommand, ValueEnum};
use std::path::PathBuf;

/// A tiny file tool, to show clap's derive API.
#[derive(Parser, Debug)]
#[command(version, about)]
struct Cli {
    /// Print more detail (repeat for even more: -vv)
    #[arg(short, long, action = clap::ArgAction::Count)]
    verbose: u8,

    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand, Debug)]
enum Command {
    /// Count lines, words, or bytes in files
    Count {
        /// What to count
        #[arg(short, long, value_enum, default_value_t = Unit::Lines)]
        unit: Unit,
        /// Files to read
        #[arg(required = true)]
        files: Vec<PathBuf>,
    },
    /// Print the first N lines of a file
    Head {
        #[arg(short = 'n', long, default_value_t = 10, value_parser = clap::value_parser!(u32).range(1..=1000))]
        lines: u32,
        file: PathBuf,
    },
}

#[derive(Copy, Clone, Debug, ValueEnum)]
enum Unit { Lines, Words, Bytes }

fn main() {
    let cli = Cli::parse();                      // exits with status 2 and a message on bad input
    if cli.verbose > 0 { eprintln!("parsed: {cli:?}"); }
    match cli.command {
        Command::Count { unit, files } => {
            for f in files {
                let text = std::fs::read_to_string(&f).unwrap_or_default();
                let n = match unit {
                    Unit::Lines => text.lines().count(),
                    Unit::Words => text.split_whitespace().count(),
                    Unit::Bytes => text.len(),
                };
                println!("{n:>6} {}", f.display());
            }
        }
        Command::Head { lines, file } => {
            let text = std::fs::read_to_string(&file).unwrap_or_default();
            for l in text.lines().take(lines as usize) { println!("{l}"); }
        }
    }
}
