// file: shop/src/lib.rs
//! A tiny shop: the crate root decides what the public API looks like.

mod inventory;                              // src/inventory.rs
mod pricing;                                // src/pricing/mod.rs + src/pricing/discount.rs

pub use inventory::{Inventory, Item};       // re-exports: users write shop::Item
pub use pricing::total;

/// Version of the pricing rules, visible inside the crate only.
pub(crate) const RULES_VERSION: u32 = 3;
