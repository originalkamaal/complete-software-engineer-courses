// file: shop/src/inventory.rs
#[derive(Debug, Clone)]
pub struct Item {
    pub name: String,
    pub cents: u64,
    sku: u32,                               // private field: only this module can set it
}

impl Item {
    pub fn new(name: &str, cents: u64) -> Item {
        Item { name: name.to_string(), cents, sku: next_sku() }
    }
    pub fn sku(&self) -> u32 {
        self.sku
    }
}

fn next_sku() -> u32 {                      // private helper
    use std::sync::atomic::{AtomicU32, Ordering};
    static NEXT: AtomicU32 = AtomicU32::new(1000);
    NEXT.fetch_add(1, Ordering::Relaxed)
}

#[derive(Default)]
pub struct Inventory {
    items: Vec<Item>,
}

impl Inventory {
    pub fn add(&mut self, item: Item) {
        self.items.push(item);
    }
    pub fn items(&self) -> &[Item] {
        &self.items
    }
}
