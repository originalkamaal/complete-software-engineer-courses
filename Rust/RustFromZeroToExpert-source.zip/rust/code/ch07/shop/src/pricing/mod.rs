// file: shop/src/pricing/mod.rs
mod discount;                               // src/pricing/discount.rs, private to pricing

use crate::inventory::Item;

/// Total price in cents after the bulk discount.
pub fn total(items: &[Item]) -> u64 {
    let gross: u64 = items.iter().map(|i| i.cents).sum();
    gross - discount::bulk(gross, items.len())
}
