// file: shop/src/pricing/discount.rs
/// 10% off orders of 3 or more items, under rules version `RULES_VERSION`.
pub(super) fn bulk(gross: u64, count: usize) -> u64 {
    debug_assert!(crate::RULES_VERSION >= 3);
    if count >= 3 { gross / 10 } else { 0 }
}
