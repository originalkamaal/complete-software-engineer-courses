// file: shop/src/main.rs
use shop::{Inventory, Item};

fn main() {
    let mut inv = Inventory::default();
    for (name, cents) in [("pen", 150), ("pad", 400), ("ink", 950)] {
        inv.add(Item::new(name, cents));
    }
    for item in inv.items() {
        println!("#{} {:<4} {:>5.2}", item.sku(), item.name, item.cents as f64 / 100.0);
    }
    println!("total with bulk discount: {:.2}", shop::total(inv.items()) as f64 / 100.0);
}
