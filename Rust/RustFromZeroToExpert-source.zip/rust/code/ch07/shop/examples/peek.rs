// file: shop/examples/peek.rs
fn main() {
    let item = shop::Item::new("x", 1);
    println!("{}", item.sku);                   // private field
    shop::pricing::total(&[]);                  // private module
}
