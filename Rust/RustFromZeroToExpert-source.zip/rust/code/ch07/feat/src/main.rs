// file: feat/src/main.rs
#[cfg(feature = "fast-hash")]
type Map<K, V> = rustc_hash::FxHashMap<K, V>;
#[cfg(not(feature = "fast-hash"))]
type Map<K, V> = std::collections::HashMap<K, V>;

fn main() {
    let mut m: Map<u64, u64> = Map::default();
    let t = std::time::Instant::now();
    for i in 0..5_000_000u64 {
        *m.entry(i % 100_000).or_insert(0) += i;
    }
    let hasher = if cfg!(feature = "fast-hash") { "FxHash" } else { "SipHash (std)" };
    println!("{hasher:<14} {} keys in {:.0?}", m.len(), t.elapsed());
}
