// file: vis/examples/use_it.rs
use vis::Parser;                                         // the re-exported path

fn main() {
    let mut p = Parser::new();
    println!("depth = {}", p.parse("((x))"));
    // println!("{}", p.depth);                          // error: field `depth` is private (pub(crate))
}
