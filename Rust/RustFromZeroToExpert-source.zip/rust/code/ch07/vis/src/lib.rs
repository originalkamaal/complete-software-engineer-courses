// file: vis/src/lib.rs
mod parse {
    pub struct Parser { pub(crate) depth: usize }       // field visible in this crate only
    impl Parser {
        pub fn new() -> Self { Parser { depth: 0 } }
        pub fn parse(&mut self, s: &str) -> usize { self.depth = helpers::nesting(s); self.depth }
    }
    mod helpers {
        pub(super) fn nesting(s: &str) -> usize {        // usable by parse, not by the rest of the crate
            let (mut d, mut max) = (0i32, 0i32);
            for c in s.chars() {
                if c == '(' { d += 1; max = max.max(d); } else if c == ')' { d -= 1; }
            }
            max as usize
        }
    }
}
pub use parse::Parser;                                  // the public path is vis::Parser

#[cfg(test)]                                            // only the tests need it
pub(crate) fn debug_depth(p: &Parser) -> usize { p.depth }

#[cfg(test)]
mod tests {
    #[test]
    fn depth_is_visible_inside_the_crate() {
        let mut p = super::Parser::new();
        p.parse("(a(b)(c(d)))");
        assert_eq!(super::debug_depth(&p), 3);
    }
}
