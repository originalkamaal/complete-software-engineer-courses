// file: textkit/core/src/tokens.rs
/// Iterates over the words of `text`: maximal runs of letters, digits, and apostrophes.
///
/// ```
/// let w: Vec<&str> = textkit_core::words("It's 9 o'clock -- isn't it?").collect();
/// assert_eq!(w, ["It's", "9", "o'clock", "isn't", "it"]);
/// ```
pub fn words(text: &str) -> impl Iterator<Item = &str> {
    text.split(|c: char| !(c.is_alphanumeric() || c == '\'')).map(|w| w.trim_matches('\'')).filter(|w| !w.is_empty())
}

/// Lower-cases a word for counting. With the `unicode-case` feature, also folds `ß` to `ss`.
///
/// ```
/// assert_eq!(textkit_core::normalise("Straße"), if cfg!(feature = "unicode-case") { "strasse" } else { "straße" });
/// ```
pub fn normalise(word: &str) -> String {
    let lower = word.to_lowercase();
    if cfg!(feature = "unicode-case") { lower.replace('ß', "ss") } else { lower }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn apostrophes_at_edges_are_trimmed() {
        assert_eq!(words("'quoted' rock'n'roll").collect::<Vec<_>>(), ["quoted", "rock'n'roll"]);
    }
}
