// file: textkit/core/src/readability.rs
/// Estimates syllables by counting groups of vowels, with a silent-`e` rule.
pub(crate) fn syllables(word: &str) -> usize {
    let w = word.to_lowercase();
    let mut count = 0;
    let mut prev_vowel = false;
    for c in w.chars() {
        let vowel = "aeiouy".contains(c);
        if vowel && !prev_vowel {
            count += 1;
        }
        prev_vowel = vowel;
    }
    if w.ends_with('e') && !w.ends_with("le") && count > 1 {
        count -= 1;
    }
    count.max(1)
}

/// Flesch reading-ease score: higher is easier (90+ very easy, below 30 very hard).
///
/// Returns `None` for text with no words.
pub fn flesch_reading_ease(stats: &crate::Stats) -> Option<f64> {
    if stats.words == 0 {
        return None;
    }
    let w = stats.words as f64;
    Some(206.835 - 1.015 * (w / stats.sentences as f64) - 84.6 * (stats.syllables as f64 / w))
}

#[cfg(test)]
mod tests {
    #[test]
    fn syllable_estimates() {
        for (word, n) in [("cat", 1), ("table", 2), ("make", 1), ("beautiful", 3), ("rhythm", 1)] {
            assert_eq!(super::syllables(word), n, "{word}");     // private function: unit tests can see it
        }
    }
}
