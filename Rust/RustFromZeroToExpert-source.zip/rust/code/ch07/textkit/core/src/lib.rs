// file: textkit/core/src/lib.rs
//! Text statistics: words, sentences, and readability.
//!
//! ```
//! let stats = textkit_core::Stats::of("One fish. Two fish!");
//! assert_eq!(stats.words, 4);
//! assert_eq!(stats.sentences, 2);
//! ```
#![warn(missing_docs)]

mod readability;
mod tokens;

pub use readability::flesch_reading_ease;
pub use tokens::{normalise, words};

/// Counts computed over a text.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Stats {
    /// Number of words.
    pub words: usize,
    /// Number of sentences (runs of text ending in `.`, `!`, or `?`).
    pub sentences: usize,
    /// Number of syllables, estimated from vowel groups.
    pub syllables: usize,
}

impl Stats {
    /// Computes statistics for `text`.
    ///
    /// Text with no sentence-ending punctuation counts as one sentence if it has any words.
    pub fn of(text: &str) -> Stats {
        let words: Vec<&str> = words(text).collect();
        let ends = text.chars().filter(|c| matches!(c, '.' | '!' | '?')).count();
        Stats {
            words: words.len(),
            sentences: if ends == 0 && !words.is_empty() { 1 } else { ends },
            syllables: words.iter().map(|w| readability::syllables(w)).sum(),
        }
    }
}
