// file: textkit/core/tests/api.rs
// An integration test: sees only the public API of textkit-core.
use textkit_core::{Stats, flesch_reading_ease};
use textkit_fixtures::{EASY, HARD};

#[test]
fn easy_text_scores_higher_than_hard_text() {
    let easy = flesch_reading_ease(&Stats::of(EASY)).unwrap();
    let hard = flesch_reading_ease(&Stats::of(HARD)).unwrap();
    assert!(easy > 90.0, "easy = {easy}");
    assert!(hard < 10.0, "hard = {hard}");
}

#[test]
fn empty_text_has_no_score() {
    assert_eq!(Stats::of(""), Stats::default());
    assert_eq!(flesch_reading_ease(&Stats::of("")), None);
}
