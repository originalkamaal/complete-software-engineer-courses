// file: textkit/fixtures/src/lib.rs
//! Sample texts shared by the workspace's tests.

/// A very easy text.
pub const EASY: &str = "The cat sat. The dog ran. We had fun.";
/// A hard text: long sentences and long words.
pub const HARD: &str = "Notwithstanding considerable institutional reluctance, the organisation's administrative \
    infrastructure underwent comprehensive restructuring, necessitating unprecedented interdepartmental coordination.";
