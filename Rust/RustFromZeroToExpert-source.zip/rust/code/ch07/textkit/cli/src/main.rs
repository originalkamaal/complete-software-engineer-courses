// file: textkit/cli/src/main.rs
use std::collections::HashMap;
use std::io::Read;
use textkit_core::{Stats, flesch_reading_ease, normalise, words};

fn main() {
    let mut text = String::new();
    std::io::stdin().read_to_string(&mut text).expect("UTF-8 input");
    let stats = Stats::of(&text);
    let mut freq: HashMap<String, usize> = HashMap::new();
    for w in words(&text) {
        *freq.entry(normalise(w)).or_default() += 1;
    }
    let mut top: Vec<_> = freq.into_iter().collect();
    top.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
    println!("{} words, {} sentences, {} syllables", stats.words, stats.sentences, stats.syllables);
    match flesch_reading_ease(&stats) {
        Some(score) => println!("reading ease {score:.1}"),
        None => println!("reading ease: n/a"),
    }
    let top: Vec<String> = top.iter().take(5).map(|(w, n)| format!("{w}×{n}")).collect();
    println!("top words: {}", top.join(" "));
}
