// file: partest/src/lib.rs
pub fn config_path() -> String {
    std::env::var("APP_CONFIG").unwrap_or_else(|_| "/etc/app.conf".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn uses_default_path() {
        assert_eq!(config_path(), "/etc/app.conf");
    }

    #[test]
    fn honours_environment() {
        unsafe { std::env::set_var("APP_CONFIG", "/tmp/test.conf") };   // process-wide!
        std::thread::sleep(std::time::Duration::from_millis(50));
        assert_eq!(config_path(), "/tmp/test.conf");
        unsafe { std::env::remove_var("APP_CONFIG") };
    }

    #[test]
    #[should_panic(expected = "divide by zero")]
    fn panics_on_zero() {
        let zero = std::hint::black_box(0);
        let _ = 1 / zero;
    }

    #[test]
    fn returns_result() -> Result<(), std::num::ParseIntError> {
        assert_eq!("42".parse::<i32>()?, 42);
        Ok(())
    }
}
