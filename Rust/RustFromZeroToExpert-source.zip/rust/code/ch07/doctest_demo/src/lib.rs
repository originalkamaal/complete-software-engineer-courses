// file: doctest_demo/src/lib.rs
//! Small text helpers.

/// Returns the initials of a name, uppercased.
///
/// ```
/// use doctest_demo::initials;
/// assert_eq!(initials("ada lovelace"), "AL");
/// assert_eq!(initials(""), "");
/// ```
///
/// Non-letters are skipped:
///
/// ```
/// # use doctest_demo::initials;
/// assert_eq!(initials("  jean-luc   picard "), "JP");
/// ```
pub fn initials(name: &str) -> String {
    name.split_whitespace().filter_map(|w| w.chars().next()).flat_map(char::to_uppercase).collect()
}

/// Divides, panicking on zero.
///
/// ```should_panic
/// doctest_demo::div(1, 0);
/// ```
pub fn div(a: i32, b: i32) -> i32 { a / b }
