// file: serdedemo/examples/unknown.rs
#![allow(dead_code)]                       // the fields are only looked at through Debug
use serde::Deserialize;

#[derive(Debug, Deserialize)]
struct Lenient { #[serde(default)] replicas: u32 }

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Strict { #[serde(default)] replicas: u32 }

fn main() {
    let typo = r#"{ "replica": 3 }"#;
    println!("lenient: {:?}", serde_json::from_str::<Lenient>(typo));
    println!("strict:  {}", serde_json::from_str::<Strict>(typo).unwrap_err());
}
