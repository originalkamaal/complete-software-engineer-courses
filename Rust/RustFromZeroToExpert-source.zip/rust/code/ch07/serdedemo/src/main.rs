// file: serdedemo/src/main.rs
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]                     // Rust snake_case <-> JSON camelCase
struct Service {
    name: String,
    listen_port: u16,
    #[serde(default)]                                   // missing in the input -> Default::default()
    replicas: u32,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    tags: Vec<String>,
    health: Health,
    env: BTreeMap<String, String>,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "lowercase")]       // an enum written as {"kind": "...", ...}
enum Health {
    Http { path: String },
    Tcp,
    None,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let input = r#"{
        "name": "api",
        "listenPort": 8080,
        "health": { "kind": "http", "path": "/healthz" },
        "env": { "RUST_LOG": "info", "MODE": "prod" }
    }"#;
    let svc: Service = serde_json::from_str(input)?;
    println!("{svc:?}");
    println!("{}", serde_json::to_string(&svc)?);

    let bad = r#"{ "name": "api", "listenPort": "eighty", "health": {"kind": "tcp"}, "env": {} }"#;
    match serde_json::from_str::<Service>(bad) {
        Ok(_) => println!("unexpected success"),
        Err(e) => println!("error: {e}"),
    }
    let too_big = r#"{ "name": "x", "listenPort": 70000, "health": {"kind": "none"}, "env": {} }"#;
    println!("error: {}", serde_json::from_str::<Service>(too_big).unwrap_err());

    let untyped: serde_json::Value = serde_json::from_str(input)?;    // when the shape is not known
    println!("health path via Value: {}", untyped["health"]["path"]);
    Ok(())
}
