// file: confload/src/lib.rs
use std::collections::HashMap;
use std::fmt;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub workers: u32,
    pub log_level: LogLevel,
    pub timeout_ms: u64,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum LogLevel { Error, Warn, Info, Debug }

/// Where a problem is.
#[derive(Debug, Clone, PartialEq)]
pub struct Span { pub line: usize, pub column: usize }

impl fmt::Display for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}", self.line, self.column)
    }
}

#[derive(Debug, Error, PartialEq)]
#[non_exhaustive]
pub enum ConfigError {
    #[error("{at}: expected `key = value`, `[section]`, or a comment")]
    Syntax { at: Span },
    #[error("{at}: unknown key `{key}` in section [{section}]")]
    UnknownKey { at: Span, section: String, key: String },
    #[error("{at}: `{key}` is set twice (first at line {first})")]
    Duplicate { at: Span, key: String, first: usize },
    #[error("{at}: invalid value {value:?} for `{key}`: {reason}")]
    Invalid { at: Span, key: String, value: String, reason: String },
    #[error("missing required key `{0}`")]
    Missing(&'static str),
}

const KNOWN: [(&str, &str); 5] =
    [("server", "host"), ("server", "port"), ("server", "workers"), ("log", "level"), ("server", "timeout_ms")];

/// Parses the whole text and returns the config, or every error found.
pub fn parse(text: &str) -> Result<ServerConfig, Vec<ConfigError>> {
    let mut errors = Vec::new();
    let mut values: HashMap<String, (String, Span)> = HashMap::new();
    let mut section = String::new();
    for (i, raw) in text.lines().enumerate() {
        let line_no = i + 1;
        let indent = raw.len() - raw.trim_start().len();
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if let Some(name) = line.strip_prefix('[').and_then(|l| l.strip_suffix(']')) {
            section = name.trim().to_string();
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            errors.push(ConfigError::Syntax { at: Span { line: line_no, column: indent + 1 } });
            continue;
        };
        let (key, value) = (key.trim(), value.trim());
        let at = Span { line: line_no, column: indent + 1 };
        if !KNOWN.contains(&(section.as_str(), key)) {
            errors.push(ConfigError::UnknownKey { at, section: section.clone(), key: key.to_string() });
            continue;
        }
        let full = format!("{section}.{key}");
        if let Some((_, first)) = values.get(&full) {
            errors.push(ConfigError::Duplicate { at, key: full, first: first.line });
            continue;
        }
        values.insert(full, (value.to_string(), at));
    }

    // Typed extraction: each field reports its own error and parsing continues.
    let mut field = |key: &'static str| values.remove(key);
    let host = field("server.host");
    let port = field("server.port");
    let workers = field("server.workers");
    let level = field("log.level");
    let timeout = field("server.timeout_ms");

    let host = match host {
        Some((h, _)) => Some(h),
        None => { errors.push(ConfigError::Missing("server.host")); None }
    };
    let port = number::<u16>("server.port", port, 1..=u16::MAX as u64, &mut errors, true);
    let workers = number::<u32>("server.workers", workers, 1..=256, &mut errors, false).or(Some(4));
    let timeout_ms = number::<u64>("server.timeout_ms", timeout, 1..=600_000, &mut errors, false).or(Some(30_000));
    let log_level = match level {
        None => Some(LogLevel::Info),
        Some((v, at)) => match v.to_ascii_lowercase().as_str() {
            "error" => Some(LogLevel::Error),
            "warn" => Some(LogLevel::Warn),
            "info" => Some(LogLevel::Info),
            "debug" => Some(LogLevel::Debug),
            _ => {
                errors.push(ConfigError::Invalid { at, key: "log.level".into(), value: v, reason: "expected error, warn, info, or debug".into() });
                None
            }
        },
    };

    match (host, port, workers, log_level, timeout_ms) {
        (Some(host), Some(port), Some(workers), Some(log_level), Some(timeout_ms)) if errors.is_empty() => {
            Ok(ServerConfig { host, port, workers, log_level, timeout_ms })
        }
        _ => Err(errors),
    }
}

fn number<T: TryFrom<u64>>(
    key: &'static str,
    entry: Option<(String, Span)>,
    range: std::ops::RangeInclusive<u64>,
    errors: &mut Vec<ConfigError>,
    required: bool,
) -> Option<T> {
    let Some((value, at)) = entry else {
        if required {
            errors.push(ConfigError::Missing(key));
        }
        return None;
    };
    let invalid = |reason: String| ConfigError::Invalid { at: at.clone(), key: key.into(), value: value.clone(), reason };
    match value.parse::<u64>() {
        Err(e) => { errors.push(invalid(e.to_string())); None }
        Ok(n) if !range.contains(&n) => {
            errors.push(invalid(format!("must be in {}..={}", range.start(), range.end())));
            None
        }
        Ok(n) => T::try_from(n).ok(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn minimal_config_uses_defaults() {
        let c = parse("[server]\nhost = example.org\nport = 443\n").unwrap();
        assert_eq!((c.workers, c.timeout_ms, c.log_level), (4, 30_000, LogLevel::Info));
    }

    #[test]
    fn reports_every_error_with_positions() {
        let errs = parse("[server]\nport = 70000\n  colour = blue\nport = 1\nnonsense\n").unwrap_err();
        assert_eq!(errs.len(), 5, "{errs:#?}");
        assert!(matches!(&errs[0], ConfigError::UnknownKey { at: Span { line: 3, column: 3 }, .. }));
        assert!(matches!(&errs[1], ConfigError::Duplicate { first: 2, .. }));
        assert!(matches!(&errs[2], ConfigError::Syntax { at: Span { line: 5, .. } }));
        assert_eq!(errs[3], ConfigError::Missing("server.host"));
        assert!(matches!(&errs[4], ConfigError::Invalid { key, .. } if key == "server.port"));
    }
}
