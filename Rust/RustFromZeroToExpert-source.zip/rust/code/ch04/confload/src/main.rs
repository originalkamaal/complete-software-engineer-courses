// file: confload/src/main.rs
use anyhow::{Context, Result};
use std::process::ExitCode;

fn main() -> Result<ExitCode> {
    let path = std::env::args().nth(1).context("usage: confload FILE")?;
    let text = std::fs::read_to_string(&path).with_context(|| format!("reading {path}"))?;
    match confload::parse(&text) {
        Ok(config) => {
            println!("{config:#?}");
            Ok(ExitCode::SUCCESS)
        }
        Err(errors) => {
            eprintln!("{path}: {} error(s)", errors.len());
            for (i, e) in errors.iter().enumerate() {
                eprintln!("  {}. {path}:{e}", i + 1);
            }
            Ok(ExitCode::from(65))                       // EX_DATAERR from sysexits.h
        }
    }
}
