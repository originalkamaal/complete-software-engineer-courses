// file: anyerr/src/main.rs
use anyhow::{Context, Result, bail, ensure};
use thiserror::Error;

/// A library-style error: callers can match on the variants.
#[derive(Debug, Error)]
pub enum ParseError {
    #[error("line {line}: expected `key=value`")]
    Syntax { line: usize },
    #[error("line {line}: invalid number for `{key}`")]
    Number { line: usize, key: String, #[source] source: std::num::ParseIntError },
}

fn parse_limits(text: &str) -> Result<Vec<(String, u32)>, ParseError> {
    let mut out = Vec::new();
    for (i, line) in text.lines().enumerate().filter(|(_, l)| !l.trim().is_empty()) {
        let (k, v) = line.split_once('=').ok_or(ParseError::Syntax { line: i + 1 })?;
        let n = v.trim().parse().map_err(|source| ParseError::Number { line: i + 1, key: k.trim().into(), source })?;
        out.push((k.trim().to_string(), n));
    }
    Ok(out)
}

/// Application code: anyhow adds context at each level.
fn load(path: &str) -> Result<Vec<(String, u32)>> {
    let text = std::fs::read_to_string(path).with_context(|| format!("reading limits file {path}"))?;
    let limits = parse_limits(&text).with_context(|| format!("parsing {path}"))?;
    ensure!(!limits.is_empty(), "{path} defines no limits");
    if let Some((k, _)) = limits.iter().find(|(_, v)| *v == 0) {
        bail!("limit `{k}` in {path} must be positive");
    }
    Ok(limits)
}

fn main() {
    std::fs::write("ok.txt", "connections = 100\nrequests=5000\n").unwrap();
    std::fs::write("typo.txt", "connections = 100\nrequests 5000\n").unwrap();
    std::fs::write("bignum.txt", "connections = 99999999999\n").unwrap();
    std::fs::write("zero.txt", "connections = 0\n").unwrap();
    for path in ["ok.txt", "typo.txt", "bignum.txt", "zero.txt", "absent.txt"] {
        match load(path) {
            Ok(l) => println!("{path}: {l:?}"),
            Err(e) => println!("{path}: {e:#}"),            // {:#} prints the chain on one line
        }
    }
    let e = load("bignum.txt").unwrap_err();
    if let Some(ParseError::Number { line, key, .. }) = e.downcast_ref::<ParseError>() {
        println!("a caller can still match the typed error: line {line}, key {key}");
    }
}
