// file: errors.rs
use std::error::Error;
use std::fmt;
use std::num::ParseIntError;

#[derive(Debug)]
enum ConfigError {
    Io(std::io::Error),
    MissingKey(&'static str),
    BadNumber { key: String, source: ParseIntError },
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ConfigError::Io(_) => write!(f, "could not read the configuration"),
            ConfigError::MissingKey(k) => write!(f, "missing required key `{k}`"),
            ConfigError::BadNumber { key, .. } => write!(f, "value of `{key}` is not a valid number"),
        }
    }
}

impl Error for ConfigError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            ConfigError::Io(e) => Some(e),
            ConfigError::BadNumber { source, .. } => Some(source),
            ConfigError::MissingKey(_) => None,
        }
    }
}

impl From<std::io::Error> for ConfigError {
    fn from(e: std::io::Error) -> Self {
        ConfigError::Io(e)
    }
}

fn workers(path: &str) -> Result<u32, ConfigError> {
    let text = std::fs::read_to_string(path)?;          // io::Error -> ConfigError via From
    let line = text.lines().find(|l| l.starts_with("workers=")).ok_or(ConfigError::MissingKey("workers"))?;
    let value = &line["workers=".len()..];
    value.parse().map_err(|source| ConfigError::BadNumber { key: "workers".into(), source })
}

fn report(e: &dyn Error) {
    eprint!("error: {e}");
    let mut cause = e.source();
    while let Some(c) = cause {
        eprint!("\n  caused by: {c}");
        cause = c.source();
    }
    eprintln!();
}

fn main() {
    std::fs::write("good.conf", "name=demo\nworkers=8\n").unwrap();
    std::fs::write("bad.conf", "workers=eight\n").unwrap();
    std::fs::write("empty.conf", "name=demo\n").unwrap();
    for path in ["good.conf", "bad.conf", "empty.conf", "nope.conf"] {
        match workers(path) {
            Ok(n) => println!("{path}: {n} workers"),
            Err(e) => report(&e),
        }
    }
}
