// file: panic.rs
struct Guard(&'static str);
impl Drop for Guard {
    fn drop(&mut self) {
        println!("drop {}", self.0);
    }
}

fn average(values: &[i32]) -> i32 {
    let _g = Guard("inner");
    values.iter().sum::<i32>() / values.len() as i32       // divide by zero if empty
}

fn main() {
    let _outer = Guard("outer");
    println!("average of [2, 4] = {}", average(&[2, 4]));
    let result = std::panic::catch_unwind(|| average(&[]));
    println!("caught a panic: {}", result.is_err());
    let config: Option<&str> = None;
    let value = config.expect("config must be loaded before use");
    println!("{value}");
}
