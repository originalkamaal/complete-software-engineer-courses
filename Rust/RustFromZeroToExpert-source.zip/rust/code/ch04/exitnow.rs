// file: exitcode.rs
use std::io::{BufWriter, Write};
use std::process::ExitCode;

fn main() -> ExitCode {
    let mut out = BufWriter::new(std::io::stdout());
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("usage: exitcode NUMBER...");
        return ExitCode::from(2);
    }
    let mut bad = 0;
    for a in &args {
        match a.parse::<f64>() {
            Ok(x) => writeln!(out, "{a} squared is {}", x * x).unwrap(),
            Err(_) => { eprintln!("not a number: {a}"); bad += 1; }
        }
    }
    std::process::exit(if bad > 0 { 1 } else { 0 })
}
