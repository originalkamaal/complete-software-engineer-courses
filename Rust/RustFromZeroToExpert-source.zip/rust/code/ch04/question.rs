// file: question.rs
use std::fs;
use std::num::ParseIntError;

fn parse_pair(s: &str) -> Result<(i32, i32), ParseIntError> {
    let (a, b) = s.split_once(',').unwrap_or((s, "0"));
    let x = a.trim().parse::<i32>()?;                    // early return on error
    let y = b.trim().parse::<i32>()?;
    Ok((x, y))
}

fn first_even_square(v: &[i32]) -> Option<i32> {
    let first = v.iter().find(|&&x| x % 2 == 0)?;       // ? on Option: return None early
    first.checked_mul(*first)                            // None on overflow
}

fn read_number(path: &str) -> Result<i64, String> {
    let text = fs::read_to_string(path).map_err(|e| format!("cannot read {path}: {e}"))?;
    text.trim().parse::<i64>().map_err(|e| format!("{path}: {e}"))
}

fn main() {
    for input in ["3, 4", "10", "7,x", ""] {
        println!("{input:?} -> {:?}", parse_pair(input));
    }
    println!("{:?} {:?} {:?}", first_even_square(&[3, 5, 6]), first_even_square(&[1, 3]), first_even_square(&[65536]));
    std::fs::write("n.txt", "42\n").unwrap();
    println!("{:?}", read_number("n.txt"));
    println!("{:?}", read_number("missing.txt"));
    let port: u16 = std::env::var("PORT").ok().and_then(|s| s.parse().ok()).unwrap_or(8080);
    let doubled = parse_pair("5,6").map(|(a, b)| a * b).unwrap_or_default();
    println!("port {port}, product {doubled}");
}
