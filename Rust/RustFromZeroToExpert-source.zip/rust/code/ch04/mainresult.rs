// file: mainresult.rs
use std::process::ExitCode;

fn run(args: &[String]) -> Result<u32, String> {
    let n: u32 = args.get(1).ok_or("usage: mainresult NUMBER")?.parse().map_err(|e| format!("bad number: {e}"))?;
    if n > 100 {
        return Err(format!("{n} is too large"));
    }
    Ok(n * 2)
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().collect();
    match run(&args) {
        Ok(v) => {
            println!("{v}");
            ExitCode::SUCCESS
        }
        Err(msg) => {
            eprintln!("mainresult: {msg}");
            ExitCode::from(2)                    // conventional "usage error" status
        }
    }
}
