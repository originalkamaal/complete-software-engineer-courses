// file: errtype.rs
use std::{error::Error, fmt, num::ParseIntError};

#[derive(Debug)]
enum ConfigError {
    Missing(&'static str),
    BadNumber { key: &'static str, source: ParseIntError },
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            ConfigError::Missing(k) => write!(f, "missing key `{k}`"),
            ConfigError::BadNumber { key, .. } => write!(f, "`{key}` is not a valid number"),
        }
    }
}

impl Error for ConfigError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            ConfigError::BadNumber { source, .. } => Some(source),
            _ => None,
        }
    }
}

fn workers(text: Option<&str>) -> Result<u32, ConfigError> {
    let t = text.ok_or(ConfigError::Missing("workers"))?;
    t.parse().map_err(|e| ConfigError::BadNumber { key: "workers", source: e })
}

fn report(e: &dyn Error) {
    print!("error: {e}");
    let mut cause = e.source();
    while let Some(c) = cause { print!("\n  caused by: {c}"); cause = c.source(); }
    println!();
}

fn main() {
    for input in [Some("8"), None, Some("-3")] {
        match workers(input) { Ok(n) => println!("workers = {n}"), Err(e) => report(&e) }
    }
}
