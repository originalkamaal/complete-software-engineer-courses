// file: combinators.rs
use std::collections::HashMap;

fn port_from(env: &HashMap<&str, &str>) -> Result<u16, String> {
    env.get("PORT")
        .ok_or("PORT is not set")?                                   // Option -> Result
        .parse::<u16>()
        .map_err(|e| format!("PORT is not a number: {e}"))
}

fn main() {
    let mut env = HashMap::new();
    println!("{:?}", port_from(&env));
    env.insert("PORT", "80x");
    println!("{:?}", port_from(&env));
    env.insert("PORT", "8080");
    println!("{:?}", port_from(&env));

    let words = ["10", "x", "30"];
    let parsed: Vec<i32> = words.iter().filter_map(|w| w.parse().ok()).collect();            // skip failures
    let all: Result<Vec<i32>, _> = words.iter().map(|w| w.parse::<i32>()).collect();         // stop at the first
    println!("filter_map: {parsed:?}, collect into Result: {}", all.is_err());
    let doubled = Some(4).map(|x| x * 2).filter(|x| *x > 5).unwrap_or(0);
    println!("doubled: {doubled}, missing name: {}", None::<&str>.map_or("anonymous".len(), |s| s.len()));
}
