// file: catch.rs
use std::panic;

fn risky_job(n: u32) -> u32 {
    if n == 3 { panic!("job {n} hit a bug"); }
    n * 10
}

fn main() {
    panic::set_hook(Box::new(|info| eprintln!("[hook] {info}")));     // replaces the default message
    let mut results = vec![];
    for n in 1..=4 {
        match panic::catch_unwind(|| risky_job(n)) {
            Ok(v) => results.push(v),
            Err(payload) => {
                let msg = payload.downcast_ref::<String>().cloned().unwrap_or_default();
                println!("job {n} failed: {msg}");
            }
        }
    }
    println!("results: {results:?}");
}
