// file: senderr.rs
use std::error::Error;
use std::thread;

type BoxErr = Box<dyn Error + Send + Sync + 'static>;

fn parse(s: &str) -> Result<i32, BoxErr> { Ok(s.trim().parse()?) }

fn main() {
    let h = thread::spawn(|| parse(" 41 ").map(|n| n + 1));     // the Result travels back to main
    println!("{:?}", h.join().unwrap());
    let h = thread::spawn(|| parse("x"));
    println!("{}", h.join().unwrap().unwrap_err());
}
