// file: cycles.rs
use std::cell::RefCell;
use std::rc::{Rc, Weak};

struct Node {
    name: String,
    parent: RefCell<Weak<Node>>,                  // back-link: does not own
    children: RefCell<Vec<Rc<Node>>>,             // forward links: own
}

impl Drop for Node {
    fn drop(&mut self) {
        println!("drop {}", self.name);
    }
}

fn node(name: &str) -> Rc<Node> {
    Rc::new(Node { name: name.into(), parent: RefCell::new(Weak::new()), children: RefCell::new(vec![]) })
}

struct Leaky {
    name: &'static str,
    other: RefCell<Option<Rc<Leaky>>>,
}
impl Drop for Leaky {
    fn drop(&mut self) {
        println!("drop {}", self.name);
    }
}

fn main() {
    {
        let root = node("root");
        let leaf = node("leaf");
        *leaf.parent.borrow_mut() = Rc::downgrade(&root);
        root.children.borrow_mut().push(Rc::clone(&leaf));
        let parent_name = leaf.parent.borrow().upgrade().map(|p| p.name.clone());
        println!("leaf's parent: {parent_name:?}; root strong={} weak={}", Rc::strong_count(&root), Rc::weak_count(&root));
    }
    println!("-- tree scope ended (both dropped) --");
    {
        let a = Rc::new(Leaky { name: "a", other: RefCell::new(None) });
        let b = Rc::new(Leaky { name: "b", other: RefCell::new(Some(Rc::clone(&a))) });
        *a.other.borrow_mut() = Some(Rc::clone(&b));       // a -> b -> a: a cycle of strong references
        println!("a strong={} b strong={}", Rc::strong_count(&a), Rc::strong_count(&b));
    }
    println!("-- cycle scope ended (nothing dropped: leaked) --");
}
