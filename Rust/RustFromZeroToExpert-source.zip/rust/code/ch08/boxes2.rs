// file: boxes2.rs
#[derive(Debug)]
enum Expr {
    Num(f64),
    Add(Box<Expr>, Box<Expr>),
    Mul(Box<Expr>, Box<Expr>),
    Neg(Box<Expr>),
}
use Expr::*;

fn eval(e: &Expr) -> f64 {
    match e {
        Num(n) => *n,
        Add(a, b) => eval(a) + eval(b),
        Mul(a, b) => eval(a) * eval(b),
        Neg(a) => -eval(a),
    }
}

fn main() {
    let e = Add(Box::new(Num(2.0)), Box::new(Mul(Box::new(Num(3.0)), Box::new(Neg(Box::new(Num(4.0)))))));
    println!("2 + 3 * -4 = {}", eval(&e));
    println!("size_of::<Expr>() = {} bytes", std::mem::size_of::<Expr>());
    let v: Vec<u32> = (0..5).collect();
    let fixed: Box<[u32]> = v.into_boxed_slice();
    println!("Vec<u32>: {} bytes, Box<[u32]>: {} bytes, contents {fixed:?}",
             std::mem::size_of::<Vec<u32>>(), std::mem::size_of::<Box<[u32]>>());
}
