// file: deref_drop.rs
use std::ops::Deref;

struct Loud(&'static str);
impl Drop for Loud {
    fn drop(&mut self) {
        println!("drop {}", self.0);
    }
}

#[allow(dead_code)]                     // the fields exist only to be dropped
struct Pair {
    first: Loud,
    second: Loud,
}

/// A wrapper that behaves like the String inside it.
struct Name(String);
impl Deref for Name {
    type Target = String;
    fn deref(&self) -> &String {
        &self.0
    }
}

fn greet(s: &str) -> String {
    format!("hello, {s}")
}

fn main() {
    let n = Name("Ferris".to_string());
    println!("{} (len {})", greet(&n), n.len());       // &Name -> &String -> &str; len() found through Deref
    let boxed = Box::new(String::from("boxed"));
    println!("{}", greet(&boxed));                      // &Box<String> -> &String -> &str

    let _a = Loud("local a");
    let _b = Loud("local b");
    let _p = Pair { first: Loud("field first"), second: Loud("field second") };
    let _v = vec![Loud("vec[0]"), Loud("vec[1]")];
    println!("end of main");
}
