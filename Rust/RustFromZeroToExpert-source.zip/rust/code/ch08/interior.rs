// file: interior.rs
use std::cell::{Cell, OnceCell, RefCell};
use std::collections::HashMap;

struct Fib {
    calls: Cell<u64>,                                   // a counter changed through &self
    memo: RefCell<HashMap<u64, u64>>,                   // a cache changed through &self
}

impl Fib {
    fn get(&self, n: u64) -> u64 {                      // note: &self, not &mut self
        self.calls.set(self.calls.get() + 1);
        if n < 2 {
            return n;
        }
        if let Some(&v) = self.memo.borrow().get(&n) {  // shared borrow ends at the end of this statement
            return v;
        }
        let v = self.get(n - 1) + self.get(n - 2);      // recursion re-borrows the RefCell: fine
        self.memo.borrow_mut().insert(n, v);
        v
    }
}

fn main() {
    let f = Fib { calls: Cell::new(0), memo: RefCell::new(HashMap::new()) };
    println!("fib(90) = {} using {} calls", f.get(90), f.calls.get());

    let config: OnceCell<String> = OnceCell::new();
    let a = config.get_or_init(|| { println!("(initialising config)"); "debug=true".to_string() });
    let b = config.get_or_init(|| unreachable!());
    println!("{a} {b}");

    let shared = RefCell::new(vec![1, 2, 3]);
    let reader = shared.borrow();
    println!("try_borrow_mut while a reader exists: {:?}", shared.try_borrow_mut().map(|_| ()));
    drop(reader);
    shared.borrow_mut().push(4);
    let r = shared.borrow();
    let w = shared.borrow_mut();                        // panics: already borrowed
    println!("{r:?} {w:?}");
}
