// file: boxes.rs
#[derive(Debug)]
enum Expr {
    Num(f64),
    Add(Box<Expr>, Box<Expr>),        // without Box, Expr would contain itself: infinite size
    Mul(Box<Expr>, Box<Expr>),
    Neg(Box<Expr>),
}

use Expr::*;

fn eval(e: &Expr) -> f64 {
    match e {
        Num(n) => *n,
        Add(a, b) => eval(a) + eval(b),
        Mul(a, b) => eval(a) * eval(b),
        Neg(a) => -eval(a),
    }
}

fn main() {
    // (2 + 3) * -4
    let e = Mul(Box::new(Add(Box::new(Num(2.0)), Box::new(Num(3.0)))), Box::new(Neg(Box::new(Num(4.0)))));
    println!("{e:?} = {}", eval(&e));
    println!("size_of: Expr {}, Box<Expr> {}, Box<[u8; 1_000_000]> {}", size_of::<Expr>(), size_of::<Box<Expr>>(), size_of::<Box<[u8; 1_000_000]>>());
    let big = vec![0u8; 1_000_000].into_boxed_slice();     // a heap slice: pointer + length
    println!("boxed slice len {} in a {}-byte handle", big.len(), size_of_val(&big));
}
