// file: cow2.rs
use std::borrow::Cow;

fn escape_html(s: &str) -> Cow<'_, str> {
    if !s.contains(['<', '>', '&', '"']) {
        return Cow::Borrowed(s);                       // nothing to do: no allocation
    }
    let mut out = String::with_capacity(s.len() + 16);
    for c in s.chars() {
        match c {
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '&' => out.push_str("&amp;"),
            '"' => out.push_str("&quot;"),
            _ => out.push(c),
        }
    }
    Cow::Owned(out)
}

fn main() {
    for s in ["plain text", "a < b && c", r#"say "hi""#] {
        let e = escape_html(s);
        let kind = match e { Cow::Borrowed(_) => "borrowed", Cow::Owned(_) => "owned" };
        println!("{kind:8} {e}");
    }
    let mut c = escape_html("plain");
    c.to_mut().push_str("!");                           // to_mut clones a borrowed value once
    println!("{c} is now owned: {}", matches!(c, Cow::Owned(_)));
}
