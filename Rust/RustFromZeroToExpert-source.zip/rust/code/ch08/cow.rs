// file: cow.rs
use std::borrow::Cow;

fn escape_html(input: &str) -> Cow<'_, str> {
    if !input.contains(['<', '>', '&']) {
        return Cow::Borrowed(input);                 // common case: no allocation
    }
    let mut out = String::with_capacity(input.len() + 16);
    for c in input.chars() {
        match c {
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '&' => out.push_str("&amp;"),
            _ => out.push(c),
        }
    }
    Cow::Owned(out)
}

fn main() {
    for s in ["plain text", "a < b && c > d"] {
        let e = escape_html(s);
        let kind = match &e { Cow::Borrowed(_) => "borrowed", Cow::Owned(_) => "owned" };
        println!("{kind:>8}: {e}");
    }
}
