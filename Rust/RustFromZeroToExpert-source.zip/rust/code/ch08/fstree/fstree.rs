// file: fstree/fstree.rs
use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};
use std::time::Instant;

thread_local! {
    static LIVE: Cell<isize> = const { Cell::new(0) };     // live Rc nodes, to detect leaks
}

// ---------- Version 1: Rc / Weak / RefCell ----------
struct RcNode {
    name: String,
    size: u64,                                            // file size; 0 for directories
    parent: RefCell<Weak<RcNode>>,
    children: RefCell<Vec<Rc<RcNode>>>,
}

impl Drop for RcNode {
    fn drop(&mut self) {
        LIVE.with(|l| l.set(l.get() - 1));
    }
}

fn rc_add(parent: &Rc<RcNode>, name: &str, size: u64) -> Rc<RcNode> {
    LIVE.with(|l| l.set(l.get() + 1));
    let n = Rc::new(RcNode { name: name.into(), size, parent: RefCell::new(Rc::downgrade(parent)), children: RefCell::new(vec![]) });
    parent.children.borrow_mut().push(Rc::clone(&n));
    n
}

fn rc_path(n: &Rc<RcNode>) -> String {
    let mut parts = vec![n.name.clone()];
    let mut cur = n.parent.borrow().upgrade();
    while let Some(p) = cur {
        parts.push(p.name.clone());
        cur = p.parent.borrow().upgrade();
    }
    parts.reverse();
    parts.join("/")
}

fn rc_total(n: &RcNode) -> u64 {
    n.size + n.children.borrow().iter().map(|c| rc_total(c)).sum::<u64>()
}

// ---------- Version 2: arena + indices ----------
#[derive(Clone, Copy, PartialEq, Debug)]
struct NodeId(usize);

struct ArenaNode {
    name: String,
    size: u64,
    parent: Option<NodeId>,
    children: Vec<NodeId>,
}

#[derive(Default)]
struct Tree {
    nodes: Vec<ArenaNode>,
}

impl Tree {
    fn root(&mut self, name: &str) -> NodeId {
        self.nodes.push(ArenaNode { name: name.into(), size: 0, parent: None, children: vec![] });
        NodeId(self.nodes.len() - 1)
    }
    fn add(&mut self, parent: NodeId, name: &str, size: u64) -> NodeId {
        let id = NodeId(self.nodes.len());
        self.nodes.push(ArenaNode { name: name.into(), size, parent: Some(parent), children: vec![] });
        self.nodes[parent.0].children.push(id);
        id
    }
    fn path(&self, mut id: NodeId) -> String {
        let mut parts = vec![self.nodes[id.0].name.as_str()];
        while let Some(p) = self.nodes[id.0].parent {
            parts.push(&self.nodes[p.0].name);
            id = p;
        }
        parts.reverse();
        parts.join("/")
    }
    fn total(&self, id: NodeId) -> u64 {
        let n = &self.nodes[id.0];
        n.size + n.children.iter().map(|&c| self.total(c)).sum::<u64>()
    }
}

/// Deterministic pseudo-random tree shape shared by both versions.
fn shape(n: usize) -> Vec<(usize, u64)> {
    let mut x: u64 = 88172645463325252;
    let mut out = Vec::with_capacity(n);
    for i in 1..n {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        let parent = if i < 50 { (x as usize) % i } else { (x as usize) % (i / 10) };   // first 10% are directories
        let size = if i < n / 10 { 0 } else { x % 100_000 };
        out.push((parent, size));
    }
    out
}

fn main() {
    let n = 200_000;
    let plan = shape(n);

    let t = Instant::now();
    let (rc_paths, rc_sum, rc_deepest) = {
        LIVE.with(|l| l.set(l.get() + 1));
        let root = Rc::new(RcNode { name: "root".into(), size: 0, parent: RefCell::new(Weak::new()), children: RefCell::new(vec![]) });
        let mut all = vec![Rc::clone(&root)];
        for (i, &(p, size)) in plan.iter().enumerate() {
            let parent = Rc::clone(&all[p]);
            all.push(rc_add(&parent, &format!("n{}", i + 1), size));
        }
        let deepest = all.iter().max_by_key(|n| rc_path(n).len()).map(rc_path).unwrap();
        (all.iter().map(|n| rc_path(n).len()).sum::<usize>(), rc_total(&root), deepest)
    };                                                     // root and `all` dropped here
    let t_rc = t.elapsed();
    let leaked = LIVE.with(|l| l.get());

    let t = Instant::now();
    let mut tree = Tree::default();
    let root = tree.root("root");
    let mut ids = vec![root];
    for (i, &(p, size)) in plan.iter().enumerate() {
        ids.push(tree.add(ids[p], &format!("n{}", i + 1), size));
    }
    let arena_deepest = ids.iter().map(|&id| tree.path(id)).max_by_key(|p| p.len()).unwrap();
    let arena_paths: usize = ids.iter().map(|&id| tree.path(id).len()).sum();
    let arena_sum = tree.total(root);
    let t_arena = t.elapsed();

    println!("nodes {n}: total size {rc_sum} vs {arena_sum}, path chars {rc_paths} vs {arena_paths}");
    println!("deepest path: {rc_deepest}");
    println!("same results: {}", rc_sum == arena_sum && rc_paths == arena_paths && rc_deepest == arena_deepest);
    println!("Rc nodes still alive after the Rc tree was dropped: {leaked}");
    println!("time: Rc/Weak/RefCell {t_rc:.0?}, arena {t_arena:.0?}");
    println!("per-node handle size: Rc {} bytes + {} for counts, NodeId {} bytes", size_of::<Rc<RcNode>>(), 2 * size_of::<usize>(), size_of::<NodeId>());
}
