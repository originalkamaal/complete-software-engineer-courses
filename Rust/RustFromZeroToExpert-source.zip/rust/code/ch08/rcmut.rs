// file: rcmut.rs
use std::rc::Rc;

fn main() {
    let mut a = Rc::new(vec![1, 2, 3]);
    Rc::make_mut(&mut a).push(4);                       // unique: modified in place
    let b = Rc::clone(&a);
    println!("before: a {a:?}, b {b:?}, count {}", Rc::strong_count(&a));
    Rc::make_mut(&mut a).push(5);                       // shared: a gets its own copy first
    println!("after:  a {a:?}, b {b:?}, a count {}, b count {}", Rc::strong_count(&a), Rc::strong_count(&b));
    println!("same allocation: {}", Rc::ptr_eq(&a, &b));

    let c = Rc::clone(&b);
    let b = Rc::try_unwrap(b).unwrap_err();             // c still points to it: cannot unwrap
    drop(c);
    let owned: Vec<i32> = Rc::try_unwrap(b).unwrap();   // last owner now: get the Vec back
    println!("unwrapped {owned:?}");
}
