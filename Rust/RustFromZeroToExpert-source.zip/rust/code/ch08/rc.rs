// file: rc.rs
use std::rc::Rc;

#[derive(Debug)]
struct Texture {
    name: String,
    bytes: usize,
}

impl Drop for Texture {
    fn drop(&mut self) {
        println!("freeing texture {}", self.name);
    }
}

struct Sprite {
    texture: Rc<Texture>,                         // many sprites share one texture
    x: i32,
}

fn main() {
    let grass = Rc::new(Texture { name: "grass.png".into(), bytes: 4096 });
    println!("count after creation: {}", Rc::strong_count(&grass));
    let mut sprites: Vec<Sprite> = (0..3).map(|i| Sprite { texture: Rc::clone(&grass), x: i * 16 }).collect();
    println!("count with 3 sprites: {}", Rc::strong_count(&grass));
    drop(grass);                                  // the original handle; sprites still hold the texture
    println!("count after dropping the original: {}", Rc::strong_count(&sprites[0].texture));
    for s in &sprites {
        print!("{}@{} ", s.texture.name, s.x);
    }
    println!("({} bytes stored once)", sprites[0].texture.bytes);
    sprites.truncate(1);
    println!("count with 1 sprite: {}", Rc::strong_count(&sprites[0].texture));
    sprites.clear();                              // last owner gone: texture freed here
    println!("end of main");
}
