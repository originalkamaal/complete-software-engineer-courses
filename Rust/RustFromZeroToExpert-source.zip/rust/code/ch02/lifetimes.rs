// file: lifetimes.rs
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() >= y.len() { x } else { y }
}

fn first<'a>(x: &'a str, _y: &str) -> &'a str {    // result tied to x only
    x
}

struct Excerpt<'a> {                                // a struct that holds a borrow
    part: &'a str,
}

impl<'a> Excerpt<'a> {
    fn part(&self) -> &'a str {
        self.part
    }
}

fn main() {
    let long_lived = String::from("a fairly long string");
    let result;
    {
        let short_lived = String::from("xyz");
        result = first(&long_lived, &short_lived);   // fine: depends only on long_lived
        println!("longest inside: {}", longest(&long_lived, &short_lived));
    }
    println!("first: {result}");

    let novel = String::from("Call me Ishmael. Some years ago...");
    let sentence = novel.split('.').next().unwrap_or("");
    let e = Excerpt { part: sentence };
    println!("excerpt: {}", e.part());
    let s: &'static str = "string literals live for the whole program";
    println!("{s}");
}
