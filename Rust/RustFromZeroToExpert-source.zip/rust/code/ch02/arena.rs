// file: arena.rs
#[derive(Clone, Copy, Debug, PartialEq)]
struct NodeId(usize);

struct Graph { names: Vec<String>, edges: Vec<Vec<NodeId>> }

impl Graph {
    fn new() -> Self { Graph { names: vec![], edges: vec![] } }
    fn add(&mut self, name: &str) -> NodeId {
        self.names.push(name.to_string());
        self.edges.push(vec![]);
        NodeId(self.names.len() - 1)
    }
    fn link(&mut self, a: NodeId, b: NodeId) { self.edges[a.0].push(b); self.edges[b.0].push(a); }
    fn neighbours(&self, n: NodeId) -> impl Iterator<Item = &str> {
        self.edges[n.0].iter().map(|id| self.names[id.0].as_str())
    }
}

fn main() {
    let mut g = Graph::new();
    let (a, b, c) = (g.add("delhi"), g.add("mumbai"), g.add("pune"));
    g.link(a, b);
    g.link(b, c);
    g.link(c, a);                                      // a cycle: no problem with indices
    for n in [a, b, c] {
        println!("{}: {:?}", g.names[n.0], g.neighbours(n).collect::<Vec<_>>());
    }
}
