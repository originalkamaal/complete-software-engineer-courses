// file: lifetimes_bad.rs
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() >= y.len() { x } else { y }
}

fn main() {
    let long_lived = String::from("a fairly long string");
    let result;
    {
        let short_lived = String::from("xyz");
        result = longest(&long_lived, &short_lived);
    }
    println!("{result}");
}
