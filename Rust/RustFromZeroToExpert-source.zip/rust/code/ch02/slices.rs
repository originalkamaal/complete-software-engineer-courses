// file: slices.rs
fn first_word(s: &str) -> &str {
    match s.find(' ') {
        Some(i) => &s[..i],
        None => s,
    }
}

fn main() {
    let mut sentence = String::from("hello world");
    let word = first_word(&sentence);               // borrows `sentence`
    sentence.clear();                               // needs &mut sentence while `word` is alive
    println!("first word: {word}");
}
