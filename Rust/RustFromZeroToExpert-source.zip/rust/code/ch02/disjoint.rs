// file: disjoint.rs
fn main() {
    let mut v = vec![1, 2, 3, 4, 5, 6];
    // let (a, b) = (&mut v[0], &mut v[5]);      // error: cannot borrow v as mutable more than once
    let (left, right) = v.split_at_mut(3);
    std::mem::swap(&mut left[0], &mut right[2]);
    println!("after swap: {v:?}");

    if let Ok([a, b]) = v.get_disjoint_mut([1, 4]) {
        *a += 100;
        *b += 100;
    }
    println!("after get_disjoint_mut: {v:?}");

    for chunk in v.chunks_mut(2) { chunk.reverse(); }
    println!("pairs reversed: {v:?}");
    println!("same index twice: {:?}", v.get_disjoint_mut([2, 2]).is_err());
}
