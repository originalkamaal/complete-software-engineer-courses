// file: returnref.rs
fn owned(n: u32) -> String { format!("item-{n}") }                    // the caller gets ownership
fn constant(ok: bool) -> &'static str { if ok { "yes" } else { "no" } } // literals live forever
fn view(s: &str) -> &str { s.split(',').next().unwrap_or("") }        // borrows from the argument

fn main() {
    let a = owned(7);
    let b = constant(true);
    let input = String::from("first,second");
    let c = view(&input);
    println!("{a} {b} {c}");
}
