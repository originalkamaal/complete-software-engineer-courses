// file: clone.rs
fn main() {
    let s1 = String::from("hello");
    let s2 = s1.clone();                            // deep copy: a second heap buffer
    println!("{s1} {s2}, different buffers: {}", s1.as_ptr() != s2.as_ptr());
    let s3 = s1;                                    // move: s3 takes over s1's buffer
    println!("{s3}");
    // println!("{s1}");                            // error[E0382]: borrow of moved value
}
