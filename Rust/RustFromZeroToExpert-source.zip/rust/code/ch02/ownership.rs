// file: ownership.rs
struct Noisy(&'static str);

impl Drop for Noisy {
    fn drop(&mut self) {
        println!("  drop {}", self.0);
    }
}

fn take(n: Noisy) {
    println!("  take() owns {}", n.0);
}                                                   // n dropped here

fn make(name: &'static str) -> Noisy {
    Noisy(name)                                     // ownership returned to the caller
}

fn main() {
    println!("start");
    let a = Noisy("a");
    let b = a;                                      // move: `a` is now unusable
    take(b);                                        // move into the function
    println!("after take");
    let c = make("c");
    {
        let _d = Noisy("d");
        println!("inner scope ends");
    }                                               // d dropped here
    let e = Noisy("e");
    drop(e);                                        // drop early with std::mem::drop
    let x = 5;
    let y = x;                                      // i32 is Copy: both usable
    println!("x={x} y={y}, c is {}", c.0);
    println!("end of main");
}                                                   // c dropped here
