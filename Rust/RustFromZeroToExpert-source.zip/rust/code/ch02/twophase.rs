// file: twophase.rs
fn main() {
    let mut v = vec![1, 2, 3];
    v.push(v.len());                      // OK: &mut v is activated after v.len() runs
    println!("{v:?}");

    let r = &mut v;
    // r.push(v.len());                   // error: v is already mutably borrowed through r
    let n = r.len();
    r.push(n);                            // compute first, then mutate
    println!("{v:?}");
}
