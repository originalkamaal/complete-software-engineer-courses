// file: loopmove.rs
fn consume(s: String) -> usize {
    s.len()
}

fn main() {
    let s = String::from("data");
    let mut total = 0;
    for _ in 0..3 {
        total += consume(s);                        // moved in the first iteration
    }
    println!("{total}");
}
