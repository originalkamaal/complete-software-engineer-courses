fn bad() -> &str { let s = String::from("x"); &s }
fn main() { bad(); }
