// file: techniques.rs
struct Player {
    name: String,
    score: u32,
}

fn bump(score: &mut u32, by: u32) {
    *score += by;
}

fn main() {
    // 1. Disjoint fields can be borrowed separately
    let mut p = Player { name: String::from("Ada"), score: 10 };
    let name = &p.name;                             // shared borrow of one field...
    bump(&mut p.score, 5);                          // ...mutable borrow of another: fine
    println!("{name}: {}", p.score);

    // 2. Disjoint parts of a slice: split_at_mut
    let mut v = [1, 2, 3, 4, 5, 6];
    let (left, right) = v.split_at_mut(3);
    left[0] += right[0];                            // two &mut into one array, proven disjoint
    println!("{v:?}");

    // 3. Indices instead of references while mutating the collection
    let mut words = vec![String::from("a"), String::from("bb")];
    let longest = (0..words.len()).max_by_key(|&i| words[i].len()).unwrap();
    words.push(format!("{}!", words[longest]));     // no live borrow across the push
    println!("{words:?}");

    // 4. Compute first, then mutate (two-phase borrows allow v.push(v.len()))
    let mut nums = vec![1, 2];
    nums.push(nums.len());
    let total: usize = nums.iter().sum();
    nums.push(total);
    println!("{nums:?}");

    // 5. Swap or take values out without moving from a borrow
    let mut slot = Some(String::from("payload"));
    let taken = slot.take();                        // leaves None behind
    let mut a = String::from("left");
    let mut b = String::from("right");
    std::mem::swap(&mut a, &mut b);
    let old = std::mem::replace(&mut a, String::from("new"));
    println!("{taken:?} {slot:?} {a} {b} {old}");
}
