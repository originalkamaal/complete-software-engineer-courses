// file: concord/concord.rs
use std::collections::BTreeMap;

/// One occurrence of a word: borrows its text from the document.
struct Occurrence<'t> {
    line_no: usize,
    line: &'t str,
}

/// The index borrows from the document text, so it cannot outlive it.
struct Concordance<'t> {
    entries: BTreeMap<String, Vec<Occurrence<'t>>>,   // key: the lowercased word
    total_words: usize,
}

impl<'t> Concordance<'t> {
    fn build(text: &'t str) -> Concordance<'t> {
        let mut entries: BTreeMap<String, Vec<Occurrence<'t>>> = BTreeMap::new();
        let mut total_words = 0;
        for (i, line) in text.lines().enumerate() {
            for raw in line.split(|c: char| !c.is_alphanumeric() && c != '\'') {
                let word = raw.trim_matches('\'');
                if word.is_empty() {
                    continue;
                }
                total_words += 1;
                entries.entry(word.to_lowercase()).or_default().push(Occurrence { line_no: i + 1, line });
            }
        }
        Concordance { entries, total_words }
    }

    fn most_frequent(&self, n: usize) -> Vec<(&str, usize)> {
        let mut counts: Vec<(&str, usize)> = self.entries.iter().map(|(w, occ)| (w.as_str(), occ.len())).collect();
        counts.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(b.0)));     // by count, then alphabetically
        counts.truncate(n);
        counts
    }

    fn in_context(&self, word: &str) -> &[Occurrence<'t>] {
        self.entries.get(&word.to_lowercase()).map(Vec::as_slice).unwrap_or(&[])
    }
}

fn main() {
    let path = std::env::args().nth(1).expect("usage: concord FILE [WORD]");
    let text = std::fs::read_to_string(&path).expect("readable UTF-8 file");
    let index = Concordance::build(&text);
    println!("{} words, {} distinct", index.total_words, index.entries.len());
    for (word, count) in index.most_frequent(8) {
        println!("{count:>4}  {word}");
    }
    if let Some(word) = std::env::args().nth(2) {
        println!("--- {word} ---");
        for occ in index.in_context(&word) {
            println!("{:>4}: {}", occ.line_no, occ.line.trim());
        }
    }
}
