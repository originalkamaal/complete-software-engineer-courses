// file: concord/broken.rs
use std::collections::BTreeMap;

struct Index<'t> {
    lines: BTreeMap<usize, &'t str>,
}

fn load(path: &str) -> Index<'_> {
    let text = std::fs::read_to_string(path).unwrap();
    let lines = text.lines().enumerate().collect();
    Index { lines }                                 // borrows `text`, which is dropped here
}

fn main() {
    let index = load("ownership.txt");
    println!("{}", index.lines.len());
}
