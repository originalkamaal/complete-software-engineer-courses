// file: dangle_scope.rs
fn main() {
    let r;
    {
        let x = 5;
        r = &x;
    }                                               // x dropped here
    println!("{r}");
}
