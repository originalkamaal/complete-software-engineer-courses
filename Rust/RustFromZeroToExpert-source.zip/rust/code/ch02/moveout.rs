// file: moveout.rs
#[derive(Debug)]
struct User { name: String, email: String }

fn main() {
    let mut names = vec![String::from("ada"), String::from("alan"), String::from("grace")];
    // let first = names[0];                           // error: cannot move out of index of Vec<String>
    let first = std::mem::take(&mut names[0]);         // leaves an empty String behind
    let last = names.pop().unwrap();                   // removes it
    let mut slot = Some(String::from("token"));
    let tok = slot.take();                             // leaves None
    println!("{first} {last} {names:?} {tok:?} {slot:?}");

    for n in names.into_iter() { print!("owned {n}; "); }   // consumes the vector
    println!();

    let u = User { name: "ada".into(), email: "ada@example.org".into() };
    let name = u.name;                                 // partial move
    println!("moved name {name}, still usable field {}", u.email);
    // println!("{u:?}");                              // error: borrow of partially moved value
}
