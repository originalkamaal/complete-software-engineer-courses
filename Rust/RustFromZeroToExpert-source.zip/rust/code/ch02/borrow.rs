// file: borrow.rs
fn length(s: &String) -> usize {                    // borrows; does not own
    s.len()
}

fn shout(s: &mut String) {                          // borrows mutably
    s.make_ascii_uppercase();
    s.push('!');
}

fn main() {
    let mut s = String::from("hello");
    let r1 = &s;
    let r2 = &s;                                    // many shared borrows: fine
    println!("{r1} {r2} {}", length(&s));
    shout(&mut s);                                  // r1 and r2 are no longer used: fine
    println!("{s}");
}
