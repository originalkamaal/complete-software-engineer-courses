// file: conflict.rs
fn main() {
    let mut s = String::from("hello");
    let r1 = &s;
    let w = &mut s;
    w.push('!');
    println!("{r1}");                               // r1 still in use: conflict
}
