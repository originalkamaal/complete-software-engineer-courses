// file: elision.rs
struct Parser { text: String }

impl Parser {
    fn first_word(&self, _sep: &str) -> &str {       // rule 3: the output borrows from self, not from _sep
        self.text.split(' ').next().unwrap_or("")
    }
}

fn trim_both(s: &str) -> &str { s.trim() }             // rule 2: one input, so output borrows from s

fn pick<'a>(a: &'a str, _b: &str) -> &'a str { a }     // two inputs: we must say which one

fn main() {
    let p = Parser { text: String::from("hello world") };
    let word;
    {
        let sep = String::from(" ");
        word = p.first_word(&sep);                       // fine: word does not borrow from sep
    }
    println!("{word} [{}] {}", trim_both("  x  "), pick("a", "b"));
}
