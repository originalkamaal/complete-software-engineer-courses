// file: dangle_return.rs
fn longest_word(text: &str) -> &str {               // fine: the result borrows from `text`
    text.split_whitespace().max_by_key(|w| w.len()).unwrap_or("")
}

fn make_greeting() -> &String {                    // a reference to what?
    let s = String::from("hi");
    &s                                              // s is dropped when the function returns
}

fn main() {
    println!("{} {}", longest_word("borrow checker rules"), make_greeting());
}
