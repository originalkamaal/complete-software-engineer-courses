// file: invalidate.rs
fn main() {
    let mut v = vec![1, 2, 3];
    let first = &v[0];                              // a reference into v's buffer
    v.push(4);                                      // may reallocate the buffer
    println!("first = {first}");
}
