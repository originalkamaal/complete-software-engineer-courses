// file: par/examples/when.rs
use rayon::prelude::*;
use std::time::Instant;

fn time<F: FnOnce() -> u64>(label: &str, f: F) -> f64 {
    let t = Instant::now();
    let r = f();
    let ms = t.elapsed().as_secs_f64() * 1000.0;
    std::hint::black_box(r);
    let _ = label;
    ms
}

fn heavy(x: u64) -> u64 { (0..2000).fold(x, |a, i| a.wrapping_mul(6364136223846793005).wrapping_add(i)) }

fn main() {
    let small: Vec<u64> = (0..1000).collect();
    let big: Vec<u64> = (0..200_000).collect();
    let s_seq = time("small seq", || small.iter().sum());
    let s_par = time("small par", || small.par_iter().sum());
    let h_seq = time("heavy seq", || big.iter().map(|&x| heavy(x)).fold(0, u64::wrapping_add));
    let h_par = time("heavy par", || big.par_iter().map(|&x| heavy(x)).reduce(|| 0, u64::wrapping_add));
    println!("threads: {}", rayon::current_num_threads());
    println!("tiny sum: parallel {} than sequential", if s_par > s_seq { "slower" } else { "not slower" });
    println!("heavy work: parallel speed-up {:.1}x", h_seq / h_par);
}
