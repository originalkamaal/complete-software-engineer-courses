// file: par/src/main.rs
use rayon::prelude::*;
use std::time::Instant;

fn is_prime(n: u64) -> bool {
    n >= 2 && (2..).take_while(|d| d * d <= n).all(|d| n % d != 0)
}

fn main() {
    let limit = 3_000_000u64;
    let t = Instant::now();
    let seq = (0..limit).filter(|&n| is_prime(n)).count();
    let t_seq = t.elapsed();
    let t = Instant::now();
    let par = (0..limit).into_par_iter().filter(|&n| is_prime(n)).count();
    let t_par = t.elapsed();
    println!("primes below {limit}: {seq} sequential in {t_seq:.0?}, {par} parallel in {t_par:.0?} on {} threads ({:.2}x)",
             rayon::current_num_threads(), t_seq.as_secs_f64() / t_par.as_secs_f64());

    let mut v: Vec<u64> = (0..10_000_000).map(|i: u64| i.wrapping_mul(0x9E3779B97F4A7C15) >> 20).collect();
    let mut w = v.clone();
    let t = Instant::now();
    v.sort_unstable();
    let t_sort = t.elapsed();
    let t = Instant::now();
    w.par_sort_unstable();
    println!("sort 10M: {t_sort:.0?} sequential, {:.0?} parallel, equal: {}", t.elapsed(), v == w);
}
