// file: spinlock.rs
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicBool, Ordering::{Acquire, Relaxed, Release}};
use std::thread;

struct SpinLock<T> { locked: AtomicBool, value: UnsafeCell<T> }
unsafe impl<T: Send> Sync for SpinLock<T> {}               // we guarantee exclusive access ourselves

impl<T> SpinLock<T> {
    const fn new(v: T) -> Self { SpinLock { locked: AtomicBool::new(false), value: UnsafeCell::new(v) } }
    fn with<R>(&self, f: impl FnOnce(&mut T) -> R) -> R {
        while self.locked.compare_exchange_weak(false, true, Acquire, Relaxed).is_err() {
            std::hint::spin_loop();
        }
        let r = f(unsafe { &mut *self.value.get() });      // exclusive while locked is true
        self.locked.store(false, Release);
        r
    }
}

static COUNTER: SpinLock<u64> = SpinLock::new(0);

fn main() {
    thread::scope(|s| {
        for _ in 0..4 {
            s.spawn(|| for _ in 0..100_000 { COUNTER.with(|c| *c += 1) });
        }
    });
    println!("counter = {}", COUNTER.with(|c| *c));
}
