// file: bounded.rs
use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};

fn main() {
    let (tx, rx) = mpsc::sync_channel::<u32>(2);
    let start = Instant::now();
    let producer = thread::spawn(move || {
        for i in 0..6 {
            tx.send(i).unwrap();                     // blocks while 2 messages are waiting
        }
        start.elapsed()
    });
    for v in rx.iter() {
        thread::sleep(Duration::from_millis(50));    // a slow consumer
        print!("{v} ");
    }
    let produced_in = producer.join().unwrap();
    println!("\nproducer was held back: {}", produced_in >= Duration::from_millis(150));

    let (tx, rx) = mpsc::channel::<String>();
    drop(rx);                                        // receiver gone
    println!("send to a closed channel: {:?}", tx.send("x".into()).is_err());
}
