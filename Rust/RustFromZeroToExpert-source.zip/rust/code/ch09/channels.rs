// file: channels.rs
use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};

fn main() {
    let (tx, rx) = mpsc::channel::<(usize, u64)>();
    for id in 0..3 {
        let tx = tx.clone();                              // one sender per producer
        thread::spawn(move || {
            for i in 0..3u64 {
                tx.send((id, i * 10 + id as u64)).unwrap();
                thread::sleep(Duration::from_millis(5));
            }
        });                                               // this producer's sender dropped here
    }
    drop(tx);                                             // drop the original, or the loop never ends
    let mut got: Vec<(usize, u64)> = rx.iter().collect(); // ends when all senders are gone
    got.sort();
    println!("received {} messages: {got:?}", got.len());

    // bounded channel: the producer can be at most 2 items ahead of a slow consumer
    let (tx, rx) = mpsc::sync_channel::<u32>(2);
    let start = Instant::now();
    let producer = thread::spawn(move || {
        for i in 0..6 {
            tx.send(i).unwrap();
            println!("  sent {i} at {:>3} ms", start.elapsed().as_millis() / 10 * 10);
        }
    });
    for v in rx {
        thread::sleep(Duration::from_millis(50));         // slow consumer
        println!("  handled {v} at {:>3} ms", start.elapsed().as_millis() / 10 * 10);
    }
    producer.join().unwrap();
}
