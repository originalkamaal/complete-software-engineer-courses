// file: poison.rs
use std::sync::{Arc, Mutex};
use std::thread;

fn main() {
    let balance = Arc::new(Mutex::new(100));
    let b = Arc::clone(&balance);
    let r = thread::spawn(move || {
        let mut g = b.lock().unwrap();
        *g -= 30;
        panic!("crashed in the middle of a transfer");      // the +30 elsewhere never happens
    })
    .join();
    println!("worker panicked: {}", r.is_err());
    match balance.lock() {
        Ok(g) => println!("balance {}", *g),
        Err(poisoned) => {
            println!("mutex is poisoned");
            let g = poisoned.into_inner();                   // choose to look anyway
            println!("half-updated balance: {}", *g);
        }
    }
    balance.clear_poison();
    println!("after clear_poison: is_poisoned = {}", balance.is_poisoned());
}
