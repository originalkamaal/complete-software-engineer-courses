// file: atomics.rs
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::thread;
use std::time::Instant;

static mut PAYLOAD: [u64; 4] = [0; 4];                 // plain memory published by a flag
static READY: AtomicBool = AtomicBool::new(false);

fn main() {
    // 1. Relaxed counter: atomicity is all we need
    let hits = Arc::new(AtomicU64::new(0));
    let t = Instant::now();
    thread::scope(|s| {
        for _ in 0..4 {
            s.spawn(|| for _ in 0..1_000_000 { hits.fetch_add(1, Ordering::Relaxed); });
        }
    });
    println!("atomic counter: {} in {:.0?}", hits.load(Ordering::Relaxed), t.elapsed());

    // 2. Release/Acquire: publish data written non-atomically
    let writer = thread::spawn(|| {
        unsafe { *(&raw mut PAYLOAD) = [1, 2, 3, 4] };           // ordinary writes...
        READY.store(true, Ordering::Release);                    // ...published by the release store
    });
    let reader = thread::spawn(|| {
        while !READY.load(Ordering::Acquire) {                   // acquire pairs with the release
            std::hint::spin_loop();
        }
        unsafe { *(&raw const PAYLOAD) }                         // guaranteed to see [1, 2, 3, 4]
    });
    writer.join().unwrap();
    println!("reader saw {:?}", reader.join().unwrap());

    // 3. compare_exchange: a lock-free maximum
    let max = AtomicU64::new(0);
    thread::scope(|s| {
        for t in 0..4u64 {
            let max = &max;
            s.spawn(move || {
                for i in 0..1000u64 {
                    let v = (i * 7919 + t * 104_729) % 100_003;
                    let mut cur = max.load(Ordering::Relaxed);
                    while v > cur {
                        match max.compare_exchange_weak(cur, v, Ordering::Relaxed, Ordering::Relaxed) {
                            Ok(_) => break,
                            Err(actual) => cur = actual,              // someone else changed it: retry
                        }
                    }
                }
            });
        }
    });
    println!("max = {} (fetch_max would do this in one call)", max.load(Ordering::Relaxed));
}
