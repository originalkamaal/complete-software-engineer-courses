// file: shared.rs
use std::collections::VecDeque;
use std::sync::{Arc, Condvar, Mutex, RwLock};
use std::thread;

fn main() {
    // Arc<Mutex<T>>: four threads increment one counter
    let counter = Arc::new(Mutex::new(0u64));
    let handles: Vec<_> = (0..4)
        .map(|_| {
            let c = Arc::clone(&counter);
            thread::spawn(move || {
                for _ in 0..100_000 {
                    *c.lock().unwrap() += 1;               // guard dropped at end of statement
                }
            })
        })
        .collect();
    for h in handles {
        h.join().unwrap();
    }
    println!("counter = {} (Arc strong count now {})", *counter.lock().unwrap(), Arc::strong_count(&counter));

    // RwLock: many readers at once
    let config = Arc::new(RwLock::new(String::from("v1")));
    thread::scope(|s| {
        for i in 0..3 {
            let cfg = &config;
            s.spawn(move || println!("reader {i} sees {}", cfg.read().unwrap()));
        }
    });
    *config.write().unwrap() = "v2".into();
    println!("after write: {}", config.read().unwrap());

    // Mutex + Condvar: a blocking queue
    let queue = Arc::new((Mutex::new(VecDeque::new()), Condvar::new()));
    let q2 = Arc::clone(&queue);
    let consumer = thread::spawn(move || {
        let (lock, ready) = &*q2;
        let mut taken = Vec::new();
        while taken.len() < 5 {
            let mut q = ready.wait_while(lock.lock().unwrap(), |q: &mut VecDeque<i32>| q.is_empty()).unwrap();
            taken.extend(q.drain(..));
        }
        taken
    });
    for i in 1..=5 {
        let (lock, ready) = &*queue;
        lock.lock().unwrap().push_back(i * i);
        ready.notify_one();
    }
    println!("consumer took {:?}", consumer.join().unwrap());

    // poisoning
    let m = Arc::new(Mutex::new(vec![1, 2, 3]));
    let m2 = Arc::clone(&m);
    let _ = thread::spawn(move || {
        let mut v = m2.lock().unwrap();
        v.push(4);
        panic!("invariant broken halfway through an update");
    })
    .join();
    match m.lock() {
        Ok(v) => println!("not poisoned: {v:?}"),
        Err(poisoned) => println!("poisoned! data was left as {:?}", poisoned.into_inner()),
    }
}
