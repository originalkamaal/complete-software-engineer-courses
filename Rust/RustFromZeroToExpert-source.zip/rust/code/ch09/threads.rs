// file: threads.rs
use std::thread;
use std::time::Duration;

fn main() {
    let data = vec![1u64, 2, 3, 4, 5, 6, 7, 8];

    // spawn: data must be moved (or cloned) into the thread
    let owned = data.clone();
    let handle = thread::spawn(move || owned.iter().map(|x| x * x).sum::<u64>());
    println!("sum of squares from a spawned thread: {}", handle.join().unwrap());

    // scoped threads may borrow `data`: the scope joins them before returning
    let (left, right) = data.split_at(data.len() / 2);
    let (a, b) = thread::scope(|s| {
        let h1 = s.spawn(|| left.iter().sum::<u64>());
        let h2 = s.spawn(|| right.iter().sum::<u64>());
        (h1.join().unwrap(), h2.join().unwrap())
    });
    println!("halves {a} + {b} = {}", a + b);

    // a panicking thread does not take down the process; join reports it
    let bad = thread::spawn(|| {
        thread::sleep(Duration::from_millis(10));
        let v: Vec<i32> = Vec::new();
        v[0]
    });
    match bad.join() {
        Ok(v) => println!("got {v}"),
        Err(e) => println!("thread panicked: {:?}", e.downcast_ref::<String>()),
    }
    println!("available parallelism: {}", thread::available_parallelism().unwrap());
}
