// file: notsend.rs
use std::rc::Rc;
use std::thread;

fn main() {
    let counter = Rc::new(5);
    let c = Rc::clone(&counter);
    let h = thread::spawn(move || println!("{c}"));
    h.join().unwrap();
}
