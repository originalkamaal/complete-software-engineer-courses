// file: scoped.rs
use std::thread;

fn main() {
    let data: Vec<u64> = (1..=1_000_000).collect();
    let mut partials = [0u64; 4];
    thread::scope(|s| {
        for (chunk, slot) in data.chunks(data.len() / 4).zip(partials.iter_mut()) {
            s.spawn(move || *slot = chunk.iter().sum());        // borrows data and one slot
        }
    });                                                         // all threads joined here
    println!("partials {partials:?}, total {}", partials.iter().sum::<u64>());

    let mut words = vec!["b", "a"];
    thread::scope(|s| {
        s.spawn(|| words.sort());                               // a mutable borrow, safely
    });
    println!("{words:?}");
}
