// file: wc5/gen.rs
fn main() {
    let mut x: u64 = 0x9E3779B97F4A7C15;
    let mut next = move || { x ^= x << 13; x ^= x >> 7; x ^= x << 17; x };
    let vocab: Vec<String> = (0..30_000)
        .map(|_| (0..2 + next() % 8).map(|_| (b'a' + (next() % 26) as u8) as char).collect())
        .collect();
    let harmonic: f64 = (1..=vocab.len()).map(|k| 1.0 / k as f64).sum();
    let mut out = String::new();
    while out.len() < 40_000_000 {
        let mut u = (next() % 1_000_000_000) as f64 / 1e9 * harmonic;   // inverse-CDF sampling of Zipf
        let mut k = 0;
        while k + 1 < vocab.len() && u > 1.0 / (k + 1) as f64 {
            u -= 1.0 / (k + 1) as f64;
            k += 1;
        }
        out.push_str(&vocab[k]);
        out.push(if next() % 12 == 0 { '\n' } else { ' ' });
    }
    print!("{out}");
}
