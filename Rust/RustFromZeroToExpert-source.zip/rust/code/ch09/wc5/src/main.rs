// file: wc5/src/main.rs
use rayon::prelude::*;
use std::collections::HashMap;
use std::sync::{Arc, Mutex, mpsc};
use std::thread;
use std::time::Instant;

type Counts = HashMap<String, u64>;

fn words(text: &str) -> impl Iterator<Item = &str> {
    text.split(|c: char| !c.is_ascii_alphabetic()).filter(|w| !w.is_empty())
}

fn count_into(map: &mut Counts, text: &str) {
    for w in words(text) {
        match map.get_mut(w) {                                    // avoid allocating a key for known words
            Some(n) => *n += 1,
            None => { map.insert(w.to_ascii_lowercase(), 1); }
        }
    }
}

/// Splits text into `n` chunks at whitespace, so no word is cut in two.
fn chunks(text: &str, n: usize) -> Vec<&str> {
    let mut out = Vec::new();
    let mut start = 0;
    for i in 1..=n {
        let mut end = if i == n { text.len() } else { (text.len() * i / n).max(start) };
        while end < text.len() && !text.as_bytes()[end].is_ascii_whitespace() {
            end += 1;
        }
        out.push(&text[start..end]);
        start = end;
    }
    out
}

fn merge(mut a: Counts, b: Counts) -> Counts {
    for (w, n) in b {
        *a.entry(w).or_insert(0) += n;
    }
    a
}

fn sequential(text: &str) -> Counts {
    let mut m = Counts::new();
    count_into(&mut m, text);
    m
}

fn shared_mutex(text: &str, threads: usize) -> Counts {
    let map = Arc::new(Mutex::new(Counts::new()));
    thread::scope(|s| {
        for chunk in chunks(text, threads) {
            let map = Arc::clone(&map);
            s.spawn(move || {
                for w in words(chunk) {
                    let mut m = map.lock().unwrap();             // one lock per word
                    match m.get_mut(w) {
                        Some(n) => *n += 1,
                        None => { m.insert(w.to_ascii_lowercase(), 1); }
                    }
                }
            });
        }
    });
    Arc::into_inner(map).unwrap().into_inner().unwrap()
}

fn per_thread_merge(text: &str, threads: usize) -> Counts {
    thread::scope(|s| {
        let handles: Vec<_> = chunks(text, threads).into_iter().map(|c| s.spawn(move || sequential(c))).collect();
        handles.into_iter().map(|h| h.join().unwrap()).fold(Counts::new(), merge)
    })
}

fn channel_pipeline(text: &str, threads: usize) -> Counts {
    let (tx, rx) = mpsc::sync_channel::<Counts>(threads);
    thread::scope(|s| {
        for chunk in chunks(text, threads * 8) {              // more, smaller jobs
            let tx = tx.clone();
            s.spawn(move || tx.send(sequential(chunk)).unwrap());
        }
        drop(tx);
        rx.iter().fold(Counts::new(), merge)                   // the merging thread runs concurrently
    })
}

fn rayon_fold(text: &str) -> Counts {
    chunks(text, rayon::current_num_threads() * 8)
        .into_par_iter()
        .map(sequential)
        .reduce(Counts::new, merge)
}

fn main() {
    let path = std::env::args().nth(1).expect("usage: wc5 FILE");
    let raw = std::fs::read_to_string(&path).expect("text file");
    let text = raw.to_ascii_lowercase();                       // normalise once, up front
    let threads = thread::available_parallelism().unwrap().get();
    println!("{:.1} MB, {threads} threads", text.len() as f64 / 1e6);

    let mut results: Vec<(&str, Counts)> = Vec::new();
    let mut base = 0.0;
    let runs: Vec<(&str, Box<dyn Fn(&str) -> Counts>)> = vec![
        ("sequential", Box::new(sequential)),
        ("shared Mutex<HashMap>", Box::new(move |t| shared_mutex(t, threads))),
        ("per-thread maps + merge", Box::new(move |t| per_thread_merge(t, threads))),
        ("channel pipeline", Box::new(move |t| channel_pipeline(t, threads))),
        ("rayon map/reduce", Box::new(rayon_fold)),
    ];
    for (name, f) in runs {
        let t = Instant::now();
        let counts = f(&text);
        let ms = t.elapsed().as_secs_f64() * 1e3;
        if base == 0.0 { base = ms; }
        println!("{name:<25} {ms:>7.0} ms  {:>5.2}x", base / ms);
        results.push((name, counts));
    }
    let same = results.iter().all(|(_, c)| *c == results[0].1);
    let total: u64 = results[0].1.values().sum();
    let mut top: Vec<_> = results[0].1.iter().collect();
    top.sort_by(|a, b| b.1.cmp(a.1).then(a.0.cmp(b.0)));
    println!("all five agree: {same}; {total} words, {} distinct; top: {:?}", results[0].1.len(), &top[..3]);
}
