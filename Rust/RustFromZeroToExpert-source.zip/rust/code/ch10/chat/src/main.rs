// file: chat/src/main.rs
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{Duration, Instant};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::broadcast;

#[derive(Clone, Debug)]
struct Msg {
    from: usize,                                    // connection id, so senders skip their own messages
    text: Arc<str>,                                 // shared, not copied, across all receivers
}

async fn serve(addr: &str) -> std::io::Result<()> {
    let listener = TcpListener::bind(addr).await?;
    let (tx, _) = broadcast::channel::<Msg>(4096);
    let online = Arc::new(AtomicUsize::new(0));
    eprintln!("chat server on {addr}");
    for id in 0usize.. {
        let (stream, _) = listener.accept().await?;
        let (tx, mut rx, online) = (tx.clone(), tx.subscribe(), Arc::clone(&online));
        tokio::spawn(async move {
            let (r, mut w) = stream.into_split();
            let mut lines = BufReader::new(r).lines();
            let name = match lines.next_line().await {          // first line: the user's name
                Ok(Some(n)) if !n.trim().is_empty() => n.trim().to_string(),
                _ => return,
            };
            let n = online.fetch_add(1, Ordering::SeqCst) + 1;
            let _ = w.write_all(format!("* welcome {name}, {n} online\n").as_bytes()).await;
            loop {
                tokio::select! {
                    line = lines.next_line() => match line {          // next_line is cancel-safe
                        Ok(Some(text)) => { let _ = tx.send(Msg { from: id, text: format!("{name}: {text}").into() }); }
                        _ => break,                                   // disconnect or error
                    },
                    msg = rx.recv() => match msg {
                        Ok(m) if m.from != id => {
                            if w.write_all(m.text.as_bytes()).await.is_err() || w.write_all(b"\n").await.is_err() { break; }
                        }
                        Ok(_) => {}
                        Err(broadcast::error::RecvError::Lagged(k)) => {
                            let _ = w.write_all(format!("* you missed {k} messages\n").as_bytes()).await;
                        }
                        Err(broadcast::error::RecvError::Closed) => break,
                    },
                }
            }
            online.fetch_sub(1, Ordering::SeqCst);
        });
    }
    Ok(())
}

/// Opens `clients` connections; each sends `per_client` messages; checks everyone receives everyone else's.
async fn load_test(addr: &str, clients: usize, per_client: usize) {
    let start = Instant::now();
    let mut conns = Vec::new();
    for c in 0..clients {
        let stream = TcpStream::connect(addr).await.expect("connect");
        stream.set_nodelay(true).unwrap();
        let (r, mut w) = stream.into_split();
        w.write_all(format!("user{c}\n").as_bytes()).await.unwrap();
        let mut lines = BufReader::new(r).lines();
        lines.next_line().await.unwrap();                         // the welcome line
        conns.push((lines, w));
    }
    let connected = start.elapsed();
    let expected = (clients - 1) * per_client;                    // messages each client should receive
    let start = Instant::now();
    let mut tasks = Vec::new();
    for (c, (mut lines, mut w)) in conns.into_iter().enumerate() {
        tasks.push(tokio::spawn(async move {
            let reader = tokio::spawn(async move {
                let mut got = 0;
                while got < expected {
                    match tokio::time::timeout(Duration::from_secs(10), lines.next_line()).await {
                        Ok(Ok(Some(l))) if !l.starts_with('*') => got += 1,
                        Ok(Ok(Some(_))) => {}
                        _ => break,
                    }
                }
                got
            });
            for i in 0..per_client {
                w.write_all(format!("message {i} from {c}\n").as_bytes()).await.unwrap();
                tokio::time::sleep(Duration::from_millis(2)).await;    // a human-ish pace, so the
            }                                                          // 4096-message buffer is not overrun
            let got = reader.await.unwrap();
            drop(w);
            got
        }));
    }
    let mut received = 0;
    let mut complete = 0;
    for t in tasks {
        let got = t.await.unwrap();
        received += got;
        complete += usize::from(got == expected);
    }
    let elapsed = start.elapsed();
    println!("{clients} clients connected in {connected:.0?}; {} messages sent, {received} deliveries in {elapsed:.0?} ({:.0} deliveries/s)",
             clients * per_client, received as f64 / elapsed.as_secs_f64());
    println!("clients that received all {expected} messages from the others: {complete}/{clients}");
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("serve") => serve("127.0.0.1:7979").await.unwrap(),
        Some("load") => {
            let clients = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(100);
            let per = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(10);
            load_test("127.0.0.1:7979", clients, per).await;
        }
        _ => eprintln!("usage: chat serve | chat load CLIENTS MESSAGES"),
    }
}
