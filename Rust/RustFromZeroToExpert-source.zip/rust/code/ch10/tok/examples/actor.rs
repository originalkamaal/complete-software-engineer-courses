// file: tok/examples/actor.rs
use std::collections::HashMap;
use tokio::sync::{mpsc, oneshot};

enum Command {
    Incr { key: String, by: i64 },
    Get { key: String, reply: oneshot::Sender<Option<i64>> },
}

/// The actor owns the map; nobody else can touch it.
async fn store(mut rx: mpsc::Receiver<Command>) {
    let mut map: HashMap<String, i64> = HashMap::new();
    while let Some(cmd) = rx.recv().await {
        match cmd {
            Command::Incr { key, by } => *map.entry(key).or_default() += by,
            Command::Get { key, reply } => { let _ = reply.send(map.get(&key).copied()); }
        }
    }
}

#[tokio::main]
async fn main() {
    let (tx, rx) = mpsc::channel(64);
    tokio::spawn(store(rx));
    let mut workers = Vec::new();
    for w in 0..8 {
        let tx = tx.clone();
        workers.push(tokio::spawn(async move {
            for i in 0..1000 {
                tx.send(Command::Incr { key: format!("k{}", i % 3), by: w }).await.unwrap();
            }
        }));
    }
    for w in workers {
        w.await.unwrap();
    }
    for key in ["k0", "k1", "k2", "missing"] {
        let (reply, answer) = oneshot::channel();
        tx.send(Command::Get { key: key.into(), reply }).await.unwrap();
        println!("{key} = {:?}", answer.await.unwrap());
    }
}
