// file: tok/examples/blocking.rs
use std::time::{Duration, Instant};

async fn ticker(start: Instant) {
    for _ in 0..4 {
        tokio::time::sleep(Duration::from_millis(100)).await;
        println!("  tick at {:>3} ms", start.elapsed().as_millis() / 10 * 10);
    }
}

#[tokio::main(flavor = "current_thread")]                 // one worker thread makes the effect obvious
async fn main() {
    let start = Instant::now();
    println!("with std::thread::sleep(350 ms) in another task:");
    let t = tokio::spawn(ticker(start));
    tokio::spawn(async { std::thread::sleep(Duration::from_millis(350)); });   // blocks the only thread
    t.await.unwrap();

    let start = Instant::now();
    println!("with spawn_blocking:");
    let t = tokio::spawn(ticker(start));
    tokio::task::spawn_blocking(|| std::thread::sleep(Duration::from_millis(350)));
    t.await.unwrap();
}
