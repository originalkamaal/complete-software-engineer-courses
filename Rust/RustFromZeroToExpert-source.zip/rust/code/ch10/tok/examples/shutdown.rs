// file: tok/examples/shutdown.rs
use std::time::Duration;
use tokio::sync::watch;
use tokio::task::JoinSet;

async fn worker(id: u32, mut stop: watch::Receiver<bool>) -> u32 {
    let mut jobs = 0;
    loop {
        tokio::select! {
            _ = tokio::time::sleep(Duration::from_millis(20)) => jobs += 1,   // "process a job"
            _ = stop.changed() => break,                                      // shutdown requested
        }
    }
    println!("worker {id} finishing after {} jobs", if jobs > 0 { "some" } else { "no" });
    jobs
}

#[tokio::main]
async fn main() {
    let (tx, rx) = watch::channel(false);
    let mut set = JoinSet::new();
    for id in 0..3 { set.spawn(worker(id, rx.clone())); }

    tokio::select! {
        _ = tokio::signal::ctrl_c() => println!("Ctrl-C received"),
        _ = tokio::time::sleep(Duration::from_millis(200)) => println!("demo: shutting down after 200 ms"),
    }
    tx.send(true).unwrap();
    let mut done = 0;
    while let Some(r) = set.join_next().await { r.unwrap(); done += 1; }
    println!("{done} workers stopped cleanly");
}
