// file: tok/examples/concurrency.rs
use std::time::Duration;
use tokio::task::JoinSet;
use tokio::time::{sleep, timeout, Instant};

async fn fetch(id: u32, ms: u64) -> String {
    sleep(Duration::from_millis(ms)).await;          // stands in for a network call
    format!("response {id}")
}

#[tokio::main]
async fn main() {
    let t = Instant::now();
    let (a, b) = tokio::join!(fetch(1, 100), fetch(2, 100));
    println!("{a}, {b}: concurrent ({} ms, not 200)", t.elapsed().as_millis() / 100 * 100);

    let mut set = JoinSet::new();
    for (id, ms) in [(1, 300), (2, 100), (3, 200)] {
        set.spawn(fetch(id, ms));
    }
    let mut order = vec![];
    while let Some(res) = set.join_next().await {
        order.push(res.unwrap());
    }
    println!("completion order: {order:?}");

    match timeout(Duration::from_millis(50), fetch(9, 1000)).await {
        Ok(r) => println!("{r}"),
        Err(_) => println!("fetch 9 timed out after 50 ms"),
    }
}
