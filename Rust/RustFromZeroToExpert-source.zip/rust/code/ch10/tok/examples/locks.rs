// file: tok/examples/locks.rs
use std::sync::{Arc, Mutex};
use std::time::Duration;

#[tokio::main]
async fn main() {
    let hits = Arc::new(Mutex::new(0u64));                 // std Mutex: never held across .await
    let mut tasks = vec![];
    for _ in 0..100 {
        let hits = Arc::clone(&hits);
        tasks.push(tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(1)).await;
            *hits.lock().unwrap() += 1;                     // lock, update, unlock: no await inside
        }));
    }
    for t in tasks { t.await.unwrap(); }
    println!("hits = {}", *hits.lock().unwrap());

    let conn = Arc::new(tokio::sync::Mutex::new(Vec::<String>::new()));   // held across an await
    let c = Arc::clone(&conn);
    tokio::spawn(async move {
        let mut log = c.lock().await;
        tokio::time::sleep(Duration::from_millis(10)).await;              // fine with tokio's Mutex
        log.push("written while holding the lock".into());
    })
    .await
    .unwrap();
    println!("{:?}", conn.lock().await);
}
