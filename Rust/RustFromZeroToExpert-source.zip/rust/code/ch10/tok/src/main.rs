// file: tok/src/main.rs
use std::time::{Duration, Instant};
use tokio::time::{sleep, timeout};

async fn fetch(name: &str, ms: u64) -> String {
    sleep(Duration::from_millis(ms)).await;                // a stand-in for network I/O
    format!("{name}({ms}ms)")
}

#[tokio::main]
async fn main() {
    let t = Instant::now();
    let a = fetch("a", 100).await;                          // sequential: one after another
    let b = fetch("b", 100).await;
    println!("sequential: {a} {b} in {} ms", t.elapsed().as_millis() / 10 * 10);

    let t = Instant::now();
    let (a, b, c) = tokio::join!(fetch("a", 100), fetch("b", 100), fetch("c", 150));   // concurrent
    println!("join!: {a} {b} {c} in {} ms", t.elapsed().as_millis() / 10 * 10);

    let t = Instant::now();
    let handles: Vec<_> = (0..10_000).map(|i| tokio::spawn(async move { sleep(Duration::from_millis(200)).await; i })).collect();
    let mut sum = 0u64;
    for h in handles {
        sum += h.await.unwrap();
    }
    println!("10,000 spawned tasks each sleeping 200 ms: sum {sum} in {} ms", t.elapsed().as_millis() / 10 * 10);

    tokio::select! {
        r = fetch("fast", 50) => println!("select!: {r} won"),
        r = fetch("slow", 500) => println!("select!: {r} won"),
    }
    match timeout(Duration::from_millis(80), fetch("too slow", 300)).await {
        Ok(v) => println!("got {v}"),
        Err(_) => println!("timeout: gave up after 80 ms"),
    }
}
