// file: echo/src/main.rs
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};

async fn handle(stream: TcpStream, id: usize) -> std::io::Result<()> {
    let (reader, mut writer) = stream.into_split();
    let mut lines = BufReader::new(reader).lines();
    while let Some(line) = lines.next_line().await? {
        writer.write_all(format!("[{id}] {}\n", line.to_uppercase()).as_bytes()).await?;
    }
    Ok(())                                                 // client closed the connection
}

#[tokio::main]
async fn main() -> std::io::Result<()> {
    let listener = TcpListener::bind("127.0.0.1:7878").await?;
    eprintln!("listening on {}", listener.local_addr()?);
    for id in 1.. {
        let (stream, _peer) = listener.accept().await?;
        tokio::spawn(async move {
            if let Err(e) = handle(stream, id).await {
                eprintln!("connection {id}: {e}");
            }
        });
    }
    Ok(())
}
