// file: mini_executor.rs
use std::future::Future;
use std::pin::{Pin, pin};
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll, Wake, Waker};
use std::thread;
use std::time::{Duration, Instant};

/// A future that completes after a delay, using a helper thread to call wake().
struct Delay {
    when: Instant,
    started: bool,
    name: &'static str,
}

impl Future for Delay {
    type Output = &'static str;
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<&'static str> {
        println!("  poll({}) at {:>3} ms", self.name, ms_since_start());
        if Instant::now() >= self.when {
            return Poll::Ready(self.name);
        }
        if !self.started {
            self.started = true;
            let waker = cx.waker().clone();
            let when = self.when;
            thread::spawn(move || {
                thread::sleep(when.saturating_duration_since(Instant::now()));
                waker.wake();                                  // "poll me again"
            });
        }
        Poll::Pending
    }
}

/// The executor's waker unparks the executor thread.
struct ThreadWaker(thread::Thread);
impl Wake for ThreadWaker {
    fn wake(self: Arc<Self>) {
        self.0.unpark();
    }
}

/// Runs one future to completion on the current thread.
fn block_on<F: Future>(fut: F) -> F::Output {
    let mut fut = pin!(fut);
    let waker = Waker::from(Arc::new(ThreadWaker(thread::current())));
    let mut cx = Context::from_waker(&waker);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => thread::park(),                   // sleep until woken
        }
    }
}

static START: Mutex<Option<Instant>> = Mutex::new(None);
fn ms_since_start() -> u128 {
    START.lock().unwrap().unwrap().elapsed().as_millis() / 10 * 10
}

async fn two_steps() -> String {
    let a = Delay { when: Instant::now() + Duration::from_millis(100), started: false, name: "first" }.await;
    let b = Delay { when: Instant::now() + Duration::from_millis(50), started: false, name: "second" }.await;
    format!("{a} then {b}")
}

fn main() {
    *START.lock().unwrap() = Some(Instant::now());
    let fut = two_steps();                                     // nothing runs yet
    println!("future created; size of its state machine: {} bytes", size_of_val(&fut));
    let result = block_on(fut);
    println!("result: {result} at {} ms", ms_since_start());
}
