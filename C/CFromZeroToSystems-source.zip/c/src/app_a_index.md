# Appendix A — Index of Deep & Tricky entries and Patterns

Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, with the unit where it is explained. Use it for revision: read each title and explain the entry before looking it up.

## Deep & Tricky

| # | Entry | Where |
| --- | --- | --- |
| DT-1 | "It worked when I ran it" proves nothing in C. | Unit 0.1 |
| DT-2 | The standard describes C; your compiler implements C plus extensions. | Unit 0.1 |
| DT-3 | The compiler sees one file at a time. | Unit 0.3 |
| DT-4 | `gcc` is a driver, not a compiler. | Unit 0.3 |
| DT-5 | Mismatched declarations across files are invisible to both compiler and linker. | Unit 0.4 |
| DT-6 | A leading zero makes an integer literal octal. | Unit 0.5 |
| DT-7 | Signed integer overflow is undefined; unsigned overflow wraps. | Unit 0.5 |
| DT-8 | Converting an out-of-range value to a signed type was implementation-defined until C23. | Unit 0.5 |
| DT-9 | Returning the address of a local variable creates a dangling pointer. | Unit 0.6 |
| DT-10 | Uninitialised automatic variables do not contain zero. | Unit 0.6 |
| DT-11 | A character constant has type `int` in C (but `char` in C++). | Unit 1.1 |
| DT-12 | `const` objects are not constant expressions (before C23). | Unit 1.1 |
| DT-13 | `unsigned short` × `unsigned short` can be signed overflow. | Unit 1.3 |
| DT-14 | The type of an expression decides overflow, not the variable it is stored in. | Unit 1.3 |
| DT-15 | `x == x` is false for NaN, so NaN breaks sorting and searching. | Unit 1.4 |
| DT-16 | `-ffast-math` makes the compiler assume no NaNs or infinities. | Unit 1.4 |
| DT-17 | Converting a floating-point value to an integer type that cannot hold it is undefined behaviour — it does not saturate and it does not wrap. | Unit 1.4 |
| DT-18 | `1 << 31` is undefined for a 32-bit `int`; `1u << 31` is fine. | Unit 1.5 |
| DT-19 | `%` of a negative number is negative. | Unit 1.5 |
| DT-20 | Precedence is not evaluation order. | Unit 1.6 |
| DT-21 | "Unspecified" and "undefined" are different promises: an unspecified order (function arguments, operands of `+`) makes the program choose one of several valid behaviours, possibly a different one each time; unsequenced side effects on the same object (`i = i++ + 1`) make the whole program undefined. | Unit 1.6 |
| DT-22 | A loop with no observable side effects that does not terminate is undefined behaviour in C11 and later, unless its controlling expression is a constant expression — so the compiler may assume that such a loop ends, and delete it. | Unit 1.7 |
| DT-23 | `int f();` and `int f(void);` are different declarations before C23. | Unit 1.8 |
| DT-24 | Arrays are not copied when passed — they become pointers. | Unit 1.8 |
| DT-25 | C does not guarantee tail-call elimination, so the maximum recursion depth of a program can change with the optimisation level, the compiler, and the stack limit of the thread it runs on. | Unit 1.8 |
| DT-26 | `va_arg(ap, T)` with a type that does not match the promoted type of the actual argument is undefined behaviour — and `va_arg(ap, char)`, `va_arg(ap, short)` and `va_arg(ap, float)` are always wrong, because those types never arrive in a variadic call. | Unit 1.10 |
| DT-27 | `int* a, b;` declares one pointer and one `int`. | Unit 2.1 |
| DT-28 | A null pointer is not necessarily all-zero bits, but `0` in source code is always a null pointer constant. | Unit 2.1 |
| DT-29 | Comparing or subtracting pointers into *different* objects is undefined (for `<`, `>`, `-`) even when both pointers are valid — so `if (p >= buf && p < buf + size)` is not a portable way to test whether an arbitrary pointer points into `buf`. | Unit 2.2 |
| DT-30 | `sizeof` on an array parameter gives the pointer size. | Unit 2.3 |
| DT-31 | `int a[3][4]` decays to `int (*)[4]`, not `int  | Unit 2.3 |
| DT-32 | `strncpy` is not a safe `strcpy`. | Unit 2.4 |
| DT-33 | Comparing strings with `==` compares addresses. | Unit 2.4 |
| DT-34 | `<ctype.h>` functions need `unsigned char` values. | Unit 2.4 |
| DT-35 | `char  | Unit 2.5 |
| DT-36 | `return a - b;` is a broken comparator. | Unit 2.7 |
| DT-37 | A function pointer cannot portably be stored in a `void *`. | Unit 2.7 |
| DT-38 | Calling a function through a pointer of a different function type is undefined behaviour, even when the parameter types "look compatible" — so passing `int cmp(const int *, const int *)` to `qsort` with a cast is wrong. | Unit 2.7 |
| DT-39 | `= {0}` zeroes every member, but in C17 the empty initialiser `= {}` is not valid C (it is a GCC extension and standard only from C23); and neither form promises that *padding bytes* are zero for an automatic struct. | Unit 3.1 |
| DT-40 | `p = realloc(p, n)` leaks on failure. | Unit 3.2 |
| DT-41 | On Linux, `malloc` rarely returns `NULL` — overcommit. | Unit 3.2 |
| DT-42 | A use-after-free often "works" — until the block is reused. | Unit 3.3 |
| DT-43 | Padding bytes have unspecified values, so `memcmp` on structs is unreliable. | Unit 3.5 |
| DT-44 | Strict-aliasing violations show up only under optimisation. | Unit 3.6 |
| DT-45 | Whether a plain `int` bit-field is signed or unsigned is implementation-defined, and almost everything else about bit-field layout is too: the order of fields within a unit, whether a field may straddle a boundary, and the size of the storage unit. | Unit 3.7 |
| DT-46 | Global variables are shared mutable state across the whole program. | Unit 4.1 |
| DT-47 | A plain `inline` function can fail to link at `-O0`. | Unit 4.2 |
| DT-48 | `#` does not expand its argument; you need two levels to stringise a macro's value. | Unit 4.3 |
| DT-49 | Code inside `assert` disappears in release builds. | Unit 4.3 |
| DT-50 | Without header dependencies, Make silently links stale objects. | Unit 4.4 |
| DT-51 | Library order on the command line matters for static libraries. | Unit 4.5 |
| DT-52 | Changing a struct in a shared library's public header breaks every program compiled against the old one. | Unit 4.5 |
| DT-53 | A cache variable keeps the value from the first configure: changing the `option()` default or a `set(... CACHE ...)` default in `CMakeLists.txt` has no effect on an existing build directory, and a `-D` given once stays until it is changed or the cache is deleted. | Unit 4.6 |
| DT-54 | Undefined behaviour can affect code that runs *before* it. | Unit 5.1 |
| DT-55 | A null check after a dereference can be deleted. | Unit 5.1 |
| DT-56 | Sanitizers only see the paths you run. | Unit 5.3 |
| DT-57 | AddressSanitizer does not detect reads of uninitialised memory at all; Valgrind's Memcheck does (at the point where the value influences behaviour), and Clang's MemorySanitizer does at compile-instrumented speed — so "clean under ASan" says nothing about uninitialised data. | Unit 5.4 |
| DT-58 | After `longjmp`, the values of local variables of the function that called `setjmp` are indeterminate if they are not `volatile` and were changed between the `setjmp` and the `longjmp`. | Unit 5.6 |
| DT-59 | After `fork`, unflushed stdio buffers are duplicated. | Unit 6.1 |
| DT-60 | `%f` in `printf` is `double`, but in `scanf` it is `float`. | Unit 6.2 |
| DT-61 | `fclose` can fail, and that is where write errors appear. | Unit 6.3 |
| DT-62 | Measure elapsed time with `CLOCK_MONOTONIC`, never with `time()`, `gettimeofday()` or `CLOCK_REALTIME`: the wall clock can jump backwards or forwards at any moment — NTP corrections, a manual change, a leap-second smear — so durations computed from it can be negative or wildly wrong. | Unit 6.5 |
| DT-63 | `wchar_t` is not "a Unicode character": its size and encoding are implementation-defined — 32-bit UTF-32 on Linux and macOS, 16-bit UTF-16 code units on Windows, where characters outside the Basic Multilingual Plane (such as most emoji) take two `wchar_t` values. | Unit 6.8 |
| DT-64 | Big-O hides constants that can dominate. | Unit 7.1 |
| DT-65 | A linked-list benchmark that builds its list with consecutive `malloc` calls and walks it right away measures a best case that real programs rarely see: the allocator places the nodes next to each other, so the "pointer chase" streams through memory like an array. | Unit 7.2 |
| DT-66 | Free-running unsigned indices — `head` and `tail` that only ever increase and wrap at 2^32 — work only when the capacity divides 2^32, that is, when it is a power of two. With any other capacity, `index % cap` jumps when the counter wraps, and the ring silently reorders or overwrites elements. | Unit 7.3 |
| DT-67 | Never iterate a hash table and rely on the order. | Unit 7.4 |
| DT-68 | `read` and `write` may transfer less than requested — and it is not an error. | Unit 8.1 |
| DT-69 | Descriptors leak into child programs unless marked close-on-exec. | Unit 8.1 |
| DT-70 | Check-then-use on file names is a race (TOCTOU). | Unit 8.2 |
| DT-71 | A child that has called `fork` must leave with `_exit`, not `exit` or `return from main`, when it does not `exec` — and after a failed `exec` too. `exit` runs the parent's `atexit` handlers and flushes the stdio buffers the child inherited, so output written by the parent before the `fork` appears twice, and cleanup meant to run once (deleting a temporary file, sending a "goodbye" message) runs in both processes. | Unit 8.3 |
| DT-72 | A reader on a pipe sees end-of-file only when *every* write descriptor for that pipe is closed — including the copies inherited through `fork` by processes that never write. Forget to close one, and the reader blocks forever. | Unit 8.4 |
| DT-73 | `signal()` semantics vary; use `sigaction`. | Unit 8.5 |
| DT-74 | Accessing a page of a file mapping that lies beyond the current end of the file raises `SIGBUS`, not `SIGSEGV` — so if another process truncates a file while you have it mapped, your next read of the vanished part kills you. | Unit 8.6 |
| DT-75 | Passing `&i` — the address of a loop variable — as the argument of `pthread_create` is a data race: the thread reads `i` whenever it gets around to it, while the loop keeps changing it, so several threads may see the same value and some values may be skipped. | Unit 9.1 |
| DT-76 | `volatile` does not make code thread-safe. | Unit 9.2 |
| DT-77 | Changing the shared state and signalling must happen with the mutex held — or at least the state change must; signalling a condition variable without first changing the predicate under the mutex can wake nobody, because a thread that checked the predicate just before may not yet be waiting: the "lost wake-up". | Unit 9.3 |
| DT-78 | Plain `int` flags between threads are a data race, even on x86. | Unit 9.5 |
| DT-79 | Forgetting `htons` on a port number does not cause an error — the program binds or connects to a different port: on a little-endian machine port 8080 (0x1F90) becomes 36895 (0x901F). | Unit 10.1 |
| DT-80 | A UDP datagram larger than the receive buffer is truncated, and the rest is discarded silently: `recvfrom` returns the buffer size, not an error, unless you ask with `MSG_TRUNC`, which makes Linux return the datagram's real length. | Unit 10.4 |
| DT-81 | Writing to a TCP socket whose peer has closed the connection raises `SIGPIPE`, and the default action of `SIGPIPE` is to terminate the process — so one client that disconnects at the wrong moment can kill a whole server that never installed a handler. | Unit 10.5 |
| DT-82 | One slow operation in an event loop delays every client. | Unit 10.6 |
| DT-83 | Two small writes in a row can cost 40 milliseconds: Nagle's algorithm meets delayed ACK. | Unit 10.6 |
| DT-84 | `select` can only watch descriptors numbered below `FD_SETSIZE` (1024 on Linux), and `FD_SET` with a larger descriptor writes past the end of the `fd_set` — memory corruption, not an error. A long-running server that opens more than about a thousand files or sockets crosses that line without noticing. | Unit 10.8 |
| DT-85 | Calling a function through a wrong prototype breaks the ABI silently. | Unit 11.2 |
| DT-86 | A linked list of N elements can be 10–100× slower to traverse than an array of N elements. | Unit 11.4 |
| DT-87 | `-ffast-math` is not one optimisation but a bundle of promises you make to the compiler — no NaNs, no infinities, no signed zeros, no trapping, associativity allowed — and breaking a promise makes the program's results, not just its speed, change; it even affects other code, because linking with `-ffast-math` can switch the CPU into "flush denormals to zero" mode for the whole process. | Unit 11.6 |
| DT-88 | An off-by-one write of a single zero byte can be exploitable. | Unit 12.1 |
| DT-89 | `calloc(n, size)` must fail if `n * size` overflows, but `malloc(n * size)` cannot know that an overflow happened — the multiplication was done, and wrapped, before `malloc` was called. So replacing `calloc` with `malloc` "for speed" can turn an allocation failure into a heap overflow, and so can `realloc(p, n * size)`. | Unit 12.3 |
| DT-90 | Checking a path for `..` with string operations does not make it safe to open: symbolic links, absolute paths, encodings (Unit 6.8's overlong forms, `%2e%2e` in URLs), and a file replaced between the check and the `open` all bypass it. On Linux, the robust tool is `openat2` with `RESOLVE_BENEATH`, which makes the kernel refuse any path that escapes the given directory — during the lookup itself. | Unit 12.5 |
| DT-91 | `write` returning success does not mean the data is on disk. | Unit 13.3 |

## Patterns

| # | Pattern | Where |
| --- | --- | --- |
| P-1 | Compile every change with warnings and sanitizers; ship with warnings as errors. | Unit 0.7 |
| P-2 | Read lines, then parse; validate every conversion completely. | Unit 1.9 |
| P-3 | Every printf-like function you write gets `__attribute__((format(printf, N, M)))`, and forwards to the `v` version of the library function (`vfprintf`, `vsnprintf`) instead of re-parsing the format. | Unit 1.10 |
| P-4 | Pair every allocation with a documented owner and a single release point. | Unit 3.3 |
| P-5 | Opaque handle + constructor/destructor pair for every non-trivial type. | Unit 3.8 |
| P-6 | `static` by default; external linkage only for the public interface. | Unit 4.1 |
| P-7 | Check every return value; propagate errors with context; assert only invariants. | Unit 5.6 |
| P-8 | Generic containers: `void *` for cold code, generated code for hot code. | Unit 7.9 |
| P-9 | One lock per piece of shared state, acquired in a documented global order, held briefly. | Unit 9.4 |
| P-10 | Per-connection receive buffer + incremental parser + hard limits. | Unit 10.3 |
| P-11 | Profile, form a hypothesis about the hardware, change one thing, measure again. | Unit 11.7 |
| P-12 | Parse untrusted input with a small, fuzzed, bounds-checked parser that produces validated structures. | Unit 12.5 |
