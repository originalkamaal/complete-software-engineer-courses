---
title: "C from Zero to Systems"
subtitle: "A complete course in the C programming language — from how a program runs to a crash-safe database server"
lang: en
---

# Preface

C is fifty years old and still runs the world: operating-system kernels, databases, language runtimes, network stacks, embedded firmware, and the libraries underneath almost every other language. Learning it well changes how you understand every other kind of programming, because C hides almost nothing about the machine.

C also forgives almost nothing. A program can compile without warnings, pass its tests, and still contain undefined behaviour that corrupts memory in production or becomes a security hole. So this book teaches C the way professionals actually write it: precise knowledge of the rules, plus the habit of checking everything with tools — compiler warnings, sanitizers, Valgrind, debuggers, static analysers, fuzzers, profilers, and measurements.

The book starts below the language, with what a compiler, linker, and running process are. It covers the core language rule by rule, then pointers, memory, program structure, undefined behaviour and debugging, the standard library, data structures and algorithms, POSIX systems programming, concurrency, networking, performance, and security. It ends with a capstone: a networked key-value database with a write-ahead log, snapshots, and crash recovery, tested by killing it mid-write.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the C standard, a particular implementation, the operating system, or the hardware.
2. **Evidence.** Every program in this book was compiled and run, and every output shown is real — including warnings, sanitizer reports, crashes, and benchmark numbers. When the first version of an example was wrong (and several were), the book shows what went wrong and how the tools revealed it, because that is how real C development goes.
3. **Order.** Nothing is used before it is taught, and later chapters refer back by unit number.

# How to use this book

## Who it is for

- **Beginners** who are willing to work carefully: start at Chapter 0 and read in order. No previous programming is assumed, though it helps.
- **Programmers from other languages:** read Chapters 0–2 quickly, but do every *Deep & Tricky* entry and *Mastery check*; C's rules differ from what you know in exactly those places.
- **Working C programmers:** use Appendix A to test yourself, then focus on Chapters 5, 9, 11, and 12.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | The rules, with small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, each labelled with its source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Common mistakes** | What people actually get wrong (in some units). |
| **Mastery check** | *Explain*, *Predict* (decide the output before running), *Write* (code it). Answers to prediction questions are at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a specification, a complete reference solution with real output, and a review checklist. Try the project yourself first.

## How to study

1. **Type the programs and run them.** Compile every one with the warning flags shown. Compare your output with the book's.
2. **Predict before you run.** When you are wrong, find out why before moving on.
3. **Break things on purpose.** Remove a bounds check, free something twice, forget a `close` — and watch which tool catches it.
4. **Use the tools from day one:** `-Wall -Wextra`, `-fsanitize=address,undefined`, and GDB. Chapter 0 shows how; Chapter 5 explains them fully.
5. **Revise with Appendix A,** which lists every DT and P entry by title.

## How to read the labels

| Label | Meaning |
| --- | --- |
| *Guarantee* / *Guarantee: C standard* | Required by the ISO C standard. True on every conforming implementation. |
| *Guarantee: UB* | The standard says the behaviour is undefined: no requirements at all. |
| *Library behaviour* | Specified by the C library documentation (glibc here) or POSIX rather than by the language. |
| *POSIX*, *OS behaviour* | Specified by POSIX or by the operating system (Linux here), not by ISO C. |
| *Toolchain behaviour*, *Compiler behaviour*, *Optimiser behaviour* | What GCC, Clang, or the linker do. Stable in practice; may change between versions. |
| *Implementation detail* | How today's implementation works internally. Useful for performance; never rely on it for correctness. |
| *Hardware fact*, *TCP behaviour*, *IEEE 754 behaviour* | True because of the machine, the protocol, or the floating-point standard. |
| *Practice*, *Design fact*, *Security fact* | Professional practice and experience, not rules of the language. |

## Toolchain and versions

All code was compiled and run on **Linux x86-64 (Ubuntu 24.04)** with:

- **GCC 13.3** (default compiler) and **GCC 14.2** (for C23 examples),
- **Clang 18** (sanitizers, MemorySanitizer, libFuzzer, `clang-tidy`),
- **glibc 2.39**, **GNU Make 4.3**, **CMake 3.28**, **NASM 2.16**, **GDB 15**, **Valgrind 3.22**, **cppcheck 2.13**, **perf** (Linux 6.8 tools).

The language baseline is **C17** (`-std=c17`); **C23** features are marked and compiled with `gcc-14 -std=c23`. POSIX programs (Chapters 8–10, 13) need Linux or another Unix; most also work on macOS and the BSDs, except Linux-specific APIs such as `epoll` (macOS and BSDs use `kqueue`). On Windows, use WSL2 to follow the book.

Measurements (Chapters 7, 9, 10, 11, 13) were taken on a 2-core virtual machine (Intel Xeon at 2.1 GHz). Your numbers will differ; compare the ratios and shapes.

A few things could not be demonstrated directly and the text says so where they arise: hardware performance counters were unavailable in the virtual machine (Cachegrind is used instead), and durability against **power loss** (as opposed to process crashes) was not tested in Chapter 13.

## Setting up

1. Install a compiler and tools. On Debian/Ubuntu: `sudo apt install build-essential clang gdb valgrind cmake`. On Fedora: `sudo dnf install gcc clang gdb valgrind cmake make`. On macOS: `xcode-select --install` (Clang; use a Linux VM or container for Valgrind, `epoll`, and `perf`).
2. Check: `gcc --version`, `clang --version`, `gdb --version`.
3. Use any editor with C support through **clangd** (VS Code, CLion, Neovim, Emacs, Zed).
4. Create a working folder with one subfolder per chapter, and keep a journal of the predictions you got wrong.

# Roadmap

| Chapter | Title | You will be able to… |
| --- | --- | --- |
| 0 | How C Becomes a Running Program | follow source code through preprocessing, compiling, assembling, and linking into a process; read binary and hex; set up warnings and sanitizers |
| 1 | Core Language | apply C's exact rules for types, conversions, operators, evaluation order, control flow, and functions |
| 2 | Pointers, Arrays, and Strings | use pointers, pointer arithmetic, arrays, strings, `const`, and function pointers safely |
| 3 | Memory and Data Layout | manage dynamic memory with clear ownership; design structs, unions, and opaque types; predict layout |
| 4 | Program Structure, the Preprocessor, and Builds | organise multi-file programs, use the preprocessor safely, and build with Make, CMake, and libraries |
| 5 | Undefined Behaviour, Debugging, and Testing | recognise UB; use warnings, static analysis, sanitizers, Valgrind, GDB; test and measure coverage |
| 6 | The Standard Library and I/O | use streams, formatted and binary I/O, files, time, and modern C11–C23 features |
| 7 | Data Structures and Algorithms in C | implement lists, hash tables, trees, heaps, sorting, and graphs, and write generic code |
| 8 | POSIX Systems Programming | use file descriptors, processes, pipes, signals, `mmap`, and `dlopen`; write a shell |
| 9 | Concurrency | write correct threaded code with mutexes, condition variables, and atomics; measure speed-up |
| 10 | Network Programming | write TCP/UDP clients and servers and an `epoll` event-driven HTTP server |
| 11 | Performance and the Machine | read assembly, use the ABI, exploit caches, branch prediction, and SIMD, and profile |
| 12 | Security and Robustness | understand memory-safety vulnerabilities and mitigations, write secure code, and fuzz |
| 13 | Capstone: A Persistent Key-Value Database Server | design, build, crash-test, load-test, and defend a durable database server |
| A | Index of Deep & Tricky entries and Patterns | revise every entry by title |
| B | Glossary | look up any term |
| C | C standards and toolchain support | see which standard introduced each feature, and compiler support |

Chapters 0–6 are the **foundation**; read them in order. Chapters 7–12 can be read in any order after Chapter 6 (Chapter 10 uses Chapter 8, and Chapter 9's project uses Chapter 7's hash table). Chapter 13 uses the whole book.
