# Appendix C — C standards and toolchain support

C is defined by ISO/IEC 9899. Each revision is mostly backwards compatible; select one with `-std=`. The `gnu` variants (`-std=gnu17`) add GCC extensions; this book uses the strict `c17` mode so that non-standard code is reported.

| Standard | Year | Features used or discussed in this book |
| --- | --- | --- |
| C89/C90 | 1989/1990 | the core language: types, pointers, structs, the preprocessor, `<stdio.h>`, `<stdlib.h>`, `<string.h>` |
| C99 | 1999 | `//` comments; declarations anywhere; `long long`; `<stdint.h>`/`<inttypes.h>`; `_Bool`/`<stdbool.h>`; designated initialisers; compound literals; flexible array members; variable-length arrays; `inline`; `restrict`; `snprintf`; `__func__` |
| C11 | 2011 | `_Generic`; `_Static_assert`; `_Alignas`/`_Alignof`; anonymous structs and unions; `_Noreturn`; `<threads.h>`; `<stdatomic.h>` and the memory model; `_Thread_local`; `aligned_alloc`; `fopen` mode `x`; `quick_exit`; removal of `gets`; VLAs made optional |
| C17 | 2018 | defect fixes only — **the baseline of this book** |
| C23 | 2024 | `bool`, `true`, `false`, `nullptr`, `static_assert`, `alignas`, `thread_local` as keywords; `constexpr` objects; `typeof`; `auto` type inference; `[[attributes]]` (`nodiscard`, `maybe_unused`, `fallthrough`, `noreturn`, `deprecated`); binary literals and digit separators; `= {}` initialisers; enums with fixed underlying types; `<stdckdint.h>` (`ckd_add`, …); `<stdbit.h>`; `#embed`; `memset_explicit`; `strdup`/`strndup`; two's complement required; `()` means `(void)` |

## Compiler support used in this book

| Feature set | GCC 13 | GCC 14 | Clang 18 |
| --- | --- | --- | --- |
| C17 | full | full | full |
| C23 core keywords, `typeof`, attributes, binary literals | yes (`-std=c2x`) | yes (`-std=c23`) | mostly (`-std=c23`) |
| C23 `constexpr` objects | no | yes | no (Clang 19+) |
| `<stdckdint.h>` | no (use `__builtin_add_overflow`) | yes | yes |
| `#embed` | no | no (GCC 15) | no (Clang 19) |

`<stdbit.h>` is provided by the C library (glibc 2.39+), not the compiler.

## Common extensions used and marked in the text

`__attribute__((...))` (`noinline`, `noipa`, `packed`, `aligned`, `target`, `warn_unused_result`, `fallthrough`, `visibility`), statement expressions `({ ... })`, `__typeof__`, `__builtin_expect`, `__builtin_cpu_supports`, `__builtin_*_overflow`, and extended inline assembly — all supported by both GCC and Clang.
