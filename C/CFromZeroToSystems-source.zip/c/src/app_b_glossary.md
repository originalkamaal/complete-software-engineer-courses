# Appendix B — Glossary

Short definitions of the terms used in this book. The unit given (where there is one) explains the term fully.

| Term | Meaning |
| --- | --- |
| ABI (application binary interface) | The binary-level contract: calling convention, type sizes, struct layout, symbol names (Unit 11.2) |
| Abstract machine | The model of execution the C standard describes; compilers must preserve only its observable behaviour (Unit 0.1) |
| Acquire / release | Memory orders that publish data from one thread to another (Unit 9.5) |
| Address space | The range of virtual addresses a process can use |
| AddressSanitizer (ASan) | Compiler instrumentation that detects out-of-bounds accesses, use-after-free, double free, and leaks at run time |
| Aliasing | Two pointers referring to the same memory; limits optimisation (Unit 11.3) |
| Alignment | The requirement that an object's address be a multiple of a value such as 4 or 8 (Unit 3.5) |
| Amortised cost | Average cost per operation over a sequence, e.g. dynamic-array push is O(1) amortised |
| Arena allocator | Allocates many objects from large chunks and frees them all at once (Chapter 3 project) |
| Array decay | Conversion of an array to a pointer to its first element in most expressions (Unit 2.3) |
| ASLR | Address space layout randomisation: random placement of stack, heap, and libraries |
| Assembler | The tool that turns assembly text into machine code in an object file |
| Atomic operation | An indivisible memory operation that is free of data races (`<stdatomic.h>`) |
| Big-endian / little-endian | Byte orders for multi-byte values: most significant first / least significant first |
| Bit-field | A struct member with an explicit width in bits (Unit 3.7) |
| Branch prediction | CPU guessing the direction of branches to execute ahead; mispredictions cost cycles (Unit 11.5) |
| BSS | The section of zero-initialised static data; takes no space in the executable file |
| Buffer overflow | Writing past the end of a buffer; the classic memory-safety vulnerability (Unit 12.1) |
| Cache line | The unit of transfer between memory and CPU caches, 64 bytes on x86-64 |
| Calling convention | Rules for passing arguments and results and preserving registers across calls |
| Canary (stack protector) | A random value checked before a function returns, detecting stack overflows |
| Compound literal | An unnamed object created in an expression: `(struct point){1, 2}` |
| Condition variable | Lets threads sleep until shared state changes; always wait in a loop (Unit 9.3) |
| Copy-on-write | Sharing pages between processes until one writes, then copying (fork, MAP_PRIVATE) |
| CRC-32 | A checksum used to detect corrupted or torn data (Unit 13.3) |
| CSR (compressed sparse row) | Graph layout in flat arrays of offsets and edges (Unit 7.8) |
| Dangling pointer | A pointer to an object whose lifetime has ended |
| Data race | Concurrent unsynchronised accesses to the same location, at least one a write: undefined behaviour |
| Deadlock | Threads waiting for each other forever, typically through opposite lock orders |
| Declaration / definition | Introducing a name and type / also creating the object or function body |
| Designated initialiser | Initialising named members or indexes: `{.y = 3}`, `{[2] = 5}` |
| Dynamic linking | Resolving library functions at load time from shared objects (`.so`) |
| ELF | Executable and Linkable Format: the object and executable format on Linux |
| epoll | Linux's scalable API for waiting on many file descriptors (Unit 10.6) |
| errno | Thread-local error code set by failing library functions and system calls |
| Event loop | A single thread that waits for ready descriptors and handles each without blocking |
| Exit status | The integer a process returns to its parent; 0 means success |
| False sharing | Independent variables on one cache line slowing threads that write them (Unit 9.7) |
| Feature-test macro | A macro like `_POSIX_C_SOURCE` defined before includes to request extra declarations |
| File descriptor | Small integer referring to an open file, pipe, socket, or device |
| Flexible array member | A last struct member `T name[];` sized at allocation time (Unit 3.8) |
| fork / exec | Create a copy of the process / replace the program running in a process (Unit 8.3) |
| Fortify source | `_FORTIFY_SOURCE`: glibc checks for overflows in common functions |
| Framing | Finding message boundaries in a byte stream (Unit 10.3) |
| fsync / fdatasync | Force file data to stable storage (DT-91) |
| Fuzzing | Automatically generating inputs to find crashes and bugs (Unit 12.6) |
| GDB | The GNU debugger (Unit 5.5) |
| Generic selection (`_Generic`) | Compile-time choice of an expression by type (C11) |
| Hash table | Key-value structure with O(1) average lookup by hashing (Unit 7.4) |
| Header file | A file of declarations shared between translation units |
| Heap (data structure) | Array-based tree giving a priority queue (Unit 7.6) |
| Heap (memory) | Memory obtained from `malloc` and released with `free` |
| Implementation-defined behaviour | Behaviour the compiler chooses and documents (e.g. size of `int`) |
| Include guard | `#ifndef X_H / #define X_H / #endif` preventing double inclusion |
| Indeterminate value | The value of an uninitialised automatic object; using it is a bug |
| Inline assembly | Assembly embedded in C with `__asm__` (Unit 11.2) |
| Integer promotion | Conversion of types narrower than `int` to `int` before arithmetic (Unit 1.3) |
| Internal / external linkage | Name visible only in its file (`static`) / across the program |
| Intrusive list | A list whose links are embedded in the elements, used with `container_of` |
| libFuzzer | Clang's in-process coverage-guided fuzzer |
| Linker | Combines object files and libraries into an executable, resolving symbols |
| Load factor | Fraction of a hash table's slots in use |
| Lock-free | Algorithms that make progress without locks, using atomics |
| LTO | Link-time optimisation: optimising across translation units |
| Macro | A preprocessor text substitution (`#define`) |
| Memory leak | Allocated memory that is never freed |
| Memory model | Rules for visibility and ordering of memory operations between threads |
| Memory order | `relaxed`, `acquire`, `release`, `acq_rel`, `seq_cst` (Unit 9.5) |
| MemorySanitizer (MSan) | Clang tool detecting reads of uninitialised memory |
| mmap | Map files or anonymous memory into the address space (Unit 8.6) |
| Mutex | Lock providing mutual exclusion (`pthread_mutex_t`) |
| Nagle's algorithm | TCP batching of small segments; combined with delayed ACK can add 40 ms (DT-83) |
| NaN | Not a Number: IEEE 754 result of undefined operations; unequal to itself |
| Non-blocking I/O | I/O calls that return `EAGAIN` instead of waiting |
| Null pointer | A pointer value pointing to no object (`NULL`, C23 `nullptr`) |
| Object file | Compiled machine code plus symbols, before linking (`.o`) |
| Opaque type | A struct declared but not defined in a header, hiding its layout (Unit 3.8) |
| Ownership | Which part of a program is responsible for freeing an object (Unit 3.3) |
| Padding | Unused bytes inserted in structs for alignment |
| PGO | Profile-guided optimisation using data from a training run |
| PIE | Position-independent executable, loadable at any address |
| Pipe | A one-way kernel channel between processes (Unit 8.4) |
| Pointer arithmetic | Adding integers to pointers moves by whole elements (Unit 2.2) |
| POSIX | The standard API of Unix-like operating systems |
| Preprocessor | The first build stage: includes, macros, conditional compilation |
| Process | A running program with its own address space |
| pthreads | POSIX threads API |
| Race condition | Outcome depending on timing between threads or processes |
| RELRO | Making dynamic-linking tables read-only after start-up |
| restrict | Qualifier promising a pointer is the only way to access its object (Unit 11.3) |
| Ring buffer | Fixed array used as a queue with wrapping indices (Unit 7.3) |
| Sanitizer | Compiler instrumentation that detects classes of bugs at run time |
| Sequence point / sequencing | Rules for the order of side effects within expressions (Unit 1.6) |
| Shared library | Library loaded at run time (`.so`), shared by processes (Unit 4.5) |
| Signal | Asynchronous notification to a process (Unit 8.5) |
| SIMD | Single instruction, multiple data: vector instructions (Unit 11.6) |
| size_t | Unsigned type of sizes and `sizeof` results |
| Snapshot | A complete copy of a database's state at a point in time (Unit 13.4) |
| Socket | Endpoint for network communication |
| soname | A shared library's versioned name recorded by programs that use it |
| Stack (memory) | Per-thread memory for function frames and automatic variables |
| Static library | Archive of object files copied into executables (`.a`) |
| Storage duration | Static, automatic, allocated, or thread lifetime of an object |
| Strict aliasing | Rule that objects may be accessed only through compatible types (Unit 3.6) |
| String literal | Text in double quotes; a read-only array of `char` ending in `'\0'` |
| Struct | Aggregate type of named members |
| System call | Request from a process to the kernel |
| Tagged union | A union plus a field saying which member is valid |
| Tentative definition | A file-scope declaration without initialiser that may become a definition |
| ThreadSanitizer (TSan) | Tool detecting data races and lock-order inversions |
| Tombstone | Marker for a deleted slot in an open-addressing hash table |
| Translation unit | A source file after preprocessing, compiled independently |
| Two's complement | The representation of signed integers on all modern machines (required in C23) |
| Undefined behaviour (UB) | Behaviour for which the standard imposes no requirements (Unit 5.1) |
| Union | Type whose members share the same storage |
| Unspecified behaviour | Behaviour with several allowed outcomes, not necessarily documented |
| Usual arithmetic conversions | Rules bringing operands to a common type (Unit 1.3) |
| Valgrind | A dynamic analysis framework; Memcheck finds memory errors without recompiling |
| Variable-length array (VLA) | Array whose size is determined at run time (optional since C11) |
| volatile | Qualifier forcing every access to happen; not a synchronisation tool (DT-76) |
| Write-ahead log (WAL) | An append-only record of changes written before they are acknowledged (Unit 13.3) |
| Zombie process | An exited child not yet waited for |
