// file: fdio.c
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* write_all writes all n bytes, retrying after short writes and EINTR. */
static int write_all(int fd, const void *buf, size_t n) {
    const char *p = buf;
    while (n > 0) {
        ssize_t w = write(fd, p, n);
        if (w < 0) {
            if (errno == EINTR)
                continue;               /* interrupted by a signal before writing anything */
            return -1;
        }
        p += w;
        n -= (size_t)w;
    }
    return 0;
}

int main(void) {
    int fd = open("fd_demo.txt", O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
    if (fd < 0) {
        perror("open");
        return 1;
    }
    const char *msg = "written with write(2)\n";
    if (write_all(fd, msg, strlen(msg)) != 0 || close(fd) != 0) {
        perror("write/close");
        return 1;
    }

    fd = open("fd_demo.txt", O_RDONLY | O_CLOEXEC);
    char buf[8];
    ssize_t r;
    printf("fd = %d; reading in chunks of %zu:\n", fd, sizeof buf);
    while ((r = read(fd, buf, sizeof buf)) > 0)        /* 0 means end of file */
        printf("  got %zd bytes: \"%.*s\"\n", r, (int)r, buf);
    if (r < 0)
        perror("read");
    close(fd);

    if (open("/no/such/file", O_RDONLY) < 0)
        printf("open failed: errno %d (%s)\n", errno, strerror(errno));
    return 0;
}
