// file: spawn.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* run executes argv[0] with arguments, waits, and returns a shell-style status. */
static int run(char *const argv[]) {
    fflush(stdout);                          /* DT-47: don't duplicate buffered output */
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }
    if (pid == 0) {                          /* child */
        execvp(argv[0], argv);               /* searches PATH; returns only on failure */
        perror(argv[0]);
        _exit(127);                          /* _exit: don't run the parent's atexit/flush */
    }
    int status;                              /* parent */
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid");
        return -1;
    }
    if (WIFEXITED(status))
        return WEXITSTATUS(status);
    if (WIFSIGNALED(status))
        return 128 + WTERMSIG(status);
    return -1;
}

int main(void) {
    char *echo[] = {"echo", "hello from a child process", NULL};
    char *falsecmd[] = {"false", NULL};
    char *missing[] = {"no-such-command", NULL};
    char *killed[] = {"sh", "-c", "kill -TERM $$", NULL};
    printf("parent pid %d\n", (int)getpid());
    printf("echo  -> status %d\n", run(echo));
    printf("false -> status %d\n", run(falsecmd));
    printf("missing -> status %d\n", run(missing));
    printf("killed  -> status %d\n", run(killed));
    return 0;
}
