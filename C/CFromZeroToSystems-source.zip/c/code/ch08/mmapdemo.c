// file: mmapdemo.c
#define _DEFAULT_SOURCE
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void) {
    /* 1. read a file through a mapping: count newlines without read() */
    int fd = open("/etc/services", O_RDONLY);
    struct stat st;
    if (fd < 0 || fstat(fd, &st) != 0)
        return 1;
    const char *data = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (data == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    close(fd);                                   /* the mapping stays valid */
    long lines = 0;
    for (off_t i = 0; i < st.st_size; i++)
        lines += data[i] == '\n';
    printf("/etc/services: %jd bytes, %ld lines (via mmap)\n", (intmax_t)st.st_size, lines);
    munmap((void *)data, (size_t)st.st_size);

    /* 2. shared anonymous memory between parent and child */
    int *counter = mmap(NULL, sizeof *counter, PROT_READ | PROT_WRITE,
                        MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (counter == MAP_FAILED)
        return 1;
    *counter = 0;
    pid_t pid = fork();
    if (pid == 0) {
        *counter = 42;                           /* visible to the parent */
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    printf("child wrote %d into shared memory\n", *counter);

    int *private_copy = mmap(NULL, sizeof *private_copy, PROT_READ | PROT_WRITE,
                             MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    *private_copy = 1;
    pid = fork();
    if (pid == 0) {
        *private_copy = 99;                      /* copy-on-write: parent's page unchanged */
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    printf("after child wrote 99 to a MAP_PRIVATE page, parent still sees %d\n", *private_copy);
    return 0;
}
