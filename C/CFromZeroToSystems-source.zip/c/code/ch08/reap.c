// file: reap.c
#define _DEFAULT_SOURCE                     /* POSIX plus WCOREDUMP, which is an XSI extension */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static void describe(pid_t pid, int status) {
    if (WIFEXITED(status)) printf("  child %d exited with status %d\n", (int)pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status)) printf("  child %d was killed by signal %d (%s)%s\n", (int)pid, WTERMSIG(status),
                                         strsignal(WTERMSIG(status)), WCOREDUMP(status) ? ", core dumped" : "");
}

int main(void) {
    pid_t a = fork();
    if (a == 0) _exit(7);                                     /* normal exit */
    pid_t b = fork();
    if (b == 0) { int *p = NULL; return *p; }                 /* crash: SIGSEGV */
    pid_t c = fork();
    if (c == 0) { pause(); _exit(0); }                        /* waits for a signal */

    sleep(1);
    char cmd[64];
    snprintf(cmd, sizeof cmd, "ps -o pid,stat,comm --ppid %d", (int)getpid());
    printf("before waiting (Z = zombie):\n");
    fflush(stdout);
    if (system(cmd) != 0) return 1;

    kill(c, SIGTERM);
    int status;
    pid_t pid;
    while ((pid = waitpid(-1, &status, 0)) > 0) describe(pid, status);
    printf("after waiting:\n");
    fflush(stdout);
    if (system(cmd) != 0) return 1;
    return 0;
}
