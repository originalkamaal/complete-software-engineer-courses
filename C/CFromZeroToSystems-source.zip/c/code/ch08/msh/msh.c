// file: msh/msh.c
/* msh: a small Unix shell with pipelines, redirection, and built-ins. */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

enum { MAX_TOKENS = 128, MAX_STAGES = 16 };

typedef struct {
    char *argv[MAX_TOKENS];
    int argc;
    const char *in, *out;
    int append;
} Stage;

static int last_status = 0;

/* tokenize splits line into tokens, honouring single and double quotes.
   Words are copied into store (at least 2 * strlen(line) + 2 bytes), because a
   word and the operator after it ("a|b") cannot both be terminated in place.
   Operators | < > >> become their own tokens. Returns the count or -1 on error. */
static int tokenize(const char *line, char *tok[], int max, char *store) {
    static char *ops[] = {"|", "<", ">", ">>"};
    int n = 0;
    const char *p = line;
    for (;;) {
        while (*p == ' ' || *p == '\t' || *p == '\n')
            p++;
        if (*p == '\0')
            break;
        if (n == max - 1)
            return -1;
        if (*p == '|' || *p == '<' || *p == '>') {
            if (p[0] == '>' && p[1] == '>') { tok[n++] = ops[3]; p += 2; }
            else { tok[n++] = *p == '|' ? ops[0] : *p == '<' ? ops[1] : ops[2]; p++; }
            continue;
        }
        tok[n++] = store;
        while (*p && *p != ' ' && *p != '\t' && *p != '\n' && *p != '|' && *p != '<' && *p != '>') {
            if (*p == '\'' || *p == '"') {
                char q = *p++;
                while (*p && *p != q)
                    *store++ = *p++;
                if (*p != q)
                    return -1;               /* unterminated quote */
                p++;
            } else {
                *store++ = *p++;
            }
        }
        *store++ = '\0';
    }
    tok[n] = NULL;
    return n;
}

/* parse groups tokens into pipeline stages. Returns the number of stages or -1. */
static int parse(char *tok[], int ntok, Stage st[], int max) {
    int ns = 0;
    memset(&st[0], 0, sizeof st[0]);
    for (int i = 0; i < ntok; i++) {
        const char *t = tok[i];
        Stage *s = &st[ns];
        if (strcmp(t, "|") == 0) {
            if (s->argc == 0 || ns + 1 == max)
                return -1;
            s->argv[s->argc] = NULL;
            memset(&st[++ns], 0, sizeof st[0]);
        } else if (strcmp(t, "<") == 0 || strcmp(t, ">") == 0 || strcmp(t, ">>") == 0) {
            if (i + 1 >= ntok)
                return -1;
            if (t[0] == '<') s->in = tok[++i];
            else { s->out = tok[++i]; s->append = t[1] == '>'; }
        } else {
            if (s->argc == MAX_TOKENS - 1)
                return -1;
            s->argv[s->argc++] = tok[i];
        }
    }
    if (st[ns].argc == 0)
        return ntok == 0 ? 0 : -1;
    st[ns].argv[st[ns].argc] = NULL;
    return ns + 1;
}

static int builtin(Stage *s) {
    const char *cmd = s->argv[0];
    if (strcmp(cmd, "exit") == 0)
        exit(s->argc > 1 ? atoi(s->argv[1]) : last_status);
    if (strcmp(cmd, "cd") == 0) {
        const char *dir = s->argc > 1 ? s->argv[1] : getenv("HOME");
        if (dir == NULL || chdir(dir) != 0) {
            fprintf(stderr, "msh: cd: %s: %s\n", dir ? dir : "", strerror(errno));
            last_status = 1;
        } else {
            last_status = 0;
        }
        return 1;
    }
    if (strcmp(cmd, "status") == 0) {
        printf("%d\n", last_status);
        last_status = 0;
        return 1;
    }
    return 0;
}

/* redirect opens path and installs it on target_fd in the child. */
static void redirect(const char *path, int flags, int target_fd) {
    int fd = open(path, flags, 0644);
    if (fd < 0) {
        fprintf(stderr, "msh: %s: %s\n", path, strerror(errno));
        _exit(1);
    }
    dup2(fd, target_fd);
    close(fd);
}

static void run_pipeline(Stage st[], int ns) {
    if (ns == 1 && builtin(&st[0]))
        return;
    pid_t pids[MAX_STAGES];
    int prev_read = -1;                       /* read end of the previous stage's pipe */
    fflush(stdout);
    for (int i = 0; i < ns; i++) {
        int fds[2] = {-1, -1};
        if (i < ns - 1 && pipe(fds) != 0) {
            perror("msh: pipe");
            break;
        }
        pid_t pid = fork();
        if (pid < 0) {
            perror("msh: fork");
            break;
        }
        if (pid == 0) {
            signal(SIGINT, SIG_DFL);          /* children die on Ctrl-C; the shell doesn't */
            if (prev_read != -1) {
                dup2(prev_read, STDIN_FILENO);
                close(prev_read);
            }
            if (fds[1] != -1) {
                dup2(fds[1], STDOUT_FILENO);
                close(fds[0]);
                close(fds[1]);
            }
            if (st[i].in)
                redirect(st[i].in, O_RDONLY, STDIN_FILENO);
            if (st[i].out)
                redirect(st[i].out, O_WRONLY | O_CREAT | (st[i].append ? O_APPEND : O_TRUNC), STDOUT_FILENO);
            execvp(st[i].argv[0], st[i].argv);
            fprintf(stderr, "msh: %s: command not found\n", st[i].argv[0]);
            _exit(127);
        }
        pids[i] = pid;
        if (prev_read != -1)
            close(prev_read);                 /* the parent keeps no pipe ends open */
        if (fds[1] != -1)
            close(fds[1]);
        prev_read = fds[0];
    }
    for (int i = 0; i < ns; i++) {
        int status;
        if (waitpid(pids[i], &status, 0) < 0)
            continue;
        if (i == ns - 1)
            last_status = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    }
}

int main(void) {
    signal(SIGINT, SIG_IGN);                  /* the shell itself ignores Ctrl-C */
    int interactive = isatty(STDIN_FILENO);
    char *line = NULL;
    size_t cap = 0;
    for (;;) {
        if (interactive) {
            fputs("msh$ ", stdout);
            fflush(stdout);
        }
        if (getline(&line, &cap, stdin) < 0)
            break;
        char *tok[MAX_TOKENS];
        Stage st[MAX_STAGES];
        char *store = malloc(2 * strlen(line) + 2);
        if (store == NULL)
            break;
        int ntok = tokenize(line, tok, MAX_TOKENS, store);
        int ns = ntok < 0 ? -1 : parse(tok, ntok, st, MAX_STAGES);
        if (ns < 0) {
            fprintf(stderr, "msh: syntax error\n");
            last_status = 2;
        } else if (ns > 0) {
            run_pipeline(st, ns);
        }
        free(store);
    }
    free(line);
    return last_status;
}
