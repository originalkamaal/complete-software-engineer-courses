// file: pipehang.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static void run(int close_write_end) {
    int fd[2];
    if (pipe(fd) < 0) return;
    if (fork() == 0) {                         /* child: write a line and exit */
        close(fd[0]);
        const char *msg = "hello through the pipe\n";
        if (write(fd[1], msg, strlen(msg)) < 0) _exit(1);
        _exit(0);
    }
    if (close_write_end) close(fd[1]);         /* the parent never writes: close its copy */
    char buf[64];
    ssize_t n, total = 0;
    alarm(2);                                  /* SIGALRM ends the process if read blocks too long */
    while ((n = read(fd[0], buf, sizeof buf)) > 0) total += n;
    alarm(0);
    printf("  read %zd bytes, then end of file\n", total);
    close(fd[0]);
    wait(NULL);
}

int main(void) {
    printf("parent closes its write end:\n");
    fflush(stdout);
    run(1);
    printf("parent forgets to close it:\n");
    fflush(stdout);
    run(0);
    printf("never reached\n");
    return 0;
}
