// file: pipeline.c
#define _POSIX_C_SOURCE 200809L
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* Runs: printf 'c\na\nb\n' | sort > sorted.txt */
int main(void) {
    int fds[2];
    if (pipe(fds) != 0) {
        perror("pipe");
        return 1;
    }
    pid_t writer = fork();
    if (writer == 0) {
        dup2(fds[1], STDOUT_FILENO);       /* stdout -> pipe's write end */
        close(fds[0]);
        close(fds[1]);                     /* the duplicate on fd 1 keeps the pipe open */
        execlp("printf", "printf", "c\\na\\nb\\n", (char *)NULL);
        _exit(127);
    }
    pid_t reader = fork();
    if (reader == 0) {
        dup2(fds[0], STDIN_FILENO);        /* stdin <- pipe's read end */
        close(fds[0]);
        close(fds[1]);                     /* essential: otherwise sort never sees end of file */
        int out = open("sorted.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (out < 0)
            _exit(1);
        dup2(out, STDOUT_FILENO);          /* > sorted.txt */
        close(out);
        execlp("sort", "sort", (char *)NULL);
        _exit(127);
    }
    close(fds[0]);                         /* the parent uses neither end */
    close(fds[1]);
    int s1, s2;
    waitpid(writer, &s1, 0);
    waitpid(reader, &s2, 0);
    printf("writer exit %d, reader exit %d\n", WEXITSTATUS(s1), WEXITSTATUS(s2));
    return 0;
}
