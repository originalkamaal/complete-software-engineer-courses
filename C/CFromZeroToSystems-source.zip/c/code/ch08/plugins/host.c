// file: plugins/host.c
#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <stdio.h>
#include "plugin.h"

int main(int argc, char *argv[]) {
    for (int i = 1; i < argc; i++) {
        void *h = dlopen(argv[i], RTLD_NOW | RTLD_LOCAL);
        if (h == NULL) {
            fprintf(stderr, "dlopen: %s\n", dlerror());
            continue;
        }
        plugin_get_fn get;
        *(void **)&get = dlsym(h, "plugin_get");   /* POSIX-blessed conversion (DT-31) */
        const Plugin *p = get ? get() : NULL;
        if (p == NULL || p->api_version != PLUGIN_API_VERSION) {
            fprintf(stderr, "%s: not a compatible plugin\n", argv[i]);
            dlclose(h);
            continue;
        }
        printf("plugin %-6s: 7 -> %d\n", p->name, p->transform(7));
        dlclose(h);                                 /* p is invalid after this */
    }
    return 0;
}
