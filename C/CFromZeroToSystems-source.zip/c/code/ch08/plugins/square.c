// file: plugins/square.c
#include "plugin.h"

static int sq(int x) { return x * x; }
static const Plugin p = {PLUGIN_API_VERSION, "square", sq};
const Plugin *plugin_get(void) { return &p; }
