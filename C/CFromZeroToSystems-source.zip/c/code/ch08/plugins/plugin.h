// file: plugins/plugin.h
#ifndef PLUGIN_H
#define PLUGIN_H

#define PLUGIN_API_VERSION 1

typedef struct {
    int api_version;
    const char *name;
    int (*transform)(int);
} Plugin;

/* Every plugin exports: const Plugin *plugin_get(void); */
typedef const Plugin *(*plugin_get_fn)(void);

#endif
