// file: plugins/double.c
#include "plugin.h"

static int twice(int x) { return 2 * x; }
static const Plugin p = {PLUGIN_API_VERSION, "double", twice};
const Plugin *plugin_get(void) { return &p; }
