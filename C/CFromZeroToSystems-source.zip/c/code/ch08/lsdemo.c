// file: lsdemo.c
#define _DEFAULT_SOURCE
#include <dirent.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static void mode_string(mode_t m, char out[11]) {
    out[0] = S_ISDIR(m) ? 'd' : S_ISLNK(m) ? 'l' : S_ISFIFO(m) ? 'p' : '-';
    const char *rwx = "rwxrwxrwx";
    for (int i = 0; i < 9; i++)
        out[i + 1] = (m & (1u << (8 - i))) ? rwx[i] : '-';
    out[10] = '\0';
}

static int cmp_names(const void *a, const void *b) {
    return strcmp(*(char *const *)a, *(char *const *)b);
}

int main(int argc, char *argv[]) {
    const char *dir = argc > 1 ? argv[1] : ".";
    DIR *d = opendir(dir);
    if (d == NULL) {
        perror(dir);
        return 1;
    }
    char *names[256];
    size_t n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && n < 256)
        if (e->d_name[0] != '.')
            names[n++] = strdup(e->d_name);
    closedir(d);
    qsort(names, n, sizeof names[0], cmp_names);   /* readdir order is arbitrary */

    for (size_t i = 0; i < n; i++) {
        char path[4096];
        snprintf(path, sizeof path, "%s/%s", dir, names[i]);
        struct stat st;
        if (lstat(path, &st) != 0) {                /* lstat: don't follow symlinks */
            perror(path);
            continue;
        }
        char mode[11];
        mode_string(st.st_mode, mode);
        printf("%s %2ju %8jd %s\n", mode, (uintmax_t)st.st_nlink, (intmax_t)st.st_size, names[i]);
        free(names[i]);
    }
    return 0;
}
