// file: signals.c
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t got_term = 0, alarms = 0;

static void on_term(int sig) {
    (void)sig;
    got_term = 1;                     /* only set a flag: async-signal-safe */
}

static void on_alarm(int sig) {
    (void)sig;
    alarms++;
    const char msg[] = "  [handler] tick\n";
    write(STDOUT_FILENO, msg, sizeof msg - 1);   /* write() is safe; printf is NOT */
}

int main(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = on_term;
    sigaction(SIGTERM, &sa, NULL);
    sa.sa_handler = on_alarm;
    sa.sa_flags = SA_RESTART;          /* restart interrupted system calls where possible */
    sigaction(SIGALRM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);          /* ignore: get EPIPE from write instead */

    setvbuf(stdout, NULL, _IONBF, 0);  /* unbuffered, so output order is obvious */
    printf("pid %d: working; SIGTERM will arrive after 3 alarms\n", (int)getpid());
    while (!got_term) {
        alarm(1);
        pause();                       /* sleep until any signal arrives */
        if (alarms == 3) {
            printf("main loop: sending myself SIGTERM\n");
            kill(getpid(), SIGTERM);
        }
    }
    printf("main loop: got SIGTERM after %d alarms; cleaning up and exiting\n", (int)alarms);
    return 0;
}
