// file: sigbus.c
#define _POSIX_C_SOURCE 200809L
#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>

int main(void) {
    long page = sysconf(_SC_PAGESIZE);
    int fd = open("mapped.dat", O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd < 0 || ftruncate(fd, 2 * page) < 0) return 1;
    char *p = mmap(NULL, 2 * page, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) return 1;
    p[0] = 'A';
    p[page] = 'B';
    printf("before truncation: p[0] = %c, p[page] = %c\n", p[0], p[page]);
    fflush(stdout);
    if (ftruncate(fd, page) < 0) return 1;       /* "another process" shrinks the file */
    printf("after truncation:  p[0] = %c\n", p[0]);
    fflush(stdout);
    printf("p[page] = %c\n", p[page]);           /* beyond the end of the file now */
    return 0;
}
