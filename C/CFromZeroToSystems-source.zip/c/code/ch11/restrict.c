// file: restrict.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Without restrict: dst might overlap src, so every store may change *scale. */
__attribute__((noipa)) void scale_plain(float *dst, const float *src, const float *scale, long n) {
    for (long i = 0; i < n; i++)
        dst[i] = src[i] * *scale;
}

/* With restrict: the caller promises no overlap, so *scale is loaded once and the loop vectorised. */
__attribute__((noipa)) void scale_restrict(float *restrict dst, const float *restrict src,
                                              const float *restrict scale, long n) {
    for (long i = 0; i < n; i++)
        dst[i] = src[i] * *scale;
}

static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

int main(void) {
    enum { N = 4096, REPS = 200000 };
    float *a = malloc(N * sizeof *a), *b = malloc(N * sizeof *b), s = 1.0001f;
    for (int i = 0; i < N; i++) a[i] = (float)i;
    double t0 = secs();
    for (int r = 0; r < REPS; r++) scale_plain(b, a, &s, N);
    double t1 = secs();
    for (int r = 0; r < REPS; r++) scale_restrict(b, a, &s, N);
    double t2 = secs();
    printf("plain: %.0f ms, restrict: %.0f ms (%.1fx), check %.1f\n",
           (t1 - t0) * 1e3, (t2 - t1) * 1e3, (t1 - t0) / (t2 - t1), b[N - 1]);
    free(a);
    free(b);
    return 0;
}
