// file: latency.c
/* Measure memory latency: chase a random cyclic chain of pointers through
   buffers of increasing size. Each load depends on the previous one, so the
   time per step is the latency of whichever cache level holds the buffer. */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

int main(void) {
    printf("%10s %10s\n", "buffer", "ns/load");
    for (size_t kb = 16; kb <= 256 * 1024; kb *= 4) {
        size_t n = kb * 1024 / 64;                      /* one pointer per 64-byte line */
        char *mem = aligned_alloc(64, n * 64);
        size_t *order = malloc(n * sizeof *order);
        for (size_t i = 0; i < n; i++) order[i] = i;
        srand(1);
        for (size_t i = n - 1; i > 0; i--) {            /* random permutation (Fisher-Yates) */
            size_t j = (size_t)rand() % (i + 1);
            size_t t = order[i]; order[i] = order[j]; order[j] = t;
        }
        for (size_t i = 0; i < n; i++)                  /* link lines into one random cycle */
            *(void **)(mem + order[i] * 64) = mem + order[(i + 1) % n] * 64;
        void **p = (void **)(mem + order[0] * 64);
        long steps = 20000000;
        double t0 = secs();
        for (long s = 0; s < steps; s++)
            p = *p;
        double t1 = secs();
        printf("%7zu KB %10.1f%s\n", kb, (t1 - t0) / steps * 1e9, p == NULL ? "!" : "");
        free(mem);
        free(order);
    }
    return 0;
}
