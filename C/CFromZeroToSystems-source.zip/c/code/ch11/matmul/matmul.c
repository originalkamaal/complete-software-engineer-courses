// file: matmul/matmul.c
/* Dense matrix multiply, five versions, each verified against the naive result. */
#define _POSIX_C_SOURCE 200809L
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

enum { N = 1024, BS = 64 };

static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

static void naive(const double *restrict A, const double *restrict B, double *restrict C) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            double s = 0;
            for (int k = 0; k < N; k++)
                s += A[i * N + k] * B[k * N + j];        /* B walked down a column */
            C[i * N + j] = s;
        }
}

static void interchanged(const double *restrict A, const double *restrict B, double *restrict C) {
    memset(C, 0, sizeof(double) * N * N);
    for (int i = 0; i < N; i++)
        for (int k = 0; k < N; k++) {
            double a = A[i * N + k];
            for (int j = 0; j < N; j++)                  /* B and C walked along rows */
                C[i * N + j] += a * B[k * N + j];
        }
}

/* blocked multiplies rows [r0, r1) of C, tile by tile. */
static void blocked_rows(const double *restrict A, const double *restrict B, double *restrict C,
                         int r0, int r1) {
    for (int ii = r0; ii < r1; ii += BS)
        for (int kk = 0; kk < N; kk += BS)
            for (int jj = 0; jj < N; jj += BS)
                for (int i = ii; i < ii + BS && i < r1; i++)
                    for (int k = kk; k < kk + BS; k++) {
                        double a = A[i * N + k];
                        for (int j = jj; j < jj + BS; j++)
                            C[i * N + j] += a * B[k * N + j];
                    }
}

static void blocked(const double *A, const double *B, double *C) {
    memset(C, 0, sizeof(double) * N * N);
    blocked_rows(A, B, C, 0, N);
}

typedef struct { const double *A, *B; double *C; int r0, r1; } Part;
static void *part_worker(void *arg) {
    Part *p = arg;
    blocked_rows(p->A, p->B, p->C, p->r0, p->r1);
    return NULL;
}

static void threaded(const double *A, const double *B, double *C) {
    enum { T = 2 };
    memset(C, 0, sizeof(double) * N * N);
    pthread_t t[T];
    Part parts[T];
    for (int i = 0; i < T; i++) {
        parts[i] = (Part){A, B, C, N / T * i, N / T * (i + 1)};   /* disjoint rows: no sharing */
        pthread_create(&t[i], NULL, part_worker, &parts[i]);
    }
    for (int i = 0; i < T; i++)
        pthread_join(t[i], NULL);
}

static double max_diff(const double *X, const double *Y) {
    double m = 0;
    for (long i = 0; i < (long)N * N; i++)
        m = fmax(m, fabs(X[i] - Y[i]));
    return m;
}

int main(void) {
    double *A = malloc(sizeof(double) * N * N), *B = malloc(sizeof(double) * N * N);
    double *ref = malloc(sizeof(double) * N * N), *C = malloc(sizeof(double) * N * N);
    srand(5);
    for (long i = 0; i < (long)N * N; i++) {
        A[i] = rand() / (double)RAND_MAX - 0.5;
        B[i] = rand() / (double)RAND_MAX - 0.5;
    }
    const double flops = 2.0 * N * N * N;
    struct { const char *name; void (*fn)(const double *, const double *, double *); } v[] = {
        {"naive i-j-k", naive}, {"interchanged i-k-j", interchanged},
        {"blocked 64x64", blocked}, {"blocked + 2 threads", threaded},
    };
    double base = 0;
    for (int k = 0; k < 4; k++) {
        double best = 1e9;
        for (int rep = 0; rep < (k == 0 ? 1 : 3); rep++) {   /* best of 3 (naive: 1, it is slow) */
            double t0 = secs();
            v[k].fn(A, B, k == 0 ? ref : C);
            double t = secs() - t0;
            if (t < best) best = t;
        }
        if (k == 0) base = best;
        printf("%-22s %8.1f ms %6.2f GFLOP/s %6.1fx  max error %.1e\n", v[k].name, best * 1e3,
               flops / best / 1e9, base / best, k == 0 ? 0.0 : max_diff(C, ref));
    }
    free(A); free(B); free(C); free(ref);
    return 0;
}
