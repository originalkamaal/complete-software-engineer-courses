// file: asm1.c
int add(int a, int b) { return a + b; }

long sum(const int *a, long n) {
    long s = 0;
    for (long i = 0; i < n; i++)
        s += a[i];
    return s;
}

int is_even(unsigned x) { return x % 2 == 0; }

int div10(int x) { return x / 10; }
