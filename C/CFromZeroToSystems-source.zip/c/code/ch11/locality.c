// file: locality.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum { N = 4096 };
static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

typedef struct { double x, y, z, mass; char name[32]; } ParticleAoS;   /* array of structs */
typedef struct { double *x, *y, *z, *mass; } ParticlesSoA;             /* struct of arrays */

int main(void) {
    double (*m)[N] = malloc(sizeof(double[N][N]));      /* 128 MB matrix */
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            m[i][j] = 1.0;
    double s = 0, t0 = secs();
    for (int i = 0; i < N; i++)                         /* row by row: sequential */
        for (int j = 0; j < N; j++)
            s += m[i][j];
    double t1 = secs();
    for (int j = 0; j < N; j++)                         /* column by column: 32 KB stride */
        for (int i = 0; i < N; i++)
            s += m[i][j];
    double t2 = secs();
    printf("row-major traversal %.0f ms, column-major %.0f ms (%.1fx slower)\n",
           (t1 - t0) * 1e3, (t2 - t1) * 1e3, (t2 - t1) / (t1 - t0));
    free(m);

    enum { P = 4000000 };
    ParticleAoS *aos = calloc(P, sizeof *aos);
    ParticlesSoA soa = {calloc(P, 8), calloc(P, 8), calloc(P, 8), calloc(P, 8)};
    double sx = 0;
    t0 = secs();
    for (int i = 0; i < P; i++) sx += aos[i].x;         /* uses 8 of every 64 bytes loaded */
    t1 = secs();
    for (int i = 0; i < P; i++) sx += soa.x[i];         /* uses every byte loaded */
    t2 = secs();
    printf("sum of x: array of structs %.1f ms, struct of arrays %.1f ms (sizeof AoS element %zu)\n",
           (t1 - t0) * 1e3, (t2 - t1) * 1e3, sizeof *aos);
    printf("%g\n", s + sx);
    return 0;
}
