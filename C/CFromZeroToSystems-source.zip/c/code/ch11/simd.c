// file: simd.c
#define _POSIX_C_SOURCE 200809L
#include <immintrin.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

__attribute__((noipa)) static float dot_scalar(const float *a, const float *b, int n) {
    float s = 0;
    for (int i = 0; i < n; i++)
        s += a[i] * b[i];        /* float addition is not associative: no vectorising without -ffast-math */
    return s;
}

__attribute__((noipa, target("avx2,fma"))) static float dot_avx2(const float *a, const float *b, int n) {
    __m256 acc0 = _mm256_setzero_ps(), acc1 = _mm256_setzero_ps();
    int i = 0;
    for (; i + 16 <= n; i += 16) {           /* two accumulators hide the FMA latency */
        acc0 = _mm256_fmadd_ps(_mm256_loadu_ps(a + i), _mm256_loadu_ps(b + i), acc0);
        acc1 = _mm256_fmadd_ps(_mm256_loadu_ps(a + i + 8), _mm256_loadu_ps(b + i + 8), acc1);
    }
    __m256 acc = _mm256_add_ps(acc0, acc1);
    float lanes[8];
    _mm256_storeu_ps(lanes, acc);
    float s = 0;
    for (int k = 0; k < 8; k++)
        s += lanes[k];
    for (; i < n; i++)                       /* leftover elements */
        s += a[i] * b[i];
    return s;
}

int main(void) {
    enum { N = 4096, REPS = 200000 };
    float *a = aligned_alloc(32, N * sizeof *a), *b = aligned_alloc(32, N * sizeof *b);
    for (int i = 0; i < N; i++) { a[i] = (float)(i % 7) * 0.5f; b[i] = (float)(i % 5) * 0.25f; }
    float r1 = 0, r2 = 0;
    double t0 = secs();
    for (int k = 0; k < REPS; k++) r1 += dot_scalar(a, b, N);
    double t1 = secs();
    for (int k = 0; k < REPS; k++) r2 += dot_avx2(a, b, N);
    double t2 = secs();
    printf("scalar %.0f ms, AVX2+FMA %.0f ms: %.1fx faster; results %.6g vs %.6g\n",
           (t1 - t0) * 1e3, (t2 - t1) * 1e3, (t1 - t0) / (t2 - t1), r1 / REPS, r2 / REPS);
    printf("this CPU supports AVX2: %s, AVX-512F: %s\n",
           __builtin_cpu_supports("avx2") ? "yes" : "no", __builtin_cpu_supports("avx512f") ? "yes" : "no");
    return 0;
}
