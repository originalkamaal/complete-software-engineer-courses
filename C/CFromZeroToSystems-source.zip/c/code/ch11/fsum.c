// file: fsum.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

__attribute__((noipa)) static float sum(const float *a, size_t n) {   /* noipa: no cross-call assumptions */
    float s = 0.0f;
    for (size_t i = 0; i < n; i++) s += a[i];
    return s;
}

int main(void) {
    enum { N = 1 << 20, REPS = 200 };
    float *a = malloc(N * sizeof *a);
    srand(1);
    for (size_t i = 0; i < N; i++) a[i] = (float)rand() / RAND_MAX;
    struct timespec t0, t1;
    float s = 0;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (int r = 0; r < REPS; r++) s = sum(a, N);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double ms = ((t1.tv_sec - t0.tv_sec) * 1e3 + (t1.tv_nsec - t0.tv_nsec) / 1e6) / REPS;
    printf("sum = %.6f   %.3f ms per sum of %d floats\n", s, ms, N);
    free(a);
    return 0;
}
