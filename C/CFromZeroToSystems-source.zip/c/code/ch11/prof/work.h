// file: prof/work.h
#ifndef WORK_H
#define WORK_H
int classify(int x);
double heavy(int n);
#endif
