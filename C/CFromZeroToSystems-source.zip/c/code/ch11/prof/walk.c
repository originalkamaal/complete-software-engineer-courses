// file: prof/walk.c
#include <stdio.h>
#include <stdlib.h>
enum { N = 2048 };
int main(int argc, char *argv[]) {
    static double m[N][N];
    for (int a = 0; a < N; a++)              /* fill at run time: a never-written static */
        for (int b = 0; b < N; b++)          /* array is all zeros, and the compiler would */
            m[a][b] = a ^ b;                 /* fold the whole sum to a constant           */
    double s = 0;
    int by_column = argc > 1;
    for (int a = 0; a < N; a++)
        for (int b = 0; b < N; b++)
            s += by_column ? m[b][a] : m[a][b];
    printf("%g\n", s);
    return 0;
}
