// file: prof/work.c
#include "work.h"

int classify(int x) {                         /* in a separate file: not inlinable without LTO */
    if (x % 97 == 0) return 3;
    if (x % 13 == 0) return 2;
    if (x & 1) return 1;
    return 0;
}

double heavy(int n) {
    double s = 0;
    for (int i = 1; i <= n; i++)
        s += 1.0 / ((double)i * i);
    return s;
}
