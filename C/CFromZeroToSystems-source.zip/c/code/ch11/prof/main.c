// file: prof/main.c
#include <stdio.h>
#include "work.h"

int main(void) {
    long counts[4] = {0};
    for (int i = 0; i < 300000000; i++)
        counts[classify(i)]++;
    printf("counts %ld %ld %ld %ld, heavy %.6f\n", counts[0], counts[1], counts[2], counts[3], heavy(50000000));
    return 0;
}
