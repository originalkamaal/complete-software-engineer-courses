// file: branches.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum { N = 1 << 22, REPS = 100 };
static double secs(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}
static int cmp(const void *a, const void *b) { return *(const int *)a - *(const int *)b; } /* values 0..255: no overflow */

__attribute__((noipa)) static long sum_big_branchy(const int *a, int n) {
    long s = 0;
    for (int i = 0; i < n; i++)
        if (a[i] >= 128)                 /* unpredictable when data is random */
            s += a[i];
    return s;
}

__attribute__((noipa)) static long sum_big_branchless(const int *a, int n) {
    long s = 0;
    for (int i = 0; i < n; i++) {
        int mask = -(a[i] >= 128);      /* all ones or all zeros */
        s += a[i] & mask;
    }
    return s;
}

int main(void) {
    int *a = malloc(N * sizeof *a);
    srand(3);
    for (int i = 0; i < N; i++) a[i] = rand() % 256;
    long r = 0;
    double t0 = secs();
    for (int k = 0; k < REPS; k++) r += sum_big_branchy(a, N);
    double t1 = secs();
    for (int k = 0; k < REPS; k++) r += sum_big_branchless(a, N);
    double t2 = secs();
    qsort(a, N, sizeof *a, cmp);
    double t3 = secs();
    for (int k = 0; k < REPS; k++) r += sum_big_branchy(a, N);
    double t4 = secs();
    printf("random data:  branchy %4.0f ms, branchless %4.0f ms\n", (t1 - t0) * 1e3, (t2 - t1) * 1e3);
    printf("sorted data:  branchy %4.0f ms\n", (t4 - t3) * 1e3);
    printf("(checksum %ld)\n", r);
    return 0;
}
