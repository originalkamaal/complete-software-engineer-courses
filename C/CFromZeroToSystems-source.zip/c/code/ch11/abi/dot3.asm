; file: abi/dot3.asm
; long dot3(const long *a, const long *b) -- dot product of two 3-element vectors
; System V AMD64: a in rdi, b in rsi, result in rax. Uses only caller-saved registers.
        global  dot3
        section .text
dot3:
        mov     rax, [rdi]          ; rax = a[0]
        imul    rax, [rsi]          ; rax *= b[0]
        mov     rcx, [rdi + 8]      ; rcx = a[1]
        imul    rcx, [rsi + 8]      ; rcx *= b[1]
        add     rax, rcx
        mov     rcx, [rdi + 16]     ; a[2] * b[2]
        imul    rcx, [rsi + 16]
        add     rax, rcx
        ret

        section .note.GNU-stack noalloc noexec nowrite progbits   ; "this code needs no executable stack"
