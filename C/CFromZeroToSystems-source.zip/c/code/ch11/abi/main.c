// file: abi/main.c
#include <stdint.h>
#include <stdio.h>

long dot3(const long *a, const long *b);     /* implemented in dot3.asm */

static inline uint64_t rdtsc(void) {          /* inline assembly: read the CPU's timestamp counter */
    uint32_t lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return (uint64_t)hi << 32 | lo;
}

int main(void) {
    long a[3] = {1, 2, 3}, b[3] = {4, 5, 6};
    uint64_t t0 = rdtsc();
    long d = dot3(a, b);
    uint64_t t1 = rdtsc();
    printf("dot3 = %ld (expected 32), took about %llu reference cycles including the call\n",
           d, (unsigned long long)(t1 - t0));
    return 0;
}
