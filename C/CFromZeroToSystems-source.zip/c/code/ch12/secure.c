// file: secure.c
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <sys/random.h>
#include <unistd.h>

/* constant_time_equal compares without an early exit, so timing reveals nothing
   about where the first difference is. */
static int constant_time_equal(const unsigned char *a, const unsigned char *b, size_t n) {
    unsigned char diff = 0;
    for (size_t i = 0; i < n; i++)
        diff |= a[i] ^ b[i];
    return diff == 0;
}

int main(void) {
    unsigned char token[16];
    if (getrandom(token, sizeof token, 0) != (ssize_t)sizeof token)   /* kernel CSPRNG */
        return 1;
    printf("session token: ");
    for (size_t i = 0; i < sizeof token; i++)
        printf("%02x", token[i]);
    printf(" (from getrandom; never use rand() for this)\n");

    char password[64];
    snprintf(password, sizeof password, "hunter2");          /* pretend it came from input */
    unsigned char a[4] = {1, 2, 3, 4}, b[4] = {1, 2, 3, 5};
    printf("constant-time compare: %d %d\n", constant_time_equal(a, a, 4), constant_time_equal(a, b, 4));
    explicit_bzero(password, sizeof password);                 /* memset could be optimised away */
    printf("password buffer cleared: first byte = %d\n", password[0]);
    printf("running as uid %d (a server should drop root privileges after setup)\n", (int)getuid());
    return 0;
}
