// file: smash.c
#include <stdio.h>
#include <string.h>

static void greet(const char *name) {
    char buf[16];
    strcpy(buf, name);          /* overflow when name has 16+ characters */
    printf("hello, %s\n", buf);
}

int main(int argc, char *argv[]) {
    greet(argc > 1 ? argv[1] : "world");
    return 0;
}
