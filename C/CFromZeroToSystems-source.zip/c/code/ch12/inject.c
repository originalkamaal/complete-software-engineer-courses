// file: inject.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* BAD: the file name is pasted into a shell command line. */
static void count_lines_bad(const char *file) {
    char cmd[256];
    snprintf(cmd, sizeof cmd, "wc -l < %s", file);
    system(cmd);
}

/* GOOD: no shell; the file name is one argument, whatever characters it contains. */
static void count_lines_good(const char *file) {
    pid_t pid = fork();
    if (pid == 0) {
        execlp("wc", "wc", "-l", "--", file, (char *)NULL);   /* "--": file can't be an option */
        _exit(127);
    }
    waitpid(pid, NULL, 0);
}

int main(int argc, char *argv[]) {
    const char *file = argc > 1 ? argv[1] : "/etc/hostname";
    printf("bad:  ");
    fflush(stdout);
    count_lines_bad(file);
    printf("good: ");
    fflush(stdout);
    count_lines_good(file);
    return 0;
}
