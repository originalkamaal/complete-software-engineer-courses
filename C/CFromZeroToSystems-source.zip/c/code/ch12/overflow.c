// file: overflow.c
#include <stdio.h>
#include <string.h>

struct session {
    char name[16];
    int is_admin;            /* lies right after name in memory */
};

/* login copies the user name without checking its length: the classic bug. */
static void login(struct session *s, const char *input) {
    strcpy(s->name, input);
}

int main(int argc, char *argv[]) {
    struct session s = {.is_admin = 0};
    login(&s, argc > 1 ? argv[1] : "alice");
    printf("name=\"%.16s\" is_admin=%d (0x%08x)\n", s.name, s.is_admin, (unsigned)s.is_admin);
    if (s.is_admin)
        printf("access granted to admin functions!\n");
    return 0;
}
