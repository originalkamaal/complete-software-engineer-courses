// file: ckdsize.c
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* allocate count records of size bytes each, plus a header; NULL if any step overflows */
static void *alloc_records(size_t header, size_t count, size_t size) {
    size_t body, total;
    if (__builtin_mul_overflow(count, size, &body) || __builtin_add_overflow(header, body, &total))
        return NULL;
    return malloc(total);
}

int main(void) {
    size_t count = SIZE_MAX / 8 + 2, size = 8;                 /* count * size wraps around to 8 */
    printf("count * size computed naively = %zu\n", count * size);
    void *naive = malloc(count * size);                        /* asks for 8 bytes, "succeeds" */
    printf("malloc(count * size): %s\n", naive ? "returned a tiny buffer - every later write overflows it" : "NULL");
    free(naive);

    void *checked = alloc_records(16, count, size);
    printf("checked allocation: %s\n", checked ? "succeeded" : "refused (overflow detected)");
    void *z = calloc(count, size);                             /* calloc must check the product itself */
    printf("calloc(count, size): %s\n", z ? "succeeded" : "NULL (calloc detected the overflow)");
    free(z);

    void *ok = alloc_records(16, 1000, 24);
    printf("alloc_records(16, 1000, 24): %s\n", ok ? "succeeded" : "refused");
    free(ok);
    return 0;
}
