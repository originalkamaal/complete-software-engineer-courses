// file: fuzzdemo/parse_kv.c
/* parse_kv parses "key=value;key=value" and returns the number of pairs.
   It contains a bug that only a specific input shape triggers. */
#include <stddef.h>
#include <stdint.h>
#include <string.h>

int parse_kv(const uint8_t *data, size_t size) {
    char key[8];
    int pairs = 0;
    size_t i = 0;
    while (i < size) {
        size_t k = 0;
        while (i < size && data[i] != '=') {
            if (k < sizeof key)          /* bounds check on the key ... */
                key[k] = (char)data[i];
            k++;
            i++;
        }
        if (i == size)
            break;
        key[k] = '\0';                   /* ... but not here: k can be >= 8 */
        i++;                             /* skip '=' */
        while (i < size && data[i] != ';')
            i++;
        i++;                             /* skip ';' */
        pairs++;
    }
    return pairs;
}
