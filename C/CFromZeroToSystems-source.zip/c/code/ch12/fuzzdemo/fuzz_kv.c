// file: fuzzdemo/fuzz_kv.c
#include <stddef.h>
#include <stdint.h>

int parse_kv(const uint8_t *data, size_t size);

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    parse_kv(data, size);
    return 0;                            /* 0: input processed; crashes are reported by sanitizers */
}
