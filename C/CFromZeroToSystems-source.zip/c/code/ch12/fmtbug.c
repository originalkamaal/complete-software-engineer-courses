// file: fmtbug.c
#include <stdio.h>

int main(int argc, char *argv[]) {
    int secret = 0x5EC12E7;
    const char *input = argc > 1 ? argv[1] : "hello";
    printf("safe:   ");
    printf("%s", input);            /* data as an argument */
    printf("\nunsafe: ");
    printf(input);                  /* data as the format: BUG */
    printf("\n");
    (void)secret;
    return 0;
}
