// file: hardening/hello.c
#include <stdio.h>
int main(void) { puts("hello"); return 0; }
