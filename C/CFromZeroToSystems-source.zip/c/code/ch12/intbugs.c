// file: intbugs.c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Vulnerable: count * size can wrap around, producing a tiny allocation. */
static void *alloc_records_bad(uint32_t count, uint32_t size) {
    uint32_t total = count * size;                    /* 32-bit wrap */
    printf("  bad:  count=%u size=%u -> allocating %u bytes\n", count, size, total);
    return malloc(total);
}

/* Fixed: check before multiplying, in the type used for the allocation. */
static void *alloc_records_good(uint32_t count, uint32_t size) {
    if (size != 0 && count > SIZE_MAX / size) {
        printf("  good: count=%u size=%u -> rejected (overflow)\n", count, size);
        return NULL;
    }
    size_t total = (size_t)count * size;
    printf("  good: count=%u size=%u -> allocating %zu bytes\n", count, size, total);
    return malloc(total);
}

/* Vulnerable: a signed length passes the check when negative, then becomes huge. */
static int copy_bad(char *dst, size_t dstsz, const char *src, int len) {
    if (len > (int)dstsz)                             /* -1 passes this check */
        return -1;
    printf("  copy_bad would memcpy %zu bytes into a %zu-byte buffer\n", (size_t)len, dstsz);
    return 0;                                         /* (not actually copying) */
}

int main(void) {
    /* 0x10000001 records of 16 bytes = 2^32 + 16 bytes: wraps to 16 in 32 bits */
    free(alloc_records_bad(0x10000001u, 16));
    free(alloc_records_good(0x10000001u, 16));
    char buf[32];
    copy_bad(buf, sizeof buf, "x", -1);
    return 0;
}
