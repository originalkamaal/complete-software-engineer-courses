// file: beneath.c
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/openat2.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

static void try(int root, const char *path) {
    struct open_how how = { .flags = O_RDONLY, .resolve = RESOLVE_BENEATH };
    long fd = syscall(SYS_openat2, root, path, &how, sizeof how);
    printf("  %-22s %s\n", path, fd >= 0 ? "opened" : strerror(errno));
    if (fd >= 0) close((int)fd);
}

int main(void) {
    mkdir("www", 0755);
    FILE *f = fopen("www/index.html", "w");
    if (f) { fputs("hi\n", f); fclose(f); }
    unlink("www/escape");
    if (symlink("/etc/hostname", "www/escape") < 0) perror("symlink");
    int root = open("www", O_DIRECTORY | O_RDONLY);
    printf("openat2 with RESOLVE_BENEATH, relative to www/:\n");
    try(root, "index.html");
    try(root, "../beneath.c");
    try(root, "/etc/hostname");
    try(root, "escape");                     /* a symlink pointing outside: no string check would see it */
    close(root);
    return 0;
}
