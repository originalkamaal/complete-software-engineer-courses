// file: tlv/fuzz_tlv.c
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct { char name[32]; int age; char *tags[8]; int ntags; } Person;
int tlv_parse(const uint8_t *p, size_t n, Person *out);
void tlv_free(Person *p);

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    Person p;
    if (tlv_parse(data, size, &p) == 0)
        tlv_free(&p);
    return 0;
}
