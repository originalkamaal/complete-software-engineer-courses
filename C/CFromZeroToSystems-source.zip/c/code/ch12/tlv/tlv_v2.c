// file: tlv/tlv_v2.c
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[32];
    int age;
    char *tags[8];
    int ntags;
} Person;

enum { TLV_OK = 0, TLV_ERR = -1 };

/* A cursor over untrusted bytes: every read is checked against what remains (P-11). */
typedef struct { const uint8_t *p; size_t left; } Cursor;

static int take(Cursor *c, size_t n, const uint8_t **out) {
    if (n > c->left)
        return TLV_ERR;
    *out = c->p;
    c->p += n;
    c->left -= n;
    return TLV_OK;
}

static int take_u8(Cursor *c, uint8_t *v) {
    const uint8_t *b;
    if (take(c, 1, &b) != TLV_OK) return TLV_ERR;
    *v = b[0];
    return TLV_OK;
}

static int take_u16be(Cursor *c, uint16_t *v) {
    const uint8_t *b;
    if (take(c, 2, &b) != TLV_OK) return TLV_ERR;
    *v = (uint16_t)(b[0] << 8 | b[1]);
    return TLV_OK;
}

void tlv_free(Person *p) {
    for (int i = 0; i < p->ntags; i++)
        free(p->tags[i]);
    p->ntags = 0;
}

static int parse_tags(Person *out, Cursor *c) {
    while (c->left > 0) {
        uint8_t tl;
        const uint8_t *s;
        if (out->ntags == (int)(sizeof out->tags / sizeof out->tags[0]))
            return TLV_ERR;                                   /* fixes D */
        if (take_u8(c, &tl) != TLV_OK || take(c, tl, &s) != TLV_OK)
            return TLV_ERR;                                   /* fixes E */
        char *tag = malloc((size_t)tl + 1);
        if (tag == NULL)
            return TLV_ERR;
        memcpy(tag, s, tl);
        tag[tl] = '\0';
        out->tags[out->ntags++] = tag;
    }
    return TLV_OK;
}

int tlv_parse(const uint8_t *p, size_t n, Person *out) {
    memset(out, 0, sizeof *out);
    Cursor c = {p, n};
    const uint8_t *magic;
    uint8_t count;
    if (take(&c, 2, &magic) != TLV_OK || magic[0] != 'T' || magic[1] != 'L' ||
        take_u8(&c, &count) != TLV_OK)
        return TLV_ERR;
    for (int r = 0; r < count; r++) {
        uint8_t type;
        uint16_t len;
        const uint8_t *v;
        if (take_u8(&c, &type) != TLV_OK || take_u16be(&c, &len) != TLV_OK ||   /* fixes A */
            take(&c, len, &v) != TLV_OK)                                        /* fixes B */
            goto fail;
        Cursor value = {v, len};
        switch (type) {
        case 1:
            if (len >= sizeof out->name)                                         /* fixes C */
                goto fail;
            memcpy(out->name, v, len);
            out->name[len] = '\0';
            break;
        case 2:
            if (len != 1)
                goto fail;
            out->age = v[0];
            break;
        case 3:
            if (parse_tags(out, &value) != TLV_OK)
                goto fail;
            break;
        default:
            goto fail;                                       /* unknown type: reject, don't guess */
        }
    }
    if (c.left != 0)
        goto fail;                                           /* trailing garbage */
    return TLV_OK;
fail:
    tlv_free(out);                                           /* no leaks on any error path */
    return TLV_ERR;
}
