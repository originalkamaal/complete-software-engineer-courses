// file: tlv/mkseed.c
#include <stdio.h>
int main(void) {
    const unsigned char msg[] = {'T', 'L', 3,
        1, 0, 5, 'a', 'l', 'i', 'c', 'e',          /* name "alice" */
        2, 0, 1, 30,                                /* age 30 */
        3, 0, 8, 3, 'c', 'o', 'w', 3, 'd', 'o', 'g'};   /* tags "cow", "dog" */
    FILE *f = fopen("seeds/valid.tlv", "wb");
    if (f == NULL) return 1;
    fwrite(msg, 1, sizeof msg, f);
    return fclose(f) != 0;
}
