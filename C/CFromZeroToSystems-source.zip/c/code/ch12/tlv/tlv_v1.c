// file: tlv/tlv_v1.c
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[32];
    int age;
    char *tags[8];
    int ntags;
} Person;

int tlv_parse(const uint8_t *p, size_t n, Person *out) {
    memset(out, 0, sizeof *out);
    if (n < 3 || p[0] != 'T' || p[1] != 'L')
        return -1;
    int count = p[2];
    size_t off = 3;
    for (int r = 0; r < count; r++) {
        uint8_t type = p[off];                               /* bug A: off may be >= n */
        uint16_t len = (uint16_t)(p[off + 1] << 8 | p[off + 2]);
        off += 3;
        const uint8_t *v = p + off;                          /* bug B: len not checked vs n */
        switch (type) {
        case 1:
            memcpy(out->name, v, len);                       /* bug C: len not checked vs 32 */
            out->name[len] = '\0';
            break;
        case 2:
            out->age = v[0];
            break;
        case 3:
            for (size_t t = 0; t < len;) {
                uint8_t tl = v[t];
                out->tags[out->ntags] = malloc(tl + 1);      /* bug D: ntags not checked vs 8 */
                memcpy(out->tags[out->ntags], v + t + 1, tl);/* bug E: tl not checked vs len */
                out->tags[out->ntags][tl] = '\0';
                out->ntags++;
                t += 1u + tl;
            }
            break;
        }
        off += len;
    }
    return 0;
}

void tlv_free(Person *p) {
    for (int i = 0; i < p->ntags; i++)
        free(p->tags[i]);
}
