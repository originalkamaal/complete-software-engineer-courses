// file: byteorder.c
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>

static int listen_on(unsigned short port_field) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_port = port_field, .sin_addr.s_addr = htonl(INADDR_LOOPBACK) };
    if (bind(s, (struct sockaddr *)&a, sizeof a) < 0 || listen(s, 1) < 0) return -1;
    socklen_t len = sizeof a;
    getsockname(s, (struct sockaddr *)&a, &len);
    printf("  asked for field value 0x%04x -> listening on port %u\n", port_field, ntohs(a.sin_port));
    return s;
}

int main(void) {
    printf("8080 = 0x%04x; htons(8080) = 0x%04x in memory order\n", 8080, htons(8080));
    int good = listen_on(htons(8080));
    int bad = listen_on(8080);                       /* bug: host byte order */
    close(good);
    close(bad);
    return 0;
}
