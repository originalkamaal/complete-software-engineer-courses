// file: udptrunc.c
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
    int r = socket(AF_INET, SOCK_DGRAM, 0), s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_addr.s_addr = htonl(INADDR_LOOPBACK) };
    socklen_t len = sizeof a;
    bind(r, (struct sockaddr *)&a, sizeof a);                  /* port 0: the kernel picks one */
    getsockname(r, (struct sockaddr *)&a, &len);

    char msg[100];
    memset(msg, 'x', sizeof msg);
    sendto(s, msg, sizeof msg, 0, (struct sockaddr *)&a, sizeof a);
    sendto(s, msg, sizeof msg, 0, (struct sockaddr *)&a, sizeof a);

    char buf[40];
    ssize_t n = recv(r, buf, sizeof buf, 0);
    printf("100-byte datagram, 40-byte buffer: recv returned %zd\n", n);
    n = recv(r, buf, sizeof buf, MSG_TRUNC);
    printf("same again with MSG_TRUNC: recv returned %zd (the real size; 40 bytes copied)\n", n);
    n = recv(r, buf, sizeof buf, MSG_DONTWAIT);
    printf("next recv: %zd - the other 60 bytes of each datagram are gone\n", n);
    close(r);
    close(s);
    return 0;
}
