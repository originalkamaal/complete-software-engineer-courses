// file: resolve.c
#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    const char *host = argc > 1 ? argv[1] : "localhost";
    struct addrinfo hints = {.ai_family = AF_UNSPEC, .ai_socktype = SOCK_STREAM};
    struct addrinfo *res;
    int rc = getaddrinfo(host, "http", &hints, &res);     /* service "http" -> port 80 */
    if (rc != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rc));
        return 1;
    }
    for (struct addrinfo *ai = res; ai != NULL; ai = ai->ai_next) {
        char ip[INET6_ADDRSTRLEN];
        unsigned port;
        if (ai->ai_family == AF_INET) {
            struct sockaddr_in *s = (struct sockaddr_in *)ai->ai_addr;
            inet_ntop(AF_INET, &s->sin_addr, ip, sizeof ip);
            port = ntohs(s->sin_port);                    /* network to host byte order */
        } else {
            struct sockaddr_in6 *s = (struct sockaddr_in6 *)ai->ai_addr;
            inet_ntop(AF_INET6, &s->sin6_addr, ip, sizeof ip);
            port = ntohs(s->sin6_port);
        }
        printf("%s -> %s port %u (%s)\n", host, ip, port, ai->ai_family == AF_INET ? "IPv4" : "IPv6");
    }
    freeaddrinfo(res);

    unsigned short p = 8080;
    printf("8080 = 0x%04x in host order; htons gives 0x%04x\n", p, htons(p));
    return 0;
}
