// file: evhttpd/loadgen.c
/* loadgen: C concurrent keep-alive connections, each sending requests for D seconds. */
#define _GNU_SOURCE
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int port;
static double duration;
static const char *path;

static double now(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

typedef struct { long requests, errors; double lat_sum, lat_max; } Stats;

static void *client(void *arg) {
    Stats *s = arg;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {.sin_family = AF_INET, .sin_port = htons((uint16_t)port),
                            .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    if (connect(fd, (struct sockaddr *)&a, sizeof a) != 0) { s->errors++; return NULL; }
    char req[256], buf[65536];
    int rlen = snprintf(req, sizeof req, "GET %s HTTP/1.1\r\nHost: x\r\n\r\n", path);
    double end = now() + duration;
    while (now() < end) {
        double t0 = now();
        if (write(fd, req, (size_t)rlen) != rlen) { s->errors++; break; }
        /* read the head, find Content-Length, then read exactly the body */
        size_t got = 0;
        char *hend = NULL;
        while ((hend = memmem(buf, got, "\r\n\r\n", 4)) == NULL) {
            ssize_t n = read(fd, buf + got, sizeof buf - got);
            if (n <= 0) { s->errors++; goto out; }
            got += (size_t)n;
        }
        char *cl = strcasestr(buf, "Content-Length:");
        long body = cl ? atol(cl + 15) : 0, have = (long)(got - (size_t)(hend + 4 - buf));
        while (have < body) {
            ssize_t n = read(fd, buf, sizeof buf);
            if (n <= 0) { s->errors++; goto out; }
            have += n;
        }
        double lat = now() - t0;
        s->requests++;
        s->lat_sum += lat;
        if (lat > s->lat_max) s->lat_max = lat;
    }
out:
    close(fd);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 5) { fprintf(stderr, "usage: loadgen PORT PATH CONNECTIONS SECONDS\n"); return 2; }
    port = atoi(argv[1]);
    path = argv[2];
    int conns = atoi(argv[3]);
    duration = atof(argv[4]);
    pthread_t *t = calloc((size_t)conns, sizeof *t);
    Stats *st = calloc((size_t)conns, sizeof *st);
    for (int i = 0; i < conns; i++) pthread_create(&t[i], NULL, client, &st[i]);
    Stats total = {0};
    for (int i = 0; i < conns; i++) {
        pthread_join(t[i], NULL);
        total.requests += st[i].requests;
        total.errors += st[i].errors;
        total.lat_sum += st[i].lat_sum;
        if (st[i].lat_max > total.lat_max) total.lat_max = st[i].lat_max;
    }
    printf("%d connections, %.0fs: %ld requests (%.0f/s), %ld errors, mean latency %.3f ms, max %.1f ms\n",
           conns, duration, total.requests, total.requests / duration, total.errors,
           total.requests ? total.lat_sum / total.requests * 1e3 : 0, total.lat_max * 1e3);
    return 0;
}
