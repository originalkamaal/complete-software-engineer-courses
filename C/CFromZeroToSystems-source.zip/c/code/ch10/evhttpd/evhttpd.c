// file: evhttpd/evhttpd.c
/* evhttpd: a single-threaded epoll HTTP/1.1 static file server. */
#define _GNU_SOURCE                       /* accept4, memmem */
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

enum { HEAD_MAX = 8192, OUT_MAX = 65536, IDLE_SECONDS = 10, MAX_EVENTS = 128 };

typedef struct Conn {
    int fd;
    char in[HEAD_MAX];          /* request head being received */
    size_t in_len;
    char out[OUT_MAX];          /* response bytes waiting to be sent */
    size_t out_len, out_off;
    int file;                   /* file being streamed after the head, or -1 */
    off_t file_left;
    bool close_after;
    time_t last_active;
    struct Conn *next;          /* list of all connections, for idle sweeps */
} Conn;

static int ep;
static const char *docroot;
static Conn *conns;
static long requests_served;

static const char *mime(const char *path) {
    const char *dot = strrchr(path, '.');
    if (dot == NULL) return "application/octet-stream";
    if (strcmp(dot, ".html") == 0) return "text/html; charset=utf-8";
    if (strcmp(dot, ".txt") == 0) return "text/plain; charset=utf-8";
    if (strcmp(dot, ".css") == 0) return "text/css";
    if (strcmp(dot, ".js") == 0) return "text/javascript";
    if (strcmp(dot, ".png") == 0) return "image/png";
    if (strcmp(dot, ".json") == 0) return "application/json";
    return "application/octet-stream";
}

static void set_events(Conn *c, uint32_t events) {
    struct epoll_event ev = {.events = events, .data.ptr = c};
    epoll_ctl(ep, EPOLL_CTL_MOD, c->fd, &ev);
}

static void conn_close(Conn *c) {
    epoll_ctl(ep, EPOLL_CTL_DEL, c->fd, NULL);
    close(c->fd);
    if (c->file >= 0)
        close(c->file);
    for (Conn **p = &conns; *p; p = &(*p)->next)       /* unlink: pointer-to-pointer, Unit 7.2 */
        if (*p == c) { *p = c->next; break; }
    free(c);
}

static void respond_simple(Conn *c, int code, const char *reason, bool keep) {
    char body[128];
    int blen = snprintf(body, sizeof body, "%d %s\n", code, reason);
    c->out_len = (size_t)snprintf(c->out, sizeof c->out,
        "HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\nContent-Length: %d\r\n%s\r\n%s",
        code, reason, blen, keep ? "" : "Connection: close\r\n", body);
    c->out_off = 0;
    c->close_after = !keep;
}

/* safe_path rejects traversal: the URL path must start with '/' and contain no ".." segment. */
static bool safe_path(const char *p) {
    if (p[0] != '/')
        return false;
    for (const char *s = p; *s; s++)
        if (s[0] == '.' && s[1] == '.' && (s == p || s[-1] == '/') && (s[2] == '/' || s[2] == '\0'))
            return false;
    return true;
}

/* handle_request parses the complete head in c->in[0..head_len) and prepares a response. */
static void handle_request(Conn *c, size_t head_len) {
    char *line_end = memmem(c->in, head_len, "\r\n", 2);
    char method[8], path[1024], version[16];
    bool keep = true;
    *line_end = '\0';
    if (sscanf(c->in, "%7s %1023s %15s", method, path, version) != 3 ||
        strncmp(version, "HTTP/1.", 7) != 0) {
        respond_simple(c, 400, "Bad Request", false);
        return;
    }
    if (strcmp(version, "HTTP/1.0") == 0)
        keep = false;                                     /* 1.0 closes by default */
    for (char *h = line_end + 2; h < c->in + head_len;) { /* scan headers for Connection */
        char *e = memmem(h, (size_t)(c->in + head_len - h), "\r\n", 2);
        if (e == NULL) break;
        *e = '\0';
        if (strncasecmp(h, "Connection:", 11) == 0) {
            const char *v = h + 11;
            while (*v == ' ') v++;
            if (strcasecmp(v, "close") == 0) keep = false;
            if (strcasecmp(v, "keep-alive") == 0) keep = true;
        }
        h = e + 2;
    }
    bool head_only = strcmp(method, "HEAD") == 0;
    if (!head_only && strcmp(method, "GET") != 0) {
        respond_simple(c, 405, "Method Not Allowed", keep);
        return;
    }
    char *q = strchr(path, '?');
    if (q) *q = '\0';                                     /* ignore the query string */
    if (!safe_path(path)) {
        respond_simple(c, 403, "Forbidden", keep);
        return;
    }
    char full[2048];
    snprintf(full, sizeof full, "%s%s", docroot, strcmp(path, "/") == 0 ? "/index.html" : path);
    int fd = open(full, O_RDONLY | O_CLOEXEC);
    struct stat st;
    if (fd < 0 || fstat(fd, &st) != 0 || !S_ISREG(st.st_mode)) {
        if (fd >= 0) close(fd);
        respond_simple(c, 404, "Not Found", keep);
        return;
    }
    c->out_len = (size_t)snprintf(c->out, sizeof c->out,
        "HTTP/1.1 200 OK\r\nContent-Type: %s\r\nContent-Length: %jd\r\n%s\r\n",
        mime(full), (intmax_t)st.st_size, keep ? "" : "Connection: close\r\n");
    c->out_off = 0;
    c->close_after = !keep;
    c->file_left = head_only ? 0 : st.st_size;
    /* put the first part of the body in the same buffer as the head: one send for
       small files, and no Nagle/delayed-ACK stall between head and body (DT-59) */
    while (c->file_left > 0 && c->out_len < sizeof c->out) {
        ssize_t r = read(fd, c->out + c->out_len, sizeof c->out - c->out_len);
        if (r <= 0)
            break;
        c->out_len += (size_t)r;
        c->file_left -= r;
    }
    if (c->file_left > 0)
        c->file = fd;                                     /* stream the rest from pump() */
    else
        close(fd);
    requests_served++;
}

/* pump writes as much pending output as the socket accepts. Returns false if the
   connection was closed. */
static bool pump(Conn *c) {
    for (;;) {
        if (c->out_off == c->out_len && c->file >= 0 && c->file_left > 0) {
            ssize_t r = read(c->file, c->out, sizeof c->out);   /* refill from the file */
            if (r <= 0) { conn_close(c); return false; }
            c->out_len = (size_t)r;
            c->out_off = 0;
            c->file_left -= r;
            if (c->file_left == 0) { close(c->file); c->file = -1; }
        }
        if (c->out_off == c->out_len)
            break;                                          /* response complete */
        ssize_t w = send(c->fd, c->out + c->out_off, c->out_len - c->out_off, MSG_NOSIGNAL);
        if (w < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                set_events(c, EPOLLOUT);                    /* wait until writable */
                return true;
            }
            conn_close(c);
            return false;
        }
        c->out_off += (size_t)w;
    }
    c->out_len = c->out_off = 0;
    if (c->close_after) {
        conn_close(c);
        return false;
    }
    set_events(c, EPOLLIN);                                 /* ready for the next request */
    return true;
}

static void on_readable(Conn *c) {
    for (;;) {
        ssize_t n = recv(c->fd, c->in + c->in_len, sizeof c->in - c->in_len, 0);
        if (n == 0) { conn_close(c); return; }              /* client closed */
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            conn_close(c);
            return;
        }
        c->in_len += (size_t)n;
        c->last_active = time(NULL);
        if (c->in_len == sizeof c->in) break;
    }
    /* answer every complete request in the buffer (pipelining), one at a time */
    while (c->out_len == 0) {
        char *end = memmem(c->in, c->in_len, "\r\n\r\n", 4);
        if (end == NULL) {
            if (c->in_len == sizeof c->in) {                /* head too large */
                respond_simple(c, 431, "Request Header Fields Too Large", false);
                c->in_len = 0;
                pump(c);
            }
            return;
        }
        size_t head_len = (size_t)(end - c->in) + 4;
        handle_request(c, head_len);
        memmove(c->in, c->in + head_len, c->in_len - head_len);
        c->in_len -= head_len;
        if (!pump(c))
            return;
    }
}

static void on_accept(int lfd) {
    for (;;) {
        int fd = accept4(lfd, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
        if (fd < 0)
            return;                                          /* EAGAIN: no more pending */
        Conn *c = calloc(1, sizeof *c);
        if (c == NULL) { close(fd); continue; }
        int one = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);   /* see DT-59 */
        c->fd = fd;
        c->file = -1;
        c->last_active = time(NULL);
        c->next = conns;
        conns = c;
        struct epoll_event ev = {.events = EPOLLIN, .data.ptr = c};
        epoll_ctl(ep, EPOLL_CTL_ADD, fd, &ev);
    }
}

static volatile sig_atomic_t stop;
static void on_term(int s) { (void)s; stop = 1; }

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "usage: evhttpd PORT DOCROOT\n");
        return 2;
    }
    docroot = argv[2];
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa = {.sa_handler = on_term};
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);

    int lfd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0), on = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons((uint16_t)atoi(argv[1])),
                               .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    if (bind(lfd, (struct sockaddr *)&addr, sizeof addr) != 0 || listen(lfd, SOMAXCONN) != 0) {
        perror("bind/listen");
        return 1;
    }
    ep = epoll_create1(EPOLL_CLOEXEC);
    struct epoll_event lev = {.events = EPOLLIN, .data.ptr = NULL};     /* NULL marks the listener */
    epoll_ctl(ep, EPOLL_CTL_ADD, lfd, &lev);
    fprintf(stderr, "evhttpd: serving %s on 127.0.0.1:%s\n", docroot, argv[1]);

    while (!stop) {
        struct epoll_event ev[MAX_EVENTS];
        int n = epoll_wait(ep, ev, MAX_EVENTS, 1000);
        for (int i = 0; i < n; i++) {
            Conn *c = ev[i].data.ptr;
            if (c == NULL)
                on_accept(lfd);
            else if (ev[i].events & (EPOLLERR | EPOLLHUP))
                conn_close(c);
            else if (ev[i].events & EPOLLOUT)
                pump(c);
            else if (ev[i].events & EPOLLIN)
                on_readable(c);
        }
        time_t now = time(NULL);                            /* idle sweep */
        for (Conn *c = conns, *next; c != NULL; c = next) {
            next = c->next;
            if (now - c->last_active > IDLE_SECONDS && c->out_len == 0)
                conn_close(c);
        }
    }
    while (conns)
        conn_close(conns);
    close(lfd);
    close(ep);
    fprintf(stderr, "evhttpd: shut down after %ld requests\n", requests_served);
    return 0;
}
