// file: echo/echo_client.c
#include "net.h"

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "usage: echo_client HOST PORT MESSAGE\n");
        return 2;
    }
    int fd = connect_to(argv[1], argv[2]);
    if (fd < 0) {
        perror("connect_to");
        return 1;
    }
    size_t len = strlen(argv[3]);
    if (write_all(fd, argv[3], len) != 0)
        return 1;
    shutdown(fd, SHUT_WR);                       /* tell the server we are done sending */
    char buf[4096];
    size_t got = 0;
    ssize_t n;
    while ((n = read(fd, buf + got, sizeof buf - 1 - got)) > 0)   /* read until the server closes */
        got += (size_t)n;
    buf[got] = '\0';
    printf("sent %zu bytes, received back: \"%s\"\n", len, buf);
    close(fd);
    return 0;
}
