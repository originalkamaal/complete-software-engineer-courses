// file: echo/echo_server.c
/* An iterative echo server: handles one client at a time. */
#include "net.h"

#include <signal.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    const char *port = argc > 1 ? argv[1] : "9000";
    signal(SIGPIPE, SIG_IGN);                    /* a vanished client must not kill us */
    int lfd = listen_on(port);
    if (lfd < 0) {
        perror("listen_on");
        return 1;
    }
    fprintf(stderr, "echo server on port %s\n", port);
    for (int served = 0; served < 3; served++) { /* serve 3 clients, then exit (for the demo) */
        int cfd = accept4(lfd, NULL, NULL, SOCK_CLOEXEC);
        if (cfd < 0) {
            perror("accept");
            continue;
        }
        char buf[4096];
        ssize_t n;
        long total = 0;
        while ((n = read(cfd, buf, sizeof buf)) > 0) {
            total += n;
            if (write_all(cfd, buf, (size_t)n) != 0)
                break;
        }
        fprintf(stderr, "client %d done: echoed %ld bytes\n", served + 1, total);
        close(cfd);
    }
    close(lfd);
    return 0;
}
