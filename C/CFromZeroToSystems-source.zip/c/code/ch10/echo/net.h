// file: echo/net.h
#ifndef NET_H
#define NET_H
#define _GNU_SOURCE              /* accept4 is a Linux extension; include this header first */
#include <stddef.h>
#include <sys/types.h>

/* listen_on returns a listening TCP socket on port (all addresses), or -1. */
int listen_on(const char *port);

/* connect_to returns a socket connected to host:port, or -1. */
int connect_to(const char *host, const char *port);

/* write_all writes n bytes, retrying partial writes. Returns 0 or -1. */
int write_all(int fd, const void *buf, size_t n);

#endif
