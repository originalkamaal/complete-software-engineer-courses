// file: polldemo.c
#define _DEFAULT_SOURCE
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void) {
    enum { N = 3 };
    struct pollfd pfd[N];
    for (int i = 0; i < N; i++) {                         /* N children, each with its own pipe */
        int fd[2];
        if (pipe(fd) < 0) return 1;
        if (fork() == 0) {
            close(fd[0]);
            usleep((unsigned)(N - i) * 150000);           /* child 2 speaks first, child 0 last */
            char msg[32];
            int n = snprintf(msg, sizeof msg, "hello from child %d", i);
            if (write(fd[1], msg, (size_t)n) < 0) _exit(1);
            _exit(0);                                      /* closing the pipe: the reader will see POLLHUP */
        }
        close(fd[1]);
        pfd[i] = (struct pollfd){ .fd = fd[0], .events = POLLIN };
    }
    int open_pipes = N;
    while (open_pipes > 0) {
        int ready = poll(pfd, N, 2000);                   /* timeout in milliseconds; -1 = forever */
        if (ready == 0) { printf("timeout\n"); break; }
        for (int i = 0; i < N; i++) {
            if (pfd[i].revents & POLLIN) {
                char buf[64];
                ssize_t n = read(pfd[i].fd, buf, sizeof buf - 1);
                if (n > 0) { buf[n] = '\0'; printf("pipe %d readable: \"%s\"\n", i, buf); continue; }
            }
            if (pfd[i].revents & (POLLHUP | POLLERR)) {
                printf("pipe %d closed\n", i);
                close(pfd[i].fd);
                pfd[i].fd = -1;                           /* negative fd: poll ignores the entry */
                open_pipes--;
            }
        }
    }
    while (wait(NULL) > 0) { }
    return 0;
}
