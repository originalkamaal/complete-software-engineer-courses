// file: framing.c
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* A receive buffer that accumulates bytes and extracts length-prefixed frames:
   4-byte big-endian length, then that many bytes of payload. */
typedef struct {
    unsigned char data[256];
    size_t len;
} RecvBuf;

enum { MAX_FRAME = 200 };

/* feed appends newly received bytes, as read() would deliver them. */
static int feed(RecvBuf *b, const unsigned char *p, size_t n) {
    if (n > sizeof b->data - b->len)
        return -1;                                /* would overflow: protocol violation */
    memcpy(b->data + b->len, p, n);
    b->len += n;
    return 0;
}

/* next_frame returns 1 and copies a complete frame out, 0 if more bytes are
   needed, -1 if the declared length is invalid. */
static int next_frame(RecvBuf *b, char *out, size_t outsz) {
    if (b->len < 4)
        return 0;
    uint32_t n = (uint32_t)b->data[0] << 24 | (uint32_t)b->data[1] << 16 |
                 (uint32_t)b->data[2] << 8 | b->data[3];
    if (n > MAX_FRAME || n >= outsz)
        return -1;                                /* never trust a length from the network */
    if (b->len < 4 + n)
        return 0;
    memcpy(out, b->data + 4, n);
    out[n] = '\0';
    memmove(b->data, b->data + 4 + n, b->len - 4 - n);   /* keep any following bytes */
    b->len -= 4 + n;
    return 1;
}

static size_t encode(unsigned char *dst, const char *msg) {
    uint32_t n = (uint32_t)strlen(msg);
    dst[0] = (unsigned char)(n >> 24); dst[1] = (unsigned char)(n >> 16);
    dst[2] = (unsigned char)(n >> 8);  dst[3] = (unsigned char)n;
    memcpy(dst + 4, msg, n);
    return 4 + n;
}

int main(void) {
    unsigned char wire[128];
    size_t w = 0;
    w += encode(wire + w, "first");
    w += encode(wire + w, "second message");
    w += encode(wire + w, "3");

    /* deliver the stream in awkward pieces, as TCP may: 3, 7, 1, then the rest */
    size_t cuts[] = {3, 7, 1, w - 11};
    RecvBuf rb = {0};
    size_t off = 0;
    char msg[MAX_FRAME + 1];
    for (size_t i = 0; i < 4; i++) {
        feed(&rb, wire + off, cuts[i]);
        off += cuts[i];
        printf("delivered %zu bytes (buffered %zu):", cuts[i], rb.len);
        int r;
        while ((r = next_frame(&rb, msg, sizeof msg)) == 1)
            printf(" [%s]", msg);
        printf("\n");
    }
    unsigned char evil[4] = {0x7F, 0xFF, 0xFF, 0xFF};        /* claims a 2 GB message */
    RecvBuf eb = {0};
    feed(&eb, evil, 4);
    printf("hostile length prefix -> %d\n", next_frame(&eb, msg, sizeof msg));
    return 0;
}
