// file: sigpipe.c
#define _DEFAULT_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static void try(int ignore) {
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_addr.s_addr = htonl(INADDR_LOOPBACK) };
    socklen_t len = sizeof a;
    bind(ls, (struct sockaddr *)&a, sizeof a);
    listen(ls, 1);
    getsockname(ls, (struct sockaddr *)&a, &len);
    int c = socket(AF_INET, SOCK_STREAM, 0);
    connect(c, (struct sockaddr *)&a, sizeof a);
    int s = accept(ls, NULL, NULL);
    close(c);                                          /* the client goes away */
    usleep(100000);
    if (ignore) signal(SIGPIPE, SIG_IGN);
    for (int i = 1; i <= 3; i++) {
        ssize_t n = write(s, "data", 4);
        printf("  write %d: %zd%s%s\n", i, n, n < 0 ? ", errno " : "", n < 0 ? strerror(errno) : "");
        fflush(stdout);
        usleep(100000);
    }
    close(s);
    close(ls);
}

int main(int argc, char **argv) {
    (void)argv;
    printf(argc > 1 ? "with SIGPIPE ignored:\n" : "default SIGPIPE action:\n");
    fflush(stdout);
    try(argc > 1);
    printf("server still alive\n");
    return 0;
}
