// file: udp.c
#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
    int srv = socket(AF_INET, SOCK_DGRAM, 0), cli = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons(0)};   /* port 0: any free port */
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) != 0)
        return 1;
    socklen_t alen = sizeof addr;
    getsockname(srv, (struct sockaddr *)&addr, &alen);          /* which port did we get? */

    const char *msgs[] = {"ping 1", "ping 2", "a much longer third datagram"};
    for (int i = 0; i < 3; i++)
        sendto(cli, msgs[i], strlen(msgs[i]), 0, (struct sockaddr *)&addr, sizeof addr);

    for (int i = 0; i < 3; i++) {
        char buf[16];                                           /* deliberately small */
        struct sockaddr_in from;
        socklen_t flen = sizeof from;
        ssize_t n = recvfrom(srv, buf, sizeof buf - 1, MSG_TRUNC, (struct sockaddr *)&from, &flen);
        size_t kept = (size_t)n < sizeof buf - 1 ? (size_t)n : sizeof buf - 1;
        buf[kept] = '\0';
        printf("datagram of %zd bytes from port %u: \"%s\"%s\n", n, ntohs(from.sin_port), buf,
               (size_t)n > kept ? " (truncated: the rest is lost)" : "");
    }
    close(srv);
    close(cli);
    return 0;
}
