// file: macros.c
#include <stdio.h>

#define SQUARE_BAD(x) x * x
#define SQUARE(x) ((x) * (x))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

/* a statement-like macro must be one statement: the do { } while (0) idiom */
#define SWAP(T, a, b) do { T tmp_ = (a); (a) = (b); (b) = tmp_; } while (0)

/* GNU statement expression: evaluates each argument once (GCC/Clang extension) */
#define MAX_ONCE(a, b) ({ __typeof__(a) a_ = (a); __typeof__(b) b_ = (b); a_ > b_ ? a_ : b_; })

static int calls;
static int next(void) { return ++calls; }

int main(void) {
    printf("SQUARE_BAD(1 + 2) = %d\n", SQUARE_BAD(1 + 2));   /* 1 + 2 * 1 + 2 */
    printf("SQUARE(1 + 2)     = %d\n", SQUARE(1 + 2));
    printf("10 / SQUARE(2)    = %d\n", 10 / SQUARE(2));

    calls = 0;
    int m = MAX(next(), 0);                  /* next() is called twice */
    printf("MAX(next(), 0) = %d after %d calls\n", m, calls);
    calls = 0;
    m = MAX_ONCE(next(), 0);
    printf("MAX_ONCE(next(), 0) = %d after %d call\n", m, calls);

    int a = 1, b = 2;
    if (a < b)
        SWAP(int, a, b);                     /* works as one statement thanks to do/while(0) */
    else
        printf("never\n");
    printf("a=%d b=%d\n", a, b);
    return 0;
}
