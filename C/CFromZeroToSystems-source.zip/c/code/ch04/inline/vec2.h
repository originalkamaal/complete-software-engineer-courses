// file: inline/vec2.h
#ifndef VEC2_H
#define VEC2_H

typedef struct { double x, y; } Vec2;

static inline Vec2 vec2_add(Vec2 a, Vec2 b) { return (Vec2){a.x + b.x, a.y + b.y}; }
static inline double vec2_dot(Vec2 a, Vec2 b) { return a.x * b.x + a.y * b.y; }

#endif
