// file: inline/use.c
#include <stdio.h>
#include "vec2.h"

inline int square(int x) { return x * x; }    /* plain inline: no external definition */

int main(void) {
    Vec2 v = vec2_add((Vec2){1, 2}, (Vec2){3, 4});
    printf("v = (%g, %g), dot = %g, square = %d\n", v.x, v.y, vec2_dot(v, v), square(7));
    return 0;
}
