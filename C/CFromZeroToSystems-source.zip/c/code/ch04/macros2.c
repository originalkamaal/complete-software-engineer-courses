// file: macros2.c
#include <stdio.h>

#define STR(x) #x                      /* argument text as a string literal */
#define XSTR(x) STR(x)                 /* expand x first, then stringise */
#define VERSION 3
#define CONCAT(a, b) a##b              /* paste tokens into one */

#define LOG(fmt, ...) fprintf(stderr, "[%s:%d] " fmt "\n", __FILE__, __LINE__, __VA_ARGS__)
#define CHECK(expr) ((expr) ? (void)0 : (void)fprintf(stderr, "check failed: %s\n", #expr))

int main(void) {
    int CONCAT(my, var) = 42;          /* declares myvar */
    printf("%s\n", STR(VERSION));      /* "VERSION": # does not expand its argument */
    printf("%s\n", XSTR(VERSION));     /* "3" */
    printf("myvar = %d\n", myvar);
    LOG("value is %d", myvar);
    CHECK(myvar == 41);
    printf("compiled with %s on %s, C version %ld\n", __VERSION__, __DATE__, __STDC_VERSION__);
    return 0;
}
