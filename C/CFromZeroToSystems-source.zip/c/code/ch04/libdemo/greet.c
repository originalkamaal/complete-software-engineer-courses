// file: libdemo/greet.c
#include "greet.h"
#include <stdio.h>

static const char *salutation(void) { return "Hello"; }   /* not exported */

int greet(char *buf, unsigned long n, const char *name) {
    return snprintf(buf, n, "%s, %s!", salutation(), name);
}

const char *greet_version(void) { return "1.0"; }
