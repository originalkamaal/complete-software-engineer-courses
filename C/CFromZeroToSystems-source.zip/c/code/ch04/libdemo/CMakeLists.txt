# file: libdemo/CMakeLists.txt
cmake_minimum_required(VERSION 3.20)
project(greet VERSION 1.0 LANGUAGES C)

set(CMAKE_C_STANDARD 17)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

add_library(greet SHARED greet.c)
target_include_directories(greet PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
set_target_properties(greet PROPERTIES VERSION 1.0 SOVERSION 1)
target_compile_options(greet PRIVATE -Wall -Wextra -pedantic)

add_executable(app app.c)
target_link_libraries(app PRIVATE greet)
