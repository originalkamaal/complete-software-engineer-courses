// file: libdemo/greet.h
#ifndef GREET_H
#define GREET_H

/* greet writes a greeting for name into buf (size n); returns snprintf's result. */
int greet(char *buf, unsigned long n, const char *name);
const char *greet_version(void);

#endif
