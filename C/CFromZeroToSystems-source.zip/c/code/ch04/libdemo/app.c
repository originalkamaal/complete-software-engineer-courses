// file: libdemo/app.c
#include <stdio.h>
#include "greet.h"

int main(void) {
    char buf[64];
    greet(buf, sizeof buf, "library");
    printf("%s (libgreet %s)\n", buf, greet_version());
    return 0;
}
