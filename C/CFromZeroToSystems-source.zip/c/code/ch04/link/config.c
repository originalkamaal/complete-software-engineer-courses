// file: link/config.c
#include "config.h"

int verbosity = 1;              /* the one definition */
static int calls;               /* internal: no other file can see or clash with it */

static void log_call(void) {    /* internal helper */
    calls++;
}

void config_load(int level) {
    log_call();
    verbosity = level;
}

int config_calls(void) { return calls; }
