// file: link/config.h
#ifndef CONFIG_H
#define CONFIG_H

extern int verbosity;           /* declared here, defined in config.c */
void config_load(int level);
int config_calls(void);

#endif
