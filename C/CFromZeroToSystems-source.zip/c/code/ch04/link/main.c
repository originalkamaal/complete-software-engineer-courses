// file: link/main.c
#include <stdio.h>
#include "config.h"

static int calls = 100;         /* a different object from config.c's calls: no clash */

int main(void) {
    printf("verbosity starts at %d\n", verbosity);
    config_load(3);
    config_load(4);
    printf("verbosity now %d, config_calls %d, main's calls %d\n", verbosity, config_calls(), calls);
    return 0;
}
