// file: calc/calc.c
#include "calc.h"

bool calc_add(int a, int b, int *out) {
    int r;
    if (__builtin_add_overflow(a, b, &r)) return false;     /* GCC/Clang builtin: no UB */
    *out = r;
    return true;
}
