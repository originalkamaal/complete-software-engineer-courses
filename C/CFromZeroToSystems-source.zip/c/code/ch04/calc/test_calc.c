// file: calc/test_calc.c
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "calc.h"

static int failures;
#define CHECK(c) do { if (!(c)) { fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); failures++; } } while (0)

int main(int argc, char **argv) {
    int r = 0;
    if (argc > 1 && strcmp(argv[1], "arithmetic") == 0) {
        CHECK(calc_add(2, 3, &r) && r == 5);
        CHECK(calc_add(-7, 7, &r) && r == 0);
    } else if (argc > 1 && strcmp(argv[1], "overflow") == 0) {
        r = 42;
        CHECK(!calc_add(INT_MAX, 1, &r) && r == 42);
        CHECK(!calc_add(INT_MIN, -1, &r));
        CHECK(calc_add(INT_MAX, 0, &r) && r == INT_MAX);
    } else {
        fprintf(stderr, "usage: calc_test arithmetic|overflow\n");
        return 2;
    }
    return failures ? 1 : 0;
}
