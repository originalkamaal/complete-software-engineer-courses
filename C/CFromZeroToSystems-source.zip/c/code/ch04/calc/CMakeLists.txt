# file: calc/CMakeLists.txt
cmake_minimum_required(VERSION 3.20)
project(calc VERSION 0.1 LANGUAGES C)

set(CMAKE_C_STANDARD 17)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

option(CALC_SANITIZE "Build with AddressSanitizer and UBSan" OFF)

add_library(calc STATIC calc.c)
target_include_directories(calc PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_options(calc PRIVATE -Wall -Wextra -pedantic)

if(CALC_SANITIZE)
  # applied to every target created after this point, for compiling and linking
  add_compile_options(-fsanitize=address,undefined -fno-omit-frame-pointer)
  add_link_options(-fsanitize=address,undefined)
  target_compile_options(calc PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
endif()

add_executable(calc_test test_calc.c)
target_link_libraries(calc_test PRIVATE calc)

enable_testing()
add_test(NAME arithmetic COMMAND calc_test arithmetic)
add_test(NAME overflow   COMMAND calc_test overflow)
