// file: calc/include/calc.h
#ifndef CALC_H
#define CALC_H
#include <stdbool.h>
/* Add two ints; returns false (and leaves *out unchanged) if the result would overflow. */
bool calc_add(int a, int b, int *out);
#endif
