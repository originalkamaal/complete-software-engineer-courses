// file: makedemo/geometry.h
#ifndef GEOMETRY_H
#define GEOMETRY_H

double circle_area(double r);
double hypotenuse(double a, double b);

#endif
