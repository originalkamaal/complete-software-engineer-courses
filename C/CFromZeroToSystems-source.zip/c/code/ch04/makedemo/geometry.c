// file: makedemo/geometry.c
#include "geometry.h"
#include <math.h>

/* M_PI is POSIX, not ISO C: with -std=c17, glibc does not define it */
static const double PI = 3.14159265358979323846;

double circle_area(double r) { return PI * r * r; }
double hypotenuse(double a, double b) { return sqrt(a * a + b * b); }
