// file: makedemo/main.c
#include <stdio.h>
#include "geometry.h"

int main(void) {
    printf("area(2) = %.4f, hypotenuse(3, 4) = %.1f\n", circle_area(2), hypotenuse(3, 4));
    return 0;
}
