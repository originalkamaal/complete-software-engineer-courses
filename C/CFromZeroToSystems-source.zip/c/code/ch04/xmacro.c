// file: xmacro.c
#include <stdio.h>

#define COLORS(X) \
    X(RED,   0xFF0000) \
    X(GREEN, 0x00FF00) \
    X(BLUE,  0x0000FF)

#define AS_ENUM(name, rgb) COLOR_##name,
#define AS_NAME(name, rgb) #name,
#define AS_RGB(name, rgb) rgb,

enum color { COLORS(AS_ENUM) COLOR_COUNT };
static const char *const color_names[] = { COLORS(AS_NAME) };
static const unsigned color_rgb[] = { COLORS(AS_RGB) };

int main(void) {
    for (int c = 0; c < COLOR_COUNT; c++)
        printf("%d %-5s #%06X\n", c, color_names[c], color_rgb[c]);
    return 0;
}
