# file: inilib/CMakeLists.txt
cmake_minimum_required(VERSION 3.20)
project(ini VERSION 1.0 LANGUAGES C)
set(CMAKE_C_STANDARD 17)
set(CMAKE_C_EXTENSIONS OFF)

option(BUILD_SHARED_LIBS "Build shared libraries" ON)

add_library(ini ini.c)
target_include_directories(ini PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
set_target_properties(ini PROPERTIES VERSION ${PROJECT_VERSION} SOVERSION 1)
target_compile_options(ini PRIVATE -Wall -Wextra -pedantic)

add_executable(iniget iniget.c)
target_link_libraries(iniget PRIVATE ini)

enable_testing()
add_test(NAME get_port COMMAND iniget ${CMAKE_CURRENT_SOURCE_DIR}/test.ini server port)
set_tests_properties(get_port PROPERTIES PASS_REGULAR_EXPRESSION "^8080")
add_test(NAME bad_file COMMAND iniget ${CMAKE_CURRENT_SOURCE_DIR}/bad.ini server host)
set_tests_properties(bad_file PROPERTIES WILL_FAIL TRUE)
