// file: inilib/ini.h
#ifndef INI_H
#define INI_H

#include <stddef.h>

typedef struct ini Ini;

/* ini_parse_file reads and parses an INI file. On failure it returns NULL
   and writes a message (with the line number, if relevant) into err.
   The caller owns the result and must release it with ini_free. */
Ini *ini_parse_file(const char *path, char *err, size_t errsz);

/* ini_get returns the value of key in section ("" for keys before any
   section), or NULL. The string is owned by ini and valid until ini_free. */
const char *ini_get(const Ini *ini, const char *section, const char *key);

/* ini_count returns the number of distinct (section, key) entries. */
size_t ini_count(const Ini *ini);

/* ini_free releases ini and every string returned by ini_get. NULL is allowed. */
void ini_free(Ini *ini);

#endif
