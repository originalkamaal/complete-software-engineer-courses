// file: inilib/ini.c
#include "ini.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *section, *key, *value;     /* each separately allocated, owned by the Ini */
} Entry;

struct ini {
    Entry *entries;
    size_t len, cap;
};

static char *dup_str(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (p != NULL)
        memcpy(p, s, n);
    return p;
}

/* trim returns a pointer to the first non-space character of s and
   terminates s after the last non-space character. */
static char *trim(char *s) {
    while (isspace((unsigned char)*s))
        s++;
    size_t n = strlen(s);
    while (n > 0 && isspace((unsigned char)s[n - 1]))
        s[--n] = '\0';
    return s;
}

static Entry *find(const Ini *ini, const char *section, const char *key) {
    for (size_t i = 0; i < ini->len; i++)
        if (strcmp(ini->entries[i].section, section) == 0 && strcmp(ini->entries[i].key, key) == 0)
            return &ini->entries[i];
    return NULL;
}

/* set adds or replaces an entry. Returns 0, or -1 when out of memory. */
static int set(Ini *ini, const char *section, const char *key, const char *value) {
    char *v = dup_str(value);
    if (v == NULL)
        return -1;
    Entry *e = find(ini, section, key);
    if (e != NULL) {                       /* duplicate key: later value wins */
        free(e->value);
        e->value = v;
        return 0;
    }
    if (ini->len == ini->cap) {
        size_t cap = ini->cap ? ini->cap * 2 : 16;
        Entry *p = realloc(ini->entries, cap * sizeof *p);
        if (p == NULL) {
            free(v);
            return -1;
        }
        ini->entries = p;
        ini->cap = cap;
    }
    Entry n = {dup_str(section), dup_str(key), v};
    if (n.section == NULL || n.key == NULL) {
        free(n.section);
        free(n.key);
        free(v);
        return -1;
    }
    ini->entries[ini->len++] = n;
    return 0;
}

Ini *ini_parse_file(const char *path, char *err, size_t errsz) {
    FILE *f = fopen(path, "r");
    if (f == NULL) {
        snprintf(err, errsz, "%s: %s", path, strerror(errno));
        return NULL;
    }
    Ini *ini = calloc(1, sizeof *ini);
    char line[1024], section[256] = "";
    int lineno = 0;
    if (ini == NULL) {
        snprintf(err, errsz, "out of memory");
        goto fail;
    }
    while (fgets(line, sizeof line, f) != NULL) {
        lineno++;
        size_t n = strlen(line);
        if (n == sizeof line - 1 && line[n - 1] != '\n' && !feof(f)) {
            snprintf(err, errsz, "%s:%d: line too long", path, lineno);
            goto fail;
        }
        char *s = trim(line);
        if (*s == '\0' || *s == ';' || *s == '#')
            continue;
        if (*s == '[') {
            char *close = strchr(s, ']');
            if (close == NULL) {
                snprintf(err, errsz, "%s:%d: missing ']'", path, lineno);
                goto fail;
            }
            *close = '\0';
            snprintf(section, sizeof section, "%s", trim(s + 1));
            continue;
        }
        char *eq = strchr(s, '=');
        if (eq == NULL) {
            snprintf(err, errsz, "%s:%d: expected key = value", path, lineno);
            goto fail;
        }
        *eq = '\0';
        char *key = trim(s), *value = trim(eq + 1);
        if (*key == '\0') {
            snprintf(err, errsz, "%s:%d: empty key", path, lineno);
            goto fail;
        }
        if (set(ini, section, key, value) != 0) {
            snprintf(err, errsz, "out of memory");
            goto fail;
        }
    }
    if (ferror(f)) {
        snprintf(err, errsz, "%s: read error", path);
        goto fail;
    }
    fclose(f);
    return ini;
fail:
    fclose(f);
    ini_free(ini);
    return NULL;
}

const char *ini_get(const Ini *ini, const char *section, const char *key) {
    const Entry *e = find(ini, section, key);
    return e ? e->value : NULL;
}

size_t ini_count(const Ini *ini) { return ini->len; }

void ini_free(Ini *ini) {
    if (ini == NULL)
        return;
    for (size_t i = 0; i < ini->len; i++) {
        free(ini->entries[i].section);
        free(ini->entries[i].key);
        free(ini->entries[i].value);
    }
    free(ini->entries);
    free(ini);
}
