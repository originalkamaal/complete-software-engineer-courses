// file: inilib/iniget.c
#include <stdio.h>
#include "ini.h"

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "usage: iniget FILE SECTION KEY\n");
        return 2;
    }
    char err[256];
    Ini *ini = ini_parse_file(argv[1], err, sizeof err);
    if (ini == NULL) {
        fprintf(stderr, "iniget: %s\n", err);
        return 2;
    }
    const char *v = ini_get(ini, argv[2], argv[3]);
    int status = 1;
    if (v != NULL) {
        printf("%s\n", v);
        status = 0;
    }
    ini_free(ini);
    return status;
}
