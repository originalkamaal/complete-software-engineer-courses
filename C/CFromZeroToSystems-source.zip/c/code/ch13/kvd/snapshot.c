// file: kvd/snapshot.c
#define _GNU_SOURCE
#include "snapshot.h"
#include "wal.h"

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int snapshot_write(const char *dir, const Table *t, uint64_t gen) {
    char tmp[512], final[512];
    snprintf(tmp, sizeof tmp, "%s/snapshot.tmp", dir);
    snprintf(final, sizeof final, "%s/snapshot", dir);
    FILE *f = fopen(tmp, "wb");
    if (f == NULL)
        return -1;
    uint32_t crc = 0;
    unsigned char hdr[16] = "KVSNAP1";
    for (int i = 0; i < 8; i++)
        hdr[8 + i] = (unsigned char)(gen >> (8 * i));
    fwrite(hdr, 1, 16, f);
    crc = crc32(hdr, 16);
    size_t it = 0;
    const Entry *e;
    while ((e = table_next(t, &it)) != NULL) {
        unsigned char lens[8];
        for (int i = 0; i < 4; i++) {
            lens[i] = (unsigned char)(e->klen >> (8 * i));
            lens[4 + i] = (unsigned char)(e->vlen >> (8 * i));
        }
        fwrite(lens, 1, 8, f);
        fwrite(e->key, 1, e->klen, f);
        fwrite(e->val, 1, e->vlen, f);
        /* chain the CRC over every record: crc = crc32(prev_crc || record) */
        uint32_t parts[1] = {crc};
        unsigned char rec_crc_in[4 + 8];
        memcpy(rec_crc_in, parts, 4);
        memcpy(rec_crc_in + 4, lens, 8);
        crc = crc32(rec_crc_in, sizeof rec_crc_in) ^ crc32(e->key, e->klen) ^ crc32(e->val, e->vlen);
    }
    unsigned char end[12] = {0xFF, 0xFF, 0xFF, 0xFF};      /* klen = 0xFFFFFFFF marks the end */
    for (int i = 0; i < 4; i++)
        end[8 + i] = (unsigned char)(crc >> (8 * i));
    fwrite(end, 1, 12, f);
    if (fflush(f) != 0 || fsync(fileno(f)) != 0 || fclose(f) != 0) {
        unlink(tmp);
        return -1;
    }
    if (rename(tmp, final) != 0)                           /* atomic replace (Unit 6.3) */
        return -1;
    int dfd = open(dir, O_RDONLY | O_DIRECTORY);           /* make the rename itself durable */
    if (dfd >= 0) {
        fsync(dfd);
        close(dfd);
    }
    return 0;
}

static int read_exact(FILE *f, void *buf, size_t n) {
    return fread(buf, 1, n, f) == n ? 0 : -1;
}

long snapshot_load(const char *dir, Table *t, uint64_t *gen) {
    char path[512];
    snprintf(path, sizeof path, "%s/snapshot", dir);
    *gen = 0;
    FILE *f = fopen(path, "rb");
    if (f == NULL)
        return 0;                                          /* no snapshot yet */
    unsigned char hdr[16];
    long n = 0;
    char *key = malloc(256), *val = malloc(65536);
    if (key == NULL || val == NULL || read_exact(f, hdr, 16) != 0 || memcmp(hdr, "KVSNAP1", 8) != 0)
        goto corrupt;
    for (int i = 0; i < 8; i++)
        *gen |= (uint64_t)hdr[8 + i] << (8 * i);
    uint32_t crc = crc32(hdr, 16);
    for (;;) {
        unsigned char lens[8];
        if (read_exact(f, lens, 8) != 0)
            goto corrupt;
        uint32_t klen = (uint32_t)lens[0] | (uint32_t)lens[1] << 8 | (uint32_t)lens[2] << 16 | (uint32_t)lens[3] << 24;
        uint32_t vlen = (uint32_t)lens[4] | (uint32_t)lens[5] << 8 | (uint32_t)lens[6] << 16 | (uint32_t)lens[7] << 24;
        if (klen == 0xFFFFFFFFu) {
            unsigned char c[4];
            if (read_exact(f, c, 4) != 0)
                goto corrupt;
            uint32_t stored = (uint32_t)c[0] | (uint32_t)c[1] << 8 | (uint32_t)c[2] << 16 | (uint32_t)c[3] << 24;
            if (stored != crc)
                goto corrupt;
            break;
        }
        if (klen > 255 || vlen > 65536 || read_exact(f, key, klen) != 0 || read_exact(f, val, vlen) != 0)
            goto corrupt;
        unsigned char rec_crc_in[12];
        memcpy(rec_crc_in, &crc, 4);
        memcpy(rec_crc_in + 4, lens, 8);
        crc = crc32(rec_crc_in, sizeof rec_crc_in) ^ crc32(key, klen) ^ crc32(val, vlen);
        if (table_set(t, key, klen, val, vlen) != 0)
            goto corrupt;
        n++;
    }
    free(key);
    free(val);
    fclose(f);
    return n;
corrupt:
    free(key);
    free(val);
    fclose(f);
    return -1;
}
