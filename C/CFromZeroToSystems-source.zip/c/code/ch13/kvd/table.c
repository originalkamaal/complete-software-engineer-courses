// file: kvd/table.c
#include "table.h"

#include <stdlib.h>
#include <string.h>

static char tomb_marker;
#define TOMB (&tomb_marker)

static uint64_t hash(const char *s, uint32_t n) {
    uint64_t h = 14695981039346656037u;
    for (uint32_t i = 0; i < n; i++) {
        h ^= (unsigned char)s[i];
        h *= 1099511628211u;
    }
    return h;
}

int table_init(Table *t) {
    t->cap = 1024;
    t->len = t->used = 0;
    t->slots = calloc(t->cap, sizeof *t->slots);
    return t->slots ? 0 : -1;
}

void table_free(Table *t) {
    for (size_t i = 0; i < t->cap; i++)
        if (t->slots[i].key != NULL && t->slots[i].key != TOMB) {
            free(t->slots[i].key);
            free(t->slots[i].val);
        }
    free(t->slots);
    t->slots = NULL;
}

static size_t find(const Table *t, const char *key, uint32_t klen, uint64_t h, int *found) {
    size_t mask = t->cap - 1, i = (size_t)h & mask, tomb = SIZE_MAX;
    for (;;) {
        const Entry *e = &t->slots[i];
        if (e->key == NULL) {
            *found = 0;
            return tomb != SIZE_MAX ? tomb : i;
        }
        if (e->key == TOMB) {
            if (tomb == SIZE_MAX) tomb = i;
        } else if (e->hash == h && e->klen == klen && memcmp(e->key, key, klen) == 0) {
            *found = 1;
            return i;
        }
        i = (i + 1) & mask;
    }
}

static int rehash(Table *t, size_t cap) {
    Entry *n = calloc(cap, sizeof *n);
    if (n == NULL)
        return -1;
    for (size_t i = 0; i < t->cap; i++) {
        Entry *e = &t->slots[i];
        if (e->key == NULL || e->key == TOMB)
            continue;
        size_t j = (size_t)e->hash & (cap - 1);
        while (n[j].key != NULL)
            j = (j + 1) & (cap - 1);
        n[j] = *e;
    }
    free(t->slots);
    t->slots = n;
    t->cap = cap;
    t->used = t->len;
    return 0;
}

const Entry *table_get(const Table *t, const char *key, uint32_t klen) {
    int found;
    size_t i = find(t, key, klen, hash(key, klen), &found);
    return found ? &t->slots[i] : NULL;
}

int table_set(Table *t, const char *key, uint32_t klen, const char *val, uint32_t vlen) {
    uint64_t h = hash(key, klen);
    int found;
    size_t i = find(t, key, klen, h, &found);
    char *v = malloc((size_t)vlen + 1);
    if (v == NULL)
        return -1;
    memcpy(v, val, vlen);
    v[vlen] = '\0';
    if (found) {
        free(t->slots[i].val);
        t->slots[i].val = v;
        t->slots[i].vlen = vlen;
        return 0;
    }
    if ((t->used + 1) * 4 > t->cap * 3) {                 /* load factor 0.75 incl. tombstones */
        size_t cap = (t->len + 1) * 2 > t->cap ? t->cap * 2 : t->cap;
        if (rehash(t, cap) != 0) {
            free(v);
            return -1;
        }
        i = find(t, key, klen, h, &found);
    }
    char *k = malloc((size_t)klen + 1);
    if (k == NULL) {
        free(v);
        return -1;
    }
    memcpy(k, key, klen);
    k[klen] = '\0';
    if (t->slots[i].key == NULL)
        t->used++;
    t->slots[i] = (Entry){k, v, klen, vlen, h};
    t->len++;
    return 0;
}

int table_del(Table *t, const char *key, uint32_t klen) {
    int found;
    size_t i = find(t, key, klen, hash(key, klen), &found);
    if (!found)
        return 0;
    free(t->slots[i].key);
    free(t->slots[i].val);
    t->slots[i] = (Entry){.key = TOMB};
    t->len--;
    return 1;
}

const Entry *table_next(const Table *t, size_t *it) {
    while (*it < t->cap) {
        const Entry *e = &t->slots[(*it)++];
        if (e->key != NULL && e->key != TOMB)
            return e;
    }
    return NULL;
}
