// file: kvd/snapshot.h
#ifndef SNAPSHOT_H
#define SNAPSHOT_H

#include <stdint.h>
#include "table.h"

/* snapshot_write writes t to dir/snapshot atomically with generation gen. Returns 0 or -1. */
int snapshot_write(const char *dir, const Table *t, uint64_t gen);
/* snapshot_load loads dir/snapshot into t and sets *gen (0 if no snapshot exists).
   Returns the number of keys loaded, or -1 if the snapshot is corrupt. */
long snapshot_load(const char *dir, Table *t, uint64_t *gen);

#endif
