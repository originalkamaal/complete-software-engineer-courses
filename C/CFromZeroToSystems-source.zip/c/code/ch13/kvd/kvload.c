// file: kvd/kvload.c
/* kvload: C connections, each doing SET then GET in a loop for D seconds (one
   request in flight per connection), reporting throughput and latency. */
#define _GNU_SOURCE
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int port;
static double duration;

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

typedef struct { int id; long ops, errors; double lat_sum, lat_max; } Stats;

static int roundtrip(int fd, const char *req, size_t n, char *buf, size_t bufsz) {
    if (write(fd, req, n) != (ssize_t)n)
        return -1;
    size_t got = 0;
    while (got == 0 || buf[got - 1] != '\n') {
        ssize_t r = read(fd, buf + got, bufsz - got - 1);
        if (r <= 0) return -1;
        got += (size_t)r;
    }
    buf[got] = '\0';
    return 0;
}

static void *worker(void *arg) {
    Stats *s = arg;
    int fd = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
    struct sockaddr_in a = {.sin_family = AF_INET, .sin_port = htons((uint16_t)port),
                            .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    if (connect(fd, (struct sockaddr *)&a, sizeof a) != 0) { s->errors++; return NULL; }
    char req[128], buf[256];
    double end = now() + duration;
    for (long i = 0; now() < end; i++) {
        int n = (i & 1) ? snprintf(req, sizeof req, "GET w%d-k%ld\n", s->id, (i - 1) % 1000)
                        : snprintf(req, sizeof req, "SET w%d-k%ld value-%ld\n", s->id, i % 1000, i);
        double t0 = now();
        if (roundtrip(fd, req, (size_t)n, buf, sizeof buf) != 0 || buf[0] == '-') { s->errors++; break; }
        double lat = now() - t0;
        s->ops++;
        s->lat_sum += lat;
        if (lat > s->lat_max) s->lat_max = lat;
    }
    close(fd);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "usage: kvload PORT CONNECTIONS SECONDS\n"); return 2; }
    port = atoi(argv[1]);
    int conns = atoi(argv[2]);
    duration = atof(argv[3]);
    pthread_t *t = calloc((size_t)conns, sizeof *t);
    Stats *st = calloc((size_t)conns, sizeof *st);
    for (int i = 0; i < conns; i++) {
        st[i].id = i;
        pthread_create(&t[i], NULL, worker, &st[i]);
    }
    Stats total = {0};
    for (int i = 0; i < conns; i++) {
        pthread_join(t[i], NULL);
        total.ops += st[i].ops;
        total.errors += st[i].errors;
        total.lat_sum += st[i].lat_sum;
        if (st[i].lat_max > total.lat_max) total.lat_max = st[i].lat_max;
    }
    printf("%3d conns: %8.0f ops/s, mean latency %7.3f ms, max %6.1f ms, errors %ld\n", conns,
           total.ops / duration, total.ops ? total.lat_sum / total.ops * 1e3 : 0, total.lat_max * 1e3,
           total.errors);
    return 0;
}
