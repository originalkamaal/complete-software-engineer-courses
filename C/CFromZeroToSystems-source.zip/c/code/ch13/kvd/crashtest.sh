# file: kvd/crashtest.sh
#!/bin/bash
# crashtest.sh POLICY: write keys, kill -9 the server, restart, verify every acknowledged key.
set -u
POLICY=$1; PORT=7402; DIR=crash-$POLICY
rm -rf $DIR
./kvd --port $PORT --dir $DIR --fsync $POLICY 2> $DIR.log & PID=$!
sleep 0.3
exec 3<>/dev/tcp/127.0.0.1/$PORT
acked=0
for i in $(seq 1 2000); do
    printf 'SET key%d value-%d\n' $i $i >&3
    read -r line <&3
    [ "$line" = "+OK" ] && acked=$i
done
kill -9 $PID; wait $PID 2>/dev/null
exec 3>&-
./kvd --port $PORT --dir $DIR --fsync $POLICY 2>> $DIR.log & PID=$!
sleep 0.5
exec 3<>/dev/tcp/127.0.0.1/$PORT
missing=0
for i in $(seq 1 $acked); do
    printf 'GET key%d\n' $i >&3
    read -r line <&3
    [ "$line" = "\$value-$i" ] || missing=$((missing + 1))
done
echo "fsync=$POLICY: $acked writes acknowledged, $missing missing after kill -9 and restart"
grep -E 'replayed|recovered' $DIR.log | tail -n 2
kill $PID; wait $PID 2>/dev/null
