// file: kvd/wal.h
#ifndef WAL_H
#define WAL_H

#include <stddef.h>
#include <stdint.h>
#include "table.h"

enum fsync_policy { FSYNC_NO, FSYNC_EVERYSEC, FSYNC_ALWAYS };

typedef struct {
    int fd;
    enum fsync_policy policy;
    int dirty;                          /* written since the last fsync */
    uint64_t records;
} Wal;

uint32_t crc32(const void *data, size_t n);

/* wal_open opens (creating if needed) the log at path for appending. */
int wal_open(Wal *w, const char *path, enum fsync_policy policy);
/* wal_append writes one record; with FSYNC_ALWAYS it also fsyncs. Returns 0 or -1. */
int wal_append(Wal *w, char op, const char *key, uint32_t klen, const char *val, uint32_t vlen);
/* wal_sync fsyncs if anything was written since the last sync. */
int wal_sync(Wal *w);
void wal_close(Wal *w);
/* wal_replay applies every valid record in path to t. A torn or corrupt tail is
   truncated away. Returns the number of records applied, or -1 on I/O error. */
long wal_replay(const char *path, Table *t, long *truncated_bytes);

#endif
