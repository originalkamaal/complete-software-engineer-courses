// file: kvd/wal.c
#define _GNU_SOURCE
#include "wal.h"

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/* CRC-32 (IEEE 802.3, as used by zip and PNG), table-driven. */
uint32_t crc32(const void *data, size_t n) {
    static uint32_t table[256];
    static int ready;
    if (!ready) {
        for (uint32_t i = 0; i < 256; i++) {
            uint32_t c = i;
            for (int k = 0; k < 8; k++)
                c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            table[i] = c;
        }
        ready = 1;
    }
    uint32_t c = 0xFFFFFFFFu;
    const unsigned char *p = data;
    for (size_t i = 0; i < n; i++)
        c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

static void put32(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8);
    p[2] = (unsigned char)(v >> 16); p[3] = (unsigned char)(v >> 24);
}

static uint32_t get32(const unsigned char *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

int wal_open(Wal *w, const char *path, enum fsync_policy policy) {
    w->fd = open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
    w->policy = policy;
    w->dirty = 0;
    w->records = 0;
    return w->fd < 0 ? -1 : 0;
}

static int write_all(int fd, const void *buf, size_t n) {
    const char *p = buf;
    while (n > 0) {
        ssize_t r = write(fd, p, n);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        p += r;
        n -= (size_t)r;
    }
    return 0;
}

int wal_append(Wal *w, char op, const char *key, uint32_t klen, const char *val, uint32_t vlen) {
    size_t n = 13 + (size_t)klen + vlen;
    unsigned char stackbuf[512], *buf = n <= sizeof stackbuf ? stackbuf : malloc(n);
    if (buf == NULL)
        return -1;
    buf[4] = (unsigned char)op;
    put32(buf + 5, klen);
    put32(buf + 9, vlen);
    memcpy(buf + 13, key, klen);
    if (vlen)
        memcpy(buf + 13 + klen, val, vlen);
    put32(buf, crc32(buf + 4, n - 4));
    int rc = write_all(w->fd, buf, n);                 /* one write: one record */
    if (buf != stackbuf)
        free(buf);
    if (rc != 0)
        return -1;
    w->records++;
    w->dirty = 1;
    if (w->policy == FSYNC_ALWAYS)
        return wal_sync(w);
    return 0;
}

int wal_sync(Wal *w) {
    if (!w->dirty)
        return 0;
    if (fdatasync(w->fd) != 0)
        return -1;
    w->dirty = 0;
    return 0;
}

void wal_close(Wal *w) {
    if (w->fd >= 0) {
        wal_sync(w);
        close(w->fd);
        w->fd = -1;
    }
}

long wal_replay(const char *path, Table *t, long *truncated_bytes) {
    *truncated_bytes = 0;
    int fd = open(path, O_RDWR | O_CLOEXEC);
    if (fd < 0)
        return errno == ENOENT ? 0 : -1;
    struct stat st;
    if (fstat(fd, &st) != 0) {
        close(fd);
        return -1;
    }
    size_t size = (size_t)st.st_size;
    unsigned char *data = malloc(size ? size : 1);
    if (data == NULL || pread(fd, data, size, 0) != (ssize_t)size) {
        free(data);
        close(fd);
        return -1;
    }
    size_t off = 0;
    long applied = 0;
    while (off + 13 <= size) {
        uint32_t klen = get32(data + off + 5), vlen = get32(data + off + 9);
        if (klen > 255 || vlen > 65536 || 13 + (size_t)klen + vlen > size - off)
            break;                                     /* torn or corrupt: lengths impossible */
        size_t n = 13 + (size_t)klen + vlen;
        if (crc32(data + off + 4, n - 4) != get32(data + off))
            break;                                     /* torn or corrupt: checksum mismatch */
        const char *key = (const char *)data + off + 13, *val = key + klen;
        char op = (char)data[off + 4];
        if (op == 'S')
            table_set(t, key, klen, val, vlen);
        else if (op == 'D')
            table_del(t, key, klen);
        else
            break;
        off += n;
        applied++;
    }
    if (off < size) {                                  /* drop everything after the last good record */
        *truncated_bytes = (long)(size - off);
        if (ftruncate(fd, (off_t)off) != 0 || fsync(fd) != 0)
            applied = -1;
    }
    free(data);
    close(fd);
    return applied;
}
