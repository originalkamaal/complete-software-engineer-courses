// file: kvd/table.h
#ifndef TABLE_H
#define TABLE_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    char *key, *val;            /* key == NULL: empty; key == TOMB: deleted */
    uint32_t klen, vlen;
    uint64_t hash;
} Entry;

typedef struct {
    Entry *slots;
    size_t cap, len, used;      /* used = live + tombstones */
} Table;

int table_init(Table *t);
void table_free(Table *t);
/* table_get returns the entry for key or NULL. */
const Entry *table_get(const Table *t, const char *key, uint32_t klen);
/* table_set stores copies of key and value. Returns 0 or -1 (out of memory). */
int table_set(Table *t, const char *key, uint32_t klen, const char *val, uint32_t vlen);
/* table_del returns 1 if the key existed, 0 if not. */
int table_del(Table *t, const char *key, uint32_t klen);
/* table_next iterates live entries: start with *it = 0. */
const Entry *table_next(const Table *t, size_t *it);

#endif
