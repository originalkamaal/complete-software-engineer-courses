// file: kvd/kvd.c
/* kvd: a persistent key-value server. */
#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "snapshot.h"
#include "table.h"
#include "wal.h"

enum { IN_MAX = 70000, OUT_MAX = 1 << 20, IDLE_SECONDS = 300 };

typedef struct Conn {
    int fd;
    char in[IN_MAX];
    size_t in_len;
    char *out;
    size_t out_len, out_off;
    bool closing;
    time_t last_active;
    struct Conn *next;
} Conn;

static struct {
    Table table;
    Wal wal;
    const char *dir;
    uint64_t gen;                       /* current log generation */
    pid_t snap_child;
    uint64_t snap_gen;
    long commands, connections;
    time_t started;
    int ep;
    Conn *conns;
} S;

static volatile sig_atomic_t stop;

static void logmsg(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "kvd: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* ---------- persistence ---------- */

static void wal_path(char *buf, size_t n, uint64_t gen) {
    snprintf(buf, n, "%s/wal.%llu", S.dir, (unsigned long long)gen);
}

static int recover(void) {
    long keys = snapshot_load(S.dir, &S.table, &S.gen);
    if (keys < 0) {
        logmsg("snapshot is corrupt; refusing to start (move it away to start from the logs)");
        return -1;
    }
    if (S.gen == 0)
        S.gen = 1;
    logmsg("snapshot: %ld keys, generation %llu", keys, (unsigned long long)S.gen);
    for (uint64_t g = S.gen;; g++) {        /* replay wal.<gen>, wal.<gen+1>, ... */
        char path[512];
        wal_path(path, sizeof path, g);
        if (access(path, F_OK) != 0)
            break;
        long truncated;
        long n = wal_replay(path, &S.table, &truncated);
        if (n < 0)
            return -1;
        logmsg("replayed %s: %ld records%s", path, n, truncated ? " (torn tail truncated)" : "");
        if (truncated)
            logmsg("  discarded %ld bytes of incomplete or corrupt log", truncated);
        S.gen = g;
    }
    logmsg("recovered %zu keys", S.table.len);
    return 0;
}

static int start_bgsave(void) {
    if (S.snap_child > 0)
        return -1;                          /* one at a time */
    char path[512];
    Wal next;
    wal_path(path, sizeof path, S.gen + 1);
    if (wal_open(&next, path, S.wal.policy) != 0)
        return -1;
    wal_close(&S.wal);                      /* everything before this point is in the old log */
    S.wal = next;
    S.gen++;
    fflush(NULL);
    pid_t pid = fork();
    if (pid < 0)
        return -1;
    if (pid == 0) {                         /* child: copy-on-write view of the table */
        int rc = snapshot_write(S.dir, &S.table, S.gen);
        _exit(rc == 0 ? 0 : 1);
    }
    S.snap_child = pid;
    S.snap_gen = S.gen;
    return 0;
}

static void reap_bgsave(void) {
    int status;
    if (S.snap_child <= 0 || waitpid(S.snap_child, &status, WNOHANG) != S.snap_child)
        return;
    S.snap_child = 0;
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        logmsg("background save failed; logs kept");
        return;
    }
    for (uint64_t g = S.snap_gen; g-- > 1;) {   /* older logs are now covered by the snapshot */
        char path[512];
        wal_path(path, sizeof path, g);
        if (unlink(path) != 0)
            break;
    }
    logmsg("background save done: generation %llu", (unsigned long long)S.snap_gen);
}

/* ---------- protocol ---------- */

static void reply(Conn *c, const char *fmt, ...) {
    if (c->out == NULL && (c->out = malloc(OUT_MAX)) == NULL) {
        c->closing = true;
        return;
    }
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(c->out + c->out_len, OUT_MAX - c->out_len, fmt, ap);
    va_end(ap);
    if (n < 0 || (size_t)n >= OUT_MAX - c->out_len) {
        c->closing = true;                  /* client isn't reading its replies: drop it */
        return;
    }
    c->out_len += (size_t)n;
}

/* next_token splits off one space-separated word; *rest gets the remainder. */
static char *next_token(char **s) {
    while (**s == ' ')
        (*s)++;
    if (**s == '\0')
        return NULL;
    char *t = *s;
    while (**s != ' ' && **s != '\0')
        (*s)++;
    if (**s == ' ')
        *(*s)++ = '\0';
    return t;
}

static void execute(Conn *c, char *line) {
    S.commands++;
    char *rest = line, *cmd = next_token(&rest);
    if (cmd == NULL)
        return;
    for (char *p = cmd; *p; p++)
        *p = (char)toupper((unsigned char)*p);
    char *key = NULL;
    size_t klen = 0;
    if (strcmp(cmd, "GET") == 0 || strcmp(cmd, "SET") == 0 || strcmp(cmd, "DEL") == 0 ||
        strcmp(cmd, "INCR") == 0) {
        key = next_token(&rest);
        if (key == NULL || (klen = strlen(key)) > 255) {
            reply(c, "-ERR missing or too long key\n");
            return;
        }
    }
    if (strcmp(cmd, "PING") == 0) {
        reply(c, "+PONG\n");
    } else if (strcmp(cmd, "GET") == 0) {
        const Entry *e = table_get(&S.table, key, (uint32_t)klen);
        if (e) reply(c, "$%s\n", e->val);
        else reply(c, "(nil)\n");
    } else if (strcmp(cmd, "SET") == 0) {
        while (*rest == ' ') rest++;
        size_t vlen = strlen(rest);
        if (vlen > 65536) {
            reply(c, "-ERR value too long\n");
        } else if (wal_append(&S.wal, 'S', key, (uint32_t)klen, rest, (uint32_t)vlen) != 0) {
            reply(c, "-ERR log write failed: %s\n", strerror(errno));   /* not acknowledged */
        } else if (table_set(&S.table, key, (uint32_t)klen, rest, (uint32_t)vlen) != 0) {
            reply(c, "-ERR out of memory\n");
        } else {
            reply(c, "+OK\n");
        }
    } else if (strcmp(cmd, "DEL") == 0) {
        int existed = table_get(&S.table, key, (uint32_t)klen) != NULL;
        if (existed && wal_append(&S.wal, 'D', key, (uint32_t)klen, NULL, 0) != 0)
            reply(c, "-ERR log write failed\n");
        else {
            if (existed) table_del(&S.table, key, (uint32_t)klen);
            reply(c, ":%d\n", existed);
        }
    } else if (strcmp(cmd, "INCR") == 0) {
        const Entry *e = table_get(&S.table, key, (uint32_t)klen);
        long long v = 0;
        if (e) {
            char *end;
            errno = 0;
            v = strtoll(e->val, &end, 10);
            if (*end != '\0' || errno == ERANGE || e->vlen == 0) {
                reply(c, "-ERR value is not an integer\n");
                return;
            }
        }
        if (v == LLONG_MAX) {
            reply(c, "-ERR increment would overflow\n");
            return;
        }
        char buf[32];
        int n = snprintf(buf, sizeof buf, "%lld", v + 1);
        if (wal_append(&S.wal, 'S', key, (uint32_t)klen, buf, (uint32_t)n) != 0 ||
            table_set(&S.table, key, (uint32_t)klen, buf, (uint32_t)n) != 0)
            reply(c, "-ERR write failed\n");
        else
            reply(c, ":%s\n", buf);
    } else if (strcmp(cmd, "DBSIZE") == 0) {
        reply(c, ":%zu\n", S.table.len);
    } else if (strcmp(cmd, "BGSAVE") == 0) {
        if (start_bgsave() == 0) reply(c, "+Background save started\n");
        else reply(c, "-ERR background save already running or failed to start\n");
    } else if (strcmp(cmd, "INFO") == 0) {
        reply(c, "$keys=%zu commands=%ld connections=%ld wal_records=%llu generation=%llu uptime=%lds\n",
              S.table.len, S.commands, S.connections, (unsigned long long)S.wal.records,
              (unsigned long long)S.gen, (long)(time(NULL) - S.started));
    } else if (strcmp(cmd, "QUIT") == 0) {
        reply(c, "+BYE\n");
        c->closing = true;
    } else {
        reply(c, "-ERR unknown command '%.32s'\n", cmd);
    }
}

/* ---------- event loop (Chapter 10) ---------- */

static void conn_close(Conn *c) {
    epoll_ctl(S.ep, EPOLL_CTL_DEL, c->fd, NULL);
    close(c->fd);
    for (Conn **p = &S.conns; *p; p = &(*p)->next)
        if (*p == c) { *p = c->next; break; }
    free(c->out);
    free(c);
}

static bool flush_out(Conn *c) {           /* returns false if the connection was closed */
    while (c->out_off < c->out_len) {
        ssize_t w = send(c->fd, c->out + c->out_off, c->out_len - c->out_off, MSG_NOSIGNAL);
        if (w < 0) {
            if (errno == EAGAIN) {
                struct epoll_event ev = {.events = EPOLLOUT, .data.ptr = c};
                epoll_ctl(S.ep, EPOLL_CTL_MOD, c->fd, &ev);
                return true;
            }
            conn_close(c);
            return false;
        }
        c->out_off += (size_t)w;
    }
    c->out_len = c->out_off = 0;
    if (c->closing) {
        conn_close(c);
        return false;
    }
    struct epoll_event ev = {.events = EPOLLIN, .data.ptr = c};
    epoll_ctl(S.ep, EPOLL_CTL_MOD, c->fd, &ev);
    return true;
}

static void on_readable(Conn *c) {
    for (;;) {
        ssize_t n = recv(c->fd, c->in + c->in_len, sizeof c->in - c->in_len, 0);
        if (n == 0) { conn_close(c); return; }
        if (n < 0) {
            if (errno == EAGAIN) break;
            conn_close(c);
            return;
        }
        c->in_len += (size_t)n;
        if (c->in_len == sizeof c->in) break;
    }
    c->last_active = time(NULL);
    size_t start = 0;
    for (;;) {                              /* execute every complete line (pipelining) */
        char *nl = memchr(c->in + start, '\n', c->in_len - start);
        if (nl == NULL)
            break;
        *nl = '\0';
        if (nl > c->in + start && nl[-1] == '\r')
            nl[-1] = '\0';                  /* accept \r\n too */
        execute(c, c->in + start);
        start = (size_t)(nl - c->in) + 1;
        if (c->closing)
            break;
    }
    memmove(c->in, c->in + start, c->in_len - start);
    c->in_len -= start;
    if (c->in_len == sizeof c->in) {        /* a line longer than the buffer */
        reply(c, "-ERR line too long\n");
        c->closing = true;
    }
    flush_out(c);                           /* with --fsync always, each record was synced in SET */
}

static void on_accept(int lfd) {
    for (;;) {
        int fd = accept4(lfd, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
        if (fd < 0)
            return;
        Conn *c = calloc(1, sizeof *c);
        if (c == NULL) { close(fd); continue; }
        int one = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
        c->fd = fd;
        c->last_active = time(NULL);
        c->next = S.conns;
        S.conns = c;
        S.connections++;
        struct epoll_event ev = {.events = EPOLLIN, .data.ptr = c};
        epoll_ctl(S.ep, EPOLL_CTL_ADD, fd, &ev);
    }
}

static void on_term(int sig) { (void)sig; stop = 1; }

int main(int argc, char *argv[]) {
    const char *port = "7379";
    enum fsync_policy policy = FSYNC_EVERYSEC;
    S.dir = "data";
    for (int i = 1; i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--port") == 0) port = argv[i + 1];
        else if (strcmp(argv[i], "--dir") == 0) S.dir = argv[i + 1];
        else if (strcmp(argv[i], "--fsync") == 0) {
            if (strcmp(argv[i + 1], "always") == 0) policy = FSYNC_ALWAYS;
            else if (strcmp(argv[i + 1], "no") == 0) policy = FSYNC_NO;
            else policy = FSYNC_EVERYSEC;
        }
    }
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa = {.sa_handler = on_term};
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    mkdir(S.dir, 0755);
    S.started = time(NULL);

    if (table_init(&S.table) != 0 || recover() != 0)
        return 1;
    char path[512];
    wal_path(path, sizeof path, S.gen);
    if (wal_open(&S.wal, path, policy) != 0) {
        logmsg("cannot open %s: %s", path, strerror(errno));
        return 1;
    }

    int lfd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0), one = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons((uint16_t)atoi(port)),
                               .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    if (bind(lfd, (struct sockaddr *)&addr, sizeof addr) != 0 || listen(lfd, SOMAXCONN) != 0) {
        logmsg("cannot listen on %s: %s", port, strerror(errno));
        return 1;
    }
    S.ep = epoll_create1(EPOLL_CLOEXEC);
    struct epoll_event lev = {.events = EPOLLIN, .data.ptr = NULL};
    epoll_ctl(S.ep, EPOLL_CTL_ADD, lfd, &lev);
    logmsg("listening on 127.0.0.1:%s, fsync=%s, dir=%s", port,
           policy == FSYNC_ALWAYS ? "always" : policy == FSYNC_NO ? "no" : "everysec", S.dir);

    time_t last_tick = time(NULL);
    while (!stop) {
        struct epoll_event ev[128];
        int n = epoll_wait(S.ep, ev, 128, 200);
        for (int i = 0; i < n; i++) {
            Conn *c = ev[i].data.ptr;
            if (c == NULL) on_accept(lfd);
            else if (ev[i].events & (EPOLLERR | EPOLLHUP)) conn_close(c);
            else if (ev[i].events & EPOLLOUT) flush_out(c);
            else if (ev[i].events & EPOLLIN) on_readable(c);
        }
        time_t now = time(NULL);
        if (now != last_tick) {             /* once per second */
            last_tick = now;
            if (S.wal.policy == FSYNC_EVERYSEC && wal_sync(&S.wal) != 0)
                logmsg("fsync failed: %s", strerror(errno));
            reap_bgsave();
            for (Conn *c = S.conns, *next; c; c = next) {
                next = c->next;
                if (now - c->last_active > IDLE_SECONDS)
                    conn_close(c);
            }
        }
    }
    logmsg("shutting down: %ld commands served", S.commands);
    while (S.conns)
        conn_close(S.conns);
    if (S.snap_child > 0)
        waitpid(S.snap_child, NULL, 0);
    wal_close(&S.wal);
    table_free(&S.table);
    close(lfd);
    return 0;
}
