// file: membugs.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void leak(void) {
    char *p = malloc(100);
    strcpy(p, "never freed");
}                                              /* p goes out of scope; block is lost */

static void use_after_free(void) {
    int *p = malloc(sizeof *p);
    *p = 1;
    free(p);
    printf("use after free reads %d\n", *p);   /* UB */
}

static void double_free(void) {
    char *p = malloc(8);
    free(p);
    free(p);                                   /* UB: corrupts the allocator */
}

int main(int argc, char *argv[]) {
    if (argc < 2)
        return 2;
    if (strcmp(argv[1], "leak") == 0)
        leak();
    else if (strcmp(argv[1], "uaf") == 0)
        use_after_free();
    else if (strcmp(argv[1], "double") == 0)
        double_free();
    return 0;
}
