// file: fam.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct msg {
    size_t len;
    char data[];                           /* flexible array member: must be last */
};

static struct msg *msg_new(const char *s) {
    size_t n = strlen(s);
    struct msg *m = malloc(sizeof *m + n + 1);   /* fixed part + the array's bytes */
    if (!m) return NULL;
    m->len = n;
    memcpy(m->data, s, n + 1);
    return m;
}

int main(void) {
    struct msg *m = msg_new("flexible");
    printf("sizeof(struct msg) = %zu, allocated %zu bytes, data = \"%s\"\n", sizeof(struct msg),
           sizeof *m + m->len + 1, m->data);

    struct msg copy = *m;                  /* copies len only: copy.data has no storage of its own */
    printf("copy.len = %zu; copy.data is at %p, %td bytes after &copy: just past the end of 'copy'\n",
           copy.len, (void *)copy.data, (char *)copy.data - (char *)&copy);
    free(m);
    return 0;
}
