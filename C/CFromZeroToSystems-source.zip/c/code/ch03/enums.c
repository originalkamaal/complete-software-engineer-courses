// file: enums.c
#include <stdio.h>

enum color { RED, GREEN = 5, BLUE };          /* 0, 5, 6 */

enum perm {                                   /* flag values: one bit each */
    PERM_READ  = 1u << 0,
    PERM_WRITE = 1u << 1,
    PERM_EXEC  = 1u << 2,
};

struct flags {
    unsigned int visible : 1;
    unsigned int dirty   : 1;
    unsigned int level   : 4;                  /* 0..15 */
    unsigned int         : 0;                  /* unnamed zero-width: start a new unit */
    unsigned int id      : 10;
};

int main(void) {
    printf("RED=%d GREEN=%d BLUE=%d sizeof(enum color)=%zu\n", RED, GREEN, BLUE, sizeof(enum color));

    enum color c = 42;                         /* no error: enums are integers */
    printf("c = %d (no range checking)\n", c);

    unsigned p = PERM_READ | PERM_EXEC;
    printf("perm 0x%X: read=%d write=%d exec=%d\n", p,
           !!(p & PERM_READ), !!(p & PERM_WRITE), !!(p & PERM_EXEC));

    struct flags f = {.visible = 1, .level = 9, .id = 1000};
    f.level = 17;                              /* stored modulo 16: 1 */
    printf("visible=%u dirty=%u level=%u id=%u sizeof=%zu\n",
           f.visible, f.dirty, f.level, f.id, sizeof f);
    return 0;
}
