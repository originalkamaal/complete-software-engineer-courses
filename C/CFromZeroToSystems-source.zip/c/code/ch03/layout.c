// file: layout.c
#include <stdalign.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

struct bad  { char a; double b; char c; int d; };
struct good { double b; int d; char a; char c; };

#define SHOW(T, m) printf("  %-2s offset %2zu size %zu\n", #m, offsetof(T, m), sizeof(((T *)0)->m))

int main(void) {
    printf("alignof: char %zu, int %zu, double %zu, long double %zu, max_align_t %zu\n",
           alignof(char), alignof(int), alignof(double), alignof(long double), alignof(max_align_t));

    printf("struct bad: size %zu\n", sizeof(struct bad));
    SHOW(struct bad, a); SHOW(struct bad, b); SHOW(struct bad, c); SHOW(struct bad, d);
    printf("struct good: size %zu\n", sizeof(struct good));
    SHOW(struct good, b); SHOW(struct good, d); SHOW(struct good, a); SHOW(struct good, c);

    struct bad arr[2];
    printf("array of 2 bad: %zu bytes; &arr[1] - &arr[0] = %td bytes\n",
           sizeof arr, (char *)&arr[1] - (char *)&arr[0]);
    return 0;
}
