// file: vecarena/vec.c
#include "vec.h"

#include <stdint.h>
#include <stdlib.h>

int vec_push(Vec *v, int x) {
    if (v->len == v->cap) {
        size_t new_cap = v->cap ? v->cap * 2 : 8;
        if (new_cap < v->cap || new_cap > SIZE_MAX / sizeof *v->data)
            return -1;                                  /* size overflow */
        int *p = realloc(v->data, new_cap * sizeof *v->data);
        if (p == NULL)
            return -1;                                  /* v unchanged (DT-32) */
        v->data = p;
        v->cap = new_cap;
    }
    v->data[v->len++] = x;
    return 0;
}

int vec_get(const Vec *v, size_t i, int *out) {
    if (i >= v->len)
        return -1;
    *out = v->data[i];
    return 0;
}

void vec_free(Vec *v) {
    free(v->data);
    *v = (Vec){0};                                      /* reset to a valid empty vector */
}
