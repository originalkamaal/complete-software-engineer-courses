// file: vecarena/vec.h
#ifndef VEC_H
#define VEC_H

#include <stddef.h>

typedef struct {
    int *data;
    size_t len, cap;
} Vec;                              /* small value type: zero-initialise with Vec v = {0}; */

/* vec_push appends x. Returns 0, or -1 if memory could not be allocated
   (the vector is then unchanged). */
int vec_push(Vec *v, int x);

/* vec_get stores element i in *out; returns -1 if i is out of range. */
int vec_get(const Vec *v, size_t i, int *out);

/* vec_free releases the storage and resets v to empty. */
void vec_free(Vec *v);

#endif
