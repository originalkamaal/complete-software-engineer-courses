// file: vecarena/demo.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "arena.h"
#include "vec.h"

int main(void) {
    enum { N = 10000 };
    Arena *a = arena_new(16 * 1024);
    Vec lengths = {0};
    char **words = malloc(N * sizeof *words);
    if (a == NULL || words == NULL)
        return 1;

    char buf[32];
    for (int i = 0; i < N; i++) {
        int n = snprintf(buf, sizeof buf, "word-%d", i * 7919 % 100003);
        words[i] = arena_strdup(a, buf);
        if (words[i] == NULL || vec_push(&lengths, n) != 0)
            return 1;
    }

    char *big = arena_alloc(a, 100000);         /* oversized: gets its own chunk */
    if (big == NULL)
        return 1;
    memset(big, 'x', 100000);

    long total = 0;
    for (size_t i = 0; i < lengths.len; i++) {
        int len;
        vec_get(&lengths, i, &len);
        total += len;
    }
    int out;
    printf("words: %zu, first \"%s\", last \"%s\"\n", lengths.len, words[0], words[N - 1]);
    printf("total characters: %ld, vec capacity: %zu\n", total, lengths.cap);
    printf("vec_get(%d) -> %d (out of range)\n", N, vec_get(&lengths, N, &out));
    printf("arena chunks (malloc calls): %zu, versus %d with one malloc per word\n",
           arena_chunks(a), N);

    vec_free(&lengths);
    free(words);
    arena_free(a);                               /* 10,000 strings released at once */
    return 0;
}
