// file: vecarena/arena.c
#include "arena.h"

#include <stdalign.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct chunk {
    struct chunk *next;
    size_t cap, used;
    alignas(max_align_t) unsigned char mem[];   /* flexible array, maximally aligned */
} Chunk;

struct arena {
    Chunk *head;                     /* most recent chunk first */
    size_t chunk_size, nchunks;
};

Arena *arena_new(size_t chunk_size) {
    Arena *a = malloc(sizeof *a);
    if (a == NULL)
        return NULL;
    *a = (Arena){.chunk_size = chunk_size ? chunk_size : 64 * 1024};
    return a;
}

static Chunk *chunk_new(size_t cap) {
    if (cap > SIZE_MAX - sizeof(Chunk))
        return NULL;
    Chunk *c = malloc(sizeof *c + cap);
    if (c != NULL)
        *c = (Chunk){.cap = cap};
    return c;
}

void *arena_alloc(Arena *a, size_t size) {
    const size_t align = alignof(max_align_t);
    if (size > SIZE_MAX - align)
        return NULL;
    size = (size + align - 1) & ~(align - 1);   /* round up: keeps every block aligned */
    Chunk *c = a->head;
    if (c == NULL || c->cap - c->used < size) {
        size_t cap = size > a->chunk_size ? size : a->chunk_size;
        Chunk *n = chunk_new(cap);
        if (n == NULL)
            return NULL;
        if (size > a->chunk_size && c != NULL) {
            n->next = c->next;               /* oversized: keep the current chunk on top */
            c->next = n;
        } else {
            n->next = c;
            a->head = n;
        }
        a->nchunks++;
        c = n;
    }
    void *p = c->mem + c->used;
    c->used += size;
    return p;
}

char *arena_strdup(Arena *a, const char *s) {
    size_t n = strlen(s) + 1;
    char *p = arena_alloc(a, n);
    if (p != NULL)
        memcpy(p, s, n);
    return p;
}

size_t arena_chunks(const Arena *a) { return a->nchunks; }

void arena_free(Arena *a) {
    if (a == NULL)
        return;
    for (Chunk *c = a->head; c != NULL;) {
        Chunk *next = c->next;
        free(c);
        c = next;
    }
    free(a);
}
