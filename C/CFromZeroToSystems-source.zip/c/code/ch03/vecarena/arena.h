// file: vecarena/arena.h
#ifndef ARENA_H
#define ARENA_H

#include <stddef.h>

typedef struct arena Arena;          /* opaque */

/* arena_new creates an arena that allocates in chunks of chunk_size bytes. */
Arena *arena_new(size_t chunk_size);

/* arena_alloc returns size bytes aligned for any type, or NULL. The memory
   lives until arena_free; it cannot be freed individually. */
void *arena_alloc(Arena *a, size_t size);

/* arena_strdup copies s into the arena. */
char *arena_strdup(Arena *a, const char *s);

/* arena_free releases every allocation made from a, and a itself. */
void arena_free(Arena *a);

/* arena_chunks reports how many chunks (malloc calls) the arena has made. */
size_t arena_chunks(const Arena *a);

#endif
