// file: punning.c
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static uint64_t bits_memcpy(double d) {
    uint64_t u;
    memcpy(&u, &d, sizeof u);       /* always correct; compiled to a single register move */
    return u;
}

static uint64_t bits_union(double d) {
    union { double d; uint64_t u; } x = {.d = d};
    return x.u;                     /* allowed in C (not in C++): reads the bytes as the other type */
}

static uint64_t bits_cast(double d) {
    return *(uint64_t *)&d;         /* violates strict aliasing: UB */
}

int main(void) {
    double d = -1.5;
    printf("memcpy: 0x%016" PRIX64 "\n", bits_memcpy(d));
    printf("union : 0x%016" PRIX64 "\n", bits_union(d));
    printf("cast  : 0x%016" PRIX64 "\n", bits_cast(d));
    uint64_t u = bits_memcpy(d);
    printf("sign %d, exponent %d, mantissa 0x%013" PRIX64 "\n",
           (int)(u >> 63), (int)((u >> 52) & 0x7FF) - 1023, u & ((UINT64_C(1) << 52) - 1));
    return 0;
}
