// file: dyn.c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    size_t n = 5;
    int *a = malloc(n * sizeof *a);           /* sizeof *a: stays right if a's type changes */
    if (a == NULL) {
        perror("malloc");
        return 1;
    }
    for (size_t i = 0; i < n; i++)
        a[i] = (int)(i * i);

    /* grow: assign to a temporary so the old block is not leaked on failure */
    int *bigger = realloc(a, 2 * n * sizeof *a);
    if (bigger == NULL) {
        free(a);
        return 1;
    }
    a = bigger;
    memset(a + n, 0, n * sizeof *a);          /* new part is uninitialised: clear it */
    n *= 2;
    for (size_t i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    free(a);
    a = NULL;                                 /* defensive: a can no longer dangle */

    int *z = calloc(4, sizeof *z);            /* zeroed */
    printf("calloc: %d %d %d %d\n", z[0], z[1], z[2], z[3]);
    free(z);

    /* size overflow: calloc checks it, a naive malloc(count * size) does not */
    size_t huge = SIZE_MAX / 4 + 2;
    void *bad = calloc(huge, 4);
    printf("calloc(SIZE_MAX/4 + 2, 4) = %p\n", bad);
    printf("naive count*size wraps to %zu bytes\n", huge * 4);

    free(NULL);                               /* always allowed: does nothing */
    return 0;
}
