// file: counter/counter.h
#ifndef COUNTER_H
#define COUNTER_H

typedef struct counter Counter;      /* incomplete type: layout unknown to users */

Counter *counter_new(const char *name);   /* caller owns the result; free with counter_free */
void counter_free(Counter *c);
void counter_add(Counter *c, long n);
long counter_value(const Counter *c);
const char *counter_name(const Counter *c);

#endif
