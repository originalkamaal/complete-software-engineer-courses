// file: counter/main.c
#include <stdio.h>
#include "counter.h"

int main(void) {
    Counter *c = counter_new("requests");
    if (c == NULL)
        return 1;
    counter_add(c, 3);
    counter_add(c, 4);
    printf("%s = %ld\n", counter_name(c), counter_value(c));
    /* c->value = 0;   error: invalid use of incomplete typedef 'Counter' */
    counter_free(c);
    return 0;
}
