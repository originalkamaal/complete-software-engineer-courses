#include "counter.h"
int f(Counter *c) { return c->value; }
