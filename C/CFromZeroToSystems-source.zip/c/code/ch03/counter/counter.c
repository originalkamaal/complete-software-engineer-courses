// file: counter/counter.c
#include "counter.h"

#include <stdlib.h>
#include <string.h>

struct counter {                     /* the definition lives only here */
    long value;
    char name[];
};

Counter *counter_new(const char *name) {
    size_t n = strlen(name) + 1;
    Counter *c = malloc(sizeof *c + n);
    if (c == NULL)
        return NULL;
    c->value = 0;
    memcpy(c->name, name, n);
    return c;
}

void counter_free(Counter *c) { free(c); }
void counter_add(Counter *c, long n) { c->value += n; }
long counter_value(const Counter *c) { return c->value; }
const char *counter_name(const Counter *c) { return c->name; }
