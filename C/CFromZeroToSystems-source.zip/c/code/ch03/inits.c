// file: inits.c
#include <stdio.h>

struct config { int port; int backlog; const char *host; double timeout; };

static int calls(void) {
    static int n;              /* static local: zero before main, keeps its value between calls */
    return ++n;
}

int main(void) {
    struct config c = { .host = "localhost", .port = 8080 };   /* backlog and timeout become 0 */
    printf("port %d backlog %d host %s timeout %.1f\n", c.port, c.backlog, c.host, c.timeout);

    int days[12] = { [1] = 28, [0] = 31, [11] = 31 };         /* the others are 0 */
    printf("days[0..2] = %d %d %d, days[11] = %d\n", days[0], days[1], days[2], days[11]);

    int squares[] = { [4] = 16, [9] = 81 };                    /* size taken from the largest index */
    printf("sizeof squares / sizeof squares[0] = %zu\n", sizeof squares / sizeof squares[0]);

    char name[8] = "ab";                                       /* "ab", then 6 zero bytes */
    printf("name[5] = %d\n", name[5]);

    calls(); calls();
    printf("calls() returned %d on the third call\n", calls());
    return 0;
}
