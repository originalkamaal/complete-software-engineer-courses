// file: shallow.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person { char *name; int age; };

static struct person person_new(const char *name, int age) {
    struct person p = { malloc(strlen(name) + 1), age };
    strcpy(p.name, name);
    return p;                                /* returning a struct by value is fine */
}

static struct person person_clone(struct person p) {     /* a deep copy: new buffer for name */
    return person_new(p.name, p.age);
}

int main(void) {
    struct person a = person_new("Ada", 36);
    struct person b = a;                     /* shallow: b.name == a.name */
    struct person c = person_clone(a);       /* deep: c.name is its own copy */
    b.name[0] = 'E';                         /* changes a's name too */
    printf("a.name = %s, b.name = %s, c.name = %s\n", a.name, b.name, c.name);
    printf("a.name == b.name? %s; a.name == c.name? %s\n", a.name == b.name ? "yes" : "no",
           a.name == c.name ? "yes" : "no");
    fflush(stdout);                          /* the crash below would lose buffered output */
    free(a.name);
    free(c.name);
    free(b.name);                            /* bug: the same block again */
    return 0;
}
