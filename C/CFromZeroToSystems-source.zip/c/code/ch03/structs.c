// file: structs.c
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[32];
    int age;
    double balance;
} Account;

static Account make_account(const char *name, int age) {    /* returned by value */
    Account a = {.age = age, .balance = 0.0};
    snprintf(a.name, sizeof a.name, "%s", name);
    return a;
}

static void deposit(Account *a, double amount) {            /* modifies the original */
    a->balance += amount;                                   /* a->x means (*a).x */
}

static void print_account(const Account *a) {              /* const pointer: read-only, no copy */
    printf("%-6s age %2d balance %8.2f\n", a->name, a->age, a->balance);
}

int main(void) {
    Account alice = make_account("Alice", 30);
    Account copy = alice;                   /* struct assignment copies every member, even arrays */
    deposit(&alice, 100.50);
    print_account(&alice);
    print_account(&copy);                   /* unaffected */
    printf("sizeof(Account) = %zu\n", sizeof(Account));

    /* comparing structs: no == operator; compare members (memcmp is unsafe: padding, DT-35) */
    printf("same name? %s\n", strcmp(alice.name, copy.name) == 0 ? "yes" : "no");
    return 0;
}
