// file: enumbits.c
#include <stdio.h>

enum color { RED, GREEN, BLUE, COLOR_COUNT };             /* COLOR_COUNT: a common idiom for the number of values */

static const char *const names[COLOR_COUNT] = { [RED] = "red", [GREEN] = "green", [BLUE] = "blue" };

static const char *name(enum color c) {
    if ((unsigned)c >= COLOR_COUNT) return "invalid";       /* an enum can hold any int */
    return names[c];
}

struct flags {
    unsigned int visible : 1;
    unsigned int level   : 3;                              /* 0..7 */
    int          signed3 : 3;                              /* -4..3 with an explicitly signed type */
};

int main(void) {
    enum color c = (enum color)7;
    printf("%s %s %s; sizeof(enum color) = %zu\n", name(GREEN), name(BLUE), name(c), sizeof(enum color));

    struct flags f = {0};
    f.level = 9;                                           /* does not fit in 3 bits: keeps the low 3 bits */
    f.signed3 = 3;
    f.signed3 += 1;                                        /* 4 does not fit in -4..3 */
    printf("level = %u (9 truncated to 3 bits), signed3 = %d, sizeof(struct flags) = %zu\n",
           (unsigned)f.level, (int)f.signed3, sizeof f);
    return 0;
}
