// file: flex.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    size_t len;
    char data[];                     /* flexible array member: must be last */
} Str;

static Str *str_new(const char *s) {
    size_t len = strlen(s);
    Str *p = malloc(sizeof *p + len + 1);    /* header + characters + terminator, one block */
    if (p == NULL)
        return NULL;
    p->len = len;
    memcpy(p->data, s, len + 1);
    return p;
}

int main(void) {
    Str *s = str_new("flexible");
    if (s == NULL)
        return 1;
    printf("len=%zu data=\"%s\" sizeof(Str)=%zu\n", s->len, s->data, sizeof(Str));
    free(s);                         /* one free releases header and data */
    return 0;
}
