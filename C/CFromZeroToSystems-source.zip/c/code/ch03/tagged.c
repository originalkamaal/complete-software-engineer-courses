// file: tagged.c
#include <stdio.h>

typedef enum { VAL_INT, VAL_DOUBLE, VAL_STR } ValKind;

typedef struct {
    ValKind kind;               /* the tag: which member is valid */
    union {                     /* anonymous union (C11): members accessed as v.i, v.d, v.s */
        long long i;
        double d;
        const char *s;
    };
} Value;

static void print_value(Value v) {
    switch (v.kind) {
    case VAL_INT:    printf("int %lld\n", v.i); break;
    case VAL_DOUBLE: printf("double %g\n", v.d); break;
    case VAL_STR:    printf("string \"%s\"\n", v.s); break;
    }
}

int main(void) {
    Value vals[] = {
        {.kind = VAL_INT, .i = 42},
        {.kind = VAL_DOUBLE, .d = 2.5},
        {.kind = VAL_STR, .s = "hello"},
    };
    for (size_t i = 0; i < 3; i++)
        print_value(vals[i]);
    printf("sizeof(Value) = %zu (tag 4 + padding 4 + largest member 8)\n", sizeof(Value));
    return 0;
}
