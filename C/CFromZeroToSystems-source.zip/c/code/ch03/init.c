// file: init.c
#include <stdio.h>

struct point { int x, y; };

static int counter;                         /* static: zero */
static struct point origin;                 /* static: every member zero */

static int next_id(void) {
    static int id = 100;                    /* initialised once, before main */
    return id++;
}

int main(void) {
    int arr[5] = {1, 2};                    /* remaining elements are zero */
    int zeros[100] = {0};                   /* idiom: all zero */
    int sparse[8] = {[2] = 5, [6] = 9};     /* designated array initialisers (C99) */
    struct point p = {.y = 3};              /* designated member initialiser; x = 0 */
    struct point *q = &(struct point){7, 8};/* compound literal: an unnamed object */

    printf("counter=%d origin=(%d,%d)\n", counter, origin.x, origin.y);
    printf("arr: %d %d %d %d %d\n", arr[0], arr[1], arr[2], arr[3], arr[4]);
    printf("zeros[99]=%d sparse: ", zeros[99]);
    for (int i = 0; i < 8; i++)
        printf("%d ", sparse[i]);
    printf("\np=(%d,%d) *q=(%d,%d)\n", p.x, p.y, q->x, q->y);
    printf("ids: %d %d %d\n", next_id(), next_id(), next_id());
    return 0;
}
