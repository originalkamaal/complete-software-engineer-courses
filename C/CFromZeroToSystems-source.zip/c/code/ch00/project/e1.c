#include "mathz.h"
int main(void){return 0;}
