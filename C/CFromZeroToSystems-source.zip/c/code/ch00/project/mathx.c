// file: project/mathx.c
#include "mathx.h"

int gcd(int a, int b) {
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a;
}

long long ipow(int base, unsigned exp) {
    long long result = 1, b = base;
    while (exp > 0) {
        if (exp & 1u)
            result *= b;
        b *= b;
        exp >>= 1;
    }
    return result;
}
