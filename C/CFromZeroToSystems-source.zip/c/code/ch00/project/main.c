// file: project/main.c
#include <stdio.h>
#include "mathx.h"

int main(void) {
    printf("gcd(84, 36) = %d\n", gcd(84, 36));
    printf("gcd(17, 5)  = %d\n", gcd(17, 5));
    printf("3^13 = %lld\n", ipow(3, 13));
    printf("2^62 = %lld\n", ipow(2, 62));
    return 0;
}
