// file: project/mathx.h
#ifndef MATHX_H
#define MATHX_H

/* gcd returns the greatest common divisor of a and b (both >= 0). */
int gcd(int a, int b);

/* ipow returns base raised to exp, by repeated squaring. */
long long ipow(int base, unsigned exp);

#endif
