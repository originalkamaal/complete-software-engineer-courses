// file: quiet.c
#include <stdio.h>

int sum(const int *a, int n) {
    int total;                       /* bug 1: not initialised */
    for (int i = 0; i <= n; i++)     /* bug 2: off by one */
        total += a[i];
    return total;
}

int main(void) {
    int v[4] = {1, 2, 3, 4};
    unsigned big = 3000000000u;
    if (big > -1)                    /* bug 3: -1 becomes UINT_MAX */
        printf("big is greater than -1\n");
    printf("sum = %d\n", sum(v, 4));
    printf("%d\n", "oops");          /* bug 4: wrong format */
    return 0;
}
