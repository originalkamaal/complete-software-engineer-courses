// file: layout.c
#include <stdio.h>
#include <stdlib.h>

int initialised_global = 42;     /* .data: has a non-zero initial value in the file */
int zero_global;                 /* .bss: zero-initialised, takes no space in the file */
static const char message[] = "constant";  /* .rodata: read-only data */

int main(void) {
    int local = 1;                            /* stack */
    static int counter = 5;                   /* .data, despite being inside main */
    int *heap = malloc(sizeof *heap);         /* heap */
    if (heap == NULL)
        return 1;

    printf("code    main               %p\n", (void *)main);
    printf("rodata  message            %p\n", (void *)message);
    printf("data    initialised_global %p\n", (void *)&initialised_global);
    printf("data    counter (static)   %p\n", (void *)&counter);
    printf("bss     zero_global        %p\n", (void *)&zero_global);
    printf("heap    *heap              %p\n", (void *)heap);
    printf("stack   local              %p\n", (void *)&local);
    free(heap);
    return 0;
}
