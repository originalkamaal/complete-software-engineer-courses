// file: stages.c
#include <stdio.h>
#define GREETING "Hello"
#define SQUARE(x) ((x) * (x))

int main(void) {
    int n = 7;
    printf("%s, square of %d is %d\n", GREETING, n, SQUARE(n));
    return 0;
}
