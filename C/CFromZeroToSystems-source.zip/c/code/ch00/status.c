// file: status.c
#include <stdlib.h>

int main(void) {
    return 3;  /* any value 0-255 is visible to the shell */
}
