// file: twos.c
#include <limits.h>
#include <stdint.h>
#include <stdio.h>

int main(void) {
    int8_t a = -1, b = -128;
    printf("-1   as bits: 0x%02X\n", (uint8_t)a);
    printf("-128 as bits: 0x%02X\n", (uint8_t)b);

    unsigned u = UINT_MAX;
    u = u + 1u;                          /* defined: wraps to 0 */
    printf("UINT_MAX + 1u = %u\n", u);

    uint8_t big = 200;
    int8_t conv = (int8_t)big;          /* implementation-defined before C23; -56 on GCC */
    printf("(int8_t)200 = %d\n", conv);
    return 0;
}
