// file: err_run.c
#include <stdio.h>

int main(void) {
    int *p = NULL;
    printf("about to crash\n");
    fflush(stdout);
    return *p;  /* undefined behaviour: null pointer dereference */
}
