// file: sizes.c
#include <limits.h>
#include <stdint.h>
#include <stdio.h>

int main(void) {
    printf("char      %zu byte(s), CHAR_BIT = %d\n", sizeof(char), CHAR_BIT);
    printf("short     %zu\n", sizeof(short));
    printf("int       %zu, range %d .. %d\n", sizeof(int), INT_MIN, INT_MAX);
    printf("long      %zu\n", sizeof(long));
    printf("long long %zu\n", sizeof(long long));
    printf("pointer   %zu\n", sizeof(void *));
    printf("int32_t   %zu, uint64_t %zu\n", sizeof(int32_t), sizeof(uint64_t));
    printf("float %zu, double %zu, long double %zu\n",
           sizeof(float), sizeof(double), sizeof(long double));
    return 0;
}
