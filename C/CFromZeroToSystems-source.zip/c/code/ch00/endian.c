// file: endian.c
#include <stdint.h>
#include <stdio.h>

int main(void) {
    uint32_t x = 0x11223344;
    unsigned char *bytes = (unsigned char *)&x;  /* view the object as raw bytes: allowed */
    for (int i = 0; i < 4; i++)
        printf("byte %d at %p: 0x%02x\n", i, (void *)&bytes[i], bytes[i]);
    return 0;
}
