// file: err_link.c
#include <stdio.h>

int helper(int);  /* declared, never defined */

int main(void) {
    printf("%d\n", helper(1));
    return 0;
}
