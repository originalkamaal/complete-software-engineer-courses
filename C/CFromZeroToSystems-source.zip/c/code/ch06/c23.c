// file: c23.c
#include <stdbit.h>
#include <stdckdint.h>
#include <stdio.h>

constexpr int N = 4;                       /* a true compile-time constant object */
enum small : unsigned char { A, B, C };    /* enum with a chosen underlying type */

[[nodiscard]] static int must_check(void) { return 7; }

int main(void) {
    int *p = nullptr;                      /* nullptr has its own type, nullptr_t */
    bool ok = true;                        /* keywords now: no <stdbool.h> */
    typeof(N) arr[N] = {};                 /* typeof; empty initialiser zeroes everything */
    auto mask = 0b1010'1010;               /* binary literal, digit separator, type inference */
    static_assert(sizeof(int) == 4);       /* message now optional */

    int sum;
    if (ckd_add(&sum, 2'000'000'000, 2'000'000'000))   /* checked arithmetic: no UB */
        printf("ckd_add overflowed; wrapped result %d\n", sum);
    unsigned long long big;
    bool ovf = ckd_mul(&big, 4'000'000'000ULL, 4ULL);
    printf("ckd_mul ok=%d result=%llu\n", !ovf, big);

    printf("nullptr=%d ok=%d sizeof arr=%zu mask=%d sizeof(enum small)=%zu\n",
           p == nullptr, ok, sizeof arr, mask, sizeof(enum small));
    printf("stdc_count_ones(0xF0F0u)=%u stdc_bit_width(1000u)=%u stdc_leading_zeros(1u)=%u\n",
           stdc_count_ones(0xF0F0u), stdc_bit_width(1000u), stdc_leading_zeros(1u));
    printf("%d\n", must_check());
    must_check();                          /* warning: result ignored */
    return 0;
}
