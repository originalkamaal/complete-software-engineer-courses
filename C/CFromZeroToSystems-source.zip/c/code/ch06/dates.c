// file: dates.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static void show(const char *label, struct tm tm) {
    char buf[64];
    time_t t = mktime(&tm);                          /* normalises tm in place */
    strftime(buf, sizeof buf, "%Y-%m-%d %H:%M %Z (%A)", &tm);
    printf("%-26s -> %s, time_t %lld\n", label, buf, (long long)t);
}

int main(void) {
    setenv("TZ", "Europe/Berlin", 1);                /* fixed zone: reproducible output */
    tzset();
    struct tm tm = { .tm_year = 2024 - 1900, .tm_mon = 1, .tm_mday = 30, .tm_hour = 12, .tm_isdst = -1 };
    show("2024-02-30 12:00", tm);                    /* there is no February 30 */

    struct tm base = { .tm_year = 2024 - 1900, .tm_mon = 0, .tm_mday = 31, .tm_hour = 9, .tm_isdst = -1 };
    base.tm_mon += 1;                                /* "one month after January 31" */
    show("2024-01-31 plus one month", base);

    struct tm dst = { .tm_year = 2024 - 1900, .tm_mon = 2, .tm_mday = 31, .tm_hour = 2, .tm_min = 30, .tm_isdst = -1 };
    show("2024-03-31 02:30 (DST gap)", dst);         /* clocks jumped from 02:00 to 03:00 */

    return 0;
}
