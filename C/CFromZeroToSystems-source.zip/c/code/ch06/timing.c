// file: timing.c
#define _DEFAULT_SOURCE                    /* POSIX functions plus common extensions such as timegm */
#include <stdio.h>
#include <time.h>

static double elapsed(struct timespec a, struct timespec b) {
    return (double)(b.tv_sec - a.tv_sec) + (double)(b.tv_nsec - a.tv_nsec) / 1e9;
}

int main(void) {
    time_t now = 1767225600;                       /* fixed instant so the output is reproducible */
    struct tm utc;
    gmtime_r(&now, &utc);                          /* thread-safe; gmtime() uses a static buffer */
    char buf[64];
    strftime(buf, sizeof buf, "%Y-%m-%d %H:%M:%S UTC (%A, day %j)", &utc);
    printf("%lld -> %s\n", (long long)now, buf);
    strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", &utc);   /* ISO 8601 */
    printf("ISO 8601: %s\n", buf);

    struct tm t = {.tm_year = 2024 - 1900, .tm_mon = 1, .tm_mday = 30, .tm_hour = 12};
    time_t normalised = timegm(&t);                /* Feb 30 normalises to Mar 1 */
    gmtime_r(&normalised, &t);
    strftime(buf, sizeof buf, "%Y-%m-%d", &t);
    printf("2024-02-30 normalises to %s\n", buf);

    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    volatile double x = 0;
    for (int i = 0; i < 10000000; i++)
        x += i;
    clock_gettime(CLOCK_MONOTONIC, &b);
    printf("loop took %.1f ms (monotonic clock)\n", elapsed(a, b) * 1000);
    printf("CPU time used: %.1f ms (clock())\n", (double)clock() / CLOCKS_PER_SEC * 1000);
    return 0;
}
