// file: formats.c
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

int main(void) {
    int n = 42;
    double pi = 3.14159265;
    printf("[%5d] [%-5d] [%05d] [%+d] [% d]\n", n, n, n, n, n);   /* width, left, zero, sign, space */
    printf("[%x] [%X] [%#x] [%o] [%#o]\n", 255, 255, 255, 8, 8);
    printf("[%.2f] [%8.3f] [%-8.1f] [%e] [%g] [%g]\n", pi, pi, pi, pi, pi, 1e-10);
    printf("[%s] [%.3s] [%10s] [%-10s]\n", "hello", "hello", "hi", "hi");
    printf("[%*d] [%.*f]\n", 6, n, 1, pi);                         /* width/precision from args */
    printf("[%c] [%%] [%p]\n", 'A', (void *)0);

    long big = 1234567890123L;
    size_t sz = sizeof big;
    int64_t i64 = -5;
    uint8_t byte = 200;
    printf("long %ld, size_t %zu, int64 %" PRId64 ", uint8 %" PRIu8 "\n", big, sz, i64, byte);

    int written = printf("abc\n");
    printf("printf returned %d\n", written);

    char buf[8];
    int needed = snprintf(buf, sizeof buf, "%d-%d-%d", 2025, 12, 31);
    printf("buf='%s', needed=%d, truncated=%s\n", buf, needed, needed >= (int)sizeof buf ? "yes" : "no");
    return 0;
}
