// file: utf8.c
#include <locale.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

/* Decode one UTF-8 sequence. Returns its length (1-4) and stores the code point,
   or returns 0 for an invalid sequence (overlong forms, surrogates, bad continuations). */
static size_t utf8_decode(const unsigned char *s, uint32_t *cp) {
    if (s[0] < 0x80) { *cp = s[0]; return 1; }
    size_t n = (s[0] & 0xE0) == 0xC0 ? 2 : (s[0] & 0xF0) == 0xE0 ? 3 : (s[0] & 0xF8) == 0xF0 ? 4 : 0;
    if (!n) return 0;
    uint32_t c = s[0] & (0x7F >> n);
    for (size_t i = 1; i < n; i++) {
        if ((s[i] & 0xC0) != 0x80) return 0;                     /* also stops at the '\0' terminator */
        c = c << 6 | (s[i] & 0x3F);
    }
    static const uint32_t min[] = {0, 0, 0x80, 0x800, 0x10000};
    if (c < min[n] || c > 0x10FFFF || (c >= 0xD800 && c <= 0xDFFF)) return 0;
    *cp = c;
    return n;
}

int main(void) {
    const char *text = "naïve café — 日本 🎉";
    printf("text: %s\n", text);
    printf("strlen (bytes): %zu\n", strlen(text));

    size_t chars = 0;
    for (const unsigned char *p = (const unsigned char *)text; *p; ) {
        uint32_t cp;
        size_t n = utf8_decode(p, &cp);
        if (!n) { printf("invalid UTF-8 at byte %td\n", p - (const unsigned char *)text); return 1; }
        if (cp > 0x7F) printf("  U+%04X uses %zu bytes\n", (unsigned)cp, n);
        chars++;
        p += n;
    }
    printf("code points: %zu\n", chars);

    printf("first 3 bytes as a C string: \"%.3s\" (cuts 'ï' in half)\n", text);

    setlocale(LC_ALL, "C.UTF-8");                   /* the locale tells mbstowcs which encoding to decode */
    wchar_t wide[64];
    size_t w = mbstowcs(wide, text, 64);
    printf("mbstowcs: %zu wide characters, sizeof(wchar_t) = %zu\n", w, sizeof(wchar_t));

    const unsigned char bad[] = {0xC0, 0xAF, 0};    /* an "overlong" encoding of '/' */
    uint32_t cp;
    printf("C0 AF decodes? %s\n", utf8_decode(bad, &cp) ? "yes" : "no (overlong form rejected)");
    return 0;
}
