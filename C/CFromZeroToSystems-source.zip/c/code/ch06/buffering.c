// file: buffering.c
#include <stdio.h>
#include <unistd.h>

int main(void) {
    printf("1. to stdout ");          /* no newline: stays in the buffer */
    fprintf(stderr, "2. to stderr\n");
    printf("3. stdout again\n");
    fflush(stdout);                    /* force everything out now */

    printf("4. before fork-like surprise\n");
    write(STDOUT_FILENO, "5. raw write(2)\n", 16);   /* bypasses the stdio buffer */
    return 0;                          /* exit flushes remaining buffers */
}
