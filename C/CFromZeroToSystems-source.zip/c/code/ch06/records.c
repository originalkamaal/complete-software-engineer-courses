// file: records.c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_RECORD (1u << 20)

static uint32_t fnv1a(const unsigned char *p, size_t n) {     /* a simple 32-bit hash used as a checksum */
    uint32_t h = 2166136261u;
    while (n--) { h ^= *p++; h *= 16777619u; }
    return h;
}

static void put32(unsigned char *b, uint32_t v) { for (int i = 0; i < 4; i++) b[i] = (unsigned char)(v >> (8 * i)); }
static uint32_t get32(const unsigned char *b) { return b[0] | (uint32_t)b[1] << 8 | (uint32_t)b[2] << 16 | (uint32_t)b[3] << 24; }

static int write_record(FILE *f, const void *data, uint32_t len) {
    unsigned char hdr[8];
    put32(hdr, len);
    put32(hdr + 4, fnv1a(data, len));
    return fwrite(hdr, 1, 8, f) == 8 && fwrite(data, 1, len, f) == len ? 0 : -1;
}

/* returns 1 = record read, 0 = clean end of file, -1 = damaged or truncated */
static int read_record(FILE *f, unsigned char **out, uint32_t *len) {
    unsigned char hdr[8];
    size_t got = fread(hdr, 1, 8, f);
    if (got == 0) return 0;
    if (got != 8) return -1;
    *len = get32(hdr);
    if (*len > MAX_RECORD) return -1;                 /* never trust a length read from a file */
    *out = malloc(*len ? *len : 1);
    if (!*out || fread(*out, 1, *len, f) != *len) { free(*out); return -1; }
    if (fnv1a(*out, *len) != get32(hdr + 4)) { free(*out); return -1; }
    return 1;
}

static void dump(const char *path) {
    FILE *f = fopen(path, "rb");
    unsigned char *p;
    uint32_t n;
    int r;
    while ((r = read_record(f, &p, &n)) == 1) { printf("  record (%u bytes): %.*s\n", n, (int)n, p); free(p); }
    printf("  %s\n", r == 0 ? "clean end of file" : "stopped: damaged or truncated record");
    fclose(f);
}

int main(void) {
    const char *msgs[] = {"first record", "second, a little longer", "third"};
    FILE *f = fopen("log.bin", "wb");
    for (int i = 0; i < 3; i++) write_record(f, msgs[i], (uint32_t)strlen(msgs[i]));
    fclose(f);
    printf("intact file:\n");
    dump("log.bin");

    f = fopen("log.bin", "r+b");                      /* flip one byte inside the second payload */
    fseek(f, 8 + 12 + 8 + 3, SEEK_SET);
    fputc('X', f);
    fclose(f);
    printf("after corrupting one byte:\n");
    dump("log.bin");
    return 0;
}
