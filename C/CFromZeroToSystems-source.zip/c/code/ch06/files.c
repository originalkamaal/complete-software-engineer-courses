// file: files.c
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* write_lines writes n lines to path atomically: readers see either the old
   file or the complete new one, never a partial write. Returns 0 or -1. */
static int write_lines(const char *path, const char *const *lines, size_t n) {
    char tmp[256];
    if (snprintf(tmp, sizeof tmp, "%s.tmp", path) >= (int)sizeof tmp)
        return -1;
    FILE *f = fopen(tmp, "w");
    if (f == NULL)
        return -1;
    for (size_t i = 0; i < n; i++) {
        if (fprintf(f, "%s\n", lines[i]) < 0) {
            fclose(f);
            remove(tmp);
            return -1;
        }
    }
    if (fclose(f) != 0) {                  /* buffered data is written here: check it */
        remove(tmp);
        return -1;
    }
    return rename(tmp, path);              /* atomic replacement on POSIX file systems */
}

/* count_lines counts '\n' characters; returns -1 on a read error. */
static long count_lines(const char *path) {
    FILE *f = fopen(path, "r");
    if (f == NULL)
        return -1;
    long lines = 0;
    int c;
    while ((c = getc(f)) != EOF)
        if (c == '\n')
            lines++;
    long result = ferror(f) ? -1 : lines;  /* EOF can mean end or error: ask */
    fclose(f);
    return result;
}

int main(void) {
    const char *lines[] = {"alpha", "beta", "gamma"};
    if (write_lines("demo.txt", lines, 3) != 0) {
        perror("write_lines");
        return 1;
    }
    printf("lines: %ld\n", count_lines("demo.txt"));

    FILE *f = fopen("demo.txt", "a");      /* append */
    if (f == NULL)
        return 1;
    fputs("delta\n", f);
    fclose(f);

    f = fopen("demo.txt", "r");
    if (f == NULL)
        return 1;
    char line[64];
    while (fgets(line, sizeof line, f) != NULL) {
        line[strcspn(line, "\n")] = '\0';  /* strip the newline */
        printf("[%s]", line);
    }
    printf("\nfeof=%d ferror=%d\n", feof(f), ferror(f));

    fseek(f, 0, SEEK_END);
    printf("size via ftell: %ld bytes\n", ftell(f));
    fclose(f);

    if (fopen("/root/forbidden/x", "w") == NULL)
        printf("fopen error: %s\n", strerror(errno));
    return 0;
}
