// file: stability.c
#include <stdio.h>
#include <stdlib.h>

struct emp { int dept; int seq; };          /* seq: position in the input */

static int by_dept(const void *a, const void *b) {
    const struct emp *x = a, *y = b;
    return (x->dept > y->dept) - (x->dept < y->dept);
}

static int by_dept_then_seq(const void *a, const void *b) {   /* stable by construction: tie-break on input order */
    const struct emp *x = a, *y = b;
    int c = by_dept(a, b);
    return c ? c : (x->seq > y->seq) - (x->seq < y->seq);
}

/* how many neighbours with the same dept are out of input order? 0 means "stable here" */
static int disorder(const struct emp *e, int n) {
    int bad = 0;
    for (int i = 1; i < n; i++)
        if (e[i].dept == e[i - 1].dept && e[i].seq < e[i - 1].seq) bad++;
    return bad;
}

int main(void) {
    for (int n = 12; n <= 1200; n *= 10) {
        struct emp *e = malloc(n * sizeof *e), *f = malloc(n * sizeof *f);
        srand(7);
        for (int i = 0; i < n; i++) e[i] = f[i] = (struct emp){ rand() % 3, i };
        qsort(e, n, sizeof e[0], by_dept);
        qsort(f, n, sizeof f[0], by_dept_then_seq);
        printf("n = %4d: plain comparator %3d neighbours out of input order; with tie-break %d\n",
               n, disorder(e, n), disorder(f, n));
        free(e);
        free(f);
    }
    return 0;
}
