// file: tools/mywc.c
/* mywc: count lines, words, and bytes, like wc(1). */
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    unsigned long long lines, words, bytes;
} Counts;

static int count_stream(FILE *f, Counts *c) {
    unsigned char buf[65536];
    bool in_word = false;
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
        c->bytes += n;
        for (size_t i = 0; i < n; i++) {
            if (buf[i] == '\n')
                c->lines++;
            if (isspace(buf[i])) {                  /* buf is unsigned char: DT-28 safe */
                in_word = false;
            } else if (!in_word) {
                in_word = true;
                c->words++;
            }
        }
    }
    return ferror(f) ? -1 : 0;
}

static int digits(unsigned long long v) {
    int d = 1;
    while (v >= 10) {
        v /= 10;
        d++;
    }
    return d;
}

static void print_counts(const Counts *c, bool l, bool w, bool b, int width, const char *name) {
    const char *sep = "";
    if (l) { printf("%*llu", width, c->lines); sep = " "; }
    if (w) { printf("%s%*llu", sep, width, c->words); sep = " "; }
    if (b) { printf("%s%*llu", sep, width, c->bytes); }
    if (name != NULL)
        printf(" %s", name);
    printf("\n");
}

int main(int argc, char *argv[]) {
    bool l = false, w = false, b = false;
    int i = 1;
    for (; i < argc && argv[i][0] == '-' && argv[i][1] != '\0'; i++) {
        for (const char *o = argv[i] + 1; *o; o++) {
            switch (*o) {
            case 'l': l = true; break;
            case 'w': w = true; break;
            case 'c': b = true; break;
            default:
                fprintf(stderr, "mywc: invalid option -- '%c'\n", *o);
                return 2;
            }
        }
    }
    if (!l && !w && !b)
        l = w = b = true;

    int nfiles = argc - i, status = 0;
    if (nfiles == 0) {
        Counts c = {0};
        if (count_stream(stdin, &c) != 0) {
            perror("mywc: stdin");
            return 1;
        }
        unsigned long long m = c.lines > c.words ? c.lines : c.words;
        m = c.bytes > m ? c.bytes : m;
        int width = (l + w + b == 1) ? 1 : digits(m);
        print_counts(&c, l, w, b, width, NULL);
        return 0;
    }

    Counts all[nfiles > 0 ? nfiles : 1], total = {0};
    bool ok[nfiles > 0 ? nfiles : 1];
    for (int k = 0; k < nfiles; k++) {
        const char *name = argv[i + k];
        all[k] = (Counts){0};
        FILE *f = strcmp(name, "-") == 0 ? stdin : fopen(name, "rb");
        ok[k] = f != NULL && count_stream(f, &all[k]) == 0;
        if (!ok[k]) {
            fprintf(stderr, "mywc: %s: %s\n", name, strerror(errno));
            status = 1;
        }
        if (f != NULL && f != stdin)
            fclose(f);
        total.lines += all[k].lines;
        total.words += all[k].words;
        total.bytes += all[k].bytes;
    }
    unsigned long long biggest = (l ? total.lines : 0);
    if (w && total.words > biggest) biggest = total.words;
    if (b && total.bytes > biggest) biggest = total.bytes;
    int width = (nfiles == 1 && l + w + b == 1) ? 1 : digits(biggest);
    for (int k = 0; k < nfiles; k++)
        if (ok[k])
            print_counts(&all[k], l, w, b, width, argv[i + k]);
    if (nfiles > 1)
        print_counts(&total, l, w, b, width, "total");
    return status;
}
