// file: tools/mygrep.c
/* mygrep: print lines containing a fixed string, like grep -F. */
#define _POSIX_C_SOURCE 200809L          /* getline */
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    bool ignore_case, invert, number, count;
} Options;

/* contains reports whether line contains pat, optionally ignoring ASCII case. */
static bool contains(const char *line, const char *pat, bool ignore_case) {
    if (!ignore_case)
        return strstr(line, pat) != NULL;
    size_t m = strlen(pat);
    for (const char *s = line; *s != '\0'; s++) {
        size_t k = 0;
        while (k < m && s[k] != '\0' &&
               tolower((unsigned char)s[k]) == tolower((unsigned char)pat[k]))
            k++;
        if (k == m)
            return true;
    }
    return m == 0;
}

/* grep_stream prints matching lines; returns the number of matches or -1. */
static long grep_stream(FILE *f, const char *name, const char *pat, const Options *o) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t len;
    long lineno = 0, matches = 0;
    while ((len = getline(&line, &cap, f)) != -1) {   /* any line length */
        lineno++;
        if (len > 0 && line[len - 1] == '\n')
            line[len - 1] = '\0';
        if (contains(line, pat, o->ignore_case) == o->invert)
            continue;
        matches++;
        if (o->count)
            continue;
        if (name != NULL)
            printf("%s:", name);
        if (o->number)
            printf("%ld:", lineno);
        printf("%s\n", line);
    }
    bool err = ferror(f);
    free(line);
    return err ? -1 : matches;
}

int main(int argc, char *argv[]) {
    Options o = {0};
    int i = 1;
    for (; i < argc && argv[i][0] == '-' && argv[i][1] != '\0'; i++) {
        for (const char *p = argv[i] + 1; *p; p++) {
            switch (*p) {
            case 'i': o.ignore_case = true; break;
            case 'v': o.invert = true; break;
            case 'n': o.number = true; break;
            case 'c': o.count = true; break;
            default:
                fprintf(stderr, "usage: mygrep [-ivnc] PATTERN [FILE...]\n");
                return 2;
            }
        }
    }
    if (i >= argc) {
        fprintf(stderr, "usage: mygrep [-ivnc] PATTERN [FILE...]\n");
        return 2;
    }
    const char *pat = argv[i++];
    int nfiles = argc - i;
    bool any = false, error = false;
    if (nfiles == 0) {
        long m = grep_stream(stdin, NULL, pat, &o);
        if (m < 0)
            error = true;
        if (o.count && m >= 0)
            printf("%ld\n", m);
        any = m > 0;
    }
    for (int k = 0; k < nfiles; k++) {
        const char *name = argv[i + k];
        FILE *f = fopen(name, "r");
        if (f == NULL) {
            fprintf(stderr, "mygrep: ");
            perror(name);
            error = true;
            continue;
        }
        long m = grep_stream(f, nfiles > 1 ? name : NULL, pat, &o);
        fclose(f);
        if (m < 0) {
            error = true;
            continue;
        }
        if (o.count) {
            if (nfiles > 1)
                printf("%s:", name);
            printf("%ld\n", m);
        }
        if (m > 0)
            any = true;
    }
    if (error)
        return 2;
    return any ? 0 : 1;
}
