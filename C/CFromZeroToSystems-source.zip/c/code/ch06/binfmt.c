// file: binfmt.c
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    uint32_t id;
    int16_t temperature;     /* tenths of a degree */
    uint8_t flags;
} Reading;

/* Encoding: id as 4 bytes little-endian, temperature as 2 bytes little-endian
   two's complement, flags as 1 byte: 7 bytes total, no padding, any machine. */
enum { READING_SIZE = 7 };

static void put_u32le(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8);
    p[2] = (unsigned char)(v >> 16); p[3] = (unsigned char)(v >> 24);
}
static uint32_t get_u32le(const unsigned char *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}
static void put_u16le(unsigned char *p, uint16_t v) {
    p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8);
}
static uint16_t get_u16le(const unsigned char *p) {
    return (uint16_t)(p[0] | p[1] << 8);
}

static void encode(unsigned char out[READING_SIZE], const Reading *r) {
    put_u32le(out, r->id);
    put_u16le(out + 4, (uint16_t)r->temperature);   /* two's complement bits */
    out[6] = r->flags;
}

static Reading decode(const unsigned char in[READING_SIZE]) {
    uint16_t t = get_u16le(in + 4);
    return (Reading){
        .id = get_u32le(in),
        .temperature = (int16_t)t,                  /* well-defined in C23; two's complement on GCC */
        .flags = in[6],
    };
}

int main(void) {
    Reading r = {.id = 0x01020304, .temperature = -125, .flags = 0x81};
    unsigned char buf[READING_SIZE];
    encode(buf, &r);
    printf("sizeof(Reading) = %zu, encoded = %d bytes:", sizeof(Reading), READING_SIZE);
    for (int i = 0; i < READING_SIZE; i++)
        printf(" %02x", buf[i]);
    printf("\n");

    FILE *f = fopen("readings.bin", "wb");
    if (f == NULL || fwrite(buf, 1, sizeof buf, f) != sizeof buf || fclose(f) != 0)
        return 1;

    unsigned char in[READING_SIZE];
    f = fopen("readings.bin", "rb");
    if (f == NULL || fread(in, 1, sizeof in, f) != sizeof in)
        return 1;
    fclose(f);
    Reading back = decode(in);
    printf("decoded: id=0x%08x temperature=%d flags=0x%02x\n",
           (unsigned)back.id, back.temperature, back.flags);
    return 0;
}
