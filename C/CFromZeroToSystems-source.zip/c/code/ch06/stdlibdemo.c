// file: stdlibdemo.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int cmp_int(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

static void goodbye(void) { printf("atexit handler ran\n"); }

int main(void) {
    int v[] = {42, 7, 19, 3, 88, 21};
    size_t n = sizeof v / sizeof v[0];
    qsort(v, n, sizeof v[0], cmp_int);
    int key = 19;
    int *found = bsearch(&key, v, n, sizeof v[0], cmp_int);
    printf("sorted:");
    for (size_t i = 0; i < n; i++)
        printf(" %d", v[i]);
    printf("; 19 found at index %td\n", found ? found - v : -1);

    const char *home = getenv("HOME");
    printf("HOME is %s\n", home ? "set" : "not set");

    srand(1);
    printf("rand(): %d %d (RAND_MAX = %d)\n", rand(), rand(), RAND_MAX);

    div_t d = div(17, 5);
    printf("div(17, 5) = %d rem %d, abs(-3) = %d, llabs = %lld\n", d.quot, d.rem, abs(-3), llabs(-9LL));

    atexit(goodbye);
    printf("calling exit(3)\n");
    exit(3);
}
