// file: degenerate.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct node { int key; struct node *left, *right; };

static struct node *insert(struct node *root, int key) {          /* iterative: no recursion depth problem */
    struct node **link = &root;
    while (*link) link = key < (*link)->key ? &(*link)->left : &(*link)->right;
    *link = calloc(1, sizeof **link);
    (*link)->key = key;
    return root;
}

static int height(const struct node *n) {                         /* iterative, with an explicit stack */
    int best = 0, top = 0;
    struct item { const struct node *n; int depth; } *stack = malloc(200000 * sizeof *stack);
    if (n) stack[top++] = (struct item){ n, 1 };
    while (top) {
        struct item it = stack[--top];
        if (it.depth > best) best = it.depth;
        if (it.n->left) stack[top++] = (struct item){ it.n->left, it.depth + 1 };
        if (it.n->right) stack[top++] = (struct item){ it.n->right, it.depth + 1 };
    }
    free(stack);
    return best;
}

static void destroy(struct node *n) {                              /* walk down the right spine iteratively */
    while (n) {
        if (n->left) { struct node *l = n->left; n->left = l->right; l->right = n; n = l; continue; }
        struct node *r = n->right;
        free(n);
        n = r;
    }
}

int main(void) {
    enum { N = 20000 };
    int *keys = malloc(N * sizeof *keys);
    for (int pass = 0; pass < 2; pass++) {
        for (int i = 0; i < N; i++) keys[i] = i;
        if (pass == 0) { srand(3); for (int i = N - 1; i > 0; i--) { int j = rand() % (i + 1), t = keys[i]; keys[i] = keys[j]; keys[j] = t; } }
        struct timespec a, b;
        clock_gettime(CLOCK_MONOTONIC, &a);
        struct node *root = NULL;
        for (int i = 0; i < N; i++) root = insert(root, keys[i]);
        clock_gettime(CLOCK_MONOTONIC, &b);
        printf("%-12s insertion: height %5d, built in %7.1f ms\n", pass ? "sorted" : "random",
               height(root), (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6);
        destroy(root);
    }
    free(keys);
    return 0;
}
