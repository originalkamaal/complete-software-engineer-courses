// file: graph.c
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

/* Compressed sparse row: edges of vertex v are to[first[v] .. first[v+1]-1]. */
typedef struct {
    int n;
    int *first, *to, *w;
} Graph;

static Graph build(int n, int m, const int (*edges)[3]) {
    Graph g = {n, calloc((size_t)n + 1, sizeof(int)), malloc((size_t)m * sizeof(int)),
               malloc((size_t)m * sizeof(int))};
    for (int e = 0; e < m; e++)
        g.first[edges[e][0] + 1]++;                   /* count out-degrees */
    for (int v = 0; v < n; v++)
        g.first[v + 1] += g.first[v];                 /* prefix sums: start offsets */
    int *pos = malloc((size_t)n * sizeof(int));
    for (int v = 0; v < n; v++)
        pos[v] = g.first[v];
    for (int e = 0; e < m; e++) {
        int u = edges[e][0];
        g.to[pos[u]] = edges[e][1];
        g.w[pos[u]] = edges[e][2];
        pos[u]++;
    }
    free(pos);
    return g;
}

static void bfs(const Graph *g, int src, int *hops) {
    int *queue = malloc((size_t)g->n * sizeof(int)), head = 0, tail = 0;
    for (int v = 0; v < g->n; v++)
        hops[v] = -1;
    hops[src] = 0;
    queue[tail++] = src;
    while (head < tail) {
        int u = queue[head++];
        for (int e = g->first[u]; e < g->first[u + 1]; e++)
            if (hops[g->to[e]] < 0) {
                hops[g->to[e]] = hops[u] + 1;
                queue[tail++] = g->to[e];
            }
    }
    free(queue);
}

/* Dijkstra with a binary heap of (dist, vertex); stale entries are skipped. */
typedef struct { long d; int v; } Item;
static void push(Item *h, int *len, Item it) {
    int i = (*len)++;
    h[i] = it;
    while (i > 0 && h[(i - 1) / 2].d > h[i].d) {
        Item t = h[i]; h[i] = h[(i - 1) / 2]; h[(i - 1) / 2] = t;
        i = (i - 1) / 2;
    }
}
static Item pop(Item *h, int *len) {
    Item top = h[0];
    h[0] = h[--(*len)];
    for (int i = 0;;) {
        int l = 2 * i + 1, r = l + 1, m = i;
        if (l < *len && h[l].d < h[m].d) m = l;
        if (r < *len && h[r].d < h[m].d) m = r;
        if (m == i) break;
        Item t = h[i]; h[i] = h[m]; h[m] = t;
        i = m;
    }
    return top;
}

static void dijkstra(const Graph *g, int src, long *dist, int *prev) {
    int m = g->first[g->n];
    Item *heap = malloc(((size_t)m + 1) * sizeof *heap);
    int len = 0;
    for (int v = 0; v < g->n; v++) {
        dist[v] = LONG_MAX;
        prev[v] = -1;
    }
    dist[src] = 0;
    push(heap, &len, (Item){0, src});
    while (len > 0) {
        Item it = pop(heap, &len);
        if (it.d > dist[it.v])
            continue;                                  /* stale entry */
        for (int e = g->first[it.v]; e < g->first[it.v + 1]; e++) {
            long nd = it.d + g->w[e];
            if (nd < dist[g->to[e]]) {
                dist[g->to[e]] = nd;
                prev[g->to[e]] = it.v;
                push(heap, &len, (Item){nd, g->to[e]});
            }
        }
    }
    free(heap);
}

int main(void) {
    /* A small road network: from, to, minutes */
    static const int edges[][3] = {
        {0, 1, 7}, {0, 2, 9}, {0, 5, 14}, {1, 2, 10}, {1, 3, 15}, {2, 3, 11},
        {2, 5, 2}, {3, 4, 6}, {5, 4, 9}, {4, 6, 3},
    };
    const char *name[] = {"A", "B", "C", "D", "E", "F", "G"};
    int m = sizeof edges / sizeof edges[0];
    Graph g = build(7, m, edges);

    int hops[7];
    bfs(&g, 0, hops);
    long dist[7];
    int prev[7];
    dijkstra(&g, 0, dist, prev);
    for (int v = 0; v < 7; v++) {
        printf("%s: hops %d, minutes %2ld, path ", name[v], hops[v], dist[v]);
        int path[7], k = 0;
        for (int x = v; x != -1; x = prev[x])
            path[k++] = x;
        while (k > 0) {
            k--;                                       /* not inside the printf: Unit 1.6 */
            printf("%s%s", name[path[k]], k ? "->" : "\n");
        }
    }
    free(g.first); free(g.to); free(g.w);
    return 0;
}
