// file: slist.c
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int value;
    struct Node *next;
} Node;

/* push_front inserts at the head; returns 0 or -1. */
static int push_front(Node **head, int value) {
    Node *n = malloc(sizeof *n);
    if (n == NULL)
        return -1;
    n->value = value;
    n->next = *head;
    *head = n;
    return 0;
}

/* remove_value removes the first node with value, with no special case for the head:
   'link' points at whichever pointer currently refers to the node being examined. */
static int remove_value(Node **head, int value) {
    for (Node **link = head; *link != NULL; link = &(*link)->next) {
        if ((*link)->value == value) {
            Node *dead = *link;
            *link = dead->next;
            free(dead);
            return 0;
        }
    }
    return -1;
}

static void reverse(Node **head) {
    Node *prev = NULL, *cur = *head;
    while (cur != NULL) {
        Node *next = cur->next;
        cur->next = prev;
        prev = cur;
        cur = next;
    }
    *head = prev;
}

static void print_list(const Node *n) {
    for (; n != NULL; n = n->next)
        printf("%d -> ", n->value);
    printf("NULL\n");
}

static void free_list(Node *n) {
    while (n != NULL) {
        Node *next = n->next;          /* read next before freeing */
        free(n);
        n = next;
    }
}

int main(void) {
    Node *head = NULL;
    for (int i = 1; i <= 5; i++)
        if (push_front(&head, i) != 0)
            return 1;
    print_list(head);
    remove_value(&head, 5);            /* the head */
    remove_value(&head, 3);            /* the middle */
    remove_value(&head, 1);            /* the tail */
    print_list(head);
    reverse(&head);
    print_list(head);
    free_list(head);
    return 0;
}
