// file: generic.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* (1) void * + size: one implementation for every type */
typedef struct {
    unsigned char *data;
    size_t len, cap, elem;
} AnyVec;

static int anyvec_push(AnyVec *v, const void *elem) {
    if (v->len == v->cap) {
        size_t cap = v->cap ? v->cap * 2 : 8;
        unsigned char *p = realloc(v->data, cap * v->elem);
        if (p == NULL)
            return -1;
        v->data = p;
        v->cap = cap;
    }
    memcpy(v->data + v->len * v->elem, elem, v->elem);
    v->len++;
    return 0;
}
static void *anyvec_at(const AnyVec *v, size_t i) { return v->data + i * v->elem; }

/* (2) macro code generation: a real type and real functions per element type */
#define VEC_DEFINE(Name, T)                                                   \
    typedef struct { T *data; size_t len, cap; } Name;                        \
    static inline int Name##_push(Name *v, T x) {                             \
        if (v->len == v->cap) {                                               \
            size_t cap = v->cap ? v->cap * 2 : 8;                             \
            T *p = realloc(v->data, cap * sizeof *p);                         \
            if (p == NULL) return -1;                                         \
            v->data = p; v->cap = cap;                                        \
        }                                                                     \
        v->data[v->len++] = x;                                                \
        return 0;                                                             \
    }                                                                         \
    static inline void Name##_free(Name *v) { free(v->data); *v = (Name){0}; }

VEC_DEFINE(IntVec, int)
VEC_DEFINE(DoubleVec, double)

typedef struct { double x, y; } Point;
VEC_DEFINE(PointVec, Point)

/* (3) _Generic: one name, dispatched on the argument type at compile time */
static void print_int(int x) { printf("int %d\n", x); }
static void print_double(double x) { printf("double %g\n", x); }
static void print_str(const char *s) { printf("string \"%s\"\n", s); }
#define print_any(x) _Generic((x), int: print_int, double: print_double, \
                              char *: print_str, const char *: print_str)(x)

int main(void) {
    AnyVec av = {.elem = sizeof(Point)};
    Point p = {1.5, 2.5};
    anyvec_push(&av, &p);
    Point *q = anyvec_at(&av, 0);              /* caller must know the real type */
    printf("AnyVec: (%g, %g)\n", q->x, q->y);
    free(av.data);

    IntVec iv = {0};
    PointVec pv = {0};
    for (int i = 0; i < 5; i++)
        IntVec_push(&iv, i * i);
    PointVec_push(&pv, (Point){3, 4});
    /* IntVec_push(&iv, "oops");  would not compile: wrong type */
    printf("IntVec: %d %d %d %d %d; PointVec: (%g, %g)\n",
           iv.data[0], iv.data[1], iv.data[2], iv.data[3], iv.data[4], pv.data[0].x, pv.data[0].y);
    IntVec_free(&iv);
    PointVec_free(&pv);

    print_any(42);
    print_any(2.5);
    print_any("hello");
    return 0;
}
