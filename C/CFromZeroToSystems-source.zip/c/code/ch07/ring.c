// file: ring.c
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define RING_CAP 8u                  /* must be a power of two */

typedef struct {
    int buf[RING_CAP];
    uint32_t head, tail;             /* free-running: never reset, wrap naturally (unsigned) */
} Ring;

static bool ring_push(Ring *r, int v) {
    if (r->tail - r->head == RING_CAP)
        return false;                /* full */
    r->buf[r->tail & (RING_CAP - 1)] = v;
    r->tail++;
    return true;
}

static bool ring_pop(Ring *r, int *out) {
    if (r->tail == r->head)
        return false;                /* empty */
    *out = r->buf[r->head & (RING_CAP - 1)];
    r->head++;
    return true;
}

int main(void) {
    Ring r = {.head = UINT32_MAX - 3, .tail = UINT32_MAX - 3};   /* start near wraparound on purpose */
    int pushed = 0, v;
    while (ring_push(&r, pushed))
        pushed++;
    printf("pushed %d before full\n", pushed);
    for (int i = 0; i < 3; i++) {
        ring_pop(&r, &v);
        printf("popped %d\n", v);
    }
    ring_push(&r, 100);
    ring_push(&r, 101);
    printf("size now %u (head=%u tail=%u)\n", r.tail - r.head, r.head, r.tail);
    while (ring_pop(&r, &v))
        printf("%d ", v);
    printf("\n");
    return 0;
}
