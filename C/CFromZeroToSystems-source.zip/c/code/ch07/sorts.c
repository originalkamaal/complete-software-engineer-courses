// file: sorts.c
#include "bench.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void insertion_sort(int *a, size_t n) {
    for (size_t i = 1; i < n; i++) {
        int x = a[i];
        size_t j = i;
        while (j > 0 && a[j - 1] > x) {
            a[j] = a[j - 1];
            j--;
        }
        a[j] = x;
    }
}

static void merge_sort_rec(int *a, int *tmp, size_t n) {
    if (n <= 16) {                         /* small subarrays: insertion sort is faster */
        insertion_sort(a, n);
        return;
    }
    size_t mid = n / 2;
    merge_sort_rec(a, tmp, mid);
    merge_sort_rec(a + mid, tmp, n - mid);
    size_t i = 0, j = mid, k = 0;
    while (i < mid && j < n)
        tmp[k++] = a[j] < a[i] ? a[j++] : a[i++];   /* '<' keeps equal elements in order: stable */
    while (i < mid)
        tmp[k++] = a[i++];
    while (j < n)
        tmp[k++] = a[j++];
    memcpy(a, tmp, n * sizeof *a);
}

static int merge_sort(int *a, size_t n) {
    int *tmp = malloc(n * sizeof *tmp);
    if (tmp == NULL)
        return -1;
    merge_sort_rec(a, tmp, n);
    free(tmp);
    return 0;
}

static void quick_sort(int *a, size_t n) {
    while (n > 16) {
        /* median of three as pivot: avoids O(n^2) on sorted input */
        size_t m = n / 2;
        int x = a[0], y = a[m], z = a[n - 1];
        int pivot = (x < y) ? (y < z ? y : (x < z ? z : x)) : (x < z ? x : (y < z ? z : y));
        size_t i = 0, j = n - 1;
        for (;;) {                           /* Hoare partition */
            while (a[i] < pivot) i++;
            while (a[j] > pivot) j--;
            if (i >= j)
                break;
            int t = a[i]; a[i] = a[j]; a[j] = t;
            i++; j--;
        }
        /* recurse into the smaller part, loop on the larger: O(log n) stack depth */
        if (j + 1 < n - j - 1) {
            quick_sort(a, j + 1);
            a += j + 1; n -= j + 1;
        } else {
            quick_sort(a + j + 1, n - j - 1);
            n = j + 1;
        }
    }
    insertion_sort(a, n);
}

static int cmp_int(const void *p, const void *q) {
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

static int is_sorted(const int *a, size_t n) {
    for (size_t i = 1; i < n; i++)
        if (a[i - 1] > a[i])
            return 0;
    return 1;
}

int main(void) {
    enum { N = 2000000 };
    int *orig = malloc(N * sizeof *orig), *a = malloc(N * sizeof *a);
    if (orig == NULL || a == NULL)
        return 1;
    srand(7);
    for (size_t i = 0; i < N; i++)
        orig[i] = rand();

    const char *names[] = {"merge sort", "quicksort", "qsort (libc)"};
    for (int s = 0; s < 3; s++) {
        memcpy(a, orig, N * sizeof *a);
        double t0 = now_sec();
        if (s == 0) merge_sort(a, N);
        else if (s == 1) quick_sort(a, N);
        else qsort(a, N, sizeof *a, cmp_int);
        double t1 = now_sec();
        printf("%-13s %7.1f ms  sorted=%d\n", names[s], (t1 - t0) * 1000, is_sorted(a, N));
    }
    /* insertion sort: only on a small prefix, it is O(n^2) */
    memcpy(a, orig, 20000 * sizeof *a);
    double t0 = now_sec();
    insertion_sort(a, 20000);
    printf("%-13s %7.1f ms  (only n = 20,000)\n", "insertion", (now_sec() - t0) * 1000);

    for (size_t i = 0; i < N; i++)
        a[i] = (int)i;                       /* already sorted: quicksort's classic worst case */
    t0 = now_sec();
    quick_sort(a, N);
    printf("quicksort on sorted input: %.1f ms (median-of-three keeps it O(n log n))\n", (now_sec() - t0) * 1000);
    free(orig);
    free(a);
    return 0;
}
