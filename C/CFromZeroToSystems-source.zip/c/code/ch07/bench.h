// file: bench.h
/* Include this header FIRST: the feature-test macro below only works if it is
   defined before any system header is included (see the note below). */
#ifndef BENCH_H
#define BENCH_H
#define _POSIX_C_SOURCE 200809L
#include <time.h>

/* now_sec returns a monotonic timestamp in seconds. */
static inline double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

#endif
