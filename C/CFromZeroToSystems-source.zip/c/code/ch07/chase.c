// file: chase.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct node { long value; struct node *next; };

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }

int main(void) {
    enum { N = 4000000 };
    long *arr = malloc(N * sizeof *arr);
    struct node *nodes = malloc(N * sizeof *nodes);         /* one block: node i is at nodes + i */
    size_t *order = malloc(N * sizeof *order);
    for (size_t i = 0; i < N; i++) { arr[i] = (long)i; nodes[i].value = (long)i; order[i] = i; }

    for (size_t i = 0; i + 1 < N; i++) nodes[i].next = &nodes[i + 1];   /* links in memory order */
    nodes[N - 1].next = NULL;

    double t = now(); long s = 0;
    for (size_t i = 0; i < N; i++) s += arr[i];
    double t_arr = now() - t;

    t = now(); long s2 = 0;
    for (struct node *p = nodes; p; p = p->next) s2 += p->value;
    double t_seq = now() - t;

    srand(1);                                                /* shuffle the visiting order */
    for (size_t i = N - 1; i > 0; i--) { size_t j = (size_t)rand() % (i + 1); size_t x = order[i]; order[i] = order[j]; order[j] = x; }
    for (size_t i = 0; i + 1 < N; i++) nodes[order[i]].next = &nodes[order[i + 1]];
    nodes[order[N - 1]].next = NULL;

    t = now(); long s3 = 0;
    for (struct node *p = &nodes[order[0]]; p; p = p->next) s3 += p->value;
    double t_rand = now() - t;

    printf("sums agree: %s\n", s == s2 && s2 == s3 ? "yes" : "no");
    printf("array                 %6.1f ms  (%.2f ns per element)\n", t_arr * 1e3, t_arr * 1e9 / N);
    printf("list, nodes in order  %6.1f ms  (%.2f ns per node)\n", t_seq * 1e3, t_seq * 1e9 / N);
    printf("list, nodes shuffled  %6.1f ms  (%.2f ns per node)\n", t_rand * 1e3, t_rand * 1e9 / N);
    free(arr); free(nodes); free(order);
    return 0;
}
