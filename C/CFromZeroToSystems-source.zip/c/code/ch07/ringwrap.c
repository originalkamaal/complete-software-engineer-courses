// file: ringwrap.c
#include <stdint.h>
#include <stdio.h>

static void run(uint32_t cap) {
    int buf[4] = {0};
    uint32_t head = UINT32_MAX - 2, tail = UINT32_MAX - 2;     /* close to wraparound */
    int next = 1;
    printf("capacity %u:", cap);
    buf[tail % cap] = next++; tail++;                          /* keep two elements in the ring */
    buf[tail % cap] = next++; tail++;
    for (int i = 0; i < 6; i++) {
        printf(" %d", buf[head % cap]); head++;                /* pop one ... */
        buf[tail % cap] = next++; tail++;                      /* ... push one */
    }
    printf("   (expected 1 2 3 4 5 6)\n");
}

int main(void) { run(3); run(4); return 0; }
