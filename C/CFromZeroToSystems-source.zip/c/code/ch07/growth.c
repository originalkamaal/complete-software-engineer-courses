// file: growth.c
#include "bench.h"
#include <stdio.h>
#include <stdlib.h>

static long linear_search(const int *a, long n, int key) {
    for (long i = 0; i < n; i++)
        if (a[i] == key)
            return i;
    return -1;
}

static long binary_search(const int *a, long n, int key) {
    long lo = 0, hi = n;                     /* search in [lo, hi) */
    while (lo < hi) {
        long mid = lo + (hi - lo) / 2;       /* not (lo + hi) / 2: avoids overflow */
        if (a[mid] < key)
            lo = mid + 1;
        else
            hi = mid;
    }
    return (lo < n && a[lo] == key) ? lo : -1;
}

int main(void) {
    printf("%10s %16s %16s\n", "n", "linear (us)", "binary (us)");
    for (long n = 1000; n <= 10000000; n *= 10) {
        int *a = malloc((size_t)n * sizeof *a);
        if (a == NULL)
            return 1;
        for (long i = 0; i < n; i++)
            a[i] = (int)(2 * i);             /* sorted, even numbers */
        const int lookups = 200;
        volatile long sink = 0;
        double t0 = now_sec();
        for (int k = 0; k < lookups; k++)
            sink += linear_search(a, n, (int)(2 * (long)((k + 0.5) / lookups * n)));
        double t1 = now_sec();
        for (int k = 0; k < lookups; k++)
            sink += binary_search(a, n, (int)(2 * (long)((k + 0.5) / lookups * n)));
        double t2 = now_sec();
        printf("%10ld %16.3f %16.3f\n", n, (t1 - t0) / lookups * 1e6, (t2 - t1) / lookups * 1e6);
        free(a);
    }
    return 0;
}
