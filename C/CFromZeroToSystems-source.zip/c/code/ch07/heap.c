// file: heap.c
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *a;
    size_t len, cap;
} Heap;

static void swap(int *x, int *y) { int t = *x; *x = *y; *y = t; }

static int heap_push(Heap *h, int v) {
    if (h->len == h->cap) {
        size_t cap = h->cap ? h->cap * 2 : 16;
        int *p = realloc(h->a, cap * sizeof *p);
        if (p == NULL)
            return -1;
        h->a = p;
        h->cap = cap;
    }
    size_t i = h->len++;
    h->a[i] = v;
    while (i > 0 && h->a[(i - 1) / 2] > h->a[i]) {       /* sift up */
        swap(&h->a[(i - 1) / 2], &h->a[i]);
        i = (i - 1) / 2;
    }
    return 0;
}

static int heap_pop(Heap *h, int *out) {
    if (h->len == 0)
        return -1;
    *out = h->a[0];
    h->a[0] = h->a[--h->len];
    size_t i = 0;
    for (;;) {                                            /* sift down */
        size_t l = 2 * i + 1, r = l + 1, m = i;
        if (l < h->len && h->a[l] < h->a[m]) m = l;
        if (r < h->len && h->a[r] < h->a[m]) m = r;
        if (m == i)
            break;
        swap(&h->a[i], &h->a[m]);
        i = m;
    }
    return 0;
}

int main(void) {
    Heap h = {0};
    int input[] = {42, 7, 19, 3, 88, 21, 3, 50};
    for (size_t i = 0; i < sizeof input / sizeof input[0]; i++)
        heap_push(&h, input[i]);
    printf("array layout:");
    for (size_t i = 0; i < h.len; i++)
        printf(" %d", h.a[i]);
    printf("\npopped in order:");
    int v;
    while (heap_pop(&h, &v) == 0)
        printf(" %d", v);
    printf("\n");
    free(h.a);
    return 0;
}
