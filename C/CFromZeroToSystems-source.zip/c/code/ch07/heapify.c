// file: heapify.c
#include <stdio.h>
#include <stdlib.h>

static long comparisons;

static int less(int a, int b) { comparisons++; return a < b; }

static void sift_down(int *h, size_t n, size_t i) {                 /* min-heap */
    for (;;) {
        size_t l = 2 * i + 1, r = l + 1, m = i;
        if (l < n && less(h[l], h[m])) m = l;
        if (r < n && less(h[r], h[m])) m = r;
        if (m == i) return;
        int t = h[i]; h[i] = h[m]; h[m] = t;
        i = m;
    }
}

static void sift_up(int *h, size_t i) {
    while (i > 0 && less(h[i], h[(i - 1) / 2])) {
        int t = h[i]; h[i] = h[(i - 1) / 2]; h[(i - 1) / 2] = t;
        i = (i - 1) / 2;
    }
}

int main(void) {
    for (size_t n = 1000; n <= 1000000; n *= 10) {
        int *a = malloc(n * sizeof *a), *b = malloc(n * sizeof *b);
        srand(5);
        for (size_t i = 0; i < n; i++) a[i] = b[i] = rand();

        comparisons = 0;
        for (size_t i = 1; i < n; i++) sift_up(a, i);               /* n inserts */
        long by_insert = comparisons;

        comparisons = 0;
        for (size_t i = n / 2; i-- > 0; ) sift_down(b, n, i);       /* Floyd: bottom-up */
        long by_floyd = comparisons;

        printf("n = %7zu: inserts %9ld comparisons (%.2f per element), heapify %8ld (%.2f per element)\n",
               n, by_insert, (double)by_insert / n, by_floyd, (double)by_floyd / n);
        free(a); free(b);
    }
    return 0;
}
