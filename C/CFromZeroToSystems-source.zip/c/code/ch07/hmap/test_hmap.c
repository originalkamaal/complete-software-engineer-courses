// file: hmap/test_hmap.c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hmap.h"

/* Reference model: a plain array indexed by key number. Slow, obviously correct. */
enum { KEYS = 2000 };
static int ref_present[KEYS];
static intptr_t ref_value[KEYS];

static void key_name(char *buf, size_t n, int k) { snprintf(buf, n, "key-%d", k); }

int main(void) {
    HMap *m = hmap_new();
    if (m == NULL)
        return 1;
    srand(12345);
    char key[32];
    long ops = 0;
    for (int round = 0; round < 200000; round++) {
        int k = rand() % KEYS, op = rand() % 3;
        key_name(key, sizeof key, k);
        if (op == 0) {                                   /* put */
            intptr_t v = rand();
            if (hmap_put(m, key, (void *)v) != 0) return 1;
            ref_present[k] = 1;
            ref_value[k] = v;
        } else if (op == 1) {                            /* del */
            int rc = hmap_del(m, key);
            if ((rc == 0) != ref_present[k]) { printf("del mismatch at %d\n", round); return 1; }
            ref_present[k] = 0;
        } else {                                         /* get */
            int found;
            void *v = hmap_get(m, key, &found);
            if (found != ref_present[k] || (found && (intptr_t)v != ref_value[k])) {
                printf("get mismatch at %d\n", round);
                return 1;
            }
        }
        ops++;
    }
    size_t expected = 0;
    for (int k = 0; k < KEYS; k++)
        expected += (size_t)ref_present[k];
    size_t iter = 0, seen = 0;
    const char *kk;
    void *vv;
    while (hmap_next(m, &iter, &kk, &vv)) {
        int k = atoi(kk + 4);
        if (!ref_present[k] || (intptr_t)vv != ref_value[k]) { printf("iteration mismatch\n"); return 1; }
        seen++;
    }
    int found;
    hmap_put(m, "null-value", NULL);
    hmap_get(m, "null-value", &found);
    printf("%ld random operations matched the reference; len=%zu expected=%zu iterated=%zu; NULL value found=%d\n",
           ops, hmap_len(m) - 1, expected, seen, found);
    hmap_free(m);
    return 0;
}
