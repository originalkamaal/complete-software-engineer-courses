// file: hmap/bench_hmap.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../bench.h"
#include "hmap.h"

static int cmp_str(const void *a, const void *b) {
    return strcmp(*(char *const *)a, *(char *const *)b);
}

int main(void) {
    enum { LOOKUPS = 100000 };
    printf("%9s %14s %14s %14s\n", "keys", "linear ns/op", "bsearch ns/op", "hmap ns/op");
    for (int n = 100; n <= 1000000; n *= 10) {
        char **keys = malloc((size_t)n * sizeof *keys), **sorted = malloc((size_t)n * sizeof *sorted);
        HMap *m = hmap_new();
        for (int i = 0; i < n; i++) {
            char buf[32];
            snprintf(buf, sizeof buf, "user:%d", (int)((i * 2654435761u) % 100000007u));
            keys[i] = strdup(buf);
            sorted[i] = keys[i];
            hmap_put(m, keys[i], keys[i]);
        }
        qsort(sorted, (size_t)n, sizeof *sorted, cmp_str);
        volatile size_t sink = 0;

        int linear_lookups = n <= 10000 ? LOOKUPS : 1000;     /* linear search is too slow at 1M */
        double t0 = now_sec();
        for (int q = 0; q < linear_lookups; q++) {
            const char *k = keys[(q * 7919) % n];
            for (int i = 0; i < n; i++)
                if (strcmp(keys[i], k) == 0) { sink += (size_t)i; break; }
        }
        double t1 = now_sec();
        for (int q = 0; q < LOOKUPS; q++) {
            const char *k = keys[(q * 7919) % n];
            sink += (size_t)bsearch(&k, sorted, (size_t)n, sizeof *sorted, cmp_str);
        }
        double t2 = now_sec();
        for (int q = 0; q < LOOKUPS; q++)
            sink += (size_t)hmap_get(m, keys[(q * 7919) % n], NULL);
        double t3 = now_sec();
        printf("%9d %14.1f %14.1f %14.1f\n", n, (t1 - t0) / linear_lookups * 1e9,
               (t2 - t1) / LOOKUPS * 1e9, (t3 - t2) / LOOKUPS * 1e9);
        for (int i = 0; i < n; i++)
            free(keys[i]);
        free(keys);
        free(sorted);
        hmap_free(m);
    }
    return 0;
}
