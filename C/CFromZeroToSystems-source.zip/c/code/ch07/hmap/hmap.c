// file: hmap/hmap.c
#include "hmap.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static char tombstone_marker;
#define TOMBSTONE (&tombstone_marker)       /* a unique address that is never a real key */

typedef struct {
    char *key;                              /* NULL: empty; TOMBSTONE: deleted */
    void *value;
    uint64_t hash;                          /* cached: cheap rehash and fast mismatch checks */
} Slot;

struct hmap {
    Slot *slots;
    size_t cap;                             /* always a power of two */
    size_t len;                             /* live keys */
    size_t used;                            /* live keys + tombstones */
};

static uint64_t hash_str(const char *s) {   /* FNV-1a */
    uint64_t h = 14695981039346656037u;
    for (; *s; s++) {
        h ^= (unsigned char)*s;
        h *= 1099511628211u;
    }
    return h;
}

HMap *hmap_new(void) {
    HMap *m = malloc(sizeof *m);
    if (m == NULL)
        return NULL;
    m->cap = 16;
    m->len = m->used = 0;
    m->slots = calloc(m->cap, sizeof *m->slots);
    if (m->slots == NULL) {
        free(m);
        return NULL;
    }
    return m;
}

void hmap_free(HMap *m) {
    if (m == NULL)
        return;
    for (size_t i = 0; i < m->cap; i++)
        if (m->slots[i].key != NULL && m->slots[i].key != TOMBSTONE)
            free(m->slots[i].key);
    free(m->slots);
    free(m);
}

/* find_slot returns the index of key's slot, or (if absent) the index where it
   should be inserted: the first tombstone on its probe path, else the empty slot. */
static size_t find_slot(const HMap *m, const char *key, uint64_t h, int *present) {
    size_t mask = m->cap - 1, i = (size_t)h & mask, first_tomb = SIZE_MAX;
    for (;;) {
        Slot *s = &m->slots[i];
        if (s->key == NULL) {
            *present = 0;
            return first_tomb != SIZE_MAX ? first_tomb : i;
        }
        if (s->key == TOMBSTONE) {
            if (first_tomb == SIZE_MAX)
                first_tomb = i;
        } else if (s->hash == h && strcmp(s->key, key) == 0) {
            *present = 1;
            return i;
        }
        i = (i + 1) & mask;                 /* linear probing; terminates: load factor < 1 */
    }
}

/* resize rehashes every live key into a table of new_cap slots (dropping tombstones). */
static int resize(HMap *m, size_t new_cap) {
    Slot *old = m->slots;
    size_t old_cap = m->cap;
    Slot *slots = calloc(new_cap, sizeof *slots);
    if (slots == NULL)
        return -1;
    m->slots = slots;
    m->cap = new_cap;
    m->used = m->len;
    for (size_t i = 0; i < old_cap; i++) {
        if (old[i].key == NULL || old[i].key == TOMBSTONE)
            continue;
        size_t j = (size_t)old[i].hash & (new_cap - 1);
        while (slots[j].key != NULL)
            j = (j + 1) & (new_cap - 1);
        slots[j] = old[i];
    }
    free(old);
    return 0;
}

int hmap_put(HMap *m, const char *key, void *value) {
    uint64_t h = hash_str(key);
    int present;
    size_t i = find_slot(m, key, h, &present);
    if (present) {
        m->slots[i].value = value;
        return 0;
    }
    /* grow (or just clean out tombstones) before the load factor exceeds 0.7 */
    if ((m->used + 1) * 10 > m->cap * 7) {
        size_t new_cap = (m->len + 1) * 10 > m->cap * 5 ? m->cap * 2 : m->cap;
        if (resize(m, new_cap) != 0)
            return -1;
        i = find_slot(m, key, h, &present);
    }
    size_t n = strlen(key) + 1;
    char *copy = malloc(n);
    if (copy == NULL)
        return -1;
    memcpy(copy, key, n);
    if (m->slots[i].key == NULL)
        m->used++;                           /* reusing a tombstone does not raise 'used' */
    m->slots[i] = (Slot){copy, value, h};
    m->len++;
    return 0;
}

void *hmap_get(const HMap *m, const char *key, int *found) {
    int present;
    size_t i = find_slot(m, key, hash_str(key), &present);
    if (found != NULL)
        *found = present;
    return present ? m->slots[i].value : NULL;
}

int hmap_del(HMap *m, const char *key) {
    int present;
    size_t i = find_slot(m, key, hash_str(key), &present);
    if (!present)
        return -1;
    free(m->slots[i].key);
    m->slots[i].key = TOMBSTONE;
    m->slots[i].value = NULL;
    m->len--;
    return 0;
}

size_t hmap_len(const HMap *m) { return m->len; }

int hmap_next(const HMap *m, size_t *iter, const char **key, void **value) {
    for (; *iter < m->cap; (*iter)++) {
        Slot *s = &m->slots[*iter];
        if (s->key != NULL && s->key != TOMBSTONE) {
            *key = s->key;
            *value = s->value;
            (*iter)++;
            return 1;
        }
    }
    return 0;
}
