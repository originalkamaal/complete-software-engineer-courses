// file: hmap/hmap.h
#ifndef HMAP_H
#define HMAP_H

#include <stddef.h>

typedef struct hmap HMap;

/* hmap_new creates an empty map, or returns NULL when out of memory. */
HMap *hmap_new(void);

/* hmap_free releases the map and its key copies. Values are not freed. */
void hmap_free(HMap *m);

/* hmap_put inserts or replaces key's value. The key is copied.
   Returns 0, or -1 when out of memory (the map is unchanged). */
int hmap_put(HMap *m, const char *key, void *value);

/* hmap_get returns key's value; *found (if not NULL) is set to 1 or 0. */
void *hmap_get(const HMap *m, const char *key, int *found);

/* hmap_del removes key. Returns 0, or -1 if it was absent. */
int hmap_del(HMap *m, const char *key);

/* hmap_len returns the number of keys. */
size_t hmap_len(const HMap *m);

/* hmap_next iterates: start with *iter = 0; returns 1 and sets *key and *value
   for each entry, then 0. The map must not be modified during iteration. */
int hmap_next(const HMap *m, size_t *iter, const char **key, void **value);

#endif
