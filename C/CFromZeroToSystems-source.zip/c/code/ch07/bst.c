// file: bst.c
#include <stdio.h>
#include <stdlib.h>

typedef struct Tree {
    int key;
    struct Tree *left, *right;
} Tree;

/* insert adds key (ignoring duplicates); returns 0 or -1. Uses a pointer to the
   link to update, as in the linked list (Unit 7.2). */
static int insert(Tree **t, int key) {
    while (*t != NULL) {
        if (key == (*t)->key)
            return 0;
        t = key < (*t)->key ? &(*t)->left : &(*t)->right;
    }
    *t = calloc(1, sizeof **t);
    if (*t == NULL)
        return -1;
    (*t)->key = key;
    return 0;
}

static const Tree *find(const Tree *t, int key) {
    while (t != NULL && t->key != key)
        t = key < t->key ? t->left : t->right;
    return t;
}

static int height(const Tree *t) {
    if (t == NULL)
        return 0;
    int l = height(t->left), r = height(t->right);
    return 1 + (l > r ? l : r);
}

static void in_order(const Tree *t, int lo, int hi) {   /* prints keys in [lo, hi], sorted */
    if (t == NULL)
        return;
    if (lo < t->key)
        in_order(t->left, lo, hi);
    if (lo <= t->key && t->key <= hi)
        printf("%d ", t->key);
    if (t->key < hi)
        in_order(t->right, lo, hi);
}

static void free_tree(Tree *t) {
    if (t == NULL)
        return;
    free_tree(t->left);
    free_tree(t->right);
    free(t);
}

int main(void) {
    Tree *random_tree = NULL, *sorted_tree = NULL;
    srand(42);
    for (int i = 0; i < 1023; i++) {
        insert(&random_tree, rand() % 100000);
        insert(&sorted_tree, i);                     /* worst case: sorted input */
    }
    printf("height with random keys: %d\n", height(random_tree));
    printf("height with sorted keys: %d (a linked list)\n", height(sorted_tree));
    printf("find(500) in sorted tree: %s\n", find(sorted_tree, 500) ? "found" : "missing");
    printf("range [10, 20]: ");
    in_order(sorted_tree, 10, 20);
    printf("\n");
    free_tree(random_tree);
    free_tree(sorted_tree);
    return 0;
}
