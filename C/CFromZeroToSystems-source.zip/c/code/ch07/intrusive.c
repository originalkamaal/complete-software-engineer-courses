// file: intrusive.c
#include <stddef.h>
#include <stdio.h>

/* A doubly linked, circular list link, embedded in the objects themselves. */
struct list_head {
    struct list_head *next, *prev;
};

#define LIST_INIT(name) {&(name), &(name)}
#define container_of(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))

static void list_add_tail(struct list_head *item, struct list_head *head) {
    item->prev = head->prev;
    item->next = head;
    head->prev->next = item;
    head->prev = item;
}

static void list_del(struct list_head *item) {
    item->prev->next = item->next;
    item->next->prev = item->prev;
    item->next = item->prev = NULL;
}

struct task {
    int id;
    const char *name;
    struct list_head run_link;      /* membership in the run queue */
    struct list_head all_link;      /* membership in the list of all tasks */
};

int main(void) {
    struct list_head run_queue = LIST_INIT(run_queue);
    struct list_head all_tasks = LIST_INIT(all_tasks);
    struct task t[3] = {{1, "init", {0}, {0}}, {2, "shell", {0}, {0}}, {3, "editor", {0}, {0}}};

    for (int i = 0; i < 3; i++) {
        list_add_tail(&t[i].all_link, &all_tasks);
        list_add_tail(&t[i].run_link, &run_queue);
    }
    list_del(&t[1].run_link);       /* shell sleeps: off the run queue, still in all_tasks */

    printf("runnable:");
    for (struct list_head *p = run_queue.next; p != &run_queue; p = p->next) {
        struct task *task = container_of(p, struct task, run_link);
        printf(" %d:%s", task->id, task->name);
    }
    printf("\nall:");
    for (struct list_head *p = all_tasks.next; p != &all_tasks; p = p->next)
        printf(" %s", container_of(p, struct task, all_link)->name);
    printf("\n");
    return 0;
}
