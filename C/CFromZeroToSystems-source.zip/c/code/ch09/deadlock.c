// file: deadlock.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>

typedef struct {
    int id;
    long balance;
    pthread_mutex_t mu;
} Account;

/* transfer locks the two accounts in a global order (by id), whatever the direction. */
static void transfer(Account *from, Account *to, long amount) {
    Account *first = from->id < to->id ? from : to;
    Account *second = from->id < to->id ? to : from;
    pthread_mutex_lock(&first->mu);
    pthread_mutex_lock(&second->mu);
    from->balance -= amount;
    to->balance += amount;
    pthread_mutex_unlock(&second->mu);
    pthread_mutex_unlock(&first->mu);
}

/* transfer_bad locks 'from' then 'to': opposite transfers can deadlock. */
static void transfer_bad(Account *from, Account *to, long amount) {
    pthread_mutex_lock(&from->mu);
    pthread_mutex_lock(&to->mu);
    from->balance -= amount;
    to->balance += amount;
    pthread_mutex_unlock(&to->mu);
    pthread_mutex_unlock(&from->mu);
}

static Account a = {1, 1000, PTHREAD_MUTEX_INITIALIZER}, b = {2, 1000, PTHREAD_MUTEX_INITIALIZER};
static int use_bad;

static void *a_to_b(void *arg) {
    (void)arg;
    for (int i = 0; i < 100000; i++)
        (use_bad ? transfer_bad : transfer)(&a, &b, 1);
    return NULL;
}
static void *b_to_a(void *arg) {
    (void)arg;
    for (int i = 0; i < 100000; i++)
        (use_bad ? transfer_bad : transfer)(&b, &a, 1);
    return NULL;
}

int main(int argc, char *argv[]) {
    use_bad = argc > 1;
    pthread_t t1, t2;
    pthread_create(&t1, NULL, a_to_b, NULL);
    pthread_create(&t2, NULL, b_to_a, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("a=%ld b=%ld total=%ld\n", a.balance, b.balance, a.balance + b.balance);
    return 0;
}
