// file: c11threads.c
#include <stdio.h>
#include <threads.h>

static mtx_t mu;
static int total;

static int work(void *arg) {
    int n = *(int *)arg;
    mtx_lock(&mu);
    total += n;
    mtx_unlock(&mu);
    return n * 10;
}

int main(void) {
    mtx_init(&mu, mtx_plain);
    thrd_t t[3];
    int args[3] = {1, 2, 3};
    for (int i = 0; i < 3; i++)
        if (thrd_create(&t[i], work, &args[i]) != thrd_success)
            return 1;
    for (int i = 0; i < 3; i++) {
        int res;
        thrd_join(t[i], &res);
        printf("thread %d returned %d\n", i, res);
    }
    printf("total %d\n", total);
    mtx_destroy(&mu);
    return 0;
}
