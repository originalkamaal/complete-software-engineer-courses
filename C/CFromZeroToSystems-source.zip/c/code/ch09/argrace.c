// file: argrace.c
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>

static void *show_bad(void *arg) { return (void *)(intptr_t)*(int *)arg; }      /* reads the shared i */
static void *show_good(void *arg) { return arg; }                              /* the value travelled with it */

int main(void) {
    enum { N = 8 };
    pthread_t t[N];
    void *got;

    printf("&i passed: ");
    for (int i = 0; i < N; i++) pthread_create(&t[i], NULL, show_bad, &i);     /* every thread gets the same address */
    for (int i = 0; i < N; i++) { pthread_join(t[i], &got); printf("%d ", (int)(intptr_t)got); }

    printf("\nvalue passed: ");
    for (int i = 0; i < N; i++) pthread_create(&t[i], NULL, show_good, (void *)(intptr_t)i);
    for (int i = 0; i < N; i++) { pthread_join(t[i], &got); printf("%d ", (int)(intptr_t)got); }
    printf("\n");
    return 0;
}
