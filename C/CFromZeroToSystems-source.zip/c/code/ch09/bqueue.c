// file: bqueue.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>

/* A bounded blocking queue: producers wait when full, consumers when empty. */
enum { CAP = 4 };
typedef struct {
    int items[CAP];
    int head, count;
    bool closed;
    pthread_mutex_t mu;
    pthread_cond_t not_empty, not_full;
} BQueue;

static void bq_push(BQueue *q, int v) {
    pthread_mutex_lock(&q->mu);
    while (q->count == CAP)                          /* while, not if: spurious wake-ups */
        pthread_cond_wait(&q->not_full, &q->mu);
    q->items[(q->head + q->count) % CAP] = v;
    q->count++;
    pthread_cond_signal(&q->not_empty);
    pthread_mutex_unlock(&q->mu);
}

/* bq_pop returns false when the queue is closed and empty. */
static bool bq_pop(BQueue *q, int *out) {
    pthread_mutex_lock(&q->mu);
    while (q->count == 0 && !q->closed)
        pthread_cond_wait(&q->not_empty, &q->mu);
    if (q->count == 0) {                             /* closed and drained */
        pthread_mutex_unlock(&q->mu);
        return false;
    }
    *out = q->items[q->head];
    q->head = (q->head + 1) % CAP;
    q->count--;
    pthread_cond_signal(&q->not_full);
    pthread_mutex_unlock(&q->mu);
    return true;
}

static void bq_close(BQueue *q) {
    pthread_mutex_lock(&q->mu);
    q->closed = true;
    pthread_cond_broadcast(&q->not_empty);           /* wake every waiting consumer */
    pthread_mutex_unlock(&q->mu);
}

static BQueue q = {.mu = PTHREAD_MUTEX_INITIALIZER,
                   .not_empty = PTHREAD_COND_INITIALIZER, .not_full = PTHREAD_COND_INITIALIZER};

static void *consumer(void *arg) {
    long id = (long)arg, sum = 0, n = 0;
    int v;
    while (bq_pop(&q, &v)) {
        sum += v;
        n++;
    }
    printf("consumer %ld: %ld items, sum %ld\n", id, n, sum);
    return (void *)sum;
}

int main(void) {
    pthread_t c[3];
    for (long i = 0; i < 3; i++)
        pthread_create(&c[i], NULL, consumer, (void *)i);
    for (int v = 1; v <= 1000; v++)
        bq_push(&q, v);                               /* blocks whenever 4 items are waiting */
    bq_close(&q);
    long total = 0;
    for (int i = 0; i < 3; i++) {
        void *s;
        pthread_join(c[i], &s);
        total += (long)s;
    }
    printf("total %ld (expected %d)\n", total, 1000 * 1001 / 2);
    return 0;
}
