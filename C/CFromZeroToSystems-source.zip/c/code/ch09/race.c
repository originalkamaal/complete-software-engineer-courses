// file: race.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>

enum { THREADS = 4, ITERS = 1000000 };

static long unsafe_count = 0;
static long safe_count = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void *racy(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERS; i++)
        unsafe_count++;                    /* data race: undefined behaviour */
    return NULL;
}

static void *locked(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERS; i++) {
        pthread_mutex_lock(&lock);
        safe_count++;                      /* critical section */
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main(void) {
    pthread_t t[THREADS];
    for (int i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, racy, NULL);
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    for (int i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, locked, NULL);
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    printf("expected %d, unsafe %ld, locked %ld\n", THREADS * ITERS, unsafe_count, safe_count);
    return 0;
}
