// file: threads.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int id;
    long from, to;     /* sum the integers in [from, to) */
    long long result;
} Job;

static void *worker(void *arg) {
    Job *job = arg;                          /* each thread gets its own Job */
    long long s = 0;
    for (long i = job->from; i < job->to; i++)
        s += i;
    job->result = s;                         /* written by one thread only */
    return job;                              /* returned to pthread_join */
}

int main(void) {
    enum { T = 4 };
    const long N = 100000000;
    pthread_t tid[T];
    Job jobs[T];
    for (int t = 0; t < T; t++) {
        jobs[t] = (Job){.id = t, .from = N / T * t, .to = t == T - 1 ? N : N / T * (t + 1)};
        int rc = pthread_create(&tid[t], NULL, worker, &jobs[t]);
        if (rc != 0) {                       /* pthreads return error codes, not errno */
            fprintf(stderr, "pthread_create: error %d\n", rc);
            return 1;
        }
    }
    long long total = 0;
    for (int t = 0; t < T; t++) {
        void *ret;
        pthread_join(tid[t], &ret);
        Job *j = ret;
        printf("thread %d summed [%ld, %ld): %lld\n", j->id, j->from, j->to, j->result);
        total += j->result;
    }
    printf("total = %lld (expected %lld)\n", total, (long long)N * (N - 1) / 2);
    return 0;
}
