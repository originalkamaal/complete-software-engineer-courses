// file: spsc.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define CAP 1024u                                     /* power of two */

typedef struct {
    _Alignas(64) atomic_uint_fast32_t head;          /* written by the consumer only */
    _Alignas(64) atomic_uint_fast32_t tail;          /* written by the producer only */
    _Alignas(64) uint64_t slot[CAP];
} Spsc;

static bool spsc_push(Spsc *q, uint64_t v) {
    uint_fast32_t t = atomic_load_explicit(&q->tail, memory_order_relaxed);   /* our own index */
    uint_fast32_t h = atomic_load_explicit(&q->head, memory_order_acquire);   /* consumer's progress */
    if (t - h == CAP)
        return false;                                                         /* full */
    q->slot[t & (CAP - 1)] = v;                                               /* write the data ... */
    atomic_store_explicit(&q->tail, t + 1, memory_order_release);             /* ... then publish it */
    return true;
}

static bool spsc_pop(Spsc *q, uint64_t *out) {
    uint_fast32_t h = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint_fast32_t t = atomic_load_explicit(&q->tail, memory_order_acquire);   /* see published slots */
    if (t == h)
        return false;                                                         /* empty */
    *out = q->slot[h & (CAP - 1)];
    atomic_store_explicit(&q->head, h + 1, memory_order_release);             /* free the slot */
    return true;
}

static Spsc q;
enum { N = 10000000 };

static void *producer(void *arg) {
    (void)arg;
    for (uint64_t i = 1; i <= N; i++)
        while (!spsc_push(&q, i))
            ;                                         /* queue full: spin */
    return NULL;
}

int main(void) {
    pthread_t p;
    pthread_create(&p, NULL, producer, NULL);
    uint64_t sum = 0, v, expected_next = 1, out_of_order = 0;
    for (long n = 0; n < N;) {
        if (spsc_pop(&q, &v)) {
            out_of_order += v != expected_next;
            expected_next = v + 1;
            sum += v;
            n++;
        }
    }
    pthread_join(p, NULL);
    printf("received %d items, sum %llu (expected %llu), out of order: %llu\n",
           N, (unsigned long long)sum, (unsigned long long)N * (N + 1) / 2,
           (unsigned long long)out_of_order);
    return 0;
}
