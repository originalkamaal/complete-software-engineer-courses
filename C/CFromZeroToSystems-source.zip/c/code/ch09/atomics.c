// file: atomics.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>

enum { THREADS = 4, ITERS = 2000000 };

static atomic_long counter = 0;
static long mutex_counter = 0;
static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;

static void *atomic_worker(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERS; i++)
        atomic_fetch_add_explicit(&counter, 1, memory_order_relaxed);   /* only atomicity needed */
    return NULL;
}

static void *mutex_worker(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERS; i++) {
        pthread_mutex_lock(&mu);
        mutex_counter++;
        pthread_mutex_unlock(&mu);
    }
    return NULL;
}

/* Message passing: the classic acquire/release pattern. */
static int payload;                     /* plain, non-atomic data */
static atomic_bool ready = false;

static void *producer(void *arg) {
    (void)arg;
    payload = 42;                                                  /* 1. write the data */
    atomic_store_explicit(&ready, true, memory_order_release);     /* 2. publish */
    return NULL;
}

static void *consumer(void *arg) {
    (void)arg;
    while (!atomic_load_explicit(&ready, memory_order_acquire))    /* 3. observe the flag */
        ;                                                          /* (spin: fine for a demo) */
    printf("consumer sees payload = %d\n", payload);              /* 4. guaranteed to see 42 */
    return NULL;
}

static double run(void *(*fn)(void *)) {
    struct timespec a, b;
    pthread_t t[THREADS];
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (int i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, fn, NULL);
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    clock_gettime(CLOCK_MONOTONIC, &b);
    return (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6;
}

int main(void) {
    double ta = run(atomic_worker), tm = run(mutex_worker);
    printf("atomic: %ld in %.0f ms; mutex: %ld in %.0f ms\n",
           atomic_load(&counter), ta, mutex_counter, tm);

    pthread_t p, c;
    pthread_create(&c, NULL, consumer, NULL);
    pthread_create(&p, NULL, producer, NULL);
    pthread_join(p, NULL);
    pthread_join(c, NULL);
    return 0;
}
