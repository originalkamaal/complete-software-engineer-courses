// file: falseshare.c
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <time.h>

enum { THREADS = 2, ITERS = 200000000 };

struct packed { volatile long count; };                    /* neighbours share a cache line */
struct padded { _Alignas(64) volatile long count; };      /* one cache line each */

static struct packed packed_counters[THREADS];
static struct padded padded_counters[THREADS];
static _Thread_local long tls_calls;                       /* one per thread */

static void *bump_packed(void *arg) {
    long i = (long)arg;
    for (int k = 0; k < ITERS; k++)
        packed_counters[i].count++;
    tls_calls++;
    return NULL;
}

static void *bump_padded(void *arg) {
    long i = (long)arg;
    for (int k = 0; k < ITERS; k++)
        padded_counters[i].count++;
    tls_calls++;
    return NULL;
}

static double run(void *(*fn)(void *)) {
    struct timespec a, b;
    pthread_t t[THREADS];
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (long i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, fn, (void *)i);
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    clock_gettime(CLOCK_MONOTONIC, &b);
    return (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6;
}

int main(void) {
    printf("sizeof(struct packed)=%zu sizeof(struct padded)=%zu\n",
           sizeof(struct packed), sizeof(struct padded));
    double p = run(bump_packed), q = run(bump_padded);
    printf("same cache line: %.0f ms, separate lines: %.0f ms (%.1fx)\n", p, q, p / q);
    printf("main thread's tls_calls = %ld (each worker had its own copy)\n", tls_calls);
    return 0;
}
