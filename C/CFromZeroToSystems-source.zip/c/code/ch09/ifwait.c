// file: ifwait.c
#define _DEFAULT_SOURCE                       /* usleep is no longer in POSIX; glibc still offers it */
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t c = PTHREAD_COND_INITIALIZER;
static int items;                     /* how many items are in the "queue" */
static int use_while;
static int waiting;

static void *consumer(void *arg) {
    pthread_mutex_lock(&m);
    waiting++;
    if (use_while) { while (items == 0) pthread_cond_wait(&c, &m); }
    else           { if (items == 0) pthread_cond_wait(&c, &m); }      /* the bug */
    items--;                                                          /* take one item */
    printf("  consumer %ld took an item, items left = %d\n", (long)(intptr_t)arg, items);
    pthread_mutex_unlock(&m);
    return NULL;
}

static void run(int with_while) {
    pthread_t a, b;
    use_while = with_while;
    items = waiting = 0;
    pthread_create(&a, NULL, consumer, (void *)1);
    pthread_create(&b, NULL, consumer, (void *)2);
    for (;;) {                                    /* wait until both consumers are asleep */
        pthread_mutex_lock(&m);
        int w = waiting;
        pthread_mutex_unlock(&m);
        if (w == 2) break;
        usleep(1000);
    }
    usleep(10000);
    pthread_mutex_lock(&m);
    items = 1;                                    /* produce ONE item ... */
    pthread_cond_broadcast(&c);                   /* ... but wake everybody */
    pthread_mutex_unlock(&m);
    usleep(100000);
    pthread_mutex_lock(&m);
    if (with_while) { items = 1; pthread_cond_broadcast(&c); }   /* second item for the waiting consumer */
    pthread_mutex_unlock(&m);
    pthread_join(a, NULL);
    pthread_join(b, NULL);
}

int main(void) {
    printf("with if:\n");
    run(0);
    printf("with while:\n");
    run(1);
    return 0;
}
