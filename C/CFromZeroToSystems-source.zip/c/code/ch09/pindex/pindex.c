// file: pindex/pindex.c
/* pindex: count word frequencies in a directory tree with a thread pool. */
#define _XOPEN_SOURCE 700                /* nftw */
#include <ctype.h>
#include <ftw.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "wordtab.h"

/* ---- bounded queue of paths (Unit 9.3) ---- */
enum { QCAP = 256 };
static struct {
    char *paths[QCAP];
    int head, count;
    bool closed;
    pthread_mutex_t mu;
    pthread_cond_t not_empty, not_full;
} q = {.mu = PTHREAD_MUTEX_INITIALIZER, .not_empty = PTHREAD_COND_INITIALIZER,
       .not_full = PTHREAD_COND_INITIALIZER};

static void q_push(char *path) {
    pthread_mutex_lock(&q.mu);
    while (q.count == QCAP)
        pthread_cond_wait(&q.not_full, &q.mu);
    q.paths[(q.head + q.count++) % QCAP] = path;
    pthread_cond_signal(&q.not_empty);
    pthread_mutex_unlock(&q.mu);
}

static char *q_pop(void) {                  /* NULL when closed and empty */
    pthread_mutex_lock(&q.mu);
    while (q.count == 0 && !q.closed)
        pthread_cond_wait(&q.not_empty, &q.mu);
    char *p = NULL;
    if (q.count > 0) {
        p = q.paths[q.head];
        q.head = (q.head + 1) % QCAP;
        q.count--;
        pthread_cond_signal(&q.not_full);
    }
    pthread_mutex_unlock(&q.mu);
    return p;
}

static void q_close(void) {
    pthread_mutex_lock(&q.mu);
    q.closed = true;
    pthread_cond_broadcast(&q.not_empty);
    pthread_mutex_unlock(&q.mu);
}

/* ---- workers ---- */
typedef struct {
    WordTab tab;                             /* private to this worker: no locking */
    long files, bytes;
    _Alignas(64) char pad;                   /* keep workers' hot fields on separate lines */
} Worker;

static void count_file(Worker *w, const char *path) {
    FILE *f = fopen(path, "rb");
    if (f == NULL)
        return;
    char buf[65536], word[64];
    size_t len = 0, n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
        w->bytes += (long)n;
        for (size_t i = 0; i < n; i++) {
            unsigned char c = (unsigned char)buf[i];
            if (isalpha(c)) {
                if (len < sizeof word)
                    word[len++] = (char)tolower(c);
            } else if (len > 0) {
                if (len < sizeof word)       /* ignore absurdly long "words" */
                    wt_add(&w->tab, word, len, 1);
                len = 0;
            }
        }
    }
    if (len > 0 && len < sizeof word)
        wt_add(&w->tab, word, len, 1);
    w->files++;
    fclose(f);
}

static void *worker_main(void *arg) {
    Worker *w = arg;
    char *path;
    while ((path = q_pop()) != NULL) {
        count_file(w, path);
        free(path);
    }
    return NULL;
}

static int visit(const char *path, const struct stat *st, int type, struct FTW *ftw) {
    (void)st; (void)ftw;
    if (type == FTW_F) {
        char *copy = strdup(path);
        if (copy != NULL)
            q_push(copy);
    }
    return 0;                                /* keep walking */
}

static int by_count(const void *a, const void *b) {
    const WordCount *x = a, *y = b;
    if (x->count != y->count)
        return x->count < y->count ? 1 : -1;
    return strcmp(x->word, y->word);         /* deterministic order for ties */
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "usage: pindex THREADS DIR [TOP]\n");
        return 2;
    }
    int nthreads = atoi(argv[1]);
    int top = argc > 3 ? atoi(argv[3]) : 10;
    if (nthreads < 1 || nthreads > 64)
        return 2;

    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    Worker *workers = calloc((size_t)nthreads, sizeof *workers);
    pthread_t *tids = calloc((size_t)nthreads, sizeof *tids);
    if (workers == NULL || tids == NULL)
        return 1;
    for (int i = 0; i < nthreads; i++)
        pthread_create(&tids[i], NULL, worker_main, &workers[i]);
    if (nftw(argv[2], visit, 32, FTW_PHYS) != 0)
        perror(argv[2]);
    q_close();

    WordTab merged = {0};
    long files = 0, bytes = 0;
    for (int i = 0; i < nthreads; i++) {
        pthread_join(tids[i], NULL);         /* after join, the worker's table is safe to read */
        files += workers[i].files;
        bytes += workers[i].bytes;
        for (size_t s = 0; s < workers[i].tab.cap; s++) {
            WordCount *wc = &workers[i].tab.slots[s];
            if (wc->word != NULL)
                wt_add(&merged, wc->word, strlen(wc->word), wc->count);
        }
        wt_free(&workers[i].tab);
    }
    WordCount *all = malloc(merged.len * sizeof *all);
    size_t n = 0;
    for (size_t s = 0; s < merged.cap; s++)
        if (merged.slots[s].word != NULL)
            all[n++] = merged.slots[s];
    qsort(all, n, sizeof *all, by_count);
    clock_gettime(CLOCK_MONOTONIC, &t1);

    printf("%ld files, %.1f MB, %zu distinct words, %d threads, %.0f ms\n", files, bytes / 1e6, n,
           nthreads, (t1.tv_sec - t0.tv_sec) * 1e3 + (t1.tv_nsec - t0.tv_nsec) / 1e6);
    for (int i = 0; i < top && (size_t)i < n; i++)
        printf("%8ld %s\n", all[i].count, all[i].word);
    free(all);
    wt_free(&merged);
    free(workers);
    free(tids);
    return 0;
}
