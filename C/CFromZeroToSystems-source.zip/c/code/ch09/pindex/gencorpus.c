// file: pindex/gencorpus.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

static const char *vocab[] = {
    "the", "of", "and", "to", "in", "is", "that", "for", "it", "as", "with", "was", "on",
    "kernel", "thread", "memory", "pointer", "lock", "queue", "cache", "file", "process",
    "signal", "socket", "buffer", "atomic", "mutex", "compiler", "linker", "stack", "heap",
};

int main(int argc, char *argv[]) {
    if (argc != 4) return 2;
    const char *dir = argv[1];
    int files = atoi(argv[2]), words = atoi(argv[3]);
    size_t nv = sizeof vocab / sizeof vocab[0];
    srand(2024);
    for (int f = 0; f < files; f++) {
        char sub[512], path[600];
        snprintf(sub, sizeof sub, "%s/d%02d", dir, f % 10);
        mkdir(dir, 0755);
        mkdir(sub, 0755);
        snprintf(path, sizeof path, "%s/file%04d.txt", sub, f);
        FILE *out = fopen(path, "w");
        if (out == NULL) return 1;
        for (int w = 0; w < words; w++) {
            size_t r = (size_t)rand() % nv;
            size_t k = (size_t)rand() % (r + 1);          /* skew towards early words */
            fprintf(out, "%s%c", vocab[k], w % 12 == 11 ? '\n' : ' ');
        }
        fclose(out);
    }
    return 0;
}
