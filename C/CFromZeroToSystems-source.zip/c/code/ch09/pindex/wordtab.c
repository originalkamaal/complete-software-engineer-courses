// file: pindex/wordtab.c
#include "wordtab.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static uint64_t hash(const char *s, size_t n) {
    uint64_t h = 14695981039346656037u;
    for (size_t i = 0; i < n; i++) {
        h ^= (unsigned char)s[i];
        h *= 1099511628211u;
    }
    return h;
}

static int grow(WordTab *t) {
    size_t cap = t->cap ? t->cap * 2 : 1024;
    WordCount *s = calloc(cap, sizeof *s);
    if (s == NULL)
        return -1;
    for (size_t i = 0; i < t->cap; i++) {
        if (t->slots[i].word == NULL)
            continue;
        size_t j = hash(t->slots[i].word, strlen(t->slots[i].word)) & (cap - 1);
        while (s[j].word != NULL)
            j = (j + 1) & (cap - 1);
        s[j] = t->slots[i];
    }
    free(t->slots);
    t->slots = s;
    t->cap = cap;
    return 0;
}

int wt_add(WordTab *t, const char *word, size_t len, long n) {
    if ((t->len + 1) * 4 > t->cap * 3 && grow(t) != 0)        /* load factor <= 0.75 */
        return -1;
    size_t i = hash(word, len) & (t->cap - 1);
    while (t->slots[i].word != NULL) {
        if (strncmp(t->slots[i].word, word, len) == 0 && t->slots[i].word[len] == '\0') {
            t->slots[i].count += n;
            return 0;
        }
        i = (i + 1) & (t->cap - 1);
    }
    char *w = malloc(len + 1);
    if (w == NULL)
        return -1;
    memcpy(w, word, len);
    w[len] = '\0';
    t->slots[i] = (WordCount){w, n};
    t->len++;
    return 0;
}

void wt_free(WordTab *t) {
    for (size_t i = 0; i < t->cap; i++)
        free(t->slots[i].word);
    free(t->slots);
    *t = (WordTab){0};
}
