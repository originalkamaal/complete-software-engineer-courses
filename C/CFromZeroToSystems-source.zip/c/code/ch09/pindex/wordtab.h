// file: pindex/wordtab.h
#ifndef WORDTAB_H
#define WORDTAB_H
#include <stddef.h>

typedef struct { char *word; long count; } WordCount;
typedef struct { WordCount *slots; size_t cap, len; } WordTab;

int wt_add(WordTab *t, const char *word, size_t len, long n);   /* 0 or -1 (no memory) */
void wt_free(WordTab *t);

#endif
