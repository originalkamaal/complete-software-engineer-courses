// file: mods/app/com/example/app/Main.java
package com.example.app;

import com.example.greeter.Greeter;

public class Main {
    public static void main(String[] args) {
        System.out.println(Greeter.greet("modules"));
        // com.example.greeter.internal.Format.decorate("x");   // error: package is not exported
    }
}
