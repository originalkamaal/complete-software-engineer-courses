// file: mods/app/module-info.java
module app {
    requires greeter;
}
