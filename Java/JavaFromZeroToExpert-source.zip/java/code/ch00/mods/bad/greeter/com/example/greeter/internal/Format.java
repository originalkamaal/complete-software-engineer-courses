// file: mods/greeter/com/example/greeter/internal/Format.java
package com.example.greeter.internal;

public class Format {
    public static String decorate(String s) { return "*** " + s + " ***"; }
}
