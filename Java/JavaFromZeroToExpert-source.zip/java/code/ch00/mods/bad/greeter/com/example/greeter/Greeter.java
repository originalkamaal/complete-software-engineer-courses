// file: mods/greeter/com/example/greeter/Greeter.java
package com.example.greeter;

import com.example.greeter.internal.Format;

public class Greeter {
    public static String greet(String name) { return Format.decorate("Hello, " + name); }
}
