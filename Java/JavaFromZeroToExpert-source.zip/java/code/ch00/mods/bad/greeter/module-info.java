// file: mods/greeter/module-info.java
module greeter {
    exports com.example.greeter;          // the API
    // com.example.greeter.internal is NOT exported
}
