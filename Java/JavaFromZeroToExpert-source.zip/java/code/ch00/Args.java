// file: Args.java
public class Args {
    public static void main(String[] args) {
        System.out.println("received " + args.length + " argument(s)");
        for (int i = 0; i < args.length; i++) {
            System.out.println("  args[" + i + "] = " + args[i]);
        }
        System.out.println("java.version = " + System.getProperty("java.version").split("\\.")[0]);
    }
}
