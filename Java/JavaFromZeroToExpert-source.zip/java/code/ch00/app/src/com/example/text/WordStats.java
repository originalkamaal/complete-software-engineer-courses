// file: app/src/com/example/text/WordStats.java
package com.example.text;

import java.util.Map;
import java.util.TreeMap;

/** Counts words in text. */
public final class WordStats {
    private WordStats() {}

    public static Map<String, Integer> count(String text) {
        Map<String, Integer> counts = new TreeMap<>();
        for (String w : text.toLowerCase().split("[^a-z']+")) {
            if (!w.isEmpty()) {
                counts.merge(w, 1, Integer::sum);
            }
        }
        return counts;
    }
}
