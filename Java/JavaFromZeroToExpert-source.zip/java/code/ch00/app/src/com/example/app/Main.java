// file: app/src/com/example/app/Main.java
package com.example.app;

import com.example.text.WordStats;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        String text = args.length > 0 ? Files.readString(Path.of(args[0])) : "to be or not to be";
        Map<String, Integer> counts = WordStats.count(text);
        counts.entrySet().stream()
              .sorted(Map.Entry.<String, Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey()))
              .limit(5)
              .forEach(e -> System.out.printf("%-6s %d%n", e.getKey(), e.getValue()));
    }
}
