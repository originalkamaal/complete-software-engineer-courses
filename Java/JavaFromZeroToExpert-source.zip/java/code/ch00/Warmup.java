// file: Warmup.java
public class Warmup {
    static long work(int n) {
        long h = 0;
        for (int i = 0; i < n; i++) {
            h = h * 31 + (i ^ (h >>> 7));
        }
        return h;
    }

    public static void main(String[] args) {
        long sink = 0;
        for (int round = 1; round <= 8; round++) {
            long t = System.nanoTime();
            for (int k = 0; k < 400; k++) {
                sink += work(5_000);                          // 400 calls of a small method per round
            }
            System.out.printf("round %d: %6.2f ms%n", round, (System.nanoTime() - t) / 1e6);
        }
        System.out.println("(checksum " + sink + ")");
    }
}
