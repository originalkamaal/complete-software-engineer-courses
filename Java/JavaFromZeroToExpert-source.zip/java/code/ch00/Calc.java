// file: Calc.java
public class Calc {
    static int sumOfSquares(int n) {
        int total = 0;
        for (int i = 1; i <= n; i++) {
            total += i * i;
        }
        return total;
    }

    static String label(String name, int n) {
        return name + "=" + n;
    }

    public static void main(String[] args) {
        System.out.println(label("sumOfSquares(10)", sumOfSquares(10)));
    }
}
