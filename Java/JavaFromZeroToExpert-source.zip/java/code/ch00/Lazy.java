// file: Lazy.java
public class Lazy {
    static class Config {
        static final int CONSTANT = 42;                       // a compile-time constant: inlined by javac
        static final long LOADED_AT;
        static {
            LOADED_AT = System.nanoTime();
            System.out.println("  [Config initialised]");
        }
        static String describe() { return "config loaded at " + LOADED_AT; }
    }

    static class Unused {
        static { System.out.println("  [Unused initialised]"); }   // never printed
    }

    public static void main(String[] args) {
        System.out.println("main starts");
        System.out.println("reading a constant: " + Config.CONSTANT);   // does NOT initialise Config
        System.out.println("calling a static method:");
        System.out.println(Config.describe().startsWith("config") ? "  ok" : "  ?");
        System.out.println("Config's loader: " + Config.class.getClassLoader().getName()
                + ", String's loader: " + String.class.getClassLoader());
    }
}
