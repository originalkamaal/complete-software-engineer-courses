// file: cp/lib/Helper.java
package lib;

public class Helper {
    public static String greet(String who) { return "hello from " + who; }
}
