// file: cp/app/Main.java
package app;

import lib.Helper;

public class Main {
    public static void main(String[] args) throws Exception {
        try {
            Class.forName("lib.Missing");
        } catch (ClassNotFoundException e) {
            System.out.println("ClassNotFoundException: " + e.getMessage());
        }
        System.out.println(Helper.greet("class path"));
    }
}
