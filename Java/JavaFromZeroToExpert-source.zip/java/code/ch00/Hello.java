// file: Hello.java
import java.util.List;

public class Hello {
    public static void main(String[] args) {
        String who = args.length > 0 ? args[0] : "world";
        System.out.println("Hello, " + who + "!");
        List<Integer> squares = List.of(1, 2, 3, 4).stream().map(n -> n * n).toList();
        System.out.println("squares " + squares + ", running on Java " + Runtime.version().feature()
                + " (" + System.getProperty("java.vm.name") + ")");
    }
}
