// file: Deadlock.java
import java.lang.management.ManagementFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class Deadlock {
    static final class Account {
        final int id;
        long balance = 1000;
        final ReentrantLock lock = new ReentrantLock();
        Account(int id) { this.id = id; }
    }

    static void transferNaive(Account from, Account to, long amount) {
        synchronized (from) {
            Thread.yield();                                       // widen the window
            synchronized (to) { from.balance -= amount; to.balance += amount; }
        }
    }

    static void transferOrdered(Account from, Account to, long amount) {
        Account first = from.id < to.id ? from : to, second = first == from ? to : from;   // global order by id
        synchronized (first) {
            synchronized (second) { from.balance -= amount; to.balance += amount; }
        }
    }

    static boolean transferTryLock(Account from, Account to, long amount) throws InterruptedException {
        if (from.lock.tryLock(10, TimeUnit.MILLISECONDS)) {
            try {
                if (to.lock.tryLock(10, TimeUnit.MILLISECONDS)) {
                    try { from.balance -= amount; to.balance += amount; return true; } finally { to.lock.unlock(); }
                }
            } finally {
                from.lock.unlock();
            }
        }
        return false;                                             // caller may retry
    }

    interface Transfer { void run(Account a, Account b) throws InterruptedException; }

    static String race(String name, Transfer transfer) throws InterruptedException {
        Account a = new Account(1), b = new Account(2);
        Thread t1 = new Thread(() -> { try { for (int i = 0; i < 100_000; i++) transfer.run(a, b); } catch (InterruptedException e) { } }, name + "-A");
        Thread t2 = new Thread(() -> { try { for (int i = 0; i < 100_000; i++) transfer.run(b, a); } catch (InterruptedException e) { } }, name + "-B");
        t1.setDaemon(true); t2.setDaemon(true);
        t1.start(); t2.start();
        t1.join(3000); t2.join(3000);
        long[] dead = ManagementFactory.getThreadMXBean().findDeadlockedThreads();
        return dead != null ? "DEADLOCK detected among " + dead.length + " threads" : "finished, total balance " + (a.balance + b.balance);
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("ordered locks: " + race("ordered", (x, y) -> transferOrdered(x, y, 1)));
        System.out.println("tryLock:       " + race("trylock", (x, y) -> { while (!transferTryLock(x, y, 1)) Thread.onSpinWait(); }));
        System.out.println("naive nesting: " + race("naive", (x, y) -> transferNaive(x, y, 1)));
    }
}
