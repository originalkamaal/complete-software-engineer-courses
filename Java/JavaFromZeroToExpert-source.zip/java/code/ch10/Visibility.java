// file: Visibility.java
public class Visibility {
    static boolean stopPlain = false;
    static volatile boolean stopVolatile = false;

    static boolean stopsWithin(Runnable loop, Runnable setFlag, long millis) throws InterruptedException {
        Thread t = new Thread(loop);
        t.setDaemon(true);                                        // so a stuck thread does not keep the JVM alive
        t.start();
        Thread.sleep(200);                                        // let the JIT compile the hot loop
        setFlag.run();
        t.join(millis);
        return !t.isAlive();
    }

    public static void main(String[] args) throws InterruptedException {
        boolean a = stopsWithin(() -> { long n = 0; while (!stopPlain) n++; }, () -> stopPlain = true, 1000);
        boolean b = stopsWithin(() -> { long n = 0; while (!stopVolatile) n++; }, () -> stopVolatile = true, 1000);
        System.out.println("plain flag:    loop stopped within 1 s? " + a);
        System.out.println("volatile flag: loop stopped within 1 s? " + b);
    }
}
