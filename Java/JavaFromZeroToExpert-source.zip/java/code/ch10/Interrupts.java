// file: Interrupts.java
public class Interrupts {
    static void politeSleep() {
        try { Thread.sleep(10_000); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }   // restore the flag
    }
    static void rudeSleep() {
        try { Thread.sleep(10_000); }
        catch (InterruptedException e) { /* swallowed */ }
    }
    static Thread worker(String name, Runnable sleeper) {
        return Thread.ofPlatform().name(name).start(() -> {
            int rounds = 0;
            while (!Thread.currentThread().isInterrupted() && rounds < 3) { sleeper.run(); rounds++; }
            System.out.println(name + " stopped after " + rounds + " round(s), interrupted flag " + Thread.currentThread().isInterrupted());
        });
    }
    public static void main(String[] args) throws InterruptedException {
        Thread polite = worker("polite", Interrupts::politeSleep);
        Thread rude = worker("rude", Interrupts::rudeSleep);
        Thread.sleep(100);
        polite.interrupt();
        rude.interrupt();
        polite.join();
        rude.join(1_000);
        System.out.println("rude still running a second later: " + rude.isAlive());
        rude.interrupt(); rude.interrupt();
        rude.join();
    }
}
