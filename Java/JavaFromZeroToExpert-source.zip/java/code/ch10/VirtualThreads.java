// file: VirtualThreads.java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

public class VirtualThreads {
    static void blockingCall() {
        try { Thread.sleep(200); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }   // stands for a network call
    }

    static long run(ExecutorService pool, int tasks) {
        long t = System.nanoTime();
        AtomicInteger done = new AtomicInteger();
        try (pool) {
            IntStream.range(0, tasks).forEach(i -> pool.submit(() -> { blockingCall(); done.incrementAndGet(); }));
        }                                                             // close() waits for all tasks
        if (done.get() != tasks) throw new AssertionError();
        return (System.nanoTime() - t) / 1_000_000;
    }

    public static void main(String[] args) throws Exception {
        int tasks = 10_000;
        System.out.printf("%,d blocking tasks of 200 ms:%n", tasks);
        System.out.printf("  200 platform threads (pool):  %,6d ms%n", run(Executors.newFixedThreadPool(200), tasks));
        System.out.printf("  one virtual thread per task:  %,6d ms%n", run(Executors.newVirtualThreadPerTaskExecutor(), tasks));
        Thread v = Thread.ofVirtual().name("my-virtual").start(() -> System.out.println("  running in " + Thread.currentThread()));
        v.join();
        long t = System.nanoTime();
        Thread[] many = new Thread[100_000];
        for (int i = 0; i < many.length; i++) many[i] = Thread.startVirtualThread(VirtualThreads::blockingCall);
        for (Thread th : many) th.join();
        System.out.printf("  100,000 virtual threads each sleeping 200 ms: %d ms total%n", (System.nanoTime() - t) / 1_000_000);
    }
}
