// file: crawler/Crawler.java
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Phaser;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

public class Crawler {
    /** A deterministic fake web: page i links to a few pseudo-random pages; fetching blocks. */
    static final class Web {
        final int pages, hosts;
        final AtomicInteger inFlight = new AtomicInteger(), maxInFlight = new AtomicInteger();
        final Map<Integer, AtomicInteger> perHost = new ConcurrentHashMap<>();
        final AtomicInteger maxPerHost = new AtomicInteger();
        final LongAdder fetches = new LongAdder();

        Web(int pages, int hosts) { this.pages = pages; this.hosts = hosts; }

        int hostOf(int page) { return page % hosts; }

        List<Integer> fetch(int page) {
            fetches.increment();
            maxInFlight.accumulateAndGet(inFlight.incrementAndGet(), Math::max);
            AtomicInteger h = perHost.computeIfAbsent(hostOf(page), k -> new AtomicInteger());
            maxPerHost.accumulateAndGet(h.incrementAndGet(), Math::max);
            try {
                Thread.sleep(2 + page % 5);                              // 2-6 ms of "network"
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                h.decrementAndGet();
                inFlight.decrementAndGet();
            }
            List<Integer> links = new ArrayList<>();
            long x = page * 2654435761L + 12345;
            int n = 1 + (int) (x >>> 7) % 4;
            for (int i = 0; i < n; i++) {
                x = x * 6364136223846793005L + 1442695040888963407L;
                links.add((int) ((x >>> 33) % pages));
            }
            if (page + 1 < pages && page % 3 == 0) links.add(page + 1);  // keeps most of the web reachable
            return links;
        }
    }

    record Result(int visited, long checksum, long millis) {}

    static Result sequential(Web web, int start) {
        long t = System.nanoTime();
        Set<Integer> seen = new java.util.HashSet<>(Set.of(start));
        ArrayDeque<Integer> queue = new ArrayDeque<>(List.of(start));
        long checksum = 0;
        while (!queue.isEmpty()) {
            int page = queue.poll();
            checksum += page;
            for (int link : web.fetch(page)) if (seen.add(link)) queue.add(link);
        }
        return new Result(seen.size(), checksum, (System.nanoTime() - t) / 1_000_000);
    }

    /** Concurrent crawl: one task per page; `seen` decides atomically who fetches a page. */
    static Result concurrent(Web web, int start, ExecutorService executor, int perHostLimit) {
        long t = System.nanoTime();
        Set<Integer> seen = ConcurrentHashMap.newKeySet();
        Map<Integer, Semaphore> hostLimits = new ConcurrentHashMap<>();
        LongAdder checksum = new LongAdder();
        Phaser pending = new Phaser(1);                                  // counts unfinished tasks; main is party 1
        class Task implements Runnable {
            final int page;
            Task(int page) { this.page = page; pending.register(); }     // registered before submission
            @Override public void run() {
                try {
                    Semaphore limit = hostLimits.computeIfAbsent(web.hostOf(page), h -> new Semaphore(perHostLimit));
                    limit.acquireUninterruptibly();
                    List<Integer> links;
                    try {
                        links = web.fetch(page);
                    } finally {
                        limit.release();
                    }
                    checksum.add(page);
                    for (int link : links) {
                        if (seen.add(link)) executor.execute(new Task(link));   // add() is atomic: exactly one thread wins
                    }
                } finally {
                    pending.arriveAndDeregister();
                }
            }
        }
        try (executor) {
            seen.add(start);
            executor.execute(new Task(start));
            pending.arriveAndAwaitAdvance();                             // wait until every registered task has finished
        }
        return new Result(seen.size(), checksum.sum(), (System.nanoTime() - t) / 1_000_000);
    }

    public static void main(String[] args) {
        int pages = 3000, hosts = 30;
        Web w1 = new Web(pages, hosts);
        Result seq = sequential(w1, 0);
        System.out.printf("sequential:            %d pages, checksum %d, %5d ms, max in flight %d%n", seq.visited(), seq.checksum(), seq.millis(), w1.maxInFlight.get());
        Web w2 = new Web(pages, hosts);
        Result pool = concurrent(w2, 0, Executors.newFixedThreadPool(32), 4);
        System.out.printf("32 platform threads:   %d pages, checksum %d, %5d ms, max in flight %d, max per host %d, fetches %d%n",
                pool.visited(), pool.checksum(), pool.millis(), w2.maxInFlight.get(), w2.maxPerHost.get(), w2.fetches.sum());
        Web w3 = new Web(pages, hosts);
        Result virt = concurrent(w3, 0, Executors.newVirtualThreadPerTaskExecutor(), 4);
        System.out.printf("virtual threads:       %d pages, checksum %d, %5d ms, max in flight %d, max per host %d, fetches %d%n",
                virt.visited(), virt.checksum(), virt.millis(), w3.maxInFlight.get(), w3.maxPerHost.get(), w3.fetches.sum());
        System.out.println("all three agree: " + (seq.visited() == pool.visited() && pool.visited() == virt.visited()
                && seq.checksum() == pool.checksum() && pool.checksum() == virt.checksum())
                + "; no page fetched twice: " + (w2.fetches.sum() == pool.visited() && w3.fetches.sum() == virt.visited()));
    }
}
