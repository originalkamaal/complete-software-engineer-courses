// file: Threads.java
public class Threads {
    public static void main(String[] args) throws InterruptedException {
        Thread worker = new Thread(() -> {
            int ticks = 0;
            try {
                while (true) {
                    Thread.sleep(20);
                    ticks++;
                }
            } catch (InterruptedException e) {                    // the interrupt arrives as an exception while blocked
                System.out.println("worker interrupted after " + (ticks >= 3 ? "some" : "few") + " ticks; cleaning up");
            }
        }, "worker-1");
        worker.start();
        Thread.sleep(100);
        worker.interrupt();
        worker.join();

        Thread spinner = Thread.ofPlatform().name("spinner").start(() -> {
            long n = 0;
            while (!Thread.currentThread().isInterrupted()) n++;   // CPU-bound code must poll the flag itself
            System.out.println("spinner saw the flag");
        });
        Thread.sleep(50);
        spinner.interrupt();
        spinner.join();
        System.out.println("main: " + Thread.currentThread().getName() + ", worker state: " + worker.getState()
                + ", cores: " + Runtime.getRuntime().availableProcessors());
    }
}
