// file: Race.java
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

public class Race {
    static long plain = 0;
    static long locked = 0;
    static final Object lock = new Object();
    static final AtomicLong atomic = new AtomicLong();
    static final LongAdder adder = new LongAdder();

    static long timed(Runnable body) throws InterruptedException {
        Thread[] ts = new Thread[4];
        long t = System.nanoTime();
        for (int i = 0; i < ts.length; i++) {
            ts[i] = new Thread(() -> { for (int k = 0; k < 2_000_000; k++) body.run(); });
            ts[i].start();
        }
        for (Thread th : ts) th.join();
        return (System.nanoTime() - t) / 1_000_000;
    }

    public static void main(String[] args) throws InterruptedException {
        long t1 = timed(() -> plain++);
        long t2 = timed(() -> { synchronized (lock) { locked++; } });
        long t3 = timed(atomic::incrementAndGet);
        long t4 = timed(adder::increment);
        System.out.printf("expected 8000000%nplain++       %8d  (%d ms)  <- lost updates%nsynchronized  %8d  (%d ms)%nAtomicLong    %8d  (%d ms)%nLongAdder     %8d  (%d ms)%n",
                plain, t1, locked, t2, atomic.get(), t3, adder.sum(), t4);
    }
}
