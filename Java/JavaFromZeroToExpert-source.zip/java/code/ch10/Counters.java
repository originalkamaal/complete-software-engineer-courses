// file: Counters.java
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

public class Counters {
    interface Counter { void inc(); long get(); }

    static long run(Counter c) throws InterruptedException {
        Thread[] ts = new Thread[4];
        long t0 = System.nanoTime();
        for (int i = 0; i < ts.length; i++) ts[i] = Thread.ofPlatform().start(() -> { for (int k = 0; k < 2_000_000; k++) c.inc(); });
        for (Thread t : ts) t.join();
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("  total " + c.get());
        return ms;
    }

    public static void main(String[] args) throws InterruptedException {
        long[] plain = {0};
        System.out.println("plain long (racy):");
        run(new Counter() { public void inc() { plain[0]++; } public long get() { return plain[0]; } });
        AtomicLong al = new AtomicLong();
        System.out.println("AtomicLong:");
        long atomicMs = run(new Counter() { public void inc() { al.incrementAndGet(); } public long get() { return al.get(); } });
        LongAdder adder = new LongAdder();
        System.out.println("LongAdder:");
        long adderMs = run(new Counter() { public void inc() { adder.increment(); } public long get() { return adder.sum(); } });
        System.out.println("LongAdder faster than AtomicLong here: " + (adderMs < atomicMs));
    }
}
