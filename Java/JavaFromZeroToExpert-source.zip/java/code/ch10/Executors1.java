// file: Executors1.java
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

public class Executors1 {
    static int slowSquare(int x) {
        try { Thread.sleep(100); } catch (InterruptedException e) { throw new IllegalStateException(e); }
        if (x == 13) throw new IllegalArgumentException("unlucky " + x);
        return x * x;
    }

    public static void main(String[] args) throws Exception {
        long t = System.nanoTime();
        try (ExecutorService pool = Executors.newFixedThreadPool(8)) {            // close() waits for submitted tasks
            List<Callable<Integer>> tasks = IntStream.rangeClosed(1, 16).<Callable<Integer>>mapToObj(i -> () -> slowSquare(i)).toList();
            int sum = 0, failed = 0;
            for (Future<Integer> f : pool.invokeAll(tasks)) {
                try {
                    sum += f.get();
                } catch (ExecutionException e) {                                  // the task's exception, wrapped
                    failed++;
                    System.out.println("task failed: " + e.getCause());
                }
            }
            System.out.printf("16 tasks of 100 ms on 8 threads: sum %d, %d failed, %d ms%n", sum, failed, (System.nanoTime() - t) / 1_000_000 / 10 * 10);
        }

        t = System.nanoTime();
        CompletableFuture<Integer> price = CompletableFuture.supplyAsync(() -> slowSquare(7));
        CompletableFuture<Integer> stock = CompletableFuture.supplyAsync(() -> slowSquare(3));
        CompletableFuture<String> report = price.thenCombine(stock, (p, s) -> "price " + p + ", stock " + s)   // both, in parallel
            .thenApply(String::toUpperCase);
        CompletableFuture<String> recovered = CompletableFuture.supplyAsync(() -> slowSquare(13)).thenApply(v -> "value " + v)
            .exceptionally(ex -> "fallback (" + ex.getCause().getMessage() + ")");
        CompletableFuture<String> timedOut = CompletableFuture.supplyAsync(() -> { slowSquare(1); slowSquare(2); slowSquare(4); return "late"; })
            .orTimeout(150, TimeUnit.MILLISECONDS).exceptionally(ex -> "timed out: " + ex.getClass().getSimpleName());
        System.out.println(report.get() + " | " + recovered.get() + " | " + timedOut.get() + " | " + (System.nanoTime() - t) / 1_000_000 / 50 * 50 + " ms");
    }
}
