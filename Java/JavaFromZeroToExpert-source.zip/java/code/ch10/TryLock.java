// file: TryLock.java
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class TryLock {
    static final ReentrantLock a = new ReentrantLock(), b = new ReentrantLock();
    static int retries = 0;

    static void both(ReentrantLock first, ReentrantLock second) throws InterruptedException {
        while (true) {
            if (first.tryLock(10, TimeUnit.MILLISECONDS)) {
                try {
                    if (second.tryLock(10, TimeUnit.MILLISECONDS)) {
                        try { return; } finally { second.unlock(); }   // got both: do the work
                    }
                } finally { first.unlock(); }
            }
            synchronized (TryLock.class) { retries++; }
            Thread.sleep(ThreadLocalRandom.current().nextInt(5));     // back off a random amount
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread t1 = Thread.ofPlatform().start(() -> { try { for (int i = 0; i < 2000; i++) both(a, b); } catch (InterruptedException e) {} });
        Thread t2 = Thread.ofPlatform().start(() -> { try { for (int i = 0; i < 2000; i++) both(b, a); } catch (InterruptedException e) {} });
        t1.join(); t2.join();
        System.out.println("4000 critical sections completed in opposite lock orders, no deadlock"
                           + (retries > 0 ? " (some retries needed)" : ""));
    }
}
