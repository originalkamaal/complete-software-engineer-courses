// file: Futures.java
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class Futures {
    static CompletableFuture<Integer> price(String item, int ms) {
        return CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); }
            if (item.equals("broken")) throw new IllegalStateException("no price for " + item);
            return item.length() * 100;
        });
    }

    public static void main(String[] args) {
        long t0 = System.nanoTime();
        CompletableFuture<Integer> total = price("pen", 200).thenCombine(price("notebook", 200), Integer::sum);
        System.out.println("combined: " + total.join() + " in " + ((System.nanoTime() - t0) / 100_000_000 * 100) + "ms (parallel)");

        String r = price("broken", 10).thenApply(p -> "price " + p)
                                       .exceptionally(e -> "recovered from " + e.getCause().getMessage())
                                       .join();
        System.out.println(r);

        List<CompletableFuture<Integer>> all = List.of(price("a", 50), price("bb", 60), price("ccc", 70));
        CompletableFuture.allOf(all.toArray(CompletableFuture[]::new)).join();
        System.out.println("allOf: " + all.stream().map(CompletableFuture::join).toList());

        try {
            price("slow", 2_000).orTimeout(100, TimeUnit.MILLISECONDS).join();
        } catch (Exception e) {
            System.out.println("orTimeout: " + e.getCause().getClass().getSimpleName());
        }
    }
}
