// file: ConcurrentTools.java
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

public class ConcurrentTools {
    static void hammer(Map<Integer, Integer> map, boolean atomicMerge) throws InterruptedException {
        Thread[] ts = new Thread[4];
        for (int i = 0; i < 4; i++) {
            ts[i] = new Thread(() -> {
                for (int k = 0; k < 200_000; k++) {
                    int key = k % 100;
                    if (atomicMerge) map.merge(key, 1, Integer::sum);          // atomic on ConcurrentHashMap
                    else map.put(key, map.getOrDefault(key, 0) + 1);            // check-then-act: a race even on a concurrent map
                }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
    }

    public static void main(String[] args) throws InterruptedException {
        Map<Integer, Integer> chmMerge = new ConcurrentHashMap<>(), chmRacy = new ConcurrentHashMap<>();
        hammer(chmMerge, true);
        hammer(chmRacy, false);
        System.out.println("ConcurrentHashMap.merge:       total " + chmMerge.values().stream().mapToInt(i -> i).sum() + " of 800000");
        System.out.println("ConcurrentHashMap get-then-put: total " + chmRacy.values().stream().mapToInt(i -> i).sum() + " of 800000  <- compound action not atomic");
        try {
            Map<Integer, Integer> hm = new HashMap<>();
            hammer(hm, true);
            System.out.println("plain HashMap, 4 threads:      total " + hm.values().stream().mapToInt(i -> i).sum() + " of 800000  <- corrupted");
        } catch (RuntimeException e) {
            System.out.println("plain HashMap, 4 threads:      " + e.getClass().getSimpleName());
        }

        // producer/consumer with a bounded queue, a latch, and a semaphore
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);            // put() blocks when full
        CountDownLatch done = new CountDownLatch(3);
        Semaphore permits = new Semaphore(2);                                   // at most 2 consumers work at once
        AtomicInteger maxConcurrent = new AtomicInteger(), current = new AtomicInteger(), sum = new AtomicInteger();
        for (int c = 0; c < 3; c++) {
            new Thread(() -> {
                try {
                    for (int v; (v = queue.take()) >= 0; ) {                    // negative value: poison pill
                        permits.acquire();
                        try {
                            maxConcurrent.accumulateAndGet(current.incrementAndGet(), Math::max);
                            sum.addAndGet(v);
                            Thread.sleep(1);
                        } finally {
                            current.decrementAndGet();
                            permits.release();
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    done.countDown();
                }
            }).start();
        }
        for (int i = 1; i <= 100; i++) queue.put(i);
        for (int c = 0; c < 3; c++) queue.put(-1);
        done.await();
        System.out.println("3 consumers processed sum " + sum.get() + " (expected 5050); most working at once: " + maxConcurrent.get());
    }
}
