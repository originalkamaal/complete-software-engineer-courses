// file: Chaining.java
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class Chaining {
    /** The repository layer's own exception: callers need not know about files. */
    static class RepositoryException extends Exception {
        private final String key;
        RepositoryException(String message, String key, Throwable cause) {
            super(message, cause);
            this.key = key;
        }
        String key() { return key; }
    }

    static String load(String key) throws RepositoryException {
        try {
            return Files.readString(Path.of("store", key + ".txt"));
        } catch (IOException e) {
            throw new RepositoryException("cannot load " + key, key, e);       // translate, keep the cause
        }
    }

    public static void main(String[] args) {
        try {
            load("customer-42");
        } catch (RepositoryException e) {
            System.out.println(e.getMessage() + " (key " + e.key() + ")");
            System.out.println("cause: " + e.getCause());
        }
        // inside a lambda, checked exceptions are not allowed: wrap in an unchecked one
        try {
            List.of("a", "b").forEach(k -> {
                try {
                    load(k);
                } catch (RepositoryException e) {
                    throw new UncheckedIOException((IOException) e.getCause());
                }
            });
        } catch (UncheckedIOException e) {
            System.out.println("unchecked wrapper: " + e.getCause().getClass().getSimpleName());
        }
    }
}
