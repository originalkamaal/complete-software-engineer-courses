// file: importer/Importer.java
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Importer {
    public record Product(String sku, String name, BigDecimal price, int stock) {}

    public record RowError(int line, int column, String message) {
        @Override public String toString() { return "line " + line + ", column " + column + ": " + message; }
    }

    /** The importer's own failure type: either the input is invalid, or I/O failed. */
    public static class ImportException extends Exception {
        private final List<RowError> errors;
        ImportException(String message, List<RowError> errors, Throwable cause) {
            super(message, cause);
            this.errors = List.copyOf(errors);
        }
        public List<RowError> errors() { return errors; }
    }

    static List<Product> parse(BufferedReader in) throws IOException, ImportException {
        List<Product> products = new ArrayList<>();
        List<RowError> errors = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String header = in.readLine();
        if (!"sku,name,price,stock".equals(header)) {
            throw new ImportException("unexpected header: " + header, List.of(new RowError(1, 1, "expected sku,name,price,stock")), null);
        }
        String line;
        int lineNo = 1;
        while ((line = in.readLine()) != null) {
            lineNo++;
            if (line.isBlank()) continue;
            String[] f = line.split(",", -1);                  // -1: keep trailing empty fields
            if (f.length != 4) {
                errors.add(new RowError(lineNo, 1, "expected 4 fields, found " + f.length));
                continue;
            }
            int before = errors.size();
            String sku = f[0].strip();
            if (!sku.matches("[A-Z]{3}-\\d{4}")) errors.add(new RowError(lineNo, 1, "bad SKU '" + sku + "'"));
            else if (!seen.add(sku)) errors.add(new RowError(lineNo, 1, "duplicate SKU " + sku));
            String name = f[1].strip();
            if (name.isEmpty()) errors.add(new RowError(lineNo, 2, "empty name"));
            BigDecimal price = null;
            try {
                price = new BigDecimal(f[2].strip());
                if (price.signum() < 0 || price.scale() > 2) errors.add(new RowError(lineNo, 3, "price must be >= 0 with at most 2 decimals: " + price));
            } catch (NumberFormatException e) {
                errors.add(new RowError(lineNo, 3, "not a number '" + f[2].strip() + "'"));
            }
            int stock = 0;
            try {
                stock = Integer.parseInt(f[3].strip());
                if (stock < 0) errors.add(new RowError(lineNo, 4, "negative stock " + stock));
            } catch (NumberFormatException e) {
                errors.add(new RowError(lineNo, 4, "not an integer '" + f[3].strip() + "'"));
            }
            if (errors.size() == before) products.add(new Product(sku, name, price, stock));
        }
        if (!errors.isEmpty()) {
            throw new ImportException(errors.size() + " invalid value(s); nothing imported", errors, null);
        }
        return products;
    }

    /** Validates `csv` completely, then replaces `data` atomically. On any failure, `data` is untouched. */
    public static int importFile(Path csv, Path data, int failAfterRows) throws ImportException {
        List<Product> products;
        try (BufferedReader in = Files.newBufferedReader(csv, StandardCharsets.UTF_8)) {
            products = parse(in);
        } catch (IOException e) {
            throw new ImportException("cannot read " + csv, List.of(), e);
        }
        Path tmp = data.resolveSibling(data.getFileName() + ".tmp");
        try {
            try (BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                int written = 0;
                for (Product p : products) {
                    if (written++ == failAfterRows) throw new IOException("simulated disk full after " + failAfterRows + " rows");
                    out.write(p.sku() + "\t" + p.name() + "\t" + p.price() + "\t" + p.stock());
                    out.newLine();
                }
            }
            try {
                Files.move(tmp, data, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, data, StandardCopyOption.REPLACE_EXISTING);
            }
            return products.size();
        } catch (IOException e) {
            try {
                Files.deleteIfExists(tmp);
            } catch (IOException cleanup) {
                e.addSuppressed(cleanup);                  // keep the original failure, attach the cleanup failure
            }
            throw new ImportException("cannot write " + data + "; previous data kept", List.of(), e);
        }
    }

    public static void main(String[] args) throws IOException {
        Path data = Path.of("products.tsv");
        Files.writeString(data, "OLD-0001\tprevious catalogue\t1.00\t1\n");
        String[][] runs = {
            {"good.csv", "-1"}, {"bad.csv", "-1"}, {"good.csv", "2"}, {"missing.csv", "-1"},
        };
        for (String[] run : runs) {
            System.out.println("== import " + run[0] + (run[1].equals("-1") ? "" : " (failing after " + run[1] + " rows)"));
            try {
                System.out.println("imported " + importFile(Path.of(run[0]), data, Integer.parseInt(run[1])) + " products");
            } catch (ImportException e) {
                System.out.println("FAILED: " + e.getMessage());
                e.errors().forEach(err -> System.out.println("  " + err));
                if (e.getCause() != null) System.out.println("  cause: " + e.getCause());
            }
            System.out.println("data file now starts with: " + Files.readAllLines(data).get(0).replace('\t', '|')
                    + " (" + Files.readAllLines(data).size() + " lines), temp file left behind: " + Files.exists(Path.of("products.tsv.tmp")));
        }
    }
}
