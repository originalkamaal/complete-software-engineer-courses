// file: CloseOrder.java
public class CloseOrder {
    record Res(String name) implements AutoCloseable {
        Res { System.out.println("open " + name); }
        @Override public void close() { System.out.println("close " + name); }
    }

    public static void main(String[] args) {
        Res db = new Res("database");
        try (db; Res file = new Res("file"); Res lock = new Res("lock")) {
            System.out.println("working with " + db.name() + ", " + file.name() + ", " + lock.name());
        }
        System.out.println("after try");
    }
}
