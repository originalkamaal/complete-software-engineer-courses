// file: Results.java
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Results {
    static final Map<String, String> EMAILS = Map.of("ada", "ada@example.com", "alan", "");

    static Optional<String> email(String user) {
        return Optional.ofNullable(EMAILS.get(user)).filter(e -> !e.isBlank());
    }

    sealed interface Parsed<T> permits Ok, Err {}
    record Ok<T>(T value) implements Parsed<T> {}
    record Err<T>(String reason, int position) implements Parsed<T> {}

    static Parsed<Integer> parsePort(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) return new Err<>("not a digit: '" + s.charAt(i) + "'", i);
        }
        if (s.isEmpty()) return new Err<>("empty", 0);
        int v = Integer.parseInt(s.length() > 5 ? "99999" : s);
        return v >= 1 && v <= 65535 ? new Ok<>(v) : new Err<>("out of range 1..65535", 0);
    }

    public static void main(String[] args) {
        for (String user : List.of("ada", "alan", "grace")) {
            String domain = email(user).map(e -> e.substring(e.indexOf('@') + 1)).orElse("(none)");
            System.out.println(user + " -> " + domain);
        }
        for (String s : List.of("8080", "80a0", "", "70000")) {
            String msg = switch (parsePort(s)) {
                case Ok<Integer>(Integer port) -> "port " + port;
                case Err<Integer>(String why, int at) -> "invalid at " + at + ": " + why;
            };
            System.out.println("\"" + s + "\" -> " + msg);
        }
    }
}
