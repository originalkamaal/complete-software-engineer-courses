// file: OrElse.java
import java.util.Optional;

public class OrElse {
    static int calls = 0;
    static String expensiveDefault() { calls++; return "default"; }

    public static void main(String[] args) {
        Optional<String> present = Optional.of("cached");
        String a = present.orElse(expensiveDefault());
        System.out.println(a + ", expensiveDefault calls with orElse: " + calls);
        calls = 0;
        String b = present.orElseGet(OrElse::expensiveDefault);
        System.out.println(b + ", expensiveDefault calls with orElseGet: " + calls);

        Optional<String> name = Optional.of("  Ada ");
        System.out.println(name.map(String::strip).filter(s -> !s.isEmpty()).map(String::toUpperCase).orElse("?"));
        System.out.println(Optional.empty().or(() -> Optional.of("fallback")).get());
    }
}
