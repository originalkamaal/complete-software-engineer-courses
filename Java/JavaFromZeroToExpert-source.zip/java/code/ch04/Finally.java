// file: Finally.java
public class Finally {
    static int returnsFromTry() {
        try {
            return 1;
        } finally {
            System.out.println("  finally runs before the method returns");
        }
    }


    static int finallyOverridesReturn() {
        try {
            return 1;
        } finally {
            return 2;                                          // replaces the pending return
        }
    }


    static int finallySwallowsException() {
        try {
            throw new IllegalStateException("important failure");
        } finally {
            return 3;                                          // the exception is silently lost
        }
    }

    static int finallyCannotChangeReturnedValue() {
        int x = 10;
        try {
            return x;                                          // the value 10 is saved here
        } finally {
            x = 20;                                            // too late
        }
    }

    public static void main(String[] args) {
        System.out.println("returnsFromTry: " + returnsFromTry());
        System.out.println("finallyOverridesReturn: " + finallyOverridesReturn());
        System.out.println("finallySwallowsException: " + finallySwallowsException());
        System.out.println("finallyCannotChangeReturnedValue: " + finallyCannotChangeReturnedValue());
        try {
            Object o = "text";
            Integer i = (Integer) o;
            System.out.println(i);
        } catch (ClassCastException | NullPointerException e) {    // multi-catch
            System.out.println("multi-catch: " + e.getClass().getSimpleName());
        }
    }
}
