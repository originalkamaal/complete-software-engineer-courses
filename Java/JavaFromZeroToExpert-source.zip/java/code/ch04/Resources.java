// file: Resources.java
public class Resources {
    record Res(String name, boolean failOnClose) implements AutoCloseable {
        Res {
            System.out.println("  open " + name);
        }
        @Override public void close() {
            System.out.println("  close " + name);
            if (failOnClose) throw new IllegalStateException("close failed: " + name);
        }
    }

    public static void main(String[] args) {
        System.out.println("normal exit:");
        try (var a = new Res("A", false); var b = new Res("B", false)) {
            System.out.println("  body uses " + a.name() + " and " + b.name());
        }

        System.out.println("body throws, and B's close throws too:");
        try (var a = new Res("A", false); var b = new Res("B", true)) {
            throw new RuntimeException("body failed");
        } catch (RuntimeException e) {
            System.out.println("caught: " + e.getMessage());
            for (Throwable s : e.getSuppressed()) {
                System.out.println("  suppressed: " + s.getMessage());
            }
        }
    }
}
