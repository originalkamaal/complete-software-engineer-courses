// file: Hierarchy.java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Hierarchy {
    static String firstLine(Path p) throws IOException {      // checked: must be declared
        return Files.readAllLines(p).get(0);                  // get(0) may throw an unchecked exception
    }

    static int depth(int n) {
        return depth(n + 1) + 1;                              // never returns
    }

    public static void main(String[] args) throws Exception {
        Files.writeString(Path.of("empty.txt"), "");
        for (String name : new String[] {"Hierarchy.java", "missing.txt", "empty.txt"}) {
            try {
                System.out.println("first line: " + firstLine(Path.of(name)).strip());
            } catch (IOException e) {
                System.out.println("checked   " + e.getClass().getName() + ": " + e.getMessage());
            } catch (IndexOutOfBoundsException e) {
                System.out.println("unchecked " + e.getClass().getName() + ": " + e.getMessage());
            }
        }
        try {
            depth(0);
        } catch (StackOverflowError e) {
            System.out.println("Error     " + e.getClass().getName() + " (stack trace has " + e.getStackTrace().length + " frames)");
        }
        for (Class<?> c = NumberFormatException.class; c != null; c = c.getSuperclass()) {
            System.out.print(c.getSimpleName() + (c.getSuperclass() != null ? " -> " : "\n"));
        }
    }
}
