// file: CheckedLambda.java
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CheckedLambda {
    static long size(Path p) throws IOException { return Files.size(p); }

    public static void main(String[] args) throws IOException {
        Path a = Files.writeString(Path.of("a.txt"), "hello");
        List<Path> paths = List.of(a, Path.of("missing.txt"));
        // paths.stream().map(p -> size(p))        // error: unreported exception IOException
        try {
            long total = paths.stream().mapToLong(p -> {
                try { return size(p); }
                catch (IOException e) { throw new UncheckedIOException(e); }   // wrap at the lambda
            }).sum();
            System.out.println("total " + total);
        } catch (UncheckedIOException e) {
            System.out.println("failed: " + e.getCause().getClass().getSimpleName() + " " + e.getCause().getMessage());
        }
    }
}
