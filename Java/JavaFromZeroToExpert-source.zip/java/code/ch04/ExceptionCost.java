// file: ExceptionCost.java
public class ExceptionCost {
    static Integer parseOrNull(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {                       // exceptions as control flow
            return null;
        }
    }

    static Integer parseCheckFirst(String s) {
        if (s.isEmpty() || s.length() > 10) return null;
        int start = s.charAt(0) == '-' ? 1 : 0;
        if (start == s.length()) return null;
        for (int i = start; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) return null;
        }
        long v = Long.parseLong(s);                                 // safe now: digits only, at most 10
        return (v < Integer.MIN_VALUE || v > Integer.MAX_VALUE) ? null : (int) v;
    }

    static class Cheap extends RuntimeException {
        Cheap() { super(null, null, false, false); }               // no stack trace, no suppression
    }

    static int recurse(int depth, boolean cheap) {
        if (depth == 0) throw cheap ? new Cheap() : new RuntimeException();
        return recurse(depth - 1, cheap) + 1;
    }

    public static void main(String[] args) {
        String[] inputs = new String[1_000_000];
        for (int i = 0; i < inputs.length; i++) inputs[i] = (i % 10 == 0) ? Integer.toString(i) : "x" + i;   // 90% invalid
        for (int round = 0; round < 3; round++) {
            long t = System.nanoTime();
            int a = 0;
            for (String s : inputs) if (parseOrNull(s) != null) a++;
            long t1 = System.nanoTime();
            int b = 0;
            for (String s : inputs) if (parseCheckFirst(s) != null) b++;
            long t2 = System.nanoTime();
            System.out.printf("round %d: try/catch %5.0f ms, check first %4.0f ms (valid: %d = %d)%n", round, (t1 - t) / 1e6, (t2 - t1) / 1e6, a, b);
        }
        for (boolean cheap : new boolean[] {false, true}) {
            long t = System.nanoTime();
            for (int i = 0; i < 100_000; i++) {
                try { recurse(50, cheap); } catch (RuntimeException e) { /* expected */ }
            }
            System.out.printf("throw from 50 frames deep x100k, %s: %.0f ms%n", cheap ? "no stack trace" : "with stack trace", (System.nanoTime() - t) / 1e6);
        }
    }
}
