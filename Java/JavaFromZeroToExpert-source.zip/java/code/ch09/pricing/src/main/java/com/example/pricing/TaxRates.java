// file: pricing/src/main/java/com/example/pricing/TaxRates.java
package com.example.pricing;

import java.math.BigDecimal;

/** Where tax rates come from: a database or a remote service in production. */
public interface TaxRates {
    /** @throws UnknownCountryException if there is no rate for the country */
    BigDecimal rateFor(String country);

    class UnknownCountryException extends RuntimeException {
        private static final long serialVersionUID = 1L;      // exceptions are Serializable; -Xlint:all insists
        public UnknownCountryException(String country) { super("no tax rate for " + country); }
    }
}
