// file: pricing/src/main/java/com/example/pricing/Money.java
package com.example.pricing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** An amount in cents. */
public record Money(long cents) implements Comparable<Money> {
    public static final Money ZERO = new Money(0);

    public static Money of(String amount) {
        return new Money(new BigDecimal(amount).movePointRight(2).longValueExact());
    }
    public Money plus(Money o) { return new Money(Math.addExact(cents, o.cents)); }
    public Money minus(Money o) { return new Money(Math.subtractExact(cents, o.cents)); }
    public Money times(int n) { return new Money(Math.multiplyExact(cents, n)); }
    /** Applies a percentage, rounding half-up to the cent. */
    public Money percent(BigDecimal pct) {
        return new Money(BigDecimal.valueOf(cents).multiply(pct).divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValueExact());
    }
    @Override public int compareTo(Money o) { return Long.compare(cents, o.cents); }
    @Override public String toString() { return "%s%d.%02d".formatted(cents < 0 ? "-" : "", Math.abs(cents / 100), Math.abs(cents % 100)); }
}
