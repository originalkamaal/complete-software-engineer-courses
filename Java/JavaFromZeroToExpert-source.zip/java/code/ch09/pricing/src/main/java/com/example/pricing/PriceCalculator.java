// file: pricing/src/main/java/com/example/pricing/PriceCalculator.java
package com.example.pricing;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/** Computes order totals: volume discount, weekend promotion, tax, shipping. */
public final class PriceCalculator {
    public record Line(String sku, Money unitPrice, int quantity) {
        public Line {
            Objects.requireNonNull(sku);
            if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive: " + quantity);
            if (unitPrice.cents() < 0) throw new IllegalArgumentException("negative price for " + sku);
        }
    }
    public record Quote(Money subtotal, Money discount, Money tax, Money shipping, Money total) {}

    private final TaxRates taxRates;                       // a dependency: looked up by country
    private final Clock clock;                             // a dependency: "today"

    public PriceCalculator(TaxRates taxRates, Clock clock) {
        this.taxRates = Objects.requireNonNull(taxRates);
        this.clock = Objects.requireNonNull(clock);
    }

    public Quote quote(List<Line> lines, String country) {
        if (lines.isEmpty()) throw new IllegalArgumentException("empty order");
        Money subtotal = Money.ZERO;
        int items = 0;
        for (Line l : lines) {
            subtotal = subtotal.plus(l.unitPrice().times(l.quantity()));
            items += l.quantity();
        }
        BigDecimal pct = items >= 100 ? BigDecimal.TEN : items >= 10 ? new BigDecimal("5") : BigDecimal.ZERO;
        DayOfWeek day = LocalDate.now(clock).getDayOfWeek();
        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) pct = pct.add(new BigDecimal("2.5"));   // weekend promotion
        Money discount = subtotal.percent(pct);
        Money net = subtotal.minus(discount);
        Money tax = net.percent(taxRates.rateFor(country));
        Money shipping = net.compareTo(Money.of("50.00")) >= 0 ? Money.ZERO : Money.of("4.99");
        return new Quote(subtotal, discount, tax, shipping, net.plus(tax).plus(shipping));
    }
}
