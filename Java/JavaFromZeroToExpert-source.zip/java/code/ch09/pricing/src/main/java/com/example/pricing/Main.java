// file: pricing/src/main/java/com/example/pricing/Main.java
package com.example.pricing;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String, BigDecimal> rates = Map.of("DE", new BigDecimal("19"), "FR", new BigDecimal("20"));
        TaxRates taxRates = c -> {
            BigDecimal r = rates.get(c);
            if (r == null) throw new TaxRates.UnknownCountryException(c);
            return r;
        };
        var calc = new PriceCalculator(taxRates, Clock.systemDefaultZone());
        var quote = calc.quote(List.of(new PriceCalculator.Line("PEN", Money.of("1.20"), 12), new PriceCalculator.Line("PAD", Money.of("4.50"), 3)), "DE");
        System.out.println("total " + quote.total() + " (discount and total depend on the day of the week)");
    }
}
