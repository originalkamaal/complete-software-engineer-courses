// file: pricing/src/test/java/com/example/pricing/PriceCalculatorTest.java
package com.example.pricing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import com.example.pricing.PriceCalculator.Line;
import com.example.pricing.PriceCalculator.Quote;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

public class PriceCalculatorTest {
    static final Clock WEDNESDAY = Clock.fixed(Instant.parse("2026-11-18T10:00:00Z"), ZoneOffset.UTC);
    static final Clock SATURDAY = Clock.fixed(Instant.parse("2026-11-21T10:00:00Z"), ZoneOffset.UTC);

    /** A fake that also records calls, so tests can verify interactions. */
    static class RecordingTaxRates implements TaxRates {
        final List<String> calls = new ArrayList<>();
        @Override public BigDecimal rateFor(String country) {
            calls.add(country);
            return switch (country) {
                case "DE" -> new BigDecimal("19");
                case "CH" -> new BigDecimal("8.1");
                case "XX" -> BigDecimal.ZERO;
                default -> throw new UnknownCountryException(country);
            };
        }
    }

    private RecordingTaxRates taxRates;
    private PriceCalculator calc;

    @Before
    public void setUp() {                                  // runs before every test, on a fresh instance
        taxRates = new RecordingTaxRates();
        calc = new PriceCalculator(taxRates, WEDNESDAY);
    }

    @Test
    public void smallOrderPaysTaxAndShipping() {
        Quote q = calc.quote(List.of(new Line("PEN", Money.of("1.20"), 5)), "DE");
        assertEquals(Money.of("6.00"), q.subtotal());
        assertEquals(Money.ZERO, q.discount());
        assertEquals(Money.of("1.14"), q.tax());
        assertEquals(Money.of("4.99"), q.shipping());
        assertEquals(Money.of("12.13"), q.total());
    }

    @Test
    public void weekendPromotionAddsToVolumeDiscount() {
        PriceCalculator weekend = new PriceCalculator(taxRates, SATURDAY);
        Quote q = weekend.quote(List.of(new Line("PAD", Money.of("4.00"), 10)), "XX");
        assertEquals(Money.of("3.00"), q.discount());      // 5% volume + 2.5% weekend of 40.00
    }

    @Test
    public void freeShippingIsDecidedAfterDiscount() {
        // 52.00 gross, 5% off -> 49.40 net: below the 50.00 threshold, so shipping applies
        Quote q = calc.quote(List.of(new Line("INK", Money.of("5.20"), 10)), "XX");
        assertEquals(Money.of("4.99"), q.shipping());
    }

    @Test
    public void asksForTheTaxRateExactlyOnce() {
        calc.quote(List.of(new Line("A", Money.of("1.00"), 1), new Line("B", Money.of("2.00"), 2)), "CH");
        assertEquals(List.of("CH"), taxRates.calls);       // interaction verified with a hand-written recorder
    }

    @Test
    public void unknownCountryPropagatesAndEmptyOrderIsRejected() {
        var e = assertThrows(TaxRates.UnknownCountryException.class, () -> calc.quote(List.of(new Line("A", Money.of("1.00"), 1)), "ZZ"));
        assertEquals("no tax rate for ZZ", e.getMessage());
        assertThrows(IllegalArgumentException.class, () -> calc.quote(List.of(), "DE"));
        assertThrows(IllegalArgumentException.class, () -> new Line("A", Money.of("1.00"), 0));
    }

    /** One test body, many rows of data: the volume-discount boundaries. */
    @RunWith(Parameterized.class)
    public static class VolumeDiscountTest {
        @Parameters(name = "{0} items -> discount {1}")
        public static Collection<Object[]> data() {
            return Arrays.asList(new Object[][] {{1, "0.00"}, {9, "0.00"}, {10, "0.50"}, {99, "4.95"}, {100, "10.00"}, {250, "25.00"}});
        }
        private final int items;
        private final String expected;
        public VolumeDiscountTest(int items, String expected) { this.items = items; this.expected = expected; }

        @Test
        public void discountAtBoundary() {
            PriceCalculator c = new PriceCalculator(country -> BigDecimal.ZERO, WEDNESDAY);     // a stub as a lambda
            assertEquals(Money.of(expected), c.quote(List.of(new Line("X", Money.of("1.00"), items)), "any").discount());
        }
    }
}
