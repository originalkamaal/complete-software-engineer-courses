// file: pricing/src/test/java/com/example/pricing/MoneyTest.java
package com.example.pricing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import java.math.BigDecimal;
import org.junit.Test;

public class MoneyTest {
    @Test
    public void parsesDecimalStringsExactly() {
        assertEquals(1234, Money.of("12.34").cents());
        assertEquals(500, Money.of("5").cents());
        assertEquals(-50, Money.of("-0.50").cents());
    }

    @Test
    public void rejectsFractionsOfACent() {
        assertThrows(ArithmeticException.class, () -> Money.of("0.005"));
    }

    @Test
    public void percentRoundsHalfUpToTheCent() {
        assertEquals(Money.of("0.13"), Money.of("2.50").percent(new BigDecimal("5")));      // 12.5 cents -> 13
        assertEquals(Money.of("0.12"), Money.of("2.49").percent(new BigDecimal("5")));      // 12.45 cents -> 12
    }

    @Test
    public void overflowIsAnErrorNotAWrongAnswer() {
        assertThrows(ArithmeticException.class, () -> new Money(Long.MAX_VALUE).plus(new Money(1)));
    }

    @Test
    public void formatsNegativeAmounts() {
        assertEquals("-0.50", new Money(-50).toString());
        assertEquals("12.05", new Money(1205).toString());
    }
}
