// file: limiter/src/test/java/limiter/TokenBucketTest.java
package limiter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class TokenBucketTest {
    /** A clock the test moves by hand. */
    static final class FakeClock {
        long nanos;
        void advanceMillis(long ms) { nanos += ms * 1_000_000; }
    }

    private FakeClock clock;
    private TokenBucket bucket;                               // 5 tokens, 10 per second

    @Before
    public void setUp() {
        clock = new FakeClock();
        bucket = new TokenBucket(5, 10, () -> clock.nanos);
    }

    private int drain() {
        int n = 0;
        while (bucket.tryAcquire()) n++;
        return n;
    }

    @Test
    public void startsFullAndAllowsABurstUpToCapacity() {
        assertEquals(5, drain());
        assertFalse(bucket.tryAcquire());
    }

    @Test
    public void refillsContinuouslyAtTheConfiguredRate() {
        drain();
        clock.advanceMillis(99);
        assertFalse("0.99 tokens is not enough", bucket.tryAcquire());
        clock.advanceMillis(1);
        assertTrue("one token after 100 ms at 10/s", bucket.tryAcquire());
        assertFalse(bucket.tryAcquire());
        clock.advanceMillis(250);
        assertEquals(2, drain());                             // 2.5 tokens -> 2 whole ones
    }

    @Test
    public void neverHoldsMoreThanCapacity() {
        clock.advanceMillis(60_000);                          // a minute idle
        assertEquals(5, drain());
    }

    @Test
    public void partialTokensAreKept() {
        drain();
        clock.advanceMillis(50);                              // 0.5
        assertFalse(bucket.tryAcquire());
        clock.advanceMillis(50);                              // 1.0: the earlier half was not lost
        assertTrue(bucket.tryAcquire());
    }

    @Test
    public void multiPermitRequestsAreAllOrNothing() {
        assertTrue(bucket.tryAcquire(3));
        assertFalse(bucket.tryAcquire(3));                    // only 2 left: takes none
        assertEquals(2, drain());
    }

    @Test
    public void reportsTimeUntilAvailable() {
        drain();
        assertEquals(100_000_000L, bucket.nanosUntilAvailable(1));
        clock.advanceMillis(40);
        assertEquals(60_000_000L, bucket.nanosUntilAvailable(1));
        assertEquals(0, new TokenBucket(1, 1, () -> 0).nanosUntilAvailable(1));
    }

    @Test
    public void survivesClockWrapAround() {
        clock.nanos = Long.MAX_VALUE - 10;                    // System.nanoTime may be near overflow
        TokenBucket b = new TokenBucket(2, 1000, () -> clock.nanos);
        assertTrue(b.tryAcquire(2));
        clock.nanos += 1_000_020;                             // wraps to a large negative number
        assertTrue("1 ms passed across the wrap: one token", b.tryAcquire());
        assertFalse(b.tryAcquire());
    }

    @Test
    public void rejectsInvalidArguments() {
        assertThrows(IllegalArgumentException.class, () -> new TokenBucket(0, 1, () -> 0));
        assertThrows(IllegalArgumentException.class, () -> new TokenBucket(1, 0, () -> 0));
        assertThrows(IllegalArgumentException.class, () -> bucket.tryAcquire(6));
        assertThrows(IllegalArgumentException.class, () -> bucket.tryAcquire(0));
    }
}
