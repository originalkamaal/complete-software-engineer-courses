// file: limiter/src/main/java/limiter/TokenBucket.java
package limiter;

import java.util.function.LongSupplier;

/**
 * A token bucket: holds up to `capacity` tokens, refilled continuously at `refillPerSecond`.
 * Each permitted request takes one token. Not thread-safe (Chapter 10 makes it so).
 */
public final class TokenBucket {
    private final long capacity;
    private final double refillPerNano;
    private final LongSupplier nanoClock;                     // injected: System::nanoTime in production
    private double tokens;
    private long lastRefill;

    public TokenBucket(long capacity, double refillPerSecond, LongSupplier nanoClock) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
        if (refillPerSecond <= 0) throw new IllegalArgumentException("refill rate must be positive");
        this.capacity = capacity;
        this.refillPerNano = refillPerSecond / 1e9;
        this.nanoClock = nanoClock;
        this.tokens = capacity;                               // starts full
        this.lastRefill = nanoClock.getAsLong();
    }

    /** Takes one token if available. */
    public boolean tryAcquire() { return tryAcquire(1); }

    public boolean tryAcquire(int permits) {
        if (permits <= 0 || permits > capacity) throw new IllegalArgumentException("permits out of range: " + permits);
        refill();
        if (tokens >= permits) {
            tokens -= permits;
            return true;
        }
        return false;
    }

    /** Nanoseconds until `permits` tokens will be available (0 if they are now). */
    public long nanosUntilAvailable(int permits) {
        refill();
        return tokens >= permits ? 0 : (long) Math.ceil((permits - tokens) / refillPerNano);
    }

    private void refill() {
        long now = nanoClock.getAsLong();
        long elapsed = now - lastRefill;                      // subtraction is safe across nanoTime overflow
        if (elapsed > 0) {
            tokens = Math.min(capacity, tokens + elapsed * refillPerNano);
            lastRefill = now;
        }
    }
}
