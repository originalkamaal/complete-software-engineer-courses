// file: Factories.java
import java.util.HashMap;
import java.util.Map;

public class Factories {
    static final class Color {
        private static final Map<String, Color> NAMED = new HashMap<>();
        final int r, g, b;

        private Color(int r, int g, int b) {                     // private: use the factories
            if ((r | g | b) >>> 8 != 0) throw new IllegalArgumentException("component out of 0..255");
            this.r = r; this.g = g; this.b = b;
        }
        private Color(int grey) { this(grey, grey, grey); }      // delegates to the main constructor

        static Color rgb(int r, int g, int b) { return new Color(r, g, b); }
        static Color grey(int level) { return new Color(level); }
        static Color hex(String s) {
            int v = Integer.parseInt(s.replace("#", ""), 16);
            return new Color(v >> 16 & 0xff, v >> 8 & 0xff, v & 0xff);
        }
        static Color named(String name) {                        // cached: one instance per name
            return NAMED.computeIfAbsent(name, n -> switch (n) {
                case "red" -> new Color(255, 0, 0);
                case "white" -> new Color(255);
                default -> throw new IllegalArgumentException("unknown colour " + n);
            });
        }
        @Override public String toString() { return "Color(%d,%d,%d)".formatted(r, g, b); }
    }

    public static void main(String[] args) {
        System.out.println(Color.rgb(10, 20, 30) + " " + Color.grey(128) + " " + Color.hex("#1e90ff"));
        System.out.println("same cached instance: " + (Color.named("red") == Color.named("red")));
        try { Color.rgb(300, 0, 0); } catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
