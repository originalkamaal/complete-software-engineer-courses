// file: bank/AccountId.java
/** An account identifier: "AC-" followed by 6 digits, with a mod-97 check. */
public record AccountId(String value) {
    public AccountId {
        if (value == null || !value.matches("AC-\\d{6}")) throw new IllegalArgumentException("malformed account id: " + value);
        if (Integer.parseInt(value.substring(3)) % 97 != 1) throw new IllegalArgumentException("check digit failed: " + value);
    }
}
