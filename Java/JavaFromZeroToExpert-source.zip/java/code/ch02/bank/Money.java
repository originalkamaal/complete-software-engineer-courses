// file: bank/Money.java
import java.util.Objects;

/** An exact amount of money in minor units (cents), with an ISO currency code. */
public record Money(long cents, String currency) implements Comparable<Money> {
    public Money {
        Objects.requireNonNull(currency, "currency");
        if (!currency.matches("[A-Z]{3}")) throw new IllegalArgumentException("bad currency code: " + currency);
    }

    public static Money of(String amount, String currency) {          // "12.34" -> 1234 cents, exactly
        var bd = new java.math.BigDecimal(amount).movePointRight(2);
        return new Money(bd.longValueExact(), currency);               // throws if it has fractions of a cent
    }

    public Money plus(Money o) { requireSame(o); return new Money(Math.addExact(cents, o.cents), currency); }
    public Money minus(Money o) { requireSame(o); return new Money(Math.subtractExact(cents, o.cents), currency); }
    public boolean isNegative() { return cents < 0; }

    private void requireSame(Money o) {
        if (!currency.equals(o.currency)) throw new IllegalArgumentException("currency mismatch: " + currency + " vs " + o.currency);
    }

    @Override public int compareTo(Money o) { requireSame(o); return Long.compare(cents, o.cents); }
    @Override public String toString() {                              // sign handled separately: -50 cents is "-0.50"
        return "%s %s%d.%02d".formatted(currency, cents < 0 ? "-" : "", Math.abs(cents / 100), Math.abs(cents % 100));
    }
}
