// file: bank/Account.java
import java.time.Clock;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** An account. Invariants: balance >= 0, balance == sum of history, history is append-only. */
public final class Account {
    private final AccountId id;
    private final String owner;
    private final Clock clock;                                   // injected, so tests can control time
    private Money balance;
    private final List<Transaction> history = new ArrayList<>();

    public Account(AccountId id, String owner, String currency, Clock clock) {
        this.id = Objects.requireNonNull(id);
        this.owner = Objects.requireNonNull(owner).strip();
        if (this.owner.isEmpty()) throw new IllegalArgumentException("owner must not be blank");
        this.clock = Objects.requireNonNull(clock);
        this.balance = new Money(0, currency);
    }

    public AccountId id() { return id; }
    public Money balance() { return balance; }                   // Money is immutable: safe to return
    public List<Transaction> history() { return Collections.unmodifiableList(history); }   // read-only view

    public void deposit(Money amount, String memo) { apply(Transaction.Kind.DEPOSIT, amount, memo); }

    public void withdraw(Money amount, String memo) { apply(Transaction.Kind.WITHDRAWAL, amount, memo); }

    /** Moves money between accounts; either both sides happen or neither. */
    public void transferTo(Account other, Money amount) {
        if (other == this) throw new IllegalArgumentException("cannot transfer to the same account");
        Money after = checkedAfter(Transaction.Kind.TRANSFER_OUT, amount);        // validate everything first...
        other.checkedAfter(Transaction.Kind.TRANSFER_IN, amount);
        record(Transaction.Kind.TRANSFER_OUT, amount, after, "to " + other.id.value());   // ...then change state
        other.record(Transaction.Kind.TRANSFER_IN, amount, other.balance.plus(amount), "from " + id.value());
    }

    private void apply(Transaction.Kind kind, Money amount, String memo) {
        record(kind, amount, checkedAfter(kind, amount), memo);
    }

    private Money checkedAfter(Transaction.Kind kind, Money amount) {
        Objects.requireNonNull(amount, "amount");
        if (amount.cents() <= 0) throw new IllegalArgumentException("amount must be positive: " + amount);
        boolean outgoing = kind == Transaction.Kind.WITHDRAWAL || kind == Transaction.Kind.TRANSFER_OUT;
        Money after = outgoing ? balance.minus(amount) : balance.plus(amount);   // also checks the currency
        if (after.isNegative()) throw new IllegalStateException("insufficient funds in " + id.value() + ": balance " + balance + ", requested " + amount);
        return after;
    }

    private void record(Transaction.Kind kind, Money amount, Money after, String memo) {
        balance = after;
        history.add(new Transaction(history.size() + 1, clock.instant(), kind, amount, after, memo));
    }

    @Override public String toString() { return id.value() + " (" + owner + "): " + balance; }
}
