// file: bank/Main.java
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

public class Main {
    static void attempt(String what, Runnable action) {
        try {
            action.run();
            System.out.println("ok:       " + what);
        } catch (RuntimeException e) {
            System.out.println("rejected: " + what + " -> " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Clock fixed = Clock.fixed(Instant.parse("2026-11-15T09:00:00Z"), ZoneOffset.UTC);
        Account alice = new Account(new AccountId("AC-000001"), "Alice", "EUR", fixed);
        Account bob = new Account(new AccountId("AC-000098"), "Bob", "EUR", fixed);
        alice.deposit(Money.of("1000.00", "EUR"), "salary");
        alice.withdraw(Money.of("120.50", "EUR"), "rent share");
        alice.transferTo(bob, Money.of("300", "EUR"));

        attempt("withdraw more than the balance", () -> bob.withdraw(Money.of("300.01", "EUR"), "too much"));
        attempt("deposit a fraction of a cent", () -> alice.deposit(Money.of("0.005", "EUR"), "dust"));
        attempt("deposit in the wrong currency", () -> alice.deposit(Money.of("5", "USD"), "dollars"));
        attempt("deposit a negative amount", () -> alice.deposit(new Money(-500, "EUR"), "sneaky"));
        attempt("transfer exceeding funds", () -> bob.transferTo(alice, Money.of("1000", "EUR")));
        attempt("open account with bad check digit", () -> new AccountId("AC-000002"));
        attempt("modify history from outside", () -> alice.history().clear());

        System.out.println(alice + "\n" + bob);
        alice.history().forEach(t -> System.out.printf("  #%d %-12s %12s -> %12s  %s%n", t.sequence(), t.kind(), t.amount(), t.balanceAfter(), t.memo()));
        System.out.println("bob's failed transfer left both balances unchanged: " + bob.balance() + ", " + alice.balance());
    }
}
