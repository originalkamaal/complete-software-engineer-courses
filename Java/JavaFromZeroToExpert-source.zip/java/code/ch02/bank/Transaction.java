// file: bank/Transaction.java
import java.time.Instant;

/** One immutable entry in an account's history. */
public record Transaction(long sequence, Instant at, Kind kind, Money amount, Money balanceAfter, String memo) {
    public enum Kind { DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT }
}
