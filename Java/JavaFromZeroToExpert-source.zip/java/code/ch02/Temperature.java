// file: Temperature.java
import java.util.Objects;

/** A temperature reading. Invariant: kelvin >= 0, unit is not null. */
public final class Temperature {
    public enum Unit { CELSIUS, FAHRENHEIT, KELVIN }

    private final double kelvin;
    private final Unit preferred;

    private Temperature(double kelvin, Unit preferred) {
        if (Double.isNaN(kelvin) || kelvin < 0) {
            throw new IllegalArgumentException("below absolute zero: " + kelvin + " K");
        }
        this.kelvin = kelvin;
        this.preferred = Objects.requireNonNull(preferred, "unit");
    }

    public static Temperature of(double value, Unit unit) {              // a static factory with a clear name
        double k = switch (Objects.requireNonNull(unit, "unit")) {
            case KELVIN -> value;
            case CELSIUS -> value + 273.15;
            case FAHRENHEIT -> (value - 32) * 5 / 9 + 273.15;
        };
        return new Temperature(k, unit);
    }

    public double in(Unit unit) {
        return switch (unit) {
            case KELVIN -> kelvin;
            case CELSIUS -> kelvin - 273.15;
            case FAHRENHEIT -> (kelvin - 273.15) * 9 / 5 + 32;
        };
    }

    public Temperature plusKelvin(double delta) {                         // "modifiers" return new objects
        return new Temperature(kelvin + delta, preferred);
    }

    @Override
    public String toString() {
        return "%.2f %s".formatted(in(preferred), preferred);
    }

    public static void main(String[] args) {
        Temperature body = Temperature.of(98.6, Unit.FAHRENHEIT);
        System.out.println(body + " = " + "%.2f C".formatted(body.in(Unit.CELSIUS)) + ", warmer: " + body.plusKelvin(1.5));
        for (Object[] bad : new Object[][] {{-300.0, Unit.CELSIUS}, {20.0, null}}) {
            try {
                Temperature.of((Double) bad[0], (Unit) bad[1]);
            } catch (IllegalArgumentException | NullPointerException e) {
                System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }
}
