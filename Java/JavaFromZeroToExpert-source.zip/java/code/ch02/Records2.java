// file: Records2.java
import java.util.ArrayList;
import java.util.List;

public class Records2 {
    record Range(int lo, int hi) {
        Range {                                                   // compact constructor
            if (lo > hi) throw new IllegalArgumentException("lo > hi: " + lo + " > " + hi);
        }
        int length() { return hi - lo; }
        static Range of(int a, int b) { return new Range(Math.min(a, b), Math.max(a, b)); }
    }

    record Team(String name, List<String> members) {}            // shallow: shares the caller's list
    record SafeTeam(String name, List<String> members) {
        SafeTeam { members = List.copyOf(members); }              // defensive, unmodifiable copy
    }

    public static void main(String[] args) {
        System.out.println(Range.of(9, 2) + " length " + Range.of(9, 2).length());
        System.out.println("equal by value: " + new Range(1, 2).equals(new Range(1, 2)));
        try { new Range(5, 1); } catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }

        List<String> people = new ArrayList<>(List.of("ada"));
        Team t = new Team("core", people);
        SafeTeam s = new SafeTeam("core", people);
        people.add("mallory");                                    // changes the list after construction
        System.out.println("Team sees " + t.members() + ", SafeTeam sees " + s.members());
        try { s.members().add("x"); } catch (UnsupportedOperationException e) { System.out.println("SafeTeam list is unmodifiable"); }
    }
}
