// file: Enums2.java
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;

public class Enums2 {
    enum Op {
        ADD("+") { long apply(long a, long b) { return a + b; } },
        SUB("-") { long apply(long a, long b) { return a - b; } },
        MUL("*") { long apply(long a, long b) { return a * b; } };

        final String symbol;
        Op(String symbol) { this.symbol = symbol; }
        abstract long apply(long a, long b);                      // each constant implements it
    }

    enum Day { MON, TUE, WED, THU, FRI, SAT, SUN }

    public static void main(String[] args) {
        for (Op op : Op.values()) System.out.println("7 " + op.symbol + " 3 = " + op.apply(7, 3));
        System.out.println("valueOf(\"MUL\") = " + Op.valueOf("MUL") + ", ordinal " + Op.MUL.ordinal());

        EnumSet<Day> weekend = EnumSet.of(Day.SAT, Day.SUN);
        EnumSet<Day> weekdays = EnumSet.complementOf(weekend);
        System.out.println("weekdays " + weekdays + ", MON..WED " + EnumSet.range(Day.MON, Day.WED));
        Map<Day, Integer> hours = new EnumMap<>(Day.class);
        hours.put(Day.FRI, 6);
        hours.put(Day.MON, 8);
        System.out.println("EnumMap keeps declaration order: " + hours);
        try { Day.valueOf("Monday"); } catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
