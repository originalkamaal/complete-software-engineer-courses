// file: HashContract.java
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class HashContract {
    static class PointNoHash {                                         // equals without hashCode: broken
        final int x, y;
        PointNoHash(int x, int y) { this.x = x; this.y = y; }
        @Override public boolean equals(Object o) {
            return o instanceof PointNoHash p && p.x == x && p.y == y;
        }
    }

    static class MutablePoint {                                        // correct methods, but mutable
        int x, y;
        MutablePoint(int x, int y) { this.x = x; this.y = y; }
        @Override public boolean equals(Object o) {
            return o instanceof MutablePoint p && p.x == x && p.y == y;
        }
        @Override public int hashCode() { return Objects.hash(x, y); }
    }

    record Point(int x, int y) {}                                     // records do it right

    public static void main(String[] args) {
        Set<PointNoHash> s1 = new HashSet<>();
        s1.add(new PointNoHash(1, 2));
        System.out.println("no hashCode: contains equal point? " + s1.contains(new PointNoHash(1, 2))
                + ", equals says " + new PointNoHash(1, 2).equals(new PointNoHash(1, 2)));

        Set<MutablePoint> s2 = new HashSet<>();
        MutablePoint p = new MutablePoint(1, 2);
        s2.add(p);
        p.x = 99;                                                     // mutate a key inside the set
        System.out.println("mutated key: contains(p)? " + s2.contains(p) + ", size " + s2.size()
                + ", but iterating finds it: " + s2.iterator().next().equals(p));

        Set<Point> s3 = new HashSet<>();
        s3.add(new Point(1, 2));
        System.out.println("record: contains? " + s3.contains(new Point(1, 2)) + ", toString " + new Point(1, 2));
    }
}
