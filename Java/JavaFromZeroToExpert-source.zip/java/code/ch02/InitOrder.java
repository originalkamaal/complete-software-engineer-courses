// file: InitOrder.java
public class InitOrder {
    static int counter = 0;

    static class Widget {
        private final int id = ++counter;                       // 1. field initialisers, in order
        private String name;
        private int size = log("field initialiser for size", 10);

        {                                                       // 2. instance initialiser block
            log("instance initialiser block, name is " + name, 0);
        }

        Widget(String name) {                                   // 3. constructor body
            this(name, 0);                                      // delegate to the other constructor
            log("Widget(String) body", 0);
        }

        Widget(String name, int extra) {
            this.name = name;                                   // `this` disambiguates field from parameter
            this.size += extra;
            log("Widget(String, int) body, name is " + this.name, 0);
        }

        static int log(String what, int v) {
            System.out.println("  " + what);
            return v;
        }

        @Override
        public String toString() {
            return "Widget#" + id + "(" + name + ", size " + size + ")";
        }
    }

    public static void main(String[] args) {
        System.out.println("new Widget(\"knob\"):");
        Widget w = new Widget("knob");
        System.out.println(w + " and " + new Widget("dial", 5));
    }
}
