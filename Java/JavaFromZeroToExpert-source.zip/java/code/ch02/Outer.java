// file: Outer.java
public class Outer {
    private final byte[] bigBuffer = new byte[10_000_000];       // 10 MB owned by each Outer

    class Inner { int get() { return bigBuffer.length; } }       // holds Outer.this
    static class Nested { int get() { return 42; } }             // holds nothing

    public static void main(String[] args) {
        Inner i = new Outer().new Inner();                        // the Outer is otherwise unreachable...
        Nested n = new Nested();
        System.gc();
        System.out.println("inner still reaches the buffer: " + i.get() + " bytes; nested: " + n.get());
    }
}
