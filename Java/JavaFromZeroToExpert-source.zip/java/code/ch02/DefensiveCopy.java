// file: DefensiveCopy.java
import java.util.ArrayList;
import java.util.List;

public class DefensiveCopy {
    record Leaky(List<String> tags) {}                                  // stores the caller's list as-is

    record Safe(List<String> tags) {
        Safe {
            tags = List.copyOf(tags);                                   // compact constructor: copy on the way in
        }
    }

    public static void main(String[] args) {
        List<String> input = new ArrayList<>(List.of("a", "b"));
        Leaky leaky = new Leaky(input);
        Safe safe = new Safe(input);
        input.add("sneaky");                                            // the caller changes its list later
        System.out.println("leaky sees " + leaky.tags() + ", safe sees " + safe.tags());
        try {
            safe.tags().add("x");
        } catch (UnsupportedOperationException e) {
            System.out.println("safe.tags() is unmodifiable: " + e.getClass().getSimpleName());
        }
    }
}
