// file: Records.java
import java.util.Comparator;
import java.util.List;

public class Records {
    record Range(int lo, int hi) implements Comparable<Range> {
        Range {                                                  // compact constructor: checks before fields are set
            if (lo > hi) throw new IllegalArgumentException("lo > hi: " + lo + " > " + hi);
        }
        static Range of(int a, int b) { return new Range(Math.min(a, b), Math.max(a, b)); }
        int length() { return hi - lo; }
        boolean overlaps(Range o) { return lo < o.hi && o.lo < hi; }
        Range span(Range o) { return new Range(Math.min(lo, o.lo), Math.max(hi, o.hi)); }
        @Override public int compareTo(Range o) {
            return Comparator.comparingInt(Range::lo).thenComparingInt(Range::hi).compare(this, o);
        }
    }

    public static void main(String[] args) {
        var ranges = List.of(Range.of(9, 5), new Range(1, 3), new Range(2, 4), new Range(8, 10));
        System.out.println(ranges.stream().sorted().toList());
        System.out.println("(1,3) overlaps (2,4): " + ranges.get(1).overlaps(ranges.get(2))
                + ", span " + ranges.get(1).span(ranges.get(2)) + ", equal to new Range(1,3)? " + ranges.get(1).equals(new Range(1, 3)));
        try {
            new Range(5, 1);
        } catch (IllegalArgumentException e) {
            System.out.println("rejected: " + e.getMessage());
        }
    }
}
