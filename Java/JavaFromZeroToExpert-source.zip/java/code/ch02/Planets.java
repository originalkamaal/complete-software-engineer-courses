// file: Planets.java
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;

public class Planets {
    enum Planet {
        MERCURY(3.303e+23, 2.4397e6), EARTH(5.976e+24, 6.37814e6), JUPITER(1.9e+27, 7.1492e7);

        static final double G = 6.67300E-11;
        private final double mass, radius;

        Planet(double mass, double radius) {
            this.mass = mass;
            this.radius = radius;
        }
        double surfaceGravity() { return G * mass / (radius * radius); }
    }

    enum Op {
        ADD("+") { int apply(int a, int b) { return a + b; } },
        MUL("*") { int apply(int a, int b) { return a * b; } };
        final String symbol;
        Op(String symbol) { this.symbol = symbol; }
        abstract int apply(int a, int b);                     // each constant supplies its own body
    }

    public static void main(String[] args) {
        double earthWeight = 70;
        double mass = earthWeight / Planet.EARTH.surfaceGravity();
        Map<Planet, Double> weights = new EnumMap<>(Planet.class);
        for (Planet p : Planet.values()) {
            weights.put(p, mass * p.surfaceGravity());
        }
        weights.forEach((p, w) -> System.out.printf("%-8s %6.1f (ordinal %d)%n", p, w, p.ordinal()));
        for (Op op : Op.values()) {
            System.out.print("6 " + op.symbol + " 7 = " + op.apply(6, 7) + "; ");
        }
        System.out.println(EnumSet.complementOf(EnumSet.of(Planet.EARTH)) + " " + Planet.valueOf("JUPITER").name());
    }
}
