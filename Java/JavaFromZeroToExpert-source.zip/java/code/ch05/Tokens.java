// file: Tokens.java
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

public class Tokens {
    static <T> T create(Class<T> type) throws ReflectiveOperationException {
        return type.getDeclaredConstructor().newInstance();       // `new T()` is impossible; this works
    }

    static <T> List<T> onlyOfType(List<?> mixed, Class<T> type) {
        return mixed.stream().filter(type::isInstance).map(type::cast).toList();
    }

    /** A super type token: subclassing it records the full generic type. */
    abstract static class TypeRef<T> {
        final Type type;
        protected TypeRef() {
            this.type = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        }
    }

    public static void main(String[] args) throws Exception {
        StringBuilder sb = create(StringBuilder.class).append("made by reflection");
        System.out.println(sb);
        List<Object> mixed = List.of(1, "two", 3.0, "four", 5);
        System.out.println(onlyOfType(mixed, String.class) + " " + onlyOfType(mixed, Integer.class));
        Type t = new TypeRef<Map<String, List<Integer>>>() {}.type;   // note the {}: an anonymous subclass
        System.out.println("captured at run time: " + t.getTypeName());
    }
}
