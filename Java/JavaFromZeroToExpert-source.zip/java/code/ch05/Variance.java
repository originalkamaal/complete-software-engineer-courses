// file: Variance.java
import java.util.ArrayList;
import java.util.List;

public class Variance {
    static double sum(List<? extends Number> numbers) {          // a producer of Numbers
        double total = 0;
        for (Number n : numbers) total += n.doubleValue();
        // numbers.add(1);                                       // compile error: capture of ? extends Number
        return total;
    }

    static void fillWithSquares(List<? super Integer> sink, int n) {   // a consumer of Integers
        for (int i = 1; i <= n; i++) sink.add(i * i);
    }

    static <T> void copy(List<? super T> dst, List<? extends T> src) {  // the signature of Collections.copy
        dst.addAll(src);
    }

    public static void main(String[] args) {
        List<Integer> ints = List.of(1, 2, 3);
        List<Double> doubles = List.of(0.5, 1.5);
        System.out.println("sum(ints) = " + sum(ints) + ", sum(doubles) = " + sum(doubles));

        List<Number> numbers = new ArrayList<>();
        List<Object> objects = new ArrayList<>();
        fillWithSquares(numbers, 3);
        fillWithSquares(objects, 2);
        copy(objects, doubles);
        System.out.println("numbers " + numbers + ", objects " + objects);

        Object[] array = new Integer[2];                         // arrays ARE covariant...
        try {
            array[0] = "a string";                               // ...so this is checked at run time
        } catch (ArrayStoreException e) {
            System.out.println("ArrayStoreException: " + e.getMessage());
        }
    }
}
