// file: config/Key.java
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

/** A typed configuration key: name, parser, default, and validation. */
public final class Key<T> {
    private final String name;
    private final Function<String, ? extends T> parser;
    private final T defaultValue;
    private final Predicate<? super T> valid;
    private final String rule;

    private Key(String name, Function<String, ? extends T> parser, T defaultValue, Predicate<? super T> valid, String rule) {
        this.name = Objects.requireNonNull(name);
        this.parser = Objects.requireNonNull(parser);
        this.defaultValue = defaultValue;
        this.valid = valid;
        this.rule = rule;
    }

    public static <T> Key<T> of(String name, Function<String, ? extends T> parser, T defaultValue) {
        return new Key<>(name, parser, defaultValue, x -> true, "");
    }

    /** Returns a key with an extra validity rule; the predicate may accept any supertype of T (PECS). */
    public Key<T> requiring(Predicate<? super T> rule, String description) {
        Predicate<T> both = x -> valid.test(x) && rule.test(x);      // both accept a T
        return new Key<>(name, parser, defaultValue, both, description);
    }

    public String name() { return name; }
    T defaultValue() { return defaultValue; }

    T parse(String raw) {
        T value = parser.apply(raw.strip());
        if (!valid.test(value)) throw new IllegalArgumentException("must be " + rule);
        return value;
    }

    @Override public String toString() { return "Key(" + name + ")"; }
}
