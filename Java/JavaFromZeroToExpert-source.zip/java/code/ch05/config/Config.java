// file: config/Config.java
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A typesafe heterogeneous container of settings. */
public final class Config {
    private final Map<Key<?>, Object> values = new HashMap<>();   // the API guarantees value matches key type

    public record Problem(String key, String raw, String message) {}

    public static final class Builder {
        private final Map<String, Key<?>> known = new HashMap<>();
        Builder register(Key<?>... keys) {
            for (Key<?> k : keys) known.put(k.name(), k);
            return this;
        }
        Config load(Map<String, String> raw, List<Problem> problems) {
            Config c = new Config();
            raw.forEach((name, text) -> {
                Key<?> key = known.get(name);
                if (key == null) {
                    problems.add(new Problem(name, text, "unknown key"));
                    return;
                }
                try {
                    c.putParsed(key, text);
                } catch (RuntimeException e) {
                    problems.add(new Problem(name, text, e.getClass().getSimpleName() + ": " + e.getMessage()));
                }
            });
            return c;
        }
    }

    private <T> void putParsed(Key<T> key, String text) {        // a helper method captures the wildcard as T
        values.put(key, key.parse(text));
    }

    /** No cast needed by callers: the key's type parameter says what comes back. */
    public <T> T get(Key<T> key) {
        @SuppressWarnings("unchecked")                            // safe: only putParsed stores values, always as T
        T v = (T) values.get(key);
        return v != null ? v : key.defaultValue();
    }

    public Map<String, Object> snapshot(Key<?>... keys) {
        Map<String, Object> m = new java.util.TreeMap<>();
        for (Key<?> k : keys) m.put(k.name(), get(k));
        return Collections.unmodifiableMap(m);
    }

    static List<String> csv(String s) {
        List<String> out = new ArrayList<>();
        for (String part : s.split(",")) if (!part.isBlank()) out.add(part.strip());
        return List.copyOf(out);
    }
}
