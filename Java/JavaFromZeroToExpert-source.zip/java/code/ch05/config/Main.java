// file: config/Main.java
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    static final Key<Integer> PORT = Key.of("server.port", Integer::valueOf, 8080).requiring(p -> p >= 1 && p <= 65535, "in 1..65535");
    static final Key<Duration> TIMEOUT = Key.of("server.timeout", Duration::parse, Duration.ofSeconds(30))
            .requiring(d -> !d.isNegative() && !d.isZero(), "positive");
    static final Key<List<String>> HOSTS = Key.of("cluster.hosts", Config::csv, List.of("localhost"))
            .requiring(l -> !l.isEmpty(), "non-empty");
    static final Key<Boolean> DEBUG = Key.of("debug", Boolean::parseBoolean, false);
    static final Key<Number> RATIO = Key.<Number>of("cache.ratio", Double::valueOf, 0.5)       // a Key<Number> parsed as Double
            .requiring((Object o) -> o != null, "present");                                     // Predicate<Object> accepted: ? super T

    public static void main(String[] args) {
        Map<String, String> file = new LinkedHashMap<>();
        file.put("server.port", " 9443 ");
        file.put("server.timeout", "PT2.5S");
        file.put("cluster.hosts", "db1, db2,,db3");
        file.put("cache.ratio", "0.75");
        List<Config.Problem> problems = new ArrayList<>();
        Config ok = new Config.Builder().register(PORT, TIMEOUT, HOSTS, DEBUG, RATIO).load(file, problems);

        int port = ok.get(PORT);                                  // no casts anywhere at the call site
        Duration timeout = ok.get(TIMEOUT);
        List<String> hosts = ok.get(HOSTS);
        System.out.println("port " + port + ", timeout " + timeout.toMillis() + " ms, hosts " + hosts + ", debug " + ok.get(DEBUG)
                + ", ratio " + ok.get(RATIO) + " problems " + problems);
        System.out.println(ok.snapshot(PORT, TIMEOUT, HOSTS, DEBUG, RATIO));

        Map<String, String> bad = Map.of("server.port", "70000", "server.timeout", "5 seconds", "cluster.hosts", " , ", "colour", "blue");
        List<Config.Problem> errs = new ArrayList<>();
        Config c = new Config.Builder().register(PORT, TIMEOUT, HOSTS, DEBUG).load(bad, errs);
        errs.stream().sorted(java.util.Comparator.comparing(Config.Problem::key))
            .forEach(p -> System.out.println("  " + p.key() + " = '" + p.raw() + "': " + p.message()));
        System.out.println("defaults still apply where values were rejected: port " + c.get(PORT) + ", hosts " + c.get(HOSTS));
    }
}
