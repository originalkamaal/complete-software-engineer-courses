// file: GenericBasics.java
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class GenericBasics {
    /** An immutable pair. */
    record Pair<A, B>(A first, B second) {
        <C> Pair<A, C> withSecond(C c) { return new Pair<>(first, c); }
    }

    /** The largest element, for any type that can be compared with itself (or a supertype). */
    static <T extends Comparable<? super T>> Optional<T> max(Collection<? extends T> items) {
        T best = null;
        for (T x : items) {
            if (best == null || x.compareTo(best) > 0) best = x;
        }
        return Optional.ofNullable(best);
    }

    /** A growable stack backed by an ArrayList. */
    static class Stack<E> {
        private final List<E> items = new ArrayList<>();
        void push(E e) { items.add(e); }
        E pop() {
            if (items.isEmpty()) throw new IllegalStateException("empty stack");
            return items.remove(items.size() - 1);
        }
        boolean isEmpty() { return items.isEmpty(); }
    }

    public static void main(String[] args) {
        Pair<String, Integer> p = new Pair<>("age", 36);
        Pair<String, Double> q = p.withSecond(36.5);
        System.out.println(p + " " + q);
        System.out.println(max(List.of(3, 9, 4)) + " " + max(List.of("pear", "apple")) + " " + max(List.<Integer>of()));
        Stack<String> s = new Stack<>();
        for (String w : "generics are checked at compile time".split(" ")) s.push(w);
        StringBuilder sb = new StringBuilder();
        while (!s.isEmpty()) sb.append(s.pop()).append(' ');
        System.out.println(sb.toString().strip());
        // s.push(42);                       // compile error: incompatible types: int cannot be converted to String
    }
}
