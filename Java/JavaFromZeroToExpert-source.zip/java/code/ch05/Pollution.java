// file: Pollution.java
import java.util.ArrayList;
import java.util.List;

public class Pollution {
    @SuppressWarnings({"rawtypes", "unchecked"})
    static void legacyAdd(List list) { list.add(42); }       // old pre-generics code

    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("ada");
        legacyAdd(names);                                      // no error: the list now holds an Integer
        System.out.println("size " + names.size());
        try {
            for (String n : names) System.out.println(n.toUpperCase());
        } catch (ClassCastException e) {
            System.out.println("ClassCastException at the read, not at the add");
        }
    }
}
