// file: Bounded.java
import java.util.List;

public class Bounded {
    static <T extends Comparable<? super T>> T max(List<? extends T> xs) {
        if (xs.isEmpty()) throw new IllegalArgumentException("empty list");
        T best = xs.get(0);
        for (T x : xs) if (x.compareTo(best) > 0) best = x;
        return best;
    }

    static <K, V extends Number> double sumValues(java.util.Map<K, V> m) {
        double s = 0;
        for (V v : m.values()) s += v.doubleValue();         // Number's method is available
        return s;
    }

    public static void main(String[] args) {
        System.out.println(max(List.of(3, 9, 4)) + " " + max(List.of("pear", "apple", "zebra")));
        System.out.println(sumValues(java.util.Map.of("a", 1, "b", 2.5)));
        System.out.println(Bounded.<Integer>max(List.of(1, 2)));
        // max(List.of(new Object()));                        // error: Object is not Comparable
    }
}
