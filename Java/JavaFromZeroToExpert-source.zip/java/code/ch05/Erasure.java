// file: Erasure.java
import java.util.ArrayList;
import java.util.List;

public class Erasure {
    interface Shape extends Comparable<Shape> { double area(); }

    record Square(double side) implements Shape {
        public double area() { return side * side; }
        public int compareTo(Shape o) { return Double.compare(area(), o.area()); }   // erased signature differs
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void main(String[] args) throws Exception {
        List<String> strings = new ArrayList<>();
        List<Integer> ints = new ArrayList<>();
        System.out.println("same class at run time: " + (strings.getClass() == ints.getClass()) + " (" + strings.getClass().getName() + ")");

        List raw = strings;                     // a raw type: generics switched off
        raw.add(42);                            // compiles (with a warning): heap pollution
        System.out.println("list now: " + strings);
        try {
            String s = strings.get(0);          // the compiler-inserted cast fails HERE, far from the bug
            System.out.println(s);
        } catch (ClassCastException e) {
            System.out.println("ClassCastException at the read: " + e.getMessage());
        }

        for (var m : Square.class.getDeclaredMethods()) {
            if (m.getName().equals("compareTo")) {
                System.out.println("compareTo(" + m.getParameterTypes()[0].getSimpleName() + ")" + (m.isBridge() ? "  <- bridge method" : ""));
            }
        }
    }
}
