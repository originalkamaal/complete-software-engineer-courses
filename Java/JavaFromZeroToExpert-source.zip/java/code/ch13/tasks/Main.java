// file: tasks/Main.java
import com.sun.net.httpserver.HttpServer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;

public class Main {
    static HttpClient client = HttpClient.newHttpClient();
    static String base;
    static int passed = 0, failed = 0;

    static HttpResponse<String> call(String method, String path, String json) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path));
        if (json != null) b.header("Content-Type", "application/json");
        b.method(method, json == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(json));
        return client.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    static void check(String what, boolean ok) {
        if (ok) passed++; else { failed++; System.out.println("FAILED: " + what); }
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        // composition root: build the object graph by hand (this is what a DI container automates)
        Clock clock = Clock.fixed(Instant.parse("2026-11-15T12:00:00Z"), ZoneOffset.UTC);
        TaskRepository repository = new InMemoryTaskRepository(clock);
        TaskService service = new TaskService(repository);
        HttpServer server = new TaskApi(service).start(0);
        base = "http://127.0.0.1:" + server.getAddress().getPort();

        var r = call("POST", "/tasks", "{\"title\": \"write chapter 13\", \"priority\": 1}");
        System.out.println("POST /tasks -> " + r.statusCode() + " Location: " + r.headers().firstValue("location").orElse("?") + "\n  " + r.body());
        check("create returns 201", r.statusCode() == 201);
        call("POST", "/tasks", "{\"title\": \"review \\\"quotes\\\" and unicode \\u00e9\"}");
        call("POST", "/tasks", "{\"title\": \"ship it\", \"priority\": 5}");

        r = call("GET", "/tasks/2", null);
        System.out.println("GET /tasks/2 -> " + r.statusCode() + " " + r.body());
        check("title round-trips with escapes", ((Map<String, Object>) Json.parse(r.body())).get("title").equals("review \"quotes\" and unicode é"));

        r = call("PUT", "/tasks/1", "{\"title\": \"write chapter 13\", \"done\": true, \"version\": 1}");
        System.out.println("PUT /tasks/1 (version 1) -> " + r.statusCode() + " " + r.body());
        check("update returns 200 and bumps version", r.statusCode() == 200 && r.body().contains("\"version\":2"));
        r = call("PUT", "/tasks/1", "{\"title\": \"stale edit\", \"version\": 1}");
        System.out.println("PUT /tasks/1 (stale version 1) -> " + r.statusCode() + " " + r.body());
        check("stale update is a 409", r.statusCode() == 409);

        r = call("GET", "/tasks?done=false", null);
        check("filter by done", ((List<Object>) Json.parse(r.body())).size() == 2);
        System.out.println("GET /tasks?done=false -> " + ((List<Object>) Json.parse(r.body())).size() + " tasks");

        String[][] bad = {
            {"POST", "/tasks", "{\"title\": \"  \", \"priority\": 9}"}, {"POST", "/tasks", "{\"title\": \"x\""}, {"POST", "/tasks", "[1, 2]"},
            {"GET", "/tasks/999", null}, {"GET", "/tasks/abc", null}, {"PATCH", "/tasks/1", "{}"}, {"DELETE", "/tasks/3", null}, {"DELETE", "/tasks/3", null},
        };
        int[] expected = {400, 400, 400, 404, 404, 405, 204, 404};
        for (int i = 0; i < bad.length; i++) {
            r = call(bad[i][0], bad[i][1], bad[i][2]);
            System.out.printf("%-6s %-10s %-34s -> %d %s%n", bad[i][0], bad[i][1], bad[i][2] == null ? "" : bad[i][2], r.statusCode(), r.body());
            check(bad[i][0] + " " + bad[i][1] + " expected " + expected[i], r.statusCode() == expected[i]);
        }
        var noType = client.send(HttpRequest.newBuilder(URI.create(base + "/tasks")).POST(HttpRequest.BodyPublishers.ofString("{}")).build(), HttpResponse.BodyHandlers.ofString());
        check("missing content type rejected", noType.statusCode() == 400);
        String deep = "[".repeat(100) + "]".repeat(100);
        check("deeply nested JSON rejected, not a stack overflow", call("POST", "/tasks", deep).statusCode() == 400);

        server.stop(0);
        System.out.println(passed + " checks passed, " + failed + " failed");
    }
}
