// file: tasks/TaskApi.java
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Executors;

/** HTTP in, HTTP out. Translates requests to service calls and exceptions to status codes. */
public final class TaskApi {
    private final TaskService service;

    public TaskApi(TaskService service) { this.service = service; }

    public HttpServer start(int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), port), 0);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.createContext("/tasks", this::handle);
        server.start();
        return server;
    }

    private record Response(int status, Object body, String location) {}

    private void handle(HttpExchange ex) throws IOException {
        Response r;
        try {
            r = route(ex);
        } catch (TaskService.ValidationException e) {
            r = error(400, "validation_failed", e.getMessage(), e.problems);
        } catch (Json.ParseException e) {
            r = error(400, "malformed_json", e.getMessage(), List.of());
        } catch (TaskService.NotFoundException e) {
            r = error(404, "not_found", e.getMessage(), List.of());
        } catch (TaskService.ConflictException e) {
            r = error(409, "conflict", e.getMessage(), List.of());
        } catch (RuntimeException e) {                                       // a bug: log it, reveal nothing
            System.err.println("internal error: " + e);
            r = error(500, "internal_error", "unexpected error", List.of());
        }
        byte[] bytes = r.body() == null ? new byte[0] : Json.write(r.body()).getBytes(StandardCharsets.UTF_8);
        if (r.location() != null) ex.getResponseHeaders().add("Location", r.location());
        if (bytes.length > 0) ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(r.status(), bytes.length == 0 ? -1 : bytes.length);
        try (var os = ex.getResponseBody()) { os.write(bytes); }
    }

    private Response route(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        String path = ex.getRequestURI().getPath();
        if (path.equals("/tasks") || path.equals("/tasks/")) {
            return switch (method) {
                case "GET" -> {
                    String q = ex.getRequestURI().getQuery();
                    Optional<Boolean> done = q != null && q.startsWith("done=") ? Optional.of(Boolean.parseBoolean(q.substring(5))) : Optional.empty();
                    yield new Response(200, service.list(done).stream().map(Task::toJson).toList(), null);
                }
                case "POST" -> {
                    Task t = service.create(body(ex));
                    yield new Response(201, t.toJson(), "/tasks/" + t.id());
                }
                default -> error(405, "method_not_allowed", method + " is not supported on /tasks", List.of());
            };
        }
        long id;
        try {
            id = Long.parseLong(path.substring("/tasks/".length()));
        } catch (NumberFormatException e) {
            return error(404, "not_found", "no such resource: " + path, List.of());
        }
        return switch (method) {
            case "GET" -> new Response(200, service.get(id).toJson(), null);
            case "PUT" -> new Response(200, service.replace(id, body(ex)).toJson(), null);
            case "DELETE" -> { service.delete(id); yield new Response(204, null, null); }
            default -> error(405, "method_not_allowed", method + " is not supported on " + path, List.of());
        };
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> body(HttpExchange ex) throws IOException {
        String type = ex.getRequestHeaders().getFirst("Content-Type");
        if (type == null || !type.startsWith("application/json")) throw new TaskService.ValidationException(List.of("Content-Type: must be application/json"));
        byte[] raw = ex.getRequestBody().readNBytes(64 * 1024 + 1);          // bound the request size
        if (raw.length > 64 * 1024) throw new TaskService.ValidationException(List.of("body: larger than 64 KiB"));
        Object parsed = Json.parse(new String(raw, StandardCharsets.UTF_8));
        if (!(parsed instanceof Map)) throw new TaskService.ValidationException(List.of("body: must be a JSON object"));
        return (Map<String, Object>) parsed;
    }

    private static Response error(int status, String code, String message, List<String> details) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("error", code);
        m.put("message", message);
        if (!details.isEmpty()) m.put("details", details);
        return new Response(status, m, null);
    }
}
