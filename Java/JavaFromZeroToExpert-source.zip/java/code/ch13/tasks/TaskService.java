// file: tasks/TaskService.java
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Business rules. Knows nothing about HTTP or JSON syntax. */
public final class TaskService {
    public static final class ValidationException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        final transient List<String> problems;                 // never serialised; -Xlint:serial would object otherwise
        ValidationException(List<String> problems) { super("validation failed"); this.problems = List.copyOf(problems); }
    }
    public static final class NotFoundException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        NotFoundException(long id) { super("no task with id " + id); }
    }
    public static final class ConflictException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        ConflictException(String message) { super(message); }
    }

    private final TaskRepository repository;

    public TaskService(TaskRepository repository) { this.repository = repository; }

    public Task create(Map<String, Object> input) {
        List<String> problems = new ArrayList<>();
        String title = title(input, problems);
        int priority = priority(input, problems, 3);
        if (!problems.isEmpty()) throw new ValidationException(problems);
        return repository.insert(title, priority);
    }

    public Task get(long id) { return repository.find(id).orElseThrow(() -> new NotFoundException(id)); }

    public List<Task> list(Optional<Boolean> done) {
        return repository.findAll().stream().filter(t -> done.isEmpty() || t.done() == done.get()).toList();
    }

    public Task replace(long id, Map<String, Object> input) {
        Task current = get(id);
        List<String> problems = new ArrayList<>();
        String title = title(input, problems);
        int priority = priority(input, problems, current.priority());
        Object done = input.getOrDefault("done", current.done());
        if (!(done instanceof Boolean)) problems.add("done: must be true or false");
        Object version = input.get("version");
        if (!(version instanceof Long)) problems.add("version: required (the version you last read)");
        if (!problems.isEmpty()) throw new ValidationException(problems);
        if ((Long) version != current.version()) {
            throw new ConflictException("task " + id + " was modified: you sent version " + version + ", current is " + current.version());
        }
        Task updated = new Task(id, title, (Boolean) done, priority, current.createdAt(), current.version() + 1);
        if (!repository.update(current, updated)) throw new ConflictException("task " + id + " was modified concurrently");
        return updated;
    }

    public void delete(long id) {
        if (!repository.delete(id)) throw new NotFoundException(id);
    }

    private static String title(Map<String, Object> input, List<String> problems) {
        if (!(input.get("title") instanceof String s) || s.isBlank()) {
            problems.add("title: required, a non-blank string");
            return "";
        }
        if (s.length() > 100) problems.add("title: at most 100 characters");
        return s.strip();
    }

    private static int priority(Map<String, Object> input, List<String> problems, int defaultValue) {
        Object p = input.getOrDefault("priority", (long) defaultValue);
        if (p instanceof Long l && l >= 1 && l <= 5) return l.intValue();
        problems.add("priority: an integer from 1 to 5");
        return defaultValue;
    }
}
