// file: tasks/Task.java
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/** A task. `version` increases on every update (optimistic concurrency, Unit 12.5). */
public record Task(long id, String title, boolean done, int priority, Instant createdAt, int version) {
    Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("title", title);
        m.put("done", done);
        m.put("priority", priority);
        m.put("createdAt", createdAt.toString());
        m.put("version", version);
        return m;
    }
}
