// file: tasks/InMemoryTaskRepository.java
import java.time.Clock;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public final class InMemoryTaskRepository implements TaskRepository {
    private final Map<Long, Task> tasks = new ConcurrentHashMap<>();
    private final AtomicLong nextId = new AtomicLong(1);
    private final Clock clock;

    public InMemoryTaskRepository(Clock clock) { this.clock = clock; }

    @Override public Task insert(String title, int priority) {
        Task t = new Task(nextId.getAndIncrement(), title, false, priority, clock.instant(), 1);
        tasks.put(t.id(), t);
        return t;
    }
    @Override public Optional<Task> find(long id) { return Optional.ofNullable(tasks.get(id)); }
    @Override public List<Task> findAll() { return tasks.values().stream().sorted(Comparator.comparingLong(Task::id)).toList(); }
    @Override public boolean update(Task expected, Task replacement) { return tasks.replace(expected.id(), expected, replacement); }   // atomic compare-and-set
    @Override public boolean delete(long id) { return tasks.remove(id) != null; }
}
