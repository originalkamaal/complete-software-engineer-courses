// file: tasks/Json.java
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A minimal JSON reader/writer. Objects are Maps, arrays are Lists, numbers are Long or Double. */
public final class Json {
    private Json() {}

    public static final class ParseException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        ParseException(String message, int position) { super(message + " at position " + position); }
    }

    public static String write(Object value) {
        StringBuilder sb = new StringBuilder();
        write(value, sb);
        return sb.toString();
    }

    private static void write(Object v, StringBuilder sb) {
        switch (v) {
            case null -> sb.append("null");
            case String s -> writeString(s, sb);
            case Number n -> sb.append(n);
            case Boolean b -> sb.append(b);
            case Map<?, ?> m -> {
                sb.append('{');
                int i = 0;
                for (var e : m.entrySet()) {
                    if (i++ > 0) sb.append(',');
                    writeString(String.valueOf(e.getKey()), sb);
                    sb.append(':');
                    write(e.getValue(), sb);
                }
                sb.append('}');
            }
            case Iterable<?> it -> {
                sb.append('[');
                int i = 0;
                for (Object x : it) {
                    if (i++ > 0) sb.append(',');
                    write(x, sb);
                }
                sb.append(']');
            }
            default -> throw new IllegalArgumentException("cannot serialise " + v.getClass());
        }
    }

    private static void writeString(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> { if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
        sb.append('"');
    }

    public static Object parse(String text) {
        Parser p = new Parser(text);
        Object v = p.value();
        p.skipSpace();
        if (p.pos != text.length()) throw new ParseException("unexpected trailing characters", p.pos);
        return v;
    }

    private static final class Parser {
        final String s;
        int pos = 0;
        int depth = 0;
        Parser(String s) { this.s = s; }

        void skipSpace() { while (pos < s.length() && " \t\r\n".indexOf(s.charAt(pos)) >= 0) pos++; }

        char peek() {
            skipSpace();
            if (pos >= s.length()) throw new ParseException("unexpected end of input", pos);
            return s.charAt(pos);
        }

        void expect(char c) {
            if (peek() != c) throw new ParseException("expected '" + c + "'", pos);
            pos++;
        }

        Object value() {
            char c = peek();
            if (c == '{') return object();
            if (c == '[') return array();
            if (c == '"') return string();
            if (s.startsWith("true", pos)) { pos += 4; return Boolean.TRUE; }
            if (s.startsWith("false", pos)) { pos += 5; return Boolean.FALSE; }
            if (s.startsWith("null", pos)) { pos += 4; return null; }
            if (c == '-' || Character.isDigit(c)) return number();
            throw new ParseException("unexpected character '" + c + "'", pos);
        }

        Map<String, Object> object() {
            if (++depth > 64) throw new ParseException("nesting too deep", pos);       // a parser must bound recursion
            expect('{');
            Map<String, Object> m = new LinkedHashMap<>();
            if (peek() == '}') { pos++; depth--; return m; }
            do {
                if (peek() != '"') throw new ParseException("expected a string key", pos);
                String key = string();
                expect(':');
                m.put(key, value());
            } while (tryConsume(','));
            expect('}');
            depth--;
            return m;
        }

        List<Object> array() {
            if (++depth > 64) throw new ParseException("nesting too deep", pos);
            expect('[');
            List<Object> l = new ArrayList<>();
            if (peek() == ']') { pos++; depth--; return l; }
            do { l.add(value()); } while (tryConsume(','));
            expect(']');
            depth--;
            return l;
        }

        boolean tryConsume(char c) { if (peek() == c) { pos++; return true; } return false; }

        String string() {
            pos++;                                                                  // opening quote
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (pos >= s.length()) throw new ParseException("unterminated string", pos);
                char c = s.charAt(pos++);
                if (c == '"') return sb.toString();
                if (c != '\\') { sb.append(c); continue; }
                if (pos >= s.length()) throw new ParseException("unterminated escape", pos);
                char e = s.charAt(pos++);
                switch (e) {
                    case '"', '\\', '/' -> sb.append(e);
                    case 'n' -> sb.append('\n');
                    case 't' -> sb.append('\t');
                    case 'r' -> sb.append('\r');
                    case 'b' -> sb.append('\b');
                    case 'f' -> sb.append('\f');
                    case 'u' -> {
                        if (pos + 4 > s.length()) throw new ParseException("bad \\u escape", pos);
                        try { sb.append((char) Integer.parseInt(s.substring(pos, pos + 4), 16)); }
                        catch (NumberFormatException ex) { throw new ParseException("bad \\u escape", pos); }
                        pos += 4;
                    }
                    default -> throw new ParseException("bad escape \\" + e, pos - 1);
                }
            }
        }

        Number number() {
            int start = pos;
            if (s.charAt(pos) == '-') pos++;
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || ".eE+-".indexOf(s.charAt(pos)) >= 0)) pos++;
            String t = s.substring(start, pos);
            try {
                return t.matches("-?\\d{1,18}") ? (Number) Long.valueOf(t) : (Number) Double.valueOf(t);
            } catch (NumberFormatException e) {
                throw new ParseException("bad number '" + t + "'", start);
            }
        }
    }
}
