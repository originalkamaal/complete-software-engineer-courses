// file: tasks/TaskRepository.java
import java.util.List;
import java.util.Optional;

/** Storage for tasks. The service layer depends on this interface, not on an implementation. */
public interface TaskRepository {
    Task insert(String title, int priority);
    Optional<Task> find(long id);
    List<Task> findAll();
    /** Replaces the task if its stored version equals `expected.version()`. */
    boolean update(Task expected, Task replacement);
    boolean delete(long id);
}
