// file: PatternsDemo.java
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class PatternsDemo {
    // Strategy: behaviour passed as a function
    interface Pricing { long priceCents(long base, int quantity); }
    static final Pricing REGULAR = (base, q) -> base * q;
    static final Pricing BULK = (base, q) -> q >= 10 ? base * q * 90 / 100 : base * q;

    // Factory: a named static method chooses the implementation
    static Pricing pricingFor(String customerType) {
        return switch (customerType) {
            case "wholesale" -> BULK;
            case "retail" -> REGULAR;
            default -> throw new IllegalArgumentException("unknown customer type " + customerType);
        };
    }

    // Builder: readable construction of an object with many optional parts
    record HttpCall(String method, String url, Map<String, String> headers, Duration timeout, int retries) {
        static Builder to(String url) { return new Builder(url); }
        static final class Builder {
            private final String url;
            private String method = "GET";
            private final Map<String, String> headers = new java.util.TreeMap<>();
            private Duration timeout = Duration.ofSeconds(10);
            private int retries = 0;
            private Builder(String url) { this.url = url; }
            Builder method(String m) { this.method = m; return this; }
            Builder header(String k, String v) { headers.put(k, v); return this; }
            Builder timeout(Duration d) { this.timeout = d; return this; }
            Builder retries(int n) { this.retries = n; return this; }
            HttpCall build() {
                if (retries < 0) throw new IllegalStateException("retries must be >= 0");
                return new HttpCall(method, url, Map.copyOf(headers), timeout, retries);
            }
        }
    }

    // Decorator: wrap a function to add behaviour (caching, timing, retrying) without changing it
    static <K, V> Function<K, V> cached(Function<K, V> f) {
        Map<K, V> cache = new ConcurrentHashMap<>();
        return k -> cache.computeIfAbsent(k, f);
    }
    static <K, V> Function<K, V> counted(Function<K, V> f, int[] calls) {
        return k -> { calls[0]++; return f.apply(k); };
    }

    // Observer: subscribers are Consumers
    static final class EventBus<E> {
        private final List<Consumer<? super E>> subscribers = new ArrayList<>();
        Runnable subscribe(Consumer<? super E> s) { subscribers.add(s); return () -> subscribers.remove(s); }   // returns "unsubscribe"
        void publish(E event) { subscribers.forEach(s -> s.accept(event)); }
    }

    // Template method as a higher-order function: the fixed skeleton takes the varying step
    static <T> T timed(String label, Supplier<T> step) {
        long t = System.nanoTime();
        try {
            return step.get();
        } finally {
            System.out.println("  [" + label + " took " + (System.nanoTime() - t) / 1_000_000 + " ms]");
        }
    }

    static long slowLookup(String key) {
        try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return key.length() * 100L;
    }

    public static void main(String[] args) {
        System.out.println("strategy + factory: retail " + pricingFor("retail").priceCents(250, 12) + ", wholesale " + pricingFor("wholesale").priceCents(250, 12));
        System.out.println("builder: " + HttpCall.to("https://example.org/api").method("POST").header("Accept", "application/json").retries(2).build());
        int[] calls = {0};
        Function<String, Long> lookup = cached(counted(PatternsDemo::slowLookup, calls));
        long total = timed("three lookups, two of them cached", () -> lookup.apply("alpha") + lookup.apply("alpha") + lookup.apply("alpha"));
        System.out.println("decorator: total " + total + ", underlying function called " + calls[0] + " time(s)");
        EventBus<String> bus = new EventBus<>();
        List<String> audit = new ArrayList<>();
        Runnable unsubscribe = bus.subscribe(audit::add);
        bus.subscribe(e -> System.out.println("  observer got: " + e));
        bus.publish("order-created");
        unsubscribe.run();
        bus.publish("order-shipped");
        System.out.println("observer: audit saw " + audit);
    }
}
