// file: Serial.java
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InvalidClassException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Serial {
    static class Range implements Serializable {
        private static final long serialVersionUID = 1L;
        final int lo, hi;
        transient int cachedLength;                                   // transient: not serialized
        Range(int lo, int hi) {
            if (lo > hi) throw new IllegalArgumentException("lo > hi");   // the invariant
            this.lo = lo;
            this.hi = hi;
            this.cachedLength = hi - lo;
        }
        @Override public String toString() { return "Range[" + lo + ".." + hi + ", cachedLength=" + cachedLength + "]"; }
    }

    static byte[] serialize(Object o) throws Exception {
        var bytes = new ByteArrayOutputStream();
        try (var out = new ObjectOutputStream(bytes)) {
            out.writeObject(o);
        }
        return bytes.toByteArray();
    }

    public static void main(String[] args) throws Exception {
        byte[] data = serialize(new Range(1, 5));
        System.out.println(data.length + " bytes for two ints");
        try (var in = new ObjectInputStream(new ByteArrayInputStream(data))) {
            System.out.println("round trip: " + in.readObject() + "   (transient field lost: the constructor did not run)");
        }
        // an attacker edits the bytes. The last 8 bytes are the int fields, in alphabetical order: hi, then lo.
        byte[] forged = data.clone();
        forged[forged.length - 1] = 9;                                 // lo = 9, hi stays 5
        try (var in = new ObjectInputStream(new ByteArrayInputStream(forged))) {
            System.out.println("forged:     " + in.readObject() + "   (invariant lo <= hi bypassed)");
        }
        try (var in = new ObjectInputStream(new ByteArrayInputStream(data))) {
            in.setObjectInputFilter(ObjectInputFilter.Config.createFilter("java.base/*;!*"));   // allow only JDK core classes
            in.readObject();
        } catch (InvalidClassException e) {
            System.out.println("with an allow-list filter: " + e.getMessage());
        }
    }
}
