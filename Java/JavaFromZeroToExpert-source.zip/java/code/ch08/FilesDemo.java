// file: FilesDemo.java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class FilesDemo {
    public static void main(String[] args) throws IOException {
        Path root = Path.of("demo-tree");
        Files.createDirectories(root.resolve("src/main"));
        Files.createDirectories(root.resolve("docs"));
        Files.writeString(root.resolve("src/main/App.java"), "class App {}\n");
        Files.writeString(root.resolve("src/main/Util.java"), "class Util {}\n// helper\n");
        Files.write(root.resolve("docs/notes.txt"), List.of("first line", "second line"));
        Files.writeString(root.resolve("docs/notes.txt"), "appended\n", StandardOpenOption.APPEND);

        try (Stream<Path> walk = Files.walk(root)) {                           // close the stream: it holds directory handles
            walk.filter(Files::isRegularFile).sorted().forEach(p -> {
                try {
                    System.out.printf("%-34s %3d bytes%n", root.relativize(p), Files.size(p));
                } catch (IOException e) {
                    throw new java.io.UncheckedIOException(e);
                }
            });
        }
        try (Stream<String> lines = Files.lines(root.resolve("docs/notes.txt"))) {
            System.out.println("lines containing 'line': " + lines.filter(l -> l.contains("line")).count());
        }
        Path p = root.resolve("src/main/../main/./App.java");
        System.out.println("normalize: " + p.normalize() + ", file name: " + p.getFileName() + ", parent: " + p.normalize().getParent());
        Files.move(root.resolve("docs/notes.txt"), root.resolve("docs/NOTES.md"), StandardCopyOption.ATOMIC_MOVE);
        try {
            Files.delete(root.resolve("docs/notes.txt"));
        } catch (NoSuchFileException e) {
            System.out.println("Files.delete explains failures: NoSuchFileException " + e.getMessage()
                    + "  (java.io.File.delete() just returns " + new java.io.File("demo-tree/docs/notes.txt").delete() + ")");
        }
        try (Stream<Path> walk = Files.walk(root)) {                           // delete a tree: children before parents
            walk.sorted(Comparator.reverseOrder()).forEach(q -> q.toFile().delete());
        }
        System.out.println("tree removed: " + !Files.exists(root));
    }
}
