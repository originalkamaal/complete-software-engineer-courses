// file: evlog/EventLog.java
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.zip.CRC32;

/**
 * File:   magic "EVLG" (4) | version u16 | reserved u16
 * Record: timestampMillis i64 | sensor u16 | kind u8 | payloadLen u8 | value f64 | payload bytes | crc32 u32
 * All integers big-endian. The CRC covers the record from the timestamp to the end of the payload.
 */
public class EventLog {
    static final int MAGIC = 0x45564C47, HEADER = 8, FIXED = 8 + 2 + 1 + 1 + 8;
    public record Event(long timestamp, int sensor, int kind, double value, String note) {}

    static final class Writer implements AutoCloseable {
        private final FileChannel ch;
        private final ByteBuffer buf = ByteBuffer.allocate(1 << 16);
        private final CRC32 crc = new CRC32();

        Writer(Path path) throws IOException {
            ch = FileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            buf.putInt(MAGIC).putShort((short) 1).putShort((short) 0);
        }

        void append(Event e) throws IOException {
            byte[] note = e.note().getBytes(StandardCharsets.UTF_8);
            if (note.length > 255) throw new IllegalArgumentException("note too long");
            if (buf.remaining() < FIXED + note.length + 4) flush();
            int start = buf.position();
            buf.putLong(e.timestamp()).putShort((short) e.sensor()).put((byte) e.kind()).put((byte) note.length).putDouble(e.value()).put(note);
            crc.reset();
            crc.update(buf.array(), start, buf.position() - start);
            buf.putInt((int) crc.getValue());
        }

        void flush() throws IOException {
            buf.flip();                                              // DT-21
            while (buf.hasRemaining()) ch.write(buf);
            buf.clear();
        }

        @Override public void close() throws IOException {
            flush();
            ch.force(true);                                          // durable before close
            ch.close();
        }
    }

    static final class Reader implements AutoCloseable {
        private final FileChannel ch;
        final TreeMap<Long, Long> index = new TreeMap<>();           // timestamp -> file offset, every 1024th record
        long validRecords, validBytes;
        String stopReason = "end of file";

        Reader(Path path) throws IOException {
            ch = FileChannel.open(path, StandardOpenOption.READ);
            ByteBuffer h = ByteBuffer.allocate(HEADER);
            ch.read(h, 0);
            h.flip();
            if (h.remaining() < HEADER || h.getInt() != MAGIC) throw new IOException("not an event log: bad magic");
            int version = h.getShort();
            if (version != 1) throw new IOException("unsupported version " + version);
            scan();
        }

        /** One pass over the file: validates every record and builds the sparse index. */
        private void scan() throws IOException {
            long pos = HEADER, size = ch.size();
            ByteBuffer b = ByteBuffer.allocate(FIXED + 255 + 4);
            CRC32 crc = new CRC32();
            while (pos < size) {
                b.clear();
                ch.read(b, pos);
                b.flip();
                if (b.remaining() < FIXED) { stopReason = "truncated record header at offset " + pos; break; }
                int len = b.get(11) & 0xFF;
                int total = FIXED + len + 4;
                if (b.remaining() < total) { stopReason = "truncated record at offset " + pos; break; }
                crc.reset();
                crc.update(b.array(), 0, FIXED + len);
                if ((int) crc.getValue() != b.getInt(FIXED + len)) { stopReason = "checksum mismatch at offset " + pos; break; }
                if (validRecords % 1024 == 0) index.put(b.getLong(0), pos);
                validRecords++;
                pos += total;
            }
            validBytes = pos;
        }

        private Event readAt(long pos, ByteBuffer b) throws IOException {
            b.clear();
            ch.read(b, pos);
            b.flip();
            long ts = b.getLong();
            int sensor = b.getShort() & 0xFFFF, kind = b.get() & 0xFF, len = b.get() & 0xFF;
            double value = b.getDouble();
            String note = new String(b.array(), FIXED, len, StandardCharsets.UTF_8);
            return new Event(ts, sensor, kind, value, note);
        }

        /** Events with from <= timestamp < to, found by seeking to the nearest indexed offset. */
        List<Event> range(long from, long to) throws IOException {
            List<Event> out = new ArrayList<>();
            var floor = index.floorEntry(from);
            long pos = floor == null ? HEADER : floor.getValue();
            ByteBuffer b = ByteBuffer.allocate(FIXED + 255 + 4);
            while (pos < validBytes) {
                Event e = readAt(pos, b);
                if (e.timestamp() >= to) break;
                if (e.timestamp() >= from) out.add(e);
                pos += FIXED + e.note().getBytes(StandardCharsets.UTF_8).length + 4;
            }
            return out;
        }

        @Override public void close() throws IOException { ch.close(); }
    }

    public static void main(String[] args) throws IOException {
        Path bin = Path.of("events.evl"), csv = Path.of("events.csv");
        int n = 1_000_000;
        java.util.Random r = new java.util.Random(11);
        String[] notes = {"", "", "", "ok", "retry", "sensor warmed up", "calibration drift détecté"};
        long t0 = 1_780_000_000_000L;

        long t = System.nanoTime();
        try (Writer w = new Writer(bin)) {
            for (int i = 0; i < n; i++) w.append(new Event(t0 + i * 250L, r.nextInt(500), r.nextInt(4), 20 + r.nextGaussian() * 3, notes[r.nextInt(notes.length)]));
        }
        long binWrite = (System.nanoTime() - t) / 1_000_000;
        r = new java.util.Random(11);
        t = System.nanoTime();
        try (BufferedWriter w = Files.newBufferedWriter(csv)) {
            for (int i = 0; i < n; i++) {
                w.write((t0 + i * 250L) + "," + r.nextInt(500) + "," + r.nextInt(4) + "," + (20 + r.nextGaussian() * 3) + "," + notes[r.nextInt(notes.length)] + "\n");
            }
        }
        long csvWrite = (System.nanoTime() - t) / 1_000_000;
        System.out.printf("wrote %,d events: binary %,d bytes in %d ms; CSV %,d bytes in %d ms%n", n, Files.size(bin), binWrite, Files.size(csv), csvWrite);

        t = System.nanoTime();
        try (Reader rd = new Reader(bin)) {
            long scan = (System.nanoTime() - t) / 1_000_000;
            long from = t0 + 600_000L * 250, to = from + 2_000;                 // a 2-second window deep in the file
            t = System.nanoTime();
            List<Event> hits = rd.range(from, to);
            long query = (System.nanoTime() - t) / 1_000;
            System.out.printf("scan + CRC check of %,d records: %d ms; index entries: %d; range query: %d events in %d µs%n",
                    rd.validRecords, scan, rd.index.size(), hits.size(), query);
            System.out.println("first hit: " + hits.get(0));
        }
        t = System.nanoTime();
        long from = t0 + 600_000L * 250, to = from + 2_000;
        long csvHits;
        try (var lines = Files.lines(csv)) {
            csvHits = lines.filter(l -> { long ts = Long.parseLong(l, 0, l.indexOf(','), 10); return ts >= from && ts < to; }).count();
        }
        System.out.printf("same query on CSV (full scan): %d events in %d ms%n", csvHits, (System.nanoTime() - t) / 1_000_000);

        // damage the file: truncate mid-record, then flip one bit
        long size = Files.size(bin);
        try (FileChannel ch = FileChannel.open(bin, StandardOpenOption.WRITE)) {
            ch.truncate(size - 7);
        }
        try (Reader rd = new Reader(bin)) {
            System.out.printf("after truncating 7 bytes: %,d valid records, stopped: %s%n", rd.validRecords, rd.stopReason);
        }
        try (FileChannel ch = FileChannel.open(bin, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            ByteBuffer one = ByteBuffer.allocate(1);
            ch.read(one, 5_000_000);
            one.flip();
            one.put(0, (byte) (one.get(0) ^ 0x10));
            ch.write(one, 5_000_000);
        }
        try (Reader rd = new Reader(bin)) {
            System.out.printf("after flipping one bit at offset 5,000,000: %,d valid records, stopped: %s%n", rd.validRecords, rd.stopReason);
        }
        Files.writeString(Path.of("fake.evl"), "this is not a log");
        try (Reader rd = new Reader(Path.of("fake.evl"))) {
            System.out.println("?");
        } catch (IOException e) {
            System.out.println("wrong file: " + e.getMessage());
        }
    }
}
