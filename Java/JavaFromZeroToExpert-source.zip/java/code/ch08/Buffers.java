// file: Buffers.java
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.HexFormat;

public class Buffers {
    static String state(ByteBuffer b) { return "position=" + b.position() + " limit=" + b.limit() + " capacity=" + b.capacity(); }

    public static void main(String[] args) throws IOException {
        ByteBuffer buf = ByteBuffer.allocate(16);
        System.out.println("new:        " + state(buf));
        buf.putInt(0xCAFEBABE).putShort((short) 258).put((byte) 7);
        System.out.println("after puts: " + state(buf));
        buf.flip();                                                    // switch from writing to reading
        System.out.println("after flip: " + state(buf) + "  bytes: " + HexFormat.ofDelimiter(" ").formatHex(buf.array(), 0, buf.limit()));
        System.out.printf("read back: %x %d %d, remaining %d%n", buf.getInt(), buf.getShort(), buf.get(), buf.remaining());
        ByteBuffer le = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(0xCAFEBABE);
        System.out.println("same int little-endian: " + HexFormat.ofDelimiter(" ").formatHex(le.array()) + "  (native order here: " + ByteOrder.nativeOrder() + ")");

        Path file = Path.of("mapped.bin");
        try (FileChannel ch = FileChannel.open(file, StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            MappedByteBuffer map = ch.map(FileChannel.MapMode.READ_WRITE, 0, 8L * 1_000_000);   // 8 MB of longs
            for (int i = 0; i < 1_000_000; i++) map.putLong(i * 8, (long) i * i);
            map.force();                                               // flush dirty pages to the file
            ByteBuffer one = ByteBuffer.allocate(8);
            ch.read(one, 8L * 999);                                    // positional read through the channel
            System.out.println("file size " + ch.size() + " bytes; the 999th long read via the channel = " + one.flip().getLong()
                    + ", via the mapping = " + map.getLong(8 * 999));
        }
    }
}
