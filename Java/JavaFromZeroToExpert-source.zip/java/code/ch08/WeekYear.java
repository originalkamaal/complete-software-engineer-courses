// file: WeekYear.java
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class WeekYear {
    public static void main(String[] args) {
        LocalDate d = LocalDate.of(2025, 12, 29);
        for (String p : new String[] {"yyyy-MM-dd", "YYYY-MM-dd", "uuuu-MM-dd", "yyyy-MM-DD"}) {
            System.out.println(p + " -> " + DateTimeFormatter.ofPattern(p, Locale.ROOT).format(d));
        }
    }
}
