// file: Buffering.java
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class Buffering {
    static long writeBytes(OutputStream out, int n) throws IOException {
        long t = System.nanoTime();
        try (out) {
            for (int i = 0; i < n; i++) out.write(i);                  // one byte at a time
        }
        return (System.nanoTime() - t) / 1_000_000;
    }

    public static void main(String[] args) throws IOException {
        int n = 2_000_000;
        long raw = writeBytes(new FileOutputStream("raw.bin"), n);
        long buffered = writeBytes(new BufferedOutputStream(new FileOutputStream("buf.bin")), n);
        System.out.printf("%,d single-byte writes: unbuffered %d ms, buffered %d ms (%.0fx); files identical: %b%n", n, raw, buffered,
                (double) raw / Math.max(1, buffered), Files.mismatch(Path.of("raw.bin"), Path.of("buf.bin")) == -1);
    }
}
