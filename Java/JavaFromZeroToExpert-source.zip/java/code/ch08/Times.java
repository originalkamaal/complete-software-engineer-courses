// file: Times.java
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;

public class Times {
    public static void main(String[] args) {
        LocalDate d = LocalDate.of(2024, 1, 31);
        System.out.println("Jan 31 + 1 month = " + d.plusMonths(1) + " (clamped to the month's end)");
        System.out.println("2024 is a leap year: " + d.isLeapYear() + ", day of week " + d.getDayOfWeek());
        System.out.println("last day of Feb 2025: " + LocalDate.of(2025, 2, 1).with(TemporalAdjusters.lastDayOfMonth()));
        Period age = Period.between(LocalDate.of(1990, 8, 15), LocalDate.of(2026, 11, 16));
        System.out.println("age: " + age.getYears() + " years " + age.getMonths() + " months " + age.getDays() + " days");
        System.out.println("days between: " + ChronoUnit.DAYS.between(LocalDate.of(2026, 1, 1), LocalDate.of(2026, 11, 16)));

        ZoneId india = ZoneId.of("Asia/Kolkata"), berlin = ZoneId.of("Europe/Berlin");
        ZonedDateTime meeting = ZonedDateTime.of(2026, 3, 29, 14, 0, 0, 0, india);
        System.out.println("meeting in India: " + meeting);
        System.out.println("same instant in Berlin: " + meeting.withZoneSameInstant(berlin));
        Instant i = meeting.toInstant();
        System.out.println("as an Instant (UTC): " + i + ", epoch seconds " + i.getEpochSecond());

        ZonedDateTime beforeDst = ZonedDateTime.of(2026, 3, 29, 1, 30, 0, 0, berlin);   // clocks jump 02:00 -> 03:00
        System.out.println("Berlin 01:30 + 1 hour (Duration) = " + beforeDst.plus(Duration.ofHours(1)).toLocalTime()
                           + ", + 1 day (Period) = " + beforeDst.plusDays(1).toLocalTime());
        System.out.println("Berlin 02:30 does not exist; of() gives " + ZonedDateTime.of(2026, 3, 29, 2, 30, 0, 0, berlin).toLocalTime());

        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd MMM uuuu, HH:mm");
        System.out.println(f.format(meeting) + " | parsed back: " + LocalDateTime.parse("16 Nov 2026, 09:05", f));
        System.out.println("ISO: " + LocalDate.parse("2026-11-16").atStartOfDay());
    }
}
