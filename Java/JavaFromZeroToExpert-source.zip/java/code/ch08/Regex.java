// file: Regex.java
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
    private static final Pattern LOG = Pattern.compile(
        "(?<date>\\d{4}-\\d{2}-\\d{2}) (?<level>ERROR|WARN|INFO) \\[(?<thread>[^\\]]+)] (?<msg>.*)");
    private static final Pattern EMAIL = Pattern.compile("[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+");

    public static void main(String[] args) {
        List<String> lines = List.of(
            "2026-11-16 ERROR [worker-3] disk full on /var",
            "garbage line",
            "2026-11-16 INFO [main] started in 412 ms");
        for (String line : lines) {
            Matcher m = LOG.matcher(line);
            if (m.matches()) {
                System.out.printf("%-5s %-8s %s%n", m.group("level"), m.group("thread"), m.group("msg"));
            } else {
                System.out.println("no match: " + line);
            }
        }

        String text = "write to ada@example.org or b.smith+java@mail.co.in today";
        Matcher m = EMAIL.matcher(text);
        while (m.find()) System.out.println("found " + m.group() + " at " + m.start() + "-" + m.end());
        System.out.println(EMAIL.matcher(text).replaceAll("<hidden>"));
        System.out.println(EMAIL.matcher(text).replaceAll(r -> r.group().replaceAll("(?<=.).(?=[^@]*@)", "*")));

        System.out.println("2026-11-16".replaceAll("(\\d+)-(\\d+)-(\\d+)", "$3/$2/$1"));
        System.out.println(List.of("a1b22c333".split("\\d+")));
        System.out.println("case-insensitive: " + Pattern.compile("^java", Pattern.CASE_INSENSITIVE).matcher("JAVA 21").find());
        System.out.println("literal dot: " + "a.b".matches("a\\.b") + ", any char: " + "axb".matches("a.b")
                           + ", Pattern.quote: " + "a.b".split(Pattern.quote(".")).length);
    }
}
