// file: Redos.java
import java.util.regex.Pattern;

public class Redos {
    static String time(Pattern p, String input) {
        long t0 = System.nanoTime();
        boolean found = p.matcher(input).find();
        long ms = (System.nanoTime() - t0) / 1_000_000;
        return (found ? "match" : "no match") + (ms < 20 ? " (under 20 ms)" : " (" + (ms < 200 ? "tens" : ms < 2000 ? "hundreds" : "thousands") + " of ms)");
    }
    public static void main(String[] args) {
        Pattern textbook = Pattern.compile("(a+)+$");
        Pattern backref = Pattern.compile("^((a+)+)\\2$");          // "some a's, then the same group again"
        for (int n = 18; n <= 27; n += 3) {
            String input = "a".repeat(n) + "!";                    // almost matches
            System.out.printf("n=%d: (a+)+$ %s; ^((a+)+)\\2$ %s%n", n, time(textbook, input), time(backref, input));
        }
    }
}
