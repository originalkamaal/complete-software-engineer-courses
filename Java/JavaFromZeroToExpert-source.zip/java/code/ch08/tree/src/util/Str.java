class Str {}
