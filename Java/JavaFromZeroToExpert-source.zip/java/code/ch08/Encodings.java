// file: Encodings.java
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;

public class Encodings {
    public static void main(String[] args) {
        String text = "naïve €5 🦀";
        byte[] utf8 = text.getBytes(StandardCharsets.UTF_8);
        byte[] utf16 = text.getBytes(StandardCharsets.UTF_16BE);
        byte[] latin1 = text.getBytes(StandardCharsets.ISO_8859_1);          // cannot represent € or 🦀
        System.out.println(text.length() + " chars -> UTF-8 " + utf8.length + " bytes, UTF-16 " + utf16.length + " bytes, Latin-1 " + latin1.length + " bytes");
        System.out.println("UTF-8 hex:  " + HexFormat.ofDelimiter(" ").formatHex(utf8));
        System.out.println("Latin-1 round trip: " + new String(latin1, StandardCharsets.ISO_8859_1) + "   (unmappable characters became '?')");
        System.out.println("UTF-8 bytes read as Latin-1: " + new String(utf8, StandardCharsets.ISO_8859_1).replaceAll("\\p{Cntrl}", "·"));
        System.out.println("default charset: " + java.nio.charset.Charset.defaultCharset());
    }
}
