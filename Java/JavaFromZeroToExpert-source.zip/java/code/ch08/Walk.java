// file: Walk.java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Walk {
    public static void main(String[] args) throws IOException {
        Path root = Files.createDirectories(Path.of("tree/src/util"));
        Files.writeString(root.resolve("Str.java"), "class Str {}\n");
        Files.writeString(Path.of("tree/src/Main.java"), "class Main {\n}\n");
        Files.writeString(Path.of("tree/README.md"), "# demo\nline 2\nline 3\n");

        try (Stream<Path> all = Files.walk(Path.of("tree"))) {
            Map<String, Long> byExt = all.filter(Files::isRegularFile)
                .collect(Collectors.groupingBy(p -> { String n = p.getFileName().toString(); return n.substring(n.lastIndexOf('.') + 1); },
                                               TreeMap::new, Collectors.counting()));
            System.out.println("files by extension: " + byExt);
        }
        try (Stream<String> lines = Files.lines(Path.of("tree/README.md"))) {
            System.out.println("README lines: " + lines.count());
        }
        try (Stream<Path> javaFiles = Files.find(Path.of("tree"), 10, (p, attr) -> attr.isRegularFile() && p.toString().endsWith(".java"))) {
            System.out.println("java files: " + javaFiles.map(p -> p.getFileName().toString()).sorted().toList());
        }
        System.out.println("relativize: " + Path.of("tree").relativize(Path.of("tree/src/util/Str.java"))
                           + ", normalize: " + Path.of("tree/src/../README.md").normalize());
    }
}
