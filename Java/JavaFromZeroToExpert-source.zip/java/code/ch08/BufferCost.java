// file: BufferCost.java
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class BufferCost {
    static long timeMs(boolean buffered) throws IOException {
        long t0 = System.nanoTime();
        try (OutputStream raw = new FileOutputStream("bytes.bin");
             OutputStream out = buffered ? new BufferedOutputStream(raw) : raw) {
            for (int i = 0; i < 1_000_000; i++) out.write(i);
        }
        return (System.nanoTime() - t0) / 1_000_000;
    }
    public static void main(String[] args) throws IOException {
        long unbuffered = timeMs(false), buffered = timeMs(true);
        System.out.println("1,000,000 single-byte writes: buffered is " + (unbuffered > 5 * buffered ? "more than 5x" : "less than 5x") + " faster");
        System.err.println("unbuffered " + unbuffered + " ms, buffered " + buffered + " ms");
    }
}
