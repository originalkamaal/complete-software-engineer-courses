// file: Decoding.java
import java.nio.charset.Charset;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class Decoding {
    public static void main(String[] args) throws Exception {
        System.out.println("default charset: " + Charset.defaultCharset());
        byte[] bad = {'c', 'a', 'f', (byte) 0xE9};                 // "café" in Latin-1, invalid as UTF-8
        System.out.println("new String(.., UTF_8): " + new String(bad, StandardCharsets.UTF_8).replace('�', '?')
                           + " (bad byte replaced)");
        System.out.println("new String(.., ISO_8859_1): " + new String(bad, StandardCharsets.ISO_8859_1));
        Path p = Files.write(Path.of("latin1.txt"), bad);
        try {
            Files.readString(p);                                    // strict: refuses invalid UTF-8
        } catch (MalformedInputException e) {
            System.out.println("Files.readString: MalformedInputException, input length " + e.getInputLength());
        }
        System.out.println("Files.readString(p, ISO_8859_1): " + Files.readString(p, StandardCharsets.ISO_8859_1));
    }
}
