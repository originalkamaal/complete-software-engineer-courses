// file: SerialFilter.java
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SerialFilter {
    record Point(int x, int y) implements Serializable {}

    static byte[] serialise(Object o) throws IOException {
        var bos = new ByteArrayOutputStream();
        try (var out = new ObjectOutputStream(bos)) { out.writeObject(o); }
        return bos.toByteArray();
    }

    static Object read(byte[] data) throws IOException, ClassNotFoundException {
        try (var in = new ObjectInputStream(new ByteArrayInputStream(data))) {
            in.setObjectInputFilter(ObjectInputFilter.Config.createFilter("SerialFilter$Point;java.lang.*;!*"));
            return in.readObject();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("allowed: " + read(serialise(new Point(1, 2))));
        try {
            read(serialise(new ArrayList<>(List.of(1))));          // not on the allow-list
        } catch (InvalidClassException e) {
            System.out.println("rejected: " + e.getMessage());
        }
    }
}
