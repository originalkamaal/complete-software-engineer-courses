// file: linkd/Main.java
import java.io.PrintStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

public class Main {
    /** The assembled application. */
    record App(Api api, int port, LinkRepository repository, HitCounter hits, ConnectionPool pool, Metrics metrics, Cache<String, Optional<String>> cache, PrintStream log)
            implements AutoCloseable {
        /** Graceful shutdown, in dependency order (R6). */
        @Override public void close() throws java.sql.SQLException {
            api.stop(2);                 // 1. stop accepting, let in-flight requests finish
            hits.close();                // 2. flush pending hit counts
            repository.shutdownDatabase();   // 3. database writes its files
            pool.close();                // 4. release connections
            if (log != null) log.close();
        }
    }

    static App start(String dbUrl, int port, int cacheCapacity, double ratePerSecond, Path accessLog) throws Exception {
        Metrics metrics = new Metrics();
        ConnectionPool pool = new ConnectionPool(dbUrl, 8, 1000);
        LinkRepository repository = new LinkRepository(pool);
        Cache<String, Optional<String>> cache = new Cache<>(cacheCapacity, System::nanoTime);
        HitCounter hits = new HitCounter(repository, 200);
        LinkService service = new LinkService(repository, cache, hits, Clock.systemUTC(), metrics);
        RateLimiter limiter = new RateLimiter(ratePerSecond, ratePerSecond, System::nanoTime);
        PrintStream log = accessLog == null ? null : new PrintStream(Files.newOutputStream(accessLog), false, "UTF-8");
        Api api = new Api(service, limiter, metrics, log);
        metrics.gauge("linkd_cache_hits_total", cache.hits::sum);
        metrics.gauge("linkd_cache_misses_total", cache.misses::sum);
        metrics.gauge("linkd_cache_size", cache::size);
        metrics.gauge("linkd_pool_idle_connections", pool::idleCount);
        metrics.gauge("linkd_pool_waits_total", pool.waits::sum);
        metrics.gauge("linkd_hits_flushed_total", hits.flushedHits::sum);
        return new App(api, api.start(port), repository, hits, pool, metrics, cache, log);
    }

    static final HttpClient CLIENT = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).connectTimeout(Duration.ofSeconds(2)).build();

    static HttpResponse<String> call(int port, String method, String path, String json, String clientId) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path)).timeout(Duration.ofSeconds(5)).header("X-Client-Id", clientId);
        if (json != null) b.header("Content-Type", "application/json");
        b.method(method, json == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(json));
        return CLIENT.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    @SuppressWarnings("unchecked")
    static String field(String json, String name) { return String.valueOf(((Map<String, Object>) Json.parse(json)).get(name)); }

    static int checks = 0, failures = 0;
    static void check(String what, boolean ok) {
        checks++;
        if (!ok) { failures++; System.out.println("  FAILED: " + what); }
    }

    static void selftest(String dbUrl) throws Exception {
        String code;
        try (App app = start(dbUrl, 0, 1000, 50, Path.of("access.log"))) {
            int port = app.port();
            var created = call(port, "POST", "/links", "{\"url\": \"https://example.org/a/long/path?q=1\"}", "tester");
            code = field(created.body(), "code");
            System.out.println("POST /links -> " + created.statusCode() + " " + created.body());
            check("create is 201 with a Location", created.statusCode() == 201 && created.headers().firstValue("location").orElse("").equals("/links/" + code));
            var redirect = call(port, "GET", "/r/" + code, null, "tester");
            System.out.println("GET /r/" + code + " -> " + redirect.statusCode() + " Location: " + redirect.headers().firstValue("location").orElse("?"));
            check("redirect is 302 to the stored URL", redirect.statusCode() == 302 && redirect.headers().firstValue("location").orElse("").equals("https://example.org/a/long/path?q=1"));
            for (int i = 0; i < 9; i++) call(port, "GET", "/r/" + code, null, "tester");
            check("hits are visible at once (pending included)", field(call(port, "GET", "/links/" + code, null, "tester").body(), "hits").equals("10"));
            check("only the first lookup could miss the cache; create() primed it", app.metrics().counter("linkd_db_lookups_total") == 0);
            check("unknown code is 404", call(port, "GET", "/r/zzzzzz", null, "tester").statusCode() == 404);
            for (String bad : List.of("{\"url\": \"javascript:alert(1)\"}", "{\"url\": \"/relative\"}", "{\"url\": \"\"}", "{\"nope\": 1}", "{not json", "{\"url\": \"http://x.org/" + "a".repeat(2100) + "\"}")) {
                check("rejected: " + bad.substring(0, Math.min(30, bad.length())), call(port, "POST", "/links", bad, "tester").statusCode() == 400);
            }
            check("oversized body is 413", call(port, "POST", "/links", "{\"url\": \"http://x.org/" + "a".repeat(9000) + "\"}", "tester").statusCode() == 413);
            check("wrong method is 405", call(port, "DELETE", "/links", null, "tester").statusCode() == 405);

            int limited = 0;
            String retryAfter = "";
            for (int i = 0; i < 120; i++) {                                    // a greedy client: bucket of 50, refilled at 50/s
                var r = call(port, "GET", "/r/" + code, null, "greedy");
                if (r.statusCode() == 429) { limited++; retryAfter = r.headers().firstValue("retry-after").orElse(""); }
            }
            System.out.println("greedy client: " + (120 - limited) + " of 120 allowed, " + limited + " rejected with 429, Retry-After: " + retryAfter);
            check("rate limiter rejected a greedy client", limited > 5 && !retryAfter.isEmpty());
            check("other clients are unaffected", call(port, "GET", "/r/" + code, null, "polite").statusCode() == 302);
            check("health is up", call(port, "GET", "/health", null, "tester").body().contains("up"));
            String metrics = call(port, "GET", "/metrics", null, "tester").body();
            System.out.println("a few lines of /metrics:");
            metrics.lines().filter(l -> l.contains("/r/{code}") || l.startsWith("linkd_cache_hits") || l.contains("le=\"1.0\"") || l.contains("_count")).forEach(l -> System.out.println("  " + l));
        }                                                                      // graceful shutdown: flush hits, close database
        System.out.println("access log: " + Files.readAllLines(Path.of("access.log")).size() + " lines; first: " + Files.readAllLines(Path.of("access.log")).get(0));

        try (App app = start(dbUrl, 0, 1000, 50, null)) {                       // restart on the same database files
            var details = call(app.port(), "GET", "/links/" + code, null, "tester");
            System.out.println("after restart: GET /links/" + code + " -> " + details.body());
            check("link and all hits survived the restart", details.statusCode() == 200 && Long.parseLong(field(details.body(), "hits")) >= 11);
            check("redirect works after restart (one database lookup, then cached)", call(app.port(), "GET", "/r/" + code, null, "tester").statusCode() == 302
                    && call(app.port(), "GET", "/r/" + code, null, "tester").statusCode() == 302 && app.metrics().counter("linkd_db_lookups_total") == 1);
        }
        System.out.println(checks + " checks, " + failures + " failed");
    }

    static void load(int cacheCapacity, int links, int requests, int concurrency) throws Exception {
        try (App app = start("jdbc:hsqldb:mem:load" + cacheCapacity, 0, cacheCapacity, 1e9, null)) {
            int port = app.port();
            List<String> codes = new ArrayList<>();
            for (int i = 0; i < links; i++) codes.add(field(call(port, "POST", "/links", "{\"url\": \"https://example.org/page/" + i + "\"}", "loader").body(), "code"));
            long lookupsBefore = app.metrics().counter("linkd_db_lookups_total");
            AtomicInteger next = new AtomicInteger();
            LongAdder ok = new LongAdder(), notFound = new LongAdder(), other = new LongAdder();
            long[] latencies = new long[requests];
            long t0 = System.nanoTime();
            try (var pool = Executors.newVirtualThreadPerTaskExecutor()) {
                for (int w = 0; w < concurrency; w++) {
                    pool.submit(() -> {
                        java.util.Random rnd = new java.util.Random(Thread.currentThread().threadId());
                        for (int i; (i = next.getAndIncrement()) < requests; ) {
                            // 80% of requests go to the most popular 5% of links; 2% ask for codes that do not exist
                            String code = rnd.nextInt(100) < 2 ? "nope" + rnd.nextInt(50) : codes.get(rnd.nextInt(100) < 80 ? rnd.nextInt(Math.max(1, links / 20)) : rnd.nextInt(links));
                            long t = System.nanoTime();
                            int status = call(port, "GET", "/r/" + code, null, "loader").statusCode();
                            latencies[i] = System.nanoTime() - t;
                            (status == 302 ? ok : status == 404 ? notFound : other).increment();
                        }
                        return null;
                    });
                }
            }
            double seconds = (System.nanoTime() - t0) / 1e9;
            java.util.Arrays.sort(latencies);
            app.hits().flush();
            long counted = 0;
            for (String c : codes) counted += Long.parseLong(field(call(port, "GET", "/links/" + c, null, "loader").body(), "hits"));
            System.out.printf("cache capacity %5d: %,d requests in %.1f s = %,.0f req/s; latency p50 %.2f ms, p99 %.2f ms, max %.1f ms%n", cacheCapacity, requests, seconds,
                    requests / seconds, latencies[requests / 2] / 1e6, latencies[(int) (requests * 0.99)] / 1e6, latencies[requests - 1] / 1e6);
            System.out.printf("  302: %d, 404: %d, other: %d; database lookups for redirects: %,d; cache hit ratio %.1f%%; pool waits %d; hits counted in database: %d (= 302s: %b)%n",
                    ok.sum(), notFound.sum(), other.sum(), app.metrics().counter("linkd_db_lookups_total") - lookupsBefore,
                    100.0 * app.cache().hits.sum() / Math.max(1, app.cache().hits.sum() + app.cache().misses.sum()), app.pool().waits.sum(), counted, counted == ok.sum());
        }
    }

    public static void main(String[] args) throws Exception {
        switch (args.length > 0 ? args[0] : "") {
            case "selftest" -> selftest("jdbc:hsqldb:file:data/linkd;hsqldb.tx=mvcc");
            case "load" -> {
                load(0, 2000, 30_000, 64);
                load(5000, 2000, 30_000, 64);
            }
            case "serve" -> {
                App app = start("jdbc:hsqldb:file:data/linkd;hsqldb.tx=mvcc", 8080, 10_000, 20, Path.of("access.log"));
                Runtime.getRuntime().addShutdownHook(new Thread(() -> {       // SIGTERM / Ctrl-C: shut down gracefully
                    try { app.close(); } catch (Exception e) { System.err.println("shutdown: " + e); }
                }));
                System.out.println("linkd listening on http://127.0.0.1:" + app.port());
                Thread.currentThread().join();
            }
            default -> System.out.println("usage: Main serve | selftest | load");
        }
    }
}
