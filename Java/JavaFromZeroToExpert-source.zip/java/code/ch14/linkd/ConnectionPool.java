// file: linkd/ConnectionPool.java
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.LongAdder;

/** A fixed-size JDBC connection pool. Borrowers wait, up to a timeout, when all connections are in use. */
public final class ConnectionPool implements AutoCloseable {
    public interface Work<T> { T run(Connection c) throws SQLException; }

    private final BlockingQueue<Connection> idle;
    private final int size;
    private final long timeoutMillis;
    final LongAdder borrows = new LongAdder(), waits = new LongAdder(), timeouts = new LongAdder();

    public ConnectionPool(String url, int size, long timeoutMillis) throws SQLException {
        this.size = size;
        this.timeoutMillis = timeoutMillis;
        this.idle = new ArrayBlockingQueue<>(size);
        for (int i = 0; i < size; i++) idle.add(DriverManager.getConnection(url, "SA", ""));
    }

    /** Runs `work` with a pooled connection and always returns the connection, rolled back to a clean state on failure. */
    public <T> T with(Work<T> work) throws SQLException {
        Connection c = idle.poll();
        if (c == null) {
            waits.increment();
            try {
                c = idle.poll(timeoutMillis, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new SQLException("interrupted while waiting for a connection");
            }
            if (c == null) {
                timeouts.increment();
                throw new SQLException("no database connection available within " + timeoutMillis + " ms");
            }
        }
        borrows.increment();
        try {
            return work.run(c);
        } catch (SQLException | RuntimeException e) {
            try {
                if (!c.getAutoCommit()) { c.rollback(); c.setAutoCommit(true); }      // DT-33: never return a dirty connection
            } catch (SQLException cleanup) {
                e.addSuppressed(cleanup);
            }
            throw e;
        } finally {
            idle.add(c);
        }
    }

    public int idleCount() { return idle.size(); }
    public int size() { return size; }

    @Override public void close() throws SQLException {
        for (int i = 0; i < size; i++) {
            Connection c = idle.poll();
            if (c != null) c.close();
        }
    }
}
