// file: linkd/HitCounter.java
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

/** Counts hits in memory; a background thread writes them to the database in batches (write-behind). */
public final class HitCounter implements AutoCloseable {
    private final ConcurrentHashMap<String, LongAdder> pending = new ConcurrentHashMap<>();
    private final LinkRepository repository;
    private final Thread flusher;
    private volatile boolean running = true;
    final LongAdder flushes = new LongAdder(), flushedHits = new LongAdder(), flushFailures = new LongAdder();

    public HitCounter(LinkRepository repository, long intervalMillis) {
        this.repository = repository;
        this.flusher = Thread.ofPlatform().name("hit-flusher").daemon(true).start(() -> {
            while (running) {
                try {
                    Thread.sleep(intervalMillis);
                } catch (InterruptedException e) {
                    break;                                                      // close() interrupts to stop promptly
                }
                flush();
            }
        });
    }

    public void record(String code) {
        pending.computeIfAbsent(code, k -> new LongAdder()).increment();        // no lock, no I/O on the request path
    }

    /** Hits recorded but not yet in the database, for one code. */
    public long pendingFor(String code) {
        LongAdder a = pending.get(code);
        return a == null ? 0 : a.sum();
    }

    public synchronized void flush() {
        Map<String, Long> batch = new HashMap<>();
        pending.forEach((code, adder) -> {
            long n = adder.sumThenReset();
            if (n > 0) batch.put(code, n);
        });
        if (batch.isEmpty()) return;
        try {
            repository.addHits(batch);
            flushes.increment();
            flushedHits.add(batch.values().stream().mapToLong(Long::longValue).sum());
        } catch (java.sql.SQLException e) {
            flushFailures.increment();
            batch.forEach((code, n) -> pending.computeIfAbsent(code, k -> new LongAdder()).add(n));   // put them back: retry next time
        }
    }

    @Override public void close() {
        running = false;
        flusher.interrupt();
        try { flusher.join(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        flush();                                                                // the final flush on shutdown
    }
}
