// file: linkd/Metrics.java
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.LongSupplier;

/** Counters, gauges, and one latency histogram, rendered in the Prometheus text format. */
public final class Metrics {
    private static final double[] BUCKETS_MS = {0.25, 0.5, 1, 2.5, 5, 10, 25, 50, 100, 250, 1000};
    private final ConcurrentHashMap<String, LongAdder> counters = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, LongSupplier> gauges = new ConcurrentHashMap<>();
    private final LongAdder[] latency = new LongAdder[BUCKETS_MS.length + 1];
    private final LongAdder latencySumMicros = new LongAdder();

    public Metrics() { for (int i = 0; i < latency.length; i++) latency[i] = new LongAdder(); }

    public void count(String name) { counters.computeIfAbsent(name, k -> new LongAdder()).increment(); }
    public void gauge(String name, LongSupplier value) { gauges.put(name, value); }
    public long counter(String name) { LongAdder a = counters.get(name); return a == null ? 0 : a.sum(); }

    public void observeLatency(long nanos) {
        double ms = nanos / 1e6;
        int i = 0;
        while (i < BUCKETS_MS.length && ms > BUCKETS_MS[i]) i++;
        latency[i].increment();
        latencySumMicros.add(nanos / 1000);
    }

    /** An upper bound for the given quantile, from the histogram buckets. */
    public double latencyQuantileMs(double q) {
        long total = 0;
        for (LongAdder a : latency) total += a.sum();
        long target = (long) Math.ceil(total * q), seen = 0;
        for (int i = 0; i < latency.length; i++) {
            seen += latency[i].sum();
            if (seen >= target) return i < BUCKETS_MS.length ? BUCKETS_MS[i] : Double.POSITIVE_INFINITY;
        }
        return 0;
    }

    public String render() {
        StringBuilder sb = new StringBuilder();
        new TreeMap<>(counters).forEach((k, v) -> sb.append(k).append(' ').append(v.sum()).append('\n'));
        for (Map.Entry<String, LongSupplier> g : new TreeMap<>(gauges).entrySet()) sb.append(g.getKey()).append(' ').append(g.getValue().getAsLong()).append('\n');
        long cumulative = 0;
        for (int i = 0; i < BUCKETS_MS.length; i++) {
            cumulative += latency[i].sum();
            sb.append("http_request_duration_ms_bucket{le=\"").append(BUCKETS_MS[i]).append("\"} ").append(cumulative).append('\n');
        }
        cumulative += latency[BUCKETS_MS.length].sum();
        sb.append("http_request_duration_ms_bucket{le=\"+Inf\"} ").append(cumulative).append('\n');
        sb.append("http_request_duration_ms_count ").append(cumulative).append('\n');
        sb.append("http_request_duration_ms_sum ").append(latencySumMicros.sum() / 1000.0).append('\n');
        return sb.toString();
    }
}
