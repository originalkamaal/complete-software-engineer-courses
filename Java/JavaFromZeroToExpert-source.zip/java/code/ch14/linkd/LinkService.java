// file: linkd/LinkService.java
import java.net.URI;
import java.sql.SQLException;
import java.time.Clock;
import java.util.Optional;

/** Business logic: validation, code generation, cached resolution. */
public final class LinkService {
    public static final class InvalidUrlException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        InvalidUrlException(String message) { super(message); }
    }

    private static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final long SPACE = 62L * 62 * 62 * 62 * 62 * 62;             // 6 characters: about 56.8 billion codes
    private static final long LINK_TTL = 60_000_000_000L, NEGATIVE_TTL = 2_000_000_000L;

    private final LinkRepository repository;
    private final Cache<String, Optional<String>> cache;                        // code -> url, or empty for "no such code"
    private final HitCounter hits;
    private final Clock clock;
    private final Metrics metrics;

    public LinkService(LinkRepository repository, Cache<String, Optional<String>> cache, HitCounter hits, Clock clock, Metrics metrics) {
        this.repository = repository;
        this.cache = cache;
        this.hits = hits;
        this.clock = clock;
        this.metrics = metrics;
    }

    /** Maps a sequence number to a 6-character code. Multiplying by a number coprime to SPACE is a bijection, so codes never collide. */
    static String codeFor(long id) {
        long n = Math.floorMod(id * 31_337_317L, SPACE);
        char[] out = new char[6];
        for (int i = 5; i >= 0; i--) { out[i] = ALPHABET.charAt((int) (n % 62)); n /= 62; }
        return new String(out);
    }

    public LinkRepository.Link create(String url) throws SQLException {
        if (url == null || url.isBlank()) throw new InvalidUrlException("url: required");
        if (url.length() > 2000) throw new InvalidUrlException("url: longer than 2000 characters");
        URI uri;
        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException e) {
            throw new InvalidUrlException("url: not a valid URI");
        }
        if (uri.getScheme() == null || !(uri.getScheme().equals("http") || uri.getScheme().equals("https")) || uri.getHost() == null) {
            throw new InvalidUrlException("url: must be an absolute http or https URL");      // no javascript:, file:, or relative URLs
        }
        LinkRepository.Link link = repository.insert(url, clock.instant(), LinkService::codeFor);
        cache.put(link.code(), Optional.of(url), LINK_TTL);
        return link;
    }

    /** The redirect path: cache first; on a miss, one database read; then count the hit in memory. */
    public Optional<String> resolve(String code) throws SQLException {
        Optional<Optional<String>> cached = cache.get(code);
        Optional<String> url;
        if (cached.isPresent()) {
            url = cached.get();
        } else {
            metrics.count("linkd_db_lookups_total");
            url = repository.findByCode(code).map(LinkRepository.Link::url);
            cache.put(code, url, url.isPresent() ? LINK_TTL : NEGATIVE_TTL);
        }
        if (url.isPresent()) hits.record(code);
        return url;
    }

    /** Link details; the hit count includes hits not yet flushed to the database. */
    public Optional<LinkRepository.Link> details(String code) throws SQLException {
        return repository.findByCode(code).map(l -> new LinkRepository.Link(l.id(), l.code(), l.url(), l.createdAt(), l.hits() + hits.pendingFor(code)));
    }
}
