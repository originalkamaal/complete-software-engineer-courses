// file: linkd/Api.java
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class Api {
    private final LinkService service;
    private final RateLimiter limiter;
    private final Metrics metrics;
    private final PrintStream accessLog;
    private final AtomicBoolean healthy = new AtomicBoolean(true);
    private HttpServer server;

    public Api(LinkService service, RateLimiter limiter, Metrics metrics, PrintStream accessLog) {
        this.service = service;
        this.limiter = limiter;
        this.metrics = metrics;
        this.accessLog = accessLog;
    }

    public int start(int port) throws IOException {
        server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), port), 1024);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.createContext("/", this::handle);
        server.start();
        return server.getAddress().getPort();
    }

    /** Stops accepting connections and waits up to `seconds` for in-flight requests. */
    public void stop(int seconds) {
        healthy.set(false);
        server.stop(seconds);
    }

    private record Response(int status, String contentType, byte[] body, Map<String, String> headers) {
        static Response json(int status, Object value) { return new Response(status, "application/json", Json.write(value).getBytes(StandardCharsets.UTF_8), Map.of()); }
        static Response error(int status, String code, String message) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("error", code);
            m.put("message", message);
            return json(status, m);
        }
    }

    private void handle(HttpExchange ex) throws IOException {
        long start = System.nanoTime();
        String method = ex.getRequestMethod(), path = ex.getRequestURI().getPath();
        String route = path.startsWith("/r/") ? "/r/{code}" : path.startsWith("/links/") ? "/links/{code}" : path;
        String client = Optional.ofNullable(ex.getRequestHeaders().getFirst("X-Client-Id")).orElse(ex.getRemoteAddress().getAddress().getHostAddress());
        Response r;
        try {
            long waitMs = route.equals("/metrics") || route.equals("/health") ? 0 : limiter.tryAcquire(client);
            if (waitMs > 0) {
                r = new Response(429, "application/json", Json.write(Map.of("error", "rate_limited", "message", "too many requests")).getBytes(StandardCharsets.UTF_8),
                        Map.of("Retry-After", String.valueOf(Math.max(1, (waitMs + 999) / 1000))));
            } else {
                r = route(method, path, route, ex);
            }
        } catch (LinkService.InvalidUrlException | Json.ParseException e) {
            r = Response.error(400, "bad_request", e.getMessage());
        } catch (SQLException e) {                                            // database unavailable or pool exhausted
            metrics.count("linkd_db_errors_total");
            r = new Response(503, "application/json", Json.write(Map.of("error", "unavailable", "message", "try again shortly")).getBytes(StandardCharsets.UTF_8),
                    Map.of("Retry-After", "1"));
        } catch (RuntimeException e) {
            System.err.println("internal error on " + method + " " + path + ": " + e);
            r = Response.error(500, "internal_error", "unexpected error");
        }
        r.headers().forEach((k, v) -> ex.getResponseHeaders().add(k, v));
        if (r.body().length > 0) ex.getResponseHeaders().add("Content-Type", r.contentType());
        ex.sendResponseHeaders(r.status(), r.body().length == 0 ? -1 : r.body().length);
        try (var os = ex.getResponseBody()) { os.write(r.body()); }
        long nanos = System.nanoTime() - start;
        metrics.count("http_requests_total{route=\"" + route + "\",status=\"" + r.status() + "\"}");
        metrics.observeLatency(nanos);
        if (accessLog != null) {                                              // one JSON object per line: easy to ship and query
            Map<String, Object> line = new LinkedHashMap<>();
            line.put("method", method);
            line.put("path", path);
            line.put("status", r.status());
            line.put("micros", nanos / 1000);
            line.put("client", client);
            accessLog.println(Json.write(line));
        }
    }

    @SuppressWarnings("unchecked")
    private Response route(String method, String path, String route, HttpExchange ex) throws IOException, SQLException {
        switch (route) {
            case "/health":
                return healthy.get() ? Response.json(200, Map.of("status", "up")) : Response.json(503, Map.of("status", "shutting down"));
            case "/metrics":
                return new Response(200, "text/plain; version=0.0.4", metrics.render().getBytes(StandardCharsets.UTF_8), Map.of());
            case "/links": {
                if (!method.equals("POST")) return Response.error(405, "method_not_allowed", method + " not supported");
                byte[] raw = ex.getRequestBody().readNBytes(8 * 1024 + 1);
                if (raw.length > 8 * 1024) return Response.error(413, "too_large", "body larger than 8 KiB");
                Object parsed = Json.parse(new String(raw, StandardCharsets.UTF_8));
                if (!(parsed instanceof Map<?, ?> m) || !(m.get("url") instanceof String url)) return Response.error(400, "bad_request", "expected {\"url\": \"...\"}");
                LinkRepository.Link link = service.create(url);
                Map<String, Object> body = new LinkedHashMap<>();
                body.put("code", link.code());
                body.put("url", link.url());
                body.put("short", "/r/" + link.code());
                return new Response(201, "application/json", Json.write(body).getBytes(StandardCharsets.UTF_8), Map.of("Location", "/links/" + link.code()));
            }
            case "/r/{code}": {
                if (!method.equals("GET") && !method.equals("HEAD")) return Response.error(405, "method_not_allowed", method + " not supported");
                Optional<String> url = service.resolve(path.substring(3));
                if (url.isEmpty()) return Response.error(404, "not_found", "no such link");
                return new Response(302, "", new byte[0], Map.of("Location", url.get(), "Cache-Control", "private, max-age=0"));
            }
            case "/links/{code}": {
                Optional<LinkRepository.Link> link = service.details(path.substring(7));
                if (link.isEmpty()) return Response.error(404, "not_found", "no such link");
                Map<String, Object> body = new LinkedHashMap<>();
                body.put("code", link.get().code());
                body.put("url", link.get().url());
                body.put("createdAt", link.get().createdAt().toString());
                body.put("hits", link.get().hits());
                return Response.json(200, body);
            }
            default:
                return Response.error(404, "not_found", "no such resource");
        }
    }
}
