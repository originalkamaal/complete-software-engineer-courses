// file: linkd/Cache.java
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.LongSupplier;

/** A thread-safe LRU cache with per-entry expiry. Capacity 0 disables it. */
public final class Cache<K, V> {
    private record Entry<V>(V value, long expiresAtNanos) {}

    private final int capacity;
    private final LongSupplier nanoClock;
    private final LinkedHashMap<K, Entry<V>> map;
    final LongAdder hits = new LongAdder(), misses = new LongAdder(), evictions = new LongAdder();

    public Cache(int capacity, LongSupplier nanoClock) {
        this.capacity = capacity;
        this.nanoClock = nanoClock;
        this.map = new LinkedHashMap<>(16, 0.75f, true) {                      // access order (Chapter 6)
            @Override protected boolean removeEldestEntry(Map.Entry<K, Entry<V>> eldest) {
                boolean evict = size() > Cache.this.capacity;
                if (evict) evictions.increment();
                return evict;
            }
        };
    }

    public Optional<V> get(K key) {
        if (capacity == 0) { misses.increment(); return Optional.empty(); }
        synchronized (map) {                                                    // even get() reorders an access-order map
            Entry<V> e = map.get(key);
            if (e != null && e.expiresAtNanos() - nanoClock.getAsLong() > 0) {
                hits.increment();
                return Optional.of(e.value());
            }
            if (e != null) map.remove(key);                                     // expired
        }
        misses.increment();
        return Optional.empty();
    }

    public void put(K key, V value, long ttlNanos) {
        if (capacity == 0) return;
        synchronized (map) { map.put(key, new Entry<>(value, nanoClock.getAsLong() + ttlNanos)); }
    }

    public int size() { synchronized (map) { return map.size(); } }
}
