// file: linkd/RateLimiter.java
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongSupplier;

/** One token bucket per client (Chapter 9's project, made thread-safe). */
public final class RateLimiter {
    private static final class Bucket {
        double tokens;
        long last;
    }
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();
    private final double capacity, refillPerNano;
    private final LongSupplier nanoClock;

    public RateLimiter(double capacity, double refillPerSecond, LongSupplier nanoClock) {
        this.capacity = capacity;
        this.refillPerNano = refillPerSecond / 1e9;
        this.nanoClock = nanoClock;
    }

    /** Returns 0 if the request is allowed, otherwise the number of milliseconds until a token is available. */
    public long tryAcquire(String client) {
        long now = nanoClock.getAsLong();
        Bucket b = buckets.computeIfAbsent(client, k -> { Bucket nb = new Bucket(); nb.tokens = capacity; nb.last = now; return nb; });
        synchronized (b) {                                                     // one small lock per client
            b.tokens = Math.min(capacity, b.tokens + (now - b.last) * refillPerNano);
            b.last = now;
            if (b.tokens >= 1) { b.tokens -= 1; return 0; }
            return (long) Math.ceil((1 - b.tokens) / refillPerNano / 1e6);
        }
    }
}
