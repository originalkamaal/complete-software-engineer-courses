// file: sym/Expr.java
/** An expression in one variable, x. */
public sealed interface Expr {
    record Num(double value) implements Expr {}
    record X() implements Expr {}
    record Add(Expr left, Expr right) implements Expr {}
    record Mul(Expr left, Expr right) implements Expr {}
    record Pow(Expr base, int exponent) implements Expr {}          // integer powers only
    record Sin(Expr arg) implements Expr {}
    record Cos(Expr arg) implements Expr {}
    record Neg(Expr arg) implements Expr {}

    static Expr num(double v) { return new Num(v); }
    Expr x = new X();
    static Expr add(Expr a, Expr b) { return new Add(a, b); }
    static Expr mul(Expr a, Expr b) { return new Mul(a, b); }
    static Expr pow(Expr a, int n) { return new Pow(a, n); }
    static Expr sin(Expr a) { return new Sin(a); }
    static Expr cos(Expr a) { return new Cos(a); }
}
