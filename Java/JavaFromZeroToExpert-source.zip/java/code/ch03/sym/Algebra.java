// file: sym/Algebra.java
import static java.lang.Math.*;

public final class Algebra {
    private Algebra() {}

    public static double eval(Expr e, double x) {
        return switch (e) {
            case Expr.Num(double v) -> v;
            case Expr.X() -> x;
            case Expr.Add(Expr a, Expr b) -> eval(a, x) + eval(b, x);
            case Expr.Mul(Expr a, Expr b) -> eval(a, x) * eval(b, x);
            case Expr.Pow(Expr b, int n) -> pow(eval(b, x), n);
            case Expr.Sin(Expr a) -> sin(eval(a, x));
            case Expr.Cos(Expr a) -> cos(eval(a, x));
            case Expr.Neg(Expr a) -> -eval(a, x);
        };
    }

    /** d/dx, by the sum, product, power (with chain), and trigonometric rules. */
    public static Expr derive(Expr e) {
        return switch (e) {
            case Expr.Num n -> new Expr.Num(0);
            case Expr.X x -> new Expr.Num(1);
            case Expr.Add(Expr a, Expr b) -> new Expr.Add(derive(a), derive(b));
            case Expr.Mul(Expr a, Expr b) -> new Expr.Add(new Expr.Mul(derive(a), b), new Expr.Mul(a, derive(b)));
            case Expr.Pow(Expr b, int n) -> new Expr.Mul(new Expr.Mul(new Expr.Num(n), new Expr.Pow(b, n - 1)), derive(b));
            case Expr.Sin(Expr a) -> new Expr.Mul(new Expr.Cos(a), derive(a));
            case Expr.Cos(Expr a) -> new Expr.Mul(new Expr.Neg(new Expr.Sin(a)), derive(a));
            case Expr.Neg(Expr a) -> new Expr.Neg(derive(a));
        };
    }

    /** One bottom-up pass of simplification rules; repeated until nothing changes. */
    public static Expr simplify(Expr e) {
        Expr prev;
        do {
            prev = e;
            e = step(e);
        } while (!e.equals(prev));                       // records compare structurally
        return e;
    }

    private static Expr step(Expr e) {
        return switch (e) {
            case Expr.Add(Expr a, Expr b) -> {
                Expr l = step(a), r = step(b);
                yield switch (new Expr.Add(l, r)) {
                    case Expr.Add(Expr.Num(double p), Expr.Num(double q)) -> new Expr.Num(p + q);
                    case Expr.Add(Expr.Num(double z), Expr o) when z == 0 -> o;
                    case Expr.Add(Expr o, Expr.Num(double z)) when z == 0 -> o;
                    case Expr.Add(Expr p, Expr q) when p.equals(q) -> new Expr.Mul(new Expr.Num(2), p);
                    case Expr.Add sum -> sum;
                };
            }
            case Expr.Mul(Expr a, Expr b) -> {
                Expr l = step(a), r = step(b);
                yield switch (new Expr.Mul(l, r)) {
                    case Expr.Mul(Expr.Num(double p), Expr.Num(double q)) -> new Expr.Num(p * q);
                    case Expr.Mul(Expr.Num(double z), Expr o) when z == 0 -> new Expr.Num(0);
                    case Expr.Mul(Expr o, Expr.Num(double z)) when z == 0 -> new Expr.Num(0);
                    case Expr.Mul(Expr.Num(double one), Expr o) when one == 1 -> o;
                    case Expr.Mul(Expr o, Expr.Num(double one)) when one == 1 -> o;
                    case Expr.Mul(Expr o, Expr.Num n) -> new Expr.Mul(n, o);                 // constants to the left
                    case Expr.Mul(Expr.Num(double p), Expr.Mul(Expr.Num(double q), Expr o)) -> new Expr.Mul(new Expr.Num(p * q), o);
                    case Expr.Mul(Expr p, Expr q) when p.equals(q) -> new Expr.Pow(p, 2);
                    case Expr.Mul m -> m;
                };
            }
            case Expr.Pow(Expr b, int n) when n == 0 -> new Expr.Num(1);
            case Expr.Pow(Expr b, int n) when n == 1 -> step(b);
            case Expr.Pow(Expr b, int n) -> new Expr.Pow(step(b), n);
            case Expr.Neg(Expr.Neg(Expr a)) -> step(a);
            case Expr.Neg(Expr.Num(double v)) -> new Expr.Num(-v);
            case Expr.Neg(Expr a) -> new Expr.Neg(step(a));
            case Expr.Sin(Expr a) -> new Expr.Sin(step(a));
            case Expr.Cos(Expr a) -> new Expr.Cos(step(a));
            case Expr.Num n -> n;
            case Expr.X x -> x;
        };
    }

    /** Prints with parentheses only where precedence requires them. */
    public static String show(Expr e) { return show(e, 0); }

    private static String show(Expr e, int outer) {                // precedence: 1 add, 2 mul, 3 neg, 4 pow
        return switch (e) {
            case Expr.Num(double v) -> v == Math.rint(v) ? Long.toString((long) v) : Double.toString(v);
            case Expr.X() -> "x";
            case Expr.Add(Expr a, Expr b) -> wrap(show(a, 1) + " + " + show(b, 1), 1, outer);
            case Expr.Mul(Expr a, Expr b) -> wrap(show(a, 2) + "·" + show(b, 2), 2, outer);
            case Expr.Neg(Expr a) -> wrap("-" + show(a, 3), 3, outer);
            case Expr.Pow(Expr b, int n) -> wrap(show(b, 5) + "^" + n, 4, outer);
            case Expr.Sin(Expr a) -> "sin(" + show(a, 0) + ")";
            case Expr.Cos(Expr a) -> "cos(" + show(a, 0) + ")";
        };
    }

    private static String wrap(String s, int prec, int outer) { return prec < outer ? "(" + s + ")" : s; }
}
