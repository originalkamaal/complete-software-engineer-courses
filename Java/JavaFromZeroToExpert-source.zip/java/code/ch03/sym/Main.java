// file: sym/Main.java
import static java.lang.Math.abs;

public class Main {
    public static void main(String[] args) {
        Expr x = Expr.x;
        Expr[] tests = {
            Expr.add(Expr.mul(Expr.num(3), Expr.pow(x, 2)), Expr.mul(Expr.num(2), x)),                    // 3x^2 + 2x
            Expr.mul(x, Expr.sin(x)),                                                                    // x sin x
            Expr.sin(Expr.pow(x, 3)),                                                                    // sin(x^3)
            Expr.pow(Expr.add(Expr.cos(x), x), 2),                                                       // (cos x + x)^2
        };
        for (Expr f : tests) {
            Expr raw = Algebra.derive(f);
            Expr d = Algebra.simplify(raw);
            double worst = 0;
            for (double at = -2; at <= 2; at += 0.25) {                  // check against a central difference
                double h = 1e-5;
                double numeric = (Algebra.eval(f, at + h) - Algebra.eval(f, at - h)) / (2 * h);
                worst = Math.max(worst, abs(numeric - Algebra.eval(d, at)));
            }
            System.out.printf("f(x)  = %s%nf'(x) = %s%n        (unsimplified: %d chars; simplified: %d; max numeric error %.1e)%n",
                    Algebra.show(f), Algebra.show(d), Algebra.show(raw).length(), Algebra.show(d).length(), worst);
        }
    }
}
