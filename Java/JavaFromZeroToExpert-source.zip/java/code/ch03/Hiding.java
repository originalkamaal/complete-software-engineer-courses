// file: Hiding.java
public class Hiding {
    static class Animal {
        String name = "animal";
        static String kind() { return "Animal.kind"; }
        String describe() { return "Animal.describe"; }
    }
    static class Cat extends Animal {
        String name = "cat";                                   // hides Animal.name
        static String kind() { return "Cat.kind"; }            // hides, does not override
        @Override String describe() { return "Cat.describe"; }
    }
    static void feed(Animal a) { System.out.println("feed(Animal)"); }
    static void feed(Cat c) { System.out.println("feed(Cat)"); }

    public static void main(String[] args) {
        Animal a = new Cat();
        System.out.println(a.describe());          // run-time type: Cat
        System.out.println(a.name);                // compile-time type: Animal
        System.out.println(((Cat) a).name);
        System.out.println(Animal.kind() + " / " + Cat.kind());
        feed(a);                                    // overload chosen at compile time
    }
}
