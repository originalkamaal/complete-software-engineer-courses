// file: Shapes.java
import java.util.List;

public class Shapes {
    abstract static class Shape {
        private final String name;
        Shape(String name) { this.name = name; }
        abstract double area();                                   // subclasses must implement
        String describe() { return "%s with area %.2f".formatted(name, area()); }   // dispatches to the subclass
    }

    static class Rect extends Shape {
        final double w, h;
        Rect(double w, double h) { this("rectangle", w, h); }
        protected Rect(String name, double w, double h) { super(name); this.w = w; this.h = h; }
        @Override double area() { return w * h; }
    }

    static final class Square extends Rect {
        Square(double side) { super("square", side, side); }
        @Override String describe() { return super.describe() + " (side " + w + ")"; }
    }

    static class Circle extends Shape {
        final double r;
        Circle(double r) { super("circle"); this.r = r; }
        @Override double area() { return Math.PI * r * r; }
    }

    public static void main(String[] args) {
        List<Shape> shapes = List.of(new Rect(2, 3), new Square(2), new Circle(1));
        for (Shape s : shapes) {
            System.out.println(s.describe() + "  [" + s.getClass().getSimpleName() + "]");
        }
    }
}
