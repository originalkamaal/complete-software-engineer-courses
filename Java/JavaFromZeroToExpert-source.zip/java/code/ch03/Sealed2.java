// file: Sealed.java
public class Sealed2 {
    sealed interface Payment permits Card, Upi, Cash, Wallet {}
    record Wallet(long paise) implements Payment {}
    record Card(String last4, long paise) implements Payment {}
    record Upi(String vpa, long paise) implements Payment {}
    record Cash(long paise) implements Payment {}

    static long fee(Payment p) {
        return switch (p) {                                    // exhaustive: no default needed
            case Card c when c.paise() > 100_000 -> c.paise() / 100;   // 1% on large card payments
            case Card c -> 200;
            case Upi u -> 0;
            case Cash c -> 0;
        };
    }

    public static void main(String[] args) {
        Payment[] ps = { new Card("4242", 250_000), new Card("1111", 5_000), new Upi("ada@bank", 99_900), new Cash(1_000) };
        for (Payment p : ps) System.out.println(p + " -> fee " + fee(p) + " paise");
    }
}
