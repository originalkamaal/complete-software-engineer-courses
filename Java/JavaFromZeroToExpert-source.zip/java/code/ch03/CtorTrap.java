// file: CtorTrap.java
public class CtorTrap {
    static class Base {
        Base() { System.out.println("Base constructor sees: " + describe()); }
        String describe() { return "base"; }
    }

    static class Derived extends Base {
        private final String label = "derived".toUpperCase();   // not yet assigned when Base() runs
        Derived() { super(); System.out.println("Derived constructor sees: " + describe()); }
        @Override String describe() { return "label=" + label + " (length " + (label == null ? "NPE!" : label.length()) + ")"; }
    }

    public static void main(String[] args) {
        new Derived();
    }
}
