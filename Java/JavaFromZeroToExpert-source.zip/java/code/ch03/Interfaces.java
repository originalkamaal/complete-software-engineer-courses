// file: Interfaces.java
public class Interfaces {
    interface Greeter {
        String name();
        default String greet() { return "Hello from " + name() + suffix(); }
        private String suffix() { return "!"; }
        static Greeter of(String n) { return () -> n; }          // a functional interface: a lambda implements it
    }

    interface Polite {
        default String greet() { return "Good day"; }
    }

    static class Butler implements Greeter, Polite {
        public String name() { return "Jeeves"; }
        @Override public String greet() {                        // must resolve the conflict explicitly
            return Polite.super.greet() + ". " + Greeter.super.greet();
        }
    }

    public static void main(String[] args) {
        System.out.println(Greeter.of("a lambda").greet());
        System.out.println(new Butler().greet());
    }
}
