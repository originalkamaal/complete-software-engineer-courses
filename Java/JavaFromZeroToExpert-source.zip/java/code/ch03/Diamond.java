// file: Diamond.java
public class Diamond {
    interface Flyer { default String move() { return "fly"; } }
    interface Swimmer { default String move() { return "swim"; } }

    static class Duck implements Flyer, Swimmer {
        @Override public String move() {                       // required: the two defaults conflict
            return Flyer.super.move() + " and " + Swimmer.super.move();
        }
    }
    static class Base { public String move() { return "walk (from the class)"; } }
    static class Penguin extends Base implements Swimmer {}     // the class method wins, no conflict

    public static void main(String[] args) {
        System.out.println(new Duck().move());
        System.out.println(new Penguin().move());
    }
}
