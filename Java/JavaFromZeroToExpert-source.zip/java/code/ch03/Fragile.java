// file: Fragile.java
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Fragile {
    /** Counts insertion attempts by extending HashSet. */
    static class InstrumentedHashSet<E> extends HashSet<E> {
        int attempts = 0;
        @Override public boolean add(E e) { attempts++; return super.add(e); }
        @Override public boolean addAll(Collection<? extends E> c) { attempts += c.size(); return super.addAll(c); }
    }

    /** The same, by composition: wraps any Set and forwards to it. */
    static class InstrumentedSet<E> extends java.util.AbstractSet<E> {
        private final Set<E> inner;
        int attempts = 0;
        InstrumentedSet(Set<E> inner) { this.inner = inner; }
        @Override public boolean add(E e) { attempts++; return inner.add(e); }
        @Override public boolean addAll(Collection<? extends E> c) { attempts += c.size(); return inner.addAll(c); }
        @Override public java.util.Iterator<E> iterator() { return inner.iterator(); }
        @Override public int size() { return inner.size(); }
    }

    public static void main(String[] args) {
        var inherited = new InstrumentedHashSet<String>();
        inherited.addAll(List.of("a", "b", "c"));
        var composed = new InstrumentedSet<String>(new HashSet<>());
        composed.addAll(List.of("a", "b", "c"));
        System.out.println("inheritance counted " + inherited.attempts + ", composition counted " + composed.attempts);
    }
}
