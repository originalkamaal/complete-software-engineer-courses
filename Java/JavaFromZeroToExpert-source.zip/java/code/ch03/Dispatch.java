// file: Dispatch.java
public class Dispatch {
    static class Animal {
        String name = "animal";
        static String kind() { return "Animal.kind"; }
        String speak() { return "..."; }
    }

    static class Dog extends Animal {
        String name = "dog";                                   // hides Animal.name: a second field
        static String kind() { return "Dog.kind"; }            // hides, does not override
        @Override String speak() { return "woof"; }
    }

    static String meet(Animal a) { return "meet(Animal)"; }
    static String meet(Dog d) { return "meet(Dog)"; }

    public static void main(String[] args) {
        Animal a = new Dog();                                  // static type Animal, run-time class Dog
        System.out.println("a.speak() = " + a.speak() + "   (virtual: the Dog's method)");
        System.out.println("a.name = " + a.name + "   (field: chosen by static type)");
        System.out.println("((Dog) a).name = " + ((Dog) a).name);
        System.out.println("meet(a) = " + meet(a) + "   (overload: chosen by static type at compile time)");
        System.out.println("Dog.kind() = " + Dog.kind() + ", Animal.kind() = " + Animal.kind());
    }
}
