// file: Patterns.java
public class Patterns {
    sealed interface Shape permits Circle, Square, Rect {}
    record Circle(double r) implements Shape {}
    record Square(double side) implements Shape {}
    record Rect(Point topLeft, Point bottomRight) implements Shape {}
    record Point(double x, double y) {}

    static double area(Shape s) {
        return switch (s) {                                             // exhaustive: no default needed
            case Circle c -> Math.PI * c.r() * c.r();
            case Square(double side) -> side * side;                    // record pattern
            case Rect(Point(var x1, var y1), Point(var x2, var y2)) ->  // nested record patterns
                Math.abs(x2 - x1) * Math.abs(y2 - y1);
        };
    }

    static String classify(Object o) {
        return switch (o) {
            case null -> "null!";
            case Integer i when i < 0 -> "negative int " + i;
            case Integer i -> "int " + i;
            case String s when s.isBlank() -> "blank string";
            case String s -> "string of length " + s.length();
            case Shape s -> "a shape with area %.1f".formatted(area(s));
            case int[] arr -> "int array of " + arr.length;
            default -> "something else: " + o.getClass().getSimpleName();
        };
    }

    public static void main(String[] args) {
        Object[] things = {42, -7, "hi", "   ", new Circle(1), new Rect(new Point(0, 0), new Point(3, 4)), new int[3], 2.5, null};
        for (Object o : things) {
            System.out.println(classify(o));
        }
        Object maybe = new Square(3);
        if (maybe instanceof Square(double side) && side > 2) {
            System.out.println("big square, side " + side);
        }
    }
}
