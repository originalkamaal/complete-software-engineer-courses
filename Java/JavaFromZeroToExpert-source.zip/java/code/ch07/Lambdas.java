// file: Lambdas.java
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Lambdas {
    @FunctionalInterface
    interface Validator<T> {
        boolean check(T value);                                    // the single abstract method
        default Validator<T> and(Validator<T> other) { return v -> check(v) && other.check(v); }
    }

    static <T, R> List<R> mapAll(List<T> in, Function<? super T, ? extends R> f) {
        List<R> out = new ArrayList<>();
        for (T t : in) out.add(f.apply(t));
        return out;
    }

    public static void main(String[] args) {
        Function<String, Integer> length = String::length;                 // method reference: instance method of the argument
        Function<Integer, Integer> square = x -> x * x;
        Function<String, Integer> lengthSquared = length.andThen(square);   // composition
        Predicate<String> isBlank = String::isBlank;
        Predicate<String> longWord = s -> s.length() > 4;
        Supplier<List<String>> newList = ArrayList::new;                    // constructor reference
        BiFunction<Integer, Integer, Integer> max = Math::max;              // static method reference
        UnaryOperator<String> shout = s -> s.toUpperCase() + "!";

        List<String> words = List.of("lambda", "is", "", "an", "anonymous", "function");
        System.out.println(mapAll(words, lengthSquared) + " " + words.stream().filter(isBlank.negate().and(longWord)).toList());
        List<String> made = newList.get();
        made.add(shout.apply("made"));
        System.out.println(made + " max=" + max.apply(3, 9));

        Validator<String> notEmpty = s -> !s.isEmpty();
        Validator<String> ascii = s -> s.chars().allMatch(c -> c < 128);
        System.out.println("validators: " + notEmpty.and(ascii).check("plain") + " " + notEmpty.and(ascii).check("naïve"));

        int base = 10;                                              // effectively final: never reassigned
        Function<Integer, Integer> addBase = x -> x + base;
        // base++;                                                  // would make the lambda above a compile error
        int[] counter = {0};                                        // the usual workaround: a mutable holder
        Runnable r = () -> counter[0]++;
        r.run(); r.run();
        System.out.println("addBase(5) = " + addBase.apply(5) + ", counter = " + counter[0]);
    }
}
