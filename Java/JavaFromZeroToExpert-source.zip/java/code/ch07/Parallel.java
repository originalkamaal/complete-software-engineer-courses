// file: Parallel.java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class Parallel {
    static boolean isPrime(long n) {
        if (n < 2) return false;
        for (long d = 2; d * d <= n; d++) if (n % d == 0) return false;
        return true;
    }

    static long ms(Runnable r) { long t = System.nanoTime(); r.run(); return (System.nanoTime() - t) / 1_000_000; }
    static long us(Runnable r) { long t = System.nanoTime(); r.run(); return (System.nanoTime() - t) / 1_000; }

    public static void main(String[] args) {
        long[] result = new long[4];
        for (int round = 0; round < 2; round++) {                              // round 0 warms up
            long seq = ms(() -> result[0] = LongStream.range(0, 2_000_000).filter(Parallel::isPrime).count());
            long par = ms(() -> result[1] = LongStream.range(0, 2_000_000).parallel().filter(Parallel::isPrime).count());
            long seqCheap = us(() -> result[2] = IntStream.range(0, 2_000).map(x -> x + 1).sum());
            long parCheap = us(() -> result[3] = IntStream.range(0, 2_000).parallel().map(x -> x + 1).sum());
            if (round == 1) {
                System.out.printf("primes below 2M: sequential %d ms, parallel %d ms on %d cores (results %d = %d)%n",
                        seq, par, Runtime.getRuntime().availableProcessors(), result[0], result[1]);
                System.out.printf("tiny cheap task (2,000 additions): sequential %d µs, parallel %d µs%n", seqCheap, parCheap);
            }
        }
        List<Integer> unsafe = new ArrayList<>();                              // not thread-safe
        try {
            IntStream.range(0, 100_000).parallel().forEach(unsafe::add);       // side effect on shared state: a data race
            System.out.println("unsafe side effect: expected 100000 elements, got " + unsafe.size());
        } catch (RuntimeException e) {
            System.out.println("unsafe side effect: failed with " + e.getClass().getSimpleName());
        }
        List<Integer> safe = IntStream.range(0, 100_000).parallel().boxed().toList();   // let the collector do it
        List<Integer> sync = Collections.synchronizedList(new ArrayList<>());
        IntStream.range(0, 100_000).parallel().forEach(sync::add);
        System.out.println("collector: " + safe.size() + " in order: " + (safe.get(99_999) == 99_999) + "; synchronizedList: " + sync.size()
                + " in order: " + sync.equals(safe));
    }
}
