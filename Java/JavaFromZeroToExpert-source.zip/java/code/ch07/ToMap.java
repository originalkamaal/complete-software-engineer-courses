// file: ToMap.java
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class ToMap {
    record City(String name, String state, Integer population) {}

    public static void main(String[] args) {
        List<City> cities = List.of(new City("pune", "MH", 7), new City("mumbai", "MH", 21), new City("delhi", "DL", 32));
        try {
            cities.stream().collect(Collectors.toMap(City::state, City::name));
        } catch (IllegalStateException e) {
            System.out.println("toMap: " + e.getMessage());
        }
        Map<String, String> merged = cities.stream()
            .collect(Collectors.toMap(City::state, City::name, (a, b) -> a + "+" + b, TreeMap::new));
        System.out.println("with merge function: " + merged);
        System.out.println("groupingBy: " + cities.stream().collect(Collectors.groupingBy(City::state, TreeMap::new,
                                Collectors.mapping(City::name, Collectors.toList()))));
        try {
            List.of(new City("new", "XX", null)).stream().collect(Collectors.toMap(City::name, City::population));
        } catch (NullPointerException e) {
            System.out.println("toMap with a null value: NullPointerException");
        }
    }
}
