// file: LambdaIdentity.java
import java.util.function.Supplier;

public class LambdaIdentity {
    static Supplier<String> nonCapturing() { return () -> "constant"; }
    static Supplier<String> capturing(String s) { return () -> s; }

    public static void main(String[] args) {
        System.out.println("non-capturing: same instance each time? " + (nonCapturing() == nonCapturing()));
        System.out.println("capturing:     same instance each time? " + (capturing("x") == capturing("x")));
        System.out.println("a lambda's class is generated at run time: name contains $$Lambda? " + nonCapturing().getClass().getName().contains("$$Lambda"));
    }
}
