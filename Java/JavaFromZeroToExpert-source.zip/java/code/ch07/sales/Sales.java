// file: sales/Sales.java
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Sales {
    record Sale(int id, LocalDate date, String region, String product, String customer, int qty, double unitPrice) {
        double amount() { return qty * unitPrice; }
    }

    /** Mean and standard deviation in one pass (mergeable, so it works in parallel). */
    static final class Stats {
        long n; double sum, sumSq;
        void add(double x) { n++; sum += x; sumSq += x * x; }
        Stats merge(Stats o) { n += o.n; sum += o.sum; sumSq += o.sumSq; return this; }
        double mean() { return sum / n; }
        double stddev() { return Math.sqrt(sumSq / n - mean() * mean()); }
        static Collector<Double, Stats, Stats> collector() {
            return Collector.of(Stats::new, Stats::add, Stats::merge, Collector.Characteristics.UNORDERED);
        }
    }

    static List<Sale> generate(int n) {
        Random r = new Random(2026);
        String[] regions = {"north", "south", "east", "west"};
        String[] products = {"laptop", "phone", "tablet", "monitor", "keyboard", "mouse", "cable"};
        double[] prices = {1200, 800, 450, 300, 80, 35, 9};
        List<Sale> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            int p = (int) Math.min(products.length - 1, Math.abs(r.nextGaussian() * 2.5));       // skewed: low values are common...
            p = products.length - 1 - p;                                                          // ...so cheap items sell most often
            out.add(new Sale(i, LocalDate.of(2026, 1, 1).plusDays(r.nextInt(300)), regions[r.nextInt(4)], products[p],
                    "c" + (int) Math.abs(r.nextGaussian() * 2000), 1 + r.nextInt(5), prices[p] * (0.9 + r.nextDouble() * 0.2)));
        }
        return out;
    }

    static long ms(Runnable r) { long t = System.nanoTime(); r.run(); return (System.nanoTime() - t) / 1_000_000; }

    public static void main(String[] args) {
        List<Sale> sales = generate(500_000);

        Map<String, Double> byRegion = sales.stream().collect(Collectors.groupingBy(Sale::region, TreeMap::new, Collectors.summingDouble(Sale::amount)));
        System.out.println("revenue by region (millions): " + byRegion.entrySet().stream()
                .map(e -> "%s=%.2f".formatted(e.getKey(), e.getValue() / 1e6)).collect(Collectors.joining(", ")));

        Map<YearMonth, Double> byMonth = sales.stream()
            .collect(Collectors.groupingBy(s -> YearMonth.from(s.date()), TreeMap::new, Collectors.summingDouble(Sale::amount)));
        var best = byMonth.entrySet().stream().max(Map.Entry.comparingByValue()).orElseThrow();
        System.out.printf("months: %d, best month %s with %.2f M%n", byMonth.size(), best.getKey(), best.getValue() / 1e6);

        System.out.println("top 3 products: " + sales.stream()
            .collect(Collectors.groupingBy(Sale::product, Collectors.summingDouble(Sale::amount)))
            .entrySet().stream().sorted(Map.Entry.<String, Double>comparingByValue().reversed()).limit(3)
            .map(e -> "%s %.1fM".formatted(e.getKey(), e.getValue() / 1e6)).toList());

        Map<String, Sale> largestPerCustomer = sales.stream()
            .collect(Collectors.toMap(Sale::customer, s -> s, (a, b) -> a.amount() >= b.amount() ? a : b));
        Sale whale = largestPerCustomer.values().stream().max(Comparator.comparingDouble(Sale::amount)).orElseThrow();
        System.out.printf("%d customers; largest single purchase: %s bought %d x %s for %.2f%n",
                largestPerCustomer.size(), whale.customer(), whale.qty(), whale.product(), whale.amount());

        Map<Integer, Long> histogram = sales.stream().collect(Collectors.groupingBy(Sale::qty, TreeMap::new, Collectors.counting()));
        System.out.println("orders by quantity: " + histogram);

        Stats st = sales.stream().map(Sale::amount).collect(Stats.collector());
        Stats stPar = sales.parallelStream().map(Sale::amount).collect(Stats.collector());
        System.out.printf("order amount: mean %.2f, stddev %.2f (parallel run agrees: %b)%n", st.mean(), st.stddev(),
                Math.abs(st.mean() - stPar.mean()) < 1e-6 && st.n == stPar.n);

        // the same query three ways, timed after warm-up
        Map<String, Double> viaLoop = new HashMap<>();
        long tLoop = 0, tStream = 0, tPar = 0;
        for (int round = 0; round < 5; round++) {
            viaLoop.clear();
            tLoop = ms(() -> { for (Sale s : sales) viaLoop.merge(s.region(), s.amount(), Double::sum); });
            tStream = ms(() -> sales.stream().collect(Collectors.groupingBy(Sale::region, Collectors.summingDouble(Sale::amount))));
            tPar = ms(() -> sales.parallelStream().collect(Collectors.groupingBy(Sale::region, Collectors.summingDouble(Sale::amount))));
        }
        System.out.printf("revenue by region: loop %d ms, stream %d ms, parallel stream %d ms; loop result matches: %b%n", tLoop, tStream, tPar,
                viaLoop.keySet().equals(byRegion.keySet()) && Math.abs(viaLoop.get("north") - byRegion.get("north")) < 1e-3);
    }
}
