// file: Collecting.java
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Collecting {
    record Emp(String name, String dept, String city, int salary) {}

    public static void main(String[] args) {
        List<Emp> staff = List.of(new Emp("Ann", "eng", "Oslo", 150), new Emp("Ben", "ops", "Rome", 95), new Emp("Mia", "eng", "Rome", 120),
                new Emp("Raj", "ops", "Oslo", 90), new Emp("Zoe", "eng", "Oslo", 120), new Emp("Kim", "hr", "Rome", 80));

        Map<String, List<String>> namesByDept = staff.stream()
            .collect(Collectors.groupingBy(Emp::dept, TreeMap::new, Collectors.mapping(Emp::name, Collectors.toList())));
        Map<String, Double> avgByDept = staff.stream().collect(Collectors.groupingBy(Emp::dept, TreeMap::new, Collectors.averagingInt(Emp::salary)));
        Map<String, Map<String, Long>> countByDeptCity = staff.stream()
            .collect(Collectors.groupingBy(Emp::dept, TreeMap::new, Collectors.groupingBy(Emp::city, TreeMap::new, Collectors.counting())));
        Map<Boolean, List<String>> highEarners = staff.stream()
            .collect(Collectors.partitioningBy(e -> e.salary() >= 120, Collectors.mapping(Emp::name, Collectors.toList())));
        Map<String, String> topByDept = staff.stream().collect(Collectors.toMap(Emp::dept, Emp::name,
                (a, b) -> a, TreeMap::new));                                    // merge function: keep the first
        Map<String, Emp> byName = staff.stream().collect(Collectors.toMap(Emp::name, Function.identity()));
        String range = staff.stream().collect(Collectors.teeing(
                Collectors.minBy(Comparator.comparingInt(Emp::salary)), Collectors.maxBy(Comparator.comparingInt(Emp::salary)),
                (min, max) -> min.get().name() + ".." + max.get().name()));

        System.out.println(namesByDept + "\n" + avgByDept + "\n" + countByDeptCity + "\n" + highEarners + "\n" + topByDept
                + " " + byName.get("Kim").city() + " " + range);
        try {
            staff.stream().collect(Collectors.toMap(Emp::dept, Emp::name));       // duplicate keys, no merge function
        } catch (IllegalStateException e) {
            System.out.println("toMap without a merge function: " + e.getMessage());
        }
    }
}
