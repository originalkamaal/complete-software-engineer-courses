// file: MethodRefs.java
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class MethodRefs {
    public static void main(String[] args) {
        Function<String, Integer> parse = Integer::parseInt;          // 1. static method
        String prefix = "id-";
        Function<String, String> addPrefix = prefix::concat;          // 2. method of a particular object
        Function<String, Integer> len = String::length;               // 3. method of the argument
        BiFunction<String, String, Boolean> starts = String::startsWith; //    two args: receiver + parameter
        Supplier<List<String>> make = java.util.ArrayList::new;       // 4. constructor

        System.out.println(parse.apply("42") + 1);
        System.out.println(addPrefix.apply("7"));
        System.out.println(len.apply("hello") + " " + starts.apply("prefix", "pre"));
        List<String> l = make.get();
        l.add("built by a constructor reference");
        System.out.println(l);
        System.out.println(List.of("b", "a").stream().map(String::toUpperCase).sorted().toList());
    }
}
