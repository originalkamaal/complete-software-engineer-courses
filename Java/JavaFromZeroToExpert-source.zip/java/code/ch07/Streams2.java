// file: Streams2.java
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Streams2 {
    record Order(String id, List<String> items) {}

    public static void main(String[] args) {
        List<Order> orders = List.of(new Order("o1", List.of("pen", "ink")), new Order("o2", List.of("pad")),
                                     new Order("o3", List.of("pen", "pad", "clip")));
        System.out.println(orders.stream().flatMap(o -> o.items().stream()).distinct().sorted().toList());

        System.out.println(Stream.iterate(1, n -> n < 1000, n -> n * 3).toList());
        System.out.println(IntStream.of(2, 4, 6, 7, 8).takeWhile(n -> n % 2 == 0).boxed().toList()
                           + " " + IntStream.of(2, 4, 6, 7, 8).dropWhile(n -> n % 2 == 0).boxed().toList());
        var stats = IntStream.rangeClosed(1, 100).summaryStatistics();
        System.out.println(stats);
        System.out.println(IntStream.rangeClosed(1, 5).mapToObj(i -> "*".repeat(i)).reduce((a, b) -> a + " " + b).get());
    }
}
