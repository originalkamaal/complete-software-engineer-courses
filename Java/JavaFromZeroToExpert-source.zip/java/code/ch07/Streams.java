// file: Streams.java
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Streams {
    record Order(String customer, String product, int qty, double price) {
        double total() { return qty * price; }
    }

    public static void main(String[] args) {
        List<Order> orders = List.of(
            new Order("ada", "pen", 10, 1.5), new Order("bob", "ink", 2, 9.0), new Order("ada", "pad", 3, 4.0),
            new Order("cy", "pen", 100, 1.2), new Order("bob", "pad", 1, 4.0), new Order("ada", "ink", 1, 9.0));

        List<String> bigSpenders = orders.stream()
            .filter(o -> o.total() > 10)
            .sorted(Comparator.comparingDouble(Order::total).reversed())
            .map(o -> o.customer() + ":" + o.product())
            .toList();
        double revenue = orders.stream().mapToDouble(Order::total).sum();
        var stats = orders.stream().mapToInt(Order::qty).summaryStatistics();
        System.out.println(bigSpenders + " revenue " + revenue + " " + stats);

        System.out.println(IntStream.rangeClosed(1, 5).map(x -> x * x).boxed().toList()
                + " " + Stream.iterate(1, x -> x * 2).limit(10).reduce(0, Integer::sum)
                + " " + Stream.of("b,a", "c", "a,d").flatMap(s -> Arrays.stream(s.split(","))).distinct().sorted().collect(Collectors.joining("|")));

        // laziness and short-circuiting: watch which elements each stage sees
        var first = Stream.of(5, 8, 3, 12, 7, 20)
            .peek(x -> System.out.print(" filter?" + x))
            .filter(x -> x > 6)
            .peek(x -> System.out.print(" map:" + x))
            .map(x -> x * 10)
            .findFirst();
        System.out.println("  -> " + first);

        Stream<String> once = Stream.of("a", "b");
        once.forEach(s -> {});
        try {
            once.forEach(s -> {});
        } catch (IllegalStateException e) {
            System.out.println("second use: " + e.getMessage());
        }
    }
}
