// file: inventory/Inventory.java
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class Inventory {
    static final String URL = "jdbc:hsqldb:mem:shop;hsqldb.tx=locks";           // two-phase locking (this database's default)

    record Product(int id, String name, int stock, int version) {}

    /** All SQL for products lives here. */
    static final class ProductRepository {
        private final Connection c;
        ProductRepository(Connection c) { this.c = c; }

        Product find(int id, boolean forUpdate) throws SQLException {
            try (PreparedStatement ps = c.prepareStatement("select id, name, stock, version from products where id = ?" + (forUpdate ? " for update" : ""))) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("no product " + id);
                    return new Product(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4));
                }
            }
        }

        void setStock(int id, int stock) throws SQLException {
            try (PreparedStatement ps = c.prepareStatement("update products set stock = ? where id = ?")) {
                ps.setInt(1, stock); ps.setInt(2, id);
                ps.executeUpdate();
            }
        }

        /** Atomic in SQL: decrements only if enough stock remains. Returns whether a row changed. */
        boolean decrementIfAvailable(int id, int qty) throws SQLException {
            try (PreparedStatement ps = c.prepareStatement("update products set stock = stock - ? where id = ? and stock >= ?")) {
                ps.setInt(1, qty); ps.setInt(2, id); ps.setInt(3, qty);
                return ps.executeUpdate() == 1;
            }
        }

        /** Optimistic: succeeds only if nobody changed the row since we read it. */
        boolean updateIfUnchanged(Product read, int newStock) throws SQLException {
            try (PreparedStatement ps = c.prepareStatement("update products set stock = ?, version = version + 1 where id = ? and version = ?")) {
                ps.setInt(1, newStock); ps.setInt(2, read.id()); ps.setInt(3, read.version());
                return ps.executeUpdate() == 1;
            }
        }
    }

    interface Purchase { boolean buy(ProductRepository repo, Connection c, AtomicInteger retries) throws SQLException; }

    static boolean naive(ProductRepository repo, Connection c, AtomicInteger retries) throws SQLException {
        Product p = repo.find(1, false);                                      // read...
        if (p.stock() < 1) return false;
        Thread.onSpinWait();
        repo.setStock(1, p.stock() - 1);                                      // ...then write: another thread may have written in between
        return true;
    }

    static boolean atomicSql(ProductRepository repo, Connection c, AtomicInteger retries) throws SQLException {
        return repo.decrementIfAvailable(1, 1);
    }

    static boolean pessimistic(ProductRepository repo, Connection c, AtomicInteger retries) throws SQLException {
        c.setAutoCommit(false);
        try {
            Product p = repo.find(1, true);                                   // select ... for update: locks the row until commit
            boolean ok = p.stock() >= 1;
            if (ok) repo.setStock(1, p.stock() - 1);
            c.commit();
            return ok;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    static boolean optimistic(ProductRepository repo, Connection c, AtomicInteger retries) throws SQLException {
        while (true) {
            Product p = repo.find(1, false);
            if (p.stock() < 1) return false;
            if (repo.updateIfUnchanged(p, p.stock() - 1)) return true;        // version matched: our write won
            retries.incrementAndGet();                                        // someone else got there first: re-read and retry
        }
    }

    static void run(String name, Purchase purchase) throws Exception {
        int stock = 500, threads = 16, attemptsEach = 50;                     // 800 attempts for 500 items
        try (Connection admin = DriverManager.getConnection(URL, "SA", ""); Statement s = admin.createStatement()) {
            s.execute("drop table products if exists");
            s.execute("create table products (id int primary key, name varchar(40), stock int not null, version int default 0 not null)");
            s.execute("insert into products values (1, 'limited edition', " + stock + ", 0)");
        }
        AtomicInteger sold = new AtomicInteger(), retries = new AtomicInteger(), errors = new AtomicInteger();
        CountDownLatch start = new CountDownLatch(1);
        long t = System.nanoTime();
        try (ExecutorService pool = Executors.newFixedThreadPool(threads)) {
            for (int i = 0; i < threads; i++) {
                pool.submit(() -> {
                    try (Connection c = DriverManager.getConnection(URL, "SA", "")) {     // one connection per thread
                        ProductRepository repo = new ProductRepository(c);
                        start.await();
                        for (int k = 0; k < attemptsEach; k++) {
                            try {
                                if (purchase.buy(repo, c, retries)) sold.incrementAndGet();
                            } catch (SQLException e) {
                                errors.incrementAndGet();                                 // e.g. serialization failure: counted, not sold
                            }
                        }
                    } catch (Exception e) {
                        errors.incrementAndGet();
                    }
                    return null;
                });
            }
            start.countDown();
        }
        long ms = (System.nanoTime() - t) / 1_000_000;
        try (Connection c = DriverManager.getConnection(URL, "SA", "")) {
            int left = new ProductRepository(c).find(1, false).stock();
            int oversold = sold.get() - (stock - left);
            System.out.printf("%-12s sold %3d, stock left %3d, %s, retries %d, errors %d, %d ms%n", name, sold.get(), left,
                    oversold == 0 && sold.get() <= stock ? "consistent" : "INCONSISTENT: " + oversold + " sales not reflected in stock", retries.get(), errors.get(), ms);
        }
    }

    public static void main(String[] args) throws Exception {
        run("naive", Inventory::naive);
        run("atomic SQL", Inventory::atomicSql);
        run("pessimistic", Inventory::pessimistic);
        run("optimistic", Inventory::optimistic);
    }
}
