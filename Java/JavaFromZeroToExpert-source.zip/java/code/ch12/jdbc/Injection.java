// file: jdbc/Injection.java
import java.sql.*;

public class Injection {
    public static void main(String[] args) throws SQLException {
        try (Connection c = DriverManager.getConnection("jdbc:hsqldb:mem:inj", "SA", "")) {
            try (Statement s = c.createStatement()) {
                s.execute("CREATE TABLE users (name VARCHAR(20), secret VARCHAR(20))");
                s.execute("INSERT INTO users VALUES ('ada', 'a-secret'), ('bob', 'b-secret')");
            }
            String input = "nobody' OR '1'='1";
            try (Statement s = c.createStatement();
                 ResultSet rs = s.executeQuery("SELECT secret FROM users WHERE name = '" + input + "'")) {
                int n = 0;
                while (rs.next()) n++;
                System.out.println("concatenated query returned " + n + " secret(s)");
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT secret FROM users WHERE name = ?")) {
                ps.setString(1, input);
                try (ResultSet rs = ps.executeQuery()) {
                    int n = 0;
                    while (rs.next()) n++;
                    System.out.println("prepared statement returned " + n + " secret(s)");
                }
            }
        }
    }
}
