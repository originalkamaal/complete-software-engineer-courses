// file: jdbc/Transactions.java
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Transactions {
    static long balance(Connection c, int id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("select balance from accounts where id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getLong(1); }
        }
    }

    /** Moves money atomically: both updates commit, or neither does. */
    static void transfer(Connection c, int from, int to, long amount) throws SQLException {
        boolean old = c.getAutoCommit();
        c.setAutoCommit(false);
        try (PreparedStatement debit = c.prepareStatement("update accounts set balance = balance - ? where id = ?");
             PreparedStatement credit = c.prepareStatement("update accounts set balance = balance + ? where id = ?")) {
            debit.setLong(1, amount); debit.setInt(2, from);
            if (debit.executeUpdate() != 1) throw new SQLException("no such account " + from);
            credit.setLong(1, amount); credit.setInt(2, to);
            if (credit.executeUpdate() != 1) throw new SQLException("no such account " + to);
            c.commit();
        } catch (SQLException e) {
            c.rollback();                                             // undo the debit if the credit failed
            throw e;
        } finally {
            c.setAutoCommit(old);
        }
    }

    public static void main(String[] args) throws SQLException {
        try (Connection c = DriverManager.getConnection("jdbc:hsqldb:mem:tx", "SA", "")) {
            try (Statement s = c.createStatement()) {
                s.execute("create table accounts (id int primary key, balance bigint not null, check (balance >= 0))");
                s.execute("insert into accounts values (1, 1000)");
                s.execute("insert into accounts values (2, 500)");
            }
            transfer(c, 1, 2, 300);
            System.out.println("after transfer 300: " + balance(c, 1) + " / " + balance(c, 2));
            for (Object[] bad : new Object[][] {{1, 99, 100L, "to a missing account"}, {2, 1, 5000L, "more than the balance"}}) {
                try {
                    transfer(c, (Integer) bad[0], (Integer) bad[1], (Long) bad[2]);
                } catch (SQLException e) {
                    System.out.println("transfer " + bad[3] + " failed (" + e.getMessage().lines().findFirst().orElse("").replaceAll(" ?SYS_CT_\\d+", "") + "); balances: "
                            + balance(c, 1) + " / " + balance(c, 2));
                }
            }

            try (Statement s = c.createStatement()) { s.execute("create table events (id int primary key, payload varchar(40))"); }
            int n = 20_000;
            long t = System.nanoTime();
            try (PreparedStatement ps = c.prepareStatement("insert into events values (?, ?)")) {
                for (int i = 0; i < n; i++) { ps.setInt(1, i); ps.setString(2, "event-" + i); ps.executeUpdate(); }      // auto-commit: one transaction each
            }
            long single = (System.nanoTime() - t) / 1_000_000;
            c.setAutoCommit(false);
            t = System.nanoTime();
            try (PreparedStatement ps = c.prepareStatement("insert into events values (?, ?)")) {
                for (int i = n; i < 2 * n; i++) {
                    ps.setInt(1, i); ps.setString(2, "event-" + i); ps.addBatch();
                    if (i % 1000 == 999) ps.executeBatch();                // send 1,000 rows per round trip
                }
            }
            c.commit();
            long batched = (System.nanoTime() - t) / 1_000_000;
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("select count(*) from events")) {
                rs.next();
                System.out.printf("%d rows; %d single auto-commit inserts: %d ms; %d batched in one transaction: %d ms%n", rs.getInt(1), n, single, n, batched);
            }
        }
    }
}
