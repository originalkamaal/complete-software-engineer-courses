// file: Timeouts.java
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class Timeouts {
    public static void main(String[] args) throws Exception {
        try (ServerSocket silent = new ServerSocket(0)) {             // accepts, never sends anything
            Thread.ofVirtual().start(() -> { try { silent.accept(); Thread.sleep(5_000); } catch (Exception e) {} });
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress("127.0.0.1", silent.getLocalPort()), 1_000);
                s.setSoTimeout(300);                                   // read timeout
                InputStream in = s.getInputStream();
                long t0 = System.nanoTime();
                try {
                    in.read();
                } catch (SocketTimeoutException e) {
                    System.out.println("read timed out after about " + Math.round((System.nanoTime() - t0) / 1e8) * 100 + " ms: " + e.getMessage());
                }
            }
        }
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", 1), 1_000);   // nothing listens on port 1
        } catch (java.net.ConnectException e) {
            System.out.println("connect refused: " + e.getMessage());
        }
    }
}
