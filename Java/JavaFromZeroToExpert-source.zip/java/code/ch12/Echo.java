// file: Echo.java
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class Echo {
    public static void main(String[] args) throws Exception {
        AtomicInteger served = new AtomicInteger();
        try (ServerSocket server = new ServerSocket(0, 50, InetAddress.getLoopbackAddress())) {   // port 0: the OS picks a free port
            int port = server.getLocalPort();
            Thread acceptor = Thread.ofVirtual().start(() -> {
                while (!server.isClosed()) {
                    try {
                        Socket client = server.accept();
                        Thread.ofVirtual().start(() -> handle(client, served));    // one virtual thread per connection
                    } catch (IOException e) {
                        break;                                                       // server closed
                    }
                }
            });

            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(InetAddress.getLoopbackAddress(), port), 1000);   // connect timeout
                s.setSoTimeout(500);                                                              // read timeout
                var out = new PrintWriter(s.getOutputStream(), true, StandardCharsets.UTF_8);
                var in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                for (String msg : new String[] {"hello", "línea two", "quit"}) {
                    out.println(msg);
                    System.out.println("sent " + msg + " -> " + in.readLine());
                }
                System.out.println("after quit, readLine() = " + in.readLine() + " (end of stream)");
            }
            Thread[] clients = new Thread[500];                                    // 500 concurrent clients
            AtomicInteger ok = new AtomicInteger();
            for (int i = 0; i < clients.length; i++) {
                int id = i;
                clients[i] = Thread.ofVirtual().start(() -> {
                    try (Socket s = new Socket(InetAddress.getLoopbackAddress(), port)) {
                        var out = new PrintWriter(s.getOutputStream(), true, StandardCharsets.UTF_8);
                        var in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                        out.println("client " + id);
                        if (("ECHO client " + id).equals(in.readLine())) ok.incrementAndGet();
                    } catch (IOException e) { /* counted as a failure */ }
                });
            }
            for (Thread t : clients) t.join();
            System.out.println("500 concurrent clients: " + ok.get() + " correct echoes; connections served: " + served.get());

            try (Socket idle = new Socket(InetAddress.getLoopbackAddress(), port)) {
                idle.setSoTimeout(200);
                idle.getInputStream().read();                                       // the server sends nothing unprompted
            } catch (SocketTimeoutException e) {
                System.out.println("read with no data: SocketTimeoutException after 200 ms (without a timeout it would block forever)");
            }
        }
    }

    static void handle(Socket client, AtomicInteger served) {
        served.incrementAndGet();
        try (client;
             var in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
             var out = new PrintWriter(client.getOutputStream(), true, StandardCharsets.UTF_8)) {
            for (String line; (line = in.readLine()) != null && !line.equals("quit"); ) {
                out.println("ECHO " + line);
            }
            out.println("bye");
        } catch (IOException e) {
            // client went away
        }
    }
}
