// file: Http.java
import com.sun.net.httpserver.HttpServer;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;

public class Http {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.createContext("/hello", ex -> {
            String name = ex.getRequestURI().getQuery() == null ? "world" : ex.getRequestURI().getQuery().replace("name=", "");
            byte[] body = ("{\"greeting\":\"hello, " + name + "\"}").getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, body.length);
            try (var os = ex.getResponseBody()) { os.write(body); }
        });
        server.createContext("/echo", ex -> {
            byte[] in = ex.getRequestBody().readAllBytes();
            String reply = ex.getRequestMethod() + " " + in.length + " bytes: " + new String(in, StandardCharsets.UTF_8).toUpperCase();
            byte[] body = reply.getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(ex.getRequestMethod().equals("POST") ? 201 : 405, body.length);
            try (var os = ex.getResponseBody()) { os.write(body); }
        });
        server.createContext("/slow", ex -> {
            try { Thread.sleep(300); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            ex.sendResponseHeaders(204, -1);
            ex.close();
        });
        server.start();
        String base = "http://127.0.0.1:" + server.getAddress().getPort();

        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
        HttpResponse<String> r = client.send(HttpRequest.newBuilder(URI.create(base + "/hello?name=Java")).GET().build(), HttpResponse.BodyHandlers.ofString());
        System.out.println(r.statusCode() + " " + r.headers().firstValue("content-type").orElse("?") + " " + r.body() + " via " + r.version());

        HttpRequest post = HttpRequest.newBuilder(URI.create(base + "/echo")).header("Content-Type", "text/plain")
            .POST(HttpRequest.BodyPublishers.ofString("some payload")).build();
        System.out.println(client.send(post, HttpResponse.BodyHandlers.ofString()).statusCode() + " " + client.send(post, HttpResponse.BodyHandlers.ofString()).body());
        System.out.println("missing path: " + client.send(HttpRequest.newBuilder(URI.create(base + "/nope")).build(), HttpResponse.BodyHandlers.ofString()).statusCode());

        long t = System.nanoTime();
        List<CompletableFuture<Integer>> calls = java.util.stream.IntStream.range(0, 20)
            .mapToObj(i -> client.sendAsync(HttpRequest.newBuilder(URI.create(base + "/slow")).build(), HttpResponse.BodyHandlers.discarding())
                .thenApply(HttpResponse::statusCode)).toList();
        CompletableFuture.allOf(calls.toArray(CompletableFuture[]::new)).join();
        System.out.println("20 async calls to a 300 ms endpoint: all " + calls.get(0).join() + ", total " + (System.nanoTime() - t) / 1_000_000 / 100 * 100 + " ms");

        try {
            client.send(HttpRequest.newBuilder(URI.create(base + "/slow")).timeout(Duration.ofMillis(100)).build(), HttpResponse.BodyHandlers.discarding());
        } catch (HttpTimeoutException e) {
            System.out.println("request timeout: " + e.getMessage());
        }
        server.stop(0);
    }
}
