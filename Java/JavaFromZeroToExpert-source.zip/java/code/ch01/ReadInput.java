// file: ReadInput.java
import java.util.Locale;
import java.util.Scanner;

public class ReadInput {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in).useLocale(Locale.ROOT);   // '.' as the decimal point everywhere
        System.out.print("How many items? ");
        int n = in.nextInt();
        double total = 0;
        for (int i = 0; i < n; i++) {
            String name = in.next();                 // one whitespace-separated token
            double price = in.nextDouble();
            System.out.printf("%n  %s costs %.2f", name, price);
            total += price;
        }
        in.nextLine();                               // consume the rest of the current line!
        System.out.print("%nYour name? ".formatted());
        String who = in.nextLine();
        System.out.printf("%nTotal for %s: %.2f%n", who, total);
        if (!in.hasNextInt()) System.out.println("no more numbers: hasNextInt() is false");
    }
}
