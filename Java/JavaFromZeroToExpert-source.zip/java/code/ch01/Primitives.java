// file: Primitives.java
public class Primitives {
    public static void main(String[] args) {
        int big = Integer.MAX_VALUE;
        System.out.println("MAX_VALUE + 1 = " + (big + 1));                  // wraps to MIN_VALUE
        try {
            System.out.println(Math.addExact(big, 1));
        } catch (ArithmeticException e) {
            System.out.println("Math.addExact: " + e.getMessage());
        }
        System.out.println("-7 / 2 = " + (-7 / 2) + ", -7 % 2 = " + (-7 % 2) + ", Math.floorMod(-7, 2) = " + Math.floorMod(-7, 2));
        System.out.println("-8 >> 1 = " + (-8 >> 1) + ", -8 >>> 28 = " + (-8 >>> 28));      // arithmetic vs logical shift
        System.out.println("1 << 33 = " + (1 << 33) + " (shift distance is taken mod 32)");
        System.out.println("(byte) 200 = " + (byte) 200 + ", (int) 3.99 = " + (int) 3.99 + ", (int) -3.99 = " + (int) -3.99);
        System.out.println("(int) 1e10 = " + (int) 1e10 + ", (int) Double.NaN = " + (int) Double.NaN);
        System.out.println("0.1 + 0.2 = " + (0.1 + 0.2) + ", 1.0 / 0 = " + (1.0 / 0) + ", 0.0 / 0 = " + (0.0 / 0));
        long bytes = 3_000_000_000L;                                          // L suffix: a long literal
        System.out.println("unsigned view of -1: " + Integer.toUnsignedString(-1) + ", bytes = " + bytes);
        char c = 'A';
        c += 2;                                                               // compound assignment casts back to char
        System.out.println("char arithmetic: " + c + " " + (c + 1) + " " + (char) (c + 1));
    }
}
