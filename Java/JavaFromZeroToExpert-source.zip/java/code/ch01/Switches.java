// file: Switches.java
public class Switches {
    enum Day { MON, TUE, WED, THU, FRI, SAT, SUN }

    static int letters(Day d) {
        return switch (d) {                               // exhaustive over the enum: no default needed
            case MON, FRI, SUN -> 6;
            case TUE -> 7;
            case THU, SAT -> 8;
            case WED -> {
                int n = "WEDNESDAY".length();
                yield n;                                  // value of a block arm
            }
        };
    }

    static String classic(int month) {
        String season;
        switch (month) {                                  // old-style statement: falls through!
            case 12: case 1: case 2: season = "winter"; break;
            case 3: case 4: case 5: season = "spring";    // missing break...
            case 6: case 7: case 8: season = "summer"; break;
            default: season = "autumn";
        }
        return season;
    }

    public static void main(String[] args) {
        for (Day d : Day.values()) {
            System.out.print(d + "=" + letters(d) + " ");
        }
        System.out.println();
        System.out.println("April is " + classic(4) + " (the fall-through bug)");
        outer:
        for (int i = 2; i < 50; i++) {
            for (int j = 2; j * j <= i; j++) {
                if (i % j == 0) continue outer;           // not prime: next i
            }
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
