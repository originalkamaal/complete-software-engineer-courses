// file: FastSum.java
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class FastSum {
    public static void main(String[] args) throws IOException {
        long t0 = System.nanoTime(), sum = 0;
        if (args.length > 0 && args[0].equals("scanner")) {
            Scanner sc = new Scanner(System.in);
            while (sc.hasNextLong()) sum += sc.nextLong();
        } else {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = br.readLine()) != null) {
                for (String tok : line.trim().split("\\s+")) if (!tok.isEmpty()) sum += Long.parseLong(tok);
            }
        }
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("sum = " + sum + (ms < 100_000 ? "" : " (slow)"));
        System.err.println((args.length > 0 ? args[0] : "bufferedreader") + ": " + ms + " ms");
    }
}
