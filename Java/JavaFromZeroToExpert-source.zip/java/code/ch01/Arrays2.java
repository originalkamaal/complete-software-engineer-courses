// file: Arrays2.java
import java.util.Arrays;

public class Arrays2 {
    public static void main(String[] args) {
        int[] a = {5, 3, 9, 1};
        int[] b = {5, 3, 9, 1};
        System.out.println("a == b: " + (a == b) + ", a.equals(b): " + a.equals(b) + ", Arrays.equals: " + Arrays.equals(a, b));
        System.out.println("toString on an array starts with: " + a.toString().substring(0, 3));
        System.out.println("Arrays.toString: " + Arrays.toString(a));
        int[] copy = Arrays.copyOf(a, 6);                  // padded with zeros
        Arrays.sort(a);
        System.out.println("sorted " + Arrays.toString(a) + ", copy " + Arrays.toString(copy)
                           + ", binarySearch(9) = " + Arrays.binarySearch(a, 9));
        int[][] tri = new int[4][];
        for (int i = 0; i < tri.length; i++) {
            tri[i] = new int[i + 1];
            tri[i][0] = tri[i][i] = 1;
            for (int j = 1; j < i; j++) tri[i][j] = tri[i - 1][j - 1] + tri[i - 1][j];
        }
        System.out.println("Pascal rows: " + Arrays.deepToString(tri));
        Object[] objs = new String[1];
        try {
            objs[0] = 42;                                  // compiles: arrays are covariant
        } catch (ArrayStoreException e) {
            System.out.println("ArrayStoreException: " + e.getMessage());
        }
    }
}
