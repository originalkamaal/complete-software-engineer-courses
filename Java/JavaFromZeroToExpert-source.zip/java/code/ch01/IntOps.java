// file: IntOps.java
public class IntOps {
    public static void main(String[] args) {
        System.out.println("-7 / 2 = " + (-7 / 2) + ", -7 % 2 = " + (-7 % 2));
        System.out.println("floorDiv = " + Math.floorDiv(-7, 2) + ", floorMod = " + Math.floorMod(-7, 2));
        int n = -3;
        System.out.println("n % 2 == 1 says odd? " + (n % 2 == 1) + "; n % 2 != 0 says odd? " + (n % 2 != 0));
        System.out.println("Integer.MAX_VALUE + 1 = " + (Integer.MAX_VALUE + 1));
        try {
            Math.addExact(Integer.MAX_VALUE, 1);
        } catch (ArithmeticException e) {
            System.out.println("addExact: " + e.getMessage());
        }
        long big = 3_000_000_000L;
        System.out.println("(int) 3e9 = " + (int) big + ", Math.toIntExact throws: " + throwsOn(() -> Math.toIntExact(big)));
        System.out.println("1 / 0.0 = " + (1 / 0.0) + ", 0.0 / 0.0 = " + (0.0 / 0.0));
        System.out.println("1 / 0 throws: " + throwsOn(() -> { int zero = 0; return 1 / zero; }));
        System.out.println("Math.abs(Integer.MIN_VALUE) = " + Math.abs(Integer.MIN_VALUE));
    }
    interface IntCall { int call(); }
    static boolean throwsOn(IntCall c) {
        try { c.call(); return false; } catch (ArithmeticException e) { return true; }
    }
}
