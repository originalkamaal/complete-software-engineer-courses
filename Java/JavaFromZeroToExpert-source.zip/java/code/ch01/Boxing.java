// file: Boxing.java
import java.util.HashMap;
import java.util.Map;

public class Boxing {
    public static void main(String[] args) {
        Integer a = 127, b = 127;
        Integer c = 1000, d = 1000;
        System.out.println("127 == 127: " + (a == b) + ", 1000 == 1000: " + (c == d) + ", 1000 equals 1000: " + c.equals(d));
        Long l = 1000L;
        System.out.println("Integer(1000).equals(Long(1000)): " + c.equals(l) + ", but c == 1000L: " + (c == 1000L));

        Map<String, Integer> stock = new HashMap<>();
        stock.put("apples", 3);
        int apples = stock.get("apples");                   // unboxing: fine
        System.out.println("apples = " + apples);
        int pears = stock.get("pears");                     // get returns null: unboxing throws
        System.out.println("pears = " + pears);
    }
}
