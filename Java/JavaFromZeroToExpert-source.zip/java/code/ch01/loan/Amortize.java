// file: loan/Amortize.java
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class Amortize {
    static final MathContext MC = new MathContext(34, RoundingMode.HALF_EVEN);   // decimal128 precision

    /** The fixed monthly payment: P * r / (1 - (1 + r)^-n), rounded to the cent. */
    static BigDecimal payment(BigDecimal principal, BigDecimal monthlyRate, int months) {
        BigDecimal onePlusR = BigDecimal.ONE.add(monthlyRate);
        BigDecimal factor = BigDecimal.ONE.subtract(BigDecimal.ONE.divide(onePlusR.pow(months, MC), MC));
        return principal.multiply(monthlyRate).divide(factor, MC).setScale(2, RoundingMode.HALF_EVEN);
    }

    public static void main(String[] args) {
        BigDecimal principal = new BigDecimal(args.length > 0 ? args[0] : "250000.00");
        BigDecimal annualRate = new BigDecimal(args.length > 1 ? args[1] : "0.0675");
        int months = args.length > 2 ? Integer.parseInt(args[2]) : 360;
        BigDecimal r = annualRate.divide(BigDecimal.valueOf(12), MC);
        BigDecimal pay = payment(principal, r, months);
        System.out.printf("loan %s at %s%% for %d months: payment %s%n", principal, annualRate.movePointRight(2), months, pay);
        System.out.printf("%5s %12s %12s %12s %14s%n", "month", "payment", "interest", "principal", "balance");

        BigDecimal balance = principal, totalInterest = BigDecimal.ZERO;
        double dBalance = principal.doubleValue(), dRate = annualRate.doubleValue() / 12, dPay = pay.doubleValue(), dInterestTotal = 0;
        for (int m = 1; m <= months; m++) {
            BigDecimal interest = balance.multiply(r).setScale(2, RoundingMode.HALF_EVEN);
            BigDecimal thisPay = (m == months) ? balance.add(interest) : pay;      // last payment clears the balance
            BigDecimal toPrincipal = thisPay.subtract(interest);
            balance = balance.subtract(toPrincipal);
            totalInterest = totalInterest.add(interest);

            double dInterest = dBalance * dRate;                                  // the same steps in double
            dInterestTotal += dInterest;
            dBalance -= ((m == months) ? dBalance + dInterest : dPay) - dInterest;

            if (m <= 3 || m > months - 3 || m % 60 == 0) {
                System.out.printf("%5d %12s %12s %12s %14s%n", m, thisPay, interest, toPrincipal, balance);
            } else if (m == 4) {
                System.out.printf("%5s%n", "...");
            }
        }
        System.out.println("final balance (BigDecimal): " + balance + ", total interest " + totalInterest);
        System.out.printf("final balance (double):     %.10f, total interest %.10f%n", dBalance, dInterestTotal);
        System.out.println("new BigDecimal(0.1) = " + new BigDecimal(0.1));
        System.out.println("BigDecimal.valueOf(0.1) = " + BigDecimal.valueOf(0.1)
                + "; 2.0 equals 2.00? " + new BigDecimal("2.0").equals(new BigDecimal("2.00"))
                + "; compareTo == 0? " + (new BigDecimal("2.0").compareTo(new BigDecimal("2.00")) == 0));
    }
}
