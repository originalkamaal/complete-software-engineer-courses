// file: Strings2.java
import java.util.stream.Collectors;

public class Strings2 {
    public static void main(String[] args) {
        long t0 = System.nanoTime();
        String s = "";
        for (int i = 0; i < 20_000; i++) s += i % 10;
        long concat = System.nanoTime() - t0;
        t0 = System.nanoTime();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20_000; i++) sb.append(i % 10);
        long builder = System.nanoTime() - t0;
        System.out.println("same result: " + s.equals(sb.toString()) + ", StringBuilder faster: " + (builder < concat));

        String json = """
            {
              "name": "ada",
              "langs": ["java", "c"]
            }
            """;
        System.out.print(json);
        System.out.println("lines: " + json.lines().count() + ", first line stripped: " + json.lines().findFirst().get().strip());
        System.out.println("'   '.isBlank() = " + "   ".isBlank() + ", '-'.repeat(5) = " + "-".repeat(5));
        System.out.println(String.join("|", "a", "b", "c") + " " + "a,b,,c".split(",").length
                           + " " + "a,b,,c,,".split(",").length);
        System.out.println("%s has %d chars".formatted("hello", "hello".length()));
        System.out.println("hello".chars().mapToObj(c -> String.valueOf((char) c)).collect(Collectors.joining(".")));
    }
}
