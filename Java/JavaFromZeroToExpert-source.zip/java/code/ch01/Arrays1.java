// file: Arrays1.java
import java.util.Arrays;

public class Arrays1 {
    public static void main(String[] args) {
        var counts = new int[5];                          // var: inferred int[]
        var names = new String[3];                        // elements are null
        int[] primes = {2, 3, 5, 7, 11};
        int[] alias = primes;                             // same array
        int[] copy = Arrays.copyOf(primes, primes.length);
        System.out.println("primes == copy: " + (primes == copy) + ", Arrays.equals: " + Arrays.equals(primes, copy)
                + ", primes.equals(copy): " + primes.equals(copy));
        alias[0] = 99;                                    // changes primes too: same array
        System.out.println(Arrays.toString(counts) + " " + Arrays.toString(names) + " primes=" + Arrays.toString(primes) + " copy=" + Arrays.toString(copy));

        int[][] grid = new int[3][4];                     // an array of 3 arrays of 4 ints
        grid[1][2] = 7;
        int[][] jagged = {{1}, {2, 3}, {4, 5, 6}};
        System.out.println(Arrays.deepToString(grid) + " " + Arrays.deepToString(jagged));
        Integer[] boxed = {5, 3, 9, 1};
        Arrays.sort(boxed, (x, y) -> y - x);              // descending, with a comparator
        System.out.println(Arrays.toString(boxed) + ", sum of primes via stream: " + Arrays.stream(copy).sum());
        System.out.println(primes[primes.length]);        // one past the end
    }
}
