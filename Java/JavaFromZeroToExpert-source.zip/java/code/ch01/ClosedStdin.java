// file: ClosedStdin.java
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ClosedStdin {
    static int readOne() {
        try (Scanner sc = new Scanner(System.in)) {   // try-with-resources closes System.in on exit
            return sc.nextInt();
        }
    }
    public static void main(String[] args) {
        System.out.println("first: " + readOne());
        try {
            System.out.println("second: " + readOne());
        } catch (NoSuchElementException e) {
            System.out.println("second read failed: " + e.getClass().getSimpleName());
        }
    }
}
