// file: Fallthrough.java
public class Fallthrough {
    enum Level { LOW, MEDIUM, HIGH }

    public static void main(String[] args) {
        int alerts = 0;
        Level l = Level.MEDIUM;
        switch (l) {
            case LOW:
                alerts += 1;
            case MEDIUM:
                alerts += 10;                 // forgot break
            case HIGH:
                alerts += 100;
        }
        System.out.println("old-style switch, MEDIUM: alerts = " + alerts);

        int arrow = switch (l) {
            case LOW -> 1;
            case MEDIUM -> 10;
            case HIGH -> 100;                 // remove this line: compile error, not exhaustive
        };
        System.out.println("switch expression, MEDIUM: " + arrow);
    }
}
