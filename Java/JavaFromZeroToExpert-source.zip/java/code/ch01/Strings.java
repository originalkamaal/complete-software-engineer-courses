// file: Strings.java
public class Strings {
    public static void main(String[] args) {
        String s1 = "hello";
        String s2 = "hel" + "lo";                         // compile-time constant: the same interned object
        String part = "hel";
        String s3 = part + "lo";                          // built at run time: a new object
        System.out.println("s1 == s2: " + (s1 == s2) + ", s1 == s3: " + (s1 == s3) + ", s1.equals(s3): " + s1.equals(s3)
                + ", s1 == s3.intern(): " + (s1 == s3.intern()));

        String json = """
                {
                  "name": "Ada",
                  "langs": ["Java", "Rust"]
                }
                """;                                      // indentation up to the closing quotes is removed
        System.out.print(json);
        System.out.println("%s has %d lines, %d chars".formatted("json", json.lines().count(), json.length()));

        String word = "naïve🦀";
        System.out.println("length() = " + word.length() + ", code points = " + word.codePointCount(0, word.length())
                + ", charAt(5) = " + (int) word.charAt(5) + " and charAt(6) = " + (int) word.charAt(6) + " (the two halves of a surrogate pair)");
        word.codePoints().forEach(cp -> System.out.print(Character.toString(cp) + "|"));
        System.out.println();
        System.out.println("reversed with StringBuilder: " + new StringBuilder(word).reverse());

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(i).append(i < 4 ? "," : "");
        }
        System.out.println(sb + " | " + String.join("-", "a", "b", "c") + " | " + "  trim me  ".strip() + "|" + " x".repeat(3));
    }
}
