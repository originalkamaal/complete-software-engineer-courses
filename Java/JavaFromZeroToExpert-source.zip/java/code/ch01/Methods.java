// file: Methods.java
import java.util.ArrayList;
import java.util.List;

public class Methods {
    static void reassign(List<String> list) {
        list = new ArrayList<>(List.of("new"));          // changes the local copy of the reference only
    }

    static void mutate(List<String> list) {
        list.add("added");                                // changes the shared object
    }

    static void increment(int x) {
        x++;                                              // a copy of the int
    }

    static String describe(int x) { return "int"; }
    static String describe(long x) { return "long"; }
    static String describe(Integer x) { return "Integer"; }
    static String describe(Object x) { return "Object"; }
    static String describe(int... xs) { return "varargs[" + xs.length + "]"; }

    static double average(double first, double... rest) {   // at least one argument required
        double sum = first;
        for (double r : rest) sum += r;
        return sum / (1 + rest.length);
    }

    public static void main(String[] args) {
        List<String> items = new ArrayList<>(List.of("original"));
        reassign(items);
        mutate(items);
        int n = 5;
        increment(n);
        System.out.println(items + ", n = " + n);
        short s = 1;
        System.out.println(describe(1) + " " + describe(s) + " " + describe(1L) + " " + describe(Integer.valueOf(1))
                + " " + describe("x") + " " + describe() + " " + describe(1, 2));
        System.out.println(average(4) + " " + average(1, 2, 3, 4));
    }
}
