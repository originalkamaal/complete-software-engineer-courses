// file: Jit.java
public class Jit {
    record Vec(double x, double y) {
        Vec plus(Vec o) { return new Vec(x + o.x, y + o.y); }
        Vec scale(double k) { return new Vec(x * k, y * k); }
        double norm2() { return x * x + y * y; }
    }

    static double work(int n) {
        double acc = 0;
        for (int i = 0; i < n; i++) {
            Vec v = new Vec(i, i + 1).plus(new Vec(1, 1)).scale(0.5);     // three temporary objects per iteration
            acc += v.norm2();
        }
        return acc;
    }

    interface Shape { double area(); }
    record Sq(double s) implements Shape { public double area() { return s * s; } }
    record Circ(double r) implements Shape { public double area() { return 3.14159 * r * r; } }
    record Tri(double b, double h) implements Shape { public double area() { return 0.5 * b * h; } }

    static double total(Shape[] shapes) { double t = 0; for (Shape s : shapes) t += s.area(); return t; }

    static long allocatedBytes() {
        return ((com.sun.management.ThreadMXBean) java.lang.management.ManagementFactory.getThreadMXBean()).getCurrentThreadAllocatedBytes();
    }

    public static void main(String[] args) {
        for (int i = 0; i < 20; i++) work(100_000);                        // warm up: C2 compiles work()
        long a0 = allocatedBytes(), t0 = System.nanoTime();
        double r = work(50_000_000);
        long t1 = System.nanoTime(), a1 = allocatedBytes();
        System.out.printf("50M iterations creating 150M Vec objects in source: %d ms, %,d bytes actually allocated (result %.3e)%n", (t1 - t0) / 1_000_000, a1 - a0, r);

        Shape[] mono = new Shape[3000], mega = new Shape[3000];
        for (int i = 0; i < 3000; i++) {
            mono[i] = new Sq(i);
            mega[i] = i % 3 == 0 ? new Sq(i) : i % 3 == 1 ? new Circ(i) : new Tri(i, 2);
        }
        double sink = 0;
        long tm = 0, tg = 0;
        for (int round = 0; round < 6; round++) {
            long s = System.nanoTime();
            for (int k = 0; k < 20_000; k++) sink += total(mono);
            long m = System.nanoTime();
            for (int k = 0; k < 20_000; k++) sink += total(mega);
            tm = (m - s) / 1_000_000;
            tg = (System.nanoTime() - m) / 1_000_000;
        }
        System.out.printf("60M virtual calls: one receiver type %d ms, three receiver types %d ms (sink %.1e)%n", tm, tg, sink);
    }
}
