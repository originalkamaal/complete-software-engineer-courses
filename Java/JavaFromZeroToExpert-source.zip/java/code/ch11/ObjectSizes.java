// file: ObjectSizes.java
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ObjectSizes {
    static class Empty {}
    static class OneByte { byte b; }
    static class Mixed { byte a; long b; byte c; int d; }          // the JVM reorders fields to pack them
    record Point(int x, int y) {}

    static long used() {
        Runtime rt = Runtime.getRuntime();
        for (int i = 0; i < 3; i++) System.gc();
        return rt.totalMemory() - rt.freeMemory();
    }

    static double bytesPer(java.util.function.IntFunction<Object> make) {
        int n = 1_000_000;
        Object[] keep = new Object[n];
        long before = used();
        for (int i = 0; i < n; i++) keep[i] = make.apply(i);
        long after = used();
        if (keep[n - 1] == null) throw new AssertionError();
        return (after - before) / (double) n;
    }

    public static void main(String[] args) {
        System.out.printf("(measured from heap growth, so within a byte or so) Object %.0f, Empty %.0f, OneByte %.0f, Mixed %.0f, Point %.0f bytes%n",
                bytesPer(i -> new Object()), bytesPer(i -> new Empty()), bytesPer(i -> new OneByte()), bytesPer(i -> new Mixed()), bytesPer(i -> new Point(i, i)));
        System.out.printf("Integer %.0f, Long %.0f, int[0] %.0f, int[4] %.0f, String of 5 ASCII chars %.0f bytes%n",
                bytesPer(i -> Integer.valueOf(i + 1000)), bytesPer(i -> Long.valueOf(i + 1000L)), bytesPer(i -> new int[0]), bytesPer(i -> new int[4]),
                bytesPer(i -> String.valueOf(10000 + i % 80000)));
        int n = 1_000_000;
        long b0 = used();
        int[] prim = new int[n];
        long b1 = used();
        List<Integer> al = new ArrayList<>(n);
        for (int i = 0; i < n; i++) al.add(i + 1000);
        long b2 = used();
        List<Integer> ll = new LinkedList<>();
        for (int i = 0; i < n; i++) ll.add(i + 1000);
        long b3 = used();
        System.out.printf("one million ints: int[] %.1f MB, ArrayList<Integer> %.1f MB, LinkedList<Integer> %.1f MB%n",
                (b1 - b0) / 1e6, (b2 - b1) / 1e6, (b3 - b2) / 1e6);
        if (prim.length + al.size() + ll.size() == 0) throw new AssertionError();
    }
}
