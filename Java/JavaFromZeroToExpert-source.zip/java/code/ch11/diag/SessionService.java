// file: diag/SessionService.java
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SessionService {
    record Session(long id, String user, byte[] state, List<String> events) {}

    private final Map<Long, Session> sessions;
    private final boolean fixed;
    private long nextId = 1;

    SessionService(boolean fixed) {
        this.fixed = fixed;
        this.sessions = fixed
            ? new LinkedHashMap<>(1024, 0.75f, true) {                                  // bounded LRU (Chapter 6)
                @Override protected boolean removeEldestEntry(Map.Entry<Long, Session> e) { return size() > 5_000; }
            }
            : new HashMap<>();                                                           // BUG 1: grows forever
    }

    long login(String user) {
        long id = nextId++;
        sessions.put(id, new Session(id, user, new byte[2048], new ArrayList<>(List.of("login"))));
        return id;
    }

    void logout(long id) {
        if (fixed) sessions.remove(id);
        else sessions.get(id).events().add("logout");                                    // BUG 1: marks, never removes
    }

    /** A report of users by number of sessions. */
    String report() {
        return fixed ? reportFast() : reportSlow();
    }

    private String reportSlow() {
        String out = "";
        List<String> users = new ArrayList<>();
        for (Session s : sessions.values()) {
            if (!users.contains(s.user())) users.add(s.user());                          // BUG 2a: O(n) lookup in a list
        }
        for (String u : users) {
            int count = 0;
            for (Session s : sessions.values()) if (s.user().equals(u)) count++;         // BUG 2b: rescans all sessions per user
            out += u + "=" + count + ";";                                                // BUG 2c: quadratic string building
        }
        return out;
    }

    private String reportFast() {
        Map<String, Integer> counts = new java.util.TreeMap<>();
        for (Session s : sessions.values()) counts.merge(s.user(), 1, Integer::sum);
        StringBuilder sb = new StringBuilder();
        counts.forEach((u, c) -> sb.append(u).append('=').append(c).append(';'));
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        boolean fixed = args.length > 0 && args[0].equals("fixed");
        int rounds = args.length > 1 ? Integer.parseInt(args[1]) : 60;
        SessionService svc = new SessionService(fixed);
        long reportNanos = 0;
        int reportLength = 0;
        for (int round = 1; round <= rounds; round++) {
            for (int i = 0; i < 2_000; i++) {
                long id = svc.login("user" + (i * 7919 + round) % 800);
                if (i % 10 != 0) svc.logout(id);                                         // 90% log out again
            }
            long t = System.nanoTime();
            reportLength = svc.report().length();
            reportNanos += System.nanoTime() - t;
            if (round % 10 == 0) {
                Runtime rt = Runtime.getRuntime();
                System.gc();
                System.out.printf("round %3d: %,7d sessions held, heap used after GC %4d MB, report() avg %.1f ms%n",
                        round, svc.sessions.size(), (rt.totalMemory() - rt.freeMemory()) >> 20, reportNanos / 1e6 / round);
            }
            if (round == rounds && args.length > 2) {                                    // pause so jcmd can inspect the live process
                System.out.println("ready " + ProcessHandle.current().pid());
                Thread.sleep(Long.parseLong(args[2]));
            }
        }
        System.out.println("report length " + reportLength);
    }
}
