// file: Escape.java
import java.lang.management.ManagementFactory;

public class Escape {
    record Point(double x, double y) { double len() { return Math.sqrt(x * x + y * y); } }

    static double sum(int n) {
        double s = 0;
        for (int i = 0; i < n; i++) s += new Point(i, i + 1).len();   // the Point never escapes
        return s;
    }

    static long allocatedBytes() {
        return ((com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean()).getCurrentThreadAllocatedBytes();
    }

    public static void main(String[] args) {
        for (int i = 0; i < 20; i++) sum(100_000);                     // warm up: let the JIT compile sum
        long before = allocatedBytes();
        double r = sum(10_000_000);
        long after = allocatedBytes();
        System.out.printf("result %.3e, bytes allocated for 10 million Points: %s%n", r,
                          (after - before) < 1_000_000 ? "almost none (scalar-replaced)" : (after - before) / 1_000_000 + " MB");
    }
}
