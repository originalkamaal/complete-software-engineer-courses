// file: GcDemo.java
import java.util.ArrayList;
import java.util.List;

public class GcDemo {
    static byte[] last;                                     // storing here makes each array escape (see Unit 11.3)

    public static void main(String[] args) {
        List<byte[]> longLived = new ArrayList<>();
        long checksum = 0;
        for (int i = 0; i < 3_000_000; i++) {
            byte[] temp = new byte[256];                    // short-lived garbage: dies in eden
            temp[0] = (byte) i;
            last = temp;
            checksum += temp[0];
            if (i % 100 == 0) longLived.add(new byte[1024]);   // 1% survive and get promoted: ~30 MB in total
        }
        System.out.println("allocated about " + (3_000_000L * 272 / 1_000_000) + " MB of short-lived objects; kept " + longLived.size() + " KiB-sized arrays; checksum " + checksum);
    }
}
