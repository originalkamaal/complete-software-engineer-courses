// file: Busy.java
import java.util.ArrayList;
import java.util.List;

public class Busy {
    static final List<byte[]> cache = new ArrayList<>();               // a "leak"
    static final Object lock = new Object();

    public static void main(String[] args) throws InterruptedException {
        Thread.ofPlatform().name("stuck-worker").start(() -> {
            synchronized (lock) { try { lock.wait(); } catch (InterruptedException e) {} }
        });
        for (int i = 0; i < 2000; i++) cache.add(new byte[1024]);
        System.out.println("ready");
        Thread.sleep(30_000);
    }
}
