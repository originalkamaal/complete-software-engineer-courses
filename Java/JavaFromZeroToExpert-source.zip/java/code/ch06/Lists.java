// file: Lists.java
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Lists {
    static long time(Runnable r) {
        long t = System.nanoTime();
        r.run();
        return (System.nanoTime() - t) / 1_000_000;
    }

    static void fill(List<Integer> l, int n) { for (int i = 0; i < n; i++) l.add(i); }

    static long sum(List<Integer> l) { long s = 0; for (int x : l) s += x; return s; }

    static void insertInMiddle(List<Integer> l, int n) { for (int i = 0; i < n; i++) l.add(l.size() / 2, i); }

    static void insertWithIterator(List<Integer> l, int n) {       // LinkedList's one real strength
        ListIterator<Integer> it = l.listIterator(l.size() / 2);
        for (int i = 0; i < n; i++) it.add(i);
    }

    public static void main(String[] args) {
        for (int round = 0; round < 2; round++) {                   // round 0 warms up the JIT
            int n = 3_000_000;
            List<Integer> a = new ArrayList<>(), l = new LinkedList<>();
            long fa = time(() -> fill(a, n)), fl = time(() -> fill(l, n));
            long sa = time(() -> sum(a)), sl = time(() -> sum(l));
            List<Integer> a2 = new ArrayList<>(), l2 = new LinkedList<>();
            fill(a2, 100_000); fill(l2, 100_000);
            long ma = time(() -> insertInMiddle(a2, 20_000)), ml = time(() -> insertInMiddle(l2, 20_000));
            List<Integer> l3 = new LinkedList<>(); fill(l3, 100_000);
            long il = time(() -> insertWithIterator(l3, 20_000));
            if (round == 1) {
                System.out.printf("append 3M:              ArrayList %4d ms, LinkedList %4d ms%n", fa, fl);
                System.out.printf("iterate 3M:             ArrayList %4d ms, LinkedList %4d ms%n", sa, sl);
                System.out.printf("20k inserts at middle:  ArrayList %4d ms, LinkedList %4d ms (via index), %d ms (via ListIterator)%n", ma, ml, il);
            }
        }
    }
}
