// file: AsList.java
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AsList {
    public static void main(String[] args) {
        String[] arr = {"a", "b", "c"};
        List<String> view = Arrays.asList(arr);
        view.set(0, "z");
        System.out.println("array after set on the list: " + Arrays.toString(arr));
        try { view.add("d"); } catch (UnsupportedOperationException e) { System.out.println("add: UnsupportedOperationException"); }
        List<String> fixed = List.of("x", "y");
        try { fixed.contains(null); } catch (NullPointerException e) { System.out.println("List.of(...).contains(null): NullPointerException"); }
        List<String> growable = new ArrayList<>(view);
        growable.add("d");
        System.out.println("copy is growable: " + growable);
    }
}
