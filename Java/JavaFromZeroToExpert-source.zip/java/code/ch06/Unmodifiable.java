// file: Unmodifiable.java
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Unmodifiable {
    public static void main(String[] args) {
        List<String> source = new ArrayList<>(List.of("a", "b"));
        List<String> view = Collections.unmodifiableList(source);
        List<String> copy = List.copyOf(source);
        source.add("c");
        System.out.println("view sees the change: " + view + ", copy does not: " + copy);

        String[] array = {"x", "y", "z"};
        List<String> asList = Arrays.asList(array);
        asList.set(0, "changed");                                   // writes through to the array
        System.out.println("array[0] = " + array[0]);
        for (Runnable r : new Runnable[] {() -> asList.add("w"), () -> copy.add("d"), () -> List.of(1, null)}) {
            try {
                r.run();
            } catch (UnsupportedOperationException | NullPointerException e) {
                System.out.println(e.getClass().getSimpleName());
            }
        }
        List<Integer> nums = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        nums.subList(1, 4).clear();                                 // a view: clearing it removes the range
        System.out.println("after subList(1,4).clear(): " + nums);
    }
}
