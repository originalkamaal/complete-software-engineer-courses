// file: HashMapInside.java
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class HashMapInside {
    record BadKey(int id) {
        @Override public int hashCode() { return 1; }               // every key in one bucket
    }
    record BadComparableKey(int id) implements Comparable<BadComparableKey> {
        @Override public int hashCode() { return 1; }
        @Override public int compareTo(BadComparableKey o) { return Integer.compare(id, o.id); }
    }
    record GoodKey(int id) {}

    static long timeLookups(Map<Object, Integer> m, java.util.function.IntFunction<Object> key, int n) {
        for (int i = 0; i < n; i++) m.put(key.apply(i), i);
        long t = System.nanoTime();
        long sum = 0;
        for (int i = 0; i < n; i++) sum += m.get(key.apply(i));
        return (System.nanoTime() - t) / 1_000_000;
    }

    public static void main(String[] args) {
        int n = 20_000;
        System.out.println("20k lookups, good hashCode:                 " + timeLookups(new HashMap<>(), GoodKey::new, n) + " ms");
        System.out.println("20k lookups, constant hashCode, Comparable: " + timeLookups(new HashMap<>(), BadComparableKey::new, n) + " ms (bucket became a tree)");
        System.out.println("20k lookups, constant hashCode:             " + timeLookups(new HashMap<>(), BadKey::new, n) + " ms (tree cannot order the keys)");

        Map<String, Integer> hash = new HashMap<>(), linked = new LinkedHashMap<>(), tree = new TreeMap<>();
        for (String w : "the quick brown fox jumps over the lazy dog".split(" ")) {
            for (Map<String, Integer> m : java.util.List.of(hash, linked, tree)) m.merge(w, 1, Integer::sum);
        }
        System.out.println("HashMap:       " + hash + "\nLinkedHashMap: " + linked + "\nTreeMap:       " + tree);
        System.out.println("getOrDefault: " + hash.getOrDefault("cat", 0) + ", computeIfAbsent: "
                + new HashMap<String, java.util.List<Integer>>().computeIfAbsent("k", k -> new java.util.ArrayList<>()));
    }
}
