// file: Cme.java
import java.util.ArrayList;
import java.util.List;

public class Cme {
    public static void main(String[] args) {
        List<Integer> a = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        try {
            for (Integer x : a) if (x % 2 == 0) a.remove(x);
        } catch (java.util.ConcurrentModificationException e) {
            System.out.println("for-each + remove: ConcurrentModificationException, list left as " + a);
        }
        List<Integer> b = new ArrayList<>(List.of(1, 2, 3, 4));
        for (Integer x : b) if (x == 3) b.remove(x);              // second-to-last: no exception, 4 is skipped
        System.out.println("removing the second-to-last element silently skipped the last: " + b);
        List<Integer> c = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        c.removeIf(x -> x % 2 == 0);
        System.out.println("removeIf: " + c);
        List<Integer> d = new ArrayList<>(List.of(10, 20, 30));
        d.remove(1);                                              // remove(int index)!
        d.remove(Integer.valueOf(10));                            // remove(Object)
        System.out.println("remove(1) removed index 1, remove(Integer.valueOf(10)) removed the value: " + d);
    }
}
