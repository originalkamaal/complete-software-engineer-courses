// file: lru/Index.java
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class Index {
    private final Map<String, TreeSet<Integer>> postings = new HashMap<>();
    private final List<String> docs = new ArrayList<>();

    int add(String text) {
        int id = docs.size();
        docs.add(text);
        for (String w : text.toLowerCase().split("[^a-z0-9]+")) {
            if (!w.isEmpty()) postings.computeIfAbsent(w, k -> new TreeSet<>()).add(id);
        }
        return id;
    }

    /** Documents containing every word: intersect posting sets, smallest first. */
    List<Integer> search(String query) {
        List<TreeSet<Integer>> sets = new ArrayList<>();
        for (String w : query.toLowerCase().split("\\s+")) {
            TreeSet<Integer> s = postings.get(w);
            if (s == null) return List.of();                     // a word that appears nowhere
            sets.add(s);
        }
        sets.sort(Comparator.comparingInt(TreeSet::size));       // start from the rarest word
        TreeSet<Integer> result = new TreeSet<>(sets.get(0));
        for (int i = 1; i < sets.size(); i++) result.retainAll(sets.get(i));
        return List.copyOf(result);
    }

    public static void main(String[] args) {
        Index idx = new Index();
        for (String d : List.of("The quick brown fox", "A quick study of Java collections", "Brown bears and the quick river",
                "Java maps: HashMap, TreeMap, LinkedHashMap", "The fox studies Java")) {
            idx.add(d);
        }
        for (String q : List.of("quick", "quick brown", "java", "java fox", "the quick", "python")) {
            List<Integer> hits = idx.search(q);
            System.out.printf("%-12s -> %s %s%n", q, hits, hits.stream().map(i -> "\"" + idx.docs.get(i) + "\"").toList());
        }
        System.out.println("distinct words indexed: " + idx.postings.size());
    }
}
