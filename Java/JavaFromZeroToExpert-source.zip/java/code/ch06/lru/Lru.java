// file: lru/Lru.java
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Lru {
    /** LRU in six lines: LinkedHashMap in access order, evicting in removeEldestEntry. */
    static class SimpleLru<K, V> extends LinkedHashMap<K, V> {
        private final int capacity;
        SimpleLru(int capacity) {
            super(16, 0.75f, true);                       // true = access order
            this.capacity = capacity;
        }
        @Override protected boolean removeEldestEntry(Map.Entry<K, V> eldest) { return size() > capacity; }
    }

    /** The same from scratch: a hash map for lookup plus a doubly linked list for recency. */
    static class HandLru<K, V> {
        private final class Node {
            K key; V value; Node prev, next;
        }
        private final Map<K, Node> map = new HashMap<>();
        private final Node head = new Node(), tail = new Node();   // sentinels: head.next is most recent
        private final int capacity;
        int evictions = 0;

        HandLru(int capacity) {
            this.capacity = capacity;
            head.next = tail;
            tail.prev = head;
        }

        V get(K key) {
            Node n = map.get(key);
            if (n == null) return null;
            unlink(n);
            linkFirst(n);                                   // O(1) move to front
            return n.value;
        }

        void put(K key, V value) {
            Node n = map.get(key);
            if (n == null) {
                if (map.size() == capacity) {               // evict the least recently used: tail.prev
                    Node lru = tail.prev;
                    unlink(lru);
                    map.remove(lru.key);
                    evictions++;
                }
                n = new Node();
                n.key = key;
                map.put(key, n);
            } else {
                unlink(n);
            }
            n.value = value;
            linkFirst(n);
        }

        private void unlink(Node n) { n.prev.next = n.next; n.next.prev = n.prev; }
        private void linkFirst(Node n) { n.next = head.next; n.prev = head; head.next.prev = n; head.next = n; }

        String order() {
            StringBuilder sb = new StringBuilder("[");
            for (Node n = tail.prev; n != head; n = n.prev) sb.append(n.key).append(n.prev != head ? ", " : "");
            return sb.append("]").toString();
        }
    }

    public static void main(String[] args) {
        SimpleLru<String, Integer> simple = new SimpleLru<>(3);
        HandLru<String, Integer> hand = new HandLru<>(3);
        String[] ops = {"put a", "put b", "put c", "get a", "put d", "get b", "put e", "get c", "put a"};
        for (String op : ops) {
            String key = op.substring(4);
            if (op.startsWith("put")) { simple.put(key, 1); hand.put(key, 1); }
            else { simple.get(key); hand.get(key); }
            System.out.printf("%-6s LinkedHashMap %-10s hand-made %s%n", op, simple.keySet(), hand.order());
        }
        // agreement on a long random workload
        SimpleLru<Integer, Integer> s2 = new SimpleLru<>(100);
        HandLru<Integer, Integer> h2 = new HandLru<>(100);
        java.util.Random rnd = new java.util.Random(7);
        int mismatches = 0;
        for (int i = 0; i < 200_000; i++) {
            int k = (int) Math.abs(rnd.nextGaussian() * 80);
            if (rnd.nextInt(3) == 0) { s2.put(k, i); h2.put(k, i); }
            else if (!java.util.Objects.equals(s2.get(k), h2.get(k))) mismatches++;
        }
        System.out.println("200,000 random operations: " + mismatches + " mismatches, " + h2.evictions + " evictions, same final order: "
                + s2.keySet().toString().equals(h2.order()));
    }
}
