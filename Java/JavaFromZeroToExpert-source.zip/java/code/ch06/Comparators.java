// file: Comparators.java
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Comparators {
    record Employee(String name, String dept, int salary) {}

    public static void main(String[] args) {
        List<Employee> staff = new ArrayList<>(List.of(
            new Employee("ravi", "eng", 90), new Employee("ada", "eng", 120),
            new Employee("lin", "ops", 90), new Employee("bo", "eng", 90)));
        staff.sort(Comparator.comparing(Employee::dept)
                             .thenComparing(Employee::salary, Comparator.reverseOrder())
                             .thenComparing(Employee::name));
        staff.forEach(e -> System.out.println(e.dept() + " " + e.salary() + " " + e.name()));

        Comparator<Integer> bySubtraction = (a, b) -> a - b;           // the classic bug
        int a = Integer.MIN_VALUE, b = 1;
        System.out.println("subtraction says MIN_VALUE > 1: " + (bySubtraction.compare(a, b) > 0)
                           + "; Integer.compare says: " + (Integer.compare(a, b) > 0));
        List<String> withNull = new ArrayList<>(java.util.Arrays.asList("b", null, "a"));
        withNull.sort(Comparator.nullsLast(Comparator.naturalOrder()));
        System.out.println(withNull);
    }
}
