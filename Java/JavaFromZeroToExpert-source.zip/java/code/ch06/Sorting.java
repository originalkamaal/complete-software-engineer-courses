// file: Sorting.java
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeMap;

public class Sorting {
    record Employee(String name, String dept, int salary, Integer bonus) {}

    public static void main(String[] args) {
        List<Employee> staff = new ArrayList<>(List.of(
            new Employee("Mia", "eng", 120, 10), new Employee("Raj", "ops", 90, null), new Employee("Zoe", "eng", 120, 5),
            new Employee("Ben", "ops", 95, 7), new Employee("Ann", "eng", 150, null)));
        staff.sort(Comparator.comparing(Employee::dept).thenComparing(Employee::salary, Comparator.reverseOrder()).thenComparing(Employee::name));
        staff.forEach(e -> System.out.print(e.dept() + "/" + e.salary() + "/" + e.name() + "  "));
        System.out.println();
        staff.sort(Comparator.comparing(Employee::bonus, Comparator.nullsLast(Comparator.naturalOrder())));
        System.out.println("by bonus, nulls last: " + staff.stream().map(e -> e.name() + "=" + e.bonus()).toList());

        Comparator<Integer> broken = (a, b) -> a - b;              // overflows for distant values
        System.out.println("a - b comparator says MIN_VALUE vs 1: " + broken.compare(Integer.MIN_VALUE, 1) + " (should be negative); Integer.compare: "
                + Integer.compare(Integer.MIN_VALUE, 1));

        PriorityQueue<Employee> bySalary = new PriorityQueue<>(Comparator.comparingInt(Employee::salary).reversed());
        bySalary.addAll(staff);
        System.out.println("top 2 earners: " + bySalary.poll().name() + ", " + bySalary.poll().name());
        TreeMap<Integer, String> grades = new TreeMap<>(java.util.Map.of(90, "A", 80, "B", 70, "C", 0, "F"));
        System.out.println("score 85 -> " + grades.floorEntry(85).getValue() + ", scores below 80: " + grades.headMap(80));
    }
}
