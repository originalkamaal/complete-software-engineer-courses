// file: Deques.java
import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.Deque;
import java.util.PriorityQueue;

public class Deques {
    record Task(String name, int priority) {}

    public static void main(String[] args) {
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(1); stack.push(2); stack.push(3);
        System.out.print("stack pops: ");
        while (!stack.isEmpty()) System.out.print(stack.pop() + " ");

        Deque<String> queue = new ArrayDeque<>();
        queue.offer("a"); queue.offer("b"); queue.offer("c");
        System.out.print("\nqueue polls: ");
        while (!queue.isEmpty()) System.out.print(queue.poll() + " ");

        PriorityQueue<Task> pq = new PriorityQueue<>(Comparator.comparingInt(Task::priority).reversed());
        pq.add(new Task("email", 1)); pq.add(new Task("outage", 9)); pq.add(new Task("review", 5));
        System.out.print("\nby priority: ");
        while (!pq.isEmpty()) System.out.print(pq.poll().name() + " ");
        System.out.println();
        try { new ArrayDeque<String>().offer(null); } catch (NullPointerException e) { System.out.println("ArrayDeque rejects null"); }
    }
}
