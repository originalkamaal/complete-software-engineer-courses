# Appendix A — Index of Deep & Tricky entries and Patterns

Every *Deep & Tricky* entry (DT) and *Pattern* (P) in the book, in number order, with the unit where it is explained. Use it for revision: read each title and explain the entry before looking it up.

## Deep & Tricky

| # | Entry | Where |
| --- | --- | --- |
| DT-1 | Java's backwards compatibility is strong at the bytecode level: classes compiled for Java 8 run on Java 21 unchanged — but not the other way round. | Unit 0.1 |
| DT-2 | Since Java 9, `+` on strings compiles to `invokedynamic`, and the JVM generates the concatenation code at run time. | Unit 0.3 |
| DT-3 | Reading a `static final` compile-time constant does not initialise its class, because `javac` copies the value into the caller. | Unit 0.4 |
| DT-4 | Integer overflow in Java is defined — it wraps — which makes it silent rather than catastrophic. | Unit 1.1 |
| DT-5 | `Integer` values from −128 to 127 are cached, so `==` happens to work for small numbers and fails for large ones. | Unit 1.2 |
| DT-6 | In an old-style `switch` *statement*, cases fall through to the next one unless you write `break`. The arrow form (`case X ->`), in both statements and expressions, never falls through, and a `switch` *expression* over an enum or sealed type must be exhaustive — the compiler rejects a missing case. | Unit 1.5 |
| DT-7 | `double` cannot represent most decimal fractions, so money must use `BigDecimal` (or integer cents) — and `new BigDecimal(0.1)` is already wrong. | Unit 1.6 |
| DT-8 | Closing a `Scanner` (or `BufferedReader`) that wraps `System.in` closes `System.in` itself, and it cannot be reopened: a second `new Scanner(System.in)` later in the program finds no input and throws `NoSuchElementException`. Create one `Scanner` for standard input for the whole program and do not close it — even though IDEs warn "resource leak". | Unit 1.7 |
| DT-9 | `final` makes a *reference* unchangeable, not the object it refers to — immutability needs defensive copies. | Unit 2.2 |
| DT-10 | `equals` and inheritance do not mix: there is no way to add a value field in a subclass and keep `equals` symmetric and transitive. | Unit 2.3 |
| DT-11 | Every instance of a non-static inner class holds a hidden reference to its outer object — a classic source of memory leaks. | Unit 2.6 |
| DT-12 | Calling an overridable method from a constructor runs the subclass's override before the subclass's fields are initialised. | Unit 3.1 |
| DT-13 | Order matters in pattern `switch`: a more general pattern before a more specific one is a compile error ("dominated"), and guards are checked in order. | Unit 3.5 |
| DT-14 | `protected` in Java is *wider* than in C++: a `protected` member is visible to every class in the same package, not only to subclasses. Package-private (no modifier) is visible to the package only. A class in another package that extends yours can use your `protected` members only through references of its own type (or subtypes). | Unit 3.6 |
| DT-15 | A `return` (or `throw`) in `finally` silently discards an exception thrown by the `try` block. | Unit 4.2 |
| DT-16 | HotSpot may throw pre-allocated exceptions *without* stack traces for frequently thrown built-in exceptions. | Unit 4.5 |
| DT-17 | `Optional.orElse(x)` always evaluates `x`, even when the `Optional` holds a value — so `opt.orElse(loadFromDatabase())` hits the database every time. Use `orElseGet(() -> loadFromDatabase())` for anything expensive or with side effects. | Unit 4.6 |
| DT-18 | Heap pollution: through raw types or unchecked casts, a `List<String>` can hold an `Integer`, and the error surfaces only when — and where — the value is read. | Unit 5.2 |
| DT-19 | The compiler generates *bridge methods* so that erased generic overrides still override. | Unit 5.2 |
| DT-20 | Arrays are covariant and checked at run time; generics are invariant and checked at compile time — so they do not mix. | Unit 5.3 |
| DT-21 | Raw types turn off generic checking: assigning a `List<String>` to a raw `List`, adding an `Integer`, and reading it back as a `String` compiles with only an "unchecked" warning and fails with `ClassCastException` far from the bad `add` — at the line that reads the element. This is called *heap pollution*. | Unit 5.4 |
| DT-22 | A poor `hashCode` turns a `HashMap` into a list — or, since Java 8, into a tree if the keys are `Comparable`. | Unit 6.3 |
| DT-23 | Modifying a collection while iterating over it throws `ConcurrentModificationException` — on a best-effort basis, even in a single thread. | Unit 6.3 |
| DT-24 | `Arrays.asList` returns a fixed-size list *backed by the array*: `set` writes through to the array, `add` and `remove` throw `UnsupportedOperationException`. And `List.of(...)` is fully immutable *and* rejects `null` elements — even `contains(null)` throws `NullPointerException`. | Unit 6.5 |
| DT-25 | A lambda is not an anonymous inner class: it compiles to a private method plus an `invokedynamic` call site, and a non-capturing lambda is a single shared instance. | Unit 7.1 |
| DT-26 | Streams are lazy, single-use, and must not have side effects that interfere with their source or depend on order. | Unit 7.3 |
| DT-27 | `Collectors.toMap` throws `IllegalStateException` on a duplicate key (unless you pass a merge function), and throws `NullPointerException` if any *value* is `null` — even though `HashMap` allows null values. `groupingBy` and `toList` have no such limits. | Unit 7.3 |
| DT-28 | Forgetting `flip()` is the classic `ByteBuffer` bug: after writing, position is at the end, so reading (or writing the buffer to a channel) sees nothing. | Unit 8.4 |
| DT-29 | A memory-mapped file cannot be unmapped explicitly; the mapping lives until the buffer is garbage collected. | Unit 8.4 |
| DT-30 | Java deserialisation runs code: `ObjectInputStream.readObject` instantiates whatever classes the byte stream names (if they are on the class path) and calls their `readObject`/`readResolve` methods, so deserialising untrusted data has led to remote code execution in many products ("gadget chains"). Never deserialise untrusted input with `ObjectInputStream`; if you must, install an `ObjectInputFilter` that allow-lists the expected classes. | Unit 8.5 |
| DT-31 | Java's regex engine backtracks, and some patterns take *exponential* time on input that almost matches — ReDoS (regular-expression denial of service). Since JDK 9 the engine remembers failed positions inside simple nested loops, so the textbook example `(a+)+$` is fast on Java 21; but that optimisation does not cover every pattern — patterns with backreferences, for example — and those still explode, adding a factor of about eight for every three extra characters below. | Unit 8.6 |
| DT-32 | In `DateTimeFormatter` patterns, `yyyy` is the *year of era* and `YYYY` is the *week-based year*: for 29–31 December in some years, `YYYY` prints the *next* year. `Y` in place of `y` (and `D` — day of year — in place of `d`) produces dates that are correct for most of the year and wrong for a few days, which is why the bug survives testing. | Unit 8.7 |
| DT-33 | When two dependencies need different versions of the same library, Maven picks the *nearest* declaration and Gradle picks the *highest* version — and either can break at run time. | Unit 9.1 |
| DT-34 | JUnit creates a new instance of the test class for every test method — so instance fields are never shared between tests, but `static` fields are. | Unit 9.4 |
| DT-35 | `volatile` guarantees visibility and ordering, not atomicity: `volatileCounter++` is still a lost-update race. | Unit 10.3 |
| DT-36 | Double-checked locking is correct only if the field is `volatile`. | Unit 10.3 |
| DT-37 | A thread-safe collection makes each *method* atomic, not sequences of methods: check-then-act on a `ConcurrentHashMap` is still a race. | Unit 10.5 |
| DT-38 | On Java 21–23, a virtual thread that blocks while inside a `synchronized` block *pins* its carrier thread. | Unit 10.7 |
| DT-39 | Java has no value types yet: every object has a header and identity, and a collection of objects is a collection of *pointers* to objects scattered across the heap. | Unit 11.1 |
| DT-40 | A "memory leak" in Java is an object that is still reachable but will never be used again. | Unit 11.2 |
| DT-41 | Micro-benchmarks written by hand measure the JIT's cleverness, not your code — use JMH. | Unit 11.3 |
| DT-42 | A network call without a timeout can block forever — and by default, Java's sockets and `HttpClient` requests have none. | Unit 12.2 |
| DT-43 | Building SQL by concatenating strings (`"... WHERE name = '" + name + "'"`) allows *SQL injection*: an input such as `' OR '1'='1` changes the query's meaning. `PreparedStatement` sends the SQL and the values separately, so a value can never become SQL — and it is also faster for repeated queries. | Unit 12.3 |
| DT-44 | A connection returned to a pool keeps its state: an unfinished transaction, a changed isolation level, or `autoCommit=false` leaks to the next user. | Unit 12.4 |
| DT-45 | Dependency injection is a pattern, not a framework: it means a class receives its collaborators instead of creating or looking them up. | Unit 13.1 |
| DT-46 | A cache is a second copy of the truth; decide what happens when the copies differ before adding one. | Unit 14.3 |
| DT-47 | A shutdown hook is the last code your service runs — keep it short, ordered, and bounded. | Unit 14.6 |

## Patterns

| # | Pattern | Where |
| --- | --- | --- |
| P-1 | Pin the Java version, compile with `--release`, and treat warnings as errors from the start. | Unit 0.6 |
| P-2 | Make classes immutable unless there is a good reason not to; make value types records; make everything else `private` by default. | Unit 2.6 |
| P-3 | Use sealed interfaces with records and pattern matching for data with a fixed set of shapes; use open class hierarchies with virtual methods for behaviour that new types will extend. | Unit 3.5 |
| P-4 | Use checked exceptions for recoverable conditions the caller is expected to handle; use unchecked exceptions for programming errors; translate at boundaries; never swallow. | Unit 4.4 |
| P-5 | In APIs, use wildcards in parameters (PECS) and never in return types; prefer `List<E>` over arrays of generics. | Unit 5.3 |
| P-6 | Declare variables and parameters by interface, return unmodifiable collections, and default to `ArrayList`, `HashMap`, `HashSet`, and `ArrayDeque`. | Unit 6.5 |
| P-7 | Use streams to say *what* is computed; use loops when the logic needs early exits with state, checked exceptions, or index arithmetic; make streams parallel only after measuring. | Unit 7.4 |
| P-8 | Never deserialize untrusted data with Java serialization; define explicit formats with versions and checksums. | Unit 8.5 |
| P-9 | Make code testable by injecting what it depends on — collaborators, time, randomness, configuration — and prefer fakes over mocks. | Unit 9.4 |
| P-10 | Share nothing if you can; share immutable data if you must share; guard mutable shared state with one clear lock — and prefer `java.util.concurrent` to `wait`/`notify`. | Unit 10.7 |
| P-11 | Diagnose before tuning: GC log first, then a heap histogram or dump for memory, and a JFR recording for CPU, allocation, and latency. | Unit 11.4 |
| P-12 | Hide JDBC behind a repository interface; use `PreparedStatement` always; one transaction per unit of work; optimistic locking for concurrent edits. | Unit 12.5 |
| P-13 | Keep business logic in plain classes with constructor-injected dependencies; let the framework stay at the edges. | Chapter 13 Project |
