# Appendix C — Java versions and features

A feature release ships every six months (March and September); every two years one is designated **long-term support** (LTS) by vendors. New language features usually appear first as **preview** features (enabled with `--enable-preview`) for one or more releases.

| Version | Year | Features used or discussed in this book |
| --- | --- | --- |
| 5 | 2004 | generics, annotations, enums, autoboxing, varargs, enhanced `for`, `java.util.concurrent`, the revised Java Memory Model |
| 7 | 2011 | try-with-resources, diamond `<>`, multi-catch, `java.nio.file` (NIO.2), strings in `switch`, `invokedynamic`, Fork/Join |
| 8 (LTS) | 2014 | lambdas, method references, streams, default methods, `Optional`, `java.time`, `CompletableFuture`, `HashMap` treeification |
| 9 | 2017 | modules (JPMS), `jshell`, `List.of`/`Map.of`, private interface methods, compact strings, `invokedynamic` string concatenation, G1 as default |
| 10 | 2018 | `var` for local variables |
| 11 (LTS) | 2018 | `java.net.http.HttpClient`, single-file source launch (`java Hello.java`), `String.strip`/`isBlank`/`repeat`/`lines`, `Files.readString`, ZGC (experimental), Flight Recorder open-sourced |
| 14 | 2020 | `switch` expressions, helpful `NullPointerException` messages |
| 15 | 2020 | text blocks, ZGC and Shenandoah production-ready |
| 16 | 2021 | records, pattern matching for `instanceof`, `Stream.toList()` |
| 17 (LTS) | 2021 | sealed classes and interfaces, strong encapsulation of JDK internals, `HexFormat`, enhanced pseudo-random generators |
| 18 | 2022 | UTF-8 as the default charset, simple web server (`jwebserver`) |
| 19–20 | 2022–23 | previews of virtual threads, record patterns, pattern `switch`, structured concurrency |
| **21 (LTS)** | 2023 | **the baseline of this book.** Virtual threads, pattern matching for `switch`, record patterns, sequenced collections, generational ZGC, key encapsulation API; previews: string templates (later withdrawn), unnamed patterns, structured concurrency, scoped values |
| 22 | 2024 | unnamed variables and patterns (`_`), Foreign Function & Memory API final, multi-file source launch; `stream gatherers` preview |
| 23 | 2024 | Markdown documentation comments, generational ZGC by default |
| 24 | 2025 | stream gatherers final, virtual threads no longer pin in `synchronized` (JEP 491), class-file API, ahead-of-time class loading and linking |
| 25 (LTS) | 2025 | scoped values final, compact source files and instance `main` methods, flexible constructor bodies, module import declarations, compact object headers, generational Shenandoah |

## Choosing a version

Use the newest LTS your organisation supports (21 or 25). Compile with `--release N` so that the same build works on any newer JDK (DT-1). Preview features are not for production: code compiled with `--enable-preview` runs only on that exact release.

## Tools in the JDK

| Tool | Purpose | Chapter |
| --- | --- | --- |
| `javac`, `java`, `jshell` | compile, run, experiment | 0 |
| `javap` | disassemble class files | 0 |
| `jar`, `jdeps`, `jlink`, `jpackage` | package, analyse dependencies, build custom runtimes and installers | 0 |
| `jcmd` | send diagnostic commands to a running JVM (histograms, thread dumps, JFR) | 10, 11 |
| `jfr` | print and summarise Flight Recorder files | 11 |
| `jstack`, `jmap`, `jstat` | thread dumps, heap dumps, GC statistics (older single-purpose tools) | 11 |
| `javadoc` | generate API documentation | — |
