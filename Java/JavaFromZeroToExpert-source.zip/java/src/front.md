---
title: "Java from Zero to Expert"
subtitle: "A complete course in modern Java (Java 21) — from the JVM and bytecode to a production-style REST service"
lang: en
---

# Preface

Java runs a large share of the world's backend software: banks, e-commerce, telecoms, big-data systems, and Android's ecosystem all grew on it. It has also changed a great deal. Modern Java has records, sealed types, pattern matching, lambdas and streams, `var`, text blocks, and virtual threads — a far more expressive language than the Java of older tutorials.

This book teaches **Java 21**, the current long-term-support baseline, the way professionals use it: immutable data by default, interfaces over inheritance, explicit error handling, tested code, and decisions checked with the JDK's own tools — the compiler's lint, `javap`, GC logs, `jcmd`, and Java Flight Recorder.

It begins below the language, with the JVM, bytecode, class loading, and the JIT compiler. It then covers the core language, classes and encapsulation, inheritance and sealed types, exceptions, generics, collections, lambdas and streams, I/O, build and test, concurrency, JVM internals, networking and JDBC, and service design. It ends with a capstone: a REST service with a SQL database, connection pool, cache, rate limiter, metrics, and graceful shutdown.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the Java Language Specification, the library's documented behaviour, HotSpot's implementation, or established practice.
2. **Evidence.** Every program shown with output was compiled and run on OpenJDK 21, and the output is real — including compiler errors, exceptions, and timings. When a first version of an example was wrong, or a measurement contradicted folklore, the book says so.
3. **Order.** Nothing is used before it is taught; later chapters refer back by unit number.

## What could not be run

The build machine for this book had no access to Maven Central. The consequences are stated where they arise: tests run with **JUnit 4.13.2** (bundled with Gradle) while JUnit 5 is shown; JDBC runs against **HSQLDB 2.2.8**, an old release that was available locally; and **Spring Boot, Mockito, Jackson, JMH, and Maven** are shown as source marked *not run here*. Everything else — which is nearly everything — uses only the JDK.

# How to use this book

## Who it is for

- **Beginners:** start at Chapter 0 and read in order. No previous programming is assumed, though it helps.
- **Programmers from other languages:** read Chapters 0–1 quickly; slow down for Chapters 2–5 and every *Deep & Tricky* entry.
- **Developers who learned Java 8 or earlier:** Chapters 3 (sealed types, patterns), 7 (streams), and 10 (virtual threads) cover the largest changes.
- **Working Java developers:** use Appendix A to test yourself, then focus on Chapters 5, 10, 11, and 14.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | The rules, with small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, labelled with their source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a specification, a complete reference solution with real output, and a review checklist.

## How to study

1. **Type the programs and run them.** Single files run directly: `java Hello.java`.
2. **Predict before you run.** When you are wrong, find out why.
3. **Compile with `-Xlint:all`** and read every warning.
4. **Break things on purpose:** remove a `volatile`, mutate a map key, drop a `flip()` — and see what happens.
5. **Revise with Appendix A,** which lists every DT and P entry by title.

## How to read the labels

| Label | Meaning |
| --- | --- |
| *Guarantee: JLS / Java SE specification* | Required by the language or platform specification; true on every conforming JVM. |
| *Library behaviour* | Documented behaviour of the standard library. |
| *Implementation behaviour* | What OpenJDK's HotSpot JVM or `javac` does; may differ on other JVMs or change between versions. |
| *Tool behaviour* | What Gradle or Maven do. |
| *Design fact*, *Practice* | Engineering consequences and professional practice. |

## Toolchain and versions

All code was run on **Linux x86-64 (Ubuntu 24.04)** with **OpenJDK 21.0.12** (HotSpot, G1 by default), **Gradle 8.14.3** (offline), JUnit 4.13.2, and HSQLDB 2.2.8. Measurements were taken on a 2-core virtual machine with a 1.5 GB default maximum heap; compare ratios and shapes, not absolute numbers, and expect run-to-run variation (the JIT makes Java timings noisier than C's).

## Setting up

1. Install a JDK 21 or later: Eclipse Temurin (adoptium.net), or `sudo apt install openjdk-21-jdk`, `brew install openjdk@21`, or SDKMAN (`sdk install java 21-tem`).
2. Check: `java -version`, `javac -version`.
3. Use IntelliJ IDEA (the Community edition is free), or VS Code with the Java extension pack, or Eclipse.
4. For Chapters 9 and 13 with internet access, use the standard Gradle or Maven set-up shown there (Maven Central, JUnit 5).

# Roadmap

| Chapter | Title | You will be able to… |
| --- | --- | --- |
| 0 | The JVM, Bytecode, Class Loading, and the JDK | explain what runs your program, and inspect it |
| 1 | Core Language | use primitives, strings, arrays, control flow, and methods precisely |
| 2 | Classes, Objects, and Encapsulation | design immutable, well-encapsulated classes; use records and enums |
| 3 | Inheritance, Interfaces, Sealed Types, Pattern Matching | choose between open and closed hierarchies; match exhaustively |
| 4 | Exceptions | handle, translate, and design failures; manage resources |
| 5 | Generics in Depth | use bounds and wildcards; understand erasure |
| 6 | The Collections Framework | choose and use collections; know how they work inside |
| 7 | Lambdas, Streams, and Functional Style | write pipelines and collectors; know when not to |
| 8 | I/O, NIO, Files, and Serialization | read and write text and binary data safely and fast |
| 9 | Build and Test | build with Gradle/Maven; write unit tests with test doubles |
| 10 | Concurrency | write correct concurrent code; use virtual threads |
| 11 | JVM Internals | read GC logs, find leaks, profile with JFR |
| 12 | Networking, HTTP, and JDBC | write clients, servers, and database code with transactions |
| 13 | Building Services | apply patterns and layers; map plain Java to Spring Boot |
| 14 | Capstone: A Production-Style REST Service | build, test, and measure a complete service |
| A | Index of Deep & Tricky entries and Patterns | revise every entry by title |
| B | Glossary | look up any term |
| C | Java versions and features | see which release introduced each feature |

Chapters 0–7 are the **foundation**; read them in order. Chapters 8–12 can be read in any order after that (11 uses 10). Chapters 13 and 14 use the whole book.
