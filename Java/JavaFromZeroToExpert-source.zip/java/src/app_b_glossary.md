# Appendix B — Glossary

| Term | Meaning |
| --- | --- |
| Autoboxing | Automatic conversion between a primitive and its wrapper object (Unit 1.2) |
| Bridge method | A synthetic method that makes an erased generic override work (DT-19) |
| Bytecode | The JVM's instruction set, produced by `javac` (Unit 0.3) |
| Checked exception | An exception the compiler requires callers to handle or declare (Unit 4.1) |
| Class loader | The JVM component that finds and loads classes on demand (Unit 0.4) |
| Collector | A recipe for folding a stream into a result, e.g. `groupingBy` (Unit 7.3) |
| Compact constructor | A record constructor that validates or normalises its components (Unit 2.4) |
| Composition root | The one place where an application's object graph is assembled (Chapter 13) |
| Connection pool | A set of reusable database connections (DT-44, Unit 14.2) |
| Data race | Unsynchronised access to shared mutable data from several threads (Unit 10.3) |
| Deadlock | Threads waiting for each other's locks in a cycle (Unit 10.4) |
| Default method | An interface method with a body (Unit 3.3) |
| Dependency injection | Giving an object its collaborators instead of letting it create them (DT-45) |
| Erasure | Removal of generic type information at compile time (Unit 5.2) |
| Escape analysis | A JIT analysis that removes allocations of objects that never leave a method (Unit 11.3) |
| Executor | An object that runs submitted tasks, usually on a thread pool (Unit 10.6) |
| Functional interface | An interface with one abstract method; the target type of a lambda (Unit 7.1) |
| Garbage collection | Automatic reclamation of unreachable objects (Unit 11.2) |
| G1 | The default, region-based, pause-targeting garbage collector (Unit 11.2) |
| Happens-before | The Java Memory Model's guarantee that one action's effects are visible to another (Unit 10.3) |
| Heap pollution | A variable of a parameterised type referring to an object of the wrong type (DT-18) |
| HotSpot | OpenJDK's JVM implementation |
| Immutable object | An object whose state cannot change after construction (Unit 2.2) |
| `invokedynamic` | A bytecode whose target is linked at run time; used for lambdas and string concatenation (DT-2, DT-25) |
| JAR | A zip archive of class files and a manifest (Unit 0.6) |
| JDBC | Java's API for relational databases (Unit 12.3) |
| JFR | Java Flight Recorder, the JVM's built-in profiler (Unit 11.4) |
| JIT | The just-in-time compiler that turns hot bytecode into machine code (Unit 0.5) |
| JMM | The Java Memory Model (Unit 10.3) |
| Lambda | An anonymous function implementing a functional interface (Unit 7.1) |
| LTS | A long-term-support release: 8, 11, 17, 21, 25 (Appendix C) |
| Memory leak | Objects that stay reachable though they will never be used (DT-40) |
| Monitor | The intrinsic lock of every object, used by `synchronized` (Unit 10.2) |
| Optimistic locking | Detecting concurrent modification with a version check instead of holding a lock (Unit 12.5) |
| Optional | A container for a value that may be absent (Unit 4.6) |
| Pattern matching | Testing a value's shape and binding its parts: `instanceof`, `switch`, record patterns (Unit 3.5) |
| PECS | Producer `extends`, consumer `super`: the wildcard rule (Unit 5.3) |
| Raw type | A generic type used without type arguments; disables generic checking (Unit 5.2) |
| Record | A concise, immutable data class with value semantics (Unit 2.4) |
| Sealed type | A class or interface with a fixed list of permitted subtypes (Unit 3.4) |
| Stream | A lazy pipeline of operations over a sequence of elements (Unit 7.2) |
| Test double | A stand-in for a dependency in a test: stub, fake, or mock (Unit 9.4) |
| Transaction | A unit of database work that commits or rolls back as a whole (Unit 12.4) |
| try-with-resources | A statement that closes its resources automatically (Unit 4.3) |
| Type token | A `Class<T>` (or super type token) carrying a type to run time (Unit 5.4) |
| Unchecked exception | A `RuntimeException`; need not be declared (Unit 4.1) |
| Virtual thread | A lightweight thread scheduled by the JVM (Unit 10.7) |
| `volatile` | A field modifier guaranteeing visibility of writes across threads (Unit 10.3) |
| Wildcard | `?` in a generic type: an unknown type argument (Unit 5.3) |
| Young generation | The heap area where new objects are allocated and most die (Unit 11.2) |
