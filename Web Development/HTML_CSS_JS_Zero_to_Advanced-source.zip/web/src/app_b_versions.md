# Appendix B — Versions and Recent Platform Features

Every example in this book was run with the tools below. Most of the platform features it relies on are recent; the table lists them with the unit that uses them, so that you can check support for the browsers your users have (MDN's compatibility tables and caniuse.com are the references).

| Tool | Version used |
| --- | --- |
| Node.js | 22.23 |
| Chromium (headless, through Playwright) | 153 |
| Playwright (Python driver and `@playwright/test`) | 1.63 |
| TypeScript | 7.0 (the native compiler) |
| Vite | 8.3 |
| `ws` (WebSocket server for Node.js) | 8.23 |

| Feature | Standard | Where in this book |
| --- | --- | --- |
| `:has()`, `:is()`, `:where()`, `:nth-child(… of S)` | Selectors Level 4 | Units 2.1–2.2 |
| Cascade layers (`@layer`) | CSS Cascade 5 | Unit 2.3, Chapters 3–4 |
| Container queries and container units | CSS Containment 3 | Unit 4.4 |
| CSS nesting, `oklch()`, `color-mix()`, relative colours, `light-dark()` | CSS Nesting 1, CSS Color 4/5 | Unit 4.3 |
| `@property` | CSS Properties and Values API 1 | Unit 4.2 |
| `@starting-style` | CSS Transitions 2 | DT-17 |
| `popover`, `<dialog>` top layer | HTML | DT-12 |
| `Array.prototype.toSorted`, `with`, `findLast` | ES2023 | Unit 5.6 |
| `Object.groupBy`, `Promise.withResolvers` | ES2024 | Units 7.2, Chapter 7 project |
| Iterator helpers (`map`, `filter`, `take` on iterators) | ES2025 | Unit 6.6 |
| `AbortSignal.timeout`, `AbortSignal.any` | DOM | Unit 7.4, Chapter 7 project |
| `scheduler.yield()` | Prioritized Task Scheduling | Unit 7.5, Chapter 13 |
| Form-associated custom elements (`ElementInternals`) | HTML | Chapter 8 project |
| Import maps, top-level `await` | HTML, ES2022 | Unit 9.1 |
| `require()` of ES modules | Node.js 22.12 | Unit 9.2 |
| Type stripping (`node file.ts`) | Node.js 22.18 | Chapter 10 |
| Built-in `WebSocket` client | Node.js 22 | Chapter 11 project |
| `node:sqlite`, `node:test` mock timers | Node.js 22 (experimental) | Chapters 15–16 |
| Trusted Types | W3C Trusted Types | Unit 14.3, Chapter 14 project |

## Habits that changed with these features

- Use cascade layers and `:where()` instead of specificity battles and `!important`.
- Use container queries for components, media queries for page layout.
- Use `AbortSignal` for every cancellable operation, including timeouts.
- Use `structuredClone` instead of JSON round-trips for copying data.
- Use `type="module"` scripts; they are deferred and scoped by default.
