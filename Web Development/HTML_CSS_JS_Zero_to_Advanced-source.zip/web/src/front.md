---
title: "HTML, CSS, and JavaScript from Zero to Advanced"
subtitle: "How the web platform really works — from HTTP and the rendering pipeline to layout, the event loop, TypeScript, security, performance, and a framework-free application"
lang: en
---

# Preface

The web platform is the most widely deployed application platform there is, and one of the least understood by the people who build on it. Many developers learn it as a pile of recipes — a flexbox incantation, a `useEffect` for fetching, a header pasted from Stack Overflow to make CORS "go away" — and the recipes work until they do not. This book builds the model underneath the recipes.

It starts below the page: what a URL is, what HTTP messages look like on the wire, how caching and validation work, and how a browser turns bytes into a document tree and then into pixels. It then teaches HTML as a language of meaning (semantics, forms, accessibility), CSS as a system of rules (the cascade, the box model, flexbox, grid, custom properties, container queries, animation), and JavaScript from its core semantics through closures, prototypes, classes, the event loop, promises, the DOM, modules, and TypeScript. The second half is about building real things: networking, storage and offline apps, performance and Core Web Vitals, security, testing, and Node.js — ending with a single-page application written without a framework, so that you know what frameworks do for you.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the HTML Living Standard, a CSS specification, ECMAScript (ECMA-262), an RFC, or the documented behaviour of a browser or Node.js.
2. **Evidence.** Every program shown with output was run — JavaScript with Node.js 22, pages in a real headless Chromium (version 153) driven from the command line — and the output is real. Where a first attempt was wrong in an instructive way, the book says so.
3. **Order.** Nothing is used before it is taught; later chapters refer back by unit number.

# How to use this book

## Who it is for

- **Beginners:** start at Chapter 0 and read in order. Type every example, run it, and change it.
- **Programmers from other languages:** read Chapters 0–4 quickly, then slowly from Chapter 5: JavaScript's equality, numbers, `this`, and the event loop differ from what you expect.
- **Working web developers:** skim the summaries and read every *Deep & Tricky* entry; Chapters 2, 6, 7, 11, 13, and 14 usually contain the most new material.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | Small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, labelled with their source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a realistic program with complete code, real output, and a review checklist.

## Running the code

Every file in the book starts with a comment naming its path, such as `// file: http/url.mjs` or `<!-- file: render/parse.html -->`; the source archive contains them all, arranged by chapter. You need:

- **Node.js 22 or later** (`node --version`). Node scripts in the early chapters use the `.mjs` extension, which makes them ES modules (Chapter 9 explains why that matters).
- **A modern browser.** To show what a page does in print, this book runs pages in headless Chromium with a small driver, `tools/page.py` (below), which prints the page's console output and the results of expressions. When you read, simply open the same files in your own browser with the developer tools open — the Console shows the same lines.
- For the driver itself: Python 3 and Playwright (`pip install playwright && playwright install chromium`).

Commands are shown as `$ command` followed by their real output. The driver:

```python
# file: ../tools/page.py
"""Drive a real browser (headless Chromium, through Playwright) from the command line.

    python3 page.py TARGET [STEP ...] [--serve CMD [--server-log]] [--width W] [--height H]
                    [--dpr N] [--media FEATURE] [--slow]

TARGET is a file (opened as file://) or a URL. Console messages and uncaught errors
are printed as they happen. STEPs run in order:
    eval:EXPR       evaluate a JavaScript expression and print "=> result" (JSON)
    click:SEL       click the element matching a CSS selector
    hover:SEL       move the mouse over it
    mouse:X,Y       click at a position (no waiting for the page, unlike click:)
    fill:SEL|TEXT   type TEXT into an input
    upload:SEL|FILE choose FILE in a file input
    press:KEY       press a key (e.g. Enter, Tab)
    wait:MS         wait MS milliseconds
    viewport:WxH    resize the viewport
    media:dark      emulate prefers-color-scheme: dark (or light, reduce for reduced motion)
    offline:on|off  cut or restore the browser's network connection
    reload          reload the page
    shot:FILE       save a screenshot
    aria:SEL        print the accessibility tree of an element, as the browser exposes it
--dpr N sets the device pixel ratio (default 1); --media dark|light|reduce emulates
a media feature from the start; --slow emulates a slow network (400 ms latency, 400 kB/s)
and a 4x slower CPU.
--serve CMD starts a server first (e.g. "node server.js"), waits until TARGET answers,
and stops it at the end; the server's own output is shown only with --server-log.
"""
import json
import os
import shlex
import subprocess
import sys
import time
import urllib.request
from playwright.sync_api import sync_playwright

def main():
    args, steps, serve, width, height, dpr, server_log = sys.argv[1:], [], None, 800, 600, 1, False
    media, slow = [], False
    target = args.pop(0)
    while args:
        a = args.pop(0)
        if a == "--serve": serve = args.pop(0)
        elif a == "--width": width = int(args.pop(0))
        elif a == "--height": height = int(args.pop(0))
        elif a == "--dpr": dpr = float(args.pop(0))
        elif a == "--server-log": server_log = True
        elif a == "--media": media.append(args.pop(0))
        elif a == "--slow": slow = True
        else: steps.append(a)
    server = None
    if serve:
        server = subprocess.Popen(shlex.split(serve), start_new_session=True,
                                  stdout=None if server_log else subprocess.DEVNULL)
        for _ in range(100):                                  # wait up to 10 s for the server
            try:
                urllib.request.urlopen(urllib.request.Request(target, method="HEAD"), timeout=1); break
            except urllib.error.HTTPError:
                break                                         # it answered, even if with an error
            except Exception:
                time.sleep(0.1)
    if "://" not in target:
        target = "file://" + os.path.abspath(target)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=dpr)
            if slow:
                cdp = page.context.new_cdp_session(page)
                cdp.send("Network.emulateNetworkConditions", {"offline": False, "latency": 400,
                         "downloadThroughput": 400_000, "uploadThroughput": 400_000})
                cdp.send("Emulation.setCPUThrottlingRate", {"rate": 4})
            for m in media:
                page.emulate_media(**({"reduced_motion": "reduce"} if m == "reduce" else {"color_scheme": m}))
            page.on("console", lambda m: print(m.text, flush=True))
            page.on("pageerror", lambda e: print(f"Uncaught {e.name}: {e.message}", flush=True))
            page.goto(target)
            for step in steps:
                kind, _, arg = step.partition(":")
                if kind == "eval":
                    print("=>", json.dumps(page.evaluate(arg)), flush=True)
                elif kind == "click": page.click(arg)
                elif kind == "hover": page.hover(arg)
                elif kind == "mouse":
                    x, y = map(float, arg.split(","))
                    page.mouse.click(x, y)
                elif kind == "fill":
                    sel, _, text = arg.partition("|")
                    page.fill(sel, text)
                elif kind == "upload":
                    sel, _, file = arg.partition("|")
                    page.set_input_files(sel, file)
                elif kind == "press": page.keyboard.press(arg)
                elif kind == "wait": page.wait_for_timeout(int(arg))
                elif kind == "viewport":
                    w, h = map(int, arg.split("x"))
                    page.set_viewport_size({"width": w, "height": h})
                elif kind == "media":
                    if arg == "reduce": page.emulate_media(reduced_motion="reduce")
                    else: page.emulate_media(color_scheme=arg)
                elif kind == "offline": page.context.set_offline(arg == "on")
                elif kind == "reload": page.reload()
                elif kind == "shot": page.screenshot(path=arg)
                elif kind == "aria": print(page.locator(arg).first.aria_snapshot(), flush=True)
                else: sys.exit(f"unknown step {step!r}")
            page.wait_for_timeout(50)                         # let late console messages arrive
            browser.close()
    finally:
        if server:
            os.killpg(server.pid, 15)

if __name__ == "__main__":
    main()
```

A command such as `python3 ../../tools/page.py demo.html "eval:document.title"` opens `demo.html`, prints what the page logs, and then prints `=> "..."`, the value of the expression. With `--serve "node server.mjs"`, the driver starts a local server first and stops it at the end (add `--server-log` to see what the server prints).

## Reading order

**Part I (Chapters 0–4)** is the platform and its two declarative languages: how the web works, HTML, CSS fundamentals, layout, and modern CSS. **Part II (Chapters 5–10)** is JavaScript: the core language, functions and objects, asynchronous programming and the event loop, the DOM and browser APIs, modules and tooling, and TypeScript. **Part III (Chapters 11–17)** builds applications: networking, storage and offline, performance, security, testing, Node.js, and the capstone application.
