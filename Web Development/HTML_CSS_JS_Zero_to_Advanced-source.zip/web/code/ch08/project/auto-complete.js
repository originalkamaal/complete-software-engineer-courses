// file: project/auto-complete.js
// <auto-complete>: an accessible combobox (WAI-ARIA "combobox with listbox popup" pattern)
// as a form-associated custom element. Options come from <option> children.
const fold = (s) => s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();   // "Österreich" ~ "oster"
let uid = 0;

class AutoComplete extends HTMLElement {
  static formAssociated = true;                       // takes part in <form> submission and reset
  #internals = this.attachInternals();
  #input; #list; #options = []; #matches = []; #active = -1; #id = `ac${++uid}`;

  connectedCallback() {
    if (this.#input) return;                          // connected again after a move: already built
    this.#options = [...this.querySelectorAll("option")].map((o) => o.value || o.textContent);
    const root = this.attachShadow({ mode: "open", delegatesFocus: true });
    root.innerHTML = `
      <style>
        :host { display: inline-block; position: relative; }
        ul { position: absolute; margin: 0; padding: 0; list-style: none; border: 1px solid; background: Canvas; }
        ul[hidden] { display: none; }
        li[aria-selected="true"] { background: Highlight; color: HighlightText; }
      </style>
      <label for="input"><slot name="label">${this.getAttribute("label") ?? ""}</slot></label>
      <input id="input" role="combobox" aria-autocomplete="list" aria-expanded="false"
             aria-controls="list" autocomplete="off">
      <ul id="list" role="listbox" hidden></ul>`;
    this.#input = root.getElementById("input");
    this.#list = root.getElementById("list");
    this.#input.addEventListener("input", () => this.#filter());
    this.#input.addEventListener("keydown", (e) => this.#key(e));
    this.#input.addEventListener("blur", () => this.#close());
    this.#list.addEventListener("pointerdown", (e) => {      // pointerdown fires before the input's blur
      const li = e.target.closest("li");
      if (li) { e.preventDefault(); this.#choose(Number(li.dataset.index)); }
    });
    this.#setValue("");
  }

  get value() { return this.#internals.form ? new FormData(this.#internals.form).get(this.getAttribute("name")) : this.#input.value; }
  formResetCallback() { this.#input.value = ""; this.#setValue(""); }

  #setValue(v) {
    this.#internals.setFormValue(v);
    if (this.hasAttribute("required"))
      this.#internals.setValidity(v ? {} : { valueMissing: true }, "Choose an option from the list.", this.#input);
  }

  #filter() {
    const q = fold(this.#input.value.trim());
    this.#matches = q ? this.#options.filter((o) => fold(o).includes(q)).slice(0, 8) : [];
    this.#active = -1;
    this.#setValue("");                                  // free text is not a value until an option is chosen
    this.#render();
  }

  #render() {
    this.#list.replaceChildren(...this.#matches.map((text, i) => {
      const li = document.createElement("li");
      Object.assign(li, { id: `${this.#id}-${i}`, textContent: text });
      li.setAttribute("role", "option");
      li.setAttribute("aria-selected", String(i === this.#active));
      li.dataset.index = i;
      return li;
    }));
    const open = this.#matches.length > 0;
    this.#list.hidden = !open;
    this.#input.setAttribute("aria-expanded", String(open));
    if (this.#active >= 0) this.#input.setAttribute("aria-activedescendant", `${this.#id}-${this.#active}`);
    else this.#input.removeAttribute("aria-activedescendant");
  }

  #key(e) {
    const n = this.#matches.length;
    if (e.key === "ArrowDown" && n) { this.#active = (this.#active + 1) % n; this.#render(); e.preventDefault(); }
    else if (e.key === "ArrowUp" && n) { this.#active = (this.#active - 1 + n) % n; this.#render(); e.preventDefault(); }
    else if (e.key === "Enter" && this.#active >= 0) { this.#choose(this.#active); e.preventDefault(); }
    else if (e.key === "Escape") this.#close();
  }

  #choose(i) {
    const value = this.#matches[i];
    this.#input.value = value;
    this.#setValue(value);
    this.#close();
    this.dispatchEvent(new Event("change", { bubbles: true }));
  }

  #close() { this.#matches = []; this.#active = -1; this.#render(); }
}
customElements.define("auto-complete", AutoComplete);
