// file: project/public/app.js
// Local-first: every note is saved in IndexedDB at once, then uploaded when the network allows.
import * as db from "/db.js";

const list = document.getElementById("notes"), status = document.getElementById("status");

async function render() {
  const notes = (await db.all()).sort((a, b) => a.created - b.created);
  list.replaceChildren(...notes.map((n) => Object.assign(document.createElement("li"),
    { textContent: n.text, className: n.synced ? "" : "pending" })));
  status.textContent = navigator.onLine ? "" : "(offline)";
  return notes;
}

let syncing = false;
async function sync() {                                     // the outbox: upload unsynced notes, oldest first
  if (syncing || !navigator.onLine) return;
  syncing = true;
  try {
    for (const note of (await db.all()).filter((n) => !n.synced)) {
      const res = await fetch("/api/notes", { method: "PUT", headers: { "Content-Type": "application/json" },
                                              body: JSON.stringify({ id: note.id, text: note.text }) });
      if (!res.ok) break;
      await db.put({ ...note, synced: true });
      console.log(`synced "${note.text}"`);
    }
  } catch (e) { console.log(`sync failed: ${e.message}`); }
  finally { syncing = false; await render(); }
}

document.getElementById("f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("text");
  await db.put({ id: crypto.randomUUID(), text: input.value, created: Date.now(), synced: false });
  input.value = "";
  await render();
  await sync();
});
addEventListener("online", () => { console.log("back online"); sync(); });
addEventListener("offline", () => { console.log("went offline"); render(); });

if ("serviceWorker" in navigator) await navigator.serviceWorker.register("/sw.js");
const notes = await render();
console.log(`loaded: ${notes.length} notes (${notes.filter((n) => !n.synced).length} pending), ` +
            `online ${navigator.onLine}, controlled by a service worker: ${navigator.serviceWorker.controller !== null}`);
sync();
