// file: project/public/sw.js
// The service worker: precache the app shell, serve it offline, and keep API data fresh when possible.
const VERSION = "v1";
const SHELL = ["/", "/app.js", "/db.js", "/style.css", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(`shell-${VERSION}`).then((c) => c.addAll(SHELL)));
  self.skipWaiting();                                      // take over without waiting for old tabs to close
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (!key.endsWith(VERSION)) await caches.delete(key);   // old versions
    await self.clients.claim();                            // control already-open pages now
  })());
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== location.origin) return;   // let the browser handle it
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(fetch(event.request));               // API: network only (the app keeps its own copy)
    return;
  }
  event.respondWith((async () => {                         // app shell: cache first, network as a fallback
    const cached = await caches.match(event.request, { ignoreSearch: true });
    return cached ?? fetch(event.request);
  })());
});
