// file: project/public/db.js
// A promise wrapper around one IndexedDB object store.
const done = (req) => new Promise((ok, no) => { req.onsuccess = () => ok(req.result); req.onerror = () => no(req.error); });
const open = indexedDB.open("notes", 1);
open.onupgradeneeded = () => open.result.createObjectStore("notes", { keyPath: "id" });
const db = await done(open);

export const all = () => done(db.transaction("notes").objectStore("notes").getAll());
export const put = (note) => done(db.transaction("notes", "readwrite").objectStore("notes").put(note));
