// file: chat/chat.js
// A chat client that reconnects with exponential backoff and resumes where it left off.
export function connect({ url, name, onMessage, onStatus = () => {} }) {
  let ws, lastSeq = 0, attempt = 0, stopped = false;
  const seen = new Set();
  function open() {
    ws = new WebSocket(`${url}?name=${encodeURIComponent(name)}&since=${lastSeq}`);
    ws.onopen = () => { attempt = 0; onStatus("open"); };
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (seen.has(msg.seq)) return;                       // never show a message twice
      seen.add(msg.seq);
      lastSeq = Math.max(lastSeq, msg.seq);
      onMessage(msg);
    };
    ws.onclose = (e) => {
      if (stopped) return;
      const delay = Math.min(10_000, 250 * 2 ** attempt++) * (0.5 + Math.random() / 2);
      onStatus(`closed (${e.code}); reconnecting in ${Math.round(delay)} ms`);
      setTimeout(open, delay);
    };
  }
  open();
  return {
    send: (text) => ws.readyState === WebSocket.OPEN && ws.send(JSON.stringify({ text })),
    close: () => { stopped = true; ws.close(); },
  };
}
