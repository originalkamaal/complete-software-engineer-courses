// file: capstone/playwright.config.js
import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: ".",
  reporter: "list",
  use: { baseURL: "http://localhost:8170" },
  webServer: { command: "node --disable-warning=ExperimentalWarning server.mjs", url: "http://localhost:8170/" },
});
