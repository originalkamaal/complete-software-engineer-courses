// file: capstone/e2e.spec.js
// The whole application, end to end, as a user (and a screen reader) experiences it.
import { test, expect } from "@playwright/test";

test.describe.configure({ mode: "serial" });                 // one shared server and database, in order

test("starts empty, and creating a note shows it", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("All notes");
  await expect(page.getByText("No notes yet.")).toBeVisible();
  await page.getByRole("link", { name: "New note" }).click();
  await expect(page).toHaveURL("/new");
  await page.getByLabel("Title").fill("Buy milk");
  await page.getByLabel("Body").fill("Two litres");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page).toHaveURL(/\/notes\/1$/);
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Buy milk");
  await expect(page.locator("#announcer")).toHaveText('Saved "Buy milk"');
});

test("the server's validation errors are shown in the form", async ({ page }) => {
  await page.goto("/new");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.locator("#errors li")).toHaveText(["$.title: shorter than 1"]);
  await expect(page).toHaveURL("/new");
});

test("Back and Forward work without reloading the page", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(() => (window.marker = "same document"));    // survives only if no reload happens
  await page.getByRole("link", { name: "Buy milk" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Buy milk");
  await page.goBack();
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("All notes");
  await page.goForward();
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Buy milk");
  expect(await page.evaluate(() => window.marker)).toBe("same document");
  await expect(page.getByRole("main")).toBeFocused();          // focus moved to the new content
});

test("deep links work on reload, and unknown paths say so", async ({ page }) => {
  await page.goto("/notes/1");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Buy milk");
  await page.goto("/no/such/page");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Page not found");
});

test("pagination loads five notes at a time", async ({ page, request }) => {
  for (let i = 2; i <= 7; i++) await request.post("/api/notes", { data: { title: `Note ${i}`, body: "" } });
  await page.goto("/");
  await expect(page.getByRole("listitem")).toHaveCount(5);
  await page.getByRole("button", { name: "Load more" }).click();
  await expect(page.getByRole("listitem")).toHaveCount(7);
  await expect(page.getByRole("button", { name: "Load more" })).toBeHidden();
});

test("deleting returns to the list, and Back does not resurrect the note", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Buy milk" }).click();
  await page.getByRole("button", { name: "Delete" }).click();
  await expect(page).toHaveURL("/");
  await expect(page.getByRole("link", { name: "Buy milk" })).toHaveCount(0);
  await page.goBack();
  await expect(page).not.toHaveURL(/\/notes\/1$/);
});
