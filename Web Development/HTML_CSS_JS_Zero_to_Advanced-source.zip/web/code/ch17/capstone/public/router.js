// file: capstone/public/router.js
// A History-API router: intercepts same-origin link clicks, matches paths to views,
// aborts the previous view's requests, restores scroll on back/forward, and moves focus.
export function createRouter(routes, outlet, { onNavigate = () => {} } = {}) {
  let controller = null;
  async function render(url, { focus = true } = {}) {
    controller?.abort();                                     // stop loading the page we are leaving
    controller = new AbortController();
    const path = new URL(url, location.origin).pathname;
    for (const [pattern, view] of routes) {
      const m = pattern.exec(path);
      if (!m) continue;
      outlet.setAttribute("aria-busy", "true");
      try {
        await view({ outlet, params: m.groups ?? {}, signal: controller.signal, navigate });
      } catch (e) {
        if (e.name === "AbortError") return;                 // superseded by a newer navigation
        outlet.replaceChildren(Object.assign(document.createElement("p"), { textContent: `Error: ${e.message}` }));
      } finally { outlet.removeAttribute("aria-busy"); }
      if (focus) { outlet.tabIndex = -1; outlet.focus(); }   // screen readers start at the new content
      onNavigate(path);
      return;
    }
  }
  function navigate(url, { replace = false } = {}) {
    history[replace ? "replaceState" : "pushState"](null, "", url);
    return render(url);
  }
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[href]");
    if (!a || a.origin !== location.origin || a.target || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
    if (a.hash && a.pathname === location.pathname) return;  // in-page anchors (the skip link)
    e.preventDefault();
    navigate(a.href);
  });
  addEventListener("popstate", () => render(location.href));
  return { start: () => render(location.href, { focus: false }), navigate };
}
