// file: capstone/public/api.js
// The client for Chapter 16's API: one place for URLs, errors, and JSON.
export class ApiError extends Error {
  constructor(status, body) { super(body?.error ?? `HTTP ${status}`); this.status = status; this.details = body?.details ?? []; }
}
async function request(path, { method = "GET", body, signal } = {}) {
  const res = await fetch(`/api${path}`, { method, signal,
    headers: body ? { "Content-Type": "application/json" } : {}, body: body && JSON.stringify(body) });
  const data = res.status === 204 ? null : await res.json();
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}
export const listNotes = (after, signal) => request(`/notes?limit=5${after ? `&after=${after}` : ""}`, { signal });
export const getNote = (id, signal) => request(`/notes/${id}`, { signal });
export const createNote = (note) => request("/notes", { method: "POST", body: note });
export const deleteNote = (id) => request(`/notes/${id}`, { method: "DELETE" });
