// file: capstone/public/app.js
// Views and wiring. State that several views share lives in signals (Chapter 6).
import { signal, effect } from "/lib/signals.mjs";
import { createRouter } from "/router.js";
import * as api from "/api.js";

const h = (tag, props = {}, ...children) => {               // a tiny element builder: never parses HTML
  const el = Object.assign(document.createElement(tag), props);
  el.append(...children.flat().filter((c) => c != null && c !== false));
  return el;
};
const status = signal("");
effect(() => { document.getElementById("announcer").textContent = status.value; });

async function listView({ outlet, signal: abort }) {
  const items = [];
  let next = null;
  const list = h("ul");
  const more = h("button", { type: "button", textContent: "Load more" });
  async function load(after) {
    const page = await api.listNotes(after, abort);
    items.push(...page.items);
    next = page.items.length && page.next ? page.items.at(-1).id : null;
    list.append(...page.items.map((n) => h("li", {}, h("a", { href: `/notes/${n.id}`, textContent: n.title }), " ",
                                             n.status === "draft" && h("span", { className: "draft", textContent: "draft" }))));
    more.hidden = !next;
    status.value = `${items.length} note${items.length === 1 ? "" : "s"} shown`;
  }
  more.addEventListener("click", () => load(next));
  await load();
  document.title = "All notes";
  outlet.replaceChildren(h("h1", { textContent: "All notes" }),
    items.length ? list : h("p", { textContent: "No notes yet." }), more);
}

async function noteView({ outlet, params, signal: abort, navigate }) {
  const note = await api.getNote(params.id, abort);
  const del = h("button", { type: "button", textContent: "Delete" });
  del.addEventListener("click", async () => {
    await api.deleteNote(note.id);
    status.value = `Deleted "${note.title}"`;
    navigate("/", { replace: true });                        // replace: Back must not return to a deleted note
  });
  document.title = note.title;
  outlet.replaceChildren(h("h1", { textContent: note.title }), h("p", { textContent: note.body || "(empty)" }),
                         h("p", {}, h("small", { textContent: `${note.status}, updated ${new Date(note.updated).toLocaleString("en-GB")}` })), del);
}

async function newView({ outlet, navigate }) {
  const errors = h("ul", { className: "errors", id: "errors" });
  const form = h("form", { noValidate: true },
    h("p", {}, h("label", { textContent: "Title ", htmlFor: "title" }), h("input", { id: "title", name: "title" })),
    h("p", {}, h("label", { textContent: "Body ", htmlFor: "body" }), h("textarea", { id: "body", name: "body" })),
    h("p", {}, h("label", {}, h("input", { type: "checkbox", name: "publish" }), " Publish now")),
    errors, h("button", { textContent: "Save" }));
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = new FormData(form);
    try {
      const note = await api.createNote({ title: data.get("title"), body: data.get("body"),
                                          status: data.get("publish") ? "published" : "draft" });
      status.value = `Saved "${note.title}"`;
      navigate(`/notes/${note.id}`);
    } catch (err) {
      if (!(err instanceof api.ApiError)) throw err;
      errors.replaceChildren(...(err.details.length ? err.details : [err.message]).map((d) => h("li", { textContent: d })));
      status.value = `Not saved: ${err.details.length || 1} problem(s)`;
    }
  });
  document.title = "New note";
  outlet.replaceChildren(h("h1", { textContent: "New note" }), form);
}

function notFound({ outlet }) {
  document.title = "Not found";
  outlet.replaceChildren(h("h1", { textContent: "Page not found" }), h("p", {}, h("a", { href: "/", textContent: "All notes" })));
}

const router = createRouter([
  [/^\/$/, listView],
  [/^\/notes\/(?<id>\d+)$/, noteView],
  [/^\/new$/, newView],
  [/.*/, notFound],
], document.getElementById("main"), { onNavigate: (path) => console.log(`[router] ${path}`) });
router.start();
