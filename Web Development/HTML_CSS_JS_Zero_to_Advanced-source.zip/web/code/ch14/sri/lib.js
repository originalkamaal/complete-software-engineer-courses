// file: sri/lib.js
console.log("lib.js ran: the version we reviewed");
console.log("lib.js ran: COMPROMISED");
