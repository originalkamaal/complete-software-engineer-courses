// file: generics/generics.ts
// Generics: functions and types parameterised by types, with constraints.
function firstOf<T>(items: readonly T[]): T | undefined { return items[0]; }
function pluck<T, K extends keyof T>(items: T[], key: K): T[K][] { return items.map((it) => it[key]); }
function groupBy<T, K extends PropertyKey>(items: T[], keyOf: (item: T) => K): Record<K, T[]> {
  const out = {} as Record<K, T[]>;
  for (const it of items) (out[keyOf(it)] ??= []).push(it);
  return out;
}

interface Product { sku: string; price: number; tags: string[] }
const products: Product[] = [
  { sku: "A1", price: 1999, tags: ["new"] }, { sku: "B2", price: 499, tags: [] }, { sku: "C3", price: 2999, tags: ["new"] },
];
const f = firstOf(products);                       // Product | undefined
const prices = pluck(products, "price");           // number[]
const byNew = groupBy(products, (p) => (p.tags.includes("new") ? "new" : "old"));   // Record<"new" | "old", Product[]>
console.log(f?.sku, prices, Object.keys(byNew), byNew.new.length);

// Utility types derive new types from existing ones
type ProductPatch = Partial<Omit<Product, "sku">>;            // every field except sku, all optional
type PriceList = Record<Product["sku"], number>;
type Summary = Pick<Product, "sku" | "price">;
const patch: ProductPatch = { price: 1799 };
const summary: Summary = { sku: "A1", price: 1999 };
const list: PriceList = { A1: 1999 };
console.log(patch, summary, list);

// satisfies checks a value against a type WITHOUT widening it to that type
const routes = { home: "/", product: "/p/:sku" } satisfies Record<string, `/${string}`>;
const r: "/p/:sku" = routes.product;                          // still the literal type
console.log(r);
