// file: generics/unsound.ts
// Types are erased before the program runs, and some constructs let wrong types through.
interface User { id: number; name: string }

const fromServer: unknown = JSON.parse('{"id": "7", "nickname": "Bo"}');
const trusted = fromServer as User;                 // an assertion: "trust me" — not checked
console.log(typeof trusted.id, trusted.name?.length); // a string id, and no name at all

const anything: any = "text";
const n: number = anything;                         // any switches type checking off, silently
console.log(n.toFixed);                              // undefined at run time

const extra = { id: 1, name: "Ana", password: "hunter2" };
const user: User = extra;                           // fine: excess-property checks apply only to literals
console.log(JSON.stringify(user));                  // ... so the password goes along for the ride

const dogs: { bark(): void }[] = [];
const animals: object[] = dogs;                     // arrays are covariant (unsound but convenient)
animals.push({});
try { dogs[0]!.bark(); }                            // ! is another unchecked "trust me"
catch (e) { console.log(`${(e as Error).name}: ${(e as Error).message}`); }
