// file: advanced/types.ts
// Computing with types: mapped, conditional, and template literal types. Checked by tsc only.
type Expect<T extends true> = T;                                  // compile-time assertions
type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;

interface Settings { theme: "light" | "dark"; fontSize: number; beta: boolean }

type Getters<T> = { [K in keyof T as `get${Capitalize<string & K>}`]: () => T[K] };   // mapped + key remapping
type ReadonlyDeep<T> = { readonly [K in keyof T]: T[K] extends object ? ReadonlyDeep<T[K]> : T[K] };
type ElementOf<T> = T extends readonly (infer E)[] ? E : never;  // conditional type with infer
type EventName<T extends string> = `on${Capitalize<T>}`;         // template literal type
type NonFunctionKeys<T> = { [K in keyof T]: T[K] extends (...a: any[]) => any ? never : K }[keyof T];

type _tests = [
  Expect<Equal<keyof Getters<Settings>, "getTheme" | "getFontSize" | "getBeta">>,
  Expect<Equal<ReturnType<Getters<Settings>["getTheme"]>, "light" | "dark">>,
  Expect<Equal<ElementOf<string[]>, string>>,
  Expect<Equal<ElementOf<readonly [1, "a"]>, 1 | "a">>,
  Expect<Equal<EventName<"click" | "focus">, "onClick" | "onFocus">>,
  Expect<Equal<NonFunctionKeys<{ a: number; f(): void }>, "a">>,
];

const s: ReadonlyDeep<{ user: { name: string } }> = { user: { name: "Ana" } };
// @ts-expect-error: deeply readonly
s.user.name = "Bo";
// @ts-expect-error: "huge" is not a valid theme
const bad: Settings["theme"] = "huge";
export {};
