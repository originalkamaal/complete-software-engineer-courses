// file: basics/narrow.ts
// Union types and narrowing: TypeScript follows your checks through the control flow.
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "rect"; width: number; height: number }
  | { kind: "triangle"; base: number; height: number };   // a discriminated union: "kind" tells them apart

function area(s: Shape): number {
  switch (s.kind) {
    case "circle": return Math.PI * s.radius ** 2;          // here s is the circle variant
    case "rect": return s.width * s.height;
    case "triangle": return (s.base * s.height) / 2;
    default: {
      const unreachable: never = s;                         // compile error if a variant is unhandled
      return unreachable;
    }
  }
}

function describe(x: string | number | string[] | null): string {
  if (x === null) return "nothing";
  if (typeof x === "number") return `number ${x.toFixed(1)}`;   // x: number
  if (Array.isArray(x)) return `list of ${x.length}`;           // x: string[]
  return `text "${x.toUpperCase()}"`;                            // x: string
}

const shapes: Shape[] = [{ kind: "circle", radius: 1 }, { kind: "rect", width: 2, height: 3 }];
console.log(shapes.map(area).map((a) => a.toFixed(2)), describe(3.14159), describe(["a"]), describe("hi"), describe(null));
