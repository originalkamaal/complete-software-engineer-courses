// file: basics/errors.ts
// Bugs that the type checker reports before the code ever runs.
interface User { id: number; name: string; email?: string }

function greet(user: User) {
  return `Hello ${user.name.toUpperCase()}, we will write to ${user.email.toLowerCase()}`;
}
const u: User = { id: 1, name: "Ana", emial: "ana@example.com" };
greet({ id: "2", name: "Bo" });
const ids = [1, 2, 3];
const first: number = ids.find((id) => id > 1);
type Status = "active" | "suspended";
const s: Status = "Active";
