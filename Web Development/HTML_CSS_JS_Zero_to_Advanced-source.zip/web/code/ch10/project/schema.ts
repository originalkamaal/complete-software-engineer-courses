// file: project/schema.ts
// A tiny runtime validator whose schemas also produce static types (the idea behind Zod and Valibot).
export type Result<T> = { ok: true; value: T } | { ok: false; errors: string[] };

export interface Schema<T> {
  parse(input: unknown, path?: string): Result<T>;
  optional(): Schema<T | undefined>;
}
export type Infer<S> = S extends Schema<infer T> ? T : never;

function schema<T>(parse: (input: unknown, path: string) => Result<T>): Schema<T> {
  const s: Schema<T> = {
    parse: (input, path = "$") => parse(input, path),
    optional: () => schema<T | undefined>((input, path) => (input === undefined ? { ok: true, value: undefined } : parse(input, path))),
  };
  return s;
}
const fail = (path: string, msg: string): Result<never> => ({ ok: false, errors: [`${path}: ${msg}`] });

export const string = (opts: { min?: number; pattern?: RegExp } = {}) => schema<string>((v, p) =>
  typeof v !== "string" ? fail(p, `expected string, got ${typeof v}`)
  : opts.min !== undefined && v.length < opts.min ? fail(p, `shorter than ${opts.min}`)
  : opts.pattern && !opts.pattern.test(v) ? fail(p, `does not match ${opts.pattern}`)
  : { ok: true, value: v });

export const number = (opts: { int?: boolean; min?: number } = {}) => schema<number>((v, p) =>
  typeof v !== "number" || Number.isNaN(v) ? fail(p, `expected number, got ${typeof v}`)
  : opts.int && !Number.isInteger(v) ? fail(p, "expected an integer")
  : opts.min !== undefined && v < opts.min ? fail(p, `less than ${opts.min}`)
  : { ok: true, value: v });

export const literal = <const L extends string | number | boolean>(...allowed: L[]) => schema<L>((v, p) =>
  allowed.includes(v as L) ? { ok: true, value: v as L } : fail(p, `expected one of ${JSON.stringify(allowed)}`));

export const array = <T>(item: Schema<T>) => schema<T[]>((v, p) => {
  if (!Array.isArray(v)) return fail(p, "expected array");
  const out: T[] = [], errors: string[] = [];
  v.forEach((x, i) => { const r = item.parse(x, `${p}[${i}]`); r.ok ? out.push(r.value) : errors.push(...r.errors); });
  return errors.length ? { ok: false, errors } : { ok: true, value: out };
});

type Shape = Record<string, Schema<unknown>>;
type ObjectOf<S extends Shape> = { [K in keyof S]: Infer<S[K]> };

export const object = <S extends Shape>(shape: S) => schema<ObjectOf<S>>((v, p) => {
  if (typeof v !== "object" || v === null || Array.isArray(v)) return fail(p, "expected object");
  const out: Record<string, unknown> = {}, errors: string[] = [];
  for (const key of Object.keys(shape)) {
    const r = shape[key]!.parse((v as Record<string, unknown>)[key], `${p}.${key}`);
    r.ok ? (out[key] = r.value) : errors.push(...r.errors);
  }
  for (const key of Object.keys(v)) if (!(key in shape)) errors.push(`${p}.${key}: unexpected property`);
  return errors.length ? { ok: false, errors } : { ok: true, value: out as ObjectOf<S> };
});
