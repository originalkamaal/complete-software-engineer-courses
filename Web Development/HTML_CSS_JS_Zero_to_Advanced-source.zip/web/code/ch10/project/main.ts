// file: project/main.ts
import { object, string, number, literal, array, type Infer } from "./schema.ts";

const User = object({
  id: number({ int: true, min: 1 }),
  email: string({ pattern: /^[^@\s]+@[^@\s]+$/ }),
  role: literal("admin", "editor", "viewer"),
  tags: array(string({ min: 1 })),
  nickname: string().optional(),
});
type User = Infer<typeof User>;          // the static type, derived from the runtime schema

function welcome(u: User): string {      // u.role is "admin" | "editor" | "viewer"; u.nickname is string | undefined
  return `${u.nickname ?? u.email} (${u.role})`;
}

for (const json of [
  '{"id": 7, "email": "ana@example.com", "role": "admin", "tags": ["ops"]}',
  '{"id": "7", "email": "ana", "role": "owner", "tags": ["", 3], "password": "x"}',
]) {
  const r = User.parse(JSON.parse(json));
  if (r.ok) console.log("valid:", welcome(r.value));
  else console.log("invalid:\n  " + r.errors.join("\n  "));
}
