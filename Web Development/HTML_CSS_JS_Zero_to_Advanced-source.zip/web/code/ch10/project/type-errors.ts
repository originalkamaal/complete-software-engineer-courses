// file: project/type-errors.ts
// Misuses that the inferred type catches at compile time.
import { object, string, literal, type Infer } from "./schema.ts";
const Post = object({ title: string(), status: literal("draft", "published") });
type Post = Infer<typeof Post>;
const p: Post = { title: "Hello", status: "archived" };
const r = Post.parse({});
console.log(r.value.title);
if (r.ok) console.log(r.value.body);
