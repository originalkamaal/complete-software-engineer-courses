// file: render/slow.js
console.log(`slow.js runs at ${Math.round(performance.now())} ms; ` +
            `paragraph exists: ${document.getElementById("after") !== null}`);
