// file: e2e/playwright.config.js
import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: ".",
  reporter: "list",
  use: { baseURL: "http://localhost:8140", trace: "retain-on-failure" },   // a full trace when a test fails
  webServer: {                                                              // start the app before the tests
    command: "node ../../ch00/project/static.mjs ../../ch08/project 8140",
    url: "http://localhost:8140/demo.html",
  },
});
