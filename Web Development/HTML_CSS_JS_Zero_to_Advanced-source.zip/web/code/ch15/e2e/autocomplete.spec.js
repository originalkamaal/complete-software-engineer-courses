// file: e2e/autocomplete.spec.js
// End-to-end tests of Chapter 8's <auto-complete>, written the way a user perceives the page:
// by role and accessible name, not by CSS classes or shadow-DOM structure.
import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => { await page.goto("/demo.html"); });

test("is a combobox named by its label", async ({ page }) => {
  const box = page.getByRole("combobox", { name: "Country" });
  await expect(box).toBeVisible();
  await expect(box).toHaveAttribute("aria-expanded", "false");
});

test("typing shows matching options, ignoring case and accents", async ({ page }) => {
  await page.getByRole("combobox", { name: "Country" }).fill("OSTER");
  await expect(page.getByRole("option")).toHaveText(["Österreich (Austria)"]);
});

test("arrow keys and Enter choose an option, and the form submits it", async ({ page }) => {
  const box = page.getByRole("combobox", { name: "Country" });
  await box.pressSequentially("ge");
  await expect(page.getByRole("option")).toHaveCount(4);
  await box.press("ArrowDown");
  await box.press("ArrowDown");
  await expect(page.getByRole("option", { name: "Georgia" })).toHaveAttribute("aria-selected", "true");
  await box.press("Enter");
  await expect(box).toHaveValue("Georgia");
  const submitted = page.waitForEvent("console", (m) => m.text().startsWith("submitted"));
  await page.getByRole("button", { name: "Send" }).click();
  expect((await submitted).text()).toBe('submitted: {"country":"Georgia"}');
});

test("Escape closes the list; free text is not a value", async ({ page }) => {
  const box = page.getByRole("combobox", { name: "Country" });
  await box.fill("ni");
  await box.press("Escape");
  await expect(page.getByRole("listbox")).toBeHidden();
  const invalid = page.waitForEvent("console", (m) => m.text().startsWith("invalid"));
  await page.getByRole("button", { name: "Send" }).click();
  await invalid;                                              // required, and "ni" was never chosen
});

test("a mouse user can pick an option", async ({ page }) => {
  await page.getByRole("combobox", { name: "Country" }).fill("ger");
  await page.getByRole("option", { name: "Nigeria" }).click();
  await expect(page.getByRole("combobox", { name: "Country" })).toHaveValue("Nigeria");
});
