// file: unit/debounce.test.js
// Fake timers make time-based code testable in microseconds, deterministically.
import { it, mock } from "node:test";
import assert from "node:assert/strict";
import { debounce } from "./debounce.js";

it("calls once, with the last arguments, after the quiet period", (t) => {
  t.mock.timers.enable({ apis: ["setTimeout"] });
  const search = t.mock.fn();                          // a spy: records its calls
  const debounced = debounce(search, 300);
  debounced("c"); t.mock.timers.tick(100);
  debounced("ca"); t.mock.timers.tick(100);
  debounced("cat");
  t.mock.timers.tick(299);
  assert.equal(search.mock.callCount(), 0);            // still inside the quiet period
  t.mock.timers.tick(1);
  assert.equal(search.mock.callCount(), 1);
  assert.deepEqual(search.mock.calls[0].arguments, ["cat"]);
});

it("a mocked fetch: the code under test never touches the network", async (t) => {
  t.mock.method(globalThis, "fetch", async (url) => new Response(JSON.stringify({ url, hits: 3 })));
  const res = await fetch("https://api.example.com/search?q=cat");
  assert.deepEqual(await res.json(), { url: "https://api.example.com/search?q=cat", hits: 3 });
  assert.equal(globalThis.fetch.mock.callCount(), 1);
});
