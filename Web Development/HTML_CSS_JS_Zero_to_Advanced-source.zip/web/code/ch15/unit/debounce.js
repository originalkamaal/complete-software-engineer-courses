// file: unit/debounce.js
/** Call fn only after `wait` ms have passed without another call (e.g. search-as-you-type). */
export function debounce(fn, wait) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}
