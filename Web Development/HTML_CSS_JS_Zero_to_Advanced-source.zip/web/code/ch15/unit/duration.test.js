// file: unit/duration.test.js
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { parseDuration, formatDuration } from "./duration.js";

describe("parseDuration", () => {
  it("parses single units", () => {
    assert.equal(parseDuration("45s"), 45_000);
    assert.equal(parseDuration("2h"), 7_200_000);
    assert.equal(parseDuration("250ms"), 250);
  });
  it("parses combinations and decimals", () => {
    assert.equal(parseDuration("1h30m"), 5_400_000);
    assert.equal(parseDuration("1.5s"), 1_500);
  });
  it("rejects nonsense with a useful message", () => {
    assert.throws(() => parseDuration("10 minutes"), { name: "SyntaxError", message: /invalid duration/ });
    assert.throws(() => parseDuration(""), TypeError);
  });
  for (const [text, ms] of [["1m", 60_000], ["1m1s", 61_000], ["0s", 0]])     // table-driven cases
    it(`"${text}" is ${ms} ms`, () => assert.equal(parseDuration(text), ms));
});

describe("formatDuration", () => {
  it("is the inverse of parseDuration", () => {
    for (const text of ["1h30m", "45s", "2h5m3s", "250ms"])
      assert.equal(formatDuration(parseDuration(text)), text);
  });
  it("formats zero", () => assert.equal(formatDuration(0), "0ms"));
});
