// file: unit/roundtrip.test.js
// A test that states a property more broadly than the examples above did — and finds a gap.
import { it } from "node:test";
import assert from "node:assert/strict";
import { parseDuration, formatDuration } from "./duration.js";

it("format(parse(x)) gives back x for every valid duration", () => {
  for (const text of ["1h30m", "90s", "45s"]) assert.equal(formatDuration(parseDuration(text)), text);
});
