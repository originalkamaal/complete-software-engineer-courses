// file: unit/duration.js
// Parses durations such as "1h30m", "45s", "2h" into milliseconds.
const UNITS = { h: 3_600_000, m: 60_000, s: 1_000, ms: 1 };

export function parseDuration(text) {
  if (typeof text !== "string" || !text.trim()) throw new TypeError("duration must be a non-empty string");
  let total = 0, rest = text.trim().toLowerCase();
  const part = /^(\d+(?:\.\d+)?)(ms|h|m|s)/;
  while (rest) {
    const m = part.exec(rest);
    if (!m) throw new SyntaxError(`invalid duration: ${JSON.stringify(text)}`);
    total += Number(m[1]) * UNITS[m[2]];
    rest = rest.slice(m[0].length);
  }
  return total;
}

export function formatDuration(ms) {
  const parts = [];
  for (const [unit, size] of Object.entries(UNITS)) {
    if (ms >= size || (unit === "ms" && parts.length === 0)) {
      parts.push(`${Math.floor(ms / size)}${unit}`);
      ms %= size;
    }
  }
  return parts.join("");
}
