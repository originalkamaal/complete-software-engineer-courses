// file: project/specificity.js
// Compute the specificity of a CSS selector as [ids, classes, types] (Selectors Level 4, §17).
// Handles compound and complex selectors, attribute selectors, pseudo-classes, pseudo-elements,
// and the special rules for :is(), :not(), :has(), :nth-child(... of S) and :where().

function splitTopLevel(text, separator = ",") {      // split on commas outside parentheses
  const parts = [];
  let depth = 0, start = 0, quote = null;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) { if (c === quote) quote = null; continue; }
    if (c === '"' || c === "'") quote = c;
    else if (c === "(" || c === "[") depth++;
    else if (c === ")" || c === "]") depth--;
    else if (c === separator && depth === 0) { parts.push(text.slice(start, i)); start = i + 1; }
  }
  parts.push(text.slice(start));
  return parts.map((p) => p.trim());
}

const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const greater = (a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
const maxOf = (list) => list.map(specificity).reduce((m, s) => (greater(s, m) > 0 ? s : m), [0, 0, 0]);

function readParens(sel, i) {                         // sel[i] === "(": return [inside, index after ")"]
  let depth = 0, j = i;
  for (; j < sel.length; j++) {
    if (sel[j] === "(") depth++;
    else if (sel[j] === ")" && --depth === 0) break;
  }
  return [sel.slice(i + 1, j), j + 1];
}

export function specificity(selector) {
  let s = [0, 0, 0], i = 0;
  const sel = selector.trim();
  const ident = () => { const m = /^-?[_a-zA-Z -￿][-\w -￿]*/.exec(sel.slice(i)); i += m ? m[0].length : 0; return m?.[0] ?? ""; };
  while (i < sel.length) {
    const c = sel[i];
    if (c === "#") { i++; ident(); s = add(s, [1, 0, 0]); }
    else if (c === ".") { i++; ident(); s = add(s, [0, 1, 0]); }
    else if (c === "[") { i = sel.indexOf("]", i) + 1; s = add(s, [0, 1, 0]); }
    else if (c === ":" && sel[i + 1] === ":") { i += 2; ident(); if (sel[i] === "(") i = readParens(sel, i)[1]; s = add(s, [0, 0, 1]); }
    else if (c === ":") {
      i++;
      const name = ident().toLowerCase();
      let arg = null;
      if (sel[i] === "(") [arg, i] = readParens(sel, i);
      if (["before", "after", "first-line", "first-letter"].includes(name)) s = add(s, [0, 0, 1]);   // legacy pseudo-elements
      else if (name === "where") { /* contributes nothing */ }
      else if (["is", "not", "has", "matches"].includes(name)) s = add(s, maxOf(splitTopLevel(arg)));
      else if (["nth-child", "nth-last-child"].includes(name) && / of /i.test(arg))
        s = add(add(s, [0, 1, 0]), maxOf(splitTopLevel(arg.split(/ of /i)[1])));
      else s = add(s, [0, 1, 0]);                       // any other pseudo-class
    }
    else if (c === "*") i++;                            // universal selector: nothing
    else if (/[\s>+~]/.test(c)) i++;                    // combinators: nothing
    else if (ident()) s = add(s, [0, 0, 1]);            // type selector
    else throw new SyntaxError(`cannot parse ${JSON.stringify(sel)} at ${i}`);
  }
  return s;
}

export { greater };
