// file: project/slow/app.js
const busy = (ms) => { const end = performance.now() + ms; while (performance.now() < end) {} };
busy(150);                                                   // "initialising" synchronously, before the page renders
addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {                                         // a late banner pushes the content down
    const b = Object.assign(document.createElement("div"), { className: "banner", textContent: "Free shipping this week!" });
    document.getElementById("banner-slot").append(b);
  }, 1000);
  document.getElementById("filter").addEventListener("click", () => {
    busy(300);                                               // filtering 10,000 products, synchronously
    document.getElementById("filter").textContent = "Filtered";
  });
});
