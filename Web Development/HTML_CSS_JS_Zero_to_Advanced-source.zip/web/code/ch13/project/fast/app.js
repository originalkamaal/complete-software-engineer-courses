// file: project/fast/app.js
const busy = (ms) => { const end = performance.now() + ms; while (performance.now() < end) {} };
requestIdleCallback(() => busy(150));                        // non-urgent initialisation, when the browser is idle
setTimeout(() => {
  const b = Object.assign(document.createElement("div"), { className: "banner", textContent: "Free shipping this week!" });
  document.getElementById("banner-slot").append(b);         // fills space that was already reserved
}, 1000);
document.getElementById("filter").addEventListener("click", async () => {
  const button = document.getElementById("filter");
  button.textContent = "Filtering…";                         // immediate feedback, painted at the next frame
  await scheduler.yield();
  for (let i = 0; i < 15; i++) { busy(20); await scheduler.yield(); }   // the same 300 ms of work, in slices
  button.textContent = "Filtered";
});
