// file: project/vitals.js
// Measures the Core Web Vitals in the page itself, the way the web-vitals library does (simplified).
const t = (ms) => `${Math.round(ms)} ms`;
let lcp = 0, cls = 0, worstEvent = 0;
const shifts = [];
new PerformanceObserver((l) => { for (const e of l.getEntries()) lcp = e.startTime; })
  .observe({ type: "largest-contentful-paint", buffered: true });
new PerformanceObserver((l) => {
  for (const e of l.getEntries()) if (!e.hadRecentInput) {
    cls += e.value;
    shifts.push(`${t(e.startTime)}: ${e.value.toFixed(3)} (` +
      e.sources.map((s) => `${s.node?.nodeName ?? "?"} moved ${Math.round(s.currentRect.y - s.previousRect.y)}px`).join(", ") + ")");
  }
})
  .observe({ type: "layout-shift", buffered: true });
new PerformanceObserver((l) => { for (const e of l.getEntries()) worstEvent = Math.max(worstEvent, e.duration); })
  .observe({ type: "event", buffered: true, durationThreshold: 16 });

window.layoutShifts = () => shifts;
window.reportVitals = () => {
  const nav = performance.getEntriesByType("navigation")[0];
  const fcp = performance.getEntriesByName("first-contentful-paint")[0];
  const bytes = [nav, ...performance.getEntriesByType("resource")].reduce((s, e) => s + e.transferSize, 0);
  return `FCP ${t(fcp?.startTime ?? NaN)}, LCP ${t(lcp)}, ` +
         `CLS ${cls.toFixed(3)}, slowest interaction ${t(worstEvent)}, transferred ${Math.round(bytes / 1024)} KiB`;
};
