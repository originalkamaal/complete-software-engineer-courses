// file: node/esm-lib/index.js
export const version = "2.0";
export default function hello(name) { return `hello ${name}`; }
