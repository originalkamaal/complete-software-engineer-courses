// file: node/esm-lib/internal.js
export const secret = 42;
