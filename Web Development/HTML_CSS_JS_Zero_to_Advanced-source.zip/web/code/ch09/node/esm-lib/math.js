// file: node/esm-lib/math.js
export const square = (x) => x * x;
