// file: node/cjs-lib/index.js
// CommonJS: require() and module.exports, loaded synchronously.
exports.version = "1.0";
exports.add = (a, b) => a + b;
console.log(`cjs-lib loaded; __filename ends with ${__filename.split("/").slice(-2).join("/")}`);
