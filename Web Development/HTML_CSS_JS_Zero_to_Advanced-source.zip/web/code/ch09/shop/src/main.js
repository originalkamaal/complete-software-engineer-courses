// file: shop/src/main.js
import "./style.css";                                    // CSS is a module too: Vite injects or extracts it
import { formatPrice } from "./money.js";                // only formatPrice is used ...

const cart = [1999, 2499, 999];
document.getElementById("total").textContent = `Total: ${formatPrice(cart.reduce((a, b) => a + b))}`;
console.log(`main.js running in ${import.meta.env.MODE} mode`);

document.getElementById("stats").addEventListener("click", async () => {
  const { summarize } = await import("./pages/stats.js");    // a separate chunk, loaded on demand
  document.getElementById("out").textContent = summarize(cart);
  console.log("stats chunk loaded and run");
});
