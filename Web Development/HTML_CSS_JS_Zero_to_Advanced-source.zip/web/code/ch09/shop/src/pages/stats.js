// file: shop/src/pages/stats.js
export function summarize(values) {
  const sum = values.reduce((a, b) => a + b, 0);
  return `items ${values.length}, mean ${(sum / values.length / 100).toFixed(2)}, max ${Math.max(...values) / 100}`;
}
