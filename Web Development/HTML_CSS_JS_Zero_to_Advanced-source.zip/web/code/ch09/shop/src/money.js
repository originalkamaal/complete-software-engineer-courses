// file: shop/src/money.js
export const formatPrice = (cents) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);

export function convertCurrencyWithLiveRates(cents) {    // ... so this is never shipped (tree shaking)
  return `UNUSED_EXPORT_MARKER ${cents}`;
}
