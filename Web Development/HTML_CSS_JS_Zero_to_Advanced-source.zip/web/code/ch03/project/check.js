// file: project/check.js
// Measures the layout and checks the requirements at the current viewport size.
const box = (sel) => document.querySelector(sel).getBoundingClientRect();
const cards = [...document.querySelectorAll(".card")].map((c) => c.getBoundingClientRect());
const columns = new Set(cards.map((r) => Math.round(r.left))).size;
const side = box(".sidebar"), main = box("main"), foot = box(".site-footer");
const checks = {
  "no horizontal page scroll": document.documentElement.scrollWidth <= innerWidth,
  "sidebar beside main on wide screens, above it on narrow ones":
    innerWidth >= 768 ? side.right <= main.left : side.bottom <= main.top,
  "footer at the bottom of the viewport or below": Math.round(foot.bottom) >= innerHeight,
  "cards at least 14rem wide unless the screen is narrower": cards.every((r) => r.width >= Math.min(224, main.width - 32)),
};
console.log(`${innerWidth}x${innerHeight}: ${columns} card column(s), sidebar ${Math.round(side.width)}px wide`);
for (const [name, ok] of Object.entries(checks)) console.log(`  ${ok ? "PASS" : "FAIL"}  ${name}`);
