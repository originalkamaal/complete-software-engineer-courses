// file: project/signup.js
// Progressive enhancement: the form works without JavaScript (the server must validate anyway);
// with it, errors are shown next to each field and in a summary that receives focus.
const form = document.getElementById("signup");
const password = document.getElementById("password");
const confirm = document.getElementById("confirm");
const labelOf = (input) => (input.labels[0]?.textContent ?? input.name).trim();

function checkConfirm() {
  confirm.setCustomValidity(confirm.value && confirm.value !== password.value
    ? "The passwords do not match." : "");
}
password.addEventListener("input", checkConfirm);
confirm.addEventListener("input", checkConfirm);

function showErrors() {
  const problems = [];
  for (const input of form.querySelectorAll("input[id]")) {
    const message = input.validity.valid ? "" : input.validationMessage;
    document.getElementById(`${input.id}-error`).textContent = message;
    input.setAttribute("aria-invalid", String(!input.validity.valid));
    if (message) problems.push({ input, message });
  }
  return problems;
}

form.addEventListener("submit", (event) => {
  checkConfirm();
  const problems = showErrors();
  const summary = document.getElementById("summary");
  if (problems.length === 0) { summary.hidden = true; return; }    // let the browser submit
  event.preventDefault();
  const list = document.getElementById("problems");
  list.replaceChildren(...problems.map(({ input, message }) => {
    const link = Object.assign(document.createElement("a"), { href: `#${input.id}`,
      textContent: `${labelOf(input)}: ${message}` });
    const item = document.createElement("li");
    item.append(link);
    return item;
  }));
  summary.hidden = false;
  summary.focus();                                                  // screen readers announce it
  console.log(`blocked: ${problems.length} problems; focus on #${document.activeElement.id}`);
});
