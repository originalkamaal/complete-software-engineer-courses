# file: img/make.sh
for w in 400 800 1600; do
  echo "<svg xmlns='http://www.w3.org/2000/svg' width='$w' height='$((w/2))'><rect width='100%' height='100%' fill='teal'/></svg>" > photo-$w.svg
done
