# Appendix B — Versions and Recent Features

Every example in this book was run with the versions below, installed in one shared `code/` folder. React and Next.js change quickly; the table of features lists the recent ones the book relies on, with where they are used, so you can tell which explanations depend on a version.

| Tool | Version used |
| --- | --- |
| Node.js | 22.23 |
| React and React DOM | 19.3.1 |
| Next.js (Turbopack) | 16.4.6 |
| Vite / `@vitejs/plugin-react` | 8.3.8 / 6.3.0 |
| React Compiler (`babel-plugin-react-compiler`) | 1.0.0 |
| TypeScript | 7.0.2 (the native compiler) |
| `tsx` (running JSX and TypeScript in Node.js) | 4.23.15 |
| React Router | 8.5.1 |
| TanStack Query | 5.107.1 |
| Zustand / Redux Toolkit | 5.1.0 / 2.14.0 |
| Tailwind CSS | 4.3.5 |
| Vitest / jsdom | 5.1.0 / 31.0.1 |
| Testing Library: React / user-event / jest-dom | 16.3.3 / 14.6.12 / 6.9.1 |
| Playwright (`@playwright/test` and the Python driver) | 1.63, Chromium 153 |
| axe-core | 4.14.1 |

| Feature | Introduced in | Where in this book |
| --- | --- | --- |
| `useActionState`, `useFormStatus`, `useOptimistic`, form `action` functions | React 19 | Chapter 4, Chapters 12–15 |
| `useEffectEvent` | React 19.2 | Chapter 3 |
| Resource preloading (`<link rel=preload>`) emitted during server rendering | React 19 | Chapter 1 |
| React Compiler (automatic memoisation) | React Compiler 1.0 | Chapter 6 |
| Server Components, Server Functions (`"use client"`, `"use server"`) | React 19, Next.js App Router | Chapters 12–15 |
| Cache Components: `"use cache"`, `cacheLife`, `cacheTag`, `updateTag`, partial prerendering | Next.js 16 | Chapter 12 |
| `proxy.js` (formerly `middleware.js`) | Next.js 16 | Chapters 13, 15 |
| Loaders, actions, and `HydrateFallback` in data routers | React Router 7+ | Chapter 7 |
| CSS-first configuration (`@theme`) and the Vite plugin | Tailwind CSS 4 | Chapter 10 |
| `node:sqlite` | Node.js 22 (experimental) | Chapters 13, 15 |

## Habits that changed with these versions

- Reach for a form `action` and `useActionState` before writing `onSubmit` handlers that juggle loading and error state.
- Let the React Compiler memoise; write `memo`, `useMemo`, and `useCallback` by hand only where measurement shows a need.
- Fetch on the server (Server Components, loaders) instead of in effects; use effects to synchronise with things outside React.
- Treat every Server Function as a public endpoint: validate, then authorise.
- Decide caching per piece of data (`"use cache"` with tags), not per page.
