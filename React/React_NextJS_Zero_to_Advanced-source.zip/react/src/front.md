---
title: "React and Next.js from Zero to Advanced"
subtitle: "How React really renders — from JSX and hooks to concurrent rendering, the React Compiler, server components, and a tested full-stack Next.js application"
lang: en
---

# Preface

React is easy to start and easy to misuse. Most React bugs come from a mental model that is almost right: that a component is a template rather than a function React calls whenever it likes; that `setState` changes a variable rather than scheduling a new render; that `useEffect` is a lifecycle method rather than a way to synchronise with something outside React; that `useMemo` is a performance switch rather than a cache with rules; that a server component is a component that "runs on the server" in the same way a client component runs in the browser. Almost-right models produce code that works in the demo and fails under real data, real users, and real networks.

This book builds the accurate model. It starts with what JSX compiles to and what an element is — and has you write a renderer for React elements in Chapter 0 — then covers components, props, and state; every hook in depth; effects and data fetching; forms; context, reducers, and external stores; performance, reconciliation, and the React Compiler; routing; server state with TanStack Query; TypeScript; styling; and testing. The last third is Next.js: the App Router, server components, server actions, caching, and streaming; authentication, databases, and deployment; accessibility and internationalisation; and a capstone full-stack application.

The book assumes the knowledge in *HTML, CSS, and JavaScript from Zero to Advanced* — the DOM, the event loop, modules, TypeScript, HTTP — and refers to it where React builds on it.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth: the React documentation (react.dev), the React source code, the Next.js documentation, or a specification.
2. **Evidence.** Every example shown with output was run — with React 19.3, Next.js 16.4, Vite 8, and Node.js 22, pages in a real headless Chromium — and the output is real.
3. **Order.** Nothing is used before it is taught; later chapters refer back by unit number.

# How to use this book

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | Small complete programs and their real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced developers, labelled with their source of truth. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project** with complete code, real output, and a review checklist.

## Running the code

All chapters share one `package.json` and `node_modules` at the top of the code folder; Chapter 0 creates them. Each chapter's folder has a `vite.config.js`, and every subfolder with an `index.html` is a page served by Vite at `/subfolder/`. Programs that only render to strings run directly in Node.js with `tsx`, which compiles JSX on the fly. Next.js projects (Chapters 12–15) have their own folders.

To show what a page does in print, pages are run in headless Chromium by a small driver, `tools/page.py` — the same one as in the HTML, CSS, and JavaScript book, which prints the page's console output, the results of expressions (`=> …`), and accessibility trees. It hides messages from development tooling (Vite's connection notices and React's DevTools hint). From Chapter 14 it also reports keyboard focus and runs the axe-core accessibility checker, and can set the browser's time zone and language. When you read, open the same pages in your browser with the developer tools open.

```python
# file: ../tools/page.py
"""Drive a real browser (headless Chromium, through Playwright) from the command line.

    python3 page.py TARGET [STEP ...] [--serve CMD [--server-log]] [--width W] [--height H]
                    [--dpr N] [--media FEATURE] [--slow] [--tz ZONE] [--locale TAG]

TARGET is a file (opened as file://) or a URL. Console messages and uncaught errors
are printed as they happen. STEPs run in order:
    eval:EXPR       evaluate a JavaScript expression and print "=> result" (JSON)
    click:SEL       click the element matching a CSS selector
    hover:SEL       move the mouse over it
    mouse:X,Y       click at a position (no waiting for the page, unlike click:)
    fill:SEL|TEXT   type TEXT into an input
    upload:SEL|FILE choose FILE in a file input
    select:SEL|VAL  choose an option of a <select>
    press:KEY       press a key (e.g. Enter, Tab)
    wait:MS         wait MS milliseconds
    viewport:WxH    resize the viewport
    media:dark      emulate prefers-color-scheme: dark (or light, reduce for reduced motion)
    offline:on|off  cut or restore the browser's network connection
    reload          reload the page
    shot:FILE       save a screenshot
    aria:SEL        print the accessibility tree of an element, as the browser exposes it
    focus           print the element that has keyboard focus (tag, id, text)
    axe             run the axe-core accessibility checker and print each rule violated
--dpr N sets the device pixel ratio (default 1); --media dark|light|reduce emulates
a media feature from the start; --slow emulates a slow network (400 ms latency, 400 kB/s)
and a 4x slower CPU. --tz and --locale set the browser's time zone (e.g. Asia/Tokyo) and
language (e.g. de-DE; also sent as Accept-Language).
--serve CMD starts a server first (e.g. "node server.js"), waits until TARGET answers,
and stops it at the end; the server's own output is shown only with --server-log.
Messages from development tooling (Vite's connection notices, React's DevTools hint) are hidden.
"""
import json
import os
import re
import shlex
import subprocess
import sys
import time
import urllib.request
from playwright.sync_api import sync_playwright

# Development-server chatter that says nothing about the page itself
NOISE = re.compile(r"^\[vite\] (connecting|connected)|Download the React DevTools")
# The axe-core accessibility checker, installed with the book's packages
AXE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "node_modules", "axe-core", "axe.min.js")

def main():
    args, steps, serve, width, height, dpr, server_log = sys.argv[1:], [], None, 800, 600, 1, False
    media, slow, tz, locale = [], False, None, None
    target = args.pop(0)
    while args:
        a = args.pop(0)
        if a == "--serve": serve = args.pop(0)
        elif a == "--width": width = int(args.pop(0))
        elif a == "--height": height = int(args.pop(0))
        elif a == "--dpr": dpr = float(args.pop(0))
        elif a == "--server-log": server_log = True
        elif a == "--media": media.append(args.pop(0))
        elif a == "--slow": slow = True
        elif a == "--tz": tz = args.pop(0)
        elif a == "--locale": locale = args.pop(0)
        else: steps.append(a)
    server = None
    if serve:
        server = subprocess.Popen(shlex.split(serve), start_new_session=True,
                                  stdout=None if server_log else subprocess.DEVNULL,
                                  stderr=None if server_log else subprocess.DEVNULL)
        for _ in range(100):                                  # wait up to 10 s for the server
            try:
                urllib.request.urlopen(urllib.request.Request(target, method="HEAD"), timeout=1); break
            except urllib.error.HTTPError:
                break                                         # it answered, even if with an error
            except Exception:
                time.sleep(0.1)
    if "://" not in target:
        target = "file://" + os.path.abspath(target)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=dpr,
                                    timezone_id=tz, locale=locale)
            if slow:
                cdp = page.context.new_cdp_session(page)
                cdp.send("Network.emulateNetworkConditions", {"offline": False, "latency": 400,
                         "downloadThroughput": 400_000, "uploadThroughput": 400_000})
                cdp.send("Emulation.setCPUThrottlingRate", {"rate": 4})
            for m in media:
                page.emulate_media(**({"reduced_motion": "reduce"} if m == "reduce" else {"color_scheme": m}))
            page.on("console", lambda m: NOISE.search(m.text) or print(m.text, flush=True))
            page.on("pageerror", lambda e: print(f"Uncaught {e.name}: {e.message}", flush=True))
            page.goto(target)
            for step in steps:
                kind, _, arg = step.partition(":")
                if kind == "eval":
                    print("=>", json.dumps(page.evaluate(arg), ensure_ascii=False), flush=True)
                elif kind == "click": page.click(arg)
                elif kind == "hover": page.hover(arg)
                elif kind == "mouse":
                    x, y = map(float, arg.split(","))
                    page.mouse.click(x, y)
                elif kind == "fill":
                    sel, _, text = arg.partition("|")
                    page.fill(sel, text)
                elif kind == "select":
                    sel, _, val = arg.partition("|")
                    page.select_option(sel, val)
                elif kind == "upload":
                    sel, _, file = arg.partition("|")
                    page.set_input_files(sel, file)
                elif kind == "press": page.keyboard.press(arg)
                elif kind == "wait": page.wait_for_timeout(int(arg))
                elif kind == "viewport":
                    w, h = map(int, arg.split("x"))
                    page.set_viewport_size({"width": w, "height": h})
                elif kind == "media":
                    if arg == "reduce": page.emulate_media(reduced_motion="reduce")
                    else: page.emulate_media(color_scheme=arg)
                elif kind == "offline": page.context.set_offline(arg == "on")
                elif kind == "reload": page.reload()
                elif kind == "shot": page.screenshot(path=arg)
                elif kind == "aria": print(page.locator(arg).first.aria_snapshot(), flush=True)
                elif kind == "focus":
                    print("focus:", page.evaluate("""() => { const e = document.activeElement;
                        return e ? `${e.tagName.toLowerCase()}${e.id ? '#' + e.id : ''} "${(e.textContent || e.value || '').trim().slice(0, 40)}"` : 'none' }"""), flush=True)
                elif kind == "axe":
                    page.add_script_tag(path=AXE)
                    found = page.evaluate("""async () => (await axe.run()).violations.map((v) =>
                        `${v.id} (${v.impact}): ${v.help} — ${v.nodes.map((n) => n.target.join(' ')).join(', ')}`)""")
                    print(f"axe: {len(found)} violation(s)", *found, sep="\n  ", flush=True)
                else: sys.exit(f"unknown step {step!r}")
            page.wait_for_timeout(50)                         # let late console messages arrive
            browser.close()
    finally:
        if server:
            os.killpg(server.pid, 15)

if __name__ == "__main__":
    main()
```
