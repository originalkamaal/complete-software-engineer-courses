// file: project/comments.jsx
// A comment form with React 19 actions: server-side validation errors next to each field,
// the typed text kept when validation fails, a pending button, and an optimistic comment
// that appears at once and is replaced (or removed) when the server answers.
import { startTransition, useActionState, useOptimistic, useState } from "react";
import { useFormStatus } from "react-dom";

async function postComment(comment) {
  const res = await fetch("/api/comments", { method: "POST", body: JSON.stringify(comment) });
  const data = await res.json();
  if (res.status === 422) return { errors: data.errors };
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return { comment: data };
}

function Submit() {
  const { pending } = useFormStatus();
  return <button disabled={pending}>{pending ? "Posting…" : "Post comment"}</button>;
}

export function Comments({ initial }) {
  const [comments, setComments] = useState(initial);
  const [optimistic, addOptimistic] = useOptimistic(comments, (list, c) => [...list, { ...c, pending: true }]);

  const [form, formAction] = useActionState(async (_previous, data) => {
    const values = { author: data.get("author"), text: data.get("text") };
    addOptimistic({ id: "pending", ...values });                         // show it now ...
    const result = await postComment(values);
    if (result.errors) return { values, errors: result.errors };         // ... it vanishes: keep the input
    startTransition(() => setComments((list) => [...list, result.comment]));   // ... replaced by the real one
    return { values: { author: values.author, text: "" }, errors: {} };  // keep the name, clear the text
  }, { values: { author: "", text: "" }, errors: {} });

  const field = (name, label, Tag = "input") => (
    <p>
      <label htmlFor={name}>{label}</label>{" "}
      <Tag id={name} name={name} defaultValue={form.values[name]} aria-invalid={Boolean(form.errors[name])}
           aria-describedby={form.errors[name] ? `${name}-error` : undefined} />
      {form.errors[name] && <span id={`${name}-error`} role="alert"> {form.errors[name]}</span>}
    </p>
  );
  return (
    <section aria-labelledby="c-h">
      <h2 id="c-h">Comments ({optimistic.length})</h2>
      <ul>{optimistic.map((c) => <li key={c.id} aria-busy={c.pending ? true : undefined}>
        <b>{c.author}</b>: {c.text}{c.pending && " (sending…)"}</li>)}</ul>
      <form action={formAction}>
        {field("author", "Name")}
        {field("text", "Comment", "textarea")}
        <Submit />
      </form>
    </section>
  );
}
