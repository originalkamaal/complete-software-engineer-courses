// file: project/main.jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Comments } from "./comments.jsx";

const initial = await fetch("/api/comments").then((r) => r.json());
createRoot(document.getElementById("root")).render(<StrictMode><Comments initial={initial} /></StrictMode>);
