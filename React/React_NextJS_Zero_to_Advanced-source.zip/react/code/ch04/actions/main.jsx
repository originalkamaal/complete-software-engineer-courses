// file: actions/main.jsx
// React 19 form actions: pass a function as the form's action; React calls it with the FormData,
// tracks the pending state, and resets the (uncontrolled) form when the action finishes.
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { createRoot } from "react-dom/client";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function SubmitButton() {
  const { pending } = useFormStatus();            // the status of the nearest parent <form>
  return <button disabled={pending}>{pending ? "Saving…" : "Save"}</button>;
}

async function save(previous, formData) {         // (previous state, form data) -> next state
  await sleep(300);
  const title = formData.get("title");
  if (title.length < 3) return { ...previous, error: "Title needs at least 3 characters" };
  return { saved: [...previous.saved, title], error: null };
}

function Notes() {
  const [state, action, isPending] = useActionState(save, { saved: [], error: null });
  return (
    <form action={action}>
      <input name="title" aria-label="Title" />
      <SubmitButton />
      <p id="status">{isPending ? "pending" : "idle"}; saved: {state.saved.join(", ") || "none"}; error: {state.error ?? "none"}</p>
    </form>
  );
}
createRoot(document.getElementById("root")).render(<Notes />);
