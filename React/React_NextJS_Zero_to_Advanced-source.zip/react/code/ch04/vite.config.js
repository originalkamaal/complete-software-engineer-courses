// file: vite.config.js
// This chapter's fake API: POST /api/comments validates and stores comments, slowly.
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const comments = [{ id: 1, author: "Ana", text: "First!" }];
function fakeApi() {
  return {
    name: "fake-api",
    configureServer(server) {
      server.middlewares.use("/api/comments", async (req, res) => {
        res.setHeader("Content-Type", "application/json");
        if (req.method === "GET") return res.end(JSON.stringify(comments));
        let body = ""; for await (const c of req) body += c;
        const { author = "", text = "" } = JSON.parse(body || "{}");
        const errors = {};
        if (!author.trim()) errors.author = "Please give your name.";
        if (text.trim().length < 5) errors.text = "A comment needs at least 5 characters.";
        if (/spam/i.test(text)) errors.text = "That looks like spam.";
        await new Promise((r) => setTimeout(r, 400));                 // a slow server
        console.log(`  api: POST comment by "${author}" -> ${Object.keys(errors).length ? "422" : "201"}`);
        if (Object.keys(errors).length) { res.statusCode = 422; return res.end(JSON.stringify({ errors })); }
        const comment = { id: comments.length + 1, author: author.trim(), text: text.trim() };
        comments.push(comment);
        res.statusCode = 201; res.end(JSON.stringify(comment));
      });
    },
  };
}
export default defineConfig({
  plugins: [react(), fakeApi()],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client", "react-dom"] },
});
