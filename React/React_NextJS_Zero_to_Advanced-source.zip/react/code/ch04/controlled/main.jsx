// file: controlled/main.jsx
// Controlled inputs: React state is the single source of truth, and every keystroke goes through it.
import { useState } from "react";
import { createRoot } from "react-dom/client";

function Controlled() {
  const [name, setName] = useState("");
  const [qty, setQty] = useState(1);
  const [agree, setAgree] = useState(false);
  const [size, setSize] = useState("m");
  return (
    <form id="controlled" onSubmit={(e) => { e.preventDefault(); console.log(JSON.stringify({ name, qty, agree, size })); }}>
      <input aria-label="Name" value={name} onChange={(e) => setName(e.target.value.toUpperCase())} />
      <input aria-label="Quantity" type="number" value={qty} onChange={(e) => setQty(e.target.valueAsNumber || 0)} />
      <input aria-label="Agree" type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
      <select aria-label="Size" value={size} onChange={(e) => setSize(e.target.value)}>
        <option value="s">S</option><option value="m">M</option><option value="l">L</option>
      </select>
      <button>Submit controlled</button>
    </form>
  );
}

function Uncontrolled() {
  // The DOM holds the values; React only sets the defaults. Read them once, on submit.
  return (
    <form id="uncontrolled" onSubmit={(e) => { e.preventDefault(); console.log(JSON.stringify(Object.fromEntries(new FormData(e.currentTarget)))); }}>
      <input name="name" aria-label="Name 2" defaultValue="Ana" />
      <input name="agree" type="checkbox" aria-label="Agree 2" defaultChecked />
      <button>Submit uncontrolled</button>
    </form>
  );
}

function Frozen() {
  return <input aria-label="Frozen" value="can't change me" />;     // value without onChange: read-only
}

function Switching() {
  const [v, setV] = useState();                                       // undefined at first: uncontrolled!
  return <input aria-label="Switching" value={v} onChange={(e) => setV(e.target.value)} />;
}

createRoot(document.getElementById("root")).render(<><Controlled /><Uncontrolled /><Frozen /><Switching /></>);
