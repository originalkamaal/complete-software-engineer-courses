// file: vite.config.js
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],                 // Tailwind v4: a Vite plugin, configured in CSS
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client"] },
  build: { rollupOptions: { input: { tw: "tw/index.html", project: "project/index.html" } } },
});
