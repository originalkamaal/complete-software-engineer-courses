// file: modules/main.jsx
import { createRoot } from "react-dom/client";
import card from "./Card.module.css";
import alert from "./Alert.module.css";

console.log("Card classes:", JSON.stringify(card));
console.log("Alert classes:", JSON.stringify(alert));
function App() {
  return <>
    <article className={card.highlighted}><h2 className={card.title}>Card title</h2></article>
    <p className={alert.title}>Alert title</p>
  </>;
}
createRoot(document.getElementById("root")).render(<App />);
window.colors = () => [...document.querySelectorAll("h2, p")].map((e) => `${e.textContent}: ${getComputedStyle(e).color}, ${getComputedStyle(e).fontSize}`);
