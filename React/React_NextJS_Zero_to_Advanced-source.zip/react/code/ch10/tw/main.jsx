// file: tw/main.jsx
import "./style.css";
import { createRoot } from "react-dom/client";

function App() {
  return <main className="mx-auto max-w-md p-4">
    <h1 className="text-2xl font-bold text-brand">Tailwind</h1>
    <button id="a" className="rounded bg-brand px-4 py-2 text-white hover:opacity-90 md:px-8">Responsive padding</button>
    <button id="b" className="p-4 p-2">"p-4 p-2"</button>
    <button id="c" className="p-2 p-4">"p-2 p-4"</button>
    <p id="d" className="w-[37px] dark:text-yellow-300">arbitrary value</p>
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
window.pads = () => ["a", "b", "c"].map((id) => `${id}: ${getComputedStyle(document.getElementById(id)).paddingLeft}`)
  .concat(`d width ${getComputedStyle(document.getElementById("d")).width}`);
