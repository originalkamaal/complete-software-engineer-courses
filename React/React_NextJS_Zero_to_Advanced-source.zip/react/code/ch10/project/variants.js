// file: project/variants.js
// A small variant helper (the idea behind libraries such as cva): turn a component's props into
// a class list, with defaults and combinations, so that styling rules live in one table.
export function variants({ base = "", variants = {}, defaults = {}, compound = [] }) {
  return (props = {}) => {
    const chosen = { ...defaults, ...Object.fromEntries(Object.entries(props).filter(([, v]) => v !== undefined)) };
    const classes = [base];
    for (const [name, options] of Object.entries(variants)) classes.push(options[chosen[name]] ?? "");
    for (const { when, className } of compound)
      if (Object.entries(when).every(([k, v]) => chosen[k] === v)) classes.push(className);
    return classes.filter(Boolean).join(" ");
  };
}
