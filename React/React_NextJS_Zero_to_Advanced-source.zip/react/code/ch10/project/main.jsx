// file: project/main.jsx
import "./style.css";
import { createRoot } from "react-dom/client";
import { Button } from "./Button.jsx";

createRoot(document.getElementById("root")).render(<p className="flex gap-2 p-4">
  <Button id="b1">Save</Button>
  <Button id="b2" intent="secondary" size="sm">Cancel</Button>
  <Button id="b3" intent="danger" size="lg">Delete everything</Button>
  <Button id="b4" disabled>Disabled</Button>
</p>);
window.styles = () => ["b1", "b2", "b3", "b4"].map((id) => {
  const s = getComputedStyle(document.getElementById(id));
  return `${id}: bg ${s.backgroundColor}, padding ${s.paddingTop} ${s.paddingLeft}, font ${s.fontSize}, ${s.textTransform}, opacity ${s.opacity}`;
});
