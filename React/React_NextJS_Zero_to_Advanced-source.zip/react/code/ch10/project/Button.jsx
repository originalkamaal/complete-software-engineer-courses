// file: project/Button.jsx
import { variants } from "./variants.js";

const button = variants({
  base: "inline-flex items-center gap-2 rounded-md font-medium focus-visible:outline-2 focus-visible:outline-offset-2 disabled:opacity-50",
  variants: {
    intent: { primary: "bg-brand text-white", secondary: "bg-zinc-100 text-zinc-900", danger: "bg-red-600 text-white" },
    size: { sm: "px-2 py-1 text-sm", md: "px-4 py-2 text-base", lg: "px-6 py-3 text-lg" },
  },
  defaults: { intent: "primary", size: "md" },
  compound: [{ when: { intent: "danger", size: "lg" }, className: "uppercase tracking-wide" }],
});

export function Button({ intent, size, className = "", ...props }) {
  return <button className={`${button({ intent, size })} ${className}`} {...props} />;
}
