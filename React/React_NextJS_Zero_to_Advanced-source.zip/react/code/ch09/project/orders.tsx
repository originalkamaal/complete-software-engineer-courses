// file: project/orders.tsx
import { renderToString } from "react-dom/server";
import { DataTable, type Column } from "./DataTable.tsx";

interface Order { id: number; customer: string; total: number; placed: Date; tags: string[] }
const orders: Order[] = [
  { id: 1, customer: "Bo", total: 25.5, placed: new Date("2026-03-01"), tags: ["gift"] },
  { id: 2, customer: "Ana", total: 120, placed: new Date("2026-01-15"), tags: [] },
  { id: 3, customer: "Cy", total: 9.99, placed: new Date("2026-02-10"), tags: ["express", "gift"] },
];
const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const columns: Column<Order>[] = [
  { key: "id", header: "#", sortable: true },
  { key: "customer", header: "Customer", sortable: true },
  { key: "total", header: "Total", sortable: true, render: (o) => money.format(o.total) },
  { key: "placed", header: "Placed", sortable: true, render: (o) => o.placed.toISOString().slice(0, 10) },
  { key: "tagList", header: "Tags", render: (o) => o.tags.join(", ") || "—" },   // computed: needs render
];

const html = renderToString(<DataTable rows={orders} columns={columns} rowKey={(o) => o.id} caption="Orders"
                                       initialSort={{ key: "total", dir: "desc" }} />);
console.log(html.replace(/<\/tr>/g, "</tr>\n"));

// Compile-time checks: each line must fail to type-check.
// @ts-expect-error: "tags" is an array, not a sortable field
const _a: Column<Order> = { key: "tags", header: "Tags", sortable: true };
// @ts-expect-error: a computed column must have a render function
const _b: Column<Order> = { key: "tagList", header: "Tags" };
// @ts-expect-error: "price" is not a field of Order
const _c = <DataTable rows={orders} columns={columns} rowKey={(o) => o.id} caption="x" initialSort={{ key: "price", dir: "asc" }} />;
