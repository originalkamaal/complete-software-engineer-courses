// file: project/DataTable.tsx
// A generic, sortable, accessible table. Columns are checked against the row type at compile time.
import { useState, type ReactNode } from "react";

type Primitive = string | number | boolean | Date | null | undefined;
type SortableKey<T> = { [K in keyof T]: T[K] extends Primitive ? K : never }[keyof T];   // keys of sortable fields

export type Column<T> =
  | { key: SortableKey<T>; header: string; render?: (row: T) => ReactNode; sortable?: boolean }
  | { key: string; header: string; render: (row: T) => ReactNode; sortable?: false };     // computed columns

interface Props<T> {
  rows: readonly T[];
  columns: readonly Column<T>[];
  rowKey: (row: T) => string | number;
  caption: string;
  initialSort?: { key: SortableKey<T>; dir: "asc" | "desc" };
}

const compare = (a: Primitive, b: Primitive) =>
  a == null ? 1 : b == null ? -1 : a instanceof Date && b instanceof Date ? a.getTime() - b.getTime()
  : typeof a === "string" && typeof b === "string" ? a.localeCompare(b) : Number(a) - Number(b);

export function DataTable<T>({ rows, columns, rowKey, caption, initialSort }: Props<T>) {
  const [sort, setSort] = useState(initialSort ?? null);
  const sorted = sort
    ? [...rows].sort((x, y) => compare(x[sort.key] as Primitive, y[sort.key] as Primitive) * (sort.dir === "asc" ? 1 : -1))
    : rows;
  return (
    <table>
      <caption>{caption}</caption>
      <thead><tr>{columns.map((c) => {
        const active = sort?.key === c.key;
        return (
          <th key={String(c.key)} scope="col" aria-sort={active ? (sort!.dir === "asc" ? "ascending" : "descending") : undefined}>
            {c.sortable ? (
              <button onClick={() => setSort({ key: c.key as SortableKey<T>, dir: active && sort!.dir === "asc" ? "desc" : "asc" })}>
                {c.header}
              </button>
            ) : c.header}
          </th>
        );
      })}</tr></thead>
      <tbody>{sorted.map((row) => (
        <tr key={rowKey(row)}>{columns.map((c) => (
          <td key={String(c.key)}>{c.render ? c.render(row) : String((row as Record<string, unknown>)[c.key as string] ?? "")}</td>
        ))}</tr>
      ))}</tbody>
    </table>
  );
}
