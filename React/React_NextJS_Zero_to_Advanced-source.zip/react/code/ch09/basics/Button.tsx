// file: basics/Button.tsx
// Typing components: props interfaces, children, events, state, refs, and native props.
import { useRef, useState, type ComponentProps, type ReactNode } from "react";

type Variant = "primary" | "danger";
interface ButtonProps extends ComponentProps<"button"> {   // every native <button> prop, plus ours
  variant?: Variant;
  icon?: ReactNode;                                          // anything renderable: elements, strings, null...
}
export function Button({ variant = "primary", icon, children, ...rest }: ButtonProps) {
  return <button className={`btn btn-${variant}`} {...rest}>{icon}{children}</button>;
}

export function NameField({ onSubmit }: { onSubmit: (name: string) => void }) {
  const [name, setName] = useState("");                      // inferred: string
  const [age, setAge] = useState<number | null>(null);       // a union needs an explicit type argument
  const input = useRef<HTMLInputElement>(null);              // a DOM ref: RefObject<HTMLInputElement | null>
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) { setName(e.target.value); }
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(name); input.current?.focus(); }}>
      <input ref={input} value={name} onChange={handleChange} />
      <input type="number" value={age ?? ""} onChange={(e) => setAge(e.target.value ? Number(e.target.value) : null)} />
      <Button type="submit" variant="primary" disabled={!name}>Save</Button>
    </form>
  );
}
