// file: basics/mistakes.tsx
// Mistakes the compiler catches.
import { useState } from "react";
import { Button, NameField } from "./Button.tsx";

export function Page() {
  const [count, setCount] = useState(0);
  return (
    <main>
      <Button variant="warning">Delete</Button>
      <Button onClick={(e) => e.target.value}>Click</Button>
      <NameField onSubmit={(name: number) => setCount(name)} />
      <NameField />
      {setCount("1")}
      <input onChange={(e) => setCount(e.target.value)} />
    </main>
  );
}
