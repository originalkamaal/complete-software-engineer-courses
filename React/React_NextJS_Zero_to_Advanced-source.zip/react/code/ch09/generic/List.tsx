// file: generic/List.tsx
// A generic component: the type of `items` decides the type of `renderItem`'s argument and of `getKey`.
import type { Key, ReactNode } from "react";

interface ListProps<T> {
  items: readonly T[];
  getKey: (item: T) => Key;
  renderItem: (item: T) => ReactNode;
  empty?: ReactNode;
}
export function List<T>({ items, getKey, renderItem, empty = "Nothing here." }: ListProps<T>) {
  if (items.length === 0) return <p>{empty}</p>;
  return <ul>{items.map((item) => <li key={getKey(item)}>{renderItem(item)}</li>)}</ul>;
}

const users = [{ id: 1, name: "Ana" }, { id: 2, name: "Bo" }];
export const ok = <List items={users} getKey={(u) => u.id} renderItem={(u) => u.name.toUpperCase()} />;
// @ts-expect-error: users have no "email"; T was inferred from `items`
export const bad = <List items={users} getKey={(u) => u.id} renderItem={(u) => u.email} />;
