// file: generic/context.tsx
// Typed reducers and context: a discriminated union of actions, and a context hook that fails
// loudly when used outside its provider, so components never have to handle "undefined".
import { createContext, use, useReducer, type Dispatch, type ReactNode } from "react";

interface Todo { id: number; text: string; done: boolean }
type Action =
  | { type: "added"; text: string }
  | { type: "toggled"; id: number }
  | { type: "removed"; id: number };

function reducer(todos: Todo[], action: Action): Todo[] {
  switch (action.type) {
    case "added": return [...todos, { id: todos.length + 1, text: action.text, done: false }];
    case "toggled": return todos.map((t) => (t.id === action.id ? { ...t, done: !t.done } : t));
    case "removed": return todos.filter((t) => t.id !== action.id);
    default: { const unreachable: never = action; throw new Error(`unknown action ${JSON.stringify(unreachable)}`); }
  }
}

const TodosContext = createContext<{ todos: Todo[]; dispatch: Dispatch<Action> } | null>(null);

export function TodosProvider({ children }: { children: ReactNode }) {
  const [todos, dispatch] = useReducer(reducer, []);
  return <TodosContext value={{ todos, dispatch }}>{children}</TodosContext>;
}
export function useTodos() {
  const value = use(TodosContext);
  if (!value) throw new Error("useTodos must be used inside <TodosProvider>");
  return value;                                     // typed without null from here on
}

export function AddButton() {
  const { dispatch } = useTodos();
  // @ts-expect-error: "add" is not an action type, and "text" is required
  dispatch({ type: "add" });
  return <button onClick={() => dispatch({ type: "added", text: "milk" })}>Add</button>;
}
