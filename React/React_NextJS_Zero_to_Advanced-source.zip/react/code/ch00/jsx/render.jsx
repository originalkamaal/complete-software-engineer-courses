// file: jsx/render.jsx
// Rendering turns elements into output. On the server: a string of HTML.
import { renderToString } from "react-dom/server";
import { Card } from "./card.jsx";

const xss = '<img src=x onerror="alert(1)">';
console.log(renderToString(<Card title={xss} tags={["new", "sale"]} />));
console.log(renderToString(<Card title="No tags" tags={[]} />));
console.log(renderToString(<ul>{[0, "", null, undefined, false, true, NaN].map((v, i) => <li key={i}>{v}</li>)}</ul>));
