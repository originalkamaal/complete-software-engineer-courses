// file: jsx/card.jsx
export function Card({ title, tags, onOpen }) {
  return (
    <article className="card">
      <h2>{title}</h2>
      {tags.length > 0 && <ul>{tags.map((t) => <li key={t}>{t}</li>)}</ul>}
      <button onClick={onOpen}>Open</button>
    </article>
  );
}
