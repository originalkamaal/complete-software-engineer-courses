// file: jsx/elements.jsx
// A React element is a plain, immutable object that DESCRIBES what to show. Nothing is rendered yet.
import { renderToString } from "react-dom/server";
import { Card } from "./card.jsx";

const el = <Card title="Hello" tags={["new"]} onOpen={() => {}} />;
console.log("type is the component function itself:", el.type === Card);
console.log("props:", Object.keys(el.props), "| key:", el.key, "| frozen:", Object.isFrozen(el));

let calls = 0;
function Counted() { calls++; return <p>counted</p>; }
const tree = <div><Counted /><Counted /></div>;
console.log("after creating the tree, Counted has been called", calls, "times");   // React calls it, later

const user = { name: "Ana" };
console.log(<p>{user.name}</p>.props.children, "|", <p>{"<b>not bold</b>"}</p>.props.children);
try { renderToString(<p>{user}</p>); } catch (e) { console.log(e.message.split(". ")[0]); }
