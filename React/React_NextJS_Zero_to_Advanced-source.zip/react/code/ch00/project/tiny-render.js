// file: project/tiny-render.js
// A renderer for React elements, in 60 lines. React elements are plain objects; components are
// functions from props to elements. Rendering means walking that tree until only strings are left.
import { Fragment } from "react";

const escapeText = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
const escapeAttr = (s) => escapeText(s).replace(/"/g, "&quot;");
const VOID = new Set(["br", "hr", "img", "input", "meta", "link"]);
const ATTR = { className: "class", htmlFor: "for" };

/** Render an element tree to an HTML string (like react-dom/server's renderToString, minus its markers). */
export function renderToHtml(node) {
  if (node === null || node === undefined || typeof node === "boolean") return "";   // renders nothing
  if (typeof node === "string" || typeof node === "number") return escapeText(node);
  if (Array.isArray(node)) return node.map(renderToHtml).join("");
  const { type, props } = node;
  if (type === Fragment) return renderToHtml(props.children);
  if (typeof type === "function") return renderToHtml(type(props));              // a component: call it
  let attrs = "";
  for (const [name, value] of Object.entries(props)) {
    if (name === "children" || name.startsWith("on") || value == null || value === false) continue;
    if (name === "style") {
      const css = Object.entries(value).map(([k, v]) => `${k.replace(/[A-Z]/g, (c) => "-" + c.toLowerCase())}:${v}`).join(";");
      attrs += ` style="${escapeAttr(css)}"`;
    } else attrs += ` ${ATTR[name] ?? name}${value === true ? '=""' : `="${escapeAttr(value)}"`}`;
  }
  if (VOID.has(type)) return `<${type}${attrs}/>`;
  return `<${type}${attrs}>${renderToHtml(props.children)}</${type}>`;
}

/** Create real DOM nodes from an element tree (once: no updates, no state). */
export function mount(node, parent) {
  if (node === null || node === undefined || typeof node === "boolean") return;
  if (typeof node === "string" || typeof node === "number") return parent.append(String(node));
  if (Array.isArray(node)) return node.forEach((n) => mount(n, parent));
  const { type, props } = node;
  if (type === Fragment) return mount(props.children, parent);
  if (typeof type === "function") return mount(type(props), parent);
  const el = document.createElement(type);
  for (const [name, value] of Object.entries(props)) {
    if (name === "children" || value == null) continue;
    if (name.startsWith("on")) el.addEventListener(name.slice(2).toLowerCase(), value);
    else if (name === "style") Object.assign(el.style, value);
    else if (name in el) el[name] = value;                                         // className, htmlFor, value...
    else el.setAttribute(name, value);
  }
  mount(props.children, el);
  parent.append(el);
}
