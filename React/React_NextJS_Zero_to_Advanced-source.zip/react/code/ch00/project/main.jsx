// file: project/main.jsx
import { mount } from "./tiny-render.js";
import { ProductList, products } from "./app.jsx";

mount(<ProductList products={products} onBuy={(p) => console.log(`buy ${p.name}`)} />, document.getElementById("root"));
console.log(`mounted: ${document.querySelectorAll("li").length} items, ` +
            `second button disabled: ${document.querySelectorAll("button")[1].disabled}`);
