// file: project/app.jsx
export function Badge({ children, tone = "info" }) {
  return <span className={`badge badge-${tone}`} title={tone}>{children}</span>;
}
export function ProductList({ products, onBuy }) {
  return (
    <>
      <h1>Products ({products.length})</h1>
      <ul>
        {products.map((p) => (
          <li key={p.id} style={{ fontWeight: p.featured ? "bold" : "normal" }}>
            {p.name} — {p.price.toFixed(2)} {p.stock === 0 && <Badge tone="warn">sold out</Badge>}
            <button disabled={p.stock === 0} onClick={() => onBuy(p)}>Buy</button>
          </li>
        ))}
      </ul>
      <label htmlFor="q">Search</label><input id="q" placeholder={'"quoted" & <angled>'} />
    </>
  );
}
export const products = [
  { id: 1, name: "Tea <green>", price: 4.5, stock: 10, featured: true },
  { id: 2, name: "Coffee & cream", price: 6, stock: 0, featured: false },
];
