// file: project/compare.jsx
// Does our renderer agree with React's? Compare the HTML both produce for the same element tree.
import { renderToString } from "react-dom/server";
import { renderToHtml } from "./tiny-render.js";
import { ProductList, products } from "./app.jsx";

const tree = <ProductList products={products} onBuy={() => {}} />;
const ours = renderToHtml(tree);
const reacts = renderToString(tree).replaceAll("<!-- -->", "");   // React separates adjacent text nodes
console.log(ours);
console.log(ours === reacts ? "identical to React's output" : `DIFFERENT from React's:\n${reacts}`);
