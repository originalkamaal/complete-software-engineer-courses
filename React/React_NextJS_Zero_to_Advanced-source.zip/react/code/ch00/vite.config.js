// file: vite.config.js
// One Vite configuration per chapter: every folder with an index.html is a page at /folder/.
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  logLevel: "warn",
  // Pre-bundle React when the server starts. Otherwise Vite discovers it on the first page load,
  // bundles it, and reloads the page, so everything in it runs twice.
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client"] },
});
