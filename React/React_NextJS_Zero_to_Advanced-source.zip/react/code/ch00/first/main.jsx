// file: first/main.jsx
import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";

function Counter() {
  const [count, setCount] = useState(0);              // state: React remembers it between renders
  console.log(`Counter renders with count = ${count}`);
  return (
    <p>
      Clicked {count} {count === 1 ? "time" : "times"}{" "}
      <button onClick={() => setCount(count + 1)}>Click</button>
    </p>
  );
}

const root = createRoot(document.getElementById("root"));
root.render(<StrictMode><Counter /></StrictMode>);   // StrictMode: extra checks in development
