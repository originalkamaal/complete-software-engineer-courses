// file: project/Tabs.jsx
import { useId, useRef, useState } from "react";

// The WAI-ARIA tabs pattern: one tab stop for the whole tab list (roving tabindex),
// arrow keys move between tabs (mirrored in right-to-left text), Home and End jump to the ends.
export function Tabs({ label, tabs, dir = "ltr" }) {
  const [selected, setSelected] = useState(0);
  const refs = useRef([]);
  const base = useId();

  function onKeyDown(event) {
    const last = tabs.length - 1;
    const forward = dir === "rtl" ? "ArrowLeft" : "ArrowRight";
    const back = dir === "rtl" ? "ArrowRight" : "ArrowLeft";
    const next = { [forward]: selected === last ? 0 : selected + 1,
                   [back]: selected === 0 ? last : selected - 1, Home: 0, End: last }[event.key];
    if (next === undefined) return;
    event.preventDefault();                       // Home/End would otherwise scroll the page
    setSelected(next);
    refs.current[next].focus();
  }

  return <div>
    <div role="tablist" aria-label={label} onKeyDown={onKeyDown}>
      {tabs.map((tab, i) => (
        <button key={tab.id} role="tab" id={`${base}-tab-${i}`} aria-controls={`${base}-panel-${i}`}
          aria-selected={i === selected} tabIndex={i === selected ? 0 : -1}
          ref={(el) => { refs.current[i] = el; }} onClick={() => setSelected(i)}>{tab.label}</button>
      ))}
    </div>
    {tabs.map((tab, i) => (
      <div key={tab.id} role="tabpanel" id={`${base}-panel-${i}`} aria-labelledby={`${base}-tab-${i}`}
        tabIndex={0} hidden={i !== selected}>{tab.content}</div>
    ))}
  </div>;
}
