// file: project/main.jsx
import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Tabs } from "./Tabs.jsx";
import { LOCALES, makeT } from "./i18n.js";

const ORDER = { items: ["Lamp", "Desk", "Chair"], total: 1234.5, arrives: new Date("2026-03-05T12:00:00Z"), last4: "4242" };

function App() {
  const [locale, setLocale] = useState(new URLSearchParams(location.search).get("lang") ?? "en");
  const { dir } = LOCALES[locale];
  const t = makeT(locale);
  useEffect(() => {                                   // the whole document's language and direction
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const money = new Intl.NumberFormat(locale, { style: "currency", currency: "EUR" }).format(ORDER.total);
  const date = new Intl.DateTimeFormat(locale, { dateStyle: "full", timeZone: "UTC" }).format(ORDER.arrives);
  return <main>
    <h1>{t("title")}</h1>
    <label>{t("language")}{" "}
      <select value={locale} onChange={(e) => setLocale(e.target.value)}>
        {Object.entries(LOCALES).map(([code, l]) => <option key={code} value={code} lang={code}>{l.name}</option>)}
      </select>
    </label>
    <Tabs key={locale} label={t("tabs")} dir={dir} tabs={[
      { id: "items", label: t("items"), content: <p>{t("count", { n: ORDER.items.length })} — {t("total", { amount: money })}</p> },
      { id: "shipping", label: t("shipping"), content: <p>{t("arrives", { date })}</p> },
      { id: "payment", label: t("payment"), content: <p>{t("paid", { last4: ORDER.last4 })}</p> },
    ]} />
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
window.state = () => `${document.documentElement.lang}/${document.documentElement.dir} selected="${document.querySelector('[aria-selected=true]').textContent}" panel="${document.querySelector('[role=tabpanel]:not([hidden])').textContent}"`;
