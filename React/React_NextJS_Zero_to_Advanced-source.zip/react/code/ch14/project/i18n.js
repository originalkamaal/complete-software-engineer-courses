// file: project/i18n.js
export const LOCALES = {
  en: { dir: "ltr", name: "English" },
  ar: { dir: "rtl", name: "العربية" },
};

const MESSAGES = {
  en: {
    title: "Order summary", tabs: "Order details", items: "Items", shipping: "Shipping", payment: "Payment",
    count: { one: "{n} item", other: "{n} items" }, total: "Total: {amount}", arrives: "Arrives {date}",
    paid: "Paid by card ending {last4}", language: "Language",
  },
  ar: {
    title: "ملخص الطلب", tabs: "تفاصيل الطلب", items: "المنتجات", shipping: "الشحن", payment: "الدفع",
    count: { zero: "لا منتجات", one: "منتج واحد", two: "منتجان", few: "{n} منتجات", many: "{n} منتجًا", other: "{n} منتج" },
    total: "الإجمالي: {amount}", arrives: "يصل {date}", paid: "دُفع ببطاقة تنتهي بـ {last4}", language: "اللغة",
  },
};

export function makeT(locale) {
  const nf = new Intl.NumberFormat(locale);
  const pr = new Intl.PluralRules(locale);
  return function t(key, values = {}) {
    let message = MESSAGES[locale][key];
    if (typeof message === "object") message = message[pr.select(values.n)] ?? message.other;
    return message.replace(/\{(\w+)\}/g, (_, name) =>
      typeof values[name] === "number" ? nf.format(values[name]) : String(values[name]));
  };
}
