// file: dialog/main.jsx
import { useState } from "react";
import { createRoot } from "react-dom/client";
import { Dialog } from "./Dialog.jsx";

function App() {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  function save(event) {
    event.preventDefault();
    setOpen(false);
    setMessage(`Saved “${new FormData(event.currentTarget).get("name")}”`);
  }
  return <main>
    <button id="opener" onClick={() => setOpen(true)}>Rename project</button>
    <button id="other">Something else</button>
    <Dialog open={open} onClose={() => setOpen(false)} title="Rename project">
      <form onSubmit={save}>
        <label>New name <input id="name" name="name" defaultValue="Apollo" /></label>
        <button type="button" onClick={() => setOpen(false)}>Cancel</button>
        <button id="save">Save</button>
      </form>
    </Dialog>
    <p role="status" id="status">{message}</p>    {/* announced by screen readers when it changes */}
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
