// file: dialog/Dialog.jsx
import { useEffect, useId, useRef } from "react";

// A modal dialog built on the native <dialog> element: showModal() makes the rest of the page
// inert, moves focus inside, closes on Escape, and returns focus to the opener when closed.
export function Dialog({ open, onClose, title, children }) {
  const ref = useRef(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = ref.current;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);
  return (
    <dialog ref={ref} aria-labelledby={titleId} onClose={onClose}>   {/* Escape fires "close" */}
      <h2 id={titleId}>{title}</h2>
      {children}
    </dialog>
  );
}
