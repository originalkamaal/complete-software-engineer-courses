// file: hydrate/main.jsx
import { hydrateRoot } from "react-dom/client";
import { Bad, Good } from "./App.jsx";

console.log(`browser time zone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}`);
const report = (id) => ({ onRecoverableError: (error) => console.log(`#${id}: ${error.message.split("\n")[0]}`) });
hydrateRoot(document.getElementById("bad"), <Bad />, report("bad"));
hydrateRoot(document.getElementById("good"), <Good timeZone="Asia/Tokyo" />, report("good"));
