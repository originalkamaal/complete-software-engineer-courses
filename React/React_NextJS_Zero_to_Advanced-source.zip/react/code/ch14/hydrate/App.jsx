// file: hydrate/App.jsx
const MEETING = new Date("2026-03-05T14:30:00Z");

// Formats with the time zone of whatever machine runs it: the server's, then the browser's.
export function Bad() {
  return <p>Meeting at {MEETING.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</p>;
}

// Formats with an explicit time zone (in a real app: the user's saved preference).
export function Good({ timeZone }) {
  const time = MEETING.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone });
  return <p>Meeting at {time} ({timeZone})</p>;
}
