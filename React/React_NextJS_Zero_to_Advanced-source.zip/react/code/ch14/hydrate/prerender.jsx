// file: hydrate/prerender.jsx
// "Server-side rendering": render both components to HTML and write the page.
import { writeFileSync } from "node:fs";
import { renderToString } from "react-dom/server";
import { Bad, Good } from "./App.jsx";

const page = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Hydration</title></head>
<body><div id="bad">${renderToString(<Bad />)}</div><div id="good">${renderToString(<Good timeZone="Asia/Tokyo" />)}</div>
<script type="module" src="./main.jsx"></script></body></html>`;
writeFileSync(new URL("./index.html", import.meta.url), page);
console.log(`server time zone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}`);
console.log(page.match(/<div id="bad">.*?<\/div>|<div id="good">.*?<\/div>/g).join("\n"));
