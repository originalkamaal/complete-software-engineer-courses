// file: audit/main.jsx
import { createRoot } from "react-dom/client";

// Looks fine with a mouse and good eyesight. Everything here is a real, common bug.
function Bad() {
  return <main>
    <h1>Newsletter</h1>
    <img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" width="40" height="40" />
    <input type="email" placeholder="Your email" />
    <div className="btn" onClick={() => alert("subscribed")}>Subscribe</div>
    <p style={{ color: "#aaa" }}>We send one email a month.</p>
    <a href="/privacy"><svg width="16" height="16"><circle cx="8" cy="8" r="7" /></svg></a>
  </main>;
}

function Good() {
  return <main>
    <h1>Newsletter</h1>
    <img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" width="40" height="40" alt="" />   {/* decorative */}
    <label htmlFor="email">Email</label>
    <input id="email" type="email" autoComplete="email" />
    <button type="button" onClick={() => console.log("subscribed")}>Subscribe</button>
    <p style={{ color: "#595959" }}>We send one email a month.</p>
    <a href="/privacy" aria-label="Privacy policy"><svg width="16" height="16" aria-hidden="true"><circle cx="8" cy="8" r="7" /></svg></a>
  </main>;
}

const which = new URLSearchParams(location.search).get("v");
createRoot(document.getElementById("root")).render(which === "good" ? <Good /> : <Bad />);
