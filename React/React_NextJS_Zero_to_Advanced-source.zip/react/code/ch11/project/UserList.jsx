// file: project/UserList.jsx
import { useEffect, useState } from "react";

export function UserList({ pageSize = 2 }) {
  const [page, setPage] = useState(1);
  const [attempt, setAttempt] = useState(0);
  const [state, setState] = useState({ status: "loading" });

  useEffect(() => {
    const controller = new AbortController();
    setState({ status: "loading" });
    fetch(`/api/users?page=${page}&size=${pageSize}`, { signal: controller.signal })
      .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
      .then((data) => setState({ status: "ok", ...data }))
      .catch((error) => { if (error.name !== "AbortError") setState({ status: "error", error }); });
    return () => controller.abort();
  }, [page, pageSize, attempt]);

  return (
    <section aria-labelledby="users-h">
      <h2 id="users-h">Users</h2>
      {state.status === "loading" && <p role="status">Loading…</p>}
      {state.status === "error" && <p role="alert">Could not load users ({state.error.message}).{" "}
        <button onClick={() => setAttempt((a) => a + 1)}>Retry</button></p>}
      {state.status === "ok" && <ul>{state.users.map((u) => <li key={u.id}>{u.name}</li>)}</ul>}
      <nav aria-label="Pages">
        <button onClick={() => setPage((p) => p - 1)} disabled={page === 1}>Previous</button>
        <span>Page {page}</span>
        <button onClick={() => setPage((p) => p + 1)} disabled={state.status !== "ok" || !state.hasMore}>Next</button>
      </nav>
    </section>
  );
}
