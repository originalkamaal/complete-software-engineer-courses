// file: project/UserList.test.jsx
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { UserList } from "./UserList.jsx";

const USERS = ["Ana", "Bo", "Cy", "Di", "Ed"].map((name, i) => ({ id: i + 1, name }));

// A fake server: pages of users, with a switch to make the next request fail.
function fakeServer() {
  const server = { failNext: false, requests: [] };
  server.fetch = vi.fn(async (url) => {
    const { searchParams } = new URL(url, "http://test");
    const page = Number(searchParams.get("page")), size = Number(searchParams.get("size"));
    server.requests.push(`page ${page}`);
    if (server.failNext) { server.failNext = false; return new Response("", { status: 503 }); }
    const users = USERS.slice((page - 1) * size, page * size);
    return Response.json({ users, hasMore: page * size < USERS.length });
  });
  return server;
}

let server;
beforeEach(() => { server = fakeServer(); vi.stubGlobal("fetch", server.fetch); });  // restored by unstubGlobals

const names = () => within(screen.getByRole("list")).getAllByRole("listitem").map((li) => li.textContent);

describe("UserList", () => {
  it("shows a loading state, then the first page", async () => {
    render(<UserList />);
    expect(screen.getByRole("status")).toHaveTextContent("Loading…");
    await screen.findByRole("list");
    expect(names()).toEqual(["Ana", "Bo"]);
    expect(screen.getByRole("button", { name: "Previous" })).toBeDisabled();
  });

  it("pages forward to the end and back", async () => {
    const user = userEvent.setup();
    render(<UserList />);
    await screen.findByRole("list");
    await user.click(screen.getByRole("button", { name: "Next" }));
    await screen.findByText("Cy");
    await user.click(screen.getByRole("button", { name: "Next" }));
    await screen.findByText("Ed");
    expect(names()).toEqual(["Ed"]);
    expect(screen.getByRole("button", { name: "Next" })).toBeDisabled();
    await user.click(screen.getByRole("button", { name: "Previous" }));
    await screen.findByText("Di");
    expect(server.requests).toEqual(["page 1", "page 2", "page 3", "page 2"]);
  });

  it("shows an error with a retry button that recovers", async () => {
    const user = userEvent.setup();
    server.failNext = true;
    render(<UserList />);
    expect(await screen.findByRole("alert")).toHaveTextContent("Could not load users (HTTP 503).");
    await user.click(screen.getByRole("button", { name: "Retry" }));
    await screen.findByRole("list");
    expect(names()).toEqual(["Ana", "Bo"]);
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });
});
