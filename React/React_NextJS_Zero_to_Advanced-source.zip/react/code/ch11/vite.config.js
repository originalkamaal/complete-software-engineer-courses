// file: vite.config.js
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// A fake sign-up API: 409 for an address that is already taken, 201 otherwise.
const api = {
  name: "fake-api",
  configureServer(server) {
    server.middlewares.use("/api/signup", (req, res) => {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", () => {
        const { email } = JSON.parse(body);
        res.statusCode = email === "taken@example.org" ? 409 : 201;
        res.setHeader("content-type", "application/json");
        res.end(JSON.stringify({ email }));
      });
    });
  },
};

export default defineConfig({
  plugins: [react(), api],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client"] },
});
