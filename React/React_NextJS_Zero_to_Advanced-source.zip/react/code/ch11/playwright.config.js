// file: playwright.config.js
import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "e2e",
  reporter: "list",
  use: { baseURL: "http://localhost:5174" },
  webServer: { command: "npx vite --port 5174 --strictPort", url: "http://localhost:5174/app/", reuseExistingServer: false },
});
