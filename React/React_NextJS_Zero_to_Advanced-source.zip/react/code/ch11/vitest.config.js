// file: vitest.config.js
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",                  // a simulated DOM in Node.js
    include: ["unit/**/*.test.*", "components/**/*.test.*", "project/**/*.test.*"],
    exclude: process.env.PITFALLS ? [] : ["components/pitfalls.test.jsx"],   // failing on purpose (Unit 11.2)
    unstubGlobals: true,                   // undo vi.stubGlobal after each test
    coverage: { provider: "v8", include: ["project/**/*.jsx"], exclude: ["**/*.test.*"] },
    setupFiles: ["./setup.js"],
  },
});
