// file: components/SearchBox.jsx
import { useEffect, useState } from "react";

export function SearchBox({ onSearch, delay = 300 }) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (!text) return;
    const id = setTimeout(() => onSearch(text), delay);   // debounce: wait for a pause in typing
    return () => clearTimeout(id);
  }, [text, delay, onSearch]);
  return <input aria-label="Search" value={text} onChange={(e) => setText(e.target.value)} />;
}
