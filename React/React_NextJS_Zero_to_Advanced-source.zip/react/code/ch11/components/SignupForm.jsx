// file: components/SignupForm.jsx
import { useState } from "react";

export function SignupForm({ onSignup }) {
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle");      // idle | saving | done | failed

  async function handleSubmit(event) {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.currentTarget));
    const found = {};
    if (!/^\S+@\S+\.\S+$/.test(data.email)) found.email = "Enter a valid email address";
    if (data.password.length < 8) found.password = "Use at least 8 characters";
    setErrors(found);
    if (Object.keys(found).length) return;
    setStatus("saving");
    try { await onSignup(data); setStatus("done"); }
    catch { setStatus("failed"); }
  }

  if (status === "done") return <p role="status">Welcome aboard!</p>;
  return (
    <form onSubmit={handleSubmit} noValidate>
      <label htmlFor="email">Email</label>
      <input id="email" name="email" type="email" aria-invalid={!!errors.email} aria-describedby="email-error" />
      <p id="email-error">{errors.email}</p>
      <label htmlFor="password">Password</label>
      <input id="password" name="password" type="password" aria-invalid={!!errors.password} aria-describedby="password-error" />
      <p id="password-error">{errors.password}</p>
      {status === "failed" && <p role="alert">Sign-up failed. Try again.</p>}
      <button disabled={status === "saving"}>{status === "saving" ? "Signing up…" : "Sign up"}</button>
    </form>
  );
}
