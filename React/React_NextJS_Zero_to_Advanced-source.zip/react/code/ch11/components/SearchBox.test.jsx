// file: components/SearchBox.test.jsx
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SearchBox } from "./SearchBox.jsx";

afterEach(() => vi.useRealTimers());

describe("SearchBox", () => {
  it("searches once, after the user stops typing", async () => {
    vi.useFakeTimers();                                   // control setTimeout from the test
    const user = userEvent.setup({ advanceTimers: vi.advanceTimersByTime });
    const onSearch = vi.fn();
    render(<SearchBox onSearch={onSearch} />);

    await user.type(screen.getByRole("textbox", { name: "Search" }), "react");
    expect(onSearch).not.toHaveBeenCalled();              // still inside the 300 ms pause
    act(() => vi.advanceTimersByTime(299));
    expect(onSearch).not.toHaveBeenCalled();
    act(() => vi.advanceTimersByTime(1));
    expect(onSearch).toHaveBeenCalledTimes(1);
    expect(onSearch).toHaveBeenCalledWith("react");
  });
});
