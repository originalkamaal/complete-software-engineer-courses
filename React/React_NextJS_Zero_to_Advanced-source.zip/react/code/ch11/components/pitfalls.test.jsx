// file: components/pitfalls.test.jsx
// Three tests that fail for reasons worth recognising.
import { it, expect, vi, afterEach } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SearchBox } from "./SearchBox.jsx";
import { SignupForm } from "./SignupForm.jsx";

afterEach(() => vi.useRealTimers());

it("fake timers without telling user-event", async () => {
  vi.useFakeTimers();
  const user = userEvent.setup();                         // user-event waits with setTimeout between keys...
  render(<SearchBox onSearch={() => {}} />);
  await user.type(screen.getByRole("textbox"), "hi");     // ...which never fires: the test times out
});

it("getBy for something that appears later", async () => {
  const user = userEvent.setup();
  render(<SignupForm onSignup={() => new Promise((r) => setTimeout(r, 20))} />);  // a 20 ms "server"
  await user.type(screen.getByLabelText("Email"), "ana@example.org");
  await user.type(screen.getByLabelText("Password"), "correct horse");
  await user.click(screen.getByRole("button", { name: "Sign up" }));
  expect(screen.getByRole("status")).toBeInTheDocument();  // not there yet: use findByRole
});

it("a query that matches the wrong thing", () => {
  render(<SignupForm onSignup={() => {}} />);
  expect(screen.getByRole("textbox", { name: "Password" })).toBeInTheDocument();
});
