// file: components/SignupForm.test.jsx
import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SignupForm } from "./SignupForm.jsx";

function setup(onSignup = vi.fn().mockResolvedValue(undefined)) {
  const user = userEvent.setup();                    // simulates real key presses and clicks
  render(<SignupForm onSignup={onSignup} />);
  return { user, onSignup };
}

describe("SignupForm", () => {
  it("shows errors next to the fields and does not submit", async () => {
    const { user, onSignup } = setup();
    await user.type(screen.getByLabelText("Email"), "ana@");
    await user.type(screen.getByLabelText("Password"), "short");
    await user.click(screen.getByRole("button", { name: "Sign up" }));

    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription("Enter a valid email address");
    expect(screen.getByLabelText("Password")).toHaveAttribute("aria-invalid", "true");
    expect(onSignup).not.toHaveBeenCalled();
  });

  it("submits valid data and shows a welcome message", async () => {
    const { user, onSignup } = setup();
    await user.type(screen.getByLabelText("Email"), "ana@example.org");
    await user.type(screen.getByLabelText("Password"), "correct horse");
    await user.click(screen.getByRole("button", { name: "Sign up" }));

    expect(onSignup).toHaveBeenCalledWith({ email: "ana@example.org", password: "correct horse" });
    expect(await screen.findByRole("status")).toHaveTextContent("Welcome aboard!");
  });

  it("disables the button while saving, then reports a failure", async () => {
    let reject;
    const { user } = setup(() => new Promise((_, r) => { reject = r; }));
    await user.type(screen.getByLabelText("Email"), "ana@example.org");
    await user.type(screen.getByLabelText("Password"), "correct horse");
    await user.click(screen.getByRole("button", { name: "Sign up" }));

    expect(screen.getByRole("button", { name: "Signing up…" })).toBeDisabled();
    reject(new Error("500"));
    expect(await screen.findByRole("alert")).toHaveTextContent("Sign-up failed");
    expect(screen.getByRole("button", { name: "Sign up" })).toBeEnabled();
  });
});
