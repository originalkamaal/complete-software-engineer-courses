// file: app/main.jsx
import { createRoot } from "react-dom/client";
import { SignupForm } from "../components/SignupForm.jsx";

async function signup(data) {
  const res = await fetch("/api/signup", { method: "POST", body: JSON.stringify(data) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}
createRoot(document.getElementById("root")).render(<main><h1>Create an account</h1><SignupForm onSignup={signup} /></main>);
