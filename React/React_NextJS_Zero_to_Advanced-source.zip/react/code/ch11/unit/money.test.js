// file: unit/money.test.js
import { describe, it, expect } from "vitest";
import { formatCents, splitBill } from "./money.js";

describe("formatCents", () => {
  it.each([[0, "$0.00"], [5, "$0.05"], [123456, "$1,234.56"], [-250, "-$2.50"]])("%i → %s", (cents, text) => {
    expect(formatCents(cents)).toBe(text);
  });
  it("rejects fractions of a cent", () => {
    expect(() => formatCents(1.5)).toThrow(/integer/);
  });
});

describe("splitBill", () => {
  it("never loses a cent", () => {
    for (let total = 0; total < 500; total++)
      for (let people = 1; people < 8; people++)
        expect(splitBill(total, people).reduce((a, b) => a + b, 0)).toBe(total);
  });
  it("gives the leftover to the first people", () => {
    expect(splitBill(1000, 3)).toEqual([334, 333, 333]);
  });
});
