// file: unit/money.js
export function formatCents(cents, currency = "USD") {
  if (!Number.isInteger(cents)) throw new TypeError(`cents must be an integer, got ${cents}`);
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
}
export function splitBill(totalCents, people) {
  const base = Math.floor(totalCents / people);
  const extra = totalCents - base * people;          // the leftover cents go to the first people
  return Array.from({ length: people }, (_, i) => base + (i < extra ? 1 : 0));
}
