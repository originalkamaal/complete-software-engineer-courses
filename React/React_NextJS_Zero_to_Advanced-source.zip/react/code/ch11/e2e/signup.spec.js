// file: e2e/signup.spec.js
import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => { await page.goto("/app/"); });

test("a new user can sign up", async ({ page }) => {
  await page.getByLabel("Email").fill("ana@example.org");
  await page.getByLabel("Password").fill("correct horse");
  await page.getByRole("button", { name: "Sign up" }).click();
  await expect(page.getByRole("status")).toHaveText("Welcome aboard!");
});

test("a taken address shows an error and keeps the input", async ({ page }) => {
  await page.getByLabel("Email").fill("taken@example.org");
  await page.getByLabel("Password").fill("correct horse");
  await page.getByRole("button", { name: "Sign up" }).click();
  await expect(page.getByRole("alert")).toHaveText("Sign-up failed. Try again.");
  await expect(page.getByLabel("Email")).toHaveValue("taken@example.org");
});

test("the button is disabled while the request is in flight", async ({ page }) => {
  let release;
  await page.route("**/api/signup", async (route) => {        // hold the request until we say so
    await new Promise((r) => (release = r));
    await route.fulfill({ status: 201, body: "{}" });
  });
  await page.getByLabel("Email").fill("ana@example.org");
  await page.getByLabel("Password").fill("correct horse");
  await page.getByRole("button", { name: "Sign up" }).click();
  await expect(page.getByRole("button", { name: "Signing up…" })).toBeDisabled();
  release();
  await expect(page.getByRole("status")).toBeVisible();
});
