// file: setup.js
import { afterEach, expect, vi } from "vitest";
import { cleanup } from "@testing-library/react";
import * as matchers from "@testing-library/jest-dom/matchers";

expect.extend(matchers);                   // toBeDisabled, toHaveTextContent, toHaveAccessibleDescription ...
afterEach(cleanup);                        // unmount everything rendered by the previous test
// Testing Library advances fake timers only through a global named `jest` (DT-22).
globalThis.jest = vi;
