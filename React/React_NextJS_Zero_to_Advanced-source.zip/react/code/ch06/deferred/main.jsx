// file: deferred/main.jsx
// The list DOES depend on the text (it is filtered by it), so memo cannot skip it. useDeferredValue
// lets React render the input first and the expensive list afterwards, interruptibly.
import { memo, Profiler, useDeferredValue, useState } from "react";
import { createRoot } from "react-dom/client";
import { busy, countItem, onRender } from "../measure.js";

const ITEMS = Array.from({ length: 600 }, (_, i) => `item ${i}`);
const deferred = new URLSearchParams(location.search).has("deferred");

function Item({ label }) { countItem(); busy(0.2); return <li>{label}</li>; }
const Results = memo(function Results({ query }) {
  const visible = ITEMS.filter((label) => label.includes(query));
  return <ul>{visible.map((label) => <Item key={label} label={label} />)}</ul>;
});

function App() {
  const [text, setText] = useState("");
  const query = useDeferredValue(text);                      // lags behind `text` while it is changing
  const shown = deferred ? query : text;
  return (
    <Profiler id="app" onRender={onRender}>
      <input aria-label="Filter" value={text} onChange={(e) => setText(e.target.value)} />
      <p style={{ opacity: shown !== text ? 0.5 : 1 }}>{shown !== text ? "updating…" : "up to date"}</p>
      <Results query={shown} />
    </Profiler>
  );
}
createRoot(document.getElementById("root")).render(<App />);
