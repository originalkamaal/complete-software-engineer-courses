// file: compiled/product.jsx
export function ProductRow({ product, onAdd }) {
  const price = (product.price / 100).toFixed(2);
  return <li>{product.name} {price} <button onClick={() => onAdd(product.id)}>Add</button></li>;
}
