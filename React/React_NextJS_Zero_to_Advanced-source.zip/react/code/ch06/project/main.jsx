// file: project/main.jsx
// The same order list, naive and optimised. Measure: first render, DOM size, typing latency.
import { memo, Profiler, useDeferredValue, useState } from "react";
import { createRoot } from "react-dom/client";
import { ORDERS } from "./data.js";
import { VirtualList } from "./Virtual.jsx";
import { countItem, onRender } from "../measure.js";

const fast = new URLSearchParams(location.search).get("mode") === "fast";

function Row({ order }) {
  countItem();
  return <span>#{order.id} {order.customer} — {order.total.toFixed(2)} ({order.status})</span>;
}
const match = (q) => (o) => o.customer.toLowerCase().includes(q) || o.status.startsWith(q);

const Naive = ({ query }) => {
  const rows = ORDERS.filter(match(query));
  return <ul>{rows.map((o) => <li key={o.id}><Row order={o} /></li>)}</ul>;
};
const Fast = memo(function Fast({ query }) {
  const rows = ORDERS.filter(match(query));
  return <VirtualList items={rows} rowHeight={24} height={480} renderRow={(o) => <Row order={o} />} />;
});

function App() {
  const [text, setText] = useState("");
  const query = useDeferredValue(text.toLowerCase());
  return (
    <Profiler id="orders" onRender={onRender}>
      <input aria-label="Filter orders" value={text} onChange={(e) => setText(e.target.value)} />
      {fast ? <Fast query={query} /> : <Naive query={text.toLowerCase()} />}
    </Profiler>
  );
}
const t0 = performance.now();
createRoot(document.getElementById("root")).render(<App />);
requestAnimationFrame(() => setTimeout(() => { window.firstRenderMs = Math.round(performance.now() - t0); }));
