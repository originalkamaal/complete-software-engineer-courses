// file: project/Virtual.jsx
// Windowing: render only the rows that are visible (plus a few extra), inside a spacer as tall as
// all the rows would be. 10,000 rows cost the same as 30.
import { useState } from "react";

export function VirtualList({ items, rowHeight, height, renderRow, overscan = 5 }) {
  const [scrollTop, setScrollTop] = useState(0);
  const first = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
  const last = Math.min(items.length, Math.ceil((scrollTop + height) / rowHeight) + overscan);
  return (
    <div role="list" aria-rowcount={items.length} style={{ height, overflowY: "auto" }}
         onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)} data-testid="viewport">
      <div style={{ height: items.length * rowHeight, position: "relative" }}>
        {items.slice(first, last).map((item, i) => (
          <div role="listitem" key={item.id} style={{ position: "absolute", top: (first + i) * rowHeight, height: rowHeight }}>
            {renderRow(item)}
          </div>
        ))}
      </div>
    </div>
  );
}
