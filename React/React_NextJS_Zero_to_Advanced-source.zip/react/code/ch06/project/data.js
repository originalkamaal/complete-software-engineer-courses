// file: project/data.js
export const ORDERS = Array.from({ length: 10_000 }, (_, i) => ({
  id: i + 1,
  customer: ["Ana", "Bo", "Cy", "Dee", "Eli"][i % 5] + " " + String.fromCharCode(65 + (i * 7) % 26),
  total: ((i * 7919) % 50000) / 100,
  status: ["paid", "shipped", "refunded"][i % 3],
}));
