// file: measure.js
// Helpers shared by this chapter's pages: a deliberately slow function, a render counter fed by
// React's <Profiler>, and the slowest interaction from the Event Timing API (Book 1, Chapter 13).
export const busy = (ms) => { const end = performance.now() + ms; while (performance.now() < end) {} };
const stats = { commits: 0, renderMs: 0, itemRenders: 0, worstInputMs: 0 };
export const countItem = () => { stats.itemRenders++; };
export const onRender = (_id, _phase, actualDuration) => { stats.commits++; stats.renderMs += actualDuration; };
new PerformanceObserver((list) => {
  for (const e of list.getEntries()) stats.worstInputMs = Math.max(stats.worstInputMs, e.duration);
}).observe({ type: "event", durationThreshold: 16, buffered: true });
window.stats = () => ({ ...stats, renderMs: Math.round(stats.renderMs) });
window.resetStats = () => Object.assign(stats, { commits: 0, renderMs: 0, itemRenders: 0, worstInputMs: 0 });
