// file: rerender/main.jsx
// Typing in a box re-renders its parent, and by default every child of the parent as well —
// here 300 slow list items that do not depend on the text at all.
import { memo, Profiler, useState } from "react";
import { createRoot } from "react-dom/client";
import { busy, countItem, onRender } from "../measure.js";

const ITEMS = Array.from({ length: 300 }, (_, i) => ({ id: i, label: `item ${i}` }));
const useMemoList = new URLSearchParams(location.search).has("memo");

function Item({ item }) { countItem(); busy(0.3); return <li>{item.label}</li>; }
function List({ items }) { return <ul>{items.map((it) => <Item key={it.id} item={it} />)}</ul>; }
const MemoList = memo(List);                               // skip re-rendering when props are equal

function App() {
  const [text, setText] = useState("");
  const ListComponent = useMemoList ? MemoList : List;
  return (
    <Profiler id="app" onRender={onRender}>
      <input aria-label="Note" value={text} onChange={(e) => setText(e.target.value)} />
      <ListComponent items={ITEMS} />
    </Profiler>
  );
}
createRoot(document.getElementById("root")).render(<App />);
