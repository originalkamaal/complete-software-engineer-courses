// file: keys/main.jsx
// Reconciliation in numbers: what does React do to the DOM when a list is reversed?
import { useState } from "react";
import { createRoot } from "react-dom/client";

const ITEMS = Array.from({ length: 100 }, (_, i) => ({ id: i, text: `row ${i}` }));

function List({ byIndex }) {
  const [items, setItems] = useState(ITEMS);
  return <section id={byIndex ? "index" : "id"}>
    <button onClick={() => setItems([...items].reverse())}>reverse</button>
    <ul>{items.map((it, i) => <li key={byIndex ? i : it.id}>{it.text}</li>)}</ul>
  </section>;
}

createRoot(document.getElementById("root")).render(<><List byIndex /><List /></>);
window.watch = (id) => {
  const counts = { nodesMoved: 0, textChanged: 0 };
  new MutationObserver((records) => {
    for (const r of records) {
      if (r.type === "childList") counts.nodesMoved += r.addedNodes.length;
      if (r.type === "characterData") counts.textChanged++;
    }
  }).observe(document.querySelector(`#${id} ul`), { childList: true, characterData: true, subtree: true });
  return () => counts;
};
