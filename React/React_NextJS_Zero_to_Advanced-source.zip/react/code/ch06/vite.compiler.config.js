// file: vite.compiler.config.js
// The same app, compiled with the React Compiler (through Babel).
import { defineConfig } from "vite";
import react, { reactCompilerPreset } from "@vitejs/plugin-react";
import babel from "@rolldown/plugin-babel";

export default defineConfig({
  plugins: [react(), babel({ presets: [reactCompilerPreset()] })],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client", "react/compiler-runtime"] },
});
