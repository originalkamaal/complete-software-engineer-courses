// file: context/main.jsx
// Context passes a value to any depth without props. Every consumer re-renders when the value
// changes — and an object created during render is a new value every time.
import { createContext, memo, use, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";

const renders = {};
const count = (name) => { renders[name] = (renders[name] ?? 0) + 1; };
window.report = () => ({ ...renders });

const Settings = createContext({ theme: "light", user: null });    // the default: used with no provider

const ThemeLabel = memo(function ThemeLabel() {                     // memo: skip re-render if props are equal
  const { theme } = use(Settings);                                  // React 19: use(Context) = useContext
  count("ThemeLabel");
  return <p>theme: {theme}</p>;
});
const UserLabel = memo(function UserLabel() {
  const { user } = use(Settings);
  count("UserLabel");
  return <p>user: {user}</p>;
});
const Static = memo(function Static() { count("Static"); return <p>no context here</p>; });

function App({ stable }) {
  const [theme, setTheme] = useState("light");
  const [user, setUser] = useState("ana");
  const [clicks, setClicks] = useState(0);
  const fresh = { theme, user };                                    // a new object on every render
  const memoised = useMemo(() => ({ theme, user }), [theme, user]); // the same object until they change
  return (
    <Settings value={stable ? memoised : fresh}>
      <button onClick={() => setUser(user === "ana" ? "bo" : "ana")}>switch user</button>
      <button onClick={() => setClicks(clicks + 1)}>unrelated update</button>
      <ThemeLabel /><UserLabel /><Static />
    </Settings>
  );
}
const stable = new URLSearchParams(location.search).has("stable");
createRoot(document.getElementById("root")).render(<App stable={stable} />);
