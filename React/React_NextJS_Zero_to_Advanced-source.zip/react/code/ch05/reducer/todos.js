// file: reducer/todos.js
// A reducer: (state, action) -> new state. Pure, so it can be tested without React at all.
export const initialTodos = { items: [], filter: "all", nextId: 1 };

export function todosReducer(state, action) {
  switch (action.type) {
    case "added":
      if (!action.text.trim()) return state;                         // unchanged state: no re-render
      return { ...state, nextId: state.nextId + 1,
               items: [...state.items, { id: state.nextId, text: action.text.trim(), done: false }] };
    case "toggled":
      return { ...state, items: state.items.map((t) => (t.id === action.id ? { ...t, done: !t.done } : t)) };
    case "cleared":
      return { ...state, items: state.items.filter((t) => !t.done) };
    case "filtered":
      return { ...state, filter: action.filter };
    default:
      throw new Error(`unknown action ${action.type}`);              // a typo should fail loudly
  }
}

export const visibleTodos = ({ items, filter }) =>
  filter === "all" ? items : items.filter((t) => t.done === (filter === "done"));
