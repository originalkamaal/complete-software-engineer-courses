// file: project/store.js
// An external store in 40 lines, the core of libraries such as Zustand.
import { useRef, useSyncExternalStore } from "react";

export function createStore(init) {
  let state;
  const listeners = new Set();
  const get = () => state;
  const set = (partial) => {
    const changes = typeof partial === "function" ? partial(state) : partial;
    const next = { ...state, ...changes };
    if (Object.keys(changes).every((k) => Object.is(next[k], state[k]))) return;   // nothing changed
    state = next;                                                                  // a new object: immutable
    for (const listener of listeners) listener();
  };
  const subscribe = (listener) => { listeners.add(listener); return () => listeners.delete(listener); };
  state = init(set, get);
  return { get, set, subscribe };
}

export const shallow = (a, b) =>
  Object.is(a, b) || (typeof a === "object" && typeof b === "object" && a && b &&
    Object.keys(a).length === Object.keys(b).length && Object.keys(a).every((k) => Object.is(a[k], b[k])));

/** Subscribe to the part of the store that `selector` picks; re-render only when it changes. */
export function useStore(store, selector = (s) => s, isEqual = Object.is) {
  const last = useRef(null);
  const getSnapshot = () => {
    const next = selector(store.get());
    if (last.current && isEqual(last.current.value, next)) return last.current.value;   // keep the old identity
    last.current = { value: next };
    return next;
  };
  return useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);
}
