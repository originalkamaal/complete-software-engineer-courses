// file: project/main.jsx
import { memo } from "react";
import { createRoot } from "react-dom/client";
import { useStore, shallow } from "./store.js";
import { cart, selectCount, selectTotal } from "./cart.js";

const renders = {};
const count = (name) => { renders[name] = (renders[name] ?? 0) + 1; };
window.report = () => ({ ...renders });

const Badge = memo(function Badge() {
  const n = useStore(cart, selectCount);                     // a number: Object.is is enough
  count("Badge");
  return <p>{n} items</p>;
});
const Total = memo(function Total() {
  const total = useStore(cart, selectTotal);
  count("Total");
  return <p>total {(total / 100).toFixed(2)}</p>;
});
const Summary = memo(function Summary() {
  const { n, coupon } = useStore(cart, (s) => ({ n: selectCount(s), coupon: s.coupon }), shallow);   // an object: compare shallowly
  count("Summary");
  return <p>{n} items, coupon {coupon ?? "none"}</p>;
});
function Buttons() {
  const add = useStore(cart, (s) => s.add);                  // functions never change: never re-renders
  count("Buttons");
  return <p>
    <button onClick={() => add({ id: "tea", name: "Tea", price: 450 })}>add tea</button>
    <button onClick={() => cart.get().applyCoupon("HALF")}>apply coupon</button>
    <button onClick={() => cart.get().applyCoupon("HALF")}>apply the same coupon again</button>
  </p>;
}
createRoot(document.getElementById("root")).render(<><Buttons /><Badge /><Total /><Summary /></>);

// The classic mistake: a selector that returns a NEW object every time, compared with Object.is.
function Broken() {
  const { n } = useStore(cart, (s) => ({ n: selectCount(s) }));
  return <p>{n}</p>;
}
window.mountBroken = () => {
  const el = document.body.appendChild(document.createElement("div"));
  createRoot(el, { onUncaughtError: (e) => console.log(`Broken crashed: ${e.message.split(".")[0]}`) }).render(<Broken />);
};
