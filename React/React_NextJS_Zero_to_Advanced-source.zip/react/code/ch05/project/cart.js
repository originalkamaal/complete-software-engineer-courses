// file: project/cart.js
import { createStore } from "./store.js";

export const cart = createStore((set) => ({
  items: [],                                       // [{ id, name, price, qty }]
  coupon: null,
  add: (product) => set((s) => {
    const existing = s.items.find((i) => i.id === product.id);
    return { items: existing
      ? s.items.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i))
      : [...s.items, { ...product, qty: 1 }] };
  }),
  applyCoupon: (code) => set({ coupon: code }),
}));
export const selectCount = (s) => s.items.reduce((n, i) => n + i.qty, 0);
export const selectTotal = (s) => s.items.reduce((t, i) => t + i.price * i.qty, 0) * (s.coupon === "HALF" ? 0.5 : 1);
