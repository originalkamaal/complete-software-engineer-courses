// file: stores/main.jsx
// External stores keep state outside React; components subscribe to the slice they select,
// and re-render only when THAT slice changes. The same feature with Zustand and Redux Toolkit.
import { memo } from "react";
import { createRoot } from "react-dom/client";
import { create } from "zustand";
import { configureStore, createSlice } from "@reduxjs/toolkit";
import { Provider, useDispatch, useSelector } from "react-redux";

const renders = {};
const count = (name) => { renders[name] = (renders[name] ?? 0) + 1; };
window.report = () => ({ ...renders });

// --- Zustand: a hook that IS the store ---
const useSettings = create((set) => ({
  theme: "light",
  user: "ana",
  switchUser: () => set((s) => ({ user: s.user === "ana" ? "bo" : "ana" })),   // returns a partial update
}));
const ZTheme = memo(function ZTheme() { const theme = useSettings((s) => s.theme); count("zustand theme"); return <p>{theme}</p>; });
const ZUser = memo(function ZUser() { const user = useSettings((s) => s.user); count("zustand user"); return <p>{user}</p>; });
function ZButton() { const switchUser = useSettings((s) => s.switchUser); return <button onClick={switchUser}>zustand: switch user</button>; }

// --- Redux Toolkit: a slice of reducer logic, a store, and react-redux hooks ---
const settings = createSlice({
  name: "settings",
  initialState: { theme: "light", user: "ana" },
  reducers: { userSwitched: (s) => { s.user = s.user === "ana" ? "bo" : "ana"; } },   // Immer: "mutations" are safe here
});
const store = configureStore({ reducer: { settings: settings.reducer } });
const RTheme = memo(function RTheme() { const theme = useSelector((s) => s.settings.theme); count("redux theme"); return <p>{theme}</p>; });
const RUser = memo(function RUser() { const user = useSelector((s) => s.settings.user); count("redux user"); return <p>{user}</p>; });
function RButton() { const dispatch = useDispatch(); return <button onClick={() => dispatch(settings.actions.userSwitched())}>redux: switch user</button>; }

createRoot(document.getElementById("root")).render(<>
  <ZButton /><ZTheme /><ZUser />
  <Provider store={store}><RButton /><RTheme /><RUser /></Provider>
</>);
window.reduxState = () => store.getState();
