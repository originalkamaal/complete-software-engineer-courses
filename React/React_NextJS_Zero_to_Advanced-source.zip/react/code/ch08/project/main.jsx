// file: project/main.jsx
import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useIssues, useSetIssueState } from "./queries.js";

function Issues() {
  const [state, setState] = useState("open");
  const { data, error, isPending, fetchNextPage, hasNextPage, isFetchingNextPage } = useIssues(state);
  const toggle = useSetIssueState();
  if (isPending) return <p>Loading issues…</p>;
  if (error) return <p role="alert">Could not load issues: {error.message}</p>;
  const items = data.pages.flatMap((p) => p.items);
  return (
    <main>
      <p>
        {["open", "closed", "all"].map((s) => (
          <button key={s} aria-pressed={s === state} onClick={() => setState(s)}>{s}</button>
        ))}{" "}
        {items.length} of {data.pages[0].total}
      </p>
      {toggle.isError && <p role="alert">Could not update issue {toggle.variables.id}: {toggle.error.message}</p>}
      <ul>
        {items.map((i) => (
          <li key={i.id} data-id={i.id}>
            #{i.id} {i.title} [{i.state}]{" "}
            <button onClick={() => toggle.mutate({ id: i.id, state: i.state === "open" ? "closed" : "open" })}>
              {i.state === "open" ? "Close" : "Reopen"}
            </button>
          </li>
        ))}
      </ul>
      {hasNextPage && <button onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
        {isFetchingNextPage ? "Loading…" : "Load more"}</button>}
    </main>
  );
}

const client = new QueryClient({ defaultOptions: { queries: { staleTime: 30_000, retry: 1 } } });
createRoot(document.getElementById("root")).render(
  <StrictMode><QueryClientProvider client={client}><Issues /></QueryClientProvider></StrictMode>);
window.issue = (id) => document.querySelector(`li[data-id="${id}"]`)?.textContent ?? "(not in the list)";
window.summary = () => document.querySelector("main p").textContent.replace(/^(open|closed|all)+\s*/, "");
