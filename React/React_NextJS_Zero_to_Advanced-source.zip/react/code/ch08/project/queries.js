// file: project/queries.js
// All server-state access in one module: query keys, fetchers, and the mutation with an
// optimistic update that is rolled back if the server refuses.
import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";

async function getJson(url, options) {
  const res = await fetch(url, options);
  const body = await res.json();
  if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
  return body;
}

export const issueKeys = {                                  // one place that defines the key hierarchy
  all: ["issues"],
  list: (state) => ["issues", "list", state],
};

export function useIssues(state) {
  return useInfiniteQuery({
    queryKey: issueKeys.list(state),
    queryFn: ({ pageParam, signal }) => getJson(`/api/issues?state=${state}&page=${pageParam}`, { signal }),
    initialPageParam: 1,
    getNextPageParam: (last) => last.nextPage,              // null: no more pages
  });
}

export function useSetIssueState() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, state }) => getJson(`/api/issues/${id}`, { method: "PATCH", body: JSON.stringify({ state }) }),
    onMutate: async ({ id, state }) => {                    // optimistic: change every cached list now
      await qc.cancelQueries({ queryKey: issueKeys.all });  // an in-flight refetch must not overwrite it
      const snapshot = qc.getQueriesData({ queryKey: issueKeys.all });
      qc.setQueriesData({ queryKey: issueKeys.all }, (data) => data && {
        ...data,
        pages: data.pages.map((p) => ({ ...p, items: p.items.map((i) => (i.id === id ? { ...i, state } : i)) })),
      });
      return { snapshot };
    },
    onError: (_err, _vars, context) => {                     // roll back to exactly what was cached before
      for (const [key, data] of context.snapshot) qc.setQueryData(key, data);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: issueKeys.all }),   // then refetch the truth
  });
}
