// file: dedupe/main.jsx
// Server state is a CACHE of data that lives elsewhere. TanStack Query keeps it per query key:
// identical queries share one request and one cache entry, fresh data is served without a request,
// and stale data is shown at once and refreshed in the background.
import { useState } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";

const fetchIssue = (id) => fetch(`/api/issues/${id}`).then((r) => r.json());

function IssueTitle({ id, label }) {
  const { data, isPending, isFetching, dataUpdatedAt } = useQuery({
    queryKey: ["issue", id],                     // the cache key: same key, same data
    queryFn: () => fetchIssue(id),
    staleTime: 1000,                             // considered fresh for 1 s: no refetch in that time
  });
  return <p>{label}: {isPending ? "loading…" : data.title}{isFetching && !isPending ? " (refreshing)" : ""}</p>;
}

function App() {
  const [shown, setShown] = useState(true);
  return <>
    <button onClick={() => setShown(!shown)}>toggle</button>
    {shown && <><IssueTitle id={1} label="header" /><IssueTitle id={1} label="sidebar" /><IssueTitle id={2} label="other" /></>}
  </>;
}
const client = new QueryClient();
createRoot(document.getElementById("root")).render(<QueryClientProvider client={client}><App /></QueryClientProvider>);
window.texts = () => [...document.querySelectorAll("p")].map((p) => p.textContent);
