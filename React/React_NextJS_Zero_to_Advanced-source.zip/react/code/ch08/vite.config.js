// file: vite.config.js
// A fake issue tracker API: 200 issues, paging, filtering, and a PATCH that always fails for issue 7.
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const issues = Array.from({ length: 200 }, (_, i) => ({
  id: i + 1, title: `Issue number ${i + 1}`, state: i % 4 === 0 ? "closed" : "open", comments: (i * 7) % 13,
}));
let requests = 0;
function fakeApi() {
  return {
    name: "fake-api",
    configureServer(server) {
      server.middlewares.use("/api", async (req, res) => {
        const url = new URL(req.url, "http://x");
        requests++;
        console.log(`  api #${requests}: ${req.method} ${url.pathname}${url.search}`);
        await new Promise((r) => setTimeout(r, 200));
        const send = (status, data) => { res.statusCode = status; res.setHeader("Content-Type", "application/json"); res.end(JSON.stringify(data)); };
        if (url.pathname === "/issues") {
          const state = url.searchParams.get("state") ?? "all";
          const page = Number(url.searchParams.get("page") ?? 1), size = 20;
          const all = issues.filter((i) => state === "all" || i.state === state);
          return send(200, { items: all.slice((page - 1) * size, page * size), nextPage: page * size < all.length ? page + 1 : null, total: all.length });
        }
        const m = /^\/issues\/(\d+)$/.exec(url.pathname);
        if (m) {
          const issue = issues.find((i) => i.id === Number(m[1]));
          if (req.method === "PATCH") {
            let body = ""; for await (const c of req) body += c;
            if (issue.id === 7) return send(500, { error: "unlucky issue: the database is down" });
            Object.assign(issue, JSON.parse(body));
          }
          return send(200, issue);
        }
        send(404, {});
      });
    },
  };
}
export default defineConfig({
  plugins: [react(), fakeApi()],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client", "@tanstack/react-query"] },
});
