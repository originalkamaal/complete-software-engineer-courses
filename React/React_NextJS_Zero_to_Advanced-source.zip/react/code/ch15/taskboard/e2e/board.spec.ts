// file: taskboard/e2e/board.spec.ts
import { test, expect, type Page } from "@playwright/test";

async function register(page: Page, email: string) {
  await page.goto("/");
  await expect(page).toHaveURL(/\/login$/);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill("correct horse");
  await page.getByRole("button", { name: "Create account" }).click();
  await expect(page.getByRole("heading", { name: "Taskboard" })).toBeVisible();
  await expect(page.locator("#who")).toHaveText(email);
}

const column = (page: Page, name: string) => page.getByRole("region", { name: new RegExp(`^${name}`) });

test("a user adds, moves, finds, and deletes tasks", async ({ page }) => {
  await register(page, "ana@example.org");
  for (const title of ["Write chapter 15", "Review 100% of PRs", "Ship it"]) {
    await page.getByRole("textbox", { name: "New task" }).fill(title);
    await page.getByRole("button", { name: "Add" }).click();
    await expect(column(page, "To do").getByText(title)).toBeVisible();
  }
  await page.getByRole("button", { name: "Move “Ship it” to Done" }).click();
  await expect(column(page, "Done")).toContainText("Ship it");
  await expect(page.locator("#stats")).toHaveText("1 of 3 done (33%)");

  await page.getByRole("searchbox", { name: "Search" }).fill("%");             // a literal %, not a wildcard
  await page.getByRole("button", { name: "Search" }).click();
  await expect(page).toHaveURL(/\?q=%25$/);
  await expect(page.locator("[data-task]")).toHaveCount(1);

  await page.getByRole("button", { name: "Delete “Review 100% of PRs”" }).click();
  await expect(page.locator("[data-task]")).toHaveCount(0);
});

test("users never see each other's tasks", async ({ browser }) => {
  const ana = await (await browser.newContext()).newPage();
  const bo = await (await browser.newContext()).newPage();            // separate cookies
  await register(ana, "ana2@example.org");
  await ana.getByRole("textbox", { name: "New task" }).fill("Ana's private task");
  await ana.getByRole("button", { name: "Add" }).click();
  await expect(ana.locator("[data-task]")).toHaveCount(1);

  await register(bo, "bo@example.org");
  await expect(bo.locator("[data-task]")).toHaveCount(0);
  await expect(bo.locator("#stats")).toHaveText("0 of 0 done (0%)");
});
