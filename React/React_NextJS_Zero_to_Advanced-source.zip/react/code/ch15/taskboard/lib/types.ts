// file: taskboard/lib/types.ts
export const STATUSES = ["todo", "doing", "done"] as const;
export type Status = (typeof STATUSES)[number];
export type Task = { id: number; title: string; status: Status };
export type User = { id: number; email: string };
export type FormState = { error?: string; values?: Record<string, string> };
