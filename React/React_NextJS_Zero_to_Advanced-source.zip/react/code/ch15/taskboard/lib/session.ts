// file: taskboard/lib/session.ts
import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { randomBytes, createHash } from "node:crypto";
import { db } from "./db";
import { hashPassword, verifyPassword } from "./password";
import type { User } from "./types";

const COOKIE = "session";
const WEEK = 7 * 24 * 60 * 60;
const sha256 = (s: string) => createHash("sha256").update(s).digest("base64url");
const DUMMY_HASH = hashPassword("dummy password for timing");

export async function createSession(userId: number) {
  const token = randomBytes(32).toString("base64url");
  db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)")
    .run(sha256(token), userId, Date.now() + WEEK * 1000);
  (await cookies()).set(COOKIE, token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: WEEK,
  });
}

export const getCurrentUser = cache(async (): Promise<User | null> => {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const row = db.prepare(`SELECT users.id, users.email, sessions.expires_at FROM sessions
    JOIN users ON users.id = sessions.user_id WHERE token_hash = ?`).get(sha256(token)) as
    { id: number; email: string; expires_at: number } | undefined;
  return row && row.expires_at > Date.now() ? { id: row.id, email: row.email } : null;
});

export async function destroySession() {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (token) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
  store.delete(COOKIE);
}

export function authenticate(email: string, password: string): User | null {
  const row = db.prepare("SELECT id, email, password_hash FROM users WHERE email = ?").get(email) as
    { id: number; email: string; password_hash: string } | undefined;
  const ok = verifyPassword(password, row?.password_hash ?? DUMMY_HASH);
  return ok && row ? { id: row.id, email: row.email } : null;
}

export function register(email: string, password: string): User | null {
  try {
    const { lastInsertRowid } = db.prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)")
      .run(email, hashPassword(password));
    return { id: Number(lastInsertRowid), email };
  } catch (e) {
    if (String((e as Error).message).includes("UNIQUE")) return null;
    throw e;
  }
}
