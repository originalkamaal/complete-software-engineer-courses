// file: taskboard/lib/tasks.ts
// The data access layer: every function takes the user, and every query is limited to them.
import "server-only";
import { db } from "./db";
import type { Status, Task, User } from "./types";

export function listTasks(user: User, query = ""): Task[] {
  const rows = db.prepare(`SELECT id, title, status FROM tasks WHERE user_id = ? AND title LIKE ? ESCAPE '\\'
    ORDER BY id`).all(user.id, `%${query.replace(/[\\%_]/g, (c) => "\\" + c)}%`) as Task[];
  // node:sqlite returns objects with a null prototype, which React will not send to the browser.
  return rows.map(({ id, title, status }) => ({ id, title, status }));
}

export function createTask(user: User, title: string): void {
  db.prepare("INSERT INTO tasks (user_id, title) VALUES (?, ?)").run(user.id, title);
}

/** Returns false if the task does not exist or belongs to someone else. */
export function moveTask(user: User, id: number, status: Status): boolean {
  return db.prepare("UPDATE tasks SET status = ? WHERE id = ? AND user_id = ?").run(status, id, user.id).changes === 1;
}

export function deleteTask(user: User, id: number): boolean {
  return db.prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?").run(id, user.id).changes === 1;
}

export async function stats(user: User): Promise<Record<Status, number>> {
  await new Promise((r) => setTimeout(r, Number(process.env.STATS_DELAY_MS ?? 0)));   // a slow report
  const rows = db.prepare("SELECT status, count(*) AS n FROM tasks WHERE user_id = ? GROUP BY status")
    .all(user.id) as { status: Status; n: number }[];
  return { todo: 0, doing: 0, done: 0, ...Object.fromEntries(rows.map((r) => [r.status, r.n])) };
}
