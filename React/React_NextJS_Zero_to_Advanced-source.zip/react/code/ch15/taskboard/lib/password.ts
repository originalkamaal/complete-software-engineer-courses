// file: taskboard/lib/password.ts
import { scryptSync, randomBytes, timingSafeEqual } from "node:crypto";

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password.normalize("NFKC"), salt, 64);
  return `${salt.toString("base64url")}:${hash.toString("base64url")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":").map((s) => Buffer.from(s, "base64url"));
  return timingSafeEqual(scryptSync(password.normalize("NFKC"), salt, 64), hash);
}
