// file: taskboard/lib/validate.ts
// Pure functions: everything that comes from a form or a URL is `unknown` until checked.
import { STATUSES, type Status } from "./types";

export type Result<T> = { ok: true; value: T } | { ok: false; error: string };

export function parseTitle(input: unknown): Result<string> {
  const title = typeof input === "string" ? input.trim().replace(/\s+/g, " ") : "";
  if (title.length === 0) return { ok: false, error: "Give the task a title" };
  if (title.length > 120) return { ok: false, error: `Titles have at most 120 characters (this one has ${title.length})` };
  return { ok: true, value: title };
}

export function parseStatus(input: unknown): Result<Status> {
  return STATUSES.includes(input as Status) ? { ok: true, value: input as Status }
    : { ok: false, error: `Unknown status ${JSON.stringify(input)}` };
}

export function parseCredentials(email: unknown, password: unknown): Result<{ email: string; password: string }> {
  const e = typeof email === "string" ? email.trim().toLowerCase() : "";
  const p = typeof password === "string" ? password : "";
  if (!/^\S+@\S+\.\S+$/.test(e)) return { ok: false, error: "Enter a valid email address" };
  if (p.length < 8) return { ok: false, error: "Passwords have at least 8 characters" };
  return { ok: true, value: { email: e, password: p } };
}

/** The search box: a trimmed, length-limited string, or "" for none. */
export function parseQuery(input: unknown): string {
  return typeof input === "string" ? input.trim().slice(0, 50) : "";
}
