// file: taskboard/vitest.config.ts
import { defineConfig } from "vitest/config";
export default defineConfig({ test: { include: ["unit/**/*.test.ts"], environment: "node" } });
