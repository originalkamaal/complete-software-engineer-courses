// file: taskboard/unit/validate.test.ts
import { describe, it, expect } from "vitest";
import { parseCredentials, parseQuery, parseStatus, parseTitle } from "../lib/validate";

describe("parseTitle", () => {
  it("trims and collapses whitespace", () => {
    expect(parseTitle("  Write   the\ttests ")).toEqual({ ok: true, value: "Write the tests" });
  });
  it.each([[""], ["   "], [undefined], [42], [null]])("rejects %j", (input) => {
    expect(parseTitle(input)).toEqual({ ok: false, error: "Give the task a title" });
  });
  it("accepts 120 characters and rejects 121", () => {
    expect(parseTitle("x".repeat(120)).ok).toBe(true);
    expect(parseTitle("x".repeat(121))).toEqual({ ok: false, error: "Titles have at most 120 characters (this one has 121)" });
  });
});

describe("parseStatus", () => {
  it.each(["todo", "doing", "done"])("accepts %s", (s) => expect(parseStatus(s)).toEqual({ ok: true, value: s }));
  it.each(["DONE", "archived", "", null, { status: "done" }])("rejects %j", (s) => expect(parseStatus(s).ok).toBe(false));
});

describe("parseCredentials and parseQuery", () => {
  it("normalises the email", () => {
    expect(parseCredentials(" Ana@Example.ORG ", "correct horse"))
      .toEqual({ ok: true, value: { email: "ana@example.org", password: "correct horse" } });
  });
  it("limits the query to 50 characters", () => expect(parseQuery("q".repeat(80))).toHaveLength(50));
  it("treats a repeated parameter (an array) as no query", () => expect(parseQuery(["a", "b"])).toBe(""));
});
