// file: taskboard/playwright.config.ts
import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "e2e",
  reporter: "list",
  use: { baseURL: "http://localhost:3200" },
  webServer: {
    // The production build, against a fresh database for every run.
    command: "rm -f e2e.db* && DATABASE_PATH=$PWD/e2e.db PORT=3200 NODE_OPTIONS=--disable-warning=ExperimentalWarning node .next/standalone/ch15/taskboard/server.js",
    url: "http://localhost:3200/login",
  },
});
