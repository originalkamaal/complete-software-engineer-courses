// file: taskboard/app/page.tsx
import { Suspense } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser } from "../lib/session";
import { listTasks } from "../lib/tasks";
import { parseQuery } from "../lib/validate";
import { Board } from "./Board";
import { NewTask } from "./NewTask";
import { Stats } from "./Stats";
import { signOut } from "./actions";

export default async function Home({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const q = parseQuery((await searchParams).q);
  const tasks = listTasks(user, q);
  return <main>
    <header>
      <h1>Taskboard</h1>
      <form action={signOut}><span id="who">{user.email}</span> <button>Sign out</button></form>
    </header>
    <Suspense fallback={<p id="stats">Counting…</p>}><Stats user={user} /></Suspense>
    <NewTask />
    <form role="search">                                            {/* a GET form: the query is in the URL */}
      <label>Search <input name="q" type="search" defaultValue={q} /></label> <button>Search</button>
    </form>
    <Board tasks={tasks} />
  </main>;
}
