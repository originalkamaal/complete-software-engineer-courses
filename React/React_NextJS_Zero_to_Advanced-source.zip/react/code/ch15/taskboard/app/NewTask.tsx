// file: taskboard/app/NewTask.tsx
"use client";
import { useActionState } from "react";
import { addTask } from "./actions";

export function NewTask() {
  const [state, action, pending] = useActionState(addTask, {});
  return (
    <form action={action} aria-label="New task">
      <label>New task <input name="title" defaultValue={state.values?.title}
        aria-invalid={!!state.error} aria-describedby="title-error" /></label>{" "}
      <button disabled={pending}>Add</button>
      <p id="title-error" role="alert">{state.error}</p>
    </form>
  );
}
