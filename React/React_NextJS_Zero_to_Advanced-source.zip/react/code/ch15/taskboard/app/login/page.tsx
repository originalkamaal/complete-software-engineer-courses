// file: taskboard/app/login/page.tsx
import { LoginForm } from "./LoginForm";

export default function Login() {
  return <main><h1>Taskboard</h1><LoginForm /></main>;
}
