// file: taskboard/app/login/LoginForm.tsx
"use client";
import { useActionState } from "react";
import { signIn } from "../actions";

export function LoginForm() {
  const [state, action, pending] = useActionState(signIn, {});
  return (
    <form action={action}>
      <p><label>Email <input name="email" type="email" autoComplete="email" defaultValue={state.values?.email} /></label></p>
      <p><label>Password <input name="password" type="password" autoComplete="current-password" /></label></p>
      {state.error && <p role="alert">{state.error}</p>}
      <button name="intent" value="login" disabled={pending}>Sign in</button>{" "}
      <button name="intent" value="register" disabled={pending}>Create account</button>
    </form>
  );
}
