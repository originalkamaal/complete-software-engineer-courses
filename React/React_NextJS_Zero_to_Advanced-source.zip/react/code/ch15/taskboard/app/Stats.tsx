// file: taskboard/app/Stats.tsx
import { stats } from "../lib/tasks";
import type { User } from "../lib/types";

export async function Stats({ user }: { user: User }) {
  const s = await stats(user);
  const total = s.todo + s.doing + s.done;
  const percent = total ? Math.round((s.done / total) * 100) : 0;
  return <p id="stats">{s.done} of {total} done ({percent}%)</p>;
}
