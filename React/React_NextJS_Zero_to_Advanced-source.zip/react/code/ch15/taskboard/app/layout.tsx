// file: taskboard/app/layout.tsx
import type { ReactNode } from "react";
import "./style.css";

export const metadata = { title: "Taskboard" };
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
