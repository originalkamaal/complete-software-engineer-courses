// file: taskboard/app/Board.tsx
"use client";
import { useOptimistic, useState, startTransition } from "react";
import { changeStatus, removeTask } from "./actions";
import { STATUSES, type Status, type Task } from "../lib/types";

const LABEL: Record<Status, string> = { todo: "To do", doing: "Doing", done: "Done" };

export function Board({ tasks }: { tasks: Task[] }) {
  // Show a move at once; the server's next render replaces it (or it is dropped on failure).
  const [shown, applyMove] = useOptimistic(tasks, (current, move: { id: number; status: Status }) =>
    current.map((t) => (t.id === move.id ? { ...t, status: move.status, pending: true } : t)));
  const [error, setError] = useState("");

  function move(task: Task, status: Status) {
    setError("");
    startTransition(async () => {
      applyMove({ id: task.id, status });
      const result = await changeStatus(task.id, status);
      if (result.error) setError(`Could not move “${task.title}”: ${result.error}`);
    });
  }

  return <>
    <p role="alert" id="board-error">{error}</p>
    <div className="columns">
      {STATUSES.map((status) => {
        const column = shown.filter((t) => t.status === status);
        return <section key={status} aria-labelledby={`h-${status}`}>
          <h2 id={`h-${status}`}>{LABEL[status]} ({column.length})</h2>
          <ul>{column.map((task) => (
            <li key={task.id} className={"pending" in task ? "pending" : undefined} data-task={task.id}>
              <span>{task.title}</span>{" "}
              {STATUSES.filter((s) => s !== status).map((s) => (
                <button key={s} onClick={() => move(task, s)} aria-label={`Move “${task.title}” to ${LABEL[s]}`}>
                  → {LABEL[s]}</button>
              )).flatMap((b) => [b, " "])}
              <button onClick={() => startTransition(() => removeTask(task.id))} aria-label={`Delete “${task.title}”`}>×</button>
            </li>))}
          </ul>
        </section>;
      })}
    </div>
  </>;
}
