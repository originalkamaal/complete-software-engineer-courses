// file: taskboard/app/actions.ts
"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { authenticate, createSession, destroySession, getCurrentUser, register } from "../lib/session";
import { createTask, deleteTask, moveTask } from "../lib/tasks";
import { parseCredentials, parseStatus, parseTitle } from "../lib/validate";
import type { FormState } from "../lib/types";

async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function signIn(_: FormState, form: FormData): Promise<FormState> {
  const email = String(form.get("email") ?? "");
  const c = parseCredentials(form.get("email"), form.get("password"));
  if (!c.ok) return { error: c.error, values: { email } };
  const user = form.get("intent") === "register" ? register(c.value.email, c.value.password)
    : authenticate(c.value.email, c.value.password);
  if (!user) return {
    error: form.get("intent") === "register" ? "That email is already registered" : "Wrong email or password",
    values: { email },
  };
  await createSession(user.id);
  redirect("/");
}

export async function signOut() {
  await destroySession();
  redirect("/login");
}

export async function addTask(_: FormState, form: FormData): Promise<FormState> {
  const user = await requireUser();
  const title = parseTitle(form.get("title"));
  if (!title.ok) return { error: title.error, values: { title: String(form.get("title") ?? "") } };
  createTask(user, title.value);
  revalidatePath("/");
  return {};
}

export async function changeStatus(id: number, status: unknown): Promise<{ error?: string }> {
  const user = await requireUser();
  const s = parseStatus(status);
  if (!s.ok) return { error: s.error };
  await new Promise((r) => setTimeout(r, Number(process.env.MOVE_DELAY_MS ?? 0)));     // network + database time
  const moved = moveTask(user, Number(id), s.value);
  revalidatePath("/");                     // either way, the board should show the database's truth
  return moved ? {} : { error: "That task no longer exists" };
}

export async function removeTask(id: number): Promise<void> {
  const user = await requireUser();
  deleteTask(user, Number(id));
  revalidatePath("/");
}
