// file: app/app/actions.js
"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "../lib/db.js";
import { authenticate, parseCredentials, register } from "../lib/auth.js";
import { createSession, destroySession, getCurrentUser } from "../lib/session.js";

export async function signUp(previous, formData) {
  const c = parseCredentials(formData.get("email"), formData.get("password"));
  if (c.error) return c;
  const user = register(c.email, c.password);
  if (!user) return { error: "That email is already registered", email: c.email };
  await createSession(user.id);
  redirect("/");
}

export async function signIn(previous, formData) {
  const c = parseCredentials(formData.get("email"), formData.get("password"));
  if (c.error) return c;
  const user = authenticate(c.email, c.password);
  if (!user) return { error: "Wrong email or password", email: c.email };   // never say which
  await createSession(user.id);
  redirect("/");
}

export async function signOut() {
  await destroySession();
  redirect("/login");
}

async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new Error("Not signed in");
  return user;
}

export async function addNote(formData) {
  const user = await requireUser();
  const text = String(formData.get("text") ?? "").trim();
  if (text.length < 1 || text.length > 500) return;
  db.prepare("INSERT INTO notes (user_id, text) VALUES (?, ?)").run(user.id, text);
  revalidatePath("/");
}

export async function deleteNote(id) {
  const user = await requireUser();
  // The owner check is part of the query: another user's note id deletes nothing.
  db.prepare("DELETE FROM notes WHERE id = ? AND user_id = ?").run(Number(id), user.id);
  revalidatePath("/");
}
