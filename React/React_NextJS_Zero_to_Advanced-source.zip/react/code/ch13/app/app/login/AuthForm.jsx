// file: app/app/login/AuthForm.jsx
"use client";
import { useActionState } from "react";

export function AuthForm({ action, label }) {
  const [state, formAction, pending] = useActionState(action, { email: "" });
  return (
    <form action={formAction} aria-label={label}>
      <label>Email <input name="email" type="email" defaultValue={state.email} /></label>
      <label>Password <input name="password" type="password" /></label>
      {state.error && <p role="alert">{state.error}</p>}
      <button disabled={pending}>{label}</button>
    </form>
  );
}
