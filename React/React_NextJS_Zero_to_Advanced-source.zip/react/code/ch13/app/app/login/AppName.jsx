// file: app/app/login/AppName.jsx
"use client";
export function AppName() {
  return <small id="app-name">{process.env.NEXT_PUBLIC_APP_NAME ?? "(unnamed)"}</small>;
}
