// file: app/app/login/page.jsx
import { AuthForm } from "./AuthForm.jsx";
import { AppName } from "./AppName.jsx";
import { signIn, signUp } from "../actions.js";

export default function Login() {
  return <main>
    <h1>Private notes <AppName /></h1>
    <p id="motd">{process.env.MOTD}</p>
    <AuthForm action={signIn} label="Sign in" />
    <AuthForm action={signUp} label="Create account" />
  </main>;
}
