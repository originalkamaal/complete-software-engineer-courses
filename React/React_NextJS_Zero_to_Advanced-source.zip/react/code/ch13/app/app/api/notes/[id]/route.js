// file: app/app/api/notes/[id]/route.js
import { db } from "../../../../lib/db.js";
import { getCurrentUser } from "../../../../lib/session.js";

export async function DELETE(request, { params }) {
  const user = await getCurrentUser();                                    // authentication
  if (!user) return Response.json({ error: "Sign in first" }, { status: 401 });
  const { id } = await params;
  const { changes } = db.prepare("DELETE FROM notes WHERE id = ? AND user_id = ?")   // authorisation
    .run(Number(id), user.id);
  // 404, not 403: do not confirm that someone else's note exists.
  return changes ? new Response(null, { status: 204 }) : Response.json({ error: "No such note" }, { status: 404 });
}
