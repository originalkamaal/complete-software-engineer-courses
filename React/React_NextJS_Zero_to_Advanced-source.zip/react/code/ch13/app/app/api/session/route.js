// file: app/app/api/session/route.js
// POST /api/session {email, password} → sets the session cookie (for API clients and tests).
import { authenticate, parseCredentials } from "../../../lib/auth.js";
import { createSession } from "../../../lib/session.js";

export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  const c = parseCredentials(body.email, body.password);
  const user = !c.error && authenticate(c.email, c.password);
  if (!user) return Response.json({ error: "Wrong email or password" }, { status: 401 });
  await createSession(user.id);
  return Response.json({ email: user.email });
}
