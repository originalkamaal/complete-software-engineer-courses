// file: app/app/api/health/route.js
// For load balancers and uptime checks: is the server up, and can it reach the database?
import { db } from "../../../lib/db.js";

export function GET() {
  const { n } = db.prepare("SELECT count(*) AS n FROM users").get();
  return Response.json({ ok: true, users: n, motd: process.env.MOTD ?? null });
}
