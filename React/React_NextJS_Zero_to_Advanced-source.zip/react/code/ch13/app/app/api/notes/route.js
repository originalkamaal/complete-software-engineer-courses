// file: app/app/api/notes/route.js
import { db } from "../../../lib/db.js";
import { getCurrentUser } from "../../../lib/session.js";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Sign in first" }, { status: 401 });
  return Response.json(db.prepare("SELECT id, text FROM notes WHERE user_id = ? ORDER BY id").all(user.id));
}
