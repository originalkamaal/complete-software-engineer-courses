// file: app/app/layout.jsx
export const metadata = { title: "Private notes" };
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
