// file: app/app/page.jsx
import { redirect } from "next/navigation";
import { db } from "../lib/db.js";
import { getCurrentUser } from "../lib/session.js";
import { addNote, deleteNote, signOut } from "./actions.js";

export default async function Home() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const notes = db.prepare("SELECT id, text FROM notes WHERE user_id = ? ORDER BY id").all(user.id);
  return <main>
    <p>Signed in as <b id="who">{user.email}</b> <button form="out">Sign out</button></p>
    <form id="out" action={signOut} />
    <h1>Your notes</h1>
    <ul id="notes">{notes.map((n) => <li key={n.id}>{n.text}{" "}
      <form action={deleteNote.bind(null, n.id)} style={{ display: "inline" }}>
        <button aria-label={`Delete note ${n.id}`}>×</button>
      </form></li>)}</ul>
    <form action={addNote}><input name="text" aria-label="New note" /><button>Add</button></form>
  </main>;
}
