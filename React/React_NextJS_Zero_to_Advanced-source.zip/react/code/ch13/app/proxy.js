// file: app/proxy.js
import { NextResponse } from "next/server";

// Runs before every matching request. An optimistic check only: it sees that a cookie exists,
// not that the session is valid. The real check is getCurrentUser() in the page and actions.
export function proxy(request) {
  if (!request.cookies.has("session")) return NextResponse.redirect(new URL("/login", request.url));
}
export const config = { matcher: ["/"] };
