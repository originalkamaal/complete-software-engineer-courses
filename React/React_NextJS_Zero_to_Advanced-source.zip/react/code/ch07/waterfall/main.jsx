// file: waterfall/main.jsx
// Fetch-in-effect makes a waterfall: the parent fetches, renders, THEN the child fetches.
// Route loaders start every fetch of the matched routes at once, before rendering.
import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider, Outlet, useLoaderData } from "react-router";

const t0 = performance.now();
const log = (what) => console.log(`${what} at ${Math.round(performance.now() - t0)} ms`);
const getJson = (url) => fetch(url).then((r) => r.json());

function EffectParent() {
  const [stats, setStats] = useState(null);
  useEffect(() => { getJson("/api/stats?delay=300").then((s) => { log("effects: parent data"); setStats(s); }); }, []);
  return stats ? <><p>{stats.total} contacts</p><EffectChild /></> : <p>loading…</p>;
}
function EffectChild() {
  const [c, setC] = useState(null);
  useEffect(() => { getJson("/api/contacts/1?delay=300").then((d) => { log("effects: child data"); setC(d); }); }, []);
  return <p>{c ? c.first : "loading…"}</p>;
}

function LoaderParent() { const stats = useLoaderData(); return <><p>{stats.total} contacts</p><Outlet /></>; }
function LoaderChild() { const c = useLoaderData(); log("loaders: child rendered with data"); return <p>{c.first}</p>; }
const router = createBrowserRouter([{
  path: "/waterfall/loaders", Component: LoaderParent, HydrateFallback: () => <p>loading…</p>,
  loader: async () => { const s = await getJson("/api/stats?delay=300"); log("loaders: parent data"); return s; },
  children: [{ index: true, Component: LoaderChild,
    loader: async () => { const c = await getJson("/api/contacts/1?delay=300"); log("loaders: child data"); return c; } }],
}]);

const root = createRoot(document.getElementById("root"));
if (location.pathname.endsWith("/loaders")) root.render(<RouterProvider router={router} />);
else root.render(<EffectParent />);
