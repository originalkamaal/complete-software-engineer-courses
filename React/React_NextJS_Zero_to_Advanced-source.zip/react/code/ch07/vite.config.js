// file: vite.config.js
// A fake contacts API (150 ms per request) and an SPA fallback, so that /project/contacts/3 loads the app.
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

let contacts = [
  { id: 1, first: "Ada", last: "Lovelace", notes: "First programmer." },
  { id: 2, first: "Grace", last: "Hopper", notes: "Compilers; COBOL." },
  { id: 3, first: "Alan", last: "Turing", notes: "Computability." },
];
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

function fakeApi() {
  return {
    name: "fake-api",
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = new URL(req.url, "http://x");
        if (!url.pathname.startsWith("/api/")) {
          // client-side routes of the project page: serve its index.html (Book 1, Unit 17.2)
          if (/^\/(project|waterfall)\/./.test(url.pathname) && !url.pathname.includes(".")) req.url = `/${url.pathname.split("/")[1]}/`;
          return next();
        }
        await delay(Number(url.searchParams.get("delay") ?? 150));
        const send = (status, data) => { res.statusCode = status; res.setHeader("Content-Type", "application/json"); res.end(JSON.stringify(data)); };
        console.log(`  api: ${req.method} ${url.pathname}${url.search}`);
        const m = /^\/api\/contacts\/(\d+)$/.exec(url.pathname);
        if (url.pathname === "/api/contacts" && req.method === "GET") {
          const q = (url.searchParams.get("q") ?? "").toLowerCase();
          return send(200, contacts.filter((c) => `${c.first} ${c.last}`.toLowerCase().includes(q)));
        }
        if (url.pathname === "/api/contacts" && req.method === "POST") {
          const c = { id: Math.max(0, ...contacts.map((x) => x.id)) + 1, first: "", last: "", notes: "" };
          contacts.push(c); return send(201, c);
        }
        if (m) {
          const c = contacts.find((x) => x.id === Number(m[1]));
          if (!c) return send(404, { error: "not found" });
          if (req.method === "GET") return send(200, c);
          if (req.method === "DELETE") { contacts = contacts.filter((x) => x !== c); return send(204, null); }
          if (req.method === "PUT") {
            let body = ""; for await (const chunk of req) body += chunk;
            const data = JSON.parse(body);
            if (!data.first?.trim()) return send(422, { errors: { first: "First name is required" } });
            Object.assign(c, data); return send(200, c);
          }
        }
        if (url.pathname === "/api/stats") return send(200, { total: contacts.length });
        send(404, { error: "no such endpoint" });
      });
    },
  };
}
export default defineConfig({
  plugins: [react(), fakeApi()],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client", "react-router"] },
});
