// file: project/main.jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router";
import { Root, Contact, EditContact, ErrorPage, Welcome, destroy } from "./routes.jsx";

const router = createBrowserRouter([{
  path: "/project/", Component: Root, loader: Root.loader, action: Root.action,
  ErrorBoundary: ErrorPage, HydrateFallback: () => <p>Loading…</p>,
  children: [{
    ErrorBoundary: ErrorPage,                                 // errors in a contact keep the list on screen
    children: [
      { index: true, Component: Welcome },
      { path: "contacts/:id", Component: Contact, loader: Contact.loader },
      { path: "contacts/:id/edit", Component: EditContact, loader: EditContact.loader, action: EditContact.action },
      { path: "contacts/:id/destroy", action: destroy.action },
    ],
  }],
}]);
router.subscribe((state) => { if (state.navigation.state === "idle") console.log(`[router] ${state.location.pathname}${state.location.search}`); });
createRoot(document.getElementById("root")).render(<StrictMode><RouterProvider router={router} /></StrictMode>);
