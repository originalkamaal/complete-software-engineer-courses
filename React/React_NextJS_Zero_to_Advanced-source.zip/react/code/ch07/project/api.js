// file: project/api.js
async function request(path, options) {
  const res = await fetch(`/api${path}`, options);
  if (res.status === 404) throw new Response("Not found", { status: 404 });   // routes turn this into a 404 page
  const data = res.status === 204 ? null : await res.json();
  return { status: res.status, data };
}
export const listContacts = (q, signal) => request(`/contacts?q=${encodeURIComponent(q)}`, { signal }).then((r) => r.data);
export const getContact = (id, signal) => request(`/contacts/${id}`, { signal }).then((r) => r.data);
export const createContact = () => request("/contacts", { method: "POST" }).then((r) => r.data);
export const updateContact = (id, data) => request(`/contacts/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteContact = (id) => request(`/contacts/${id}`, { method: "DELETE" });
