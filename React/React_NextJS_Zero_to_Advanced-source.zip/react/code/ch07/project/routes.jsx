// file: project/routes.jsx
// A contacts app with React Router's data APIs: loaders read, actions write, and after every
// action the router re-runs the loaders, so the screen always shows the server's data.
import { Form, Link, NavLink, Outlet, redirect, useLoaderData, useNavigation, useRouteError,
         useSubmit, isRouteErrorResponse, useActionData } from "react-router";
import * as api from "./api.js";

export function Root() {
  const { contacts, q } = useLoaderData();
  const navigation = useNavigation();                       // "idle" | "loading" | "submitting"
  const submit = useSubmit();
  return (
    <div className="app">
      <nav aria-label="Contacts">
        <Form role="search" id="search">
          <input aria-label="Search contacts" name="q" defaultValue={q} key={q}
                 onChange={(e) => submit(e.currentTarget.form, { replace: q !== "" })} />
        </Form>
        <Form method="post"><button>New</button></Form>
        <ul>{contacts.map((c) => <li key={c.id}>
          <NavLink to={`contacts/${c.id}`}>{c.first || c.last ? `${c.first} ${c.last}` : <i>No name</i>}</NavLink>
        </li>)}</ul>
      </nav>
      <main aria-busy={navigation.state !== "idle"}><Outlet /></main>
    </div>
  );
}
Root.loader = async ({ request }) => {
  const q = new URL(request.url).searchParams.get("q") ?? "";   // the search lives in the URL
  return { contacts: await api.listContacts(q, request.signal), q };
};
Root.action = async () => {
  const contact = await api.createContact();
  return redirect(`contacts/${contact.id}/edit`);
};

export function Contact() {
  const c = useLoaderData();
  return (
    <article>
      <h1>{c.first} {c.last}</h1>
      <p>{c.notes}</p>
      <Link to="edit">Edit</Link>
      <Form method="post" action="destroy" onSubmit={(e) => { if (!confirm("Delete this contact?")) e.preventDefault(); }}>
        <button>Delete</button>
      </Form>
    </article>
  );
}
Contact.loader = ({ params, request }) => api.getContact(params.id, request.signal);

export function EditContact() {
  const c = useLoaderData();
  const errors = useActionData()?.errors ?? {};
  const navigation = useNavigation();
  return (
    <Form method="post">
      <h1>Edit contact</h1>
      <p><label>First <input name="first" defaultValue={c.first} aria-invalid={!!errors.first}
           aria-describedby={errors.first ? "first-error" : undefined} /></label>
         {errors.first && <span id="first-error" role="alert"> {errors.first}</span>}</p>
      <p><label>Last <input name="last" defaultValue={c.last} /></label></p>
      <p><label>Notes <textarea name="notes" defaultValue={c.notes} /></label></p>
      <button disabled={navigation.state === "submitting"}>{navigation.state === "submitting" ? "Saving…" : "Save"}</button>
    </Form>
  );
}
EditContact.loader = Contact.loader;
EditContact.action = async ({ request, params }) => {
  const data = Object.fromEntries(await request.formData());
  const { status, data: body } = await api.updateContact(params.id, data);
  if (status === 422) return body;                           // shown by useActionData; the form keeps its input
  return redirect(`/project/contacts/${params.id}`);
};

export const destroy = { action: async ({ params }) => { await api.deleteContact(params.id); return redirect("/project/"); } };

export function ErrorPage() {
  const error = useRouteError();
  return <article role="alert"><h1>{isRouteErrorResponse(error) && error.status === 404 ? "Not found" : "Something went wrong"}</h1>
    <Link to="/project/">Back to all contacts</Link></article>;
}

export const Welcome = () => <p>Choose a contact, or create a new one.</p>;
