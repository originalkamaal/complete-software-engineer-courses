// file: custom/main.jsx
// A custom hook is a function whose name starts with "use" and that calls other hooks.
// It shares LOGIC between components; each component that calls it gets its OWN state.
import { useState, useId } from "react";
import { createRoot } from "react-dom/client";

function useToggle(initial = false) {
  const [on, setOn] = useState(initial);
  const toggle = () => setOn((v) => !v);
  return [on, toggle];
}

function useField(label, validate) {
  const id = useId();                                 // unique, stable, and the same on server and client
  const [value, setValue] = useState("");
  const [touched, setTouched] = useState(false);
  const error = touched ? validate(value) : null;
  return {
    value, error,
    inputProps: { id, value, onChange: (e) => setValue(e.target.value), onBlur: () => setTouched(true),
                  "aria-invalid": Boolean(error), "aria-describedby": error ? `${id}-err` : undefined },
    labelProps: { htmlFor: id, children: label },
    errorProps: { id: `${id}-err`, children: error },
  };
}

function Field({ label, validate }) {
  const f = useField(label, validate);
  return <p><label {...f.labelProps} /> <input {...f.inputProps} /> {f.error && <span {...f.errorProps} />}</p>;
}

function Panel({ title }) {
  const [open, toggle] = useToggle();
  return <section><button aria-expanded={open} onClick={toggle}>{title}</button>{open && <p>{title} content</p>}</section>;
}

createRoot(document.getElementById("root")).render(<>
  <Panel title="First" /><Panel title="Second" />
  <Field label="Email" validate={(v) => (v.includes("@") ? null : "needs an @")} />
  <Field label="Name" validate={(v) => (v ? null : "required")} />
</>);
