// file: rules/main.jsx
// Hooks are identified by the ORDER in which they are called. A conditional hook breaks the order.
import { useState } from "react";
import { createRoot } from "react-dom/client";

function Profile({ showNickname }) {
  const [name, setName] = useState("Ana");
  if (showNickname) {
    const [nickname] = useState("Annie");          // BREAKS THE RULES: only called on some renders
    return <p>{name} ({nickname})</p>;
  }
  const [age] = useState(36);
  return <p>{name}, {age}</p>;
}

function App() {
  const [show, setShow] = useState(false);
  return <><button onClick={() => setShow(!show)}>toggle</button><Profile showNickname={show} /></>;
}
createRoot(document.getElementById("root")).render(<App />);
