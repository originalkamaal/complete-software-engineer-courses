// file: refs/main.jsx
// useRef: a box that survives renders and does NOT cause one when it changes.
import { useRef, useState } from "react";
import { createRoot } from "react-dom/client";

function Search() {
  const input = useRef(null);                     // React puts the DOM node here after it renders
  const renders = useRef(0);
  const [query, setQuery] = useState("");
  renders.current++;                              // fine: not used to decide what to render
  return (
    <p>
      <input ref={input} value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search" />
      <button onClick={() => input.current.focus()}>Focus the search box</button>
      <button onClick={() => { input.current.value = "typed by the DOM"; }}>Write to the DOM directly</button>
      <span id="info"> renders: {renders.current}, state: "{query}"</span>
    </p>
  );
}

function Stopwatch() {
  const [, force] = useState(0);
  const clicks = useRef(0);
  return <p><button onClick={() => { clicks.current++; console.log(`ref is ${clicks.current}`); }}>count in a ref</button>
    <button onClick={() => force((n) => n + 1)}>re-render</button> shown: {clicks.current}</p>;
}
createRoot(document.getElementById("root")).render(<><Search /><Stopwatch /></>);
