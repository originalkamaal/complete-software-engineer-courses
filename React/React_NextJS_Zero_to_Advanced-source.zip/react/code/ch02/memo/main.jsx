// file: memo/main.jsx
// useMemo caches a computed value until one of its dependencies changes (compared with Object.is).
import { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";

const PRODUCTS = Array.from({ length: 20_000 }, (_, i) => ({ id: i, name: `item ${i}`, price: (i * 7919) % 1000 }));
let filterRuns = 0;
function filterProducts(products, { maxPrice }) {
  filterRuns++;
  return products.filter((p) => p.price <= maxPrice);
}

function List() {
  const [maxPrice, setMaxPrice] = useState(100);
  const [dark, setDark] = useState(false);
  const options = { maxPrice };                                           // a NEW object on every render
  const cached = useMemo(() => filterProducts(PRODUCTS, { maxPrice }), [maxPrice]);
  const useless = useMemo(() => filterProducts(PRODUCTS, options), [options]);   // deps change every time
  return (
    <p className={dark ? "dark" : ""}>
      {cached.length} / {useless.length} products{" "}
      <button onClick={() => setDark(!dark)}>toggle theme</button>
      <button onClick={() => setMaxPrice(maxPrice + 100)}>raise price limit</button>
    </p>
  );
}
createRoot(document.getElementById("root")).render(<List />);
window.filterRuns = () => filterRuns;
