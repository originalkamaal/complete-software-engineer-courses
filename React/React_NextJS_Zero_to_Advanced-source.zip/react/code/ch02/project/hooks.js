// file: project/hooks.js
// A tiny component runtime with hooks: enough to show HOW React remembers state between renders.
// State lives outside the component, in a slot list per component instance; an instance is
// identified by its position in the tree (and its key and type), and its hooks by call order.
import { Fragment } from "react";

const instances = new Map();          // instance id -> { hooks: [], count }
let current = null;                   // the instance currently rendering
let rerender = null, scheduled = false;
export const handlers = new Map();    // element id -> onClick, so that tests can "click"

function schedule() {
  if (scheduled) return;
  scheduled = true;
  queueMicrotask(() => {                                     // batch all updates of this tick
    scheduled = false;
    try { rerender(); } catch (e) { console.log(`render failed: ${e.message}`); }
  });
}

export function useState(initial) {
  const inst = current, i = inst.cursor++;
  if (!(i in inst.hooks)) inst.hooks[i] = typeof initial === "function" ? initial() : initial;
  const set = (v) => {
    const next = typeof v === "function" ? v(inst.hooks[i]) : v;
    if (Object.is(next, inst.hooks[i])) return;               // same value: no re-render
    inst.hooks[i] = next;
    schedule();
  };
  return [inst.hooks[i], set];
}

export function useRef(initial) {
  const inst = current, i = inst.cursor++;
  if (!(i in inst.hooks)) inst.hooks[i] = { current: initial };
  return inst.hooks[i];
}

export function useMemo(compute, deps) {
  const inst = current, i = inst.cursor++;
  const old = inst.hooks[i];
  if (old && deps.length === old.deps.length && deps.every((d, k) => Object.is(d, old.deps[k]))) return old.value;
  inst.hooks[i] = { value: compute(), deps };
  return inst.hooks[i].value;
}

function renderNode(node, path, seen) {
  if (node == null || typeof node === "boolean") return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map((n, i) => renderNode(n, `${path}/${n?.key ?? i}`, seen)).join("");
  const { type, props } = node;
  if (type === Fragment) return renderNode(props.children, path, seen);
  if (typeof type === "function") {
    const id = `${path}<${type.name}>`;                       // position + type = identity
    seen.add(id);
    const inst = instances.get(id) ?? { hooks: [], count: null };
    instances.set(id, inst);
    const prev = current;
    current = inst; inst.cursor = 0;
    try {
      const out = type(props);
      if (inst.count !== null && inst.cursor !== inst.count)
        throw new Error(`${type.name} called ${inst.cursor} hooks, but ${inst.count} during the previous render`);
      inst.count = inst.cursor;
      return renderNode(out, `${id}`, seen);
    } finally { current = prev; }
  }
  if (props.id && props.onClick) handlers.set(props.id, props.onClick);
  const attrs = props.id ? ` id="${props.id}"` : "";
  return `<${type}${attrs}>${renderNode(props.children, path + "/" + type, seen)}</${type}>`;
}

export function createRoot(onCommit) {
  let element;
  rerender = () => {
    const seen = new Set();
    handlers.clear();
    const html = renderNode(element, "root", seen);
    for (const id of instances.keys()) if (!seen.has(id)) instances.delete(id);   // unmounted: state is gone
    onCommit(html);
  };
  return { render(el) { element = el; rerender(); } };
}
export const click = (id) => handlers.get(id)();
export const settle = () => new Promise((r) => setTimeout(r, 0));
