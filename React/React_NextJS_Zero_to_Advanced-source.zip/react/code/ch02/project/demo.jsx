// file: project/demo.jsx
import { createRoot, useState, useMemo, useRef, click, settle } from "./hooks.js";

let expensive = 0;
function Counter({ label }) {
  const [count, setCount] = useState(0);
  const renders = useRef(0);
  renders.current++;
  const squared = useMemo(() => (expensive++, count * count), [count]);
  return <li>{label}: {count} (squared {squared}, rendered {renders.current}×)
    <button id={`inc-${label}`} onClick={() => { setCount((c) => c + 1); setCount((c) => c + 1); }}>+2</button></li>;
}

function App() {
  const [showB, setShowB] = useState(true);
  const [tick, setTick] = useState(0);
  return <div>
    <button id="toggle" onClick={() => setShowB(!showB)}>toggle B</button>
    <button id="tick" onClick={() => setTick(tick + 1)}>tick</button>
    <ul><Counter label="A" />{showB && <Counter label="B" />}</ul>
  </div>;
}

const root = createRoot((html) => console.log(html.replace(/<\/?(div|ul|button)[^>]*>|toggle B|tick|\+2/g, "").replace(/<\/li>/g, " | ")));
root.render(<App />);
click("inc-A"); await settle();                 // two updates, one render
click("tick"); await settle();                  // App re-renders: counters keep their state
click("toggle"); await settle();                // B unmounts: its state is deleted
click("toggle"); await settle();                // B mounts again: fresh state
console.log(`useMemo computed ${expensive} times`);

function Broken({ flag }) {
  const [a] = useState(1);
  if (flag) useState(2);                          // breaks the order
  return <p>{a}</p>;
}
function Parent() { const [f, setF] = useState(false); return <div><button id="f" onClick={() => setF(true)}>x</button><Broken flag={f} /></div>; }
const root2 = createRoot(() => {});
root2.render(<Parent />);
click("f");
await settle();
