// file: stream/app/report/page.jsx
import { Suspense } from "react";
import { connection } from "next/server";
import { getSales, getReviews } from "../slow.js";

async function Sales() {
  await connection();                       // per-request data: never prerendered
  const { total } = await getSales();
  return <p id="sales">Sales today: {total}</p>;
}
async function Reviews() {
  await connection();
  const reviews = await getReviews();
  return <ul id="reviews">{reviews.map((r) => <li key={r}>{r}</li>)}</ul>;
}

export default function Report() {
  return <main>
    <h1>Daily report</h1>                    {/* static shell: prerendered at build time */}
    <Suspense fallback={<p>Loading sales…</p>}><Sales /></Suspense>
    <Suspense fallback={<p>Loading reviews…</p>}><Reviews /></Suspense>
  </main>;
}
