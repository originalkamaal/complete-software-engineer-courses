// file: stream/app/product/page.jsx
import { cacheLife } from "next/cache";
import { wait } from "../slow.js";

async function getPrice() {
  "use cache";                              // the result is cached and reused across requests
  cacheLife({ stale: 30, revalidate: 5, expire: 3600 });   // seconds
  await wait(300);
  return { price: 42, computedAt: new Date().toISOString() };
}

export default async function Product() {
  const { price, computedAt } = await getPrice();
  return <main><h1>Widget</h1><p>${price} (computed {computedAt})</p></main>;
}
