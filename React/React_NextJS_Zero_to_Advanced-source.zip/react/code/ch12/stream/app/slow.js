// file: stream/app/slow.js
export const wait = (ms) => new Promise((r) => setTimeout(r, ms));
export async function getSales() { await wait(800); return { total: 12345 }; }
export async function getReviews() { await wait(1600); return ["Great", "Fast delivery"]; }
