// file: rsc/app/page.jsx
import { getNotes, SECRET_API_KEY } from "../lib/db.js";
import { LikeButton } from "./LikeButton.jsx";

// A Server Component: it runs only on the server, may be async, and may read secrets.
export default async function Home() {
  const notes = await getNotes();
  console.log(`[server] rendering Home with key ending ${SECRET_API_KEY.slice(-4)}`);
  return <main>
    <h1>Notes</h1>
    <ul>{notes.map((n) => <li key={n.id}>{n.text} <LikeButton id={n.id} /></li>)}</ul>
  </main>;
}
