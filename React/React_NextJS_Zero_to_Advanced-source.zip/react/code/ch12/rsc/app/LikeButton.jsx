// file: rsc/app/LikeButton.jsx
"use client";                              // this module and its imports are sent to the browser
import { useState } from "react";

export function LikeButton({ id }) {
  const [likes, setLikes] = useState(0);
  return <button onClick={() => setLikes(likes + 1)} aria-label={`Like note ${id}`}>♥ {likes}</button>;
}
