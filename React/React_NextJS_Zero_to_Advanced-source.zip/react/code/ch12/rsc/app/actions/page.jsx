// file: rsc/app/actions/page.jsx
import { revalidatePath } from "next/cache";
import { addNote, getNotes } from "../../lib/db.js";

// A Server Function: called from the browser by a form, runs on the server.
async function create(formData) {
  "use server";
  const text = String(formData.get("text") ?? "").trim();
  if (!text) return;
  await addNote(text);
  console.log(`[server] added "${text}"`);
  revalidatePath("/actions");             // the prerendered page is now stale: render it again
}

export default async function ActionsPage() {
  const notes = await getNotes();
  return <main>
    <h1>Notes ({notes.length})</h1>
    <ul>{notes.map((n) => <li key={n.id}>{n.text}</li>)}</ul>
    <form action={create}>
      <input name="text" aria-label="New note" required />
      <button>Add</button>
    </form>
  </main>;
}
