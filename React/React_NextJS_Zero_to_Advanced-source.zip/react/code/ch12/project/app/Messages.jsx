// file: project/app/Messages.jsx
import { getMessages } from "../lib/store.js";

export async function Messages() {
  const messages = await getMessages();
  return <ol id="messages">{messages.map((m) => <li key={m.id}><b>{m.name}</b>: {m.text}</li>)}</ol>;
}
