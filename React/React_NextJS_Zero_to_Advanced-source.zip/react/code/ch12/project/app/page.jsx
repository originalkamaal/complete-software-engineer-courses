// file: project/app/page.jsx
import { Messages } from "./Messages.jsx";
import { MessageForm } from "./MessageForm.jsx";

export default function Home() {
  return <main>
    <h1>Guestbook</h1>
    <MessageForm />
    <Messages />
  </main>;
}
