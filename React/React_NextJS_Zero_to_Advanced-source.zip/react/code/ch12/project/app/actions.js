// file: project/app/actions.js
"use server";                               // every export is a Server Function (a public endpoint)
import { updateTag } from "next/cache";
import { addMessage } from "../lib/store.js";

export async function postMessage(previous, formData) {
  const values = { name: String(formData.get("name") ?? "").trim(), text: String(formData.get("text") ?? "").trim() };
  const errors = {};
  if (values.name.length < 1 || values.name.length > 40) errors.name = "Name must be 1–40 characters";
  if (values.text.length < 1 || values.text.length > 280) errors.text = "Message must be 1–280 characters";
  if (Object.keys(errors).length) return { errors, values };

  await addMessage(values);
  updateTag("messages");                    // expire the cached list; this request sees the new one
  return { errors: {}, values: { name: values.name, text: "" }, posted: Date.now() };
}
