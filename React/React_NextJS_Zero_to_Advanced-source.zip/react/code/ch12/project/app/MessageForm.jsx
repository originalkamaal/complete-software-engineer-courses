// file: project/app/MessageForm.jsx
"use client";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { postMessage } from "./actions.js";

function Submit() {
  const { pending } = useFormStatus();
  return <button disabled={pending}>{pending ? "Posting…" : "Post"}</button>;
}

export function MessageForm() {
  const [state, action] = useActionState(postMessage, { errors: {}, values: { name: "", text: "" } });
  return (
    <form action={action} key={state.posted}>     {/* a new key after success clears the fields */}
      <label>Name <input name="name" defaultValue={state.values.name} aria-invalid={!!state.errors.name} /></label>
      {state.errors.name && <p role="alert">{state.errors.name}</p>}
      <label>Message <textarea name="text" defaultValue={state.values.text} aria-invalid={!!state.errors.text} /></label>
      {state.errors.text && <p role="alert">{state.errors.text}</p>}
      <Submit />
    </form>
  );
}
