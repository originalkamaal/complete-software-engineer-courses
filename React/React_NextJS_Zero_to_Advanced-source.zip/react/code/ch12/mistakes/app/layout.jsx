// file: rsc/app/layout.jsx
export const metadata = { title: "Chapter 12" };
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
