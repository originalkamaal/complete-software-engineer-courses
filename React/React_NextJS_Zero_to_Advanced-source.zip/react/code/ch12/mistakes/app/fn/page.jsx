// file: mistakes/app/fn/page.jsx
import { Clicker } from "../Clicker.jsx";
// Mistake 1: a Server Component passes a function to a Client Component.
export default function Page() {
  return <Clicker onClick={() => console.log("clicked")} />;
}
