// file: mistakes/app/Clicker.jsx
"use client";
export function Clicker({ onClick }) { return <button onClick={onClick}>Click</button>; }
