// file: vite.config.js
// This chapter's Vite configuration also serves a small fake API, with deliberate delays.
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const USERS = { 1: "Ana", 2: "Bo", 3: "Cy" };
const WORDS = ["react", "reason", "reduce", "redux", "ref", "render", "rust", "ruby", "remix", "relay"];

function fakeApi() {
  return {
    name: "fake-api",
    configureServer(server) {
      server.middlewares.use("/api", (req, res) => {
        const url = new URL(req.url, "http://x");
        const reply = (data, ms) => setTimeout(() => {
          res.setHeader("Content-Type", "application/json");
          res.end(JSON.stringify(data));
        }, ms);
        const user = /^\/users\/(\d+)$/.exec(url.pathname);
        if (user) return reply({ id: Number(user[1]), name: USERS[user[1]] }, user[1] === "1" ? 600 : 100);
        if (url.pathname === "/search") {             // shorter queries are slower: replies arrive out of order
          const q = url.searchParams.get("q") ?? "";
          console.log(`  api: search "${q}"`);
          return reply({ q, results: WORDS.filter((w) => w.startsWith(q)) }, Math.max(50, 400 - q.length * 100));
        }
        res.statusCode = 404; res.end("{}");
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), fakeApi()],
  logLevel: "warn",
  optimizeDeps: { include: ["react", "react/jsx-dev-runtime", "react-dom/client"] },
});
