// file: needless/main.jsx
// Two ways to show a filtered list. The effect version renders twice per change and, for one
// render, shows a list that does not match the query.
import { useEffect, useLayoutEffect, useState } from "react";
import { createRoot } from "react-dom/client";

const ITEMS = ["apple", "apricot", "banana", "blueberry", "cherry"];

function WithEffect({ query }) {
  const [visible, setVisible] = useState(ITEMS);
  useEffect(() => { setVisible(ITEMS.filter((i) => i.startsWith(query))); }, [query]);   // copies derived data into state
  console.log(`WithEffect render: query "${query}", showing ${visible.length}`);
  return <p>{visible.join(", ")}</p>;
}

function Derived({ query }) {
  const visible = ITEMS.filter((i) => i.startsWith(query));                              // just compute it
  console.log(`Derived render:    query "${query}", showing ${visible.length}`);
  return <p>{visible.join(", ")}</p>;
}

function Timing() {
  console.log("Timing: render");
  useLayoutEffect(() => { console.log("Timing: layout effect (DOM updated, not yet painted)"); });
  useEffect(() => {
    console.log("Timing: effect");
    requestAnimationFrame(() => console.log("Timing: next frame"));
  });
  return null;
}

function App() {
  const [query, setQuery] = useState("");
  return <><button onClick={() => setQuery("b")}>filter "b"</button><WithEffect query={query} /><Derived query={query} /><Timing /></>;
}
createRoot(document.getElementById("root")).render(<App />);
