// file: stale/main.jsx
// An effect sees the props and state of the render that created it. With the wrong dependencies,
// it keeps seeing old ones forever: a "stale closure".
import { useEffect, useEffectEvent, useState } from "react";
import { createRoot } from "react-dom/client";

function Stale() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setCount(count + 1), 100);   // count is 0 in this closure, forever
    return () => clearInterval(id);
  }, []);                                                       // the linter would flag the missing count
  return <p id="stale">{count}</p>;
}

function Updater() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setCount((c) => c + 1), 100); // needs no outside value at all
    return () => clearInterval(id);
  }, []);
  return <p id="updater">{count}</p>;
}

function WithEvent({ step }) {
  const [count, setCount] = useState(0);
  const onTick = useEffectEvent(() => setCount(count + step)); // always sees the latest count and step,
  useEffect(() => {                                            // without restarting the interval
    const id = setInterval(onTick, 100);
    return () => clearInterval(id);
  }, []);
  return <p id="event">{count}</p>;
}

createRoot(document.getElementById("root")).render(<><Stale /><Updater /><WithEvent step={10} /></>);
