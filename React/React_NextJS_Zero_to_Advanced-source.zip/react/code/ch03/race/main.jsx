// file: race/main.jsx
// Fetching in an effect. User 1 takes 600 ms, user 2 takes 100 ms: switch from 1 to 2 quickly,
// and the slow, outdated answer arrives LAST.
import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";

function Profile({ id, safe }) {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => {
    const controller = new AbortController();
    setUser(null);
    fetch(`/api/users/${id}`, { signal: safe ? controller.signal : undefined })
      .then((r) => r.json())
      .then(setUser)
      .catch((e) => { if (e.name !== "AbortError") setError(e); });
    if (safe) return () => controller.abort();        // the cleanup cancels the request we no longer want
  }, [id, safe]);
  if (error) return <p>Error: {error.message}</p>;
  return <p id={safe ? "safe" : "unsafe"}>{safe ? "safe" : "unsafe"}: user {id} is {user ? user.name : "loading…"}</p>;
}

function App() {
  const [id, setId] = useState(1);
  return <>
    <button onClick={() => setId(2)}>show user 2</button>
    <Profile id={id} safe={false} />
    <Profile id={id} safe />
  </>;
}
createRoot(document.getElementById("root")).render(<App />);
