// file: project/hooks.js
import { useEffect, useState } from "react";

/** The value, but only after it has stopped changing for `delay` ms. */
export function useDebouncedValue(value, delay) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);                  // a newer value cancels the pending one
  }, [value, delay]);
  return debounced;
}

/** Fetch JSON for a URL (or nothing for null). Outdated requests are aborted, so a slow old
 *  response can never overwrite a newer one. Returns { data, error, loading }. */
export function useJson(url) {
  const [state, setState] = useState({ data: null, error: null, loading: false });
  useEffect(() => {
    if (url === null) { setState({ data: null, error: null, loading: false }); return; }
    const controller = new AbortController();
    setState((s) => ({ ...s, loading: true, error: null }));      // keep showing old data while loading
    fetch(url, { signal: controller.signal })
      .then((r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then((data) => setState({ data, error: null, loading: false }))
      .catch((error) => {
        if (error.name === "AbortError") console.log(`aborted ${url}`);
        else setState({ data: null, error, loading: false });
      });
    return () => controller.abort();
  }, [url]);
  return state;
}
