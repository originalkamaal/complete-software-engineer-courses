// file: project/main.jsx
import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { useDebouncedValue, useJson } from "./hooks.js";

function Search() {
  const [text, setText] = useState("");
  const query = useDebouncedValue(text.trim(), 150);
  const { data, error, loading } = useJson(query ? `/api/search?q=${encodeURIComponent(query)}` : null);
  return (
    <search>
      <label>Search packages <input value={text} onChange={(e) => setText(e.target.value)} /></label>
      <p aria-live="polite">{loading ? "Searching…" : error ? `Failed: ${error.message}` : data ? `${data.results.length} results for "${data.q}"` : ""}</p>
      {data && <ul aria-busy={loading}>{data.results.map((r) => <li key={r}>{r}</li>)}</ul>}
    </search>
  );
}
createRoot(document.getElementById("root")).render(<StrictMode><Search /></StrictMode>);
