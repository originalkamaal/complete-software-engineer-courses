// file: effect/main.jsx
// An effect synchronises a component with something outside React — here, a "chat connection".
import { StrictMode, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";

const connections = new Set();
function connect(room) {                          // a stand-in for a WebSocket or a subscription
  const c = { room };
  connections.add(c);
  console.log(`  connect to ${room}: ${connections.size} open`);
  return () => { connections.delete(c); console.log(`  disconnect from ${room}: ${connections.size} open`); };
}

function ChatRoom({ room, withCleanup }) {
  useEffect(() => {
    const disconnect = connect(room);
    if (withCleanup) return disconnect;           // the cleanup runs before the next effect, and on unmount
  }, [room, withCleanup]);                         // re-synchronise when the room changes
  return <p>Room: {room}</p>;
}

function App() {
  const [room, setRoom] = useState("general");
  const [cleanup, setCleanup] = useState(new URLSearchParams(location.search).has("cleanup"));
  const [shown, setShown] = useState(true);
  return <>
    <button onClick={() => setRoom(room === "general" ? "travel" : "general")}>switch room</button>
    <button onClick={() => setShown(!shown)}>show/hide</button>
    {shown && <ChatRoom room={room} withCleanup={cleanup} />}
  </>;
}
console.log("mount (StrictMode mounts, unmounts, and mounts again in development):");
createRoot(document.getElementById("root")).render(<StrictMode><App /></StrictMode>);
window.openConnections = () => connections.size;
