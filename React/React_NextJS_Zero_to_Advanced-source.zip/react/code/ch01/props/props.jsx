// file: props/props.jsx
// Components compose: props flow down, children are just another prop, and props are read-only.
import { renderToString } from "react-dom/server";

function Panel({ title, tone = "info", children }) {          // a default value for a missing prop
  return <section className={`panel ${tone}`}><h2>{title}</h2>{children}</section>;
}
function Avatar({ user, size = 32 }) {
  return <img src={user.avatarUrl} alt={user.name} width={size} height={size} />;
}
function Profile({ user }) {          // everything between <Panel> and </Panel> becomes its children
  return (
    <Panel title={user.name}>
      <Avatar user={user} size={48} />
      <p>{user.bio}</p>
    </Panel>
  );
}
const user = { name: "Ana", bio: "Writes compilers.", avatarUrl: "/ana.png" };
console.log(renderToString(<Profile user={user} />));

function Greedy(props) {
  try { props.title = "changed"; } catch (e) { console.log(`props are frozen: ${e.constructor.name}`); }
  return null;
}
renderToString(<Greedy title="original" />);
