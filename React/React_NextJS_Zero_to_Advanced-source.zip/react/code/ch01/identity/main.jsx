// file: identity/main.jsx
// React keeps state per position in the tree, per component type. Two ways that surprises people.
import { useState } from "react";
import { createRoot } from "react-dom/client";

function Field({ label }) {
  const [text, setText] = useState("");
  return <label>{label} <input value={text} onChange={(e) => setText(e.target.value)} /></label>;
}

function Form() {
  const [user, setUser] = useState("ana");
  const [ticks, setTicks] = useState(0);
  // BUG: a component defined inside another is a NEW function on every render, so React sees a
  // different component type each time, unmounts the old one, and its state is lost.
  function InnerField() { return <Field label="inner" />; }
  return (
    <div>
      <p>
        <button onClick={() => setTicks(ticks + 1)}>re-render ({ticks})</button>{" "}
        <button onClick={() => setUser(user === "ana" ? "bo" : "ana")}>switch user ({user})</button>
      </p>
      <p id="outer"><Field label="outer" /></p>
      <p id="inner"><InnerField /></p>
      <p id="same"><Field label={`message to ${user}`} /></p>
      <p id="keyed"><Field key={user} label={`message to ${user}, keyed`} /></p>
    </div>
  );
}
createRoot(document.getElementById("root")).render(<Form />);
