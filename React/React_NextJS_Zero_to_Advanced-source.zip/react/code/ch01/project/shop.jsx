// file: project/shop.jsx
// A product list and a cart. One piece of state — the cart lines — lives in the common parent;
// everything else (counts, totals, which buttons are disabled) is derived from it while rendering.
import { useState } from "react";

const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const fmt = (cents) => money.format(cents / 100);

export const PRODUCTS = [
  { id: "tea", name: "Green tea", price: 450, stock: 3 },
  { id: "cof", name: "Coffee beans", price: 1299, stock: 5 },
  { id: "mug", name: "Mug", price: 899, stock: 0 },
];

function ProductList({ products, inCart, onAdd }) {
  return (
    <section aria-labelledby="products-h">
      <h2 id="products-h">Products</h2>
      <ul>
        {products.map((p) => {
          const left = p.stock - (inCart[p.id] ?? 0);
          return (
            <li key={p.id}>
              {p.name} — {fmt(p.price)}{" "}
              <button onClick={() => onAdd(p.id)} disabled={left === 0} aria-label={p.stock === 0 ? `${p.name}: sold out` : `Add ${p.name} to cart`}>
                {p.stock === 0 ? "Sold out" : "Add"}
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function CartLine({ product, qty, onChange }) {
  return (
    <li>
      {product.name} × {qty} = {fmt(product.price * qty)}{" "}
      <button onClick={() => onChange(qty - 1)} aria-label={`One less ${product.name}`}>−</button>
      <button onClick={() => onChange(qty + 1)} disabled={qty >= product.stock} aria-label={`One more ${product.name}`}>+</button>
      <button onClick={() => onChange(0)} aria-label={`Remove ${product.name}`}>Remove</button>
    </li>
  );
}

export function Shop({ products = PRODUCTS }) {
  const [cart, setCart] = useState({});               // { productId: quantity } — the only state
  const byId = Object.fromEntries(products.map((p) => [p.id, p]));
  const setQty = (id, qty) => setCart((c) => {
    if (qty > 0) return { ...c, [id]: qty };          // a new object every time: never mutate state
    const { [id]: _removed, ...rest } = c;            // (and spreading keeps each line in its place)
    return rest;
  });
  const lines = Object.entries(cart);
  const count = lines.reduce((n, [, q]) => n + q, 0);                       // derived, not stored
  const total = lines.reduce((s, [id, q]) => s + byId[id].price * q, 0);
  return (
    <main>
      <ProductList products={products} inCart={cart} onAdd={(id) => setQty(id, (cart[id] ?? 0) + 1)} />
      <section aria-labelledby="cart-h">
        <h2 id="cart-h">Cart ({count} {count === 1 ? "item" : "items"})</h2>
        {lines.length === 0 ? <p>Your cart is empty.</p> : (
          <ul>{lines.map(([id, qty]) => <CartLine key={id} product={byId[id]} qty={qty} onChange={(q) => setQty(id, q)} />)}</ul>
        )}
        <p>Total: <strong>{fmt(total)}</strong></p>
      </section>
    </main>
  );
}
