// file: project/main.jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Shop } from "./shop.jsx";

createRoot(document.getElementById("root")).render(<StrictMode><Shop /></StrictMode>);
