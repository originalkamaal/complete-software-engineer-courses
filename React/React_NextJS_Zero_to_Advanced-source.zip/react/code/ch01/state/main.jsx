// file: state/main.jsx
// Three facts about state, each with a button.
import { useState } from "react";
import { createRoot } from "react-dom/client";

function Snapshot() {
  const [count, setCount] = useState(0);
  function addThreeWrong() {
    setCount(count + 1); setCount(count + 1); setCount(count + 1);   // count is 0 in all three
    console.log(`right after the setters, count is still ${count}`);
  }
  function addThreeRight() {
    setCount((c) => c + 1); setCount((c) => c + 1); setCount((c) => c + 1);   // updater functions queue
  }
  return <p id="snap">count {count} <button onClick={addThreeWrong}>+3 (wrong)</button> <button onClick={addThreeRight}>+3 (right)</button></p>;
}

function Mutation() {
  const [items, setItems] = useState(["a"]);
  console.log(`Mutation renders: ${items.join(",")}`);
  return (
    <p id="mut">
      {items.join(", ")}{" "}
      <button onClick={() => { items.push("b"); setItems(items); }}>push (mutate)</button>{" "}
      <button onClick={() => setItems([...items, "c"])}>append (copy)</button>
    </p>
  );
}

function Batching() {
  const [a, setA] = useState(0), [b, setB] = useState(0);
  console.log(`Batching renders: a=${a} b=${b}`);
  return <p id="batch"><button onClick={() => { setA(a + 1); setB(b + 1); }}>both</button>
    <button onClick={() => setTimeout(() => { setA((x) => x + 1); setB((x) => x + 1); }, 0)}>both, later</button></p>;
}

createRoot(document.getElementById("root")).render(<><Snapshot /><Mutation /><Batching /></>);
