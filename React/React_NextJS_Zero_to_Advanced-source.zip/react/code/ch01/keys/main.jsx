// file: keys/main.jsx
// Each row has its own state (a note being typed). Reversing the list shows what keys are for.
import { useState } from "react";
import { createRoot } from "react-dom/client";

function Row({ name }) {
  const [note, setNote] = useState("");
  return <li>{name}: <input aria-label={`note for ${name}`} value={note} onChange={(e) => setNote(e.target.value)} /></li>;
}

function List({ useIndexKeys }) {
  const [people, setPeople] = useState(["Ana", "Bo", "Cy"]);
  return (
    <section id={useIndexKeys ? "index" : "id"}>
      <button onClick={() => setPeople([...people].reverse())}>Reverse</button>
      <ul>{people.map((name, i) => <Row key={useIndexKeys ? i : name} name={name} />)}</ul>
    </section>
  );
}

createRoot(document.getElementById("root")).render(<><List useIndexKeys /><List /></>);
