---
title: "Digital Design and Computer Architecture from Zero to Advanced"
subtitle: "From transistors and logic gates to a pipelined RISC-V processor in Verilog, branch predictors, caches, virtual memory, DRAM, and multicore coherence — every circuit simulated, every number measured"
lang: en
---

# Preface

A computer is a stack of promises. A program promises the compiler to follow the rules of its language; the compiler promises the processor an instruction stream that follows the rules of its **instruction set architecture** (ISA); the processor promises that, however it reorders and speculates inside, the result will look as if those instructions ran one after another; and the circuits underneath promise that a 1 stays a 1 long enough to be captured by the next clock edge. This book is about how each promise is kept — and about the cases where one is quietly broken, which is where most of the interesting engineering, and most of the security problems of the last decade, come from.

The book follows the topic order of Prof. Onur Mutlu's *Digital Design and Computer Architecture* course at ETH Zürich, whose lectures are freely available on YouTube, so that you can watch a lecture and then work through the matching chapter. Each chapter names the lectures it accompanies. The text, the circuits, the programs, and the exercises are written fresh for this book; the course is the map, not the source.

**Part I (Chapters 0–3)** goes from the transformation hierarchy and how to measure a computer, through Boolean algebra and combinational circuits, sequential circuits and finite state machines, to hardware description in Verilog, timing, and verification. **Part II (Chapters 4–9)** defines an ISA (RISC-V, compared throughout with MIPS and LC-3), writes assembly that runs, and then builds the processor: single-cycle, multi-cycle, pipelined with forwarding and stalls, precise exceptions, out-of-order execution, branch prediction, and the ways of finding more parallelism — superscalar, VLIW, SIMD, and GPUs. **Part III (Chapters 10–14)** is the memory system: caches, virtual memory, DRAM and its reliability and security problems such as RowHammer, storage and I/O, and multiprocessors with cache coherence and memory consistency. **Chapter 15** puts it together: a pipelined RV32I processor in Verilog that runs C programs compiled with GCC, with caches and a branch predictor, measured against the simulators you built along the way.

Three promises shape every page:

1. **Precision.** Each *Deep & Tricky* fact is labelled with its source of truth — the RISC-V ISA manual, the IEEE Verilog standard (IEEE 1364-2005 / 1800-2017), a JEDEC DRAM standard, a published paper, or a vendor's manual.
2. **Evidence.** Every circuit in the book was simulated with Icarus Verilog or Verilator, and every program was run; the waveforms, gate counts, cycle counts, miss rates, and timings shown are real outputs. When a first version of an example behaved differently from what the text claimed, the text was changed to match the hardware — and some of those surprises are kept, because they teach something.
3. **Order.** Nothing is used before it is taught.

# How to use this book

## Who it is for

- **Programmers who want to know what their code turns into:** read in order. The C book of this series is the best preparation; you should be able to read C and use the command line.
- **Students taking a computer architecture course:** read each chapter alongside the lectures it names, and do every *Predict* question before running the code.
- **Engineers preparing for hardware, performance, or systems roles:** the *Deep & Tricky* entries and the chapter projects are the parts interviews draw from.

No electronics background is needed: Chapter 1 starts from what a transistor does as a switch.

## The shape of a unit

| Part | What it gives you |
| --- | --- |
| **One-line summary** | The whole idea in one sentence. |
| **Lesson** | Circuits in Verilog, programs in C and assembly, simulators in Python — complete, with real output. |
| **Deep & Tricky (DT-n)** | Precise facts that surprise experienced engineers, labelled with their source of truth, usually with an experiment that shows the failure. |
| **Patterns (P-n)** | Engineering practices with their trade-offs. |
| **Mastery check** | *Predict* questions; answers at the end of each chapter. |

Each chapter ends with a **Chapter Project**: a realistic piece of work with complete code, real output, and a review checklist.

## Running the code

The source archive has one directory per chapter, with every file exactly as listed (each starts with a one-line `// file:` or `# file:` comment that names it). Console blocks show the exact commands, run from the chapter's directory.

You need a Linux machine (or macOS with Homebrew equivalents) with: `gcc`, `make`, Python 3, **Icarus Verilog** (`iverilog`, `vvp`) for simulation, **Verilator** for fast simulation and linting, **Yosys** for synthesis and gate counts, the **RISC-V GNU toolchain** (`riscv64-linux-gnu-gcc`, which also builds 32-bit RV32I code with `-march=rv32i -mabi=ilp32`), **QEMU user mode** (`qemu-riscv64`) to run RISC-V Linux programs, and **Valgrind** (its Cachegrind tool counts instructions and simulates caches). On Debian or Ubuntu:

```text
apt install build-essential python3 iverilog verilator yosys gcc-riscv64-linux-gnu qemu-user valgrind gtkwave
```

GTKWave is optional; it shows the `.vcd` waveform files the testbenches write. Everything was run on Ubuntu 24.04 with Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33, GCC 13.3 (native and RISC-V), and QEMU 8.2, on a two-core x86-64 virtual machine. Timings and cache sizes are from that machine; yours will differ in the numbers and agree in the shape.

## Reading order

| Part | Chapters | Builds on |
| --- | --- | --- |
| I — Digital design | 0 Why architecture · 1 Combinational logic · 2 Sequential logic · 3 Verilog, timing, verification | C (helpful) |
| II — The processor | 4 ISA and assembly · 5 Single- and multi-cycle · 6 Pipelining · 7 Exceptions and out-of-order · 8 Branch prediction · 9 Superscalar, VLIW, SIMD, GPUs | Part I |
| III — Memory and beyond | 10 Caches · 11 Virtual memory · 12 DRAM · 13 Storage and I/O · 14 Multiprocessors and coherence | Part II |
| Project | 15 A RISC-V CPU in Verilog | Everything |
