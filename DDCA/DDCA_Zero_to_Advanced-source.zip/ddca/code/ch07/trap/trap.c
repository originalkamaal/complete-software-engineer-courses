// file: trap/trap.c
#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>

static volatile int before = 0, after = 0;

static void handler(int sig, siginfo_t *info, void *uc_) {
    ucontext_t *uc = uc_;
    unsigned long pc = uc->uc_mcontext.__gregs[REG_PC];
    printf("signal %s at pc %#lx, si_addr %p\n", sig == SIGILL ? "SIGILL" : "SIGSEGV", pc, info->si_addr);
    printf("before = %d (older instruction completed), after = %d (younger instruction did not)\n", before, after);
    exit(0);
}

int main(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = handler;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGILL, &sa, NULL);
    sigaction(SIGSEGV, &sa, NULL);
    extern char faulting_instruction[];
    printf("the faulting instruction is at %p\n", (void *)faulting_instruction);
    __asm__ volatile(
        "li t0, 1\n"
        "sw t0, %0\n"                      /* before = 1 : older than the fault */
        ".globl faulting_instruction\n"
        "faulting_instruction:\n"
        ".word 0x00000000\n"               /* an illegal instruction (all zeros) */
        "sw t0, %1\n"                      /* after = 1  : younger: must not happen */
        : "=m"(before), "=m"(after) : : "t0");
    return 1;
}
