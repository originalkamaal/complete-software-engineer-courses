# file: project/cache_lat.py
"""Chapter 7 project: give loads a realistic latency from a small cache, and measure how much
an out-of-order core hides it compared with an in-order one."""
import os
import pickle
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../model"))
from ooo import simulate, Bimodal

class DirectMapped:
    """A direct-mapped cache: `lines` lines of `line_bytes`; hit and miss latencies in cycles."""
    def __init__(self, lines=64, line_bytes=16, hit=3, miss=40):
        self.tags = [None] * lines
        self.lines, self.line_bytes, self.hit, self.miss = lines, line_bytes, hit, miss
        self.hits = self.misses = 0
    def latency(self, addr):
        block = addr // self.line_bytes
        idx, tag = block % self.lines, block // self.lines
        if self.tags[idx] == tag:
            self.hits += 1
            return self.hit
        self.tags[idx] = tag
        self.misses += 1
        return self.miss

trace = pickle.load(open(sys.argv[1], "rb"))
print(f"{'machine':30} {'cache':>18} {'IPC':>6} {'vs ideal':>9}")
for name, cfg in [("in-order, 1-wide", dict(width=1, rob_size=8, in_order=True)),
                  ("out-of-order, 4-wide, ROB 32", dict(width=4, rob_size=32)),
                  ("out-of-order, 4-wide, ROB 128", dict(width=4, rob_size=128))]:
    ideal = simulate(trace, **cfg)["ipc"]
    for lines in (64, 16, 4):
        c = DirectMapped(lines=lines)
        ipc = simulate(trace, load_latency=c.latency, **cfg)["ipc"]
        rate = c.misses / (c.hits + c.misses)
        print(f"{name:30} {lines:3d} lines, {rate:5.1%} miss {ipc:6.2f} {ipc / ideal:8.0%}")
