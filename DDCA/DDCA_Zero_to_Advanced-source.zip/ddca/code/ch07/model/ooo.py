# file: model/ooo.py
"""A trace-driven out-of-order core model: fetch, rename/dispatch into a reorder buffer,
dataflow issue to functional units, out-of-order completion, in-order commit."""
import pickle
import sys
from collections import deque

LAT = {"alu": 1, "branch": 1, "jump": 1, "load": 3, "store": 1, "other": 1}

def simulate(trace, width=1, rob_size=1, in_order=False, branches="perfect", penalty=0,
             fault_at=None, rename=True, load_latency=None):
    """branches: "perfect" (never stall), "stall" (fetch waits for every branch and jump to execute),
    or a predictor object with .predict_and_update(pc, taken, target) -> bool (True = mispredicted)."""
    n = len(trace)
    rob = deque()                      # entries: [index, ready_cycle or None, done_cycle or None]
    last_writer = {}                   # arch register -> trace index of its youngest in-flight writer
    done_at = {}                       # trace index -> cycle its result is available
    last_store = {}                    # address -> index of youngest store to it
    readers = {}                       # arch register -> indices that read it since its last write
    fetch_i, committed, cycle = 0, 0, 0
    fetch_blocked_until = 0            # cycle at which fetch may resume after a branch
    completed_not_committed_at_fault = None
    while committed < n:
        cycle += 1
        # 1. commit: in order, up to `width` per cycle, only finished instructions
        for _ in range(width):
            if not rob:
                break
            i, _, done = rob[0]
            if done is None or done > cycle:
                break
            if fault_at is not None and i == fault_at:
                completed_not_committed_at_fault = sum(1 for e in rob if e[2] is not None and e[2] <= cycle)
                return {"cycles": cycle, "committed": committed, "fault_at": i,
                        "rob_occupancy": len(rob),
                        "younger_already_executed": completed_not_committed_at_fault - 1}
            rob.popleft()
            committed += 1
        # 2. issue: oldest-first, up to `width` instructions whose operands are ready
        issued = 0
        for e in rob:
            if issued == width:
                break
            if e[2] is not None:
                continue
            i = e[0]
            stop_here = in_order                               # in-order issue: never pass a waiting instruction
            _, kind, dst, srcs, addr, taken, nxt = trace[i]
            deps = [done_at.get(p) for p in e[1]]
            if any(d is None or d > cycle for d in deps):
                if stop_here:
                    break
                continue                                   # an operand is not ready yet
            lat = load_latency(addr) if (kind == "load" and load_latency) else LAT[kind]
            e[2] = cycle + lat
            done_at[i] = e[2]
            issued += 1
            if kind in ("branch", "jump") and fetch_blocked_until == ("wait", i):
                fetch_blocked_until = e[2] + penalty
        # 3. fetch + rename + dispatch into the ROB
        for _ in range(width):
            if fetch_i >= n or len(rob) >= rob_size:
                break
            if isinstance(fetch_blocked_until, tuple) or cycle < fetch_blocked_until:
                break
            pc, kind, dst, srcs, addr, taken, nxt = trace[fetch_i]
            producers = [last_writer[s] for s in srcs if s in last_writer]   # true (RAW) dependences
            if not rename and dst:                                          # without renaming, the one
                if dst in last_writer:                                      # register name is shared:
                    producers.append(last_writer[dst])                      # WAW: wait for the old writer
                producers += readers.get(dst, [])                           # WAR: wait for older readers
            for s in srcs:
                readers.setdefault(s, []).append(fetch_i)
            if kind == "load" and addr in last_store:
                producers.append(last_store[addr])                         # memory dependence
            rob.append([fetch_i, producers, None])
            if dst:
                last_writer[dst] = fetch_i
                readers[dst] = []
            if kind == "store":
                last_store[addr] = fetch_i
            if kind in ("branch", "jump"):
                if branches == "perfect":
                    mispredicted = False
                elif branches == "stall":
                    mispredicted = True
                else:
                    mispredicted = branches.predict_and_update(pc, taken, nxt)
                if mispredicted:
                    fetch_blocked_until = ("wait", fetch_i)      # resume after it executes
                    fetch_i += 1
                    break
            fetch_i += 1
    return {"cycles": cycle, "committed": committed, "ipc": committed / cycle}

class Bimodal:
    """2-bit saturating counters indexed by PC; jumps and targets assumed predicted correctly."""
    def __init__(self, bits=10):
        self.table = [2] * (1 << bits)
        self.mask = (1 << bits) - 1
        self.misses = 0
    def predict_and_update(self, pc, taken, target):
        i = (pc >> 2) & self.mask
        guess = self.table[i] >= 2
        self.table[i] = min(3, self.table[i] + 1) if taken else max(0, self.table[i] - 1)
        miss = guess != taken
        self.misses += miss
        return miss

if __name__ == "__main__":
    trace = pickle.load(open(sys.argv[1], "rb"))
    print(f"{'machine':42} {'branches':>9} {'cycles':>9} {'IPC':>6}")
    runs = [("in-order pipeline, 1-wide", dict(width=1, rob_size=8, in_order=True)),
            ("out-of-order, 1-wide, ROB 8", dict(width=1, rob_size=8)),
            ("in-order, 4-wide, ROB 32", dict(width=4, rob_size=32, in_order=True)),
            ("out-of-order, 4-wide, ROB 32", dict(width=4, rob_size=32)),
            ("out-of-order, 4-wide, ROB 128", dict(width=4, rob_size=128)),
            ("out-of-order, 8-wide, ROB 256", dict(width=8, rob_size=256))]
    for name, cfg in runs:
        for br in ("perfect", "stall", "bimodal"):
            b = Bimodal() if br == "bimodal" else br
            res = simulate(trace, branches=b, penalty=10 if br == "bimodal" else 0, **cfg)
            print(f"{name:42} {br:>9} {res['cycles']:9d} {res['ipc']:6.2f}")
