# file: model/fault.py
"""Inject a fault into one instruction and show what the ROB guarantees at that moment."""
import pickle
import sys
from ooo import simulate

t = pickle.load(open(sys.argv[1], "rb"))
r = simulate(t, width=4, rob_size=128, fault_at=100000)
print(f"fault at instruction {r['fault_at']}: committed {r['committed']}, ROB holds {r['rob_occupancy']},"
      f" younger instructions already executed: {r['younger_already_executed']}")
