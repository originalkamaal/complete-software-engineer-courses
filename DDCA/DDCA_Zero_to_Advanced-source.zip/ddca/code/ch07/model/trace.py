# file: model/trace.py
"""Run a program on rvsim and record, per instruction, what an out-of-order model needs."""
import os
import pickle
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../ch04/rvsim"))
from rvsim import CPU

def classify(w):
    op = w & 0x7F
    return {0x03: "load", 0x23: "store", 0x63: "branch", 0x6F: "jump", 0x67: "jump",
            0x33: "alu", 0x13: "alu", 0x37: "alu", 0x17: "alu"}.get(op, "other")

def record(elf):
    cpu = CPU()
    cpu.load_elf(elf)
    out = []
    while cpu.exit_code is None:
        pc = cpu.pc
        w = cpu.ld(pc, 4, False)
        kind = classify(w)
        rd, rs1, rs2 = w >> 7 & 31, w >> 15 & 31, w >> 20 & 31
        op = w & 0x7F
        srcs = []
        if op not in (0x37, 0x17, 0x6F):                 # lui, auipc, jal read no register
            srcs.append(rs1)
        if op in (0x33, 0x23, 0x63):                     # R-type, store, branch read rs2
            srcs.append(rs2)
        dst = rd if op not in (0x23, 0x63, 0x73) else 0
        addr = None
        if kind in ("load", "store"):
            imm = (w >> 20) if kind == "load" else ((w >> 25) << 5 | (w >> 7 & 31))
            imm = imm - 4096 if imm & 0x800 else imm
            addr = (cpu.x[rs1] + imm) & 0xFFFFFFFF
        cpu.step()
        taken = cpu.pc != pc + 4
        out.append((pc, kind, dst, tuple(s for s in srcs if s), addr, taken, cpu.pc))
    return out

if __name__ == "__main__":
    t = record(sys.argv[1])
    pickle.dump(t, open(sys.argv[2], "wb"))
    kinds = {}
    for x in t:
        kinds[x[1]] = kinds.get(x[1], 0) + 1
    print(f"{len(t)} instructions:", ", ".join(f"{k} {v}" for k, v in sorted(kinds.items())))
