# file: model/rename.py
import pickle
import sys
from ooo import simulate

t = pickle.load(open(sys.argv[1], "rb"))
for on in (True, False):
    ipc = simulate(t, width=4, rob_size=128, rename=on)["ipc"]
    print(f"4-wide, ROB 128, renaming {'on ' if on else 'off'}: IPC {ipc:.2f}")
