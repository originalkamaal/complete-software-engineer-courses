// file: host/falseshare.c
// Two threads each increment their own counter 100 million times. The counters are either
// adjacent (same 64-byte cache line) or 64 bytes apart. No data is shared — only a line.
// Plain increments (load, add, store) and atomic ones (lock add) are both measured.
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <time.h>

#define N 100000000
static struct { volatile long a; volatile long b; } near_;                         // same line
static struct { volatile long a; char pad[56]; volatile long b; } far_ __attribute__((aligned(64)));
static volatile long *ca, *cb;
static int atomic_ops;

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }
static void inc(volatile long *c) {
    if (atomic_ops)
        for (long i = 0; i < N; i++) atomic_fetch_add_explicit((_Atomic long *)c, 1, memory_order_relaxed);
    else
        for (long i = 0; i < N; i++) (*c)++;
}
static void *inc_a(void *p) { inc(ca); return p; }
static void *inc_b(void *p) { inc(cb); return p; }

static void run(const char *what, volatile long *a, volatile long *b, int threads) {
    ca = a; cb = b;
    pthread_t t1, t2;
    double t = now();
    pthread_create(&t1, NULL, inc_a, NULL);
    if (threads == 2) pthread_create(&t2, NULL, inc_b, NULL);
    pthread_join(t1, NULL);
    if (threads == 2) pthread_join(t2, NULL);
    printf("%-8s %-36s %5.2f s\n", atomic_ops ? "atomic" : "plain", what, now() - t);
}

int main(void) {
    for (atomic_ops = 0; atomic_ops <= 1; atomic_ops++) {
        run("one thread, one counter", &far_.a, &far_.b, 1);
        run("two threads, counters 64 bytes apart", &far_.a, &far_.b, 2);
        run("two threads, counters in one line", &near_.a, &near_.b, 2);
    }
    return 0;
}
