// file: host/sb.c
// The "store buffering" litmus test. Thread 0: x = 1; r0 = y.  Thread 1: y = 1; r1 = x.
// Under sequential consistency at least one thread must see the other's store, so r0 = r1 = 0
// is impossible. On x86 (TSO) each store can wait in a store buffer while the later load runs.
// Each round uses fresh variables; the two threads meet at a spin barrier before each round.
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>

#define ROUNDS 200000
typedef struct { _Alignas(64) volatile int v; } padded;   // one variable per cache line
static padded *x, *y;
static int r0[ROUNDS], r1[ROUNDS];
static atomic_int arrived;
static int fence;

static void barrier(int round) {                           // both threads wait for each other
    atomic_fetch_add(&arrived, 1);
    while (atomic_load(&arrived) < 2 * (round + 1)) ;
}
static void *t0(void *a) {
    for (int i = 0; i < ROUNDS; i++) {
        barrier(i);
        x[i].v = 1;
        if (fence) atomic_thread_fence(memory_order_seq_cst);   // mfence on x86
        r0[i] = y[i].v;
    }
    return a;
}
static void *t1(void *a) {
    for (int i = 0; i < ROUNDS; i++) {
        barrier(i);
        y[i].v = 1;
        if (fence) atomic_thread_fence(memory_order_seq_cst);
        r1[i] = x[i].v;
    }
    return a;
}

int main(void) {
    x = aligned_alloc(64, ROUNDS * sizeof *x);
    y = aligned_alloc(64, ROUNDS * sizeof *y);
    for (fence = 0; fence <= 1; fence++) {
        for (int i = 0; i < ROUNDS; i++) x[i].v = y[i].v = 0;
        atomic_store(&arrived, 0);
        pthread_t a, b;
        pthread_create(&a, NULL, t0, NULL);
        pthread_create(&b, NULL, t1, NULL);
        pthread_join(a, NULL); pthread_join(b, NULL);
        long both_zero = 0;
        for (int i = 0; i < ROUNDS; i++) both_zero += (r0[i] == 0 && r1[i] == 0);
        printf("%s: r0 = r1 = 0 in %ld of %d rounds\n", fence ? "with a fence " : "without fence", both_zero, ROUNDS);
    }
    return 0;
}
