# file: coh/mesi.py
"""A snooping cache-coherence simulator: private caches on a shared bus, with the MSI or MESI
protocol. Counts bus transactions — the cost of coherence."""
from collections import Counter

class System:
    def __init__(self, cores, protocol="MESI"):
        self.n, self.protocol = cores, protocol
        self.state = [dict() for _ in range(cores)]        # line -> 'M', 'E', 'S' (absent = I)
        self.bus = Counter()

    def _others(self, core, line):
        return [c for c in range(self.n) if c != core and line in self.state[c]]

    def read(self, core, line):
        st = self.state[core]
        if line in st:
            return                                         # hit in M, E or S: no bus traffic
        others = self._others(core, line)
        self.bus["BusRd"] += 1
        for c in others:
            if self.state[c][line] == "M":
                self.bus["flush"] += 1                     # owner supplies the dirty line
            self.state[c][line] = "S"
        st[line] = "S" if others or self.protocol == "MSI" else "E"

    def write(self, core, line):
        st = self.state[core]
        s = st.get(line)
        if s == "M":
            return
        if s == "E":
            st[line] = "M"                                 # silent upgrade: nobody else has it
            return
        others = self._others(core, line)
        if s == "S":
            self.bus["BusUpgr"] += 1                       # invalidate the other copies
        else:
            self.bus["BusRdX"] += 1                        # read for ownership
            if any(self.state[c][line] == "M" for c in others):
                self.bus["flush"] += 1
        self.bus["invalidations"] += len(others)
        for c in others:
            del self.state[c][line]
        st[line] = "M"

    def total(self):
        return self.bus["BusRd"] + self.bus["BusRdX"] + self.bus["BusUpgr"]
