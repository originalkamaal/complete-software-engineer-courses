# file: coh/patterns.py
from mesi import System

def private(s):                     # each core reads then writes its own 100 lines, 10 times
    for _ in range(10):
        for c in range(s.n):
            for l in range(100):
                s.read(c, (c, l)); s.write(c, (c, l))

def producer_consumer(s):           # core 0 writes 100 lines, then cores 1..3 read them; 10 rounds
    for _ in range(10):
        for l in range(100):
            s.write(0, l)
        for c in range(1, s.n):
            for l in range(100):
                s.read(c, l)

def false_sharing(s):               # four cores each update "their own" counter — in one line
    for _ in range(1000):
        for c in range(s.n):
            s.read(c, "line"); s.write(c, "line")

def read_shared(s):                 # everybody reads a shared table of 100 lines, 10 times
    for _ in range(10):
        for c in range(s.n):
            for l in range(100):
                s.read(c, ("table", l))

print(f"{'pattern (4 cores)':20} {'protocol':8} {'bus transactions':>17} {'invalidations':>14} {'cache-to-cache':>15}")
for name, f in (("private data", private), ("producer-consumer", producer_consumer),
                ("false sharing", false_sharing), ("read-only sharing", read_shared)):
    for proto in ("MSI", "MESI"):
        s = System(4, proto)
        f(s)
        print(f"{name:20} {proto:8} {s.total():17d} {s.bus['invalidations']:14d} {s.bus['flush']:15d}")
