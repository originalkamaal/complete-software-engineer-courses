# file: project/locks.py
"""Spin locks on the MESI simulator: every core wants the lock 20 times. Each simulation step,
every core performs one memory operation; we count the bus traffic per acquisition."""
import sys
sys.path.insert(0, "../coh")
from mesi import System

HOLD = 20                           # steps the critical section takes
ROUNDS = 20

def simulate(kind, cores):
    s = System(cores)
    mem = {"lock": 0, "next": 0, "serving": 0}
    state = [{"phase": "try", "left": ROUNDS, "hold": 0, "ticket": None} for _ in range(cores)]
    acquisitions = steps = 0
    while any(st["left"] for st in state):
        steps += 1
        for c, st in enumerate(state):
            if not st["left"]:
                continue
            if st["phase"] == "hold":                        # in the critical section
                st["hold"] -= 1
                if st["hold"] == 0:                           # release
                    if kind == "ticket":
                        s.write(c, "serving"); mem["serving"] += 1
                    else:
                        s.write(c, "lock"); mem["lock"] = 0
                    st["left"] -= 1
                    st["phase"] = "try"
                continue
            if kind == "TAS":                                 # test-and-set: an atomic swap every time
                s.write(c, "lock")
                got = mem["lock"] == 0
                mem["lock"] = 1
            elif kind == "TTAS":                              # test-and-test-and-set: spin on a read
                s.read(c, "lock")
                got = False
                if mem["lock"] == 0:
                    s.write(c, "lock")                        # looks free: now try the swap
                    got = mem["lock"] == 0
                    mem["lock"] = 1
            else:                                             # ticket lock: take a number, wait for it
                if st["ticket"] is None:
                    s.write(c, "next")                        # atomic fetch-and-increment
                    st["ticket"] = mem["next"]; mem["next"] += 1
                s.read(c, "serving")
                got = mem["serving"] == st["ticket"]
                if got:
                    st["ticket"] = None
            if got:
                st["phase"], st["hold"] = "hold", HOLD
                acquisitions += 1
    return s.total() / acquisitions, steps

print(f"{'lock':6} " + "".join(f"{f'{n} cores':>16}" for n in (2, 4, 8, 16)) + "   (bus transactions per acquisition)")
for kind in ("TAS", "TTAS", "ticket"):
    print(f"{kind:6} " + "".join(f"{simulate(kind, n)[0]:16.1f}" for n in (2, 4, 8, 16)))
