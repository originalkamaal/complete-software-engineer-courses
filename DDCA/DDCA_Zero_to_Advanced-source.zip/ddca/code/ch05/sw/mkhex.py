# file: sw/mkhex.py
"""Write a flat binary image as 32-bit little-endian words, one hex word per line (for $readmemh)."""
import sys
data = open(sys.argv[1], "rb").read()
data += bytes(-len(data) % 4)
with open(sys.argv[2], "w") as f:
    for i in range(0, len(data), 4):
        f.write(f"{int.from_bytes(data[i:i + 4], 'little'):08x}\n")
print(f"{sys.argv[2]}: {len(data) // 4} words")
