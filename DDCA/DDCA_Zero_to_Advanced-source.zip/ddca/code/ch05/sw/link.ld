/* file: sw/link.ld */
ENTRY(_start)
SECTIONS {
  . = 0;
  .text   : { *(.text._start) *(.text*) }
  .rodata : { *(.rodata*) *(.srodata*) }
  .data   : { *(.data*) }
  __global_pointer$ = . + 0x800;
  .sdata  : { *(.sdata*) }
  .bss    : { *(.sbss*) *(.bss*) *(COMMON) }
  _end = .;
  /DISCARD/ : { *(.note*) *(.comment*) *(.riscv.attributes) *(.eh_frame*) }
}
