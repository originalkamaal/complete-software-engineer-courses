# file: project/rvsim_m.py
"""rvsim with the RV32M extension: the golden model for sc_cpu with M_EXT = 1."""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../ch04/rvsim"))
from rvsim import CPU, sext, MASK

def tdiv(a, b):                       # signed division rounding toward zero, as RISC-V requires
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q

class CPUM(CPU):
    def step(self):
        w = self.ld(self.pc, 4, False)
        if w & 0x7F != 0x33 or w >> 25 != 1:
            return super().step()                               # not an M instruction
        rd, f3 = w >> 7 & 31, w >> 12 & 7
        a, b = self.x[w >> 15 & 31], self.x[w >> 20 & 31]
        sa, sb = sext(a, 32), sext(b, 32)
        if f3 == 0:   v = a * b
        elif f3 == 1: v = (sa * sb) >> 32
        elif f3 == 2: v = (sa * b) >> 32
        elif f3 == 3: v = (a * b) >> 32
        elif f3 == 4: v = -1 if b == 0 else (sa if (sa == -2**31 and sb == -1) else tdiv(sa, sb))
        elif f3 == 5: v = MASK if b == 0 else a // b
        elif f3 == 6: v = sa if b == 0 else (0 if (sa == -2**31 and sb == -1) else sa - tdiv(sa, sb) * sb)
        else:         v = a if b == 0 else a % b
        if rd:
            self.x[rd] = v & MASK
        self.pc = (self.pc + 4) & MASK
        self.count += 1

if __name__ == "__main__":
    cpu = CPUM()
    cpu.load_elf(sys.argv[1])
    code = cpu.run()
    sys.stdout.write(cpu.out.decode(errors="replace"))
    print(f"[rvsim_m: {cpu.count} instructions, exit {code}]", file=sys.stderr)
    sys.exit(code)
