// file: project/mtest.c
// Multiply/divide workload. Built two ways: -march=rv32im (hardware M) and with -DSOFT for rv32i.
#include "rt.h"

#ifdef SOFT
static unsigned umul(unsigned a, unsigned b) { unsigned r = 0; while (b) { if (b & 1) r += a; a <<= 1; b >>= 1; } return r; }
#define MUL(a, b) umul((a), (b))
#else
#define MUL(a, b) ((unsigned)(a) * (unsigned)(b))
#endif

static unsigned matmul_checksum(void) {             // 12x12 integer matrix product
    enum { N = 12 };
    static unsigned A[N][N], B[N][N], C[N][N];
    unsigned seed = 12345;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            seed = MUL(seed, 1103515245u) + 12345u; A[i][j] = seed >> 20;
            seed = MUL(seed, 1103515245u) + 12345u; B[i][j] = seed >> 20;
        }
    unsigned sum = 0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            unsigned s = 0;
            for (int k = 0; k < N; k++) s += MUL(A[i][k], B[k][j]);
            C[i][j] = s;
            sum ^= s + (unsigned)i;
        }
    return sum;
}

int main(void) {
    puts_("matmul checksum: "); putint((int)matmul_checksum()); puts_("\n");
#ifndef SOFT
    volatile int x = 7, y = -2, z = 0, m = (int)0x80000000, n1 = -1;   // volatile: computed at run time
    puts_("7/-2 = "); putint(x / y); puts_(", 7%-2 = "); putint(x % y);
    puts_(", -7/2 = "); putint(-x / -y); puts_(", -7%2 = "); putint(-x % -y); puts_("\n");
    puts_("7/0 = "); putint(x / z); puts_(", 7%0 = "); putint(x % z); puts_("\n");
    puts_("INT_MIN/-1 = "); putint(m / n1); puts_(", INT_MIN%-1 = "); putint(m % n1); puts_("\n");
    volatile unsigned u = 0xFFFFFFFFu;
    puts_("mulhu(0xFFFFFFFF, 0xFFFFFFFF) = "); putint((int)(((unsigned long long)u * u) >> 32)); puts_("\n");
#endif
    return 0;
}
