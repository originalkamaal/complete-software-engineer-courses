// file: host/mlp.c
// Memory-level parallelism: follow K independent random pointer chains at once through 1 GiB.
// One chain waits for each DRAM access in turn; several chains keep several banks busy.
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <time.h>

#define SIZE (1UL << 30)
#define LINE 64
#define NLINES (SIZE / LINE)
#define STEPS 4000000

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

int main(void) {
    char *buf = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    madvise(buf, SIZE, MADV_HUGEPAGE);                         // keep TLB misses out of the picture
    size_t *perm = malloc(NLINES * sizeof *perm);
    for (size_t i = 0; i < NLINES; i++) perm[i] = i;
    srand(2);
    for (size_t i = NLINES - 1; i > 0; i--) {
        size_t j = ((size_t)rand() << 31 | rand()) % (i + 1);
        size_t t = perm[i]; perm[i] = perm[j]; perm[j] = t;
    }
    for (size_t i = 0; i < NLINES; i++)                        // one random cycle through all lines
        *(char **)(buf + perm[i] * LINE) = buf + perm[(i + 1) % NLINES] * LINE;

    for (int k = 1; k <= 16; k *= 2) {
        char *p[16];
        for (int c = 0; c < k; c++) p[c] = buf + perm[c * (NLINES / 16)] * LINE;   // far-apart starts
        double t = now();
        for (int s = 0; s < STEPS / k; s++)
            for (int c = 0; c < k; c++) p[c] = *(char **)p[c];
        t = now() - t;
        size_t sum = 0;
        for (int c = 0; c < k; c++) sum += (size_t)p[c] & 1;
        printf("%2d chains: %6.1f ns per load, %5.2f GB/s of 64-byte lines%s\n", k, t / STEPS * 1e9,
               STEPS * 64.0 / t / 1e9, sum == 99 ? "!" : "");
    }
    return 0;
}
