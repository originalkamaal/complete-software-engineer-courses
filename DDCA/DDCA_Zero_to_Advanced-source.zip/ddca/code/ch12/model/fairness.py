# file: model/fairness.py
"""Two programs share one memory: a streaming 'hog' with high row-buffer locality and a program
with random accesses. Slowdown = throughput alone / throughput when sharing."""
from dram import *

def make_stream():
    state = {"i": 0}
    def gen(rng):
        state["i"] += 1
        return state["i"] // 1024 % 8, state["i"] // 128          # long runs of hits, moving across banks
    return gen

def rand_gen(rng):
    return rng.randrange(8), rng.randrange(65536)

def cores():
    return [Core(0, make_stream(), mlp=8, think=0), Core(1, rand_gen, mlp=2, think=20)]

def compare(policies):
    alone = []
    for i in range(2):
        c = cores()[i]
        simulate([c], fr_fcfs, until=100_000)
        alone.append(c.done)
    print(f"{'scheduler':10} {'stream slowdown':>16} {'random slowdown':>16} {'unfairness':>11} {'total requests':>15}")
    for name, policy in policies:
        cs = cores()
        simulate(cs, policy, until=100_000)
        sd = [alone[i] / cs[i].done for i in range(2)]
        print(f"{name:10} {sd[0]:16.2f} {sd[1]:16.2f} {max(sd) / min(sd):11.2f} {cs[0].done + cs[1].done:15d}")

if __name__ == "__main__":
    compare([("FCFS", fcfs), ("FR-FCFS", fr_fcfs)])
