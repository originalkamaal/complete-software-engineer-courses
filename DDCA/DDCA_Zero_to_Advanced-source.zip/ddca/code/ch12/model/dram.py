# file: model/dram.py
"""A DRAM timing model: banks with row buffers, the three access cases (hit, empty, conflict),
and a memory controller with a pluggable scheduling policy, driven by closed-loop cores."""
import random

T_RCD, T_CL, T_RP, T_BURST = 14, 14, 14, 4        # nanoseconds, roughly DDR4-3200 22-22-22

class Bank:
    def __init__(self):
        self.open_row, self.free_at = None, 0

class Core:
    """Keeps `mlp` requests in flight; after each completes, computes for `think` ns, then issues another."""
    def __init__(self, cid, gen, mlp, think):
        self.cid, self.gen, self.mlp, self.think = cid, gen, mlp, think
        self.done = 0
        self.latency = 0

def simulate(cores, policy, banks=8, until=200_000, open_page=True, seed=1):
    rng = random.Random(seed)
    bank = [Bank() for _ in range(banks)]
    queue = []                                     # (arrival, core, bank, row, seq)
    seq = 0
    pending_issue = []                             # (time, core) when a core will issue
    for c in cores:
        for _ in range(c.mlp):
            pending_issue.append((0, c))
    bus_free = 0
    t = 0
    stats = {"hit": 0, "empty": 0, "conflict": 0}
    while t < until:
        for item in [p for p in pending_issue if p[0] <= t]:
            pending_issue.remove(item)
            b, r = item[1].gen(rng)
            queue.append((t, item[1], b, r, seq)); seq += 1
        ready = [q for q in queue if bank[q[2]].free_at <= t]
        if ready and bus_free <= t:
            q = policy(ready, bank, t)
            queue.remove(q)
            arr, core, b, r, _ = q
            bk = bank[b]
            if bk.open_row == r:
                lat, kind = T_CL, "hit"
            elif bk.open_row is None:
                lat, kind = T_RCD + T_CL, "empty"
            else:
                lat, kind = T_RP + T_RCD + T_CL, "conflict"
            stats[kind] += 1
            finish = t + lat + T_BURST
            row_time = lat - T_CL                          # precharge and activate, if needed
            bk.free_at = t + row_time + T_BURST            # next column command to this bank
            if open_page:
                bk.open_row = r                            # leave the row open for future hits
            else:
                bk.open_row = None                         # close it now: precharge after the access
                bk.free_at += T_CL + T_RP
            bus_free = t + T_BURST                         # one burst per slot on the shared bus
            core.done += 1
            core.latency += finish - arr
            pending_issue.append((finish + core.think, core))
        t += 1
    return stats

# --- scheduling policies: choose one of the requests whose bank is free ---
def fcfs(ready, bank, t):
    return min(ready, key=lambda q: q[4])                      # oldest first

def fr_fcfs(ready, bank, t):
    hits = [q for q in ready if bank[q[2]].open_row == q[3]]   # row hits first, then oldest
    return min(hits or ready, key=lambda q: q[4])
