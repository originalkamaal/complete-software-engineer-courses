# file: model/rowhammer.py
"""RowHammer: activating a DRAM row many times disturbs its physical neighbours; if a neighbour
is not refreshed before it has seen HC_FIRST nearby activations, its cells flip. This model runs one
64 ms refresh window of activations on one bank and counts victim rows that flip, with and without
mitigations."""
import random

ROWS = 1024
HC_FIRST = 10_000          # activations of adjacent rows before the first flip (modern DDR4: ~10K)
ACTS = 1_360_000           # one 64 ms window at one activation every 47 ns
REFS = 8192                # regular refresh commands per window (one every 7.8 us)

def run(pattern, mitigation, seed=1):
    rng = random.Random(seed)
    disturb = [0] * ROWS
    flipped = set()
    tracker = []           # TRR's small table of [row, count]
    acts_per_ref = ACTS // REFS
    refresh = lambda r: disturb.__setitem__(r, 0) if 0 <= r < ROWS else None
    for i in range(ACTS):
        row = pattern(i, rng)
        for v in (row - 1, row + 1):                      # charge leaks from both neighbours
            if 0 <= v < ROWS:
                disturb[v] += 1
                if disturb[v] >= HC_FIRST:
                    flipped.add(v)
        if mitigation[0] == "para" and rng.random() < mitigation[1]:
            refresh(row + rng.choice((-1, 1)))           # PARA: probabilistic adjacent row activation
        if mitigation[0] == "trr":
            for e in tracker:
                if e[0] == row:
                    e[1] += 1
                    break
            else:
                if len(tracker) == mitigation[1]:
                    tracker.pop(0)                        # table full: forget the oldest entry
                tracker.append([row, 1])
        if i % acts_per_ref == acts_per_ref - 1:          # a regular refresh command
            r = (i // acts_per_ref) * ROWS // REFS        # refreshes rows in turn, each once per window
            refresh(r)
            if mitigation[0] == "trr" and tracker:        # TRR: also refresh the top aggressor's neighbours
                top = max(tracker, key=lambda e: e[1])
                refresh(top[0] - 1); refresh(top[0] + 1)
                tracker.remove(top)
    return len(flipped)

patterns = {
    "normal program (random rows)": lambda i, rng: rng.randrange(ROWS),
    "single-sided (row 100 + far row)": lambda i, rng: (100, 700)[i % 2],
    "double-sided (rows 100 and 102)": lambda i, rng: (100, 102)[i % 2],
    "many-sided, 10 aggressor pairs": lambda i, rng: 100 + 2 * (i % 20),
    "double-sided + 4 decoy rows": lambda i, rng: (100, 102, 500, 500, 600, 600, 700, 700, 800, 800)[i % 10],
}
mitigations = [("none", 0), ("para", 0.0005), ("para", 0.005), ("trr", 4)]
names = ["none", "PARA p=0.0005", "PARA p=0.005", "TRR, 4 entries"]
print(f"{'access pattern':34}" + "".join(f"{n:>16}" for n in names) + "   (victim rows that flip)")
for pname, pat in patterns.items():
    print(f"{pname:34}" + "".join(f"{run(pat, m):16d}" for m in mitigations))
