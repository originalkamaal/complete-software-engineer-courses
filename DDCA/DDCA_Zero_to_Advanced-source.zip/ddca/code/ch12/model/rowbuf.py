# file: model/rowbuf.py
"""Row-buffer locality and bank-level parallelism: one core, different access patterns."""
from dram import *

def streaming():
    state = {"i": 0}
    def gen(rng):
        state["i"] += 1
        return 0, state["i"] // 128                 # 128 consecutive blocks per 8 KiB row, one bank
    return gen

def random_one_bank(rng):
    return 0, rng.randrange(65536)

def random_all_banks(rng):
    return rng.randrange(8), rng.randrange(65536)

print(f"{'pattern':34} {'policy':6} {'requests/us':>11} {'avg latency':>12}   hits / empty / conflicts")
for name, gen, mlp in (("streaming, one bank", streaming(), 4),
                       ("random rows, one bank", random_one_bank, 4),
                       ("random rows, 8 banks", random_all_banks, 4),
                       ("random rows, 8 banks, 1 in flight", random_all_banks, 1)):
    for open_page in (True, False):
        c = Core(0, gen, mlp, think=0)
        s = simulate([c], fr_fcfs, open_page=open_page, until=100_000)
        print(f"{name:34} {'open' if open_page else 'closed':6} {c.done / 100:11.1f} "
              f"{c.latency / c.done:9.1f} ns   {s['hit']} / {s['empty']} / {s['conflict']}")
