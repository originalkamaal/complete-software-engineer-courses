# file: project/bliss.py
"""BLISS: the Blacklisting memory scheduler (Subramanian et al., ICCD 2014)."""
import sys
sys.path.insert(0, "../model")
from dram import fcfs, fr_fcfs
from fairness import compare

class Bliss:
    """Blacklisting (Subramanian et al., ICCD 2014): a core served `limit` times in a row is
    deprioritised for a while; otherwise FR-FCFS."""
    def __init__(self, limit=4, clear=10_000):
        self.limit, self.clear = limit, clear
        self.last, self.streak, self.black, self.cleared_at = None, 0, set(), 0
    def __call__(self, ready, bank, t):
        if t - self.cleared_at >= self.clear:
            self.black.clear(); self.cleared_at = t
        good = [q for q in ready if q[1].cid not in self.black] or ready
        q = fr_fcfs(good, bank, t)
        self.streak = self.streak + 1 if q[1].cid == self.last else 1
        self.last = q[1].cid
        if self.streak >= self.limit:
            self.black.add(q[1].cid)
        return q

compare([("FCFS", fcfs), ("FR-FCFS", fr_fcfs), ("BLISS", Bliss())])
for limit in (2, 8, 32):
    compare([(f"BLISS {limit}", Bliss(limit=limit))])
