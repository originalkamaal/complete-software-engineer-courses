# file: project/make_pipe_bp.py
"""Derive pipe_bp.v from Chapter 6's pipe_cpu.v: predict branches and jumps in IF with a
64-entry branch target buffer and a 256-entry table of 2-bit counters, check in EX."""
import sys

src, dst = sys.argv[1], sys.argv[2]
v = open(src).read()

def edit(old, new):
    global v
    assert v.count(old) == 1, f"edit target not found exactly once: {old[:60]!r}"
    v = v.replace(old, new)

edit("module pipe_cpu", "module pipe_bp")
edit('$display("[pipe_cpu FORWARD=%0d', '$display("[pipe_bp FORWARD=%0d')

# 1. Predictor state and the prediction in IF.
edit("""    always @(posedge clk)
        if (rst) pc <= 0;
        else if (redirect) pc <= redirect_pc;
        else if (!stall) pc <= pc + 4;""",
"""    reg        btb_valid [0:63];
    reg [23:0] btb_tag   [0:63];
    reg [31:0] btb_target[0:63];
    reg        btb_cond  [0:63];                          // conditional branch (consult the counter)?
    reg [1:0]  bht       [0:255];
    integer p;
    initial for (p = 0; p < 256; p = p + 1) begin bht[p] = 2'd1; if (p < 64) btb_valid[p] = 0; end
    wire [5:0] bi = pc[7:2];
    wire btb_hit = btb_valid[bi] && btb_tag[bi] == pc[31:8];
    wire f_pred = btb_hit && (!btb_cond[bi] || bht[pc[9:2]][1]);   // predicted taken?
    wire [31:0] f_next = f_pred ? btb_target[bi] : pc + 4;
    always @(posedge clk)
        if (rst) pc <= 0;
        else if (redirect) pc <= redirect_pc;
        else if (!stall) pc <= f_next;""")

# 2. The prediction travels with the instruction.
edit("""    reg [31:0] d_instr, d_pc;                             // IF/ID pipeline register""",
"""    reg [31:0] d_instr, d_pc, d_pnext;                    // IF/ID pipeline register (+ predicted next PC)""")
edit("""        else if (!stall) begin d_instr <= mem[pc[31:2]]; d_pc <= pc; end""",
"""        else if (!stall) begin d_instr <= mem[pc[31:2]]; d_pc <= pc; d_pnext <= f_next; end""")
edit("""    reg [31:0] e_instr, e_pc, e_a, e_b;                   // ID/EX pipeline register""",
"""    reg [31:0] e_instr, e_pc, e_a, e_b, e_pnext;          // ID/EX pipeline register""")
edit("""            e_instr <= d_instr; e_pc <= d_pc; e_a <= d_a; e_b <= d_b;""",
"""            e_instr <= d_instr; e_pc <= d_pc; e_a <= d_a; e_b <= d_b; e_pnext <= d_pnext;""")

# 3. EX checks the prediction: redirect only when the predicted next PC was wrong.
edit("""    assign redirect = (is_br && take) || is_jal || is_jalr;
    assign redirect_pc = is_jalr ? ((fa + immI) & ~32'd1) : e_pc + (is_jal ? immJ : immB);""",
"""    wire ctrl = is_br || is_jal || is_jalr;
    wire [31:0] actual_next = is_jalr ? ((fa + immI) & ~32'd1) :
                              (is_jal || (is_br && take)) ? e_pc + (is_jal ? immJ : immB) : e_pc + 4;
    assign redirect = (e_instr != NOP) && (ctrl ? (actual_next != e_pnext) : (e_pnext != e_pc + 4));
    assign redirect_pc = actual_next;
    always @(posedge clk) if (!rst && ctrl) begin           // train the predictor
        if (is_br) bht[e_pc[9:2]] <= take ? (bht[e_pc[9:2]] == 3 ? 3 : bht[e_pc[9:2]] + 1)
                                          : (bht[e_pc[9:2]] == 0 ? 0 : bht[e_pc[9:2]] - 1);
        if (actual_next != e_pc + 4) begin                  // taken: remember the target
            btb_valid[e_pc[7:2]] <= 1; btb_tag[e_pc[7:2]] <= e_pc[31:8];
            btb_target[e_pc[7:2]] <= actual_next; btb_cond[e_pc[7:2]] <= is_br;
        end
    end""")
edit("""                $display("[stall cycles %0d, redirects %0d (each flushes 2 instructions)]", stalls, flushes);""",
"""                $display("[stall cycles %0d, mispredictions %0d (each flushes 2 instructions)]", stalls, flushes);""")
open(dst, "w").write(v)
print(f"wrote {dst}")
