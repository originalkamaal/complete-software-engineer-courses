// file: progs/bench.c
// Kernels with different branch behaviour; the predictor study attributes each branch to its function.
#include "rt.h"
#include "data.h"

#define NOINLINE __attribute__((noipa))   /* no inlining, no interprocedural shortcuts */
#define KEEP __asm__ volatile("")             /* keeps an if as a real branch (Chapter 0, Unit 0.2) */
static unsigned seed;
static unsigned rnd(void) { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return seed; }   // xorshift32

#define N 400
static int a[N];

#define SUM_BIG(s) do {                       /* the branch from Chapter 0's sorted/random experiment */ \
        for (int rep = 0; rep < 5; rep++)                                                           \
            for (int i = 0; i < N; i++)                                                             \
                if (a[i] >= 128) { s += a[i]; KEEP; }                                               \
    } while (0)
static NOINLINE int threshold_random(void) {
    for (int i = 0; i < N; i++) a[i] = DATA[i];
    int s = 0;
    SUM_BIG(s);
    return s;
}
static NOINLINE int threshold_sorted(void) {
    for (int i = 0; i < N; i++) a[i] = DATA[i];
    for (int i = 1; i < N; i++) { int v = a[i], j = i - 1; while (j >= 0 && a[j] > v) { a[j + 1] = a[j]; j--; } a[j + 1] = v; }
    int s = 0;
    SUM_BIG(s);
    return s;
}
static NOINLINE int pattern(void) {           // a branch with a period-3 pattern: taken, taken, not taken
    int s = 0, m = 0;
    for (int i = 0; i < 6000; i++) {
        if (m != 2) { s += i; KEEP; } else s -= 1;
        if (++m == 3) m = 0;
    }
    return s;
}
static NOINLINE int correlated(void) {        // the second branch is decided by the first
    int s = 0;
    seed = 7;
    for (int i = 0; i < 4000; i++) {
        int x = rnd() & 1, y = x;
        __asm__ volatile("" : "+r"(y));       // hide that y == x, so GCC keeps two separate branches
        if (x) { s += 3; KEEP; }              // random: unpredictable on its own
        if (!y) { s += 5; KEEP; }             // predictable only from the previous branch's outcome
    }
    return s;
}
static NOINLINE int bsearch_(int key) {
    int lo = 0, hi = N - 1;
    while (lo <= hi) { int mid = (lo + hi) >> 1; if (a[mid] < key) lo = mid + 1; else if (a[mid] > key) hi = mid - 1; else return mid; }
    return -1;
}
static NOINLINE int search(void) {
    for (int i = 0; i < N; i++) a[i] = 3 * i;
    int found = 0;
    seed = 3;
    for (int k = 0; k < 1500; k++) found += bsearch_(rnd() & 1023) >= 0;
    return found;
}
static NOINLINE int depth(int n) {
    __asm__ volatile("" : "+r"(n));       // GCC can otherwise prove depth(n) == n and delete the recursion
    if (n == 0) return 0;
    return 1 + depth(n - 1);
}
static NOINLINE int calls(void) { int s = 0, d = 0; for (int i = 0; i < 200; i++) { s += depth(d); if (++d == 23) d = 0; } return s; }

int main(void) {
    puts_("threshold random "); putint(threshold_random()); puts_("\n");
    puts_("threshold sorted "); putint(threshold_sorted()); puts_("\n");
    puts_("pattern "); putint(pattern()); puts_("\n");
    puts_("correlated "); putint(correlated()); puts_("\n");
    puts_("search "); putint(search()); puts_("\n");
    puts_("calls "); putint(calls()); puts_("\n");
    return 0;
}
