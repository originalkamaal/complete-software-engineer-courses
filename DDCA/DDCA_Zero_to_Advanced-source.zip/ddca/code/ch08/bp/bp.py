# file: bp/bp.py
"""Branch predictor study: run a program on rvsim, collect every control-transfer instruction,
and replay the stream through several direction predictors and target predictors."""
import os
import subprocess
import sys
from bisect import bisect_right
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../ch04/rvsim"))
from rvsim import CPU

def collect(elf):
    cpu = CPU()
    cpu.load_elf(elf)
    events = []                            # (pc, kind, taken, target)
    while cpu.exit_code is None:
        pc = cpu.pc
        w = cpu.ld(pc, 4, False)
        op, rd, rs1 = w & 0x7F, w >> 7 & 31, w >> 15 & 31
        cpu.step()
        if op == 0x63:
            events.append((pc, "cond", cpu.pc != pc + 4, cpu.pc))
        elif op == 0x6F:
            events.append((pc, "call" if rd == 1 else "jump", True, cpu.pc))
        elif op == 0x67:
            kind = "ret" if (rd == 0 and rs1 == 1) else ("icall" if rd == 1 else "ijump")
            events.append((pc, kind, True, cpu.pc))
    return events, cpu.count

def functions(elf):
    out = subprocess.run(["riscv64-linux-gnu-nm", "-n", elf], capture_output=True, text=True).stdout
    syms = [(int(a, 16), n) for a, t, n in (l.split() for l in out.splitlines() if len(l.split()) == 3) if t in "tT"]
    return [a for a, _ in syms], [n for _, n in syms]

# ---------------- direction predictors: predict(pc) -> bool, then update(pc, taken) ----------------
class Static:
    def __init__(self, rule): self.rule = rule
    def predict(self, pc, target): return self.rule(pc, target)
    def update(self, pc, taken): pass

class Bimodal:
    def __init__(self, bits=12):
        self.t, self.m = [1] * (1 << bits), (1 << bits) - 1      # 2-bit counters, start weakly not-taken
    def predict(self, pc, target): return self.t[(pc >> 2) & self.m] >= 2
    def update(self, pc, taken):
        i = (pc >> 2) & self.m
        self.t[i] = min(3, self.t[i] + 1) if taken else max(0, self.t[i] - 1)

class GShare:
    """2-bit counters indexed by PC XOR the global history of recent branch outcomes."""
    def __init__(self, bits=12, hist=12):
        self.t, self.m, self.h, self.hm = [1] * (1 << bits), (1 << bits) - 1, 0, (1 << hist) - 1
    def idx(self, pc): return ((pc >> 2) ^ self.h) & self.m
    def predict(self, pc, target): return self.t[self.idx(pc)] >= 2
    def update(self, pc, taken):
        i = self.idx(pc)
        self.t[i] = min(3, self.t[i] + 1) if taken else max(0, self.t[i] - 1)
        self.h = ((self.h << 1) | taken) & self.hm

class Local:
    """Two-level local predictor: each branch's own recent history selects a 2-bit counter."""
    def __init__(self, bits=10, hist=10):
        self.bht, self.bm = [0] * (1 << bits), (1 << bits) - 1
        self.pht, self.hm = [1] * (1 << hist), (1 << hist) - 1
    def predict(self, pc, target): return self.pht[self.bht[(pc >> 2) & self.bm]] >= 2
    def update(self, pc, taken):
        b = (pc >> 2) & self.bm
        h = self.bht[b]
        self.pht[h] = min(3, self.pht[h] + 1) if taken else max(0, self.pht[h] - 1)
        self.bht[b] = ((h << 1) | taken) & self.hm

class Tournament:
    """A chooser of 2-bit counters picks, per branch, whichever of two predictors has been right."""
    def __init__(self, a, b, bits=12):
        self.a, self.b, self.c, self.m = a, b, [2] * (1 << bits), (1 << bits) - 1
    def predict(self, pc, target):
        self.pa, self.pb = self.a.predict(pc, target), self.b.predict(pc, target)
        return self.pb if self.c[(pc >> 2) & self.m] >= 2 else self.pa
    def update(self, pc, taken):
        i = (pc >> 2) & self.m
        if self.pa != self.pb:
            self.c[i] = min(3, self.c[i] + 1) if self.pb == taken else max(0, self.c[i] - 1)
        self.a.update(pc, taken)
        self.b.update(pc, taken)

class Perceptron:
    """Jimenez & Lin (2001): one weight vector per branch; predict taken if bias + sum(w_i * h_i) >= 0,
    where h_i is +1/-1 for the i-th most recent global outcome. Learns linear functions of long histories."""
    def __init__(self, rows=256, hist=24):
        self.w = [[0] * (hist + 1) for _ in range(rows)]
        self.rows, self.hist = rows, hist
        self.h = [1] * hist
        self.theta = int(1.93 * hist + 14)                   # training threshold from the paper
    def predict(self, pc, target):
        w = self.w[(pc >> 2) % self.rows]
        self.y = w[0] + sum(wi * hi for wi, hi in zip(w[1:], self.h))
        return self.y >= 0
    def update(self, pc, taken):
        w = self.w[(pc >> 2) % self.rows]
        t = 1 if taken else -1
        if (self.y >= 0) != taken or abs(self.y) <= self.theta:
            w[0] = max(-128, min(127, w[0] + t))
            for i in range(self.hist):
                w[i + 1] = max(-128, min(127, w[i + 1] + t * self.h[i]))
        self.h = [t] + self.h[:-1]

def run(events, pred, names_at):
    starts, names = names_at
    total, miss, per = 0, 0, {}
    for pc, kind, taken, target in events:
        if kind != "cond":
            continue
        guess = pred.predict(pc, target)
        pred.update(pc, taken)
        fn = names[bisect_right(starts, pc) - 1]
        t, m = per.get(fn, (0, 0))
        per[fn] = (t + 1, m + (guess != taken))
        total += 1
        miss += guess != taken
    return total, miss, per

if __name__ == "__main__":
    elf = sys.argv[1]
    events, ninstr = collect(elf)
    syms = functions(elf)
    kernels = ["threshold_random", "threshold_sorted", "pattern", "correlated", "bsearch_", "depth"]
    preds = [("always taken", lambda: Static(lambda pc, t: True)),
             ("BTFN", lambda: Static(lambda pc, t: t < pc)),
             ("bimodal 4K", lambda: Bimodal(12)),
             ("local 1K x 10", lambda: Local(10, 10)),
             ("gshare 4K, h12", lambda: GShare(12, 12)),
             ("tournament", lambda: Tournament(Bimodal(12), GShare(12, 12))),
             ("perceptron h24", lambda: Perceptron(256, 24))]
    print(f"{ninstr} instructions, {sum(e[1] == 'cond' for e in events)} conditional branches")
    print(f"{'predictor':16} {'MPKI':>6} " + " ".join(f"{k[:10]:>10}" for k in kernels))
    for name, make in preds:
        total, miss, per = run(events, make(), syms)
        cells = []
        for k in kernels:
            t, m = per.get(k, (0, 0))
            cells.append(f"{100 * m / t:9.1f}%" if t else f"{'-':>10}")
        print(f"{name:16} {1000 * miss / ninstr:6.2f} " + " ".join(cells))
