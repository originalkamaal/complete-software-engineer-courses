# file: bp/targets.py
"""Target prediction: a branch target buffer (last target per PC) versus a return address stack for returns."""
import sys
from bp import collect

def study(elf, btb_entries=64, ras_depth=8):
    events, n = collect(elf)
    btb = {}
    ras = []
    stats = {}
    def count(kind, ok):
        t, m = stats.get(kind, (0, 0))
        stats[kind] = (t + 1, m + (not ok))
    for pc, kind, taken, target in events:
        if not taken:
            continue                                       # a not-taken branch needs no target
        slot = (pc >> 2) % btb_entries
        entry = btb.get(slot)
        btb_ok = entry is not None and entry == (pc, target)
        if kind == "ret":
            ras_ok = bool(ras) and ras[-1] == target
            if ras:
                ras.pop()
            count("ret via BTB", btb_ok)
            count("ret via RAS", ras_ok)
        else:
            count(kind + " via BTB", btb_ok)
        if kind in ("call", "icall"):
            ras.append(pc + 4)                             # push the return address
            if len(ras) > ras_depth:
                ras.pop(0)                                 # overflow: the oldest entry is lost
        btb[slot] = (pc, target)
    return stats

if __name__ == "__main__":
    for elf in sys.argv[1:]:
        print(f"== {elf}")
        for kind, (t, m) in sorted(study(elf).items()):
            print(f"  {kind:16} {t:7d} taken transfers, {100 * m / t:5.1f}% wrong target")
