# file: project/make_pipe_id.py
"""Derive pipe_id.v from pipe_cpu.v: resolve conditional branches and jal in ID (penalty 1 cycle)."""
import sys

src, dst = sys.argv[1], sys.argv[2]
v = open(src).read()

def edit(old, new):
    global v
    assert v.count(old) == 1, f"edit target not found exactly once: {old[:60]!r}"
    v = v.replace(old, new)

edit("module pipe_cpu", "module pipe_id")
edit('$display("[pipe_cpu FORWARD=%0d', '$display("[pipe_id FORWARD=%0d')

# 1. Branch comparison and target in ID, with forwarding from EX/MEM into ID.
edit("""    reg [31:0] e_instr, e_pc, e_a, e_b;                   // ID/EX pipeline register""",
"""    wire d_is_br = d_op == 7'b1100011, d_is_jal = d_op == 7'b1101111;
    wire [31:0] d_fa = (m_we && m_rd == d_rs1 && d_rs1 != 0) ? m_val : d_a;   // forward into ID
    wire [31:0] d_fb = (m_we && m_rd == d_rs2 && d_rs2 != 0) ? m_val : d_b;
    reg d_take;
    always @(*) case (d_instr[14:12])
        3'd0: d_take = d_fa == d_fb;   3'd1: d_take = d_fa != d_fb;
        3'd4: d_take = $signed(d_fa) < $signed(d_fb);   3'd5: d_take = $signed(d_fa) >= $signed(d_fb);
        3'd6: d_take = d_fa < d_fb;    3'd7: d_take = d_fa >= d_fb;
        default: d_take = 0;
    endcase
    wire [31:0] d_immB = {{19{d_instr[31]}}, d_instr[31], d_instr[7], d_instr[30:25], d_instr[11:8], 1'b0};
    wire [31:0] d_immJ = {{11{d_instr[31]}}, d_instr[31], d_instr[19:12], d_instr[20], d_instr[30:21], 1'b0};
    wire id_redirect = !stall && ((d_is_br && d_take) || d_is_jal);
    wire [31:0] id_target = d_pc + (d_is_jal ? d_immJ : d_immB);

    reg [31:0] e_instr, e_pc, e_a, e_b;                   // ID/EX pipeline register""")

# 2. Hazards: a branch in ID needs its operands *now*.
edit("""    assign stall = FORWARD ? (e_load && hit_e)            // load-use: the value exists only after MEM
                           : (hit_e || hit_m);           // no forwarding: wait until WB writes it""",
"""    wire br_hazard = d_is_br && (hit_e || (m_load && hit_m));   // value not yet available in ID
    assign stall = (e_load && hit_e) || br_hazard;""")

# 3. Redirects: jalr still from EX (flush 2); branches and jal from ID (flush IF/ID only).
edit("""    assign redirect = (is_br && take) || is_jal || is_jalr;
    assign redirect_pc = is_jalr ? ((fa + immI) & ~32'd1) : e_pc + (is_jal ? immJ : immB);""",
"""    assign redirect = is_jalr;
    assign redirect_pc = (fa + immI) & ~32'd1;""")
edit("""        else if (redirect) pc <= redirect_pc;
        else if (!stall) pc <= pc + 4;""",
"""        else if (redirect) pc <= redirect_pc;
        else if (id_redirect) pc <= id_target;
        else if (!stall) pc <= pc + 4;""")
edit("""        if (rst || redirect) begin d_instr <= NOP; d_pc <= 0; end   // flush the wrong-path fetch""",
"""        if (rst || redirect || id_redirect) begin d_instr <= NOP; d_pc <= 0; end""")
edit("""        if (redirect) flushes = flushes + 1;""",
"""        if (redirect) flushes = flushes + 1;
        if (id_redirect && !redirect) id_flushes = id_flushes + 1;""")
edit("""    integer cycles = 0, retired = 0, stalls = 0, flushes = 0, j;""",
"""    integer cycles = 0, retired = 0, stalls = 0, flushes = 0, id_flushes = 0, j;""")
edit("""                $display("[stall cycles %0d, redirects %0d (each flushes 2 instructions)]", stalls, flushes);""",
"""                $display("[stall cycles %0d, EX redirects %0d (flush 2), ID redirects %0d (flush 1)]",
                         stalls, flushes, id_flushes);""")
open(dst, "w").write(v)
print(f"wrote {dst}")
