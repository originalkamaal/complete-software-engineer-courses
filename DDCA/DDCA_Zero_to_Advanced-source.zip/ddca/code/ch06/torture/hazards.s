# file: torture/hazards.s
# Back-to-back dependences of every kind; the checksum must match rvsim's.
    .text
    .globl _start
_start:
    lla  t6, data
    li   s0, 0                  # checksum
    li   t0, 5
    addi t1, t0, 1              # EX->EX forwarding (distance 1)
    add  t2, t1, t0             # distance 1 and 2 at once
    sub  t3, t2, t1             # chain
    add  s0, s0, t3
    lw   t4, 0(t6)              # load ...
    add  t5, t4, t4             # ... used at once: load-use stall
    add  s0, s0, t5
    lw   t4, 4(t6)
    nop
    add  t5, t4, t2             # load, then use at distance 2: forwarded from WB
    add  s0, s0, t5
    sw   t5, 8(t6)              # store data forwarded (rs2)
    lw   a1, 8(t6)              # load what was just stored
    add  s0, s0, a1
    lw   a2, 0(t6)
    sw   a2, 12(t6)             # load-use into a store's data
    lw   a3, 12(t6)
    add  s0, s0, a3
    lw   a4, 0(t6)
    beq  a4, t0, skip1          # load-use into a branch (7 != 5: not taken)
    addi s0, s0, 100
skip1:
    li   a5, 3
loop:                           # a taken backward branch three times
    add  s0, s0, a5
    addi a5, a5, -1
    bnez a5, loop
    lla  a6, target
    jalr ra, 0(a6)              # jalr with a register written two instructions earlier
    addi s0, s0, 1000           # executed after target returns here through ra
    j    finish
target:
    addi s0, s0, 7
    ret                         # jalr through ra written by the jalr above
finish:
    add  s0, s0, x0
    addi x0, s0, 1              # writes to x0 are ignored ...
    add  s0, s0, x0             # ... and x0 still reads 0
    mv   a0, s0
    andi a0, a0, 255
    li   a7, 93
    ecall
    .data
data: .word 7, 11, 0, 0
