# file: torture/pipeview.py
"""Print which instruction occupies each pipeline stage, cycle by cycle, from pipe_cpu's +trace output."""
import re
import subprocess
import sys

elf, trace = sys.argv[1], sys.argv[2]
names = {}
dump = subprocess.run(["riscv64-linux-gnu-objdump", "-d", elf], capture_output=True, text=True).stdout
for line in dump.splitlines():
    m = re.match(r"\s+([0-9a-f]+):\s+[0-9a-f]{8}\s+(\S+)\s*(\S*)", line)
    if m:
        names[int(m.group(1), 16)] = (m.group(2) + " " + m.group(3).split(",")[0])[:12]

def show(pc):
    return "-" if pc == 0xFFFFFFFF else names.get(pc, f"{pc:x}")

print(f"{'cyc':>3} | {'IF':12} | {'ID':12} | {'EX':12} | {'MEM':12} | {'WB':12} | note")
for line in open(trace):
    if not line.startswith("T "):
        continue
    _, cyc, f, d, e, m, w, stall, redirect = line.split()
    note = ("stall" if stall == "1" else "") + (" redirect: flush IF, ID" if redirect == "1" else "")
    cols = [show(int(x, 16)) for x in (f, d, e, m, w)]
    print(f"{int(cyc):>3} | " + " | ".join(f"{c:12}" for c in cols) + f" | {note}")
