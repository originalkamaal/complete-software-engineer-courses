# file: project/make_pipe_cache2.py
"""Make the data cache of pipe_cache.v two-way set-associative with LRU replacement:
each set gets a second way, a hit may be in either, and a miss replaces the least recently used."""
import sys

src, dst = sys.argv[1], sys.argv[2]
v = open(src).read()

def edit(old, new):
    global v
    assert v.count(old) == 1, f"edit target not found exactly once: {old[:60]!r}"
    v = v.replace(old, new)

edit("module pipe_cache #", "module pipe_cache2 #")
edit('$display("[pipe_cache FORWARD', '$display("[pipe_cache2 FORWARD')
edit("""    reg        d_valid [0:DS-1], d_dirty [0:DS-1];
    reg [27:0] d_tag   [0:DS-1];""",
"""    reg        d_valid [0:1][0:DS-1], d_dirty [0:1][0:DS-1];
    reg [27:0] d_tag   [0:1][0:DS-1];
    reg        d_lru   [0:DS-1];                          // the way to replace next""")
edit("""    wire d_hit = d_valid[di] && d_tag[di] == d_blk;""",
"""    wire d_hit0 = d_valid[0][di] && d_tag[0][di] == d_blk;
    wire d_hit1 = d_valid[1][di] && d_tag[1][di] == d_blk;
    wire d_hit = d_hit0 || d_hit1;
    wire d_way = d_hit1;                                  // the way that hit
    wire d_vic = d_lru[di];                               // the way to fill on a miss""")
edit("""    wire [8:0] d_cost = d_valid[di] && d_dirty[di] ? 2 * LAT : LAT;""",
"""    wire [8:0] d_cost = d_valid[d_vic][di] && d_dirty[d_vic][di] ? 2 * LAT : LAT;""")
edit("""        if (s < DS) begin d_valid[s] = 0; d_dirty[s] = 0; end""",
"""        if (s < DS) begin d_valid[0][s] = 0; d_valid[1][s] = 0; d_dirty[0][s] = 0; d_dirty[1][s] = 0; d_lru[s] = 0; end""")
edit("""                d_valid[di] <= 1; d_tag[di] <= d_blk; d_dirty[di] <= 0;""",
"""                d_valid[d_vic][di] <= 1; d_tag[d_vic][di] <= d_blk; d_dirty[d_vic][di] <= 0;""")
edit("""        end else if (DC_SETS != 0 && m_st)
            d_dirty[di] <= 1;                             // a store hit dirties the block""",
"""        end else if (DC_SETS != 0 && (m_load || m_st)) begin   // a hit: update LRU, maybe dirty
            d_lru[di] <= ~d_way;
            if (m_st) d_dirty[d_way][di] <= 1;
        end""")
open(dst, "w").write(v)
