# file: project/predict2.py
"""The model's prediction for a two-way LRU data cache with the same total size."""
import sys
sys.path.insert(0, "../model")
sys.argv = ["predict2"]
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from predict import cpu, Cache, LAT, BASE        # reuses the traces collected by predict.py
for sets in (32, 128, 512):                          # two ways: same bytes as 64, 256, 1024 sets
    ic, dc = Cache(32 * sets, 16, 1), Cache(32 * sets, 16, 2)
    for a in cpu.itrace:
        ic.access(a)
    for a, w in cpu.dtrace:
        dc.access(a, w)
    cycles = BASE + LAT * (ic.misses + dc.misses + dc.writebacks)
    print(f"2-way, {sets:4d} sets ({32 * sets:5d} bytes): {dc.misses:6d} D-misses, {dc.writebacks:6d} write-backs, "
          f"predicted CPI {cycles / cpu.count:.3f}")
