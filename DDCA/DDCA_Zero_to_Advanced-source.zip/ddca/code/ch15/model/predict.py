# file: model/predict.py
"""Predict the capstone CPU's cache behaviour from the instruction-set simulator of Chapter 4
and the cache simulator of Chapter 10: run the program, collect every instruction fetch and data
access, and feed them to two direct-mapped caches with 16-byte blocks."""
import sys
sys.path.insert(0, "../../ch04/rvsim")
sys.path.insert(0, "../../ch10/sim")
from rvsim import CPU
from cachesim import Cache

class TracingCPU(CPU):
    def __init__(self):
        super().__init__(mem_size=1 << 16)
        self.itrace, self.dtrace, self.fetching = [], [], False
    def step(self):
        self.itrace.append(self.pc)
        self.fetching = True                     # step()'s first ld is the instruction fetch
        super().step()
    def ld(self, addr, size, signed):
        if self.fetching:
            self.fetching = False
        else:
            self.dtrace.append((addr, False))
        return super().ld(addr, size, signed)
    def st(self, addr, size, v):
        self.dtrace.append((addr, True))
        super().st(addr, size, v)

cpu = TracingCPU()
cpu.load_elf("../sw/memtest.elf")
cpu.run()
LAT, BASE = 20, 274702                           # memory latency; cycles of the CPU with perfect memory
print(f"{cpu.count} instructions, {len(cpu.dtrace)} data accesses")
for sets in (64, 256, 1024, 4096):
    ic, dc = Cache(16 * sets, 16, 1), Cache(16 * sets, 16, 1)
    for a in cpu.itrace:
        ic.access(a)
    for a, w in cpu.dtrace:
        dc.access(a, w)
    cycles = BASE + LAT * (ic.misses + dc.misses + dc.writebacks)
    print(f"{sets:5d} sets ({16 * sets:6d} bytes each): {ic.misses:5d} I-misses, {dc.misses:6d} D-misses, "
          f"{dc.writebacks:6d} write-backs -> predicted {cycles} cycles, CPI {cycles / cpu.count:.3f}")
