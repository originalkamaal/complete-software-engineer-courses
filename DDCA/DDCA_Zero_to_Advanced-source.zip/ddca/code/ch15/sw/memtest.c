// file: sw/memtest.c
// Memory-system workloads for the capstone CPU (RV32I only: no multiply or divide).
#include "rt.h"

#define NOINLINE __attribute__((noipa))
#define R 64                                  // 64 x 64 ints = 16 KiB per matrix
static int A[R][R], B[R][R];
static unsigned seed = 1;
static unsigned rnd(void) { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return seed; }

static NOINLINE int sum_rows(void) {          // walks A in memory order
    int s = 0;
    for (int i = 0; i < R; i++) for (int j = 0; j < R; j++) s += A[i][j];
    return s;
}
static NOINLINE int sum_cols(void) {          // the same sum, 256 bytes between accesses
    int s = 0;
    for (int j = 0; j < R; j++) for (int i = 0; i < R; i++) s += A[i][j];
    return s;
}
static NOINLINE void transpose(void) {        // reads rows of A, writes columns of B
    for (int i = 0; i < R; i++) for (int j = 0; j < R; j++) B[j][i] = A[i][j];
}

#define NODES 2048                            // 2048 nodes of 8 bytes = 16 KiB
struct node { struct node *next; int val; };
static struct node pool[NODES];
static int order[NODES];
static NOINLINE int chase(void) {             // follows the list in a random order
    int s = 0;
    for (struct node *p = &pool[order[0]]; p; p = p->next) s += p->val;
    return s;
}

static void say(const char *what, int v) { puts_(what); putint(v); puts_("\n"); }

int main(void) {
    for (int i = 0; i < R; i++) for (int j = 0; j < R; j++) A[i][j] = (int)(rnd() & 255);
    for (int i = 0; i < NODES; i++) { order[i] = i; pool[i].val = i & 7; }
    for (int i = NODES - 1; i > 0; i--) {     // shuffle with rejection sampling instead of %
        unsigned j;
        do j = rnd() & (NODES - 1); while (j > (unsigned)i);
        int t = order[i]; order[i] = order[j]; order[j] = t;
    }
    for (int i = 0; i < NODES - 1; i++) pool[order[i]].next = &pool[order[i + 1]];
    pool[order[NODES - 1]].next = 0;

    say("rows ", sum_rows());
    say("cols ", sum_cols());
    transpose();
    say("trans ", B[5][7] - A[7][5]);
    say("chase ", chase());
    return 0;
}
