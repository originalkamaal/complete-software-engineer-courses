# file: rtl/make_pipe_cache.py
"""Derive pipe_cache.v from Chapter 8's pipe_bp.v: add direct-mapped instruction and data caches
(16-byte blocks, write-back, write-allocate) in front of a memory with a fixed latency. A miss
freezes the whole pipeline until the block has arrived. The caches hold tags, valid and dirty bits;
the data stays in the pipeline's memory array, so the caches decide *when* an access completes,
not *what* it returns (Chapter 10's project built the data path)."""
import sys

src, dst = sys.argv[1], sys.argv[2]
v = open(src).read()

def edit(old, new, count=1):
    global v
    assert v.count(old) == count, f"edit target found {v.count(old)} times: {old[:60]!r}"
    v = v.replace(old, new)

edit("module pipe_bp #(parameter MEMWORDS = 16384, parameter HEX = \"prog.hex\", parameter FORWARD = 1)",
     "module pipe_cache #(parameter MEMWORDS = 16384, parameter HEX = \"prog.hex\", parameter FORWARD = 1,\n"
     "                    parameter IC_SETS = 64, parameter DC_SETS = 64, parameter LAT = 20)")
edit('$display("[pipe_bp FORWARD=%0d', '$display("[pipe_cache FORWARD=%0d')

# every pipeline register, the PC, the register file, memory writes and predictor training
# hold their values while the pipeline is frozen
n = v.count("always @(posedge clk)")
edit("always @(posedge clk)", "always @(posedge clk) if (!freeze)", n)
edit("    localparam NOP = 32'h0000_0013;                       // addi x0, x0, 0: a bubble",
     "    localparam NOP = 32'h0000_0013;                       // addi x0, x0, 0: a bubble\n"
     "    wire freeze;                                          // a cache miss is being served")

caches = """
    // ===================== caches =====================
    localparam IS = IC_SETS == 0 ? 1 : IC_SETS, DS = DC_SETS == 0 ? 1 : DC_SETS;
    reg        i_valid [0:IS-1];
    reg [27:0] i_tag   [0:IS-1];                          // block address (addr >> 4) as the tag
    reg        d_valid [0:DS-1], d_dirty [0:DS-1];
    reg [27:0] d_tag   [0:DS-1];
    wire [27:0] i_blk = pc[31:4], d_blk = m_val[31:4];
    wire [31:0] ii = i_blk & (IS - 1), di = d_blk & (DS - 1);
    wire i_hit = i_valid[ii] && i_tag[ii] == i_blk;
    wire d_hit = d_valid[di] && d_tag[di] == d_blk;
    wire d_miss = DC_SETS != 0 && !rst && (m_load || m_st) && !d_hit;
    wire i_miss = IC_SETS != 0 && !rst && !i_hit;
    assign freeze = d_miss || i_miss;
    wire [8:0] d_cost = d_valid[di] && d_dirty[di] ? 2 * LAT : LAT;   // write the victim back first
    reg  [8:0] wait_cnt;
    integer s, i_misses = 0, d_misses = 0, writebacks = 0, frozen = 0;
    initial for (s = 0; s < DS || s < IS; s = s + 1) begin
        if (s < IS) i_valid[s] = 0;
        if (s < DS) begin d_valid[s] = 0; d_dirty[s] = 0; end
    end
    always @(posedge clk)
        if (rst) wait_cnt <= 0;
        else if (d_miss) begin                            // the older instruction goes first
            if (wait_cnt == d_cost - 1) begin
                wait_cnt <= 0;
                if (d_cost != LAT) writebacks = writebacks + 1;
                d_valid[di] <= 1; d_tag[di] <= d_blk; d_dirty[di] <= 0;
                d_misses = d_misses + 1;
            end else wait_cnt <= wait_cnt + 1;
        end else if (i_miss) begin
            if (wait_cnt == LAT - 1) begin
                wait_cnt <= 0;
                i_valid[ii] <= 1; i_tag[ii] <= i_blk;
                i_misses = i_misses + 1;
            end else wait_cnt <= wait_cnt + 1;
        end else if (DC_SETS != 0 && m_st)
            d_dirty[di] <= 1;                             // a store hit dirties the block
    always @(posedge clk) if (!rst && freeze) frozen = frozen + 1;

    // ===================== WB ====================="""
edit("\n    // ===================== WB =====================", caches)
edit("""                $display("[stall cycles %0d, mispredictions %0d (each flushes 2 instructions)]", stalls, flushes);""",
     """                $display("[stall cycles %0d, mispredictions %0d (each flushes 2 instructions)]", stalls, flushes);
                $display("[caches %0d + %0d sets: %0d I-misses, %0d D-misses, %0d write-backs; %0d cycles frozen; %0d cycles in all, CPI %0.3f]",
                         IC_SETS, DC_SETS, i_misses, d_misses, writebacks, frozen, cycles + frozen,
                         1.0 * (cycles + frozen) / retired);""")
open(dst, "w").write(v)
