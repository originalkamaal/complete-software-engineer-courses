# file: sumprint.s
    .data
arr:    .word 3, 1, 4, 1, 5, 9, 2, 6, 5, 3     # int arr[10]
n:      .word 10
buf:    .space 12                              # char buf[12]

    .text
    .globl _start
_start:
    .option push
    .option norelax
    lla  gp, __global_pointer$   # set up gp: the linker may address data relative to it
    .option pop
    lla  t0, arr                 # t0 = &arr[0]  (lla: PC-relative address)
    lw   t1, n                   # t1 = n        (lw with a symbol: auipc + lw)
    li   a0, 0                   # sum = 0
loop:                            # while (n > 0)
    beqz t1, done
    lw   t2, 0(t0)               #   sum += *p
    add  a0, a0, t2
    addi t0, t0, 4               #   p++   (4 bytes per word)
    addi t1, t1, -1              #   n--
    j    loop
done:
    # convert a0 to decimal, right to left, by repeated subtraction of powers of ten
    lla  t0, buf + 11
    li   t1, 10
    sb   t1, 0(t0)               # buf[11] = '\n'
digits:
    addi t0, t0, -1
    li   t2, 0                   # quotient
div10:                           # while (a0 >= 10) { a0 -= 10; q++; }
    blt  a0, t1, divdone
    addi a0, a0, -10
    addi t2, t2, 1
    j    div10
divdone:
    addi a0, a0, '0'             # remainder -> ASCII digit
    sb   a0, 0(t0)
    mv   a0, t2                  # continue with the quotient
    bnez a0, digits
    # write(1, t0, buf + 12 - t0)
    lla  a2, buf + 12
    sub  a2, a2, t0
    mv   a1, t0
    li   a0, 1
    li   a7, 64
    ecall
    li   a0, 0                   # exit(0)
    li   a7, 93
    ecall
