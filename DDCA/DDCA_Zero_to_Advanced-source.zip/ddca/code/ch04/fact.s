# file: fact.s
    .text
    .globl _start
# unsigned fact(unsigned n) { return n <= 1 ? 1 : n * fact(n - 1); }
# RV32I has no multiply: mul(a, b) below is shift-and-add.
fact:
    li   t0, 1
    bgtu a0, t0, recurse
    li   a0, 1
    ret                          # = jalr x0, 0(ra)
recurse:
    addi sp, sp, -16             # stack frame: 16 bytes
    sw   ra, 12(sp)              # save the return address
    sw   s0, 8(sp)               # save the caller's s0
    mv   s0, a0                  # keep n across the call
    addi a0, a0, -1
    call fact                    # = jal ra, fact   (a0 = fact(n - 1))
    mv   a1, s0
    call mul                     # a0 = fact(n - 1) * n
    lw   s0, 8(sp)
    lw   ra, 12(sp)
    addi sp, sp, 16
    ret

mul:                             # a0 = a0 * a1, leaf function: no frame needed
    li   t0, 0
mul_loop:
    beqz a1, mul_done
    andi t1, a1, 1
    beqz t1, mul_skip
    add  t0, t0, a0
mul_skip:
    slli a0, a0, 1
    srli a1, a1, 1
    j    mul_loop
mul_done:
    mv   a0, t0
    ret

_start:
    li   a0, 10
    call fact                    # fact(10) = 3628800
    li   t0, 3628800
    sub  a0, a0, t0              # exit status 0 if correct
    li   a7, 93
    ecall
