// file: rvsim/rt.c
#include "rt.h"

int main(void);

void rt_write(const char *s, unsigned n) {
    register long a0 __asm__("a0") = 1, a1 __asm__("a1") = (long)s, a2 __asm__("a2") = n;
    register long a7 __asm__("a7") = 64;
    __asm__ volatile("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a7) : "memory");
}

void rt_exit(int code) {
    register long a0 __asm__("a0") = code, a7 __asm__("a7") = 93;
    __asm__ volatile("ecall" : : "r"(a0), "r"(a7));
    for (;;) {}
}

void puts_(const char *s) {
    unsigned n = 0;
    while (s[n]) n++;
    rt_write(s, n);
}

void putint(int v) {                              // no division in RV32I: subtract powers of ten
    static const int pow10[] = {1000000000, 100000000, 10000000, 1000000, 100000, 10000, 1000, 100, 10, 1};
    char buf[12];
    unsigned n = 0, u = v < 0 ? -(unsigned)v : (unsigned)v;
    int started = 0;
    if (v < 0) buf[n++] = '-';
    for (int i = 0; i < 10; i++) {
        char d = '0';
        while (u >= (unsigned)pow10[i]) { u -= pow10[i]; d++; }
        if (d != '0' || started || i == 9) { buf[n++] = d; started = 1; }
    }
    rt_write(buf, n);
}

void *memset(void *p, int c, unsigned n) { char *q = p; while (n--) *q++ = (char)c; return p; }
void *memcpy(void *d, const void *s, unsigned n) { char *a = d; const char *b = s; while (n--) *a++ = *b++; return d; }

__asm__(".section .text._start\n"            // the entry point, in assembly: set gp, call main, exit
        ".globl _start\n"
        "_start:\n"
        ".option push\n.option norelax\n"
        "lla gp, __global_pointer$\n"
        ".option pop\n"
        "call main\n"
        "tail rt_exit\n");
