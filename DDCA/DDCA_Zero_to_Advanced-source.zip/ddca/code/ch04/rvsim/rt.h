// file: rvsim/rt.h
#ifndef RT_H
#define RT_H
void rt_write(const char *s, unsigned n);
void rt_exit(int code) __attribute__((noreturn));
void puts_(const char *s);
void putint(int v);
#endif
