# file: rvsim/rvsim.py
"""rvsim: an RV32I instruction-set simulator that runs static ELF32 programs (Linux write/exit ecalls)."""
import struct
import sys

MASK = 0xFFFFFFFF

def sext(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v

class CPU:
    def __init__(self, mem_size=1 << 24):
        self.x = [0] * 32
        self.pc = 0
        self.mem = bytearray(mem_size)
        self.count = 0
        self.out = bytearray()
        self.exit_code = None

    def load_elf(self, path):
        data = open(path, "rb").read()
        assert data[:4] == b"\x7fELF" and data[4] == 1, "need a 32-bit ELF"
        entry, phoff = struct.unpack_from("<II", data, 0x18)
        phentsize, phnum = struct.unpack_from("<HH", data, 0x2A)
        for i in range(phnum):
            p_type, off, vaddr, _, filesz, memsz = struct.unpack_from("<IIIIII", data, phoff + i * phentsize)
            if p_type == 1:                                          # PT_LOAD
                self.mem[vaddr:vaddr + filesz] = data[off:off + filesz]
                self.mem[vaddr + filesz:vaddr + memsz] = bytes(memsz - filesz)
        self.pc = entry
        self.x[2] = len(self.mem) - 16                               # sp at the top of memory

    def ld(self, addr, size, signed):
        v = int.from_bytes(self.mem[addr:addr + size], "little")
        return sext(v, size * 8) & MASK if signed else v

    def st(self, addr, size, v):
        self.mem[addr:addr + size] = (v & ((1 << size * 8) - 1)).to_bytes(size, "little")

    def step(self):
        w = self.ld(self.pc, 4, False)
        op, rd, f3 = w & 0x7F, w >> 7 & 31, w >> 12 & 7
        a, b = self.x[w >> 15 & 31], self.x[w >> 20 & 31]
        f7 = w >> 25
        immI = sext(w >> 20, 12)
        next_pc, val = self.pc + 4, None
        if op == 0x37:   val = w & 0xFFFFF000                                      # LUI
        elif op == 0x17: val = (self.pc + (w & 0xFFFFF000)) & MASK                 # AUIPC
        elif op == 0x6F:                                                           # JAL
            imm = (w >> 31) << 20 | (w >> 12 & 0xFF) << 12 | (w >> 20 & 1) << 11 | (w >> 21 & 0x3FF) << 1
            val, next_pc = next_pc, (self.pc + sext(imm, 21)) & MASK
        elif op == 0x67:                                                           # JALR
            val, next_pc = next_pc, (a + immI) & MASK & ~1
        elif op == 0x63:                                                           # branches
            imm = (w >> 31) << 12 | (w >> 7 & 1) << 11 | (w >> 25 & 0x3F) << 5 | (w >> 8 & 0xF) << 1
            sa, sb = sext(a, 32), sext(b, 32)
            taken = {0: a == b, 1: a != b, 4: sa < sb, 5: sa >= sb, 6: a < b, 7: a >= b}[f3]
            if taken:
                next_pc = (self.pc + sext(imm, 13)) & MASK
        elif op == 0x03:                                                           # loads
            addr = (a + immI) & MASK
            val = {0: (1, True), 1: (2, True), 2: (4, False), 4: (1, False), 5: (2, False)}[f3]
            val = self.ld(addr, val[0], val[1])
        elif op == 0x23:                                                           # stores
            imm = sext((w >> 25) << 5 | (w >> 7 & 31), 12)
            self.st((a + imm) & MASK, 1 << f3, b)
        elif op in (0x13, 0x33):                                                   # ALU
            imm_mode = op == 0x13
            y = immI & MASK if imm_mode else b
            sh = y & 31
            if f3 == 0:   val = a - y if (not imm_mode and f7 == 0x20) else a + y
            elif f3 == 1: val = a << sh
            elif f3 == 2: val = int(sext(a, 32) < sext(y, 32))
            elif f3 == 3: val = int(a < y)
            elif f3 == 4: val = a ^ y
            elif f3 == 5: val = (sext(a, 32) >> sh) if (f7 & 0x20) else a >> sh
            elif f3 == 6: val = a | y
            else:         val = a & y
            val &= MASK
        elif op == 0x73:                                                           # ECALL
            self.syscall()
        elif op == 0x0F:                                                           # FENCE: no-op here
            pass
        else:
            raise RuntimeError(f"illegal instruction {w:08x} at {self.pc:08x}")
        if val is not None and rd:
            self.x[rd] = val
        self.pc = next_pc
        self.count += 1

    def syscall(self):
        n, a0, a1, a2 = self.x[17], self.x[10], self.x[11], self.x[12]
        if n == 64:                                          # write(fd, buf, len)
            self.out += self.mem[a1:a1 + a2]
            self.x[10] = a2
        elif n == 93:                                        # exit(code)
            self.exit_code = a0 & 0xFF
        else:
            raise RuntimeError(f"unsupported syscall {n}")

    def run(self, limit=50_000_000, trace=False):
        while self.exit_code is None and self.count < limit:
            if trace:
                print(f"{self.count:6d} pc={self.pc:08x} instr={self.ld(self.pc, 4, False):08x}", file=sys.stderr)
            self.step()
        return self.exit_code

if __name__ == "__main__":
    cpu = CPU()
    cpu.load_elf(sys.argv[1])
    code = cpu.run(trace="--trace" in sys.argv)
    sys.stdout.write(cpu.out.decode(errors="replace"))
    print(f"[rvsim: {cpu.count} instructions, exit {code}]", file=sys.stderr)
    sys.exit(code)
