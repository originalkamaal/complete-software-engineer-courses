// file: rvsim/tests.c
#include "rt.h"

static unsigned mul(unsigned a, unsigned b) { unsigned r = 0; while (b) { if (b & 1) r += a; a <<= 1; b >>= 1; } return r; }

static int fib(int n) { return n < 2 ? n : fib(n - 1) + fib(n - 2); }

static void bubble(int *a, int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j + 1 < n - i; j++)
            if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
}

static unsigned crc32(const unsigned char *p, unsigned n) {
    unsigned c = 0xFFFFFFFFu;
    while (n--) {
        c ^= *p++;
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & -(c & 1));
    }
    return ~c;
}

int main(void) {
    puts_("fib(20) = "); putint(fib(20)); puts_("\n");
    int a[12] = {5, -3, 9, 0, 12, -7, 3, 3, 100, -50, 8, 1};
    bubble(a, 12);
    puts_("sorted:");
    for (int i = 0; i < 12; i++) { puts_(" "); putint(a[i]); }
    puts_("\n");
    puts_("12345 * 6789 = "); putint((int)mul(12345, 6789)); puts_("\n");
    const char *msg = "The quick brown fox jumps over the lazy dog";
    unsigned n = 0; while (msg[n]) n++;
    puts_("crc32 = "); putint((int)crc32((const unsigned char *)msg, n)); puts_("\n");
    signed char sc = -100; unsigned char uc = 200;
    puts_("sign tests: "); putint(sc >> 2); puts_(" "); putint(uc >> 2); puts_(" "); putint(-17 >> 1); puts_("\n");
    return 42;
}
