# file: formats.s
    .text
    .globl _start
_start:
    add  x5, x6, x7          # R
    addi x5, x6, -3          # I
    lw   x8, 12(x2)          # I (load)
    sw   x8, -4(x2)          # S
    beq  x5, x6, _start      # B (backwards: negative offset)
    lui  x9, 0x12345         # U
    jal  x1, _start          # J
