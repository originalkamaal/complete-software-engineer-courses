# file: toy.py
LOAD, ADD, STORE, HALT = 1, 2, 3, 0          # opcode in the high byte, address in the low byte

mem = [0] * 16
program = [(LOAD, 12), (ADD, 13), (ADD, 14), (STORE, 15), (HALT, 0)]
for i, (op, addr) in enumerate(program):
    mem[i] = op << 8 | addr                    # instructions are numbers in memory
mem[12:15] = [5, 7, 9]                         # data, in the same memory

pc, acc, cycles = 0, 0, 0
while True:
    instr = mem[pc]                            # fetch
    op, addr = instr >> 8, instr & 0xFF        # decode
    pc += 1
    cycles += 1
    if op == LOAD:    acc = mem[addr]          # execute
    elif op == ADD:   acc += mem[addr]
    elif op == STORE: mem[addr] = acc
    elif op == HALT:  break
    print(f"pc={pc - 1:2} instr={instr:#06x} acc={acc}")
print(f"halted after {cycles} instructions; mem[15] = {mem[15]}")
print("memory:", mem)
