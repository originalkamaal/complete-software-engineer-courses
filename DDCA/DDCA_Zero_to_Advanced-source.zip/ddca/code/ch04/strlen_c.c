// file: strlen_c.c
unsigned my_strlen(const char *s) {
    unsigned n = 0;
    while (s[n] != '\0')
        n++;
    return n;
}
