# file: li.s
    .globl _start
_start:
    li   a0, 0x12345FFF       # bit 11 is 1: the assembler compensates
    lui  a1, 0x12345           # naive pair: lui of the top 20 bits...
    addi a1, a1, -1            # ...plus 0xFFF, which as a 12-bit signed value is -1
