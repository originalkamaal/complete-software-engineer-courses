# file: decode.py
import subprocess, sys

def sext(v, bits):
    return v - (1 << bits) if v >> (bits - 1) & 1 else v

def decode(w):
    op, rd, f3, rs1, rs2, f7 = w & 0x7F, w >> 7 & 31, w >> 12 & 7, w >> 15 & 31, w >> 20 & 31, w >> 25
    if op == 0x33:
        return f"R  add-family f7={f7:#x} f3={f3} rd=x{rd} rs1=x{rs1} rs2=x{rs2}"
    if op in (0x13, 0x03, 0x67):
        return f"I  op={op:#04x} f3={f3} rd=x{rd} rs1=x{rs1} imm={sext(w >> 20, 12)}"
    if op == 0x23:
        imm = (w >> 25) << 5 | (w >> 7 & 31)
        return f"S  f3={f3} rs1=x{rs1} rs2=x{rs2} imm={sext(imm, 12)}"
    if op == 0x63:
        imm = (w >> 31) << 12 | (w >> 7 & 1) << 11 | (w >> 25 & 0x3F) << 5 | (w >> 8 & 0xF) << 1
        return f"B  f3={f3} rs1=x{rs1} rs2=x{rs2} offset={sext(imm, 13)}"
    if op in (0x37, 0x17):
        return f"U  rd=x{rd} imm={w >> 12:#x}"
    if op == 0x6F:
        imm = (w >> 31) << 20 | (w >> 12 & 0xFF) << 12 | (w >> 20 & 1) << 11 | (w >> 21 & 0x3FF) << 1
        return f"J  rd=x{rd} offset={sext(imm, 21)}"
    return "?"

dump = subprocess.run(["riscv64-linux-gnu-objdump", "-d", sys.argv[1]], capture_output=True, text=True).stdout
for line in dump.splitlines():
    parts = line.split("\t")
    if len(parts) >= 3 and parts[0].strip().endswith(":") and len(parts[1].strip()) == 8:
        word = int(parts[1], 16)
        print(f"{word:08x}  {parts[2]:<6} {parts[3] if len(parts) > 3 else '':<18} -> {decode(word)}")
