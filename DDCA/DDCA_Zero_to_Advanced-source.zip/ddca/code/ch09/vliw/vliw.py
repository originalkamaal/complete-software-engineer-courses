# file: vliw/vliw.py
"""Static scheduling for a VLIW machine: pack the operations of a loop body into wide instructions
(bundles) of fixed slots, respecting dependences and latencies — what a VLIW compiler does."""

SLOTS = {"mem": 2, "fp": 2, "int": 1}                    # functional units per bundle
LAT = {"load": 3, "fmul": 4, "fadd": 3, "store": 1, "add": 1}
UNIT = {"load": "mem", "store": "mem", "fmul": "fp", "fadd": "fp", "add": "int"}

def saxpy_body(unroll):
    """y[i] = a * x[i] + y[i], unrolled `unroll` times; returns (name, op, sources)."""
    ops = []
    for k in range(unroll):
        ops += [(f"lx{k}", "load", []), (f"ly{k}", "load", []),
                (f"m{k}", "fmul", [f"lx{k}"]), (f"a{k}", "fadd", [f"m{k}", f"ly{k}"]),
                (f"s{k}", "store", [f"a{k}"])]
    ops.append(("inc", "add", []))                        # pointer/counter update, once per body
    return ops

def schedule(ops):
    ready_at, placed, bundles = {}, set(), []
    cycle = 0
    while len(placed) < len(ops):
        free = dict(SLOTS)
        bundle = []
        for name, op, srcs in ops:                        # list scheduling, in program order
            if name in placed or free[UNIT[op]] == 0:
                continue
            if all(s in ready_at and ready_at[s] <= cycle for s in srcs):
                bundle.append(name)
                free[UNIT[op]] -= 1
                placed.add(name)
                ready_at[name] = cycle + LAT[op]
        bundles.append(bundle)
        cycle += 1
    while any(t > len(bundles) for t in ready_at.values()):
        bundles.append([])                                # wait for the last results
    return bundles

for unroll in (1, 4):
    ops = saxpy_body(unroll)
    b = schedule(ops)
    used = sum(len(x) for x in b)
    total = len(b) * sum(SLOTS.values())
    print(f"unroll {unroll}: {len(ops)} operations in {len(b)} bundles, "
          f"{len(b) / unroll:.2f} cycles per element, {100 * used / total:.0f}% of slots used")
    for i, x in enumerate(b):
        print(f"   bundle {i:2d}: " + (", ".join(x) if x else "(empty: waiting for latency)"))
