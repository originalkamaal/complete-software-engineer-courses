# file: gpu/simt.py
"""A SIMT model: a warp of 32 threads shares one program counter. When threads disagree at a
branch, the warp runs each path in turn with the other threads masked off, then reconverges."""

WARP = 32

def run_kernel(n_threads, branch_of):
    """Each thread runs: 4 instructions; if branch_of(tid): 20 instructions else 10; then 4 more.
    Returns (issue cycles, useful thread-instructions, total lane-slots)."""
    issue = useful = 0
    for w in range(0, n_threads, WARP):
        tids = list(range(w, min(w + WARP, n_threads)))
        takes = [branch_of(t) for t in tids]
        issue += 4; useful += 4 * len(tids)                       # common prefix: all lanes active
        n_then = sum(takes)
        if n_then:                                                # "then" path, other lanes masked
            issue += 20; useful += 20 * n_then
        if n_then < len(tids):                                    # "else" path
            issue += 10; useful += 10 * (len(tids) - n_then)
        issue += 4; useful += 4 * len(tids)                       # after reconvergence
    return issue, useful, issue * WARP

cases = [
    ("no branch taken by anyone", lambda t: False),
    ("whole warps agree (tid / 32 even)", lambda t: (t // 32) % 2 == 0),
    ("half of each warp (tid even)", lambda t: t % 2 == 0),
    ("one thread per warp (tid % 32 == 0)", lambda t: t % 32 == 0),
    ("data-dependent, about half", lambda t: (t * 2654435761 >> 7) & 1 == 1),
]
print(f"{'branch pattern':38} {'issue cycles':>12} {'SIMD efficiency':>16}")
for name, f in cases:
    issue, useful, slots = run_kernel(4096, f)
    print(f"{name:38} {issue:12d} {100 * useful / slots:15.0f}%")
