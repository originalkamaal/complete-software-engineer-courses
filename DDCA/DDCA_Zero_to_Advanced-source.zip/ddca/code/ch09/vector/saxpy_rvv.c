// file: vector/saxpy_rvv.c
// SAXPY with the RISC-V vector extension: a vector-length-agnostic "strip-mined" loop.
#include <riscv_vector.h>
#include <stdio.h>

static int strips;

void saxpy_rvv(size_t n, float a, const float *x, float *y) {
    while (n > 0) {
        size_t vl = __riscv_vsetvl_e32m1(n);                  // hardware says how many it will do
        vfloat32m1_t vx = __riscv_vle32_v_f32m1(x, vl);
        vfloat32m1_t vy = __riscv_vle32_v_f32m1(y, vl);
        vy = __riscv_vfmacc_vf_f32m1(vy, a, vx, vl);           // vy += a * vx, vl elements at once
        __riscv_vse32_v_f32m1(y, vy, vl);
        x += vl; y += vl; n -= vl;
        strips++;
    }
}

int main(void) {
    enum { N = 100 };
    float x[N], y[N];
    for (int i = 0; i < N; i++) { x[i] = i; y[i] = 1; }
    saxpy_rvv(N, 2.0f, x, y);
    int ok = 1;
    for (int i = 0; i < N; i++) ok &= (y[i] == 2.0f * i + 1);
    printf("VLEN %4zu bits: %2zu floats per vector, %2d strips for %d elements, results %s\n",
           __riscv_vsetvlmax_e32m1() * 32, __riscv_vsetvlmax_e32m1(), strips, N, ok ? "correct" : "WRONG");
    return 0;
}
