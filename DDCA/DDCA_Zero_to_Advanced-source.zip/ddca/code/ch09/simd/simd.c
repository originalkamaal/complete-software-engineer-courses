// file: simd/simd.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <time.h>
#define N 4096
static float x[N], y[N];
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }
__attribute__((noipa)) void saxpy(int n, float a, const float *restrict xs, float *restrict ys) {
    for (int i = 0; i < n; i++) ys[i] = a * xs[i] + ys[i];
}
__attribute__((noipa)) float dot(int n, const float *xs, const float *ys) {
    float s = 0;
    for (int i = 0; i < n; i++) s += xs[i] * ys[i];
    return s;
}
int main(void) {
    for (int i = 0; i < N; i++) { x[i] = i * 0.001f; y[i] = 1.0f; }
    double t0 = now();
    for (int r = 0; r < 100000; r++) saxpy(N, 1e-7f, x, y);
    double t_saxpy = now() - t0;
    t0 = now();
    float s = 0;
    for (int r = 0; r < 20000; r++) s += dot(N, x, y);
    double t_dot = now() - t0;
    printf("saxpy: %.2f ns per element   dot: %.2f ns per element   (check %.3f %.1f)\n",
           t_saxpy * 1e9 / (100000.0 * N), t_dot * 1e9 / (20000.0 * N), y[N - 1], s / 20000);
    return 0;
}
