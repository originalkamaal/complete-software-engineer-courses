# file: gray.py
def gray(n):
    return n ^ (n >> 1)

def gray_to_bin(g):
    n = 0
    while g:
        n ^= g
        g >>= 1
    return n

print("n  binary  gray   bits changed (binary vs gray)")
for n in range(8):
    b_change = bin(n ^ (n + 1) & 0xF).count("1")
    g_change = bin(gray(n) ^ gray((n + 1) % 16)).count("1")
    print(f"{n}  {n:04b}    {gray(n):04b}   {b_change} vs {g_change}")
assert all(gray_to_bin(gray(n)) == n for n in range(1 << 12))
print("gray_to_bin(gray(n)) == n for all 12-bit n")
