# file: mtbf.py
import math

tau, T0 = 20e-12, 150e-12            # 20 ps time constant, 150 ps window: illustrative values
fd = 10e6                            # the asynchronous input changes 10 million times a second
for fc_mhz in (100, 500, 1000, 2000):
    fc = fc_mhz * 1e6
    t_setup = 50e-12
    one = 0.0                        # one flip-flop: the logic after it uses the value at once
    two = 1 / fc - t_setup           # two flip-flops: almost a full cycle to resolve
    for name, tr in (("1 flop ", 0.2 / fc), ("2 flops", two)):
        mtbf = math.exp(tr / tau) / (T0 * fc * fd)
        print(f"{fc_mhz:5d} MHz {name}: MTBF = {mtbf:9.3g} s ({mtbf / 3.15e7:9.3g} years)")
