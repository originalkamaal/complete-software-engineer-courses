# file: project/separate.py
"""Reducing write amplification: victim selection, and separating hot from cold data."""
import sys
sys.path.insert(0, "../ssd")
from ftl import FTL, run, hot_cold

N = 100_000
is_hot = lambda lpn, n=int(256 * 64 * (1 - 0.125)): lpn < n // 5     # the FTL is told which data is hot

configs = [
    ("FIFO victim, one stream", dict(victim="fifo")),
    ("greedy victim, one stream", dict(victim="greedy")),
    ("greedy, hot/cold streams", dict(victim="greedy", streams=2, hot=is_hot)),
    ("greedy, hot/cold streams, wear levelling", dict(victim="greedy", streams=2, hot=is_hot, wear_limit=8)),
]
print(f"{'hot/cold workload, 12.5% over-provisioning':44} {'WA':>5} {'erases: min':>12} {'max':>5}")
for name, kw in configs:
    f = run(FTL(op=0.125, **kw), hot_cold, N)
    print(f"{name:44} {f.wa():5.2f} {min(f.erases):12d} {max(f.erases):5d}")
