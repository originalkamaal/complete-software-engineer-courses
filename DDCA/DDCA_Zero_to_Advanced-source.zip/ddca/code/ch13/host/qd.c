// file: host/qd.c
// Random 4 KiB direct reads from 1, 4, 16 and 64 threads: an SSD (or a virtual disk backed by
// one) serves many requests in parallel, so throughput grows with the queue depth.
#define _GNU_SOURCE
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define FILE_SIZE (256L << 20)
#define BLK 4096
#define PER_THREAD_MS 1500

static int fd;
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static void *worker(void *arg) {
    unsigned seed = (unsigned)(size_t)arg;
    char *buf = aligned_alloc(BLK, BLK);
    long n = 0;
    double end = now() + PER_THREAD_MS / 1000.0;
    while (now() < end) {
        long blk = rand_r(&seed) % (FILE_SIZE / BLK);
        if (pread(fd, buf, BLK, blk * BLK) != BLK) { perror("pread"); exit(1); }
        n++;
    }
    free(buf);
    return (void *)n;
}

int main(void) {
    char *buf = aligned_alloc(BLK, BLK);
    memset(buf, 'y', BLK);
    int w = open("qd.bin", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    for (long i = 0; i < FILE_SIZE / BLK; i++) if (write(w, buf, BLK) != BLK) return 1;
    fsync(w); close(w);
    fd = open("qd.bin", O_RDONLY | O_DIRECT);
    for (int threads = 1; threads <= 64; threads *= 4) {
        pthread_t t[64];
        double start = now();
        for (int i = 0; i < threads; i++) pthread_create(&t[i], NULL, worker, (void *)(size_t)(i + 1));
        long total = 0;
        for (int i = 0; i < threads; i++) { void *r; pthread_join(t[i], &r); total += (long)r; }
        double secs = now() - start;
        printf("%2d requests in flight: %7.0f reads/s (%5.0f MB/s), %6.1f us average latency\n",
               threads, total / secs, total * (double)BLK / secs / 1e6, threads * secs / total * 1e6);
    }
    close(fd); unlink("qd.bin");
    return 0;
}
