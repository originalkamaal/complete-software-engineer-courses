// file: host/io.c
// What the storage stack costs: the page cache, direct I/O, sequential versus random, and fsync.
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define FILE_SIZE (256L << 20)
#define BLK 4096

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static void reads(const char *what, int flags, int random, long count) {
    int fd = open("data.bin", O_RDONLY | flags);
    char *buf = aligned_alloc(BLK, BLK);                 // O_DIRECT needs aligned buffers
    srand(3);
    double t = now();
    for (long i = 0; i < count; i++) {
        long blk = random ? rand() % (FILE_SIZE / BLK) : i % (FILE_SIZE / BLK);
        if (pread(fd, buf, BLK, blk * BLK) != BLK) { perror("pread"); exit(1); }
    }
    t = now() - t;
    printf("%-34s %8.1f us per 4 KiB read, %7.0f MB/s\n", what, t / count * 1e6, count * (double)BLK / t / 1e6);
    free(buf);
    close(fd);
}

int main(void) {
    char *buf = aligned_alloc(BLK, BLK);
    memset(buf, 'x', BLK);
    int fd = open("data.bin", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    for (long i = 0; i < FILE_SIZE / BLK; i++) if (write(fd, buf, BLK) != BLK) return 1;
    fsync(fd);
    close(fd);

    reads("page cache, sequential", 0, 0, 65536);
    reads("page cache, random", 0, 1, 65536);
    reads("O_DIRECT (device), sequential", O_DIRECT, 0, 8192);
    reads("O_DIRECT (device), random", O_DIRECT, 1, 8192);

    fd = open("log.bin", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    for (int sync = 0; sync <= 1; sync++) {
        double t = now();
        for (int i = 0; i < 200; i++) {
            if (write(fd, buf, 512) != 512) return 1;     // append a 512-byte "log record"
            if (sync) fdatasync(fd);                      // ...and wait until it is on the device
        }
        t = now() - t;
        printf("append 512 bytes%-18s %8.1f us each\n", sync ? ", fdatasync each" : "", t / 200 * 1e6);
    }
    close(fd);
    unlink("data.bin"); unlink("log.bin");
    return 0;
}
