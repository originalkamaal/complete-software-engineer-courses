# file: ssd/ftl.py
"""A page-mapped flash translation layer (FTL): out-of-place writes, a logical-to-physical map,
garbage collection, and the resulting write amplification."""
import random

class FTL:
    def __init__(self, blocks=256, pages=64, op=0.125, victim="greedy", streams=1, hot=None, wear_limit=0):
        self.B, self.P = blocks, pages
        self.logical = int(blocks * pages * (1 - op))          # what the host is told it has
        self.l2p = {}                                          # logical page -> (block, page)
        self.owner = [[None] * pages for _ in range(blocks)]   # physical page -> logical page or None
        self.valid = [0] * blocks
        self.erases = [0] * blocks
        self.free = list(range(blocks))
        self.age = {}                                          # block -> when it was filled
        self.victim, self.hot, self.wear_limit = victim, hot, wear_limit
        self.open = [self.free.pop(0) for _ in range(streams)] # one open block per stream
        self.next = [0] * streams
        self.host_writes = self.flash_writes = 0
        self.clock = 0

    def _program(self, lpn, stream):
        b = self.open[stream]
        p = self.next[stream]
        self.owner[b][p] = lpn
        self.valid[b] += 1
        self.l2p[lpn] = (b, p)
        self.flash_writes += 1
        self.next[stream] += 1
        if self.next[stream] == self.P:                        # block full: open a fresh one
            self.age[b] = self.clock
            self.open[stream] = self.free.pop(0)
            self.next[stream] = 0

    def _invalidate(self, lpn):
        if lpn in self.l2p:
            b, p = self.l2p.pop(lpn)
            self.owner[b][p] = None
            self.valid[b] -= 1

    def _gc(self):
        while len(self.free) < 2:
            full = [b for b in self.age]                       # only full, closed blocks
            coldest = min(full, key=lambda b: self.erases[b])
            if self.wear_limit and max(self.erases) - self.erases[coldest] > self.wear_limit:
                v = coldest                                    # static wear levelling: move cold data
            elif self.victim == "greedy":
                v = min(full, key=lambda b: self.valid[b])     # fewest valid pages to copy
            else:
                v = min(full, key=lambda b: self.age[b])       # FIFO: oldest block
            del self.age[v]
            for p in range(self.P):                            # relocate the still-valid pages
                lpn = self.owner[v][p]
                if lpn is not None:
                    self._invalidate(lpn)
                    self._program(lpn, self._stream(lpn))      # keep hot with hot, cold with cold
            self.owner[v] = [None] * self.P
            self.erases[v] += 1
            self.free.append(v)

    def _stream(self, lpn):
        return 0 if self.hot is None or self.hot(lpn) else len(self.open) - 1

    def write(self, lpn):
        self.clock += 1
        self.host_writes += 1
        self._invalidate(lpn)
        self._program(lpn, self._stream(lpn))
        self._gc()

    def wa(self):
        return self.flash_writes / self.host_writes

def run(ftl, pattern, n_writes, seed=1):
    rng = random.Random(seed)
    for lpn in range(ftl.logical):                             # fill the drive once
        ftl.write(lpn)
    ftl.host_writes = ftl.flash_writes = 0                     # measure the steady state
    for i in range(n_writes):
        ftl.write(pattern(i, rng, ftl.logical))
    return ftl

sequential = lambda i, rng, n: i % n
uniform = lambda i, rng, n: rng.randrange(n)
def hot_cold(i, rng, n):                                       # 80% of writes go to 20% of the data
    return rng.randrange(n // 5) if rng.random() < 0.8 else n // 5 + rng.randrange(n - n // 5)

if __name__ == "__main__":
    print(f"{'workload':12} {'over-provisioning':>18} {'write amplification':>20}")
    for name, pat in (("sequential", sequential), ("uniform", uniform), ("hot/cold", hot_cold)):
        for op in (0.07, 0.125, 0.28):
            f = run(FTL(op=op), pat, 100_000)
            print(f"{name:12} {100 * op:17.0f}% {f.wa():20.2f}")
