// file: host/tlb.c
// Random accesses touching one int per page versus the same number of accesses in few pages,
// with 4 KiB pages and (if the kernel grants them) 2 MiB transparent huge pages.
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static double walk(char *buf, size_t pages, size_t step, int iters) {
    // a random cyclic permutation of pages; each visit loads one int at a fixed offset of the page
    size_t *order = malloc(pages * sizeof *order);
    for (size_t i = 0; i < pages; i++) order[i] = i;
    srand(1);
    for (size_t i = pages - 1; i > 0; i--) { size_t j = rand() % (i + 1); size_t t = order[i]; order[i] = order[j]; order[j] = t; }
    // a random 64-byte line in each page, so that the lines spread over all cache sets
    size_t *line = malloc(pages * sizeof *line);
    for (size_t i = 0; i < pages; i++) line[i] = (rand() % (step / 64)) * 64;
#define AT(k) (buf + order[k] * step + line[k])
    for (size_t i = 0; i < pages; i++)                       // store "next" pointers: a dependent chain
        *(char **)AT(i) = AT((i + 1) % pages);
    char *p = AT(0);
    free(order); free(line);
    double t = now();
    for (int i = 0; i < iters; i++) p = *(char **)p;
    t = now() - t;
    if (p == 0) puts("");                                    // keep the chain alive
    return t / iters * 1e9;
}

int main(void) {
    const size_t SIZE = 1UL << 30;                           // 1 GiB
    for (int huge = 0; huge <= 1; huge++) {
        char *buf = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        madvise(buf, SIZE, huge ? MADV_HUGEPAGE : MADV_NOHUGEPAGE);
        memset(buf, 1, SIZE);
        long anon_huge = 0;
        FILE *sm = fopen("/proc/self/smaps_rollup", "r");
        char l[256];
        while (sm && fgets(l, sizeof l, sm)) sscanf(l, "AnonHugePages: %ld", &anon_huge);
        if (sm) fclose(sm);
        printf("%s pages requested (%ld MiB of huge pages granted):\n", huge ? "2 MiB huge" : "4 KiB", anon_huge >> 10);
        for (size_t pages = 16; pages <= 65536 * 4; pages *= 4)
            printf("  %7zu blocks, one per 4 KiB page (%5zu MiB span): %5.1f ns per load\n",
                   pages, pages * 4096 >> 20, walk(buf, pages, 4096, 20000000));
        munmap(buf, SIZE);
    }
    FILE *f = fopen("/sys/kernel/mm/transparent_hugepage/enabled", "r");
    char line[128] = "";
    if (f) { if (!fgets(line, sizeof line, f)) line[0] = 0; fclose(f); }
    printf("transparent_hugepage: %s", line);
    return 0;
}
