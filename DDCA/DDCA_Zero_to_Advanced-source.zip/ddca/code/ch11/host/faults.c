// file: host/faults.c
// Demand paging and copy-on-write, observed through the page-fault counter.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static long minor_faults(void) { struct rusage u; getrusage(RUSAGE_SELF, &u); return u.ru_minflt; }
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

int main(void) {
    const size_t SIZE = 64UL << 20, PAGE = 4096;               // 64 MiB = 16,384 pages
    long f0 = minor_faults();
    char *buf = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    madvise(buf, SIZE, MADV_NOHUGEPAGE);
    printf("after mmap of 64 MiB:          %6ld page faults\n", minor_faults() - f0);

    f0 = minor_faults();
    volatile char sum = 0;
    for (size_t i = 0; i < SIZE; i += PAGE) sum += buf[i];      // read every page
    printf("after reading every page:      %6ld page faults\n", minor_faults() - f0);

    f0 = minor_faults();
    double t = now();
    for (size_t i = 0; i < SIZE; i += PAGE) buf[i] = 1;         // write every page
    t = now() - t;
    printf("after writing every page:      %6ld page faults (%.2f us each)\n", minor_faults() - f0,
           t / (SIZE / PAGE) * 1e6);

    f0 = minor_faults();
    for (size_t i = 0; i < SIZE; i += PAGE) buf[i] = 2;         // write again: pages are present
    printf("after writing every page again: %5ld page faults\n", minor_faults() - f0);

    fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {                                              // child shares the pages, read-only
        long c0 = minor_faults();
        for (size_t i = 0; i < SIZE / 2; i += PAGE) buf[i] = 3;  // writing half of them copies them
        printf("child, writing half the pages:  %5ld page faults (copy-on-write)\n", minor_faults() - c0);
        fflush(stdout);
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    printf("parent still sees buf[0] = %d\n", buf[0]);
    return 0;
}
