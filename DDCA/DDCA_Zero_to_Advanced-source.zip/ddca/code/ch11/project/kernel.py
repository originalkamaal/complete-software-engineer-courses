# file: project/kernel.py
"""A tiny operating-system memory manager on top of the Sv32 walker: demand paging,
fork with copy-on-write, and segmentation faults — all driven by page faults."""
import sys
sys.path.insert(0, "../mmu")
from sv32 import *

COW = 1 << 8                     # one of the two PTE bits reserved for software (RSW)

class Process:
    def __init__(self, kernel, asid):
        self.aspace = AddressSpace(kernel.mem, asid)
        self.regions = []        # (start, end, flags) the program is allowed to use
        self.pid = asid

class Kernel:
    def __init__(self):
        self.mem = Memory(32 << 20)
        self.refs = {}           # frame -> number of page-table entries that point to it
        self.stats = {"demand": 0, "cow_copy": 0, "cow_reuse": 0, "segv": 0}

    def pte_addr(self, proc, va):
        """Software walk to the level-0 PTE's address (allocating tables), as an OS does."""
        l1 = proc.aspace.root + 4 * (va >> 22)
        pte = self.mem.r32(l1)
        if not pte & V:
            pte = (self.mem.alloc_frame() >> 12) << 10 | V
            self.mem.w32(l1, pte)
        return (pte >> 10 << 12) + 4 * (va >> 12 & 0x3FF)

    def page_fault(self, proc, va, access):
        region = next((r for r in proc.regions if r[0] <= va < r[1]), None)
        if region is None or (access == "w" and not region[2] & W):
            self.stats["segv"] += 1
            raise PageFault(f"segmentation fault: pid {proc.pid} {access} at {va:08x}")
        pa_pte = self.pte_addr(proc, va)
        pte = self.mem.r32(pa_pte)
        if not pte & V:                                       # first touch: demand paging
            frame = self.mem.alloc_frame()                    # (frames start zeroed)
            self.refs[frame] = 1
            self.mem.w32(pa_pte, (frame >> 12) << 10 | region[2] | U | V)
            self.stats["demand"] += 1
        elif access == "w" and pte & COW:                     # a write to a shared page
            frame = pte >> 10 << 12
            if self.refs[frame] > 1:                          # still shared: copy it
                new = self.mem.alloc_frame()
                self.mem.b[new:new + PAGE] = self.mem.b[frame:frame + PAGE]
                self.refs[frame] -= 1
                self.refs[new] = 1
                frame = new
                self.stats["cow_copy"] += 1
            else:                                             # last user: just make it writable
                self.stats["cow_reuse"] += 1
            self.mem.w32(pa_pte, (frame >> 12) << 10 | (pte & 0xFF) | W)
        else:
            raise PageFault(f"unexpected fault at {va:08x}")
        # a real kernel would now execute sfence.vma to drop stale TLB entries

    def access(self, proc, va, access, value=None):
        for _ in range(2):                                    # try, fault, retry once
            try:
                pa, _, _ = walk(self.mem, proc.aspace.satp(), va, access, user=True)
                break
            except PageFault:
                self.page_fault(proc, va, access)
        if access == "w":
            self.mem.w32(pa, value)
        return self.mem.r32(pa)

    def fork(self, parent, asid):
        child = Process(self, asid)
        child.regions = list(parent.regions)
        for start, end, _ in parent.regions:
            for va in range(start, end, PAGE):
                p = self.pte_addr(parent, va)
                pte = self.mem.r32(p)
                if pte & V:                                   # share the frame, read-only, both sides
                    shared = (pte & ~W) | (COW if pte & W else 0)
                    self.mem.w32(p, shared)
                    self.mem.w32(self.pte_addr(child, va), shared)
                    self.refs[pte >> 10 << 12] += 1
        return child
