# file: project/run.py
from kernel import *

k = Kernel()
parent = Process(k, asid=1)
HEAP = 0x1000_0000
parent.regions.append((HEAP, HEAP + 16 * PAGE, R | W))          # a 64 KiB heap, nothing mapped yet
parent.regions.append((0x0001_0000, 0x0001_0000 + PAGE, R))     # a read-only page

def frames():
    return (k.mem.next_free - PAGE) // PAGE

for i in range(8):                                               # touch 8 of the 16 heap pages
    k.access(parent, HEAP + i * PAGE, "w", 100 + i)
print(f"parent wrote 8 pages: {k.stats}, frames in use {frames()}")

child = k.fork(parent, asid=2)
print(f"after fork:           {k.stats}, frames in use {frames()}")
for i in (0, 1):
    k.access(child, HEAP + i * PAGE, "w", 900 + i)               # child writes 2 shared pages
print(f"child wrote 2 pages:  {k.stats}, frames in use {frames()}")
print("parent reads", [k.access(parent, HEAP + i * PAGE, "r") for i in range(4)],
      " child reads", [k.access(child, HEAP + i * PAGE, "r") for i in range(4)])

k.access(parent, HEAP + 0 * PAGE, "w", 7)                        # parent is now the only user
k.access(parent, HEAP + 5 * PAGE, "w", 8)                        # still shared with the child
print(f"parent wrote 2 pages: {k.stats}, frames in use {frames()}")
print("child still reads page 5 as", k.access(child, HEAP + 5 * PAGE, "r"))

for va, acc in ((HEAP + 20 * PAGE, "r"), (0x0001_0000, "w")):
    try:
        k.access(parent, va, acc, 1)
    except PageFault as e:
        print(e)
print(f"final: {k.stats}")
