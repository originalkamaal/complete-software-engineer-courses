# file: mmu/sv32.py
"""RISC-V Sv32 virtual memory: page tables in simulated physical memory, a hardware page-table
walker following the privileged specification (section 4.3.2), and a TLB with ASIDs."""
from collections import OrderedDict

V, R, W, X, U, G, A, D = (1 << i for i in range(8))
PAGE = 4096

class PageFault(Exception):
    pass

class Memory:
    def __init__(self, size):
        self.b = bytearray(size)
        self.next_free = PAGE                 # frame 0 is never handed out
        self.reads = 0
    def alloc_frame(self):
        f, self.next_free = self.next_free, self.next_free + PAGE
        return f
    def r32(self, a):
        self.reads += 1
        return int.from_bytes(self.b[a:a + 4], "little")
    def w32(self, a, v):
        self.b[a:a + 4] = v.to_bytes(4, "little")

class AddressSpace:
    """What an operating system does: build a two-level page table."""
    def __init__(self, mem, asid):
        self.mem, self.asid = mem, asid
        self.root = mem.alloc_frame()
    def satp(self):
        return 1 << 31 | self.asid << 22 | self.root >> 12          # MODE = Sv32
    def map(self, va, pa, flags, mega=False):
        vpn1, vpn0 = va >> 22, va >> 12 & 0x3FF
        l1 = self.root + 4 * vpn1
        if mega:                                                    # a 4 MiB leaf at level 1
            self.mem.w32(l1, (pa >> 12) << 10 | flags | V)
            return
        pte = self.mem.r32(l1)
        if not pte & V:                                             # allocate a level-0 table
            pte = (self.mem.alloc_frame() >> 12) << 10 | V          # pointer: V=1, R=W=X=0
            self.mem.w32(l1, pte)
        self.mem.w32((pte >> 10 << 12) + 4 * vpn0, (pa >> 12) << 10 | flags | V)

def walk(mem, satp, va, access, user):
    """The hardware walker. access is 'r', 'w' or 'x'. Returns (physical address, level, pte flags)."""
    a = (satp & 0x3FFFFF) << 12
    vpn = [va >> 12 & 0x3FF, va >> 22]
    for i in (1, 0):
        pte_addr = a + 4 * vpn[i]
        pte = mem.r32(pte_addr)
        if not pte & V or (not pte & R and pte & W):
            raise PageFault(f"invalid PTE at level {i}")
        if pte & (R | X):
            break                                                   # a leaf
        if i == 0:
            raise PageFault("pointer PTE at level 0")
        a = (pte >> 10) << 12
    need = {"r": R, "w": W, "x": X}[access]
    if not pte & need:
        raise PageFault(f"no {access} permission")
    if user and not pte & U:
        raise PageFault("user access to a supervisor page")
    if not user and pte & U:
        raise PageFault("supervisor access to a user page (SUM=0)")
    if i == 1 and (pte >> 10) & 0x3FF:
        raise PageFault("misaligned megapage")
    new = pte | A | (D if access == "w" else 0)                     # hardware A/D update (Svadu)
    if new != pte:
        mem.w32(pte_addr, new)
    ppn = pte >> 10
    if i == 1:
        pa = (ppn >> 10) << 22 | va & 0x3FFFFF                      # superpage: keep VPN[0] and offset
    else:
        pa = ppn << 12 | va & 0xFFF
    return pa, i, new & 0xFF

class TLB:
    def __init__(self, entries):
        self.n, self.e = entries, OrderedDict()                     # (asid, vpn, level) -> (ppn base, flags)
        self.hits = self.misses = 0
    def translate(self, mem, satp, va, access, user):
        asid = satp >> 22 & 0x1FF
        for level, shift in ((0, 12), (1, 22)):
            for key in ((asid, va >> shift, level), (None, va >> shift, level)):   # None = global
                if key in self.e:
                    base, flags = self.e[key]
                    if {"r": R, "w": W, "x": X}[access] & flags and bool(flags & U) == user \
                            and (access != "w" or flags & D):
                        self.hits += 1
                        self.e.move_to_end(key)
                        return base | va & ((1 << shift) - 1)
        self.misses += 1
        pa, level, flags = walk(mem, satp, va, access, user)
        shift = 22 if level else 12
        key = (None if flags & G else asid, va >> shift, level)
        if len(self.e) == self.n:
            self.e.popitem(last=False)                               # evict least recently used
        self.e[key] = (pa >> shift << shift, flags)
        return pa
