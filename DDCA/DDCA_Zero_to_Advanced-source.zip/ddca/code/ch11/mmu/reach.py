# file: mmu/reach.py
"""TLB reach: how much memory a TLB covers, and what megapages and ASIDs change."""
import random
from sv32 import *

def setup(mega, span, asid=1, mem=None):
    mem = mem or Memory(96 << 20)
    asp = AddressSpace(mem, asid)
    if mega:
        for off in range(0, span, 1 << 22):
            asp.map(0x0040_0000 + off, 0x0100_0000 + off, R | W | U, mega=True)
    else:
        for off in range(0, span, PAGE):
            asp.map(0x0040_0000 + off, 0x0100_0000 + off, R | W | U)
    return mem, asp

rng = random.Random(1)
print(f"{'working set':>12} {'pages':>8} {'TLB entries':>12} {'TLB miss %':>11} {'PTE reads per access':>21}")
for span in (64 << 10, 1 << 20, 16 << 20):
    trace = [0x0040_0000 + rng.randrange(span) & ~3 for _ in range(20000)]
    for mega in (False, True):
        for entries in (16, 64):
            mem, asp = setup(mega, span)
            tlb, before = TLB(entries), mem.reads
            for va in trace:
                tlb.translate(mem, asp.satp(), va, "r", True)
            print(f"{span >> 10:9d} KiB {'4 MiB' if mega else '4 KiB':>8} {entries:12d} "
                  f"{100 * tlb.misses / len(trace):10.1f}% {(mem.reads - before) / len(trace):21.2f}")

# two processes take turns, 200 accesses each, 50 times
mem, p1 = setup(False, 128 << 10, asid=1)
mem, p2 = setup(False, 128 << 10, asid=2, mem=mem)
for use_asid in (False, True):
    tlb = TLB(64)
    for turn in range(100):
        p = (p1, p2)[turn % 2]
        if not use_asid:
            tlb.e.clear()                         # without ASIDs the OS must flush on every switch
        for _ in range(200):
            tlb.translate(mem, p.satp(), 0x0040_0000 + rng.randrange(128 << 10) & ~3, "r", True)
    print(f"two processes, 32 pages each, 64-entry TLB, {'ASIDs   ' if use_asid else 'flushing'}: "
          f"{100 * tlb.misses / (tlb.hits + tlb.misses):.1f}% TLB misses")
