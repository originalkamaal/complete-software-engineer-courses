# file: mmu/demo.py
from sv32 import *

mem = Memory(64 << 20)
p1 = AddressSpace(mem, asid=1)
code, data, kern = mem.alloc_frame(), mem.alloc_frame(), mem.alloc_frame()
p1.map(0x0001_0000, code, R | X | U)                    # user code: read + execute
p1.map(0x0002_0000, data, R | W | U)                    # user data: read + write
p1.map(0xC000_0000, kern, R | W | G)                    # kernel data, global, supervisor only
p1.map(0x8000_0000, 0x0040_0000, R | W | X | G, mega=True)  # 4 MiB kernel megapage at PA 4 MiB

tests = [("user fetch from code page", 0x0001_0ABC, "x", True),
         ("user store to data page", 0x0002_0010, "w", True),
         ("user store to code page", 0x0001_0000, "w", True),
         ("user load from kernel page", 0xC000_0000, "r", True),
         ("kernel load from kernel page", 0xC000_0123, "r", False),
         ("kernel load inside megapage", 0x8012_3456, "r", False),
         ("user load from unmapped page", 0x0003_0000, "r", True)]
for name, va, acc, user in tests:
    before = mem.reads
    try:
        pa, level, flags = walk(mem, p1.satp(), va, acc, user)
        print(f"{name:30} VA {va:08x} -> PA {pa:08x}  level {level}, "
              f"{mem.reads - before} PTE reads, A={flags >> 6 & 1} D={flags >> 7 & 1}")
    except PageFault as e:
        print(f"{name:30} VA {va:08x} -> page fault: {e}")
