// file: host/matmul.c
// Matrix multiply three ways: the naive ijk order, the cache-friendly ikj order, and blocked (tiled).
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifndef N
#define N 1024
#endif
static double A[N][N], B[N][N], C[N][N];

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

__attribute__((noipa)) static void ijk(void) {           // inner loop walks B down a column
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            double s = 0;
            for (int k = 0; k < N; k++) s += A[i][k] * B[k][j];
            C[i][j] = s;
        }
}
__attribute__((noipa)) static void ikj(void) {           // inner loop walks B and C along rows
    for (int i = 0; i < N; i++)
        for (int k = 0; k < N; k++) {
            double a = A[i][k];
            for (int j = 0; j < N; j++) C[i][j] += a * B[k][j];
        }
}
__attribute__((noipa)) static void blocked(int T) {      // T x T tiles that stay in the cache
    for (int ii = 0; ii < N; ii += T)
        for (int kk = 0; kk < N; kk += T)
            for (int jj = 0; jj < N; jj += T)
                for (int i = ii; i < ii + T && i < N; i++)
                    for (int k = kk; k < kk + T && k < N; k++) {
                        double a = A[i][k];
                        for (int j = jj; j < jj + T && j < N; j++) C[i][j] += a * B[k][j];
                    }
}
static double check(void) { double s = 0; for (int i = 0; i < N; i++) s += C[i][(i * 7) % N]; return s; }
static void clear(void) { for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) C[i][j] = 0; }

int main(void) {
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) { A[i][j] = (i + j) % 7; B[i][j] = (i * j) % 5; }
    double t;
    t = now(); ijk(); printf("ijk          %6.2f s  check %.0f\n", now() - t, check());
    clear(); t = now(); ikj(); printf("ikj          %6.2f s  check %.0f\n", now() - t, check());
    for (int T = 16; T <= 256; T *= 4) {
        clear(); t = now(); blocked(T); printf("blocked %3d  %6.2f s  check %.0f\n", T, now() - t, check());
    }
    return 0;
}
