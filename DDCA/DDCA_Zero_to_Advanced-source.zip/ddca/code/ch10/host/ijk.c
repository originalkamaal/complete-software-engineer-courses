// file: host/ijk.c
// Only the naive ijk loop, for counting cache misses with perf.
#include <stdio.h>
#ifndef N
#define N 1024
#endif
static double A[N][N], B[N][N], C[N][N];
int main(void) {
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) { A[i][j] = (i + j) % 7; B[i][j] = (i * j) % 5; }
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            double s = 0;
            for (int k = 0; k < N; k++) s += A[i][k] * B[k][j];
            C[i][j] = s;
        }
    double check = 0;
    for (int i = 0; i < N; i++) check += C[i][i];
    printf("N=%d check %.0f\n", N, check);
    return 0;
}
