# file: sim/replace.py
"""Replacement policies on a fully associative cache of 64 blocks: LRU, FIFO, random,
and Belady's OPT (evict the block used furthest in the future: the unreachable ideal)."""
from cachesim import Cache
import random

BLOCKS, BLOCK = 64, 64

def opt_misses(trace):
    blocks = [a // BLOCK for a in trace]
    next_use, last = [0] * len(blocks), {}
    for i in range(len(blocks) - 1, -1, -1):             # when is each block used next?
        next_use[i] = last.get(blocks[i], float("inf"))
        last[blocks[i]] = i
    cache, misses = {}, 0                                # block -> its next use
    for i, b in enumerate(blocks):
        if b not in cache:
            misses += 1
            if len(cache) == BLOCKS:
                del cache[max(cache, key=cache.get)]
        cache[b] = next_use[i]
    return misses

def run(trace):
    out = []
    for policy in ("lru", "fifo", "random"):
        c = Cache(BLOCKS * BLOCK, BLOCK, BLOCKS, policy)
        for a in trace:
            c.access(a)
        out.append(c.misses)
    out.append(opt_misses(trace))
    return [100 * m / len(trace) for m in out]

rng = random.Random(3)
hot = [rng.randrange(0, 48 * BLOCK) for _ in range(20000)]
traces = {
    "loop over 60 blocks": [b * BLOCK for _ in range(100) for b in range(60)],
    "loop over 65 blocks": [b * BLOCK for _ in range(100) for b in range(65)],
    "loop over 96 blocks": [b * BLOCK for _ in range(100) for b in range(96)],
    "hot set of 48 + a scan": [x for i, h in enumerate(hot) for x in ((h,) if i % 4 else (h, (10000 + i) * BLOCK))],
    "random over 128 blocks": [rng.randrange(0, 128 * BLOCK) for _ in range(20000)],
}
print(f"{'access pattern (64-block cache)':32} {'LRU':>6} {'FIFO':>6} {'random':>7} {'OPT':>6}   (miss %)")
for name, t in traces.items():
    print(f"{name:32} " + " ".join(f"{m:6.1f}" for m in run(t)))
