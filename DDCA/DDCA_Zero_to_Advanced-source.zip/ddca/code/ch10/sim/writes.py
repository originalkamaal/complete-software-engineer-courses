# file: sim/writes.py
"""Memory traffic of write-through versus write-back caches for three store patterns."""
from cachesim import Cache
import random

rng = random.Random(5)
patterns = {
    "counter updated 10,000 times": [(0, True)] * 10000,
    "array of 4096 ints written once": [(4 * i, True) for i in range(4096)],
    "read-mostly, 10% stores, 4 KiB": [(rng.randrange(0, 4096, 4), rng.random() < 0.1) for _ in range(10000)],
}
print(f"{'pattern (8 KiB, 4-way, 64 B blocks)':34} {'write-through: words to memory':>31} {'write-back: blocks to memory':>29}")
for name, trace in patterns.items():
    wt, wb = Cache(8192, 64, 4, write_back=False), Cache(8192, 64, 4)
    for a, w in trace:
        wt.access(a, w); wb.access(a, w)
    dirty = sum(d for s in wb.data for d in s.values())     # still dirty: written back at the end
    print(f"{name:34} {wt.mem_writes:31d} {wb.writebacks + dirty:29d}")
