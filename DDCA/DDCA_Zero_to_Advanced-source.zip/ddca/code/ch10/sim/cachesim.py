# file: sim/cachesim.py
"""A trace-driven cache simulator: size, block size, associativity, replacement policy,
write policy, and classification of misses into compulsory, capacity, and conflict (the 3 Cs)."""
import random
from collections import OrderedDict

class Cache:
    def __init__(self, size, block, ways, policy="lru", write_back=True, seed=1):
        self.block, self.ways = block, ways
        self.sets = size // (block * ways)
        assert self.sets * block * ways == size and self.sets & (self.sets - 1) == 0
        self.data = [OrderedDict() for _ in range(self.sets)]   # tag -> dirty, in LRU order
        self.policy, self.write_back = policy, write_back
        self.rng = random.Random(seed)
        self.hits = self.misses = self.writebacks = self.mem_writes = 0

    def split(self, addr):
        blk = addr // self.block
        return blk % self.sets, blk // self.sets            # index, tag

    def access(self, addr, write=False):
        index, tag = self.split(addr)
        s = self.data[index]
        if tag in s:
            self.hits += 1
            if self.policy == "lru":
                s.move_to_end(tag)                           # most recently used goes last
            hit = True
        else:
            self.misses += 1
            if write and not self.write_back:                # write-through, no write-allocate
                self.mem_writes += 1
                return False
            if len(s) == self.ways:                          # evict a victim
                if self.policy == "random":
                    victim = self.rng.choice(list(s))
                else:                                        # lru and fifo both evict the first
                    victim = next(iter(s))
                if s.pop(victim):
                    self.writebacks += 1
            s[tag] = False
            hit = False
        if write:
            if self.write_back:
                s[tag] = True                                # mark dirty; memory updated on eviction
            else:
                self.mem_writes += 1                         # write-through: every store goes to memory
        return hit

def classify(trace, size, block, ways):
    """3C model: compulsory = first touch of a block; capacity = also misses in a fully associative
    LRU cache of the same size; conflict = the rest."""
    real = Cache(size, block, ways)
    full = Cache(size, block, size // block)
    seen = set()
    comp = cap = conf = 0
    for addr in trace:
        blk = addr // block
        h_real, h_full = real.access(addr), full.access(addr)
        if not h_real:
            if blk not in seen:
                comp += 1
            elif not h_full:
                cap += 1
            else:
                conf += 1
        seen.add(blk)
    return comp, cap, conf, len(trace)
