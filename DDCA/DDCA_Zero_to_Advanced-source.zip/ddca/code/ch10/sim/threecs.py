# file: sim/threecs.py
from cachesim import Cache, classify
import random

def matrix_walk(n, by_row, base=0, elem=4, reps=2):
    """Read an n x n int matrix stored row-major, `reps` times, by rows or by columns."""
    return [base + elem * (i * n + j if by_row else j * n + i)
            for _ in range(reps) for i in range(n) for j in range(n)]

def ping_pong(stride, n=256, reps=4):
    """Alternate between two arrays whose starts are `stride` bytes apart."""
    return [base + 4 * i for _ in range(reps) for i in range(n) for base in (0, stride)]

rng = random.Random(7)
traces = {
    "row-major walk of 64x64 ints": matrix_walk(64, True),
    "column walk of 64x64 ints": matrix_walk(64, False),
    "two arrays 8 KiB apart": ping_pong(8192),
    "two arrays 8 KiB + 64 B apart": ping_pong(8192 + 64),
    "random in 32 KiB": [rng.randrange(0, 32768, 4) for _ in range(20000)],
}
print("8 KiB cache, 64-byte blocks")
print(f"{'trace':32} {'ways':>4} {'miss %':>7} {'compulsory':>11} {'capacity':>9} {'conflict':>9}")
for name, t in traces.items():
    for ways in (1, 4):
        comp, cap, conf, n = classify(t, 8192, 64, ways)
        print(f"{name:32} {ways:4d} {100 * (comp + cap + conf) / n:6.1f}% {comp:11d} {cap:9d} {conf:9d}")
