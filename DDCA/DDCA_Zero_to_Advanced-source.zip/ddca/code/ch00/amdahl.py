# file: amdahl.py
def speedup(p, s):
    return 1 / ((1 - p) + p / s)

for p in (0.5, 0.9, 0.99):
    row = "  ".join(f"s={s:>4}: {speedup(p, s):6.2f}x" for s in (2, 10, 100, 1_000_000))
    print(f"p={p:<4} {row}   limit {1 / (1 - p):.0f}x")
print(f"FPU 2x faster on a program 5% FP: {speedup(0.05, 2):.3f}x")
