// file: chase.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(void) {
    printf("%10s  %8s\n", "size", "ns/load");
    for (size_t bytes = 4 << 10; bytes <= (256u << 20); bytes *= 2) {
        size_t n = bytes / sizeof(void *);
        void **mem = malloc(n * sizeof(void *));
        size_t *perm = malloc(n * sizeof(size_t));
        for (size_t i = 0; i < n; i++) perm[i] = i;
        srand(42);
        for (size_t i = n - 1; i > 0; i--) {               // random cyclic order (Fisher–Yates)
            size_t j = (size_t)rand() % (i + 1);
            size_t t = perm[i]; perm[i] = perm[j]; perm[j] = t;
        }
        for (size_t i = 0; i < n; i++) mem[perm[i]] = &mem[perm[(i + 1) % n]];
        void **p = &mem[perm[0]];
        long steps = 20 * 1000 * 1000;
        double t0 = now();
        for (long i = 0; i < steps; i++) p = (void **)*p;  // each load depends on the last
        double ns = (now() - t0) * 1e9 / steps;
        printf("%8zu KiB  %8.1f%s\n", bytes >> 10, ns, p == NULL ? "!" : "");
        free(mem);
        free(perm);
    }
    return 0;
}
