// file: flushreload.c
#include <stdint.h>
#include <stdio.h>
#include <x86intrin.h>

#define LINES 16
#define STRIDE 4096                       // one line per page: defeats the adjacent-line prefetcher

static uint8_t probe[LINES * STRIDE];

static void victim(int secret) {
    volatile uint8_t x = probe[secret * STRIDE];   // the only trace of the secret: one cache line
    (void)x;
}

static uint64_t time_load(volatile uint8_t *p) {
    unsigned aux;
    _mm_mfence();
    uint64_t t0 = __rdtscp(&aux);
    (void)*p;
    uint64_t t1 = __rdtscp(&aux);
    return t1 - t0;
}

static int recover(int secret) {
    int votes[LINES] = {0};
    for (int trial = 0; trial < 200; trial++) {
        for (int i = 0; i < LINES; i++) _mm_clflush(&probe[i * STRIDE]);   // flush
        _mm_mfence();
        victim(secret);                                                   // victim runs
        int best = 0;
        uint64_t best_t = UINT64_MAX;
        for (int k = 0; k < LINES; k++) {                                 // reload, in a scrambled order
            int i = (k * 7 + trial) % LINES;
            uint64_t t = time_load(&probe[i * STRIDE]);
            if (t < best_t) { best_t = t; best = i; }
        }
        votes[best]++;
    }
    int guess = 0;
    for (int i = 1; i < LINES; i++) if (votes[i] > votes[guess]) guess = i;
    return guess;
}

int main(void) {
    for (int i = 0; i < LINES * STRIDE; i++) probe[i] = 1;          // make the pages real
    int secrets[] = {3, 11, 7, 0, 15};
    for (int k = 0; k < 5; k++)
        printf("victim's secret %2d -> attacker recovered %2d\n", secrets[k], recover(secrets[k]));
    return 0;
}
