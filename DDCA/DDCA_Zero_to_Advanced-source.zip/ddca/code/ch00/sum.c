// file: sum.c
#include <stdio.h>

long sum(const long *a, long n) {
    long s = 0;
    for (long i = 0; i < n; i++)
        s += a[i];
    return s;
}

int main(void) {
    long data[] = {3, 1, 4, 1, 5, 9, 2, 6};
    printf("sum = %ld\n", sum(data, 8));
    return 0;
}
