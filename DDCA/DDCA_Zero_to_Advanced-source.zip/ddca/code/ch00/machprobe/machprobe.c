// file: machprobe/machprobe.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

static double chase_ns(size_t bytes) {
    size_t n = bytes / sizeof(void *);
    void **mem = malloc(n * sizeof(void *));
    size_t *perm = malloc(n * sizeof(size_t));
    for (size_t i = 0; i < n; i++) perm[i] = i;
    srand(7);
    for (size_t i = n - 1; i > 0; i--) {
        size_t j = (size_t)rand() % (i + 1);
        size_t t = perm[i]; perm[i] = perm[j]; perm[j] = t;
    }
    for (size_t i = 0; i < n; i++) mem[perm[i]] = &mem[perm[(i + 1) % n]];
    void **p = &mem[perm[0]];
    long steps = 5 * 1000 * 1000;
    double best = 1e9;
    for (int rep = 0; rep < 3; rep++) {
        double t0 = now();
        for (long i = 0; i < steps; i++) p = (void **)*p;
        double ns = (now() - t0) * 1e9 / steps;
        if (ns < best) best = ns;
    }
    if (p == NULL) puts("");
    free(mem);
    free(perm);
    return best;
}

static double branch_ns(int sorted) {
    enum { N = 1 << 20 };
    static int a[N];
    srand(3);
    for (int i = 0; i < N; i++) a[i] = rand() % 256;
    if (sorted) {
        int count[256] = {0}, k = 0;
        for (int i = 0; i < N; i++) count[a[i]]++;
        for (int v = 0; v < 256; v++) while (count[v]--) a[k++] = v;
    }
    volatile long sink = 0;
    double best = 1e9;
    for (int rep = 0; rep < 5; rep++) {
        double t0 = now();
        long s = 0;
        for (int i = 0; i < N; i++)
            if (a[i] >= 128) {
                s += a[i];
                __asm__ volatile("");              // keep the branch: no conditional-move rewrite
            }
        sink = s;
        double t = (now() - t0) * 1e9 / N;
        if (t < best) best = t;
    }
    (void)sink;
    return best;
}

static double stream_gbs(void) {
    size_t n = (128u << 20) / sizeof(long);
    long *a = malloc(n * sizeof(long));
    for (size_t i = 0; i < n; i++) a[i] = (long)i;
    double best = 1e9;
    volatile long sink;
    for (int rep = 0; rep < 3; rep++) {
        double t0 = now();
        long s = 0;
        for (size_t i = 0; i < n; i++) s += a[i];
        sink = s;
        double t = now() - t0;
        if (t < best) best = t;
    }
    (void)sink;
    free(a);
    return n * sizeof(long) / best / 1e9;
}

int main(void) {
    printf("== memory latency (pointer chasing) ==\n");
    double prev = 0;
    for (size_t kib = 8; kib <= 128 * 1024; kib *= 2) {
        double ns = chase_ns(kib << 10);
        const char *mark = (prev > 0 && ns > 1.6 * prev) ? "  <- jump" : "";
        printf("%8zu KiB %7.1f ns%s\n", kib, ns, mark);
        prev = ns;
    }
    printf("== bandwidth ==\nsequential read %.1f GB/s\n", stream_gbs());
    double r = branch_ns(0), s = branch_ns(1);
    printf("== branches ==\nrandom %.2f ns/elem, sorted %.2f ns/elem\n", r, s);
    printf("estimated misprediction penalty: %.1f ns (half of the random branches mispredict)\n", (r - s) * 2);
    return 0;
}
