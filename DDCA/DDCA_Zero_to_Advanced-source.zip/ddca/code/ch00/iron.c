// file: iron.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 2000000

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

static long work_branchy(const int *a, long n) {
    long s = 0;
    for (long i = 0; i < n; i++)
        if (a[i] >= 128) {                   // a data-dependent branch
            s += a[i];
            __asm__ volatile("");            // keeps it a branch (see below)
        }
    return s;
}

int main(int argc, char **argv) {
    int sorted = argc > 1;
    int *a = malloc(N * sizeof *a);
    srand(1);
    for (long i = 0; i < N; i++) a[i] = rand() % 256;
    if (sorted) {                              // counting sort: same values, in order
        long count[256] = {0};
        for (long i = 0; i < N; i++) count[a[i]]++;
        long k = 0;
        for (int v = 0; v < 256; v++) while (count[v]--) a[k++] = v;
    }
    long s = 0;
    double t0 = now();
    for (int rep = 0; rep < 20; rep++) s += work_branchy(a, N);
    printf("%s: s = %ld, %.0f ms\n", sorted ? "sorted" : "random", s, (now() - t0) * 1e3);
    free(a);
    return 0;
}
