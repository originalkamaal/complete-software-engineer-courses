// file: stream.c
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(void) {
    size_t n = (256u << 20) / sizeof(long);               // 256 MiB: far beyond the caches
    long *a = malloc(n * sizeof(long));
    for (size_t i = 0; i < n; i++) a[i] = (long)i;
    long s = 0;
    double best = 1e9;
    for (int rep = 0; rep < 5; rep++) {
        double t0 = now();
        for (size_t i = 0; i < n; i++) s += a[i];
        double t = now() - t0;
        if (t < best) best = t;
    }
    double gbs = n * sizeof(long) / best / 1e9;
    printf("sequential read: %.1f GB/s (checksum %ld)\n", gbs, s & 1);
    printf("time per 8-byte element: %.2f ns\n", best * 1e9 / n);
    free(a);
    return 0;
}
